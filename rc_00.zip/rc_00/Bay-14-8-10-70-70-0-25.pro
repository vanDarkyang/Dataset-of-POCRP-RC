Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_0 C_3 A_1 H_0 G_2 
Stack 2
H_1 D_3 H_4 I_1 B_1 
Stack 3
B_5 F_4 E_7 E_3 I_4 
Stack 4
E_1 J_3 C_1 E_6 I_5 
Stack 5
F_2 H_2 F_0 D_2 A_2 
Stack 6
H_6 G_0 F_6 F_5 C_5 
Stack 7
A_0 J_2 D_4 E_2 H_5 
Stack 8
G_7 D_6 F_7 C_2 B_4 
Stack 9
F_1 J_1 D_1 E_5 G_3 
Stack 10
G_1 A_4 C_4 G_5 G_4 
Stack 11
E_8 B_0 E_0 I_3 F_3 
Stack 12
D_5 E_4 I_2 C_0 J_4 
Stack 13
B_3 D_7 I_0 A_3 B_2 
Stack 14
J_0 H_3 G_6 C_6 F_8 
