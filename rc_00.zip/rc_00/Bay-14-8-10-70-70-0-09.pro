Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_0 E_5 F_5 C_5 F_2 
Stack 2
D_3 J_4 H_5 I_3 E_6 
Stack 3
B_3 G_2 B_1 H_2 I_1 
Stack 4
C_6 D_4 A_4 J_3 E_1 
Stack 5
D_1 C_3 D_2 G_0 B_2 
Stack 6
C_1 D_5 E_0 D_0 J_1 
Stack 7
G_5 A_2 G_4 I_4 A_3 
Stack 8
C_2 E_3 J_2 B_4 D_6 
Stack 9
E_8 E_2 H_4 J_0 I_2 
Stack 10
F_7 H_3 A_1 C_4 G_6 
Stack 11
B_0 E_7 I_0 D_7 F_6 
Stack 12
F_8 C_0 B_5 G_7 F_0 
Stack 13
G_1 E_4 A_0 F_3 G_3 
Stack 14
I_5 H_1 F_4 F_1 H_6 
