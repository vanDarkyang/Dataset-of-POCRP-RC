Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_3 D_3 D_12 B_7 F_1 B_4 
Stack 2
B_2 A_6 H_9 G_3 E_3 F_8 
Stack 3
E_13 A_8 G_5 G_9 G_2 C_2 
Stack 4
H_10 C_1 A_3 G_1 C_0 D_4 
Stack 5
I_8 F_3 E_2 E_5 I_6 G_11 
Stack 6
D_9 D_1 E_7 B_1 H_11 
Stack 7
B_9 D_5 C_10 D_7 J_0 
Stack 8
D_0 B_0 H_1 E_12 C_9 
Stack 9
E_11 A_1 I_2 A_0 F_5 
Stack 10
B_5 J_6 J_9 H_0 J_2 
Stack 11
J_1 D_10 D_2 A_2 F_6 
Stack 12
F_2 F_9 C_3 B_8 H_7 
Stack 13
E_8 D_11 C_11 J_5 F_7 
Stack 14
I_0 H_5 I_9 G_7 D_6 
Stack 15
I_5 J_8 D_8 A_5 A_9 
Stack 16
I_3 F_0 C_8 A_7 G_6 
Stack 17
F_11 I_1 G_10 E_9 B_3 
Stack 18
J_4 G_4 G_0 G_12 C_7 
Stack 19
E_1 I_10 B_6 E_10 H_3 
Stack 20
C_5 I_7 E_0 F_12 C_4 
Stack 21
J_7 F_10 C_6 F_4 G_8 
Stack 22
H_6 E_6 H_8 H_4 H_2 
Stack 23
I_4 E_4 B_10 F_13 A_4 
