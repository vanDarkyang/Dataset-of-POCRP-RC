Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
M_0 M_2 F_1 L_4 
Stack 2
C_1 D_4 N_1 K_6 
Stack 3
H_3 J_6 H_8 J_7 
Stack 4
C_0 I_7 G_4 L_0 
Stack 5
G_2 J_3 H_2 M_3 
Stack 6
H_4 K_0 G_1 F_6 
Stack 7
D_0 I_5 O_2 D_5 
Stack 8
F_7 O_1 A_2 L_1 
Stack 9
I_6 H_1 E_5 E_0 
Stack 10
C_4 E_2 G_0 G_7 
Stack 11
C_3 G_5 B_0 I_8 
Stack 12
E_3 M_4 A_1 F_0 
Stack 13
F_3 J_2 B_2 H_0 
Stack 14
I_1 G_8 N_2 F_4 
Stack 15
D_3 L_5 F_5 A_0 
Stack 16
K_2 K_1 E_4 H_7 
Stack 17
B_1 D_1 K_4 O_0 
Stack 18
F_2 J_5 G_3 M_1 
Stack 19
I_3 I_4 L_3 B_3 
Stack 20
H_6 J_0 E_6 I_2 
Stack 21
D_2 K_5 G_6 N_3 
Stack 22
N_0 H_9 L_2 E_1 
Stack 23
C_2 J_1 K_3 
Stack 24
H_5 I_0 J_4 
