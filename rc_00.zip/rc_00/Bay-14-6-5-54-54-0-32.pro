Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_3 D_1 E_8 C_11 
Stack 2
B_3 B_9 C_5 A_8 
Stack 3
C_8 B_0 C_3 A_2 
Stack 4
C_1 A_1 A_5 D_5 
Stack 5
B_1 E_5 B_5 C_9 
Stack 6
B_10 A_9 C_10 D_8 
Stack 7
E_7 D_9 C_0 B_8 
Stack 8
D_2 B_2 E_0 B_4 
Stack 9
B_7 C_6 C_4 E_9 
Stack 10
D_0 A_3 D_7 C_2 
Stack 11
C_7 E_6 A_0 A_7 
Stack 12
E_4 E_1 D_6 D_4 
Stack 13
D_10 A_4 E_3 
Stack 14
B_6 E_2 A_6 
