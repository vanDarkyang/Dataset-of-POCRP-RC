Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_3 H_0 F_6 G_8 A_5 H_9 
Stack 2
C_7 B_0 C_6 B_10 B_4 A_8 
Stack 3
J_6 E_6 I_0 C_3 I_6 C_10 
Stack 4
I_4 F_10 J_0 H_10 D_10 A_6 
Stack 5
C_0 D_8 E_8 F_12 G_1 H_1 
Stack 6
B_1 F_2 J_7 E_10 H_6 
Stack 7
D_3 D_6 E_7 C_9 I_5 
Stack 8
A_1 B_8 G_6 J_2 H_5 
Stack 9
E_4 A_7 I_9 G_11 D_12 
Stack 10
G_12 A_4 H_8 D_9 I_7 
Stack 11
E_2 F_13 F_9 G_2 H_4 
Stack 12
I_1 H_3 H_7 J_9 H_11 
Stack 13
D_0 B_9 F_11 F_4 B_2 
Stack 14
E_12 J_5 J_4 A_2 G_10 
Stack 15
G_3 E_11 F_8 B_7 G_5 
Stack 16
E_3 J_8 E_13 C_4 D_4 
Stack 17
A_9 F_7 G_4 C_2 E_1 
Stack 18
D_11 A_0 G_0 D_5 I_8 
Stack 19
G_9 F_0 F_1 D_7 C_8 
Stack 20
E_9 G_7 C_1 I_3 J_1 
Stack 21
C_11 E_5 E_0 I_10 D_1 
Stack 22
I_2 H_2 F_3 F_5 B_6 
Stack 23
J_3 C_5 B_5 A_3 D_2 
