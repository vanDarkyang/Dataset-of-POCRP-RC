Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
L_4 F_4 L_5 H_9 
Stack 2
M_3 J_5 G_2 H_0 
Stack 3
A_0 D_3 I_0 M_0 
Stack 4
E_6 G_8 I_3 D_4 
Stack 5
F_5 I_2 D_2 J_7 
Stack 6
A_1 J_2 H_3 C_3 
Stack 7
F_6 E_5 G_1 J_1 
Stack 8
B_2 J_6 E_1 N_1 
Stack 9
N_0 N_3 H_8 J_4 
Stack 10
F_3 D_5 L_0 E_0 
Stack 11
H_7 F_7 M_2 G_4 
Stack 12
N_2 O_0 C_0 J_0 
Stack 13
I_7 L_3 H_2 G_7 
Stack 14
C_2 M_1 F_0 H_5 
Stack 15
G_5 H_1 C_4 F_1 
Stack 16
K_1 O_1 L_2 B_1 
Stack 17
L_1 I_1 K_2 I_8 
Stack 18
E_2 K_6 E_3 D_1 
Stack 19
B_3 I_5 E_4 G_0 
Stack 20
A_2 F_2 O_2 M_4 
Stack 21
I_6 C_1 K_0 H_4 
Stack 22
K_5 K_4 K_3 H_6 
Stack 23
G_6 J_3 G_3 
Stack 24
I_4 B_0 D_0 
