Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_8 B_3 C_9 B_2 B_4 C_15 
Stack 2
A_10 A_7 C_7 D_3 D_7 B_8 
Stack 3
D_12 B_12 A_2 D_5 C_12 E_4 
Stack 4
E_8 D_11 D_9 C_2 C_1 B_10 
Stack 5
B_11 B_13 D_4 C_14 C_6 
Stack 6
A_6 C_4 B_7 E_6 E_3 
Stack 7
E_12 B_14 E_14 C_16 E_0 
Stack 8
B_0 A_12 C_5 C_3 E_1 
Stack 9
A_1 A_11 B_15 D_10 D_1 
Stack 10
B_1 D_15 E_5 C_8 A_14 
Stack 11
E_9 D_14 D_2 E_11 E_13 
Stack 12
B_5 C_0 D_0 A_5 A_4 
Stack 13
C_13 B_6 B_9 D_8 C_11 
Stack 14
E_2 C_10 A_9 A_3 E_7 
Stack 15
E_10 A_0 D_6 D_13 A_13 
