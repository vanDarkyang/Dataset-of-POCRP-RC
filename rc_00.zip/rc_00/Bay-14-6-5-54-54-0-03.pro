Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_9 D_8 E_1 E_0 
Stack 2
A_8 C_3 A_1 E_7 
Stack 3
D_3 C_1 E_5 B_10 
Stack 4
D_6 A_2 E_4 C_6 
Stack 5
A_0 C_8 A_4 B_5 
Stack 6
C_0 C_2 B_6 D_10 
Stack 7
C_10 A_9 E_2 B_0 
Stack 8
E_8 D_2 E_6 E_9 
Stack 9
A_6 D_4 B_2 A_7 
Stack 10
D_9 D_0 C_5 D_7 
Stack 11
B_8 D_5 C_7 D_1 
Stack 12
B_4 B_3 C_11 C_4 
Stack 13
A_5 B_7 E_3 
Stack 14
C_9 B_1 A_3 
