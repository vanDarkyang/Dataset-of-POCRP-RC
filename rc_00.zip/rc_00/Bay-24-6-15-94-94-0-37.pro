Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_0 M_0 K_4 E_0 
Stack 2
K_3 H_7 K_2 N_2 
Stack 3
H_2 K_1 G_6 B_1 
Stack 4
D_0 H_4 E_1 F_2 
Stack 5
G_3 L_3 F_3 I_3 
Stack 6
D_5 E_5 G_1 L_1 
Stack 7
E_2 M_4 N_3 G_0 
Stack 8
D_1 C_0 L_2 G_5 
Stack 9
J_2 F_0 H_1 G_2 
Stack 10
H_6 A_1 J_3 F_7 
Stack 11
H_9 N_1 I_2 N_0 
Stack 12
B_3 K_0 I_7 M_1 
Stack 13
H_0 I_4 J_1 C_1 
Stack 14
F_4 H_5 J_5 G_7 
Stack 15
E_4 D_2 M_3 I_8 
Stack 16
E_6 A_2 F_6 G_8 
Stack 17
L_0 J_6 C_2 J_7 
Stack 18
E_3 L_5 I_5 G_4 
Stack 19
D_3 K_5 C_4 O_0 
Stack 20
I_1 B_2 D_4 I_0 
Stack 21
C_3 O_2 M_2 K_6 
Stack 22
I_6 J_4 H_3 L_4 
Stack 23
F_5 B_0 O_1 
Stack 24
H_8 A_0 F_1 
