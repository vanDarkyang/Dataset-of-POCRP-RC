Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_1 E_6 O_1 F_3 C_1 G_2 
Stack 2
G_6 D_7 I_2 H_9 L_5 A_3 
Stack 3
E_4 C_2 N_4 G_4 N_5 H_4 
Stack 4
H_11 E_0 F_4 C_0 K_0 I_7 
Stack 5
D_0 J_0 C_3 F_0 D_5 
Stack 6
J_6 I_8 I_6 B_0 I_5 
Stack 7
A_2 A_1 H_7 B_4 N_0 
Stack 8
F_8 D_1 F_7 J_2 I_10 
Stack 9
E_8 K_6 D_3 H_2 F_2 
Stack 10
H_8 M_5 K_2 G_3 B_1 
Stack 11
K_8 M_4 G_8 E_7 A_4 
Stack 12
H_10 I_1 G_0 O_3 M_2 
Stack 13
C_6 L_4 O_2 G_5 N_1 
Stack 14
G_10 F_5 M_0 F_9 D_4 
Stack 15
J_4 F_6 J_3 K_4 J_1 
Stack 16
I_0 D_6 H_6 O_0 H_3 
Stack 17
G_9 L_1 L_2 K_1 B_2 
Stack 18
M_3 M_6 C_5 A_0 B_5 
Stack 19
I_9 I_3 J_7 G_1 E_2 
Stack 20
K_7 L_6 K_5 J_8 N_3 
Stack 21
B_3 G_7 D_2 H_5 E_5 
Stack 22
C_4 J_9 L_0 H_1 I_4 
Stack 23
J_5 N_2 L_3 E_1 O_4 
Stack 24
H_0 E_3 K_3 M_1 L_7 
