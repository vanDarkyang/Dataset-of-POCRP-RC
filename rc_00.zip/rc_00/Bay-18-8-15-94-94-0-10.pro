Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_7 L_5 K_2 C_2 E_4 K_0 
Stack 2
C_3 G_6 K_4 F_6 L_3 B_2 
Stack 3
F_3 I_4 L_0 F_1 C_1 D_0 
Stack 4
E_5 I_1 D_5 L_2 H_2 E_6 
Stack 5
C_0 I_6 H_5 M_1 H_4 
Stack 6
B_3 J_6 K_6 O_2 E_1 
Stack 7
H_7 N_2 K_5 G_5 F_0 
Stack 8
H_9 H_0 J_1 G_8 I_3 
Stack 9
F_2 I_5 H_6 L_4 F_4 
Stack 10
D_4 E_0 E_3 D_1 J_7 
Stack 11
I_8 H_1 K_3 M_4 A_1 
Stack 12
G_0 L_1 M_3 G_3 N_0 
Stack 13
G_2 H_8 G_7 J_4 J_3 
Stack 14
K_1 D_3 A_0 B_0 G_4 
Stack 15
J_0 E_2 M_0 J_2 N_3 
Stack 16
N_1 O_0 O_1 G_1 F_5 
Stack 17
D_2 H_3 J_5 M_2 I_0 
Stack 18
B_1 F_7 C_4 I_2 A_2 
