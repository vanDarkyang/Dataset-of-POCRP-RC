Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 E_2 C_16 E_9 
Stack 2
B_6 E_4 A_1 C_2 
Stack 3
A_4 B_11 A_2 C_8 
Stack 4
C_9 C_0 C_4 B_0 
Stack 5
B_2 A_14 B_15 C_11 
Stack 6
A_9 D_10 A_0 E_14 
Stack 7
D_14 C_10 B_7 A_12 
Stack 8
E_6 D_3 D_11 B_10 
Stack 9
B_3 B_12 A_6 B_8 
Stack 10
D_9 C_5 A_7 C_6 
Stack 11
A_3 E_12 D_12 E_7 
Stack 12
E_8 D_5 D_6 C_13 
Stack 13
D_2 C_7 D_13 B_1 
Stack 14
E_5 D_7 E_0 D_0 
Stack 15
B_14 A_5 E_1 B_5 
Stack 16
E_13 C_12 A_8 A_13 
Stack 17
A_10 C_14 D_1 E_10 
Stack 18
C_1 D_4 E_3 A_11 
Stack 19
C_15 B_9 B_13 D_8 
Stack 20
B_4 D_15 E_11 
