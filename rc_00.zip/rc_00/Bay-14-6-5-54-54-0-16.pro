Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 D_6 D_7 E_1 
Stack 2
D_4 C_8 C_3 B_8 
Stack 3
E_6 A_2 B_3 E_5 
Stack 4
C_11 E_8 B_1 D_3 
Stack 5
C_9 B_2 E_0 C_5 
Stack 6
B_10 D_0 A_9 B_4 
Stack 7
C_7 C_0 D_2 C_1 
Stack 8
A_8 A_6 A_7 B_9 
Stack 9
E_9 B_0 A_3 B_5 
Stack 10
D_8 D_10 C_10 A_4 
Stack 11
E_4 A_5 E_2 A_0 
Stack 12
C_6 D_5 E_7 B_6 
Stack 13
D_1 C_4 E_3 
Stack 14
B_7 D_9 C_2 
