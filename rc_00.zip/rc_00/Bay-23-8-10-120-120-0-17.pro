Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_3 E_13 H_10 G_10 C_9 E_1 
Stack 2
B_8 F_9 C_0 J_7 B_7 I_9 
Stack 3
G_7 I_0 B_4 D_5 H_9 F_12 
Stack 4
D_6 H_4 I_2 E_9 H_3 A_5 
Stack 5
J_1 E_6 D_3 F_1 H_7 J_3 
Stack 6
F_13 H_5 D_1 F_7 I_8 
Stack 7
B_9 H_0 G_2 E_5 H_6 
Stack 8
B_0 D_4 J_6 A_8 D_12 
Stack 9
B_5 D_11 D_9 A_0 F_0 
Stack 10
C_3 A_7 E_4 A_9 D_0 
Stack 11
F_6 C_5 E_11 A_4 B_6 
Stack 12
B_3 G_5 J_5 B_2 C_11 
Stack 13
E_7 E_10 E_12 I_6 G_3 
Stack 14
G_11 E_8 H_2 G_8 D_8 
Stack 15
E_0 C_7 I_4 J_8 C_10 
Stack 16
J_0 C_1 C_8 I_10 C_4 
Stack 17
D_7 D_2 H_1 F_5 F_8 
Stack 18
F_2 G_0 F_3 I_7 C_6 
Stack 19
I_1 I_3 E_2 G_9 J_4 
Stack 20
H_8 H_11 G_4 F_11 J_2 
Stack 21
F_10 F_4 D_10 G_1 A_3 
Stack 22
C_2 B_1 I_5 B_10 G_12 
Stack 23
A_2 G_6 A_6 J_9 A_1 
