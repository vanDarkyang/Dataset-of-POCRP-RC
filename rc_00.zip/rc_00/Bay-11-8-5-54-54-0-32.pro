Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_3 E_4 C_6 C_10 A_2 
Stack 2
B_3 D_10 A_3 C_0 D_5 
Stack 3
C_8 B_6 E_6 E_0 C_9 
Stack 4
C_1 D_1 E_1 C_4 D_8 
Stack 5
B_1 B_9 A_4 D_7 B_8 
Stack 6
B_10 B_0 E_2 A_0 B_4 
Stack 7
E_7 A_1 E_8 D_6 E_9 
Stack 8
D_2 E_5 C_5 E_3 C_2 
Stack 9
B_7 A_9 C_3 A_6 A_7 
Stack 10
D_0 D_9 A_5 C_11 D_4 
Stack 11
C_7 B_2 B_5 A_8 
