Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_4 E_9 D_8 A_3 B_0 
Stack 2
A_7 B_2 B_4 B_3 D_3 
Stack 3
E_7 B_8 B_1 D_10 A_4 
Stack 4
E_2 C_0 A_0 C_3 B_5 
Stack 5
C_1 A_8 D_6 C_2 B_7 
Stack 6
B_9 E_6 A_2 D_4 D_5 
Stack 7
E_0 E_8 D_2 E_1 D_9 
Stack 8
A_9 A_1 C_8 A_5 A_6 
Stack 9
C_4 C_7 E_3 D_1 B_10 
Stack 10
E_5 D_0 C_11 D_7 B_6 
Stack 11
C_9 C_5 C_6 C_10 
