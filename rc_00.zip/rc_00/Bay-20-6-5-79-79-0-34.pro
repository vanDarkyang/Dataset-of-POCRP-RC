Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 D_10 A_10 E_6 
Stack 2
E_8 E_1 E_0 D_11 
Stack 3
C_16 B_1 A_4 B_5 
Stack 4
D_12 B_12 C_15 C_3 
Stack 5
E_9 C_8 A_11 B_3 
Stack 6
D_0 A_6 A_7 E_10 
Stack 7
A_8 C_14 D_14 A_0 
Stack 8
C_12 C_6 B_8 D_3 
Stack 9
B_6 C_0 B_2 E_14 
Stack 10
D_13 D_4 B_13 C_1 
Stack 11
B_4 C_4 B_11 C_11 
Stack 12
B_14 A_3 E_7 E_4 
Stack 13
E_12 A_5 A_14 C_9 
Stack 14
A_13 E_3 A_1 D_2 
Stack 15
D_7 A_9 B_9 B_0 
Stack 16
D_15 E_11 C_10 D_5 
Stack 17
C_13 C_7 C_5 E_5 
Stack 18
B_7 D_9 B_10 D_8 
Stack 19
D_1 E_2 E_13 B_15 
Stack 20
A_2 D_6 A_12 
