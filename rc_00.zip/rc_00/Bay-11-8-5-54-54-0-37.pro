Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_5 E_1 A_8 A_1 D_1 
Stack 2
E_2 D_10 E_9 B_9 B_0 
Stack 3
B_7 B_6 A_3 C_0 B_8 
Stack 4
C_2 A_5 B_10 D_3 A_4 
Stack 5
C_9 A_6 D_7 E_3 A_2 
Stack 6
D_2 B_1 A_9 C_5 E_6 
Stack 7
B_3 D_9 B_5 C_7 C_8 
Stack 8
E_4 E_7 D_4 D_6 C_6 
Stack 9
D_8 C_11 C_10 A_7 B_4 
Stack 10
D_0 D_5 B_2 C_1 C_3 
Stack 11
C_4 E_0 A_0 E_8 
