Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_4 I_3 G_0 H_2 J_0 
Stack 2
E_2 E_5 D_0 F_0 E_1 
Stack 3
G_2 F_1 D_5 B_1 D_2 
Stack 4
G_3 G_1 C_1 G_5 H_0 
Stack 5
E_0 B_2 A_0 C_3 A_1 
Stack 6
F_6 C_4 E_6 J_2 H_3 
Stack 7
I_1 A_2 B_0 F_2 E_3 
Stack 8
I_0 D_1 H_4 F_4 F_3 
Stack 9
F_5 G_4 H_1 D_3 C_0 
Stack 10
D_4 B_3 C_2 I_2 J_1 
