Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_4 C_2 A_8 B_1 
Stack 2
C_12 A_12 B_5 C_7 
Stack 3
B_12 B_2 B_15 C_9 
Stack 4
A_13 B_6 C_14 A_9 
Stack 5
C_5 C_3 A_14 A_2 
Stack 6
A_1 B_4 A_3 A_0 
Stack 7
C_0 C_8 B_8 B_7 
Stack 8
C_4 A_11 B_3 C_11 
Stack 9
A_7 A_10 A_6 B_0 
Stack 10
C_10 B_14 B_10 B_11 
Stack 11
C_1 B_13 C_13 
Stack 12
A_5 C_6 B_9 
