Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_8 D_4 H_4 F_5 C_3 
Stack 2
A_2 G_6 B_4 I_1 E_0 
Stack 3
B_2 G_4 A_3 J_2 I_3 
Stack 4
D_6 I_0 H_2 G_5 J_4 
Stack 5
E_2 D_1 F_6 F_1 B_3 
Stack 6
D_0 D_5 C_2 F_7 C_4 
Stack 7
C_0 D_3 E_4 G_1 I_2 
Stack 8
G_7 H_0 D_2 H_3 C_5 
Stack 9
I_4 G_2 F_2 E_5 E_8 
Stack 10
C_1 F_0 E_1 I_5 G_0 
Stack 11
F_4 E_3 C_6 B_5 B_1 
Stack 12
H_1 J_1 A_1 F_3 J_3 
Stack 13
A_4 A_0 J_0 E_6 B_0 
Stack 14
H_6 G_3 H_5 D_7 E_7 
