Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_1 F_3 F_1 L_4 
Stack 2
E_2 L_3 I_8 O_2 
Stack 3
M_3 J_3 H_0 I_2 
Stack 4
M_4 N_3 G_1 K_3 
Stack 5
J_5 F_6 H_2 D_1 
Stack 6
B_0 J_7 I_4 K_1 
Stack 7
H_3 F_2 I_1 C_3 
Stack 8
L_2 I_6 G_3 D_4 
Stack 9
C_0 L_1 H_4 K_2 
Stack 10
M_1 G_4 K_6 E_4 
Stack 11
I_0 J_6 H_1 E_3 
Stack 12
K_5 B_1 K_0 D_2 
Stack 13
E_5 L_0 F_0 H_5 
Stack 14
A_1 F_4 O_0 J_4 
Stack 15
J_2 C_2 K_4 A_0 
Stack 16
E_6 I_7 D_3 N_0 
Stack 17
B_3 C_1 L_5 N_1 
Stack 18
J_0 H_6 G_2 M_0 
Stack 19
I_5 C_4 D_5 F_7 
Stack 20
G_0 N_2 E_0 G_6 
Stack 21
D_0 I_3 J_1 H_7 
Stack 22
H_9 A_2 B_2 O_1 
Stack 23
G_7 M_2 G_5 
Stack 24
H_8 F_5 G_8 
