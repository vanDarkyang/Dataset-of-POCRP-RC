Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_2 K_3 M_5 L_3 M_1 E_2 
Stack 2
G_8 E_1 L_0 H_10 I_7 F_6 
Stack 3
I_1 I_10 L_4 C_4 I_5 H_1 
Stack 4
C_6 G_2 H_7 M_4 I_6 G_10 
Stack 5
J_1 G_1 M_6 O_1 D_4 
Stack 6
B_0 A_1 D_6 D_3 I_4 
Stack 7
E_0 A_4 I_3 I_9 J_6 
Stack 8
O_0 N_3 H_9 E_5 G_6 
Stack 9
I_8 F_4 H_11 K_8 A_0 
Stack 10
H_4 G_4 B_2 L_5 L_2 
Stack 11
I_2 E_7 L_1 C_5 O_2 
Stack 12
A_2 F_8 M_3 B_5 J_8 
Stack 13
L_7 H_3 D_5 M_2 G_9 
Stack 14
E_4 O_4 N_2 E_8 C_2 
Stack 15
F_1 I_0 B_1 M_0 K_1 
Stack 16
F_5 J_5 D_7 L_6 J_7 
Stack 17
K_6 B_3 H_8 F_3 J_9 
Stack 18
H_2 H_0 N_4 E_3 D_2 
Stack 19
C_0 K_5 J_4 H_6 K_4 
Stack 20
H_5 A_3 G_0 D_0 K_2 
Stack 21
G_7 J_0 N_5 F_7 F_0 
Stack 22
K_0 O_3 N_0 C_3 K_7 
Stack 23
G_5 F_9 G_3 J_2 E_6 
Stack 24
J_3 D_1 B_4 N_1 C_1 
