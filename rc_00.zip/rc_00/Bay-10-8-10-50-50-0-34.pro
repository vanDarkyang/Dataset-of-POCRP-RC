Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_3 E_4 E_5 H_3 E_0 
Stack 2
C_2 I_1 H_4 F_4 G_4 
Stack 3
E_6 E_2 G_1 H_1 F_2 
Stack 4
B_1 G_5 G_3 G_0 D_3 
Stack 5
F_0 I_0 F_5 H_0 J_1 
Stack 6
E_1 C_0 A_2 C_1 D_5 
Stack 7
F_6 A_1 B_0 B_2 G_2 
Stack 8
F_1 H_2 J_2 I_2 J_0 
Stack 9
F_3 D_1 C_4 E_3 D_2 
Stack 10
A_0 B_3 C_3 D_4 D_0 
