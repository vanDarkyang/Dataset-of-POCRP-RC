Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_6 D_7 D_9 B_9 E_7 
Stack 2
E_9 D_3 E_3 D_5 C_1 
Stack 3
A_8 B_7 B_1 E_5 C_10 
Stack 4
E_8 B_2 A_1 D_6 E_4 
Stack 5
A_0 C_11 A_7 C_5 C_0 
Stack 6
A_9 A_2 B_6 D_1 E_1 
Stack 7
B_10 C_7 A_4 B_8 D_2 
Stack 8
D_8 E_2 C_9 B_3 C_8 
Stack 9
C_3 C_2 A_5 D_10 A_6 
Stack 10
B_5 A_3 B_4 C_6 B_0 
Stack 11
C_4 D_0 D_4 E_0 
