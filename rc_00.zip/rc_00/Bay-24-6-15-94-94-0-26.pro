Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_2 L_3 E_1 K_2 
Stack 2
E_2 D_0 N_0 N_1 
Stack 3
J_3 I_4 D_3 I_1 
Stack 4
E_6 I_7 I_6 J_0 
Stack 5
G_3 E_4 C_2 G_2 
Stack 6
F_3 H_5 F_7 D_1 
Stack 7
H_4 H_8 C_1 H_0 
Stack 8
I_5 O_1 M_1 G_0 
Stack 9
H_3 G_1 F_2 F_6 
Stack 10
F_0 B_0 M_3 F_1 
Stack 11
L_0 A_2 E_5 L_4 
Stack 12
L_5 J_5 C_4 J_2 
Stack 13
N_2 E_3 D_4 H_1 
Stack 14
J_1 M_4 K_3 G_5 
Stack 15
K_4 J_4 C_3 M_0 
Stack 16
I_2 K_1 C_0 I_0 
Stack 17
J_7 G_6 O_0 M_2 
Stack 18
E_0 O_2 L_2 F_5 
Stack 19
D_5 I_8 N_3 A_0 
Stack 20
F_4 K_6 B_2 A_1 
Stack 21
K_0 G_4 G_7 H_2 
Stack 22
H_9 H_7 K_5 G_8 
Stack 23
H_6 B_3 L_1 
Stack 24
I_3 J_6 B_1 
