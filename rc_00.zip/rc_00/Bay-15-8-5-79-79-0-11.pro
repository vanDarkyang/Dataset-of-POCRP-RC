Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_11 E_13 B_7 B_2 C_5 B_6 
Stack 2
C_9 C_14 B_4 A_11 E_1 B_5 
Stack 3
B_0 A_6 A_10 D_5 C_4 E_9 
Stack 4
C_16 C_6 A_2 E_3 E_11 B_1 
Stack 5
C_2 A_12 C_1 D_8 E_5 
Stack 6
A_14 E_4 E_14 D_15 A_1 
Stack 7
E_12 A_5 D_1 C_3 A_7 
Stack 8
A_13 C_8 C_12 D_4 E_10 
Stack 9
E_2 B_3 E_7 B_15 C_15 
Stack 10
D_7 C_0 E_0 D_13 D_3 
Stack 11
B_12 C_13 D_10 C_11 B_14 
Stack 12
B_9 B_11 D_6 D_9 B_13 
Stack 13
A_0 D_12 E_8 D_14 E_6 
Stack 14
C_10 C_7 D_0 A_9 A_3 
Stack 15
B_10 B_8 A_4 D_2 A_8 
