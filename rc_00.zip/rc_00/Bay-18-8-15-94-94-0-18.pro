Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
M_0 I_3 J_2 O_2 L_4 B_3 
Stack 2
C_1 H_6 G_8 A_2 K_6 I_2 
Stack 3
H_3 D_2 L_5 E_5 J_7 N_3 
Stack 4
C_0 N_0 K_1 G_0 L_0 E_1 
Stack 5
G_2 C_2 D_1 B_0 M_3 
Stack 6
H_4 H_5 J_5 A_1 F_6 
Stack 7
D_0 M_2 I_4 B_2 D_5 
Stack 8
F_7 D_4 J_0 N_2 L_1 
Stack 9
I_6 J_6 K_5 F_5 E_0 
Stack 10
C_4 I_7 H_9 E_4 G_7 
Stack 11
C_3 J_3 J_1 K_4 I_8 
Stack 12
E_3 K_0 I_0 G_3 F_0 
Stack 13
F_3 I_5 F_1 L_3 H_0 
Stack 14
I_1 O_1 N_1 E_6 F_4 
Stack 15
D_3 H_1 H_8 G_6 A_0 
Stack 16
K_2 E_2 G_4 L_2 H_7 
Stack 17
B_1 G_5 H_2 K_3 O_0 
Stack 18
F_2 M_4 G_1 J_4 M_1 
