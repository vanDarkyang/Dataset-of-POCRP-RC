Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_4 C_3 D_1 A_3 
Stack 2
D_8 B_4 E_6 E_7 
Stack 3
E_8 B_8 D_2 C_6 
Stack 4
A_8 C_10 A_1 C_2 
Stack 5
C_1 A_4 E_3 D_7 
Stack 6
E_0 C_4 B_2 B_5 
Stack 7
D_6 B_6 A_9 C_5 
Stack 8
E_5 D_9 E_2 B_10 
Stack 9
C_11 B_7 D_5 C_7 
Stack 10
E_4 D_10 C_0 E_1 
Stack 11
A_7 A_0 D_0 D_3 
Stack 12
A_6 B_3 B_0 C_8 
Stack 13
A_5 A_2 B_9 
Stack 14
B_1 E_9 C_9 
