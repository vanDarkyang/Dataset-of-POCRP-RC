Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_2 H_2 E_6 I_4 E_3 
Stack 2
F_0 D_1 E_4 I_0 B_0 
Stack 3
D_6 D_4 D_7 B_4 J_3 
Stack 4
C_5 I_1 F_1 E_8 G_5 
Stack 5
A_2 F_8 E_7 H_5 G_4 
Stack 6
I_2 F_6 B_1 B_3 C_2 
Stack 7
B_5 G_2 I_5 C_6 E_5 
Stack 8
J_2 A_1 B_2 E_0 D_2 
Stack 9
C_1 G_6 E_1 F_7 F_4 
Stack 10
G_1 H_1 H_6 H_4 A_3 
Stack 11
C_0 G_0 A_4 J_1 A_0 
Stack 12
C_4 D_5 D_0 H_0 J_4 
Stack 13
G_3 F_3 J_0 H_3 C_3 
Stack 14
F_5 F_2 G_7 D_3 I_3 
