Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_6 E_7 C_4 F_9 J_6 I_6 
Stack 2
J_4 E_4 G_6 D_3 A_0 E_0 
Stack 3
C_0 E_8 G_4 H_7 J_3 D_2 
Stack 4
J_5 H_0 B_8 A_4 F_0 B_5 
Stack 5
A_5 H_3 I_1 E_6 A_7 F_11 
Stack 6
F_12 I_9 J_9 C_1 F_4 
Stack 7
A_2 G_3 I_10 A_9 B_3 
Stack 8
D_8 I_0 G_10 D_6 A_6 
Stack 9
F_1 A_1 F_13 G_5 G_9 
Stack 10
E_3 J_8 E_11 F_7 I_2 
Stack 11
G_12 B_4 G_7 B_0 H_5 
Stack 12
E_10 H_8 G_8 E_5 H_10 
Stack 13
H_6 D_7 A_3 D_5 E_2 
Stack 14
I_3 F_2 D_12 B_2 E_1 
Stack 15
H_1 A_8 C_8 J_0 C_2 
Stack 16
B_10 G_2 D_9 I_4 C_7 
Stack 17
H_11 J_1 B_6 C_6 G_1 
Stack 18
H_9 D_1 I_7 B_9 J_7 
Stack 19
D_10 I_8 G_11 I_5 D_4 
Stack 20
C_9 F_8 B_7 C_5 G_0 
Stack 21
C_11 B_1 F_3 C_3 D_0 
Stack 22
H_4 E_9 E_13 C_10 F_10 
Stack 23
E_12 D_11 J_2 H_2 F_5 
