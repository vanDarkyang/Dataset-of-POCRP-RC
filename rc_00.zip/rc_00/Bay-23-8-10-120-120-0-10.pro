Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_2 H_2 F_1 A_6 E_6 E_8 
Stack 2
D_3 A_2 A_8 F_3 J_5 H_10 
Stack 3
E_3 C_8 G_2 H_9 I_3 H_5 
Stack 4
H_0 C_4 A_3 H_1 H_7 J_7 
Stack 5
J_9 D_7 G_1 F_7 E_13 I_9 
Stack 6
C_1 E_1 I_0 I_10 A_9 
Stack 7
E_9 C_9 D_5 I_8 J_1 
Stack 8
E_4 J_8 C_5 F_11 D_9 
Stack 9
F_4 F_8 A_5 G_8 B_4 
Stack 10
D_6 D_1 I_4 A_4 D_0 
Stack 11
F_13 D_12 B_0 G_11 A_1 
Stack 12
A_0 A_7 F_2 I_5 E_10 
Stack 13
D_11 F_6 F_0 G_3 J_4 
Stack 14
D_2 H_6 G_6 G_10 I_7 
Stack 15
F_9 J_0 H_11 C_11 B_3 
Stack 16
G_7 B_5 F_10 C_3 G_5 
Stack 17
E_12 E_7 G_9 B_6 J_2 
Stack 18
H_4 G_4 B_7 E_2 E_5 
Stack 19
E_11 B_10 C_10 C_6 C_2 
Stack 20
F_5 J_6 D_10 J_3 C_0 
Stack 21
D_8 F_12 E_0 B_2 B_8 
Stack 22
H_8 G_0 B_1 I_6 H_3 
Stack 23
C_7 B_9 G_12 I_1 D_4 
