Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_2 A_0 A_7 C_0 
Stack 2
B_12 A_3 B_8 B_0 
Stack 3
A_12 B_6 B_4 A_5 
Stack 4
B_5 C_13 B_15 A_1 
Stack 5
C_9 A_14 A_8 B_10 
Stack 6
A_9 A_11 B_11 C_5 
Stack 7
C_6 C_11 B_13 C_14 
Stack 8
A_10 A_4 A_6 C_2 
Stack 9
C_10 A_13 B_9 C_8 
Stack 10
C_7 C_4 A_2 B_3 
Stack 11
B_1 C_1 C_12 
Stack 12
C_3 B_7 B_14 
