Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_10 B_8 A_4 A_3 
Stack 2
C_2 B_9 A_11 C_14 
Stack 3
C_5 C_3 C_7 C_8 
Stack 4
A_8 C_10 C_12 B_6 
Stack 5
A_7 A_5 B_12 A_2 
Stack 6
C_11 C_6 B_10 C_13 
Stack 7
B_0 B_3 B_5 A_0 
Stack 8
B_1 B_14 C_1 A_14 
Stack 9
C_0 B_15 A_12 B_13 
Stack 10
B_11 C_4 B_4 A_1 
Stack 11
A_9 B_7 B_2 
Stack 12
A_13 A_6 C_9 
