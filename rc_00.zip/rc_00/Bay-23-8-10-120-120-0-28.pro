Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_3 B_0 I_9 A_8 E_8 F_1 
Stack 2
H_4 E_12 J_9 G_11 F_10 C_0 
Stack 3
A_7 B_6 J_3 E_0 C_9 C_7 
Stack 4
E_2 C_2 D_5 I_5 G_3 D_4 
Stack 5
I_10 H_7 I_6 I_8 J_1 A_3 
Stack 6
C_8 G_9 F_13 B_9 C_5 
Stack 7
J_4 E_7 G_8 C_11 A_0 
Stack 8
I_3 D_8 B_2 A_2 B_7 
Stack 9
F_9 D_1 E_13 J_8 I_4 
Stack 10
B_10 F_8 B_8 E_9 H_0 
Stack 11
I_2 A_1 D_9 E_6 E_3 
Stack 12
G_10 D_3 A_5 I_0 F_5 
Stack 13
J_6 G_4 C_6 D_0 G_1 
Stack 14
F_0 C_1 H_2 H_11 G_5 
Stack 15
J_5 H_5 I_1 J_7 F_7 
Stack 16
D_6 G_7 F_6 I_7 A_6 
Stack 17
E_5 G_6 E_1 H_1 G_0 
Stack 18
D_10 E_11 F_11 D_12 E_10 
Stack 19
H_6 H_10 H_9 B_4 C_10 
Stack 20
C_3 F_2 A_4 A_9 H_3 
Stack 21
C_4 G_2 J_2 G_12 B_5 
Stack 22
B_1 D_11 H_8 F_3 D_2 
Stack 23
D_7 F_12 J_0 E_4 F_4 
