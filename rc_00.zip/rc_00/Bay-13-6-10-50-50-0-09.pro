Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 I_2 C_2 D_0 
Stack 2
G_0 H_3 F_4 I_3 
Stack 3
E_0 H_1 C_4 E_2 
Stack 4
B_0 F_1 B_2 B_1 
Stack 5
B_3 E_1 D_3 C_1 
Stack 6
E_4 J_1 H_2 I_0 
Stack 7
C_0 H_0 E_3 A_2 
Stack 8
E_5 G_3 F_5 F_3 
Stack 9
G_2 F_2 C_3 E_6 
Stack 10
A_0 J_0 D_4 G_1 
Stack 11
F_0 J_2 H_4 D_5 
Stack 12
D_1 D_2 G_4 
Stack 13
I_1 F_6 G_5 
