Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_4 B_3 A_2 E_0 B_1 
Stack 2
H_1 B_4 E_7 E_6 C_3 
Stack 3
A_3 E_2 D_1 I_5 G_4 
Stack 4
C_6 D_3 B_2 E_3 I_2 
Stack 5
H_2 J_0 B_0 H_0 F_0 
Stack 6
E_8 I_4 A_0 F_4 A_1 
Stack 7
F_8 G_7 G_1 I_1 F_5 
Stack 8
J_2 J_3 H_5 D_5 C_5 
Stack 9
C_4 E_1 D_6 F_3 D_7 
Stack 10
H_4 F_7 I_0 G_6 G_0 
Stack 11
D_0 G_3 C_2 F_2 G_2 
Stack 12
F_6 D_2 G_5 H_3 C_1 
Stack 13
D_4 E_5 H_6 J_4 F_1 
Stack 14
J_1 E_4 C_0 I_3 B_5 
