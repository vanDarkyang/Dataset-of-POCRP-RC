Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_4 C_0 A_0 B_1 
Stack 2
E_0 F_0 E_2 F_3 
Stack 3
A_2 A_1 I_1 I_3 
Stack 4
C_2 C_4 E_1 E_5 
Stack 5
G_2 F_6 G_3 F_2 
Stack 6
F_4 H_1 D_5 J_1 
Stack 7
D_1 H_0 B_3 E_6 
Stack 8
C_3 I_0 H_2 B_2 
Stack 9
D_0 H_4 E_4 D_2 
Stack 10
G_1 C_1 G_5 G_0 
Stack 11
F_5 I_2 B_0 J_2 
Stack 12
D_4 D_3 J_0 
Stack 13
H_3 F_1 E_3 
