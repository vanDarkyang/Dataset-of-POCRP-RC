Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_2 B_3 F_0 G_7 B_5 
Stack 2
D_7 C_2 E_0 A_1 D_0 
Stack 3
A_0 C_0 B_0 I_3 B_4 
Stack 4
B_1 F_1 G_0 F_8 H_3 
Stack 5
F_7 G_6 F_2 E_6 A_4 
Stack 6
I_1 D_6 C_1 I_4 E_2 
Stack 7
E_8 C_5 I_5 A_2 G_5 
Stack 8
G_4 I_0 F_3 G_3 E_7 
Stack 9
F_5 A_3 E_3 J_1 J_3 
Stack 10
D_4 D_1 F_4 H_0 J_4 
Stack 11
I_2 C_3 J_0 E_4 B_2 
Stack 12
C_6 H_1 C_4 H_5 E_5 
Stack 13
E_1 D_5 G_2 G_1 F_6 
Stack 14
J_2 H_2 H_4 D_3 H_6 
