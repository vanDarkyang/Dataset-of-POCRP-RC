Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_8 B_9 E_9 B_0 
Stack 2
E_8 D_0 B_2 B_3 
Stack 3
D_5 C_0 C_9 B_4 
Stack 4
D_9 A_8 D_4 E_6 
Stack 5
D_10 A_7 C_1 D_8 
Stack 6
B_6 E_1 A_4 B_5 
Stack 7
C_10 E_4 A_3 D_1 
Stack 8
D_7 B_10 B_1 C_7 
Stack 9
A_5 C_5 B_8 E_3 
Stack 10
A_2 C_6 E_2 D_3 
Stack 11
C_2 C_3 E_0 E_5 
Stack 12
C_11 C_4 A_9 A_6 
Stack 13
A_0 B_7 E_7 
Stack 14
A_1 D_6 D_2 
