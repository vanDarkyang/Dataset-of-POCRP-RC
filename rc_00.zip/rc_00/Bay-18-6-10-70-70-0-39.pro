Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_8 D_1 F_2 E_6 
Stack 2
A_2 D_5 E_1 D_7 
Stack 3
B_2 D_3 C_6 C_3 
Stack 4
D_6 H_0 A_1 E_0 
Stack 5
E_2 G_2 J_0 I_3 
Stack 6
D_0 F_0 H_5 J_4 
Stack 7
C_0 E_3 F_5 B_3 
Stack 8
G_7 J_1 I_1 C_4 
Stack 9
I_4 A_0 J_2 I_2 
Stack 10
C_1 G_3 G_5 C_5 
Stack 11
F_4 H_4 F_1 E_8 
Stack 12
H_1 B_4 F_7 G_0 
Stack 13
A_4 A_3 G_1 B_1 
Stack 14
H_6 H_2 H_3 J_3 
Stack 15
D_4 F_6 E_5 B_0 
Stack 16
G_6 C_2 I_5 E_7 
Stack 17
G_4 E_4 B_5 
Stack 18
I_0 D_2 F_3 
