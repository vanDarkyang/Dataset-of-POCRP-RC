Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_8 A_10 D_7 D_5 
Stack 2
E_9 E_8 D_15 B_13 
Stack 3
B_0 E_11 B_14 E_12 
Stack 4
E_3 D_3 A_7 A_9 
Stack 5
C_3 D_11 D_10 E_14 
Stack 6
A_3 C_12 C_13 B_2 
Stack 7
B_15 B_12 B_4 C_7 
Stack 8
A_4 A_11 A_0 B_10 
Stack 9
C_0 A_2 D_12 E_5 
Stack 10
C_5 C_4 B_3 C_6 
Stack 11
A_12 B_7 D_0 E_13 
Stack 12
E_6 D_9 C_16 E_1 
Stack 13
D_4 B_5 D_2 C_8 
Stack 14
C_10 A_1 E_7 E_2 
Stack 15
D_1 A_14 D_14 B_9 
Stack 16
D_8 E_0 B_11 C_15 
Stack 17
A_6 C_14 B_1 C_9 
Stack 18
D_6 E_4 A_13 D_13 
Stack 19
C_11 C_1 C_2 B_8 
Stack 20
B_6 A_5 E_10 
