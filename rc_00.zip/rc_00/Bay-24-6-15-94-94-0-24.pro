Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_0 G_2 K_0 C_3 
Stack 2
G_1 B_1 K_3 H_9 
Stack 3
J_5 L_1 L_2 F_5 
Stack 4
N_1 K_5 F_2 D_3 
Stack 5
F_1 B_2 G_3 M_2 
Stack 6
H_0 I_4 I_3 O_2 
Stack 7
K_6 H_4 A_1 H_6 
Stack 8
H_3 D_2 C_2 E_6 
Stack 9
B_0 J_6 C_1 M_1 
Stack 10
G_4 G_7 D_5 K_2 
Stack 11
D_0 I_6 N_2 F_3 
Stack 12
H_1 G_8 E_4 I_1 
Stack 13
E_5 J_4 F_7 L_5 
Stack 14
K_4 H_2 G_5 C_4 
Stack 15
E_1 K_1 D_4 E_0 
Stack 16
B_3 I_5 J_0 M_0 
Stack 17
E_3 I_2 L_4 I_7 
Stack 18
E_2 H_8 A_0 L_3 
Stack 19
F_6 F_0 N_3 G_6 
Stack 20
M_4 O_1 J_1 A_2 
Stack 21
J_2 H_5 L_0 C_0 
Stack 22
I_8 D_1 N_0 F_4 
Stack 23
J_3 G_0 J_7 
Stack 24
O_0 H_7 M_3 
