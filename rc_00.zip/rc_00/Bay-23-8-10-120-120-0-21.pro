Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_0 H_7 E_12 F_0 D_1 B_2 
Stack 2
D_11 J_8 C_6 I_9 J_6 E_13 
Stack 3
E_2 C_10 F_5 H_4 I_4 D_5 
Stack 4
I_0 I_5 J_3 F_12 D_0 G_12 
Stack 5
B_8 G_9 I_2 H_6 F_4 I_3 
Stack 6
D_12 E_9 G_11 A_9 H_5 
Stack 7
H_2 J_2 A_2 C_9 D_10 
Stack 8
F_13 B_5 D_2 G_1 I_7 
Stack 9
G_10 C_8 G_2 F_2 I_10 
Stack 10
C_2 G_5 E_1 H_8 C_5 
Stack 11
D_8 J_7 H_9 F_8 J_4 
Stack 12
F_9 F_3 F_6 E_4 B_9 
Stack 13
E_5 E_10 B_6 B_3 C_11 
Stack 14
I_6 H_11 G_6 I_1 A_3 
Stack 15
F_1 D_6 A_5 G_8 A_0 
Stack 16
F_7 A_1 E_0 E_8 E_11 
Stack 17
B_1 E_7 C_3 J_5 H_0 
Stack 18
D_3 C_4 A_8 D_4 D_9 
Stack 19
B_0 G_0 G_3 I_8 B_7 
Stack 20
H_1 A_7 F_11 H_3 A_4 
Stack 21
C_1 J_1 E_6 G_7 F_10 
Stack 22
C_7 B_10 H_10 A_6 G_4 
Stack 23
E_3 B_4 J_0 J_9 D_7 
