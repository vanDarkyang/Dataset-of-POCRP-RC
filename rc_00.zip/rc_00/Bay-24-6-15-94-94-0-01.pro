Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 H_9 H_1 G_1 
Stack 2
K_3 L_2 E_5 L_0 
Stack 3
H_6 D_5 K_4 D_0 
Stack 4
H_8 D_3 J_1 J_4 
Stack 5
F_2 I_2 F_4 F_5 
Stack 6
H_7 E_1 A_1 C_2 
Stack 7
E_2 O_2 A_0 M_3 
Stack 8
M_4 K_0 I_4 H_0 
Stack 9
N_0 C_4 D_4 J_5 
Stack 10
L_1 K_2 B_2 F_1 
Stack 11
F_6 G_6 F_7 N_2 
Stack 12
B_1 O_0 K_1 N_1 
Stack 13
G_8 A_2 K_6 G_3 
Stack 14
O_1 J_0 G_4 F_0 
Stack 15
G_5 M_0 H_3 D_2 
Stack 16
J_3 H_5 E_0 B_0 
Stack 17
B_3 C_3 E_4 N_3 
Stack 18
M_1 K_5 I_3 G_7 
Stack 19
E_6 G_2 J_6 H_2 
Stack 20
F_3 L_5 L_4 I_0 
Stack 21
J_2 I_6 I_7 E_3 
Stack 22
I_1 G_0 C_0 M_2 
Stack 23
H_4 C_1 L_3 
Stack 24
I_5 J_7 I_8 
