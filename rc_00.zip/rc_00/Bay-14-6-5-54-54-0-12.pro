Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_10 B_4 A_5 D_6 
Stack 2
B_3 E_6 D_5 A_6 
Stack 3
E_7 A_0 A_2 E_4 
Stack 4
C_11 C_3 C_6 B_10 
Stack 5
D_3 E_3 E_9 D_2 
Stack 6
A_8 C_9 E_0 E_5 
Stack 7
D_1 E_8 B_2 A_7 
Stack 8
E_1 D_0 B_5 D_4 
Stack 9
A_9 D_10 C_2 B_9 
Stack 10
B_7 C_7 C_8 C_4 
Stack 11
A_1 C_5 D_7 A_4 
Stack 12
B_0 C_1 A_3 E_2 
Stack 13
D_8 C_0 B_1 
Stack 14
B_6 D_9 B_8 
