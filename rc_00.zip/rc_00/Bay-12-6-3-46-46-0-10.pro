Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_6 A_14 A_6 B_9 
Stack 2
B_8 A_8 B_1 B_0 
Stack 3
A_5 A_2 C_8 C_7 
Stack 4
A_0 B_3 C_14 B_13 
Stack 5
A_12 C_3 B_10 C_6 
Stack 6
B_4 B_15 A_7 C_9 
Stack 7
C_13 C_5 C_11 A_4 
Stack 8
A_1 B_7 B_5 C_1 
Stack 9
C_12 B_12 B_14 B_2 
Stack 10
A_3 A_11 B_11 C_2 
Stack 11
A_10 C_0 C_10 
Stack 12
A_13 C_4 A_9 
