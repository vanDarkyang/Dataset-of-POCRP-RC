Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 E_3 I_0 E_5 I_3 
Stack 2
D_5 F_2 F_4 A_0 G_2 
Stack 3
H_3 G_5 B_2 C_2 F_0 
Stack 4
E_6 E_4 B_3 G_1 H_4 
Stack 5
A_1 E_1 D_2 H_1 D_0 
Stack 6
E_2 D_3 F_6 H_0 G_3 
Stack 7
E_0 J_0 F_5 B_0 G_0 
Stack 8
D_1 J_1 G_4 J_2 C_4 
Stack 9
H_2 C_1 I_2 F_3 B_1 
Stack 10
C_0 A_2 F_1 I_1 D_4 
