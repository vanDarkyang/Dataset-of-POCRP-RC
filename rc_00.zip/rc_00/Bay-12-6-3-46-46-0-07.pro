Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_10 C_9 B_9 A_0 
Stack 2
B_4 A_5 B_2 C_0 
Stack 3
C_13 B_5 C_7 B_8 
Stack 4
A_1 A_2 B_11 C_11 
Stack 5
A_9 B_3 A_8 C_2 
Stack 6
A_3 B_6 A_12 B_10 
Stack 7
C_4 A_14 B_0 C_12 
Stack 8
C_6 B_13 B_12 C_3 
Stack 9
C_1 C_8 C_14 A_7 
Stack 10
B_7 B_15 B_14 C_5 
Stack 11
C_10 A_6 A_13 
Stack 12
A_11 B_1 A_4 
