Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_8 D_0 C_3 C_0 D_5 G_2 
Stack 2
E_9 C_9 I_10 I_4 B_6 H_4 
Stack 3
B_1 F_11 E_8 H_7 D_9 D_2 
Stack 4
A_6 F_7 E_10 I_6 I_7 B_5 
Stack 5
I_9 F_8 H_0 D_10 F_10 E_5 
Stack 6
C_5 I_5 J_6 B_0 I_2 
Stack 7
D_6 C_6 F_13 H_2 G_6 
Stack 8
C_7 D_3 B_8 E_11 E_2 
Stack 9
H_10 E_4 J_2 I_0 J_5 
Stack 10
I_1 F_0 J_8 G_8 E_1 
Stack 11
F_1 B_7 A_3 G_9 C_1 
Stack 12
C_11 B_10 F_6 A_8 E_13 
Stack 13
H_9 F_3 J_1 H_11 A_7 
Stack 14
G_3 D_1 I_8 C_10 H_8 
Stack 15
H_1 G_5 B_9 D_12 F_4 
Stack 16
E_0 A_0 G_1 A_1 D_11 
Stack 17
F_2 H_6 H_3 C_2 A_2 
Stack 18
F_9 G_0 B_4 F_5 G_12 
Stack 19
G_7 H_5 J_7 J_0 I_3 
Stack 20
C_4 J_4 J_3 E_7 D_8 
Stack 21
E_3 G_4 E_12 J_9 A_4 
Stack 22
F_12 B_2 E_6 G_11 D_7 
Stack 23
G_10 A_5 A_9 B_3 D_4 
