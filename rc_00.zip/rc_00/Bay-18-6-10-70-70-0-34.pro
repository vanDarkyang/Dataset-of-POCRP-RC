Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_1 F_7 D_2 J_4 
Stack 2
E_0 F_8 B_4 H_2 
Stack 3
D_4 E_6 I_2 A_4 
Stack 4
G_2 C_4 E_7 B_5 
Stack 5
A_0 I_0 H_6 G_4 
Stack 6
F_4 J_0 I_1 D_5 
Stack 7
C_0 E_8 G_7 C_2 
Stack 8
C_6 C_5 C_3 D_7 
Stack 9
D_0 I_3 E_2 E_1 
Stack 10
G_5 E_3 G_1 J_3 
Stack 11
F_6 F_5 H_4 H_0 
Stack 12
E_4 B_2 B_3 F_0 
Stack 13
A_3 A_2 H_3 I_4 
Stack 14
J_2 G_0 C_1 I_5 
Stack 15
F_2 F_1 D_6 B_0 
Stack 16
G_3 D_3 F_3 H_5 
Stack 17
E_5 G_6 H_1 
Stack 18
A_1 B_1 D_1 
