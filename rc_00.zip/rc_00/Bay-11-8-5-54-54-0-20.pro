Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_7 D_6 B_3 D_10 D_2 
Stack 2
A_1 D_1 B_2 C_6 C_4 
Stack 3
A_3 B_1 E_2 A_2 C_2 
Stack 4
E_5 E_3 E_9 A_5 D_9 
Stack 5
B_6 A_8 A_7 A_4 D_4 
Stack 6
C_11 B_10 B_5 A_6 D_5 
Stack 7
B_7 D_8 C_5 D_3 C_7 
Stack 8
E_6 C_10 E_0 E_1 A_0 
Stack 9
B_8 B_9 D_7 C_0 B_0 
Stack 10
C_8 C_3 D_0 B_4 E_4 
Stack 11
C_9 A_9 E_8 C_1 
