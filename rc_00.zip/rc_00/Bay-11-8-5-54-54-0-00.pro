Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_8 D_10 A_2 C_0 A_8 
Stack 2
B_0 D_0 C_9 E_0 E_6 
Stack 3
B_5 A_3 A_6 E_9 A_1 
Stack 4
A_5 E_3 A_7 B_1 C_6 
Stack 5
E_5 C_10 D_7 B_4 B_3 
Stack 6
C_11 B_10 D_5 E_7 D_8 
Stack 7
D_9 C_1 E_8 B_7 C_3 
Stack 8
C_7 A_0 D_1 C_5 E_4 
Stack 9
C_2 B_6 E_1 C_8 D_4 
Stack 10
A_4 A_9 D_3 D_6 B_2 
Stack 11
D_2 C_4 E_2 B_9 
