Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_10 D_1 B_9 C_8 D_11 C_15 
Stack 2
C_16 A_13 E_4 C_5 B_6 B_13 
Stack 3
B_0 A_1 B_14 B_5 C_3 E_3 
Stack 4
A_0 C_7 A_9 A_10 D_12 A_6 
Stack 5
E_5 E_2 B_2 C_4 E_7 
Stack 6
B_10 C_1 D_5 B_8 B_11 
Stack 7
D_6 A_11 D_13 D_3 A_4 
Stack 8
B_15 A_8 E_8 C_13 E_10 
Stack 9
D_8 B_4 A_5 D_7 E_11 
Stack 10
B_12 C_14 E_13 C_9 E_14 
Stack 11
B_1 C_6 D_10 A_7 A_12 
Stack 12
A_14 D_15 C_2 D_14 A_3 
Stack 13
E_1 D_2 C_0 D_4 E_0 
Stack 14
A_2 E_6 E_9 C_11 E_12 
Stack 15
B_3 D_0 D_9 B_7 C_12 
