Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_4 I_2 H_4 F_7 
Stack 2
D_1 E_7 G_4 D_2 
Stack 3
C_2 J_1 B_3 J_3 
Stack 4
E_2 B_4 F_5 A_4 
Stack 5
J_0 G_7 B_0 E_8 
Stack 6
I_0 G_5 E_6 E_5 
Stack 7
F_0 F_2 A_3 G_2 
Stack 8
F_4 I_3 G_6 H_1 
Stack 9
F_8 D_6 A_0 B_5 
Stack 10
B_1 C_3 G_0 H_2 
Stack 11
F_3 B_2 H_0 E_0 
Stack 12
A_1 H_6 C_6 G_3 
Stack 13
I_4 C_0 D_0 C_1 
Stack 14
C_5 D_7 J_2 I_1 
Stack 15
F_6 G_1 H_3 E_3 
Stack 16
E_1 E_4 H_5 D_3 
Stack 17
D_5 I_5 F_1 
Stack 18
D_4 J_4 A_2 
