Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_8 C_1 E_7 A_6 E_2 
Stack 2
D_10 D_3 B_9 E_3 B_10 
Stack 3
C_5 C_9 A_1 B_7 B_4 
Stack 4
A_9 C_0 A_4 A_2 E_4 
Stack 5
C_6 B_0 A_3 E_9 E_5 
Stack 6
C_8 B_3 B_6 E_8 B_8 
Stack 7
E_1 C_11 D_2 D_4 D_6 
Stack 8
D_1 B_2 D_0 A_0 C_10 
Stack 9
D_5 E_6 B_5 E_0 C_4 
Stack 10
A_5 C_3 D_9 C_7 D_8 
Stack 11
A_7 C_2 D_7 B_1 
