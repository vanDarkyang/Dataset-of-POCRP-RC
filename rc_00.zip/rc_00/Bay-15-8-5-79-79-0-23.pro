Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_13 E_13 D_4 B_15 B_3 B_12 
Stack 2
E_1 D_9 A_12 C_10 D_12 B_0 
Stack 3
A_10 B_6 A_9 D_6 D_3 D_13 
Stack 4
C_14 B_9 A_1 C_1 E_8 B_5 
Stack 5
A_14 E_11 D_11 A_11 C_13 
Stack 6
E_7 C_16 A_6 C_6 A_5 
Stack 7
B_11 C_9 C_7 C_4 D_14 
Stack 8
D_8 E_3 D_7 D_10 E_4 
Stack 9
B_2 C_3 A_2 D_15 A_3 
Stack 10
E_10 E_5 C_15 C_5 D_1 
Stack 11
A_7 C_0 A_0 B_7 B_14 
Stack 12
C_11 C_2 A_8 D_5 B_10 
Stack 13
A_4 D_0 E_14 E_0 B_4 
Stack 14
E_6 E_2 E_12 E_9 C_8 
Stack 15
B_1 C_12 B_8 A_13 D_2 
