Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_0 H_2 D_0 F_0 
Stack 2
H_3 F_4 I_3 F_3 
Stack 3
B_1 E_1 I_2 D_3 
Stack 4
F_1 E_4 J_2 A_2 
Stack 5
B_2 D_2 F_2 J_0 
Stack 6
H_4 D_4 F_6 G_5 
Stack 7
E_2 C_4 F_5 A_1 
Stack 8
C_0 D_1 H_0 D_5 
Stack 9
B_3 E_3 G_3 E_0 
Stack 10
G_2 H_1 G_4 C_2 
Stack 11
C_1 G_0 G_1 E_5 
Stack 12
I_0 I_1 E_6 
Stack 13
B_0 J_1 C_3 
