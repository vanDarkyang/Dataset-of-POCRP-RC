Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_3 D_2 C_5 D_1 F_6 
Stack 2
E_4 F_1 D_0 I_5 A_3 
Stack 3
I_3 B_4 G_4 G_0 I_1 
Stack 4
G_7 D_3 F_0 J_2 J_1 
Stack 5
A_1 D_5 D_4 D_7 G_6 
Stack 6
B_2 I_0 C_0 D_6 G_3 
Stack 7
H_3 H_5 C_2 I_4 F_5 
Stack 8
B_0 E_2 H_1 H_2 F_8 
Stack 9
A_0 B_3 E_6 H_6 E_1 
Stack 10
F_4 E_0 B_5 A_4 C_6 
Stack 11
F_3 H_0 J_4 C_1 B_1 
Stack 12
E_7 G_5 A_2 E_8 E_3 
Stack 13
C_3 F_7 G_2 F_2 E_5 
Stack 14
H_4 C_4 I_2 J_0 G_1 
