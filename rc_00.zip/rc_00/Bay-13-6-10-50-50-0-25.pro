Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 F_6 E_5 C_1 
Stack 2
I_0 C_4 G_3 D_0 
Stack 3
G_0 F_5 B_2 E_3 
Stack 4
B_3 E_4 H_1 C_0 
Stack 5
C_2 F_3 G_2 F_4 
Stack 6
J_1 J_2 F_0 D_2 
Stack 7
I_1 G_1 H_4 G_4 
Stack 8
D_1 E_0 H_3 E_1 
Stack 9
I_3 G_5 H_2 B_1 
Stack 10
E_6 D_3 A_0 B_0 
Stack 11
I_2 A_1 F_2 J_0 
Stack 12
D_4 E_2 D_5 
Stack 13
H_0 A_2 F_1 
