Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
O_1 B_3 A_4 A_1 J_3 F_1 
Stack 2
I_6 M_3 O_4 D_7 E_6 L_2 
Stack 3
J_9 H_9 O_2 E_0 J_2 I_8 
Stack 4
H_4 C_6 J_6 J_4 I_7 M_2 
Stack 5
D_3 F_8 F_7 A_2 M_5 
Stack 6
G_2 H_5 J_5 H_7 M_6 
Stack 7
E_4 F_6 G_1 H_10 G_0 
Stack 8
E_3 K_6 K_4 L_1 O_0 
Stack 9
G_7 E_2 M_0 B_1 E_8 
Stack 10
O_3 G_4 E_1 F_9 D_5 
Stack 11
H_1 K_1 E_7 L_3 B_2 
Stack 12
F_5 H_0 C_3 J_8 I_3 
Stack 13
G_5 I_10 H_2 D_0 A_0 
Stack 14
B_0 H_3 N_3 C_4 F_4 
Stack 15
J_0 I_4 G_9 F_0 C_2 
Stack 16
C_0 N_2 D_4 E_5 L_5 
Stack 17
C_1 G_8 I_2 M_4 H_6 
Stack 18
I_1 F_3 J_7 D_6 D_2 
Stack 19
D_1 I_9 B_4 M_1 N_4 
Stack 20
L_7 J_1 C_5 L_6 F_2 
Stack 21
N_0 K_7 H_8 G_6 K_0 
Stack 22
I_0 L_4 I_5 K_5 B_5 
Stack 23
K_3 A_3 L_0 K_8 K_2 
Stack 24
N_5 N_1 G_10 H_11 G_3 
