Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_1 B_2 E_2 C_2 
Stack 2
F_4 C_0 J_2 G_6 
Stack 3
B_0 H_6 F_0 H_0 
Stack 4
B_1 F_8 D_4 H_2 
Stack 5
E_6 I_4 E_5 B_3 
Stack 6
E_1 G_1 B_5 G_3 
Stack 7
G_7 E_4 E_7 C_3 
Stack 8
I_0 F_2 A_2 G_0 
Stack 9
G_2 A_3 A_4 D_6 
Stack 10
J_3 H_3 E_0 F_1 
Stack 11
C_5 I_5 G_4 C_4 
Stack 12
F_6 C_1 I_3 F_7 
Stack 13
F_5 B_4 J_1 E_8 
Stack 14
J_4 J_0 H_4 G_5 
Stack 15
A_1 D_3 I_2 E_3 
Stack 16
D_2 D_7 A_0 D_1 
Stack 17
H_5 D_5 F_3 
Stack 18
H_1 D_0 C_6 
