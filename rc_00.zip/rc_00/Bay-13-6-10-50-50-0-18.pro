Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_1 A_0 I_1 F_3 
Stack 2
E_3 D_2 I_0 F_2 
Stack 3
D_1 F_5 F_1 H_0 
Stack 4
J_0 J_2 C_2 D_3 
Stack 5
D_5 A_2 I_2 C_4 
Stack 6
G_5 B_2 E_1 E_6 
Stack 7
F_6 I_3 D_4 H_4 
Stack 8
B_0 D_0 G_2 C_1 
Stack 9
G_3 F_4 B_1 E_5 
Stack 10
B_3 F_0 H_2 E_0 
Stack 11
C_3 G_0 E_4 E_2 
Stack 12
H_3 C_0 A_1 
Stack 13
H_1 G_1 G_4 
