Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 D_15 C_4 A_7 E_6 D_5 
Stack 2
E_8 C_13 A_3 D_14 D_11 E_5 
Stack 3
C_16 B_7 A_5 B_8 B_5 D_8 
Stack 4
D_12 D_1 E_3 B_2 C_3 B_15 
Stack 5
E_9 A_2 A_9 B_13 B_3 
Stack 6
D_0 D_10 E_11 B_11 E_10 
Stack 7
A_8 E_1 C_7 E_7 A_0 
Stack 8
C_12 B_1 D_9 A_14 D_3 
Stack 9
B_6 B_12 E_2 A_1 E_14 
Stack 10
D_13 C_8 D_6 B_9 C_1 
Stack 11
B_4 A_6 A_10 C_10 C_11 
Stack 12
B_14 C_14 E_0 C_5 E_4 
Stack 13
E_12 C_6 A_4 B_10 C_9 
Stack 14
A_13 C_0 C_15 E_13 D_2 
Stack 15
D_7 D_4 A_11 A_12 B_0 
