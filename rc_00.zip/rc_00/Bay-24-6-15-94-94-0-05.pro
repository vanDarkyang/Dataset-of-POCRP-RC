Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_7 M_3 I_0 B_1 
Stack 2
K_2 G_6 J_0 J_6 
Stack 3
I_7 E_5 I_1 B_3 
Stack 4
O_1 H_4 K_0 F_0 
Stack 5
H_8 D_5 F_5 K_5 
Stack 6
A_2 I_8 M_2 K_3 
Stack 7
D_4 G_5 F_3 H_6 
Stack 8
N_2 E_6 C_3 G_2 
Stack 9
G_8 D_0 A_1 J_4 
Stack 10
H_7 G_7 B_0 H_2 
Stack 11
F_6 G_3 L_5 L_1 
Stack 12
C_2 M_4 N_1 D_1 
Stack 13
I_6 C_1 K_6 L_0 
Stack 14
F_1 H_0 M_1 E_0 
Stack 15
E_1 H_9 H_1 A_0 
Stack 16
I_3 I_2 F_4 J_1 
Stack 17
E_2 I_5 L_3 L_2 
Stack 18
E_3 M_0 F_2 D_2 
Stack 19
J_2 H_5 K_1 N_0 
Stack 20
O_2 G_4 J_7 G_0 
Stack 21
D_3 N_3 B_2 C_0 
Stack 22
J_3 L_4 I_4 E_4 
Stack 23
C_4 K_4 H_3 
Stack 24
O_0 J_5 G_1 
