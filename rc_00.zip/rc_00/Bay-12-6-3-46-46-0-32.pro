Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_11 B_4 C_14 B_15 
Stack 2
A_5 B_7 C_7 A_8 
Stack 3
A_13 B_14 A_7 A_6 
Stack 4
B_5 C_3 C_13 C_1 
Stack 5
C_2 B_6 B_9 A_1 
Stack 6
C_4 B_12 A_2 B_10 
Stack 7
B_0 C_9 B_13 A_14 
Stack 8
A_4 A_0 C_8 B_2 
Stack 9
C_6 C_5 A_10 A_3 
Stack 10
B_3 C_10 B_8 C_11 
Stack 11
B_1 C_12 C_0 
Stack 12
A_11 A_9 A_12 
