Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_9 H_10 J_1 J_9 D_11 I_8 
Stack 2
A_6 D_12 H_11 J_0 D_1 A_8 
Stack 3
C_8 C_0 F_11 F_2 I_9 B_6 
Stack 4
A_5 G_0 A_3 D_8 E_0 J_7 
Stack 5
E_3 E_1 E_6 D_7 H_5 B_8 
Stack 6
F_10 F_12 A_2 E_5 G_8 
Stack 7
G_9 H_3 F_8 E_11 D_10 
Stack 8
E_12 B_5 F_1 F_7 D_2 
Stack 9
J_5 H_1 C_10 C_7 I_6 
Stack 10
H_9 F_3 F_9 J_3 B_1 
Stack 11
D_9 C_5 I_5 A_0 B_2 
Stack 12
B_4 C_4 A_1 F_5 E_9 
Stack 13
B_10 F_0 G_12 B_9 J_2 
Stack 14
D_3 G_4 F_4 G_10 D_0 
Stack 15
F_6 G_3 A_7 C_9 C_2 
Stack 16
D_6 B_0 C_3 C_11 J_8 
Stack 17
G_2 G_11 I_7 H_7 J_6 
Stack 18
E_13 G_1 G_7 D_4 E_7 
Stack 19
I_10 I_0 H_8 E_8 F_13 
Stack 20
D_5 E_2 E_4 I_4 H_6 
Stack 21
H_4 B_3 B_7 I_3 I_2 
Stack 22
J_4 H_0 I_1 A_4 H_2 
Stack 23
C_1 G_5 E_10 G_6 C_6 
