Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_11 F_9 D_5 C_0 D_6 G_6 
Stack 2
C_10 J_1 G_8 I_4 G_0 C_3 
Stack 3
J_5 E_1 I_10 A_8 G_9 H_5 
Stack 4
J_9 J_4 C_9 F_13 I_3 G_2 
Stack 5
I_0 H_1 E_6 E_2 E_9 F_1 
Stack 6
G_11 C_1 J_2 C_11 D_10 
Stack 7
D_8 D_9 G_10 F_8 E_13 
Stack 8
B_7 F_7 J_6 G_4 B_3 
Stack 9
H_4 F_0 C_4 D_2 I_1 
Stack 10
E_11 E_12 H_7 E_0 F_4 
Stack 11
E_3 D_7 J_7 B_10 A_7 
Stack 12
B_1 B_2 E_4 E_5 I_7 
Stack 13
E_10 G_1 F_6 A_2 G_3 
Stack 14
B_9 G_7 I_8 H_8 J_0 
Stack 15
H_11 B_6 A_1 I_2 F_10 
Stack 16
A_9 F_3 F_12 A_3 H_2 
Stack 17
F_2 H_10 B_4 D_3 C_8 
Stack 18
H_0 A_4 A_5 F_11 D_0 
Stack 19
F_5 G_5 H_6 H_3 J_3 
Stack 20
C_7 E_7 I_5 D_12 D_1 
Stack 21
C_6 J_8 G_12 I_9 B_5 
Stack 22
A_6 D_4 H_9 I_6 E_8 
Stack 23
A_0 B_0 B_8 C_2 C_5 
