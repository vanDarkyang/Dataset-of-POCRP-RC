Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_5 I_4 J_1 J_3 
Stack 2
C_5 A_4 B_4 J_4 
Stack 3
E_3 I_5 I_3 G_5 
Stack 4
D_2 D_7 I_1 F_0 
Stack 5
H_0 H_6 E_4 H_2 
Stack 6
I_0 C_1 H_5 B_2 
Stack 7
D_4 F_3 H_1 E_7 
Stack 8
F_7 F_5 F_4 G_1 
Stack 9
F_2 D_3 J_0 G_7 
Stack 10
E_0 H_4 G_2 G_3 
Stack 11
F_6 A_0 A_1 C_0 
Stack 12
A_3 E_2 F_1 D_1 
Stack 13
B_0 F_8 E_1 G_4 
Stack 14
C_2 B_1 G_0 I_2 
Stack 15
B_3 G_6 C_4 D_6 
Stack 16
A_2 D_5 B_5 E_8 
Stack 17
D_0 J_2 C_6 
Stack 18
C_3 E_6 H_3 
