Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_7 E_2 A_1 H_3 F_2 
Stack 2
E_5 F_3 A_2 B_2 J_3 
Stack 3
J_1 G_3 A_4 B_0 E_8 
Stack 4
J_0 C_2 F_4 C_1 I_4 
Stack 5
D_4 F_6 C_6 F_1 B_1 
Stack 6
E_6 C_5 B_4 G_2 G_5 
Stack 7
D_6 E_7 G_0 G_6 C_3 
Stack 8
I_3 B_5 F_8 I_2 A_0 
Stack 9
H_5 C_4 D_1 E_0 H_1 
Stack 10
G_7 H_6 E_3 E_4 B_3 
Stack 11
G_4 F_7 J_4 C_0 D_0 
Stack 12
H_4 J_2 D_2 I_0 D_3 
Stack 13
G_1 F_0 E_1 H_2 F_5 
Stack 14
I_5 A_3 H_0 D_5 I_1 
