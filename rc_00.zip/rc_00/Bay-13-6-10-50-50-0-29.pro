Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_0 F_2 D_5 E_6 
Stack 2
C_0 D_1 C_2 C_4 
Stack 3
E_2 E_0 E_3 B_1 
Stack 4
B_3 F_4 G_2 A_1 
Stack 5
D_3 A_0 F_3 E_1 
Stack 6
C_1 I_2 H_0 H_4 
Stack 7
I_3 D_4 J_0 J_1 
Stack 8
E_5 F_5 A_2 B_2 
Stack 9
C_3 H_2 H_1 G_5 
Stack 10
G_3 I_1 G_1 H_3 
Stack 11
F_0 J_2 E_4 G_0 
Stack 12
F_6 D_2 I_0 
Stack 13
F_1 G_4 D_0 
