Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_0 C_1 D_1 F_2 F_3 
Stack 2
H_3 I_0 E_3 F_6 D_3 
Stack 3
B_1 B_0 H_1 F_5 A_2 
Stack 4
F_1 H_2 G_0 H_0 J_0 
Stack 5
B_2 F_4 I_1 G_3 G_5 
Stack 6
H_4 E_1 J_1 G_4 A_1 
Stack 7
E_2 E_4 D_0 G_1 D_5 
Stack 8
C_0 D_2 I_3 E_6 E_0 
Stack 9
B_3 D_4 I_2 C_3 C_2 
Stack 10
G_2 C_4 J_2 F_0 E_5 
