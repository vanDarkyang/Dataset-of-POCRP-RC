Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_4 H_3 I_0 D_2 E_3 G_2 
Stack 2
G_7 L_0 I_3 D_5 J_0 D_1 
Stack 3
E_0 F_4 M_2 C_2 H_1 C_0 
Stack 4
J_6 M_1 J_3 E_4 L_2 M_0 
Stack 5
D_0 F_7 E_2 J_7 G_1 
Stack 6
I_2 F_0 M_4 F_3 F_2 
Stack 7
E_5 G_0 H_4 D_4 K_2 
Stack 8
G_4 F_1 B_3 O_0 J_4 
Stack 9
K_0 I_1 L_1 A_2 D_3 
Stack 10
H_9 K_3 E_1 G_8 J_2 
Stack 11
L_3 L_5 N_1 H_0 N_0 
Stack 12
N_2 H_2 C_3 F_6 C_4 
Stack 13
I_8 G_6 I_5 E_6 H_7 
Stack 14
F_5 H_5 J_5 G_3 A_0 
Stack 15
N_3 H_6 G_5 K_1 H_8 
Stack 16
B_1 O_1 L_4 K_4 O_2 
Stack 17
M_3 C_1 I_6 J_1 I_7 
Stack 18
A_1 K_6 K_5 B_2 B_0 
