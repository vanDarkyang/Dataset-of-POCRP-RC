Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_4 A_6 B_7 B_2 C_6 
Stack 2
D_8 A_5 D_10 A_9 C_2 
Stack 3
E_8 B_1 A_0 E_2 D_7 
Stack 4
A_8 C_3 B_3 D_5 B_5 
Stack 5
C_1 B_4 A_2 C_0 C_5 
Stack 6
E_0 B_8 E_9 D_0 B_10 
Stack 7
D_6 C_10 D_1 B_0 C_7 
Stack 8
E_5 A_4 E_6 B_9 E_1 
Stack 9
C_11 C_4 D_2 C_9 D_3 
Stack 10
E_4 B_6 A_1 A_3 C_8 
Stack 11
A_7 D_9 E_3 E_7 
