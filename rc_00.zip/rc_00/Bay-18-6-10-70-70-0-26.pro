Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_2 H_4 H_0 I_1 
Stack 2
C_0 J_4 E_3 B_1 
Stack 3
A_4 B_0 J_1 I_5 
Stack 4
C_6 G_5 I_3 F_3 
Stack 5
D_3 C_3 A_1 I_0 
Stack 6
B_5 D_7 C_5 G_4 
Stack 7
G_0 D_2 F_2 E_7 
Stack 8
H_5 J_0 D_4 F_8 
Stack 9
F_4 D_6 E_5 A_3 
Stack 10
B_2 F_5 E_2 F_0 
Stack 11
F_1 C_4 F_7 E_8 
Stack 12
F_6 B_3 I_4 H_1 
Stack 13
D_1 D_5 G_1 D_0 
Stack 14
H_6 G_6 I_2 H_3 
Stack 15
G_2 H_2 E_1 J_3 
Stack 16
E_0 G_3 E_4 E_6 
Stack 17
G_7 B_4 A_0 
Stack 18
J_2 C_1 C_2 
