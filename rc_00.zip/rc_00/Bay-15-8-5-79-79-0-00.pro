Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_10 B_13 C_2 C_4 A_3 E_0 
Stack 2
E_10 D_10 D_14 B_5 A_8 D_0 
Stack 3
C_6 D_1 D_6 E_12 C_3 A_4 
Stack 4
B_9 E_4 E_14 D_7 C_13 A_6 
Stack 5
C_8 A_2 E_13 B_2 D_15 
Stack 6
D_8 B_11 C_14 C_1 A_1 
Stack 7
C_11 C_7 B_14 E_9 A_7 
Stack 8
B_7 D_2 E_1 D_11 B_1 
Stack 9
D_5 E_3 C_9 D_12 E_5 
Stack 10
C_16 C_10 A_12 B_3 C_15 
Stack 11
B_10 C_5 B_8 E_6 D_13 
Stack 12
A_5 A_9 B_4 E_2 B_6 
Stack 13
B_0 B_12 B_15 D_9 A_13 
Stack 14
D_4 C_12 A_14 A_0 E_11 
Stack 15
D_3 A_11 E_8 E_7 C_0 
