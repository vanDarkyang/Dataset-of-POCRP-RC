Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_10 B_11 B_8 A_3 
Stack 2
E_10 C_7 B_4 A_8 
Stack 3
C_6 D_2 B_15 C_3 
Stack 4
B_9 E_3 A_14 C_13 
Stack 5
C_8 C_10 E_8 D_15 
Stack 6
D_8 C_5 C_4 A_1 
Stack 7
C_11 A_9 B_5 A_7 
Stack 8
B_7 B_12 E_12 B_1 
Stack 9
D_5 C_12 D_7 E_5 
Stack 10
C_16 A_11 B_2 C_15 
Stack 11
B_10 C_2 C_1 D_13 
Stack 12
A_5 D_14 E_9 B_6 
Stack 13
B_0 D_6 D_11 A_13 
Stack 14
D_4 E_14 D_12 E_11 
Stack 15
D_3 E_13 B_3 C_0 
Stack 16
B_13 C_14 E_6 E_0 
Stack 17
D_10 B_14 E_2 D_0 
Stack 18
D_1 E_1 D_9 A_4 
Stack 19
E_4 C_9 A_0 A_6 
Stack 20
A_2 A_12 E_7 
