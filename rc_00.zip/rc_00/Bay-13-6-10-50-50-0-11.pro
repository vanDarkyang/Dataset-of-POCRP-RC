Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_5 E_4 F_4 F_5 
Stack 2
E_3 D_0 H_2 E_6 
Stack 3
C_2 H_4 G_1 G_2 
Stack 4
G_4 G_5 A_1 C_1 
Stack 5
B_1 F_2 C_4 I_0 
Stack 6
F_1 H_1 J_2 B_3 
Stack 7
D_3 B_0 I_3 D_5 
Stack 8
F_3 H_0 J_0 H_3 
Stack 9
D_4 E_1 G_3 I_2 
Stack 10
F_6 I_1 A_2 A_0 
Stack 11
E_0 G_0 E_2 B_2 
Stack 12
J_1 F_0 D_2 
Stack 13
D_1 C_0 C_3 
