Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
N_1 F_6 G_1 J_0 M_4 K_6 
Stack 2
F_3 E_1 H_5 D_1 A_1 O_2 
Stack 3
I_2 I_1 D_2 K_2 J_3 M_3 
Stack 4
E_5 G_0 F_7 D_3 C_3 F_5 
Stack 5
H_4 L_2 H_0 H_7 J_5 
Stack 6
B_2 F_2 D_4 A_0 H_8 
Stack 7
J_6 N_0 G_5 J_4 K_0 
Stack 8
C_2 D_0 L_3 J_1 F_0 
Stack 9
I_0 G_3 I_3 E_6 M_0 
Stack 10
D_5 I_5 F_4 I_6 C_4 
Stack 11
A_2 G_2 L_4 L_1 B_3 
Stack 12
B_1 C_0 B_0 H_3 G_4 
Stack 13
C_1 E_3 N_3 K_5 I_7 
Stack 14
M_1 I_8 K_1 J_7 K_3 
Stack 15
I_4 M_2 E_2 E_4 K_4 
Stack 16
G_7 H_2 E_0 H_9 G_6 
Stack 17
F_1 G_8 J_2 H_1 N_2 
Stack 18
H_6 L_5 O_1 L_0 O_0 
