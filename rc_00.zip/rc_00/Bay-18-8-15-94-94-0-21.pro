Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 G_5 M_3 G_0 L_3 F_7 
Stack 2
I_6 M_1 I_3 K_4 I_8 O_2 
Stack 3
J_2 G_4 N_3 J_3 L_1 M_4 
Stack 4
E_5 L_0 J_1 F_4 H_4 A_0 
Stack 5
K_5 G_1 C_4 G_3 D_5 
Stack 6
E_0 E_2 C_0 H_8 K_3 
Stack 7
G_8 F_0 K_2 J_7 D_0 
Stack 8
J_6 H_5 I_0 C_1 E_1 
Stack 9
D_1 L_2 A_1 I_4 I_5 
Stack 10
J_0 H_1 J_4 D_3 F_2 
Stack 11
K_6 I_1 K_1 O_1 N_2 
Stack 12
O_0 K_0 F_6 B_2 F_3 
Stack 13
H_9 M_0 F_5 H_7 H_6 
Stack 14
H_0 E_6 D_2 J_5 H_3 
Stack 15
B_0 I_7 M_2 L_4 E_4 
Stack 16
E_3 B_1 F_1 G_7 I_2 
Stack 17
H_2 C_2 N_1 N_0 B_3 
Stack 18
G_6 D_4 L_5 G_2 A_2 
