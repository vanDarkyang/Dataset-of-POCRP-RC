Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 B_6 A_7 A_3 
Stack 2
B_7 C_3 A_2 C_4 
Stack 3
A_9 C_11 B_11 C_5 
Stack 4
A_5 A_4 B_0 C_8 
Stack 5
B_14 C_6 C_13 B_9 
Stack 6
A_8 B_4 B_3 C_10 
Stack 7
B_5 B_13 B_8 B_2 
Stack 8
A_6 A_12 A_11 C_7 
Stack 9
A_14 C_0 A_1 B_15 
Stack 10
A_0 B_10 C_14 B_12 
Stack 11
C_1 C_9 A_10 
Stack 12
C_2 C_12 A_13 
