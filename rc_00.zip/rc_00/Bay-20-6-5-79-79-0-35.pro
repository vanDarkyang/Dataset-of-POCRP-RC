Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_2 D_11 E_0 E_5 
Stack 2
C_5 B_14 B_3 D_7 
Stack 3
C_16 B_11 C_10 C_13 
Stack 4
E_2 C_15 D_14 E_7 
Stack 5
A_14 A_6 D_5 C_14 
Stack 6
A_8 D_2 C_7 A_7 
Stack 7
C_4 A_1 D_1 A_9 
Stack 8
A_3 D_10 B_6 C_2 
Stack 9
D_4 A_13 E_14 A_4 
Stack 10
D_8 C_11 E_1 B_4 
Stack 11
B_15 B_1 E_12 B_0 
Stack 12
C_9 C_12 B_8 B_9 
Stack 13
A_11 E_10 B_13 C_6 
Stack 14
D_6 D_12 E_6 E_13 
Stack 15
C_1 D_9 B_10 C_3 
Stack 16
E_9 B_7 A_2 A_5 
Stack 17
E_11 D_3 D_13 A_12 
Stack 18
B_5 B_12 C_8 A_10 
Stack 19
D_15 E_4 A_0 C_0 
Stack 20
D_0 E_8 E_3 
