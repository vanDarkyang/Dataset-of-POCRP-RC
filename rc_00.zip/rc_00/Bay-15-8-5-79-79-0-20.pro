Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 A_12 C_11 C_12 C_13 C_6 
Stack 2
A_14 A_3 B_8 C_9 A_4 C_5 
Stack 3
A_0 E_6 E_14 A_10 D_7 E_7 
Stack 4
B_11 E_4 C_1 A_9 C_2 E_11 
Stack 5
B_0 B_7 C_0 E_9 E_8 
Stack 6
B_15 A_8 D_11 A_2 C_15 
Stack 7
A_7 B_2 B_6 D_12 A_5 
Stack 8
A_13 E_5 E_1 B_4 D_5 
Stack 9
D_8 D_6 A_6 E_2 B_12 
Stack 10
A_11 D_2 D_10 B_10 E_0 
Stack 11
A_1 E_3 D_1 C_4 D_0 
Stack 12
C_3 B_13 C_7 E_10 D_13 
Stack 13
B_3 D_15 D_4 D_14 C_16 
Stack 14
B_5 C_14 E_12 E_13 C_8 
Stack 15
B_9 B_14 D_3 D_9 C_10 
