Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_8 C_11 C_5 A_4 B_4 
Stack 2
E_8 A_0 C_6 A_3 E_6 
Stack 3
D_5 A_1 C_3 B_1 D_8 
Stack 4
D_9 B_9 C_4 B_8 B_5 
Stack 5
D_10 D_0 B_7 E_2 D_1 
Stack 6
B_6 C_0 D_6 E_0 C_7 
Stack 7
C_10 A_8 E_9 A_9 E_3 
Stack 8
D_7 A_7 B_2 E_7 D_3 
Stack 9
A_5 E_1 C_9 D_2 E_5 
Stack 10
A_2 E_4 D_4 B_0 A_6 
Stack 11
C_2 B_10 C_1 B_3 
