Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_0 H_8 E_5 K_1 M_4 B_2 
Stack 2
B_0 F_7 J_4 E_6 E_4 G_0 
Stack 3
L_1 J_2 F_1 H_2 J_0 G_1 
Stack 4
H_6 K_2 O_1 I_7 D_1 A_0 
Stack 5
N_3 B_1 K_6 M_0 E_1 
Stack 6
O_2 F_0 H_1 G_7 C_3 
Stack 7
L_2 G_5 L_3 C_2 L_4 
Stack 8
J_1 H_7 A_1 J_6 A_2 
Stack 9
E_0 F_6 F_2 J_5 G_6 
Stack 10
N_1 H_3 D_0 H_9 M_1 
Stack 11
K_4 L_0 F_4 J_7 L_5 
Stack 12
D_2 I_6 G_8 I_4 F_3 
Stack 13
I_0 E_2 K_3 H_0 D_3 
Stack 14
I_1 I_2 C_1 H_5 J_3 
Stack 15
D_4 E_3 B_3 K_5 G_4 
Stack 16
G_3 M_3 I_8 M_2 O_0 
Stack 17
G_2 D_5 N_0 N_2 C_4 
Stack 18
H_4 F_5 C_0 I_3 I_5 
