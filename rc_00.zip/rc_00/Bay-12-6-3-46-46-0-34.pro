Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_2 B_12 C_13 A_8 
Stack 2
C_3 C_4 A_5 C_12 
Stack 3
B_1 B_8 B_13 C_6 
Stack 4
A_13 B_14 A_3 A_9 
Stack 5
C_7 B_11 B_9 C_11 
Stack 6
A_1 A_12 B_6 B_15 
Stack 7
B_5 A_0 A_11 A_7 
Stack 8
A_10 A_6 B_4 B_10 
Stack 9
B_2 C_1 C_10 B_0 
Stack 10
C_0 C_5 C_9 B_3 
Stack 11
C_14 C_2 A_14 
Stack 12
A_4 C_8 B_7 
