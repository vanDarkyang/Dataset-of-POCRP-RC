Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_2 F_5 F_4 B_1 
Stack 2
I_0 H_6 G_2 G_8 
Stack 3
F_1 O_1 G_4 H_2 
Stack 4
F_3 I_1 A_2 L_4 
Stack 5
H_0 G_1 G_7 N_0 
Stack 6
E_2 F_0 J_2 G_6 
Stack 7
G_0 F_6 E_0 A_1 
Stack 8
E_5 C_0 I_6 J_0 
Stack 9
C_2 L_3 L_1 G_5 
Stack 10
L_2 H_9 M_1 M_0 
Stack 11
C_1 I_2 B_3 O_2 
Stack 12
H_5 O_0 M_2 D_0 
Stack 13
D_1 K_3 J_7 H_7 
Stack 14
I_3 H_1 J_3 N_3 
Stack 15
B_0 H_8 J_6 L_5 
Stack 16
N_2 K_6 E_4 L_0 
Stack 17
B_2 A_0 G_3 E_3 
Stack 18
F_7 N_1 I_4 C_3 
Stack 19
I_7 H_4 K_0 E_1 
Stack 20
K_4 D_4 J_1 D_2 
Stack 21
K_5 H_3 K_1 C_4 
Stack 22
M_4 J_4 I_8 M_3 
Stack 23
J_5 I_5 E_6 
Stack 24
D_3 D_5 F_2 
