Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_2 E_12 D_2 B_4 
Stack 2
D_14 C_9 B_7 B_5 
Stack 3
A_1 C_2 C_14 E_14 
Stack 4
D_11 D_13 B_11 D_7 
Stack 5
B_0 D_5 A_5 D_1 
Stack 6
C_1 A_0 E_1 E_7 
Stack 7
E_9 C_3 A_6 D_12 
Stack 8
B_12 E_5 C_0 C_4 
Stack 9
E_6 D_15 E_0 D_3 
Stack 10
B_15 C_13 E_2 E_11 
Stack 11
B_1 D_10 D_6 A_3 
Stack 12
B_6 D_9 C_11 C_6 
Stack 13
E_3 A_8 A_13 B_8 
Stack 14
E_8 C_8 C_12 E_4 
Stack 15
D_0 A_2 A_10 E_13 
Stack 16
A_9 C_7 C_16 B_13 
Stack 17
A_7 C_15 E_10 C_5 
Stack 18
A_14 D_8 B_3 A_12 
Stack 19
B_14 D_4 A_11 A_4 
Stack 20
B_9 B_10 C_10 
