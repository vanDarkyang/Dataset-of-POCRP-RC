Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_5 A_2 B_8 A_1 
Stack 2
E_9 D_1 D_6 D_8 
Stack 3
A_8 D_10 C_7 C_0 
Stack 4
E_5 D_4 D_5 A_6 
Stack 5
C_2 A_7 C_4 C_9 
Stack 6
A_4 A_0 E_3 D_7 
Stack 7
B_6 B_0 C_8 E_7 
Stack 8
A_9 C_11 C_1 E_6 
Stack 9
B_3 A_5 D_0 C_6 
Stack 10
E_8 E_0 B_9 E_2 
Stack 11
C_3 D_9 B_5 B_7 
Stack 12
B_4 C_10 D_2 D_3 
Stack 13
B_2 B_10 E_4 
Stack 14
A_3 E_1 B_1 
