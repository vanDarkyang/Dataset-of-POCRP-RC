Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_7 D_8 A_7 E_5 
Stack 2
B_3 B_4 C_9 C_11 
Stack 3
E_1 A_2 E_3 E_7 
Stack 4
A_6 C_6 A_4 E_6 
Stack 5
D_9 B_1 D_5 B_8 
Stack 6
D_0 D_10 E_9 E_4 
Stack 7
C_8 C_1 B_10 B_2 
Stack 8
C_2 E_0 D_6 D_3 
Stack 9
C_3 C_10 E_2 D_2 
Stack 10
A_8 A_9 D_4 B_7 
Stack 11
C_5 C_7 A_1 B_6 
Stack 12
A_3 A_5 B_5 E_8 
Stack 13
D_1 B_9 C_4 
Stack 14
B_0 A_0 C_0 
