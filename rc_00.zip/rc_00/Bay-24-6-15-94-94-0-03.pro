Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
N_0 B_1 L_0 E_5 
Stack 2
F_1 M_0 J_2 M_4 
Stack 3
D_1 F_0 A_1 J_0 
Stack 4
E_6 L_1 H_9 M_2 
Stack 5
C_4 I_0 J_3 F_2 
Stack 6
G_2 E_0 C_3 J_6 
Stack 7
G_5 G_3 H_8 E_3 
Stack 8
J_7 G_8 G_7 H_6 
Stack 9
O_1 J_4 L_2 B_2 
Stack 10
F_6 M_3 K_0 I_5 
Stack 11
J_5 H_2 O_2 F_7 
Stack 12
K_6 K_4 D_5 I_4 
Stack 13
E_4 D_4 J_1 E_1 
Stack 14
A_0 H_7 L_5 H_1 
Stack 15
N_2 M_1 F_4 H_4 
Stack 16
G_6 D_3 K_5 D_2 
Stack 17
D_0 K_2 I_8 C_0 
Stack 18
N_3 N_1 L_4 G_0 
Stack 19
C_1 I_7 I_1 G_1 
Stack 20
H_5 K_1 G_4 C_2 
Stack 21
L_3 E_2 F_3 H_0 
Stack 22
B_3 I_2 O_0 B_0 
Stack 23
F_5 I_3 A_2 
Stack 24
H_3 I_6 K_3 
