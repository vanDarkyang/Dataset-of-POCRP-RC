Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_0 F_0 A_8 F_13 A_4 G_2 
Stack 2
B_4 J_5 B_6 B_1 F_8 A_7 
Stack 3
D_9 G_9 H_4 B_7 C_0 C_5 
Stack 4
H_8 G_1 F_4 G_5 E_6 G_6 
Stack 5
J_2 I_5 D_6 I_7 D_2 A_2 
Stack 6
D_8 D_12 C_8 D_7 A_6 
Stack 7
D_11 C_11 B_10 G_10 A_0 
Stack 8
C_7 H_6 A_9 D_3 H_9 
Stack 9
E_9 I_3 J_6 E_10 D_10 
Stack 10
H_5 F_10 A_5 C_3 I_8 
Stack 11
F_6 H_3 F_1 H_0 F_3 
Stack 12
F_9 J_8 B_0 I_4 G_8 
Stack 13
I_9 E_3 I_1 D_4 G_12 
Stack 14
J_3 D_1 A_1 C_9 G_7 
Stack 15
E_2 E_13 D_0 B_5 G_3 
Stack 16
I_10 E_4 F_7 J_4 G_0 
Stack 17
E_5 F_11 E_1 C_2 J_7 
Stack 18
B_8 F_5 H_1 J_0 E_7 
Stack 19
B_3 H_2 J_9 I_6 A_3 
Stack 20
H_10 I_0 C_6 F_2 C_10 
Stack 21
I_2 B_2 J_1 E_8 E_12 
Stack 22
H_11 G_4 G_11 D_5 C_1 
Stack 23
H_7 C_4 B_9 E_11 F_12 
