Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_7 N_2 G_7 E_4 
Stack 2
C_3 H_0 A_0 L_3 
Stack 3
F_3 I_5 M_0 C_1 
Stack 4
E_5 E_0 O_1 H_2 
Stack 5
C_0 H_1 J_5 H_4 
Stack 6
B_3 L_1 C_4 E_1 
Stack 7
H_7 H_8 C_2 F_0 
Stack 8
H_9 D_3 F_6 I_3 
Stack 9
F_2 E_2 F_1 F_4 
Stack 10
D_4 O_0 L_2 J_7 
Stack 11
I_8 H_3 M_1 A_1 
Stack 12
G_0 F_7 O_2 N_0 
Stack 13
G_2 K_2 G_5 J_3 
Stack 14
K_1 K_4 G_8 G_4 
Stack 15
J_0 L_0 L_4 N_3 
Stack 16
N_1 D_5 D_1 F_5 
Stack 17
D_2 H_5 M_4 I_0 
Stack 18
B_1 K_6 G_3 A_2 
Stack 19
L_5 K_5 J_4 K_0 
Stack 20
G_6 J_1 B_0 B_2 
Stack 21
I_4 H_6 J_2 D_0 
Stack 22
I_1 E_3 G_1 E_6 
Stack 23
I_6 K_3 M_2 
Stack 24
J_6 M_3 I_2 
