Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_5 A_11 B_3 B_6 
Stack 2
C_14 C_13 B_8 A_0 
Stack 3
C_3 B_12 B_0 B_1 
Stack 4
A_9 B_4 B_9 A_13 
Stack 5
C_7 A_3 C_12 B_15 
Stack 6
A_14 B_11 C_10 A_10 
Stack 7
A_8 B_14 A_5 C_8 
Stack 8
C_1 A_12 A_6 C_9 
Stack 9
B_10 A_4 C_5 B_13 
Stack 10
B_7 C_4 C_6 A_2 
Stack 11
C_11 A_1 B_2 
Stack 12
C_2 C_0 A_7 
