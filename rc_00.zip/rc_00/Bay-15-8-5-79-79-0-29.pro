Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_2 E_1 A_8 C_0 D_9 A_6 
Stack 2
E_11 A_13 D_4 E_7 A_10 C_12 
Stack 3
B_11 B_1 C_11 C_10 A_1 C_1 
Stack 4
B_5 B_9 E_9 D_12 B_0 C_13 
Stack 5
A_14 B_7 A_4 C_15 D_3 
Stack 6
B_13 A_2 B_10 C_14 B_4 
Stack 7
A_9 A_7 D_6 E_3 E_5 
Stack 8
D_8 C_5 E_8 D_11 D_15 
Stack 9
A_3 E_6 C_7 E_14 C_6 
Stack 10
A_11 D_13 E_12 D_0 B_2 
Stack 11
C_4 C_9 C_16 B_12 E_13 
Stack 12
B_3 D_1 D_7 E_10 A_0 
Stack 13
B_6 B_15 E_2 E_4 A_12 
Stack 14
D_14 B_8 B_14 D_10 C_3 
Stack 15
C_8 A_5 E_0 D_5 C_2 
