Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
N_1 G_0 J_7 J_2 
Stack 2
C_3 J_3 J_0 K_5 
Stack 3
G_4 H_1 I_4 H_4 
Stack 4
F_0 N_0 K_6 L_2 
Stack 5
K_3 E_0 F_7 N_2 
Stack 6
D_3 A_1 M_1 A_0 
Stack 7
G_3 E_4 K_2 M_4 
Stack 8
D_0 H_9 H_6 B_0 
Stack 9
F_5 J_4 C_0 F_6 
Stack 10
L_0 I_7 H_5 C_1 
Stack 11
L_3 G_1 G_2 F_2 
Stack 12
I_0 I_8 K_0 J_6 
Stack 13
G_6 B_2 E_2 G_5 
Stack 14
L_4 G_7 D_1 E_6 
Stack 15
I_2 D_2 K_1 B_1 
Stack 16
I_5 N_3 K_4 O_0 
Stack 17
M_3 J_1 D_5 D_4 
Stack 18
H_2 H_7 I_3 O_1 
Stack 19
E_1 A_2 E_5 J_5 
Stack 20
M_0 F_3 L_5 F_4 
Stack 21
H_0 H_8 E_3 H_3 
Stack 22
O_2 I_6 G_8 I_1 
Stack 23
L_1 B_3 M_2 
Stack 24
C_2 C_4 F_1 
