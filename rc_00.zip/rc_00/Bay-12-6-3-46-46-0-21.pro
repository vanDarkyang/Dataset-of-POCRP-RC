Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_14 A_3 A_1 B_5 
Stack 2
C_10 C_14 A_10 C_4 
Stack 3
C_11 B_2 C_3 C_5 
Stack 4
A_4 A_8 C_7 C_9 
Stack 5
B_9 A_0 C_0 A_2 
Stack 6
A_7 C_13 A_5 B_0 
Stack 7
B_6 C_12 B_3 A_12 
Stack 8
A_11 B_1 C_2 B_4 
Stack 9
C_6 C_1 B_7 B_14 
Stack 10
B_12 B_15 C_8 A_9 
Stack 11
A_13 B_11 A_6 
Stack 12
B_10 B_13 B_8 
