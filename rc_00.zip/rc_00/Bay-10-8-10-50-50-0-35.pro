Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_0 E_4 D_1 A_2 E_2 
Stack 2
B_0 J_1 I_3 B_1 F_4 
Stack 3
B_3 F_5 C_0 G_2 F_3 
Stack 4
J_0 F_2 E_5 I_0 F_6 
Stack 5
E_1 D_3 E_3 F_1 E_6 
Stack 6
G_3 G_5 A_1 D_2 G_4 
Stack 7
D_5 H_2 H_1 G_1 I_1 
Stack 8
D_0 A_0 D_4 C_4 H_4 
Stack 9
H_0 C_1 C_3 C_2 J_2 
Stack 10
H_3 F_0 I_2 B_2 G_0 
