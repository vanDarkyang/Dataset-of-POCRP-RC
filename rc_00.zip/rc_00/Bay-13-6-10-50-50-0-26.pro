Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_3 F_0 A_2 I_1 
Stack 2
F_1 I_0 I_3 J_1 
Stack 3
E_6 D_3 F_4 B_2 
Stack 4
E_3 D_1 B_1 G_4 
Stack 5
F_5 J_0 H_2 G_3 
Stack 6
G_0 A_1 D_0 C_1 
Stack 7
F_6 H_1 E_1 C_0 
Stack 8
G_1 I_2 D_5 B_0 
Stack 9
G_5 F_2 C_2 C_3 
Stack 10
E_0 J_2 E_4 E_2 
Stack 11
D_4 E_5 H_0 C_4 
Stack 12
H_3 H_4 A_0 
Stack 13
D_2 F_3 G_2 
