Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 I_2 E_0 G_2 D_0 
Stack 2
I_0 D_4 G_5 F_0 E_3 
Stack 3
G_0 H_0 D_3 H_4 C_0 
Stack 4
B_3 F_6 A_1 H_3 F_4 
Stack 5
C_2 C_4 E_2 H_2 D_2 
Stack 6
J_1 F_5 A_2 A_0 G_4 
Stack 7
I_1 E_4 E_5 F_2 E_1 
Stack 8
D_1 F_3 G_3 D_5 B_1 
Stack 9
I_3 J_2 B_2 F_1 B_0 
Stack 10
E_6 G_1 H_1 C_1 J_0 
