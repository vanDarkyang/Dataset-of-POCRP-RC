Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_7 B_2 H_4 A_4 J_5 D_8 
Stack 2
D_3 A_9 C_6 G_5 D_1 F_8 
Stack 3
H_10 J_6 J_0 B_5 E_10 C_3 
Stack 4
G_12 F_12 F_10 I_7 B_1 B_9 
Stack 5
C_5 C_8 I_6 B_4 C_11 F_5 
Stack 6
F_0 E_5 E_8 E_12 B_0 
Stack 7
G_10 I_5 H_5 C_9 C_10 
Stack 8
J_9 G_4 I_4 F_13 G_2 
Stack 9
D_5 A_1 E_13 I_2 B_6 
Stack 10
I_9 I_1 A_8 H_6 B_7 
Stack 11
D_10 G_1 B_3 D_4 E_0 
Stack 12
D_6 H_7 I_0 J_2 D_9 
Stack 13
C_1 D_7 A_0 E_2 F_1 
Stack 14
J_1 G_0 A_3 G_9 J_4 
Stack 15
G_6 H_9 D_11 I_3 A_7 
Stack 16
C_4 D_12 B_10 F_6 C_0 
Stack 17
B_8 A_6 G_8 C_7 H_8 
Stack 18
G_3 C_2 E_4 H_2 I_8 
Stack 19
D_0 J_8 F_2 F_4 H_3 
Stack 20
G_11 F_11 A_2 I_10 F_3 
Stack 21
A_5 E_3 F_7 E_9 H_0 
Stack 22
D_2 E_1 F_9 E_6 H_11 
Stack 23
H_1 J_3 G_7 E_7 E_11 
