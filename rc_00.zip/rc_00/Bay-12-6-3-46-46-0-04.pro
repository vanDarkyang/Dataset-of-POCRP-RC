Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_5 B_5 C_4 B_7 
Stack 2
B_9 B_14 B_1 A_2 
Stack 3
A_0 B_2 C_1 C_6 
Stack 4
B_4 B_3 A_10 A_6 
Stack 5
B_13 A_5 A_13 B_6 
Stack 6
C_3 C_7 A_9 A_8 
Stack 7
A_12 C_11 A_3 C_14 
Stack 8
B_12 C_13 C_2 B_0 
Stack 9
C_0 A_14 B_15 A_4 
Stack 10
B_11 A_7 A_11 A_1 
Stack 11
C_9 B_8 C_8 
Stack 12
C_10 B_10 C_12 
