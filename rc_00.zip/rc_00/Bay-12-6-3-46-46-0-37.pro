Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_0 B_7 C_12 B_1 
Stack 2
B_3 B_5 C_4 B_12 
Stack 3
A_4 A_5 C_0 B_11 
Stack 4
A_7 C_2 C_5 C_11 
Stack 5
B_4 A_6 C_10 C_13 
Stack 6
B_6 A_13 C_14 A_8 
Stack 7
A_2 B_15 A_1 C_6 
Stack 8
A_14 B_14 C_1 A_9 
Stack 9
C_9 C_7 C_8 A_10 
Stack 10
C_3 A_3 B_9 A_0 
Stack 11
B_13 A_11 A_12 
Stack 12
B_8 B_10 B_2 
