Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_8 I_8 E_0 D_4 D_1 H_4 
Stack 2
G_3 H_0 I_1 F_1 B_3 E_1 
Stack 3
C_0 H_6 L_4 H_5 O_0 J_0 
Stack 4
E_4 N_3 B_2 N_1 D_3 N_2 
Stack 5
G_1 K_2 M_3 A_0 L_0 
Stack 6
L_3 G_2 B_0 K_0 J_2 
Stack 7
I_3 E_2 F_2 I_5 O_2 
Stack 8
H_9 J_7 H_1 G_4 G_0 
Stack 9
G_6 G_7 I_6 E_3 M_0 
Stack 10
D_0 I_2 E_6 I_7 J_1 
Stack 11
A_2 J_4 F_6 K_1 O_1 
Stack 12
H_2 M_2 B_1 J_5 H_3 
Stack 13
L_5 I_4 C_3 J_6 M_1 
Stack 14
G_5 L_2 E_5 D_5 F_4 
Stack 15
H_7 K_3 C_4 I_0 F_7 
Stack 16
F_3 L_1 D_2 H_8 C_1 
Stack 17
K_6 K_4 M_4 J_3 F_0 
Stack 18
C_2 F_5 A_1 K_5 N_0 
