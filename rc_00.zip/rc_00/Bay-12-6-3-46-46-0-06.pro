Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_0 A_7 C_7 B_7 
Stack 2
A_12 C_11 A_5 B_11 
Stack 3
B_0 B_12 A_8 C_10 
Stack 4
C_8 C_6 A_14 B_3 
Stack 5
A_3 B_5 B_9 C_2 
Stack 6
B_13 A_11 C_4 C_12 
Stack 7
B_14 C_9 B_15 B_1 
Stack 8
C_14 C_13 C_5 C_3 
Stack 9
B_2 A_6 A_9 C_1 
Stack 10
B_8 A_1 B_4 A_10 
Stack 11
A_4 B_10 B_6 
Stack 12
A_0 A_13 A_2 
