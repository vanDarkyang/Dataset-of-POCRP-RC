Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_1 I_6 D_0 J_3 B_1 J_6 
Stack 2
G_6 C_10 H_6 A_9 I_8 B_4 
Stack 3
H_10 J_0 E_5 J_7 E_0 D_10 
Stack 4
G_0 F_1 F_7 C_7 A_7 F_12 
Stack 5
I_4 B_5 B_9 E_3 I_9 A_0 
Stack 6
D_6 E_9 E_10 C_4 B_10 
Stack 7
H_5 D_9 E_13 I_5 F_8 
Stack 8
F_11 G_12 B_6 G_9 F_4 
Stack 9
C_11 D_2 H_2 B_0 H_7 
Stack 10
H_1 B_7 C_2 F_10 C_8 
Stack 11
G_8 I_7 C_5 D_8 F_13 
Stack 12
E_8 I_10 C_0 C_3 B_3 
Stack 13
E_6 A_1 F_3 J_5 G_4 
Stack 14
J_2 D_3 D_4 A_8 E_2 
Stack 15
E_7 H_11 G_5 F_2 G_3 
Stack 16
J_8 G_11 H_3 E_12 H_0 
Stack 17
B_8 E_4 H_9 A_3 D_7 
Stack 18
C_6 D_5 A_4 G_7 D_11 
Stack 19
F_5 D_12 F_6 I_0 B_2 
Stack 20
G_10 E_11 G_2 J_9 I_2 
Stack 21
H_8 A_2 F_0 I_1 D_1 
Stack 22
I_3 E_1 C_1 J_1 A_6 
Stack 23
C_9 H_4 J_4 A_5 F_9 
