Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_7 C_3 G_7 G_2 D_6 G_6 
Stack 2
B_0 F_13 H_2 D_10 C_0 E_0 
Stack 3
B_5 A_5 H_9 F_8 D_0 I_9 
Stack 4
C_2 A_8 I_8 J_5 G_12 B_9 
Stack 5
F_6 I_7 G_11 H_8 H_10 J_4 
Stack 6
A_2 J_6 E_11 D_8 G_1 
Stack 7
H_11 F_3 J_2 C_1 J_9 
Stack 8
C_6 H_4 A_0 D_5 F_2 
Stack 9
G_5 G_8 I_3 D_1 C_7 
Stack 10
G_9 A_1 C_4 J_8 B_3 
Stack 11
E_6 G_10 B_6 D_4 B_4 
Stack 12
A_3 D_7 I_0 D_12 F_4 
Stack 13
D_2 F_0 G_3 F_5 C_9 
Stack 14
F_1 H_7 J_1 C_11 H_0 
Stack 15
I_4 A_4 E_2 I_10 E_12 
Stack 16
B_7 E_4 A_6 D_11 I_1 
Stack 17
A_7 F_10 C_10 I_2 J_3 
Stack 18
F_12 C_5 E_1 E_3 F_7 
Stack 19
H_3 H_1 D_3 I_6 E_9 
Stack 20
C_8 B_10 E_10 H_6 B_2 
Stack 21
A_9 G_0 J_0 G_4 E_8 
Stack 22
E_13 I_5 B_1 B_8 D_9 
Stack 23
E_5 F_9 F_11 H_5 E_7 
