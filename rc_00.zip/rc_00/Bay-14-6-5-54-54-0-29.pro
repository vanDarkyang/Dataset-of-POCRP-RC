Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_4 C_0 D_2 D_7 
Stack 2
A_7 A_8 C_8 C_10 
Stack 3
E_7 E_6 E_3 B_0 
Stack 4
E_2 E_8 C_11 D_3 
Stack 5
C_1 A_1 C_6 A_4 
Stack 6
B_9 C_7 A_3 B_5 
Stack 7
E_0 D_0 B_3 B_7 
Stack 8
A_9 C_5 D_10 D_5 
Stack 9
C_4 D_8 C_3 D_9 
Stack 10
E_5 B_4 C_2 A_6 
Stack 11
C_9 B_1 D_4 B_10 
Stack 12
E_9 A_0 E_1 B_6 
Stack 13
B_2 D_6 A_5 
Stack 14
B_8 A_2 D_1 
