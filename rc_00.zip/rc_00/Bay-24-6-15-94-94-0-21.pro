Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 F_0 F_5 L_3 
Stack 2
I_6 H_5 D_2 I_8 
Stack 3
J_2 L_2 M_2 L_1 
Stack 4
E_5 H_1 F_1 H_4 
Stack 5
K_5 I_1 N_1 D_5 
Stack 6
E_0 K_0 L_5 K_3 
Stack 7
G_8 M_0 G_0 D_0 
Stack 8
J_6 E_6 K_4 E_1 
Stack 9
D_1 I_7 J_3 I_5 
Stack 10
J_0 B_1 F_4 F_2 
Stack 11
K_6 C_2 G_3 N_2 
Stack 12
O_0 D_4 H_8 F_3 
Stack 13
H_9 M_3 J_7 H_6 
Stack 14
H_0 I_3 C_1 H_3 
Stack 15
B_0 N_3 I_4 E_4 
Stack 16
E_3 J_1 D_3 I_2 
Stack 17
H_2 C_4 O_1 B_3 
Stack 18
G_6 C_0 B_2 A_2 
Stack 19
G_5 K_2 H_7 F_7 
Stack 20
M_1 I_0 J_5 O_2 
Stack 21
G_4 A_1 L_4 M_4 
Stack 22
L_0 J_4 G_7 A_0 
Stack 23
G_1 K_1 N_0 
Stack 24
E_2 F_6 G_2 
