Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_4 B_1 C_11 E_8 
Stack 2
A_3 C_3 D_8 E_3 
Stack 3
C_10 A_0 C_9 E_4 
Stack 4
D_7 E_0 A_8 B_3 
Stack 5
B_9 B_10 C_1 D_3 
Stack 6
A_1 B_8 D_2 A_2 
Stack 7
E_2 E_1 D_1 D_10 
Stack 8
C_6 A_6 E_7 A_9 
Stack 9
D_4 C_2 B_6 C_5 
Stack 10
E_6 D_6 C_4 E_5 
Stack 11
B_5 B_7 A_7 D_0 
Stack 12
A_4 C_0 D_9 E_9 
Stack 13
B_2 C_7 C_8 
Stack 14
A_5 B_0 D_5 
