Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 F_0 M_0 K_6 
Stack 2
M_2 E_4 G_6 C_0 
Stack 3
I_5 O_2 I_1 J_6 
Stack 4
A_2 O_0 I_2 H_8 
Stack 5
K_3 H_6 I_6 C_4 
Stack 6
B_1 G_0 B_0 F_1 
Stack 7
H_7 D_4 M_1 G_3 
Stack 8
G_8 E_5 E_1 J_2 
Stack 9
J_3 M_3 D_2 L_5 
Stack 10
F_3 F_7 K_4 G_2 
Stack 11
D_3 L_0 G_5 N_3 
Stack 12
I_0 E_0 C_3 N_1 
Stack 13
M_4 C_1 E_6 D_5 
Stack 14
J_4 K_2 E_3 I_8 
Stack 15
I_4 I_3 F_2 E_2 
Stack 16
F_4 H_3 H_5 J_7 
Stack 17
D_1 A_1 L_1 J_1 
Stack 18
I_7 G_7 D_0 K_5 
Stack 19
H_9 N_2 F_5 F_6 
Stack 20
L_4 H_4 K_0 B_3 
Stack 21
G_1 B_2 K_1 N_0 
Stack 22
H_0 H_2 L_3 O_1 
Stack 23
G_4 J_5 A_0 
Stack 24
L_2 J_0 H_1 
