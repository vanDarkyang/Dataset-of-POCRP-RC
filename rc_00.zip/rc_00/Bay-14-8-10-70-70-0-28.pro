Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 G_1 A_3 J_3 A_2 
Stack 2
F_8 A_0 C_0 J_1 I_5 
Stack 3
E_5 B_5 J_2 E_7 E_8 
Stack 4
D_0 H_0 H_6 H_5 F_3 
Stack 5
E_1 G_2 D_5 F_1 H_1 
Stack 6
H_2 I_3 D_3 F_0 G_6 
Stack 7
B_2 E_0 C_3 B_1 G_3 
Stack 8
B_3 D_1 G_4 E_3 C_5 
Stack 9
G_5 F_5 H_4 J_0 I_4 
Stack 10
G_0 D_2 H_3 D_4 C_1 
Stack 11
G_7 J_4 E_4 C_6 D_7 
Stack 12
I_2 I_1 B_4 I_0 F_2 
Stack 13
F_7 F_6 D_6 B_0 C_4 
Stack 14
A_1 F_4 E_2 A_4 E_6 
