Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_6 B_5 C_10 C_7 E_7 
Stack 2
C_1 C_0 E_6 B_4 E_2 
Stack 3
B_9 E_4 E_8 E_9 A_6 
Stack 4
D_9 E_0 B_7 A_2 A_3 
Stack 5
A_9 D_3 A_4 E_1 A_1 
Stack 6
B_6 C_9 D_8 B_3 E_3 
Stack 7
D_1 B_0 C_8 B_1 D_10 
Stack 8
D_0 C_5 C_11 E_5 B_2 
Stack 9
D_7 B_8 C_3 D_5 D_4 
Stack 10
C_2 D_2 A_5 B_10 C_6 
Stack 11
A_7 A_8 C_4 A_0 
