Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_1 H_4 C_2 E_3 I_0 
Stack 2
H_2 G_1 D_7 D_2 H_5 
Stack 3
D_3 E_2 F_4 H_3 C_4 
Stack 4
B_0 D_0 A_4 A_1 F_6 
Stack 5
G_0 I_2 F_5 F_3 F_1 
Stack 6
F_2 J_4 E_0 G_4 F_7 
Stack 7
C_3 F_0 E_1 E_5 A_2 
Stack 8
C_5 B_1 D_1 B_2 H_0 
Stack 9
I_3 J_0 D_4 I_5 F_8 
Stack 10
A_3 G_6 G_3 G_2 A_0 
Stack 11
E_8 D_5 G_5 J_3 E_7 
Stack 12
C_6 E_6 G_7 C_0 H_1 
Stack 13
I_4 J_2 I_1 C_1 H_6 
Stack 14
B_4 D_6 B_3 E_4 B_5 
