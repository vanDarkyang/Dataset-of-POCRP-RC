Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_0 H_0 C_1 G_0 
Stack 2
H_1 G_3 J_1 E_4 
Stack 3
F_1 D_1 F_3 F_2 
Stack 4
G_5 D_4 G_1 E_1 
Stack 5
I_1 B_1 G_2 I_0 
Stack 6
F_4 F_0 J_2 E_2 
Stack 7
A_2 E_3 H_3 E_5 
Stack 8
D_3 G_4 D_5 C_4 
Stack 9
J_0 I_3 F_6 C_2 
Stack 10
H_4 A_0 H_2 E_0 
Stack 11
D_0 I_2 A_1 B_3 
Stack 12
C_0 C_3 F_5 
Stack 13
D_2 E_6 B_2 
