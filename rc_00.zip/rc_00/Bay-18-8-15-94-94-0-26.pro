Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_2 D_5 E_3 C_1 K_2 A_0 
Stack 2
E_2 F_4 M_4 M_1 N_1 A_1 
Stack 3
J_3 K_0 J_4 F_2 I_1 H_2 
Stack 4
E_6 H_9 K_1 M_3 J_0 G_8 
Stack 5
G_3 H_6 G_6 E_5 G_2 
Stack 6
F_3 I_3 O_2 C_4 D_1 
Stack 7
H_4 L_3 I_8 D_4 H_0 
Stack 8
I_5 D_0 K_6 K_3 G_0 
Stack 9
H_3 I_4 G_4 C_3 F_6 
Stack 10
F_0 I_7 H_7 C_0 F_1 
Stack 11
L_0 E_4 B_3 O_0 L_4 
Stack 12
L_5 H_5 J_6 L_2 J_2 
Stack 13
N_2 H_8 E_1 N_3 H_1 
Stack 14
J_1 O_1 N_0 B_2 G_5 
Stack 15
K_4 G_1 D_3 G_7 M_0 
Stack 16
I_2 B_0 I_6 K_5 I_0 
Stack 17
J_7 A_2 C_2 L_1 M_2 
Stack 18
E_0 J_5 F_7 B_1 F_5 
