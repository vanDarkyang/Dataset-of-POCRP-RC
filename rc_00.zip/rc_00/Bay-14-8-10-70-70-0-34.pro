Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_1 F_2 F_5 G_7 A_4 
Stack 2
E_0 G_3 B_2 C_3 B_5 
Stack 3
D_4 E_5 A_2 E_2 G_4 
Stack 4
G_2 A_1 G_0 G_1 D_5 
Stack 5
A_0 F_7 F_1 H_4 C_2 
Stack 6
F_4 F_8 D_3 B_3 D_7 
Stack 7
C_0 E_6 G_6 H_3 E_1 
Stack 8
C_6 C_4 B_1 C_1 J_3 
Stack 9
D_0 I_0 D_2 D_6 H_0 
Stack 10
G_5 J_0 B_4 F_3 F_0 
Stack 11
F_6 E_8 I_2 H_1 I_4 
Stack 12
E_4 C_5 E_7 D_1 I_5 
Stack 13
A_3 I_3 H_6 J_4 B_0 
Stack 14
J_2 E_3 I_1 H_2 H_5 
