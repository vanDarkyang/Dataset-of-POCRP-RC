Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_5 A_5 B_5 C_1 
Stack 2
E_2 A_6 D_4 E_8 
Stack 3
B_7 B_1 C_10 D_1 
Stack 4
C_2 D_9 B_2 B_0 
Stack 5
C_9 E_7 A_0 B_8 
Stack 6
D_2 C_11 A_1 A_4 
Stack 7
B_3 D_5 B_9 A_2 
Stack 8
E_4 E_0 C_0 E_6 
Stack 9
D_8 A_8 D_3 C_8 
Stack 10
D_0 E_9 E_3 C_6 
Stack 11
C_4 A_3 C_5 B_4 
Stack 12
E_1 B_10 C_7 C_3 
Stack 13
D_10 D_7 D_6 
Stack 14
B_6 A_9 A_7 
