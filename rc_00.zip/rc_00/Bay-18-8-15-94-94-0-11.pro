Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_0 D_2 J_4 H_3 M_1 E_1 
Stack 2
I_3 N_1 J_5 G_1 K_4 I_5 
Stack 3
C_0 J_7 E_6 I_4 H_5 I_1 
Stack 4
K_1 G_8 C_1 M_3 K_6 J_3 
Stack 5
D_5 F_1 J_0 I_8 E_3 
Stack 6
H_4 D_3 K_3 M_4 I_7 
Stack 7
C_4 G_5 G_0 O_0 K_2 
Stack 8
N_3 D_4 I_2 H_7 C_2 
Stack 9
K_5 N_0 O_1 L_3 H_0 
Stack 10
E_0 L_2 B_0 A_1 L_5 
Stack 11
B_2 G_3 I_0 D_0 H_2 
Stack 12
F_6 J_1 B_3 N_2 A_2 
Stack 13
G_7 J_6 A_0 O_2 F_7 
Stack 14
H_6 F_5 F_4 H_8 G_2 
Stack 15
D_1 G_6 F_3 G_4 I_6 
Stack 16
E_4 L_1 H_1 M_0 F_0 
Stack 17
H_9 E_2 M_2 B_1 L_0 
Stack 18
F_2 L_4 E_5 J_2 C_3 
