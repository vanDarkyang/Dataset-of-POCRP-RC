Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_0 G_5 K_3 M_4 
Stack 2
B_0 H_7 C_1 E_4 
Stack 3
L_1 F_6 B_3 J_0 
Stack 4
H_6 H_3 I_8 D_1 
Stack 5
N_3 L_0 N_0 E_1 
Stack 6
O_2 I_6 C_0 C_3 
Stack 7
L_2 E_2 K_1 L_4 
Stack 8
J_1 I_2 E_6 A_2 
Stack 9
E_0 E_3 H_2 G_6 
Stack 10
N_1 M_3 I_7 M_1 
Stack 11
K_4 D_5 M_0 L_5 
Stack 12
D_2 F_5 G_7 F_3 
Stack 13
I_0 E_5 C_2 D_3 
Stack 14
I_1 J_4 J_6 J_3 
Stack 15
D_4 F_1 J_5 G_4 
Stack 16
G_3 O_1 H_9 O_0 
Stack 17
G_2 K_6 J_7 C_4 
Stack 18
H_4 H_1 I_4 I_5 
Stack 19
H_8 L_3 H_0 B_2 
Stack 20
F_7 A_1 H_5 G_0 
Stack 21
J_2 F_2 K_5 G_1 
Stack 22
K_2 D_0 M_2 A_0 
Stack 23
B_1 F_4 N_2 
Stack 24
F_0 G_8 I_3 
