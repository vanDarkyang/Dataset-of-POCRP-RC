Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_13 C_1 B_5 B_7 
Stack 2
B_11 B_9 A_14 A_11 
Stack 3
C_2 A_5 A_6 C_3 
Stack 4
B_6 C_0 C_6 B_4 
Stack 5
C_14 C_5 A_3 A_9 
Stack 6
B_8 B_1 B_15 B_10 
Stack 7
A_12 A_0 B_12 A_8 
Stack 8
B_3 C_8 B_14 C_13 
Stack 9
C_12 A_10 C_11 B_13 
Stack 10
A_1 C_4 A_4 A_2 
Stack 11
C_7 C_9 B_2 
Stack 12
B_0 C_10 A_7 
