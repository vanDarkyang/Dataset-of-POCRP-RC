Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_3 C_10 A_11 A_8 
Stack 2
A_14 A_5 C_13 A_7 
Stack 3
A_2 C_1 B_5 A_6 
Stack 4
A_0 B_4 A_3 B_10 
Stack 5
C_9 C_8 C_4 B_1 
Stack 6
B_9 A_9 A_1 A_13 
Stack 7
B_15 B_8 C_11 C_6 
Stack 8
B_14 C_3 A_12 B_7 
Stack 9
B_2 C_0 B_0 B_6 
Stack 10
A_10 C_2 C_5 B_11 
Stack 11
A_4 B_12 C_7 
Stack 12
C_14 B_13 C_12 
