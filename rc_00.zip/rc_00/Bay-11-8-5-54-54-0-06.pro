Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_1 B_7 A_9 E_6 B_6 
Stack 2
A_2 C_2 A_8 E_0 C_0 
Stack 3
A_7 D_1 B_5 C_6 D_2 
Stack 4
A_6 C_11 B_8 D_0 B_9 
Stack 5
A_0 B_2 C_5 B_1 E_5 
Stack 6
C_1 B_4 E_2 C_7 E_7 
Stack 7
E_8 D_5 D_8 D_7 C_3 
Stack 8
A_4 D_9 D_4 E_9 E_4 
Stack 9
B_3 B_0 A_3 A_1 C_8 
Stack 10
A_5 C_9 D_6 D_3 D_10 
Stack 11
C_10 B_10 C_4 E_3 
