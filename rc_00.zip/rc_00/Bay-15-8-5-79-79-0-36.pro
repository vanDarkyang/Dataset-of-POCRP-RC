Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_11 A_13 B_12 E_8 D_4 D_5 
Stack 2
D_8 B_15 D_14 B_2 E_1 D_13 
Stack 3
D_3 A_5 B_0 B_7 C_6 C_4 
Stack 4
B_9 A_3 A_2 B_13 E_12 C_15 
Stack 5
B_10 A_12 D_6 C_3 E_6 
Stack 6
B_8 B_14 A_0 E_5 D_2 
Stack 7
C_7 A_6 C_10 C_5 A_10 
Stack 8
A_9 A_14 D_15 B_6 D_12 
Stack 9
E_4 A_4 B_4 C_1 E_13 
Stack 10
C_9 C_13 E_10 D_11 D_7 
Stack 11
B_11 B_1 D_0 C_8 A_8 
Stack 12
A_1 C_16 E_9 D_10 E_11 
Stack 13
E_2 A_7 C_0 B_3 C_12 
Stack 14
E_3 D_9 E_14 B_5 D_1 
Stack 15
C_2 E_7 E_0 C_14 C_11 
