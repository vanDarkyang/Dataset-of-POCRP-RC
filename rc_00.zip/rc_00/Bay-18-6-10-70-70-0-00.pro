Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_7 H_2 C_2 H_0 
Stack 2
B_3 D_3 J_3 C_1 
Stack 3
F_1 C_4 C_5 I_0 
Stack 4
F_6 E_2 D_4 D_2 
Stack 5
D_0 E_1 J_2 G_5 
Stack 6
F_2 I_1 F_7 H_3 
Stack 7
I_2 F_0 D_7 A_3 
Stack 8
G_2 A_0 J_4 D_1 
Stack 9
E_4 E_6 G_0 G_1 
Stack 10
H_5 A_2 E_3 C_3 
Stack 11
F_8 D_5 B_4 I_5 
Stack 12
C_6 E_5 J_1 F_4 
Stack 13
H_1 F_3 A_1 G_6 
Stack 14
G_4 B_0 F_5 G_7 
Stack 15
J_0 I_3 B_5 G_3 
Stack 16
H_4 C_0 D_6 I_4 
Stack 17
B_1 E_8 H_6 
Stack 18
E_0 A_4 B_2 
