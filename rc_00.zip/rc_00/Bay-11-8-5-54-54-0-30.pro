Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_4 A_4 C_2 D_2 E_4 
Stack 2
A_3 B_2 D_6 D_1 B_3 
Stack 3
C_10 A_5 B_7 E_7 D_3 
Stack 4
D_7 B_1 C_0 B_6 A_2 
Stack 5
B_9 C_3 C_7 C_4 D_10 
Stack 6
A_1 A_0 B_0 A_7 A_9 
Stack 7
E_2 E_0 C_11 D_9 C_5 
Stack 8
C_6 B_10 D_8 C_8 E_5 
Stack 9
D_4 B_8 C_9 D_5 D_0 
Stack 10
E_6 E_1 A_8 E_8 E_9 
Stack 11
B_5 A_6 C_1 E_3 
