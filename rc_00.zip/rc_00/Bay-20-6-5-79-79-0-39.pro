Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_4 B_10 B_9 C_3 
Stack 2
A_13 A_7 B_1 E_1 
Stack 3
D_4 D_10 D_6 B_0 
Stack 4
C_2 A_1 C_16 C_9 
Stack 5
D_5 B_2 C_1 B_7 
Stack 6
D_2 A_6 D_11 E_12 
Stack 7
D_3 A_3 A_5 B_14 
Stack 8
C_11 E_8 A_0 D_14 
Stack 9
B_5 A_12 C_15 E_11 
Stack 10
D_0 E_10 E_7 C_8 
Stack 11
A_8 A_14 A_2 B_8 
Stack 12
E_9 A_10 A_9 E_6 
Stack 13
B_6 D_15 D_9 B_15 
Stack 14
E_4 C_10 C_7 B_4 
Stack 15
A_4 E_14 C_12 B_3 
Stack 16
D_13 C_0 D_1 A_11 
Stack 17
B_12 C_13 D_7 D_8 
Stack 18
D_12 E_2 B_11 E_13 
Stack 19
C_14 E_0 C_6 E_5 
Stack 20
B_13 E_3 C_5 
