Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 G_2 H_4 B_0 
Stack 2
F_8 I_3 H_3 A_4 
Stack 3
E_5 E_0 E_4 A_2 
Stack 4
D_0 D_1 B_4 I_5 
Stack 5
E_1 F_5 D_6 E_8 
Stack 6
H_2 D_2 E_2 F_3 
Stack 7
B_2 J_4 J_3 H_1 
Stack 8
B_3 I_1 J_1 G_6 
Stack 9
G_5 F_6 E_7 G_3 
Stack 10
G_0 F_4 H_5 C_5 
Stack 11
G_7 A_3 F_1 I_4 
Stack 12
I_2 C_0 F_0 C_1 
Stack 13
F_7 J_2 B_1 D_7 
Stack 14
A_1 H_6 E_3 F_2 
Stack 15
G_1 D_5 J_0 C_4 
Stack 16
A_0 D_3 D_4 E_6 
Stack 17
B_5 C_3 C_6 
Stack 18
H_0 G_4 I_0 
