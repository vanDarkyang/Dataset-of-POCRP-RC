Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_4 G_0 I_5 E_3 
Stack 2
G_7 F_1 J_5 J_0 
Stack 3
E_0 I_1 G_5 H_1 
Stack 4
J_6 K_3 L_4 L_2 
Stack 5
D_0 L_5 I_6 G_1 
Stack 6
I_2 H_2 K_5 F_2 
Stack 7
E_5 G_6 D_2 K_2 
Stack 8
G_4 H_5 D_5 J_4 
Stack 9
K_0 H_6 C_2 D_3 
Stack 10
H_9 O_1 E_4 J_2 
Stack 11
L_3 C_1 J_7 N_0 
Stack 12
N_2 K_6 F_3 C_4 
Stack 13
I_8 I_0 D_4 H_7 
Stack 14
F_5 I_3 O_0 A_0 
Stack 15
N_3 M_2 A_2 H_8 
Stack 16
B_1 J_3 G_8 O_2 
Stack 17
M_3 E_2 H_0 I_7 
Stack 18
A_1 M_4 F_6 B_0 
Stack 19
H_3 H_4 E_6 G_2 
Stack 20
L_0 B_3 G_3 D_1 
Stack 21
F_4 L_1 K_1 C_0 
Stack 22
M_1 E_1 K_4 M_0 
Stack 23
F_7 N_1 J_1 
Stack 24
F_0 C_3 B_2 
