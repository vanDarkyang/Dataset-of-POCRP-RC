Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_12 B_14 C_10 C_11 
Stack 2
B_4 B_0 B_15 A_0 
Stack 3
A_9 C_0 A_11 A_13 
Stack 4
B_3 C_2 C_8 B_12 
Stack 5
C_4 B_2 C_14 A_1 
Stack 6
B_9 B_5 C_9 A_8 
Stack 7
B_6 A_7 C_1 B_1 
Stack 8
A_14 C_6 B_10 B_8 
Stack 9
A_10 A_2 C_13 B_7 
Stack 10
A_6 C_7 B_11 B_13 
Stack 11
C_12 C_5 A_3 
Stack 12
A_5 A_4 C_3 
