Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_4 F_6 B_5 I_3 
Stack 2
C_4 B_0 E_6 H_4 
Stack 3
H_5 D_6 I_5 H_6 
Stack 4
G_7 G_2 I_1 H_1 
Stack 5
C_5 F_2 A_3 G_6 
Stack 6
E_5 F_3 G_1 B_2 
Stack 7
A_2 F_1 A_1 E_4 
Stack 8
E_7 G_0 D_4 F_4 
Stack 9
C_0 B_3 E_3 E_2 
Stack 10
I_4 I_2 C_3 D_1 
Stack 11
C_6 H_3 H_2 J_2 
Stack 12
C_1 G_5 G_3 F_5 
Stack 13
J_0 D_0 A_4 E_0 
Stack 14
D_5 C_2 E_8 B_4 
Stack 15
F_8 G_4 D_3 I_0 
Stack 16
F_0 J_3 J_1 D_2 
Stack 17
A_0 E_1 D_7 
Stack 18
H_0 B_1 F_7 
