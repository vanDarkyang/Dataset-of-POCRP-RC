Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 C_0 C_6 C_9 C_1 A_5 
Stack 2
A_7 D_2 D_1 E_11 A_0 B_9 
Stack 3
C_15 B_12 C_5 E_5 C_12 A_3 
Stack 4
A_9 E_0 C_14 D_5 B_15 B_13 
Stack 5
B_11 B_3 D_11 D_13 D_4 
Stack 6
B_1 C_7 A_10 E_3 A_8 
Stack 7
A_2 D_14 D_3 E_6 E_8 
Stack 8
B_2 C_2 B_6 D_12 E_4 
Stack 9
B_0 C_4 D_15 E_7 A_14 
Stack 10
D_9 D_0 B_10 C_3 A_4 
Stack 11
B_5 E_12 B_14 D_8 E_13 
Stack 12
D_6 C_16 E_1 E_10 A_13 
Stack 13
C_11 C_8 D_7 A_12 C_10 
Stack 14
E_14 D_10 B_4 A_11 C_13 
Stack 15
A_6 B_8 B_7 E_2 E_9 
