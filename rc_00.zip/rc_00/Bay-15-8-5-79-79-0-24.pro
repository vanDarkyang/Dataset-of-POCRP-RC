Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_15 E_3 C_9 C_2 C_16 E_14 
Stack 2
C_7 C_3 E_5 C_13 D_10 E_8 
Stack 3
A_4 B_12 B_11 C_0 A_12 C_11 
Stack 4
D_5 E_9 D_6 A_5 D_3 D_12 
Stack 5
C_8 D_2 B_7 A_11 D_9 
Stack 6
E_4 E_0 C_4 B_6 A_0 
Stack 7
B_14 D_8 A_3 C_5 D_13 
Stack 8
E_2 D_11 B_8 D_15 C_12 
Stack 9
A_9 B_9 E_6 E_1 E_7 
Stack 10
D_4 C_10 B_5 B_0 A_2 
Stack 11
B_10 C_6 C_1 A_13 E_13 
Stack 12
B_4 A_1 B_2 D_14 E_10 
Stack 13
A_6 A_10 A_7 E_11 B_3 
Stack 14
C_14 B_15 B_13 A_14 D_7 
Stack 15
E_12 B_1 D_1 D_0 A_8 
