Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_11 B_11 C_16 C_15 
Stack 2
C_5 E_7 B_10 D_9 
Stack 3
E_10 E_0 C_13 A_2 
Stack 4
D_2 A_9 C_10 E_12 
Stack 5
B_3 C_9 E_3 C_4 
Stack 6
A_4 D_8 C_2 A_14 
Stack 7
D_12 D_13 D_15 D_1 
Stack 8
B_6 D_14 D_3 E_9 
Stack 9
D_11 B_14 E_11 C_3 
Stack 10
A_13 E_14 B_9 C_14 
Stack 11
D_10 A_10 A_7 B_4 
Stack 12
C_1 A_6 C_8 E_1 
Stack 13
A_11 E_13 B_7 E_6 
Stack 14
A_0 C_6 B_0 B_2 
Stack 15
D_6 E_2 B_5 D_0 
Stack 16
A_12 B_1 C_7 B_13 
Stack 17
E_5 A_1 B_8 E_8 
Stack 18
A_5 D_7 C_0 A_8 
Stack 19
B_12 A_3 D_4 D_5 
Stack 20
C_12 B_15 E_4 
