Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 C_5 H_0 J_3 F_0 
Stack 2
D_0 D_1 E_0 C_6 I_2 
Stack 3
A_1 B_3 G_1 E_7 D_7 
Stack 4
D_6 E_1 G_6 J_0 I_5 
Stack 5
G_7 E_4 A_2 E_6 H_1 
Stack 6
F_6 F_5 A_3 H_2 B_2 
Stack 7
G_3 F_2 J_2 E_3 A_4 
Stack 8
F_8 G_0 I_4 D_3 I_1 
Stack 9
B_0 F_1 B_1 E_5 F_3 
Stack 10
F_4 B_5 C_0 E_8 I_3 
Stack 11
C_4 B_4 D_2 H_6 D_5 
Stack 12
G_5 D_4 I_0 H_4 H_5 
Stack 13
C_1 G_4 E_2 J_1 A_0 
Stack 14
H_3 F_7 C_3 J_4 G_2 
