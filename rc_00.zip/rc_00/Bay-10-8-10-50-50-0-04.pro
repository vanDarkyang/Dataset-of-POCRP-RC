Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_6 B_2 C_1 H_4 A_0 
Stack 2
F_4 H_3 E_5 E_0 E_6 
Stack 3
C_4 G_4 B_3 I_0 B_1 
Stack 4
G_0 E_1 G_3 I_1 D_5 
Stack 5
A_1 C_0 H_1 D_3 B_0 
Stack 6
G_2 F_2 D_4 D_0 J_1 
Stack 7
H_0 F_0 D_1 E_4 I_2 
Stack 8
J_0 I_3 E_2 G_5 A_2 
Stack 9
C_3 F_5 E_3 J_2 C_2 
Stack 10
F_1 G_1 D_2 H_2 F_3 
