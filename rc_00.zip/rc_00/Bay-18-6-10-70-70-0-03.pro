Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_0 E_4 I_3 A_2 
Stack 2
A_4 H_1 C_0 I_1 
Stack 3
A_3 F_1 F_5 E_3 
Stack 4
D_1 E_6 B_0 H_2 
Stack 5
G_2 F_8 G_3 I_0 
Stack 6
C_4 D_2 C_1 I_5 
Stack 7
C_2 B_4 E_8 H_6 
Stack 8
D_7 C_3 F_7 G_5 
Stack 9
D_5 F_0 F_4 H_0 
Stack 10
E_5 F_6 F_2 B_2 
Stack 11
J_4 D_4 B_1 D_0 
Stack 12
E_7 E_1 G_4 G_6 
Stack 13
I_4 E_0 B_5 H_3 
Stack 14
I_2 C_5 J_2 D_3 
Stack 15
A_0 G_7 F_3 A_1 
Stack 16
J_3 B_3 C_6 D_6 
Stack 17
J_1 H_4 J_0 
Stack 18
H_5 G_1 E_2 
