Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_5 A_2 A_6 C_1 
Stack 2
A_4 B_13 A_5 B_9 
Stack 3
A_12 B_10 C_8 C_2 
Stack 4
A_13 C_3 C_13 A_10 
Stack 5
C_4 A_14 A_11 C_11 
Stack 6
A_3 B_2 B_8 B_3 
Stack 7
B_1 A_0 B_4 C_7 
Stack 8
C_5 B_14 C_12 C_10 
Stack 9
A_9 C_14 B_12 B_7 
Stack 10
C_6 B_15 B_0 C_9 
Stack 11
C_0 A_1 B_11 
Stack 12
B_6 A_7 A_8 
