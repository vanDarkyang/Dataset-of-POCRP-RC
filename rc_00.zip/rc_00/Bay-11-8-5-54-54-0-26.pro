Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_8 A_8 C_7 A_6 A_5 
Stack 2
A_0 D_9 E_9 B_7 C_3 
Stack 3
C_10 C_0 E_3 C_6 B_9 
Stack 4
C_8 E_0 E_6 B_0 B_1 
Stack 5
B_6 B_10 D_2 E_5 E_1 
Stack 6
A_7 A_9 E_4 C_11 E_7 
Stack 7
B_5 D_10 E_2 A_2 C_4 
Stack 8
A_1 D_1 E_8 C_1 D_3 
Stack 9
D_8 B_2 C_2 B_3 C_5 
Stack 10
C_9 A_4 D_0 B_4 D_5 
Stack 11
A_3 D_6 D_4 D_7 
