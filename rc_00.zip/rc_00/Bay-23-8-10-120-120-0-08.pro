Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_10 H_3 C_2 D_5 B_2 J_7 
Stack 2
B_1 G_3 B_0 H_0 A_2 I_2 
Stack 3
G_2 E_2 E_3 G_7 J_1 F_1 
Stack 4
D_12 E_12 A_3 I_9 G_4 A_7 
Stack 5
D_1 I_10 C_11 H_9 B_10 G_10 
Stack 6
C_7 F_4 J_8 H_11 I_6 
Stack 7
A_8 H_10 F_12 F_6 B_9 
Stack 8
J_4 D_10 A_5 I_1 H_5 
Stack 9
J_0 H_8 E_5 D_0 C_0 
Stack 10
C_8 J_5 E_6 B_6 B_8 
Stack 11
I_0 H_4 J_9 B_4 C_6 
Stack 12
F_7 J_2 J_3 D_6 E_9 
Stack 13
I_8 J_6 E_11 D_3 I_7 
Stack 14
F_3 B_3 F_5 A_6 B_5 
Stack 15
F_13 D_9 G_6 E_13 D_2 
Stack 16
G_8 C_5 D_4 C_4 G_9 
Stack 17
A_1 D_11 H_7 E_1 F_9 
Stack 18
G_5 G_0 C_3 G_11 C_9 
Stack 19
F_8 A_4 H_6 I_3 E_10 
Stack 20
E_8 I_4 E_4 F_11 E_7 
Stack 21
C_1 G_12 E_0 D_8 I_5 
Stack 22
F_0 D_7 H_2 A_0 G_1 
Stack 23
A_9 H_1 B_7 F_2 C_10 
