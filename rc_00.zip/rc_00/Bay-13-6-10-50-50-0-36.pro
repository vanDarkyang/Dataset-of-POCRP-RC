Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_1 F_1 E_5 J_0 
Stack 2
B_2 J_2 D_2 H_2 
Stack 3
G_3 I_0 I_2 F_5 
Stack 4
D_1 C_0 A_1 G_4 
Stack 5
F_0 B_3 J_1 H_0 
Stack 6
C_4 F_4 D_4 E_4 
Stack 7
G_1 E_3 E_1 D_5 
Stack 8
H_4 H_3 C_3 G_2 
Stack 9
C_2 F_6 G_0 B_1 
Stack 10
G_5 E_2 A_0 F_3 
Stack 11
B_0 I_3 E_6 E_0 
Stack 12
I_1 F_2 H_1 
Stack 13
D_0 D_3 A_2 
