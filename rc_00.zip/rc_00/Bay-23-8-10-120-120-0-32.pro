Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_8 I_0 F_2 J_5 G_9 G_10 
Stack 2
H_1 D_12 C_1 B_7 H_4 B_10 
Stack 3
H_9 A_9 C_2 C_3 I_1 F_10 
Stack 4
J_8 A_1 F_7 D_2 I_5 C_10 
Stack 5
C_7 B_0 E_9 E_6 E_13 A_4 
Stack 6
B_9 E_0 D_8 E_10 F_11 
Stack 7
A_0 I_9 F_4 C_8 A_6 
Stack 8
C_11 I_3 C_4 E_11 I_6 
Stack 9
J_1 G_3 F_5 F_1 H_2 
Stack 10
H_11 B_1 A_8 C_9 D_9 
Stack 11
I_8 D_5 I_7 B_6 F_12 
Stack 12
B_8 D_11 G_7 H_5 E_12 
Stack 13
I_10 G_5 G_4 A_5 C_5 
Stack 14
I_4 J_7 G_6 G_8 J_3 
Stack 15
G_0 D_7 D_6 J_9 G_1 
Stack 16
H_10 J_0 D_4 E_4 E_7 
Stack 17
F_13 H_3 A_2 H_0 C_6 
Stack 18
J_2 B_2 E_3 D_1 G_2 
Stack 19
A_3 H_7 H_6 F_0 D_3 
Stack 20
F_3 J_6 G_12 D_0 E_2 
Stack 21
I_2 B_3 J_4 B_5 B_4 
Stack 22
F_8 C_0 G_11 D_10 F_6 
Stack 23
E_5 E_1 A_7 H_8 F_9 
