Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_2 A_9 D_10 E_1 B_4 B_13 
Stack 2
D_14 A_7 D_9 A_6 B_5 C_5 
Stack 3
A_1 A_14 A_8 C_0 E_14 A_12 
Stack 4
D_11 B_14 C_8 E_0 D_7 A_4 
Stack 5
B_0 B_9 A_2 E_2 D_1 
Stack 6
C_1 E_12 C_7 D_6 E_7 
Stack 7
E_9 C_9 C_15 C_11 D_12 
Stack 8
B_12 C_2 D_8 A_13 C_4 
Stack 9
E_6 D_13 D_4 C_12 D_3 
Stack 10
B_15 D_5 B_10 A_10 E_11 
Stack 11
B_1 A_0 D_2 C_16 A_3 
Stack 12
B_6 C_3 B_7 E_10 C_6 
Stack 13
E_3 E_5 C_14 B_3 B_8 
Stack 14
E_8 D_15 B_11 A_11 E_4 
Stack 15
D_0 C_13 A_5 C_10 E_13 
