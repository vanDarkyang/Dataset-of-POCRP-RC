Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_3 G_5 L_3 N_3 D_0 G_7 
Stack 2
H_5 K_5 L_4 H_3 I_4 M_4 
Stack 3
D_1 G_3 O_2 K_2 K_0 F_2 
Stack 4
H_9 F_7 J_2 L_5 F_1 N_1 
Stack 5
E_3 H_0 B_1 I_6 H_8 
Stack 6
I_3 K_6 H_2 I_5 M_3 
Stack 7
B_3 O_0 I_2 I_1 G_8 
Stack 8
E_0 F_3 C_1 L_1 H_4 
Stack 9
H_7 I_8 O_1 J_1 C_0 
Stack 10
G_4 K_4 N_0 B_2 F_5 
Stack 11
G_1 L_2 K_1 M_2 J_4 
Stack 12
J_6 E_4 I_7 L_0 F_0 
Stack 13
F_6 H_6 B_0 H_1 G_2 
Stack 14
A_2 K_3 C_4 D_4 J_0 
Stack 15
G_0 D_3 E_1 F_4 E_6 
Stack 16
J_5 G_6 J_7 C_3 D_2 
Stack 17
A_0 E_2 E_5 I_0 M_1 
Stack 18
C_2 A_1 D_5 N_2 M_0 
