Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 E_4 E_0 D_0 E_3 
Stack 2
C_4 B_9 D_5 B_4 E_6 
Stack 3
D_10 A_2 A_8 D_3 A_3 
Stack 4
A_6 D_9 A_1 A_9 B_0 
Stack 5
C_11 C_6 A_7 E_5 C_3 
Stack 6
C_9 D_4 B_2 A_4 E_1 
Stack 7
B_5 C_7 C_0 E_2 E_7 
Stack 8
B_3 A_0 E_8 B_7 C_10 
Stack 9
B_8 D_1 D_2 B_6 D_8 
Stack 10
B_10 C_5 D_6 E_9 C_8 
Stack 11
C_1 C_2 D_7 A_5 
