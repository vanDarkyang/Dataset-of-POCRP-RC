Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_4 G_1 B_0 I_2 
Stack 2
E_2 B_2 H_4 J_0 
Stack 3
G_2 C_4 H_1 E_1 
Stack 4
G_3 A_2 C_2 D_2 
Stack 5
E_0 D_1 H_2 H_0 
Stack 6
F_6 G_4 F_0 A_1 
Stack 7
I_1 B_3 B_1 H_3 
Stack 8
I_0 G_0 G_5 E_3 
Stack 9
F_5 D_0 C_3 F_3 
Stack 10
D_4 D_5 J_2 C_0 
Stack 11
I_3 C_1 F_2 J_1 
Stack 12
E_5 A_0 F_4 
Stack 13
F_1 E_6 D_3 
