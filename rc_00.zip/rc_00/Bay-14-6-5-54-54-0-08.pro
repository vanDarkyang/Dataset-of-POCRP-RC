Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_4 D_10 D_8 E_5 
Stack 2
A_9 E_9 C_6 B_10 
Stack 3
B_0 A_0 E_0 E_8 
Stack 4
B_9 D_4 D_9 D_7 
Stack 5
A_4 D_5 D_2 C_7 
Stack 6
C_9 C_4 B_1 E_4 
Stack 7
A_8 E_2 A_3 B_7 
Stack 8
C_8 C_5 D_3 B_5 
Stack 9
A_6 C_2 C_0 E_7 
Stack 10
B_6 C_10 A_7 B_8 
Stack 11
D_1 C_1 A_5 D_6 
Stack 12
B_2 C_3 E_1 A_2 
Stack 13
B_3 A_1 E_6 
Stack 14
D_0 C_11 E_3 
