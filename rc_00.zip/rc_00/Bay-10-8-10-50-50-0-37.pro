Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_0 E_1 G_4 J_2 F_5 
Stack 2
H_2 D_0 G_0 F_2 A_2 
Stack 3
D_2 C_2 B_2 F_4 F_3 
Stack 4
D_4 C_3 A_1 F_0 B_1 
Stack 5
I_1 F_1 B_0 C_4 E_0 
Stack 6
E_4 D_3 C_0 G_2 D_1 
Stack 7
F_6 E_6 H_4 H_1 J_1 
Stack 8
I_3 C_1 H_0 D_5 I_2 
Stack 9
H_3 I_0 G_5 B_3 J_0 
Stack 10
E_5 G_3 E_3 G_1 E_2 
