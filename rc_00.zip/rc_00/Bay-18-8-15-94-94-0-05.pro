Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_7 J_2 C_1 F_3 B_1 N_0 
Stack 2
K_2 O_2 H_0 C_3 J_6 G_0 
Stack 3
I_7 D_3 H_9 A_1 B_3 C_0 
Stack 4
O_1 J_3 I_2 B_0 F_0 E_4 
Stack 5
H_8 C_4 I_5 L_5 K_5 
Stack 6
A_2 O_0 M_0 N_1 K_3 
Stack 7
D_4 M_3 H_5 K_6 H_6 
Stack 8
N_2 G_6 G_4 M_1 G_2 
Stack 9
G_8 E_5 N_3 H_1 J_4 
Stack 10
H_7 H_4 L_4 F_4 H_2 
Stack 11
F_6 D_5 K_4 L_3 L_1 
Stack 12
C_2 I_8 J_5 F_2 D_1 
Stack 13
I_6 G_5 I_0 K_1 L_0 
Stack 14
F_1 E_6 J_0 J_7 E_0 
Stack 15
E_1 D_0 I_1 B_2 A_0 
Stack 16
I_3 G_7 K_0 I_4 J_1 
Stack 17
E_2 G_3 F_5 H_3 L_2 
Stack 18
E_3 M_4 M_2 G_1 D_2 
