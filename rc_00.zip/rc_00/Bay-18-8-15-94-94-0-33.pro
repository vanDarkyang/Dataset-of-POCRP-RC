Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
N_3 L_0 K_2 C_0 N_2 F_3 
Stack 2
K_3 H_7 I_5 M_2 E_5 A_2 
Stack 3
L_2 B_1 O_2 G_1 M_0 F_2 
Stack 4
J_4 J_1 D_4 H_0 I_8 L_3 
Stack 5
E_6 B_2 J_3 J_5 E_2 
Stack 6
G_2 E_1 F_7 L_1 M_1 
Stack 7
E_3 I_1 F_6 H_2 H_5 
Stack 8
O_0 J_6 F_5 K_1 N_0 
Stack 9
C_3 K_4 A_0 E_0 F_1 
Stack 10
C_4 M_4 A_1 J_0 O_1 
Stack 11
L_4 N_1 G_6 I_4 H_6 
Stack 12
G_4 G_7 F_0 I_3 H_4 
Stack 13
I_7 I_0 J_2 D_2 H_3 
Stack 14
G_3 D_0 E_4 G_0 G_5 
Stack 15
H_9 H_1 J_7 L_5 B_0 
Stack 16
B_3 I_2 H_8 C_2 D_3 
Stack 17
K_5 M_3 G_8 D_5 C_1 
Stack 18
D_1 F_4 I_6 K_0 K_6 
