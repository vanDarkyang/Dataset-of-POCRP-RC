Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 E_5 A_0 A_2 
Stack 2
D_0 A_1 G_2 H_4 
Stack 3
H_0 E_0 F_4 E_4 
Stack 4
F_3 I_2 J_0 D_5 
Stack 5
C_0 G_0 C_3 I_3 
Stack 6
C_4 C_2 G_5 G_3 
Stack 7
D_3 J_1 H_2 J_2 
Stack 8
E_6 E_1 I_0 C_1 
Stack 9
G_4 F_1 E_3 I_1 
Stack 10
B_0 B_2 B_3 G_1 
Stack 11
F_0 D_2 B_1 F_5 
Stack 12
E_2 F_2 H_1 
Stack 13
D_4 H_3 F_6 
