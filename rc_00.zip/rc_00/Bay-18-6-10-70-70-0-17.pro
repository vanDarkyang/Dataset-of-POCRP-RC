Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 E_4 B_1 J_1 
Stack 2
D_0 F_5 C_0 J_4 
Stack 3
A_1 F_2 D_2 F_0 
Stack 4
D_6 G_0 I_0 I_2 
Stack 5
G_7 F_1 E_2 D_7 
Stack 6
F_6 B_5 C_3 I_5 
Stack 7
G_3 B_4 J_3 H_1 
Stack 8
F_8 D_4 C_6 B_2 
Stack 9
B_0 G_4 E_7 A_4 
Stack 10
F_4 F_7 J_0 I_1 
Stack 11
C_4 H_0 E_6 F_3 
Stack 12
G_5 E_0 H_2 I_3 
Stack 13
C_1 G_1 E_3 D_5 
Stack 14
H_3 G_6 D_3 H_5 
Stack 15
C_5 A_2 E_5 A_0 
Stack 16
D_1 A_3 E_8 G_2 
Stack 17
B_3 J_2 H_6 
Stack 18
E_1 I_4 H_4 
