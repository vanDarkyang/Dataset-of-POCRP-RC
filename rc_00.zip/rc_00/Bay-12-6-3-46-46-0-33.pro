Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 B_1 B_11 A_11 
Stack 2
B_5 C_0 C_1 C_6 
Stack 3
A_8 B_14 B_3 C_13 
Stack 4
B_10 B_6 C_4 C_14 
Stack 5
A_3 C_12 C_2 A_13 
Stack 6
B_2 A_9 C_11 B_13 
Stack 7
C_5 B_8 C_3 B_9 
Stack 8
B_4 A_2 B_15 C_8 
Stack 9
A_4 A_0 A_5 A_10 
Stack 10
C_10 A_14 A_12 A_7 
Stack 11
C_9 B_12 B_7 
Stack 12
B_0 C_7 A_6 
