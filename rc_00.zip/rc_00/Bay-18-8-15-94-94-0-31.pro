Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_2 F_4 D_0 E_3 M_4 A_2 
Stack 2
L_4 B_3 H_4 I_4 G_7 M_0 
Stack 3
N_2 M_3 G_3 J_1 H_6 O_0 
Stack 4
G_6 H_0 A_0 L_5 K_3 N_1 
Stack 5
C_1 I_7 I_5 E_2 F_5 
Stack 6
D_1 C_3 I_3 G_2 K_0 
Stack 7
G_8 H_5 L_0 A_1 H_7 
Stack 8
J_3 D_5 J_2 J_7 M_2 
Stack 9
I_6 H_8 J_5 O_2 I_0 
Stack 10
F_1 K_5 D_2 J_4 L_1 
Stack 11
G_0 K_1 L_3 D_3 C_4 
Stack 12
I_2 H_2 H_9 F_3 N_0 
Stack 13
E_6 E_0 J_6 B_1 C_2 
Stack 14
E_4 K_4 D_4 L_2 C_0 
Stack 15
F_7 I_8 J_0 H_3 O_1 
Stack 16
K_6 B_2 B_0 G_4 M_1 
Stack 17
F_6 F_0 N_3 E_1 F_2 
Stack 18
I_1 G_1 G_5 E_5 H_1 
