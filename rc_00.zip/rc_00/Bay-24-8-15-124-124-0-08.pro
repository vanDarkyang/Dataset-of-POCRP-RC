Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_5 C_6 K_4 I_2 F_5 J_9 
Stack 2
C_4 H_1 B_3 B_2 L_3 O_4 
Stack 3
M_4 H_11 N_0 K_3 G_5 G_3 
Stack 4
I_1 A_1 F_8 H_0 N_3 F_2 
Stack 5
I_10 K_8 I_8 K_7 E_3 
Stack 6
M_6 H_2 D_7 K_0 L_6 
Stack 7
B_4 B_1 H_10 M_5 J_4 
Stack 8
C_0 G_10 D_0 M_2 O_2 
Stack 9
C_5 F_6 I_4 F_4 B_5 
Stack 10
I_0 G_4 I_3 D_5 E_6 
Stack 11
L_4 D_4 C_3 G_9 I_9 
Stack 12
D_6 B_0 I_5 K_6 H_8 
Stack 13
M_1 N_2 J_5 G_1 L_2 
Stack 14
E_2 H_5 O_3 J_8 I_7 
Stack 15
F_7 J_7 H_6 L_5 H_4 
Stack 16
J_2 K_5 A_3 E_4 H_7 
Stack 17
D_1 A_2 H_3 E_8 O_1 
Stack 18
G_8 J_1 E_0 L_7 F_9 
Stack 19
G_7 N_4 K_1 F_3 I_6 
Stack 20
G_2 M_3 K_2 D_3 G_0 
Stack 21
H_9 J_0 E_7 O_0 G_6 
Stack 22
A_0 J_6 C_2 E_1 L_0 
Stack 23
F_0 M_0 L_1 A_4 N_5 
Stack 24
J_3 N_1 C_1 D_2 F_1 
