Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_3 A_9 I_1 E_6 E_12 B_8 
Stack 2
C_8 G_6 H_9 H_2 F_6 D_12 
Stack 3
I_9 B_4 G_4 D_7 G_8 G_2 
Stack 4
G_10 D_10 C_2 H_3 A_6 D_3 
Stack 5
A_2 A_1 I_6 B_1 G_1 A_5 
Stack 6
C_1 B_10 F_7 B_6 I_7 
Stack 7
J_9 G_11 B_9 J_2 B_7 
Stack 8
I_4 F_10 G_9 H_6 H_8 
Stack 9
E_8 C_7 I_5 H_4 H_11 
Stack 10
B_5 H_1 D_8 J_0 A_8 
Stack 11
F_4 E_13 F_0 E_11 J_3 
Stack 12
G_0 I_2 C_4 H_7 D_5 
Stack 13
E_0 E_1 A_3 H_10 A_4 
Stack 14
E_9 I_0 J_4 F_2 C_6 
Stack 15
D_9 E_3 I_3 C_5 G_7 
Stack 16
D_1 E_4 B_2 D_6 I_10 
Stack 17
J_6 I_8 D_2 C_11 D_4 
Stack 18
A_0 J_7 C_9 E_2 G_12 
Stack 19
F_12 D_0 F_5 F_8 B_3 
Stack 20
H_0 B_0 C_10 G_5 E_10 
Stack 21
E_7 A_7 C_3 D_11 E_5 
Stack 22
J_5 J_8 F_11 F_9 F_3 
Stack 23
J_1 H_5 C_0 F_1 F_13 
