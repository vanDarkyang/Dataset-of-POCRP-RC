Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 G_5 F_5 H_4 
Stack 2
E_2 D_4 F_0 I_1 
Stack 3
F_1 I_0 G_4 D_0 
Stack 4
E_3 F_6 E_4 H_2 
Stack 5
C_2 B_1 H_1 D_2 
Stack 6
C_4 D_5 A_0 J_0 
Stack 7
B_3 A_2 E_0 F_4 
Stack 8
C_0 C_1 H_3 I_3 
Stack 9
F_3 G_3 G_2 D_1 
Stack 10
H_0 I_2 F_2 G_0 
Stack 11
J_2 E_5 E_1 J_1 
Stack 12
B_2 C_3 D_3 
Stack 13
G_1 B_0 E_6 
