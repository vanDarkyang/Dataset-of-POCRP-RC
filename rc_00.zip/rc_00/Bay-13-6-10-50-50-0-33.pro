Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_6 F_6 H_1 E_5 
Stack 2
J_1 I_3 H_0 E_4 
Stack 3
F_4 G_4 F_5 A_2 
Stack 4
D_1 D_5 D_4 C_0 
Stack 5
E_0 D_0 H_4 F_0 
Stack 6
C_4 B_1 E_3 D_2 
Stack 7
F_1 E_1 J_0 C_2 
Stack 8
C_1 I_0 G_3 G_0 
Stack 9
C_3 A_0 F_3 G_1 
Stack 10
J_2 B_2 H_3 B_0 
Stack 11
F_2 B_3 H_2 D_3 
Stack 12
G_5 G_2 E_2 
Stack 13
A_1 I_2 I_1 
