Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 C_6 B_0 A_9 E_5 
Stack 2
D_4 D_1 D_10 D_2 D_3 
Stack 3
E_6 B_7 A_5 A_7 C_5 
Stack 4
C_11 D_6 D_5 A_3 B_4 
Stack 5
C_9 C_8 C_4 C_10 C_1 
Stack 6
B_10 A_2 D_9 E_2 B_9 
Stack 7
C_7 E_8 D_7 E_7 B_5 
Stack 8
A_8 B_2 C_3 E_3 A_4 
Stack 9
E_9 D_0 B_3 C_2 A_0 
Stack 10
D_8 C_0 B_1 E_1 B_6 
Stack 11
E_4 A_6 E_0 B_8 
