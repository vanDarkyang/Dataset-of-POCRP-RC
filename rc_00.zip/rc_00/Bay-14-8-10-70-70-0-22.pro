Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_0 C_6 J_0 I_3 B_2 
Stack 2
D_5 J_3 G_5 A_4 E_6 
Stack 3
F_7 C_2 C_3 B_1 G_4 
Stack 4
J_1 H_1 E_0 I_4 C_0 
Stack 5
F_0 D_3 H_0 G_6 C_4 
Stack 6
F_6 E_1 B_3 D_2 E_8 
Stack 7
D_4 F_3 B_4 A_2 E_2 
Stack 8
F_8 H_3 H_4 D_6 C_5 
Stack 9
B_5 D_7 I_2 G_7 J_4 
Stack 10
E_4 J_2 H_5 H_6 I_5 
Stack 11
E_3 H_2 F_5 F_2 A_0 
Stack 12
G_3 D_0 B_0 G_1 E_5 
Stack 13
A_3 E_7 C_1 F_4 I_0 
Stack 14
I_1 F_1 G_2 A_1 D_1 
