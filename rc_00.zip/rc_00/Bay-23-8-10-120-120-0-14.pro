Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_3 C_9 C_8 B_8 I_0 G_8 
Stack 2
B_2 E_2 E_11 C_5 H_11 E_8 
Stack 3
D_9 F_2 B_4 D_6 D_7 I_5 
Stack 4
H_8 F_10 F_9 A_0 I_4 J_6 
Stack 5
I_6 F_3 H_2 A_4 I_7 C_2 
Stack 6
J_9 G_9 J_2 H_10 D_12 
Stack 7
E_7 E_3 H_6 B_6 F_5 
Stack 8
J_0 H_3 G_6 G_10 F_7 
Stack 9
E_0 E_5 C_3 C_11 J_5 
Stack 10
I_1 A_9 D_0 B_5 B_9 
Stack 11
F_4 F_13 G_4 B_0 F_1 
Stack 12
E_10 J_4 G_1 H_7 H_5 
Stack 13
E_12 E_1 A_2 H_4 I_8 
Stack 14
G_0 D_10 F_11 I_3 I_10 
Stack 15
F_0 A_6 G_2 E_9 B_3 
Stack 16
H_1 D_11 J_7 F_6 B_7 
Stack 17
H_0 J_1 D_5 A_3 A_7 
Stack 18
C_0 E_6 C_10 G_11 G_7 
Stack 19
G_12 C_7 G_3 E_4 G_5 
Stack 20
A_8 I_9 D_8 A_5 E_13 
Stack 21
J_3 H_9 D_2 B_10 C_4 
Stack 22
F_12 A_1 J_8 D_4 F_8 
Stack 23
I_2 C_1 D_1 C_6 B_1 
