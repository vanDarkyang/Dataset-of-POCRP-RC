Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 C_1 D_3 C_0 A_3 
Stack 2
F_0 G_4 A_4 A_0 I_2 
Stack 3
D_7 H_0 B_4 C_5 B_1 
Stack 4
J_4 E_7 B_3 G_7 H_5 
Stack 5
C_4 D_6 F_3 I_4 I_5 
Stack 6
E_2 F_6 B_2 C_2 C_6 
Stack 7
H_1 B_5 E_6 E_3 I_3 
Stack 8
F_7 G_1 F_8 E_1 A_1 
Stack 9
F_1 B_0 D_4 E_0 I_1 
Stack 10
J_3 E_8 F_4 H_6 G_6 
Stack 11
J_2 G_5 D_0 I_0 D_5 
Stack 12
A_2 J_0 F_5 H_3 E_4 
Stack 13
E_5 C_3 F_2 G_0 H_4 
Stack 14
J_1 D_2 G_3 H_2 G_2 
