Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
M_4 D_3 N_1 J_5 F_2 J_7 
Stack 2
K_1 J_2 K_2 J_0 A_2 K_6 
Stack 3
N_0 H_7 H_4 M_1 F_7 F_5 
Stack 4
I_8 H_6 I_2 O_0 J_1 G_4 
Stack 5
C_2 J_3 B_2 D_1 M_3 
Stack 6
B_3 F_4 F_0 L_3 A_1 
Stack 7
M_0 G_3 I_1 D_4 H_9 
Stack 8
C_1 L_5 I_3 N_2 L_0 
Stack 9
C_4 G_6 E_4 I_7 L_1 
Stack 10
O_2 C_0 D_0 E_0 G_8 
Stack 11
A_0 H_3 B_0 J_6 E_1 
Stack 12
I_6 K_5 F_6 K_0 O_1 
Stack 13
H_2 G_5 G_1 I_0 N_3 
Stack 14
L_4 I_5 H_1 L_2 E_2 
Stack 15
M_2 E_3 F_3 K_4 G_0 
Stack 16
B_1 J_4 I_4 E_5 G_7 
Stack 17
H_5 F_1 D_5 K_3 H_8 
Stack 18
H_0 E_6 C_3 G_2 D_2 
