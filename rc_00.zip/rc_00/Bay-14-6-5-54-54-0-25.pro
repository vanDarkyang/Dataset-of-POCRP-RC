Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 D_9 C_0 E_9 
Stack 2
C_4 C_6 E_8 A_5 
Stack 3
D_10 D_4 D_2 E_3 
Stack 4
A_6 C_7 D_6 E_6 
Stack 5
C_11 A_0 D_7 A_3 
Stack 6
C_9 D_1 D_0 B_0 
Stack 7
B_5 C_5 B_4 C_3 
Stack 8
B_3 C_2 D_3 E_1 
Stack 9
B_8 E_0 A_9 E_7 
Stack 10
B_10 D_5 E_5 C_10 
Stack 11
C_1 A_8 A_4 D_8 
Stack 12
E_4 A_1 E_2 C_8 
Stack 13
B_9 A_7 B_7 
Stack 14
A_2 B_2 B_6 
