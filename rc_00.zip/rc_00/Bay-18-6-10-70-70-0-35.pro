Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_3 G_0 H_6 B_5 
Stack 2
A_1 F_1 J_0 D_5 
Stack 3
G_2 A_4 F_3 B_1 
Stack 4
F_4 H_1 G_7 I_3 
Stack 5
F_2 C_5 E_3 G_5 
Stack 6
F_0 G_3 E_5 E_1 
Stack 7
C_2 J_2 F_8 C_6 
Stack 8
A_2 E_4 I_1 J_3 
Stack 9
J_4 C_4 D_6 E_8 
Stack 10
G_1 I_4 D_4 C_3 
Stack 11
A_3 E_7 H_0 E_6 
Stack 12
D_0 I_5 F_6 H_2 
Stack 13
G_6 H_5 C_0 D_3 
Stack 14
A_0 E_0 D_7 D_2 
Stack 15
H_3 B_0 H_4 I_2 
Stack 16
D_1 B_4 F_5 E_2 
Stack 17
F_7 J_1 B_2 
Stack 18
G_4 I_0 C_1 
