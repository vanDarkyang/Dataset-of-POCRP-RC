Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_9 D_12 C_10 A_9 E_13 E_14 
Stack 2
D_5 D_0 B_5 D_3 A_12 C_7 
Stack 3
C_9 D_6 D_4 B_14 E_7 B_9 
Stack 4
A_0 B_6 B_13 C_1 C_5 D_7 
Stack 5
C_14 B_12 B_7 C_8 B_11 
Stack 6
A_6 E_4 D_14 B_8 E_5 
Stack 7
E_10 D_15 A_14 E_9 E_11 
Stack 8
C_12 B_2 B_10 A_13 B_0 
Stack 9
C_11 A_1 E_6 A_10 C_15 
Stack 10
B_1 E_8 D_8 E_2 E_1 
Stack 11
A_4 D_11 C_2 E_0 A_2 
Stack 12
A_7 D_1 E_12 C_3 E_3 
Stack 13
C_0 A_11 B_15 C_4 B_3 
Stack 14
C_16 C_13 C_6 D_13 A_3 
Stack 15
D_10 A_8 A_5 B_4 D_2 
