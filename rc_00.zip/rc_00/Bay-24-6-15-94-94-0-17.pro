Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_3 G_8 L_0 I_6 
Stack 2
B_2 E_6 J_1 O_2 
Stack 3
G_3 A_0 I_4 E_0 
Stack 4
D_2 I_0 I_5 C_4 
Stack 5
A_2 I_2 D_0 J_5 
Stack 6
K_2 C_2 F_6 E_3 
Stack 7
G_7 F_0 K_5 D_1 
Stack 8
G_6 H_4 O_0 H_6 
Stack 9
C_1 I_1 N_2 L_2 
Stack 10
I_3 L_1 M_0 F_4 
Stack 11
L_5 I_8 G_4 H_9 
Stack 12
J_3 M_2 L_3 I_7 
Stack 13
E_4 J_4 M_1 G_0 
Stack 14
K_4 O_1 G_5 H_8 
Stack 15
K_1 H_3 D_5 A_1 
Stack 16
D_4 J_2 H_2 K_0 
Stack 17
F_1 D_3 L_4 C_3 
Stack 18
E_5 J_0 J_7 H_1 
Stack 19
G_2 B_3 C_0 E_2 
Stack 20
G_1 F_5 M_4 H_0 
Stack 21
N_3 B_1 E_1 N_0 
Stack 22
H_7 K_6 F_7 F_2 
Stack 23
B_0 H_5 F_3 
Stack 24
M_3 J_6 N_1 
