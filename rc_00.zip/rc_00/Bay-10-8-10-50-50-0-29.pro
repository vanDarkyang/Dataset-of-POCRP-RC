Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_0 F_0 F_5 F_3 C_4 
Stack 2
C_0 F_6 H_2 H_0 B_1 
Stack 3
E_2 F_1 I_1 J_0 A_1 
Stack 4
B_3 F_2 J_2 A_2 E_1 
Stack 5
D_3 D_1 D_2 H_1 H_4 
Stack 6
C_1 E_0 G_4 G_1 J_1 
Stack 7
I_3 F_4 D_5 E_4 B_2 
Stack 8
E_5 A_0 C_2 I_0 G_5 
Stack 9
C_3 I_2 E_3 D_0 H_3 
Stack 10
G_3 D_4 G_2 E_6 G_0 
