Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_5 B_1 D_0 C_4 E_4 
Stack 2
E_9 A_3 D_5 B_8 C_6 
Stack 3
A_6 E_8 C_3 B_3 D_9 
Stack 4
A_9 C_8 B_0 E_3 D_6 
Stack 5
A_4 C_7 E_5 D_2 C_11 
Stack 6
D_10 D_7 A_0 C_10 B_6 
Stack 7
D_8 B_7 C_9 E_0 A_5 
Stack 8
E_1 A_1 E_2 B_9 E_7 
Stack 9
D_1 D_4 B_10 A_7 A_8 
Stack 10
D_3 C_5 B_4 B_2 C_2 
Stack 11
C_1 C_0 E_6 A_2 
