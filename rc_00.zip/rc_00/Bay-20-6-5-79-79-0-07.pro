Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_5 C_13 D_15 D_14 
Stack 2
A_8 C_7 B_12 E_0 
Stack 3
A_12 B_8 B_14 E_6 
Stack 4
E_8 D_3 C_10 E_11 
Stack 5
B_13 B_9 C_11 E_9 
Stack 6
B_7 B_11 B_5 B_1 
Stack 7
D_1 E_14 E_10 D_9 
Stack 8
D_12 B_4 A_13 A_4 
Stack 9
B_3 E_3 A_1 A_14 
Stack 10
B_6 C_4 C_1 C_0 
Stack 11
C_15 D_8 E_5 E_7 
Stack 12
B_10 D_2 D_13 E_4 
Stack 13
C_12 A_3 A_10 A_9 
Stack 14
E_1 A_11 D_6 E_2 
Stack 15
B_0 D_5 A_2 D_4 
Stack 16
D_11 D_10 C_9 A_0 
Stack 17
D_0 E_12 C_8 E_13 
Stack 18
C_16 C_2 B_15 C_6 
Stack 19
D_7 C_14 C_3 A_6 
Stack 20
B_2 A_7 C_5 
