Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_4 J_5 C_2 L_4 
Stack 2
G_6 E_2 C_3 H_2 
Stack 3
D_1 D_5 J_3 F_2 
Stack 4
G_7 I_2 D_0 O_0 
Stack 5
H_8 J_4 K_3 B_3 
Stack 6
H_4 D_4 H_7 H_5 
Stack 7
E_1 E_6 I_1 E_0 
Stack 8
K_2 K_1 J_0 N_2 
Stack 9
L_1 M_4 D_3 B_2 
Stack 10
I_6 G_3 K_6 E_3 
Stack 11
H_9 M_3 H_1 D_2 
Stack 12
G_2 I_8 I_4 J_6 
Stack 13
L_2 J_2 I_5 H_6 
Stack 14
G_5 F_6 K_4 M_2 
Stack 15
B_0 H_0 B_1 N_1 
Stack 16
F_1 F_3 F_4 E_5 
Stack 17
J_1 I_0 N_3 M_0 
Stack 18
I_7 J_7 A_0 M_1 
Stack 19
G_8 O_1 F_5 C_1 
Stack 20
L_3 L_5 A_2 E_4 
Stack 21
K_5 H_3 I_3 O_2 
Stack 22
G_0 N_0 F_0 L_0 
Stack 23
A_1 K_0 G_1 
Stack 24
F_7 C_0 C_4 
