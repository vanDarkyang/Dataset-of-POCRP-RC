Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_4 L_2 F_0 H_11 J_2 F_6 
Stack 2
E_5 L_0 K_4 H_3 E_8 G_3 
Stack 3
G_7 K_1 M_0 L_7 F_3 O_1 
Stack 4
F_1 G_2 J_1 J_4 A_3 E_0 
Stack 5
O_2 G_10 L_4 H_5 E_7 
Stack 6
B_0 I_7 A_4 D_7 O_0 
Stack 7
H_1 F_4 L_5 A_1 H_10 
Stack 8
N_2 J_3 C_5 K_2 I_9 
Stack 9
K_8 C_4 I_3 B_4 M_5 
Stack 10
L_1 M_6 C_1 E_2 M_3 
Stack 11
A_0 I_1 N_0 I_0 A_2 
Stack 12
K_0 O_3 J_9 G_4 I_10 
Stack 13
C_6 O_4 J_0 D_1 K_7 
Stack 14
D_0 K_3 D_2 B_1 C_2 
Stack 15
I_6 G_8 H_2 I_8 N_4 
Stack 16
B_3 F_8 M_4 N_1 E_4 
Stack 17
H_7 C_0 D_3 G_5 G_0 
Stack 18
F_5 G_9 D_6 B_5 J_7 
Stack 19
E_6 N_5 E_1 G_6 D_4 
Stack 20
J_8 K_5 N_3 H_8 I_4 
Stack 21
C_3 I_5 I_2 H_9 F_9 
Stack 22
M_1 B_2 F_2 L_6 D_5 
Stack 23
E_3 M_2 J_5 L_3 H_6 
Stack 24
G_1 H_0 K_6 F_7 J_6 
