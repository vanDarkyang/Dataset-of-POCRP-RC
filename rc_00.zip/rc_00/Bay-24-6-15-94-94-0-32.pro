Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_5 I_3 K_5 H_2 
Stack 2
A_2 J_6 N_1 G_8 
Stack 3
K_1 F_3 F_1 D_1 
Stack 4
F_4 N_0 I_1 D_3 
Stack 5
H_3 D_2 B_3 I_7 
Stack 6
H_9 J_5 I_5 I_6 
Stack 7
K_6 B_1 A_0 M_4 
Stack 8
K_3 G_5 B_0 C_1 
Stack 9
E_5 N_2 H_0 G_6 
Stack 10
O_0 C_3 F_0 E_2 
Stack 11
M_0 L_5 J_3 E_0 
Stack 12
C_0 G_0 G_4 F_6 
Stack 13
K_2 M_2 B_2 L_4 
Stack 14
J_4 G_1 G_7 F_5 
Stack 15
L_1 H_1 F_7 F_2 
Stack 16
H_6 K_4 H_4 D_4 
Stack 17
E_4 J_2 J_0 I_0 
Stack 18
E_1 G_2 L_2 E_3 
Stack 19
J_1 A_1 I_4 N_3 
Stack 20
G_3 D_5 M_3 O_2 
Stack 21
H_8 E_6 C_2 D_0 
Stack 22
K_0 I_2 I_8 J_7 
Stack 23
L_0 H_7 C_4 
Stack 24
O_1 M_1 L_3 
