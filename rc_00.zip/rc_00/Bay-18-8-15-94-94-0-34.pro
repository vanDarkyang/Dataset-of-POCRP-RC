Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_6 G_7 B_1 I_7 L_1 K_1 
Stack 2
F_5 C_3 D_5 H_2 N_0 D_0 
Stack 3
B_0 E_4 C_1 H_5 D_4 I_1 
Stack 4
D_2 L_5 H_1 L_3 I_6 E_5 
Stack 5
M_2 N_3 C_0 K_3 H_0 
Stack 6
L_2 E_6 M_0 J_6 I_5 
Stack 7
M_4 J_0 G_0 G_3 G_6 
Stack 8
I_8 H_6 I_4 G_5 E_0 
Stack 9
H_8 F_7 J_7 F_4 D_3 
Stack 10
G_4 G_2 M_3 K_4 D_1 
Stack 11
F_0 F_1 O_0 O_2 J_4 
Stack 12
I_0 A_2 G_1 E_3 H_7 
Stack 13
F_2 C_4 H_3 K_0 J_3 
Stack 14
G_8 J_5 B_3 B_2 L_4 
Stack 15
E_1 H_4 H_9 M_1 O_1 
Stack 16
C_2 F_3 K_5 A_0 J_1 
Stack 17
N_1 N_2 E_2 I_2 K_2 
Stack 18
A_1 J_2 I_3 L_0 K_6 
