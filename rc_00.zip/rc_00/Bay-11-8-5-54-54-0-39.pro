Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_8 C_10 C_5 E_9 E_2 
Stack 2
E_5 E_6 A_3 A_1 B_8 
Stack 3
D_1 C_9 D_8 B_5 A_5 
Stack 4
D_3 D_7 E_4 C_0 E_3 
Stack 5
C_2 D_2 A_2 D_9 B_4 
Stack 6
A_8 C_1 A_9 E_1 A_7 
Stack 7
D_0 E_7 C_11 D_4 B_3 
Stack 8
C_7 D_6 B_6 C_3 C_4 
Stack 9
B_10 B_7 A_0 B_1 D_10 
Stack 10
B_0 A_6 D_5 B_9 E_0 
Stack 11
C_8 A_4 C_6 B_2 
