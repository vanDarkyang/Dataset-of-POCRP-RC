Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_9 C_12 E_6 B_6 E_7 A_11 
Stack 2
C_3 B_13 D_2 B_15 A_7 B_14 
Stack 3
E_8 B_12 C_1 C_7 E_3 E_9 
Stack 4
B_4 A_0 C_6 C_11 E_11 A_12 
Stack 5
D_14 D_15 B_1 A_6 B_7 
Stack 6
C_5 C_0 D_5 E_0 A_3 
Stack 7
A_5 B_10 A_8 A_10 D_8 
Stack 8
C_2 C_4 E_1 A_1 D_0 
Stack 9
D_1 E_14 E_5 A_2 C_16 
Stack 10
E_4 B_2 D_7 C_9 D_12 
Stack 11
D_11 C_8 D_3 E_2 D_10 
Stack 12
B_9 A_14 C_15 B_8 C_14 
Stack 13
A_4 C_10 B_11 B_0 E_10 
Stack 14
B_5 E_12 C_13 A_13 B_3 
Stack 15
D_6 D_13 E_13 D_4 D_9 
