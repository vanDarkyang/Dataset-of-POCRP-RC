Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_4 B_2 C_2 B_1 E_8 
Stack 2
A_9 B_3 C_10 A_3 D_7 
Stack 3
B_0 D_0 C_1 D_3 C_7 
Stack 4
B_9 D_10 C_3 C_0 E_4 
Stack 5
A_4 E_9 A_1 A_7 B_7 
Stack 6
C_9 A_0 C_11 A_5 B_5 
Stack 7
A_8 D_4 D_8 E_1 E_7 
Stack 8
C_8 D_5 C_6 E_6 B_8 
Stack 9
A_6 C_4 E_0 E_3 D_6 
Stack 10
B_6 E_2 D_9 E_5 A_2 
Stack 11
D_1 C_5 D_2 B_10 
