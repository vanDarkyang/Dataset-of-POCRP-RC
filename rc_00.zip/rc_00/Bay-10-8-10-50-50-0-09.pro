Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 F_0 G_3 D_3 I_3 
Stack 2
G_0 D_1 F_2 H_2 E_2 
Stack 3
E_0 I_1 J_0 E_3 B_1 
Stack 4
B_0 I_2 J_2 F_5 C_1 
Stack 5
B_3 H_3 D_2 C_3 I_0 
Stack 6
E_4 H_1 F_6 D_4 A_2 
Stack 7
C_0 F_1 C_2 H_4 F_3 
Stack 8
E_5 E_1 F_4 G_4 E_6 
Stack 9
G_2 J_1 C_4 G_5 G_1 
Stack 10
A_0 H_0 B_2 D_0 D_5 
