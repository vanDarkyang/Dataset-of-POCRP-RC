Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_2 I_0 B_2 I_1 F_3 
Stack 2
G_3 A_0 D_3 A_2 D_1 
Stack 3
E_2 F_6 J_1 C_0 G_0 
Stack 4
G_5 D_0 H_1 F_2 F_0 
Stack 5
B_3 H_2 C_2 J_0 F_1 
Stack 6
F_5 D_5 C_3 H_3 E_4 
Stack 7
J_2 C_1 H_4 E_1 E_0 
Stack 8
G_1 I_3 B_1 E_3 G_4 
Stack 9
I_2 E_6 E_5 F_4 D_4 
Stack 10
C_4 A_1 G_2 H_0 B_0 
