Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_3 B_4 C_10 A_4 D_8 
Stack 2
D_0 A_7 A_2 A_0 D_9 
Stack 3
E_1 E_4 C_5 D_5 B_5 
Stack 4
D_6 B_6 C_2 A_6 B_9 
Stack 5
B_2 B_7 D_2 C_7 A_5 
Stack 6
A_1 C_0 B_1 D_7 C_8 
Stack 7
B_0 A_3 E_5 E_0 E_2 
Stack 8
E_6 C_4 C_1 E_3 D_10 
Stack 9
D_3 C_6 C_3 D_1 C_11 
Stack 10
B_8 E_8 E_9 B_10 C_9 
Stack 11
E_7 A_8 D_4 A_9 
