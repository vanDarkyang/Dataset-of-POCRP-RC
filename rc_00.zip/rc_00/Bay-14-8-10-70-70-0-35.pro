Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_3 H_3 E_7 F_8 B_1 
Stack 2
A_1 D_1 I_5 I_1 I_3 
Stack 3
G_2 F_7 H_5 D_6 G_5 
Stack 4
F_4 G_4 E_0 D_4 E_1 
Stack 5
F_2 G_0 B_0 H_0 C_6 
Stack 6
F_0 F_1 B_4 F_6 J_3 
Stack 7
C_2 A_4 J_1 C_0 E_8 
Stack 8
A_2 H_1 I_0 D_7 C_3 
Stack 9
J_4 C_5 H_6 H_4 E_6 
Stack 10
G_1 G_3 J_0 F_5 H_2 
Stack 11
A_3 J_2 F_3 B_2 D_3 
Stack 12
D_0 E_4 G_7 C_1 D_2 
Stack 13
G_6 C_4 E_3 B_5 I_2 
Stack 14
A_0 I_4 E_5 D_5 E_2 
