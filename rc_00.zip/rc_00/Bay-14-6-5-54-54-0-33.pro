Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_2 A_2 D_7 B_1 
Stack 2
D_3 C_9 B_8 A_3 
Stack 3
B_0 E_3 E_6 C_2 
Stack 4
B_3 E_4 C_6 A_8 
Stack 5
D_10 C_3 C_5 A_5 
Stack 6
A_6 C_8 A_9 D_4 
Stack 7
A_1 E_0 E_9 D_0 
Stack 8
A_4 C_1 C_11 D_1 
Stack 9
E_7 D_8 B_7 D_5 
Stack 10
A_7 B_5 D_9 B_9 
Stack 11
A_0 B_2 B_4 B_6 
Stack 12
D_2 C_7 B_10 E_8 
Stack 13
C_4 D_6 C_0 
Stack 14
E_1 C_10 E_5 
