Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_1 C_3 D_0 I_2 F_2 
Stack 2
E_3 H_3 F_4 E_1 H_0 
Stack 3
D_1 H_1 F_0 D_4 D_3 
Stack 4
J_0 A_0 G_0 G_2 C_4 
Stack 5
D_5 D_2 C_0 B_1 E_6 
Stack 6
G_5 F_5 G_1 H_2 H_4 
Stack 7
F_6 J_2 I_1 E_4 C_1 
Stack 8
B_0 A_2 I_0 A_1 E_5 
Stack 9
G_3 B_2 F_1 G_4 E_0 
Stack 10
B_3 I_3 C_2 F_3 E_2 
