Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_2 B_3 F_2 D_5 
Stack 2
I_1 C_4 D_4 C_0 
Stack 3
D_1 J_1 C_2 E_2 
Stack 4
I_2 H_3 J_0 G_0 
Stack 5
B_1 G_4 J_2 A_0 
Stack 6
A_1 E_1 E_3 H_2 
Stack 7
D_2 D_0 F_1 D_3 
Stack 8
I_3 G_3 E_0 F_0 
Stack 9
H_4 H_1 E_6 C_1 
Stack 10
G_5 E_4 C_3 B_0 
Stack 11
B_2 F_6 G_1 F_5 
Stack 12
E_5 A_2 H_0 
Stack 13
I_0 F_3 F_4 
