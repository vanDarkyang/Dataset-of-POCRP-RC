Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_4 C_14 B_7 E_14 E_11 E_1 
Stack 2
B_13 A_13 B_2 A_5 E_0 D_12 
Stack 3
A_0 B_4 D_14 A_14 C_3 B_9 
Stack 4
D_7 C_10 E_13 E_8 D_15 A_7 
Stack 5
C_9 B_8 E_12 D_2 B_14 
Stack 6
D_5 C_6 B_3 A_3 E_10 
Stack 7
C_7 D_0 A_1 D_10 A_8 
Stack 8
C_2 E_3 E_5 D_6 E_4 
Stack 9
E_9 C_1 D_1 C_5 D_8 
Stack 10
A_9 D_3 E_6 A_11 B_10 
Stack 11
C_12 A_6 B_15 D_13 B_0 
Stack 12
C_0 A_2 C_16 C_13 B_11 
Stack 13
C_8 C_11 A_10 A_12 E_7 
Stack 14
D_4 B_6 D_11 B_1 D_9 
Stack 15
B_5 C_15 B_12 C_4 E_2 
