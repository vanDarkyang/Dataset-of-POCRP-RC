Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_6 B_6 C_1 C_2 
Stack 2
D_8 D_6 B_8 B_1 
Stack 3
E_3 D_2 B_2 B_4 
Stack 4
A_9 C_9 E_5 C_8 
Stack 5
E_0 A_0 A_3 E_8 
Stack 6
D_10 A_8 B_3 A_4 
Stack 7
B_10 E_6 D_3 A_5 
Stack 8
C_6 C_5 D_4 E_9 
Stack 9
D_5 C_3 E_2 C_0 
Stack 10
B_9 C_10 C_4 D_0 
Stack 11
B_7 E_1 B_0 D_9 
Stack 12
D_1 E_4 A_1 C_11 
Stack 13
E_7 A_7 C_7 
Stack 14
A_2 D_7 B_5 
