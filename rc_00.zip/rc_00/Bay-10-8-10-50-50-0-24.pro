Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_0 H_0 C_2 C_1 B_2 
Stack 2
C_0 J_1 F_2 A_2 H_3 
Stack 3
E_1 G_0 E_2 D_0 F_0 
Stack 4
E_0 B_1 F_4 D_3 D_4 
Stack 5
G_5 G_4 F_6 G_3 H_4 
Stack 6
G_1 J_2 E_4 A_0 E_6 
Stack 7
G_2 E_5 D_5 H_2 I_1 
Stack 8
F_3 J_0 H_1 D_2 I_2 
Stack 9
E_3 B_3 A_1 C_3 F_5 
Stack 10
F_1 C_4 I_0 D_1 I_3 
