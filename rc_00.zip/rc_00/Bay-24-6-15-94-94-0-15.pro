Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_5 F_7 J_2 G_0 
Stack 2
G_3 H_6 F_3 H_5 
Stack 3
C_3 G_2 C_4 L_3 
Stack 4
B_2 M_0 F_6 H_4 
Stack 5
G_1 K_6 L_1 C_2 
Stack 6
O_1 J_7 H_9 G_4 
Stack 7
N_1 E_0 F_4 J_6 
Stack 8
A_1 G_6 J_1 O_2 
Stack 9
D_1 H_7 G_8 D_4 
Stack 10
D_0 I_7 H_0 H_2 
Stack 11
A_0 I_6 K_3 J_3 
Stack 12
B_1 K_1 N_2 J_4 
Stack 13
I_1 D_2 D_5 L_5 
Stack 14
E_6 E_5 K_0 F_2 
Stack 15
C_0 K_5 N_0 I_2 
Stack 16
G_7 J_0 I_4 M_1 
Stack 17
F_0 E_4 O_0 F_1 
Stack 18
B_3 I_5 C_1 E_2 
Stack 19
K_4 M_4 M_2 D_3 
Stack 20
H_1 A_2 I_8 K_2 
Stack 21
E_3 G_5 I_3 M_3 
Stack 22
E_1 L_2 H_3 H_8 
Stack 23
N_3 L_0 L_4 
Stack 24
I_0 B_0 F_5 
