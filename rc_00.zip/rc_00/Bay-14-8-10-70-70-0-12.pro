Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_5 F_4 J_4 I_5 B_3 
Stack 2
D_3 E_5 E_6 J_0 H_0 
Stack 3
F_6 F_5 B_0 H_3 C_0 
Stack 4
B_1 D_2 A_4 I_4 C_3 
Stack 5
B_5 D_7 H_6 B_4 F_0 
Stack 6
G_0 D_1 H_1 C_1 F_2 
Stack 7
C_6 D_0 F_8 D_6 I_2 
Stack 8
D_4 A_2 G_2 G_1 C_4 
Stack 9
A_3 I_3 B_2 H_4 C_5 
Stack 10
E_7 E_2 C_2 G_3 J_1 
Stack 11
J_2 G_5 F_3 A_0 E_4 
Stack 12
G_4 G_7 J_3 I_0 E_3 
Stack 13
F_7 E_1 E_0 H_2 A_1 
Stack 14
E_8 D_5 I_1 G_6 F_1 
