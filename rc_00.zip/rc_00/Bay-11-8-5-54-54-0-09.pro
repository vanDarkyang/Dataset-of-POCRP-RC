Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 C_1 C_5 D_7 C_7 
Stack 2
E_8 E_0 C_0 B_1 D_0 
Stack 3
A_3 B_4 D_9 B_2 D_5 
Stack 4
B_3 C_3 C_11 E_1 C_9 
Stack 5
A_9 E_7 B_8 A_8 A_7 
Stack 6
B_9 D_3 A_6 E_2 C_8 
Stack 7
D_8 A_1 A_2 A_0 B_5 
Stack 8
D_4 A_4 C_4 D_2 B_7 
Stack 9
E_4 B_10 E_3 E_5 C_6 
Stack 10
B_0 C_2 A_5 B_6 D_10 
Stack 11
C_10 E_9 D_6 E_6 
