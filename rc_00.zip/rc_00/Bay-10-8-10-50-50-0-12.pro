Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 C_0 F_2 D_3 F_4 
Stack 2
D_5 H_3 E_6 D_0 H_4 
Stack 3
D_2 E_4 E_3 E_0 E_5 
Stack 4
F_1 I_2 B_3 G_2 J_2 
Stack 5
C_3 C_4 J_0 I_0 F_6 
Stack 6
F_3 G_4 B_2 F_0 A_2 
Stack 7
J_1 G_3 G_5 B_0 C_2 
Stack 8
C_1 I_3 A_1 E_1 A_0 
Stack 9
G_0 E_2 D_4 I_1 H_1 
Stack 10
G_1 H_2 F_5 H_0 D_1 
