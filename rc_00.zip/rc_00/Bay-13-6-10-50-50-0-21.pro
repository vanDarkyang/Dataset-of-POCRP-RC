Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_1 E_0 F_3 I_0 
Stack 2
B_2 G_3 G_0 H_3 
Stack 3
A_2 B_1 I_3 C_2 
Stack 4
A_0 B_3 J_2 E_6 
Stack 5
F_6 G_4 D_3 H_1 
Stack 6
D_0 E_1 D_2 J_0 
Stack 7
D_4 F_0 G_2 C_3 
Stack 8
F_5 E_3 G_5 E_5 
Stack 9
G_1 E_2 J_1 D_5 
Stack 10
C_4 C_1 B_0 C_0 
Stack 11
E_4 H_4 F_4 H_0 
Stack 12
D_1 F_2 I_1 
Stack 13
H_2 I_2 A_1 
