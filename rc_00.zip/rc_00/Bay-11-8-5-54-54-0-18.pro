Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_5 B_4 A_5 E_3 C_0 
Stack 2
E_9 B_2 E_0 C_8 A_6 
Stack 3
A_8 A_3 D_9 C_1 C_9 
Stack 4
E_5 A_2 C_10 D_0 D_7 
Stack 5
C_2 D_1 B_10 B_9 E_7 
Stack 6
A_4 D_10 E_1 B_5 E_6 
Stack 7
B_6 D_4 B_8 D_2 C_6 
Stack 8
A_9 A_7 D_6 E_4 E_2 
Stack 9
B_3 A_0 C_7 B_1 B_7 
Stack 10
E_8 B_0 D_5 A_1 D_3 
Stack 11
C_3 C_11 C_4 D_8 
