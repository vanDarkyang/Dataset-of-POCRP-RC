Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_12 E_13 A_10 D_8 E_0 C_8 
Stack 2
E_9 A_4 D_3 E_10 E_3 B_7 
Stack 3
C_15 D_5 D_2 C_10 E_4 D_15 
Stack 4
E_12 C_14 D_13 E_11 D_0 E_5 
Stack 5
A_14 B_5 A_5 A_6 E_14 
Stack 6
C_5 E_1 D_14 D_12 C_4 
Stack 7
A_8 C_11 A_0 C_9 B_2 
Stack 8
D_7 B_9 B_13 B_1 A_1 
Stack 9
E_8 C_7 C_12 A_11 B_12 
Stack 10
B_3 C_1 C_2 B_15 A_3 
Stack 11
A_13 C_3 A_7 B_10 B_14 
Stack 12
D_4 B_11 C_0 E_6 B_8 
Stack 13
E_7 D_9 A_9 C_13 D_10 
Stack 14
A_2 C_16 B_6 D_6 C_6 
Stack 15
B_0 E_2 B_4 D_11 D_1 
