Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 B_6 E_3 C_10 E_4 
Stack 2
C_6 C_0 B_4 C_1 C_9 
Stack 3
B_10 D_2 D_6 A_4 C_4 
Stack 4
D_10 E_1 C_7 A_1 A_2 
Stack 5
B_7 D_0 C_2 E_6 A_0 
Stack 6
A_8 D_3 D_4 D_7 B_0 
Stack 7
B_5 B_1 D_8 E_5 D_1 
Stack 8
A_5 E_7 E_2 D_9 C_8 
Stack 9
C_5 C_11 B_3 E_8 D_5 
Stack 10
E_9 A_6 B_9 A_7 A_3 
Stack 11
B_2 A_9 E_0 B_8 
