Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_0 B_5 B_0 D_7 C_0 
Stack 2
A_9 A_5 C_11 B_2 A_1 
Stack 3
A_3 B_8 C_7 C_9 C_8 
Stack 4
C_4 D_4 B_6 B_7 D_3 
Stack 5
E_6 C_6 D_2 E_7 B_3 
Stack 6
D_1 A_7 C_1 A_6 A_2 
Stack 7
A_8 C_5 D_10 E_8 D_6 
Stack 8
B_9 B_1 B_4 D_5 D_9 
Stack 9
E_3 D_0 B_10 C_3 E_9 
Stack 10
C_10 E_4 E_5 E_1 D_8 
Stack 11
A_4 A_0 C_2 E_2 
