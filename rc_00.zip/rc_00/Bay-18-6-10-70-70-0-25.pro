Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_0 H_2 D_1 A_3 
Stack 2
H_1 G_0 C_4 C_6 
Stack 3
B_5 J_2 E_0 G_2 
Stack 4
E_1 D_6 I_2 B_1 
Stack 5
F_2 J_1 I_0 I_4 
Stack 6
H_6 A_4 G_6 I_5 
Stack 7
A_0 B_0 H_0 A_2 
Stack 8
G_7 E_4 I_1 C_5 
Stack 9
F_1 D_7 E_3 H_5 
Stack 10
G_1 H_3 E_6 B_4 
Stack 11
E_8 A_1 D_2 G_3 
Stack 12
D_5 H_4 F_5 G_4 
Stack 13
B_3 E_7 E_2 F_3 
Stack 14
J_0 C_1 C_2 J_4 
Stack 15
C_3 F_0 E_5 B_2 
Stack 16
D_3 F_6 G_5 F_8 
Stack 17
F_4 D_4 I_3 
Stack 18
J_3 F_7 C_0 
