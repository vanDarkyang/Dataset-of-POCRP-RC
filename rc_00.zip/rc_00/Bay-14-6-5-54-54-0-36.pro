Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_5 C_8 C_9 B_2 
Stack 2
E_9 C_7 E_2 A_2 
Stack 3
A_6 D_7 B_10 E_4 
Stack 4
A_9 B_7 B_4 C_6 
Stack 5
A_4 A_1 E_6 D_9 
Stack 6
D_10 D_4 C_4 D_6 
Stack 7
D_8 C_5 B_8 C_11 
Stack 8
E_1 C_0 B_3 B_6 
Stack 9
D_1 D_0 E_3 A_5 
Stack 10
D_3 D_5 D_2 E_7 
Stack 11
C_1 C_3 C_10 A_8 
Stack 12
B_1 B_0 E_0 C_2 
Stack 13
A_3 E_5 B_9 
Stack 14
E_8 A_0 A_7 
