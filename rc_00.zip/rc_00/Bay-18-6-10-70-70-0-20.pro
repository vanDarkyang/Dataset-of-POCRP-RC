Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_5 E_1 F_7 C_1 
Stack 2
B_0 H_4 D_6 C_3 
Stack 3
B_3 E_0 F_0 F_3 
Stack 4
B_2 G_7 A_3 E_2 
Stack 5
C_5 H_1 F_6 I_2 
Stack 6
D_4 E_7 D_3 I_5 
Stack 7
E_6 C_2 I_3 B_4 
Stack 8
H_0 F_4 H_3 D_2 
Stack 9
F_2 E_8 J_2 A_2 
Stack 10
H_5 D_7 I_1 F_5 
Stack 11
A_1 D_0 J_1 A_4 
Stack 12
D_5 J_3 C_0 F_1 
Stack 13
D_1 G_0 A_0 G_2 
Stack 14
H_6 C_4 I_0 H_2 
Stack 15
G_3 G_1 G_4 C_6 
Stack 16
F_8 J_0 E_4 B_1 
Stack 17
G_6 B_5 I_4 
Stack 18
E_3 J_4 E_5 
