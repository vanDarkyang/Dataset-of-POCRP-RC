Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_0 A_8 B_6 D_8 E_7 
Stack 2
D_9 D_10 C_1 C_5 E_9 
Stack 3
A_1 C_2 B_2 D_0 E_2 
Stack 4
B_3 A_9 A_4 E_8 B_8 
Stack 5
E_3 E_5 B_4 D_3 C_7 
Stack 6
B_5 D_2 D_4 A_3 A_7 
Stack 7
C_3 B_0 B_9 C_10 C_11 
Stack 8
E_0 C_8 D_5 D_1 C_4 
Stack 9
B_7 E_1 A_5 C_6 D_6 
Stack 10
B_1 C_9 A_2 B_10 D_7 
Stack 11
A_6 E_4 E_6 A_0 
