Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_5 E_3 G_1 H_4 
Stack 2
B_1 E_0 E_4 C_3 
Stack 3
J_2 B_3 F_4 I_0 
Stack 4
H_1 G_2 H_3 E_2 
Stack 5
D_1 D_5 D_0 G_5 
Stack 6
I_3 F_3 F_6 A_1 
Stack 7
F_5 C_1 F_2 F_0 
Stack 8
G_3 C_0 D_2 B_2 
Stack 9
C_4 C_2 G_4 H_0 
Stack 10
H_2 J_1 J_0 A_2 
Stack 11
E_1 E_6 D_3 B_0 
Stack 12
D_4 F_1 G_0 
Stack 13
I_1 A_0 I_2 
