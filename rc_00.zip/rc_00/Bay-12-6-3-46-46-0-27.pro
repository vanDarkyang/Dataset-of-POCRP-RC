Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_14 B_1 A_6 B_0 
Stack 2
A_9 C_7 A_13 C_3 
Stack 3
C_4 A_2 A_1 A_10 
Stack 4
A_12 B_4 B_11 C_10 
Stack 5
B_3 C_0 C_9 B_13 
Stack 6
C_1 A_0 A_14 C_5 
Stack 7
B_6 C_6 A_8 B_5 
Stack 8
B_9 B_7 C_2 B_14 
Stack 9
B_8 B_15 C_11 B_10 
Stack 10
C_12 B_12 A_3 C_8 
Stack 11
A_11 B_2 A_7 
Stack 12
A_5 A_4 C_13 
