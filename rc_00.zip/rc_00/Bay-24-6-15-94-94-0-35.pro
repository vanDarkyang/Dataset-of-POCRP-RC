Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_8 E_2 C_3 D_1 
Stack 2
G_3 J_7 E_5 B_3 
Stack 3
C_0 G_7 C_4 O_0 
Stack 4
E_4 I_2 D_2 D_3 
Stack 5
G_1 J_4 M_4 L_0 
Stack 6
L_3 M_2 A_1 J_2 
Stack 7
I_3 I_4 D_4 O_2 
Stack 8
H_9 L_2 F_1 G_0 
Stack 9
G_6 K_3 H_5 M_0 
Stack 10
D_0 L_1 N_1 J_1 
Stack 11
A_2 K_4 A_0 O_1 
Stack 12
H_2 F_5 K_0 H_3 
Stack 13
L_5 E_0 I_5 M_1 
Stack 14
G_5 I_1 G_4 F_4 
Stack 15
H_7 L_4 E_3 F_7 
Stack 16
F_3 B_2 I_7 C_1 
Stack 17
K_6 M_3 K_1 F_0 
Stack 18
C_2 B_0 J_5 N_0 
Stack 19
I_8 F_2 J_6 H_4 
Stack 20
H_0 H_1 D_5 E_1 
Stack 21
H_6 I_6 I_0 J_0 
Stack 22
N_3 E_6 H_8 N_2 
Stack 23
K_2 F_6 J_3 
Stack 24
G_2 B_1 K_5 
