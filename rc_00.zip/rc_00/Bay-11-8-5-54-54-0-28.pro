Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_10 B_3 B_4 E_2 A_9 
Stack 2
C_0 A_2 E_9 D_4 C_7 
Stack 3
B_7 D_1 B_9 C_10 E_8 
Stack 4
C_8 A_0 D_0 B_2 B_6 
Stack 5
C_4 B_8 D_9 C_1 A_8 
Stack 6
B_5 C_3 A_5 B_0 D_3 
Stack 7
A_6 D_5 D_2 E_0 A_7 
Stack 8
C_9 D_7 E_6 C_6 B_1 
Stack 9
A_4 E_1 B_10 D_8 E_4 
Stack 10
C_11 A_1 D_6 E_3 A_3 
Stack 11
C_2 C_5 E_7 E_5 
