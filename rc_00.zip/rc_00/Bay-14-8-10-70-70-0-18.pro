Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 G_7 G_6 I_1 A_3 
Stack 2
B_2 D_0 G_2 H_6 F_2 
Stack 3
C_4 J_4 A_4 E_0 C_5 
Stack 4
C_6 I_2 E_4 E_7 H_4 
Stack 5
J_2 F_5 I_4 C_0 B_4 
Stack 6
H_5 E_5 D_7 G_5 G_0 
Stack 7
B_3 J_3 I_3 A_2 D_1 
Stack 8
E_1 A_0 F_3 C_3 D_3 
Stack 9
C_1 F_6 B_5 F_7 J_0 
Stack 10
E_6 F_8 F_0 H_0 E_2 
Stack 11
D_2 I_0 D_6 H_2 J_1 
Stack 12
F_1 B_0 C_2 B_1 G_4 
Stack 13
D_5 H_3 G_1 E_8 D_4 
Stack 14
G_3 H_1 F_4 I_5 E_3 
