Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_0 G_1 G_2 I_3 
Stack 2
E_3 E_5 E_0 J_4 
Stack 3
C_2 A_2 F_4 F_8 
Stack 4
F_2 D_7 I_1 A_4 
Stack 5
C_1 D_5 F_3 G_5 
Stack 6
H_4 F_1 G_7 E_4 
Stack 7
D_1 F_0 C_5 B_1 
Stack 8
C_6 E_2 F_5 H_6 
Stack 9
J_1 E_6 C_3 F_6 
Stack 10
G_4 I_4 D_6 E_1 
Stack 11
B_4 G_3 I_0 I_5 
Stack 12
B_5 E_8 H_2 D_2 
Stack 13
G_0 J_3 D_3 H_3 
Stack 14
D_4 H_1 B_3 A_0 
Stack 15
C_4 A_1 F_7 I_2 
Stack 16
G_6 H_5 D_0 H_0 
Stack 17
J_2 B_0 E_7 
Stack 18
A_3 B_2 C_0 
