Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 H_3 G_1 D_0 G_3 
Stack 2
F_5 E_3 D_4 D_3 E_6 
Stack 3
J_1 E_5 E_0 I_0 E_2 
Stack 4
C_1 D_2 D_1 G_2 F_2 
Stack 5
E_4 G_0 H_0 J_0 F_4 
Stack 6
C_2 F_3 H_2 B_0 G_5 
Stack 7
A_0 E_1 A_1 G_4 B_2 
Stack 8
I_1 I_3 D_5 H_4 F_1 
Stack 9
C_0 C_3 I_2 F_6 H_1 
Stack 10
J_2 C_4 B_3 F_0 A_2 
