Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_5 F_2 H_8 G_7 N_2 M_4 
Stack 2
J_0 H_5 H_0 L_5 I_0 L_2 
Stack 3
J_7 F_7 I_8 F_1 M_2 D_4 
Stack 4
J_4 K_2 D_0 A_0 E_2 B_0 
Stack 5
C_1 E_5 M_1 C_4 N_0 
Stack 6
H_7 I_5 G_2 K_1 L_3 
Stack 7
E_0 I_6 O_2 B_1 I_1 
Stack 8
I_7 H_2 D_2 B_3 H_9 
Stack 9
F_3 F_4 B_2 E_4 I_3 
Stack 10
F_6 J_1 N_3 K_6 C_0 
Stack 11
G_8 A_1 G_3 J_3 C_3 
Stack 12
C_2 M_3 J_6 K_0 A_2 
Stack 13
H_4 H_6 G_4 K_3 N_1 
Stack 14
D_5 O_0 G_5 J_5 I_4 
Stack 15
G_1 L_4 F_0 D_1 F_5 
Stack 16
D_3 K_4 J_2 G_0 G_6 
Stack 17
E_1 M_0 L_1 E_6 E_3 
Stack 18
L_0 O_1 H_3 H_1 I_2 
