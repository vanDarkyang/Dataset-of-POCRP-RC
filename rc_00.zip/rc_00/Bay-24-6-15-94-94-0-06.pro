Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_3 L_0 K_4 K_3 
Stack 2
A_1 H_4 I_6 L_1 
Stack 3
E_0 J_5 H_8 G_1 
Stack 4
I_8 H_1 I_2 H_6 
Stack 5
N_0 L_5 E_5 L_4 
Stack 6
F_1 E_4 G_8 H_0 
Stack 7
C_1 H_3 F_4 J_0 
Stack 8
D_4 B_1 K_1 F_6 
Stack 9
J_6 D_3 C_0 F_5 
Stack 10
H_7 O_2 O_0 D_2 
Stack 11
J_7 O_1 E_2 F_2 
Stack 12
H_5 G_0 H_9 A_0 
Stack 13
J_4 I_1 B_3 I_0 
Stack 14
G_6 F_0 B_2 K_0 
Stack 15
M_0 I_5 J_2 M_1 
Stack 16
C_4 G_5 A_2 K_2 
Stack 17
D_0 L_2 B_0 M_4 
Stack 18
I_4 I_3 G_4 N_3 
Stack 19
G_3 E_3 C_3 N_2 
Stack 20
L_3 J_3 D_5 N_1 
Stack 21
F_7 E_1 M_2 H_2 
Stack 22
K_5 D_1 J_1 E_6 
Stack 23
G_2 G_7 K_6 
Stack 24
C_2 I_7 M_3 
