Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_6 D_1 C_3 B_3 B_4 
Stack 2
D_8 E_7 C_10 D_3 C_8 
Stack 3
E_3 A_2 E_1 D_4 E_8 
Stack 4
A_9 B_6 E_4 E_2 A_4 
Stack 5
E_0 D_6 A_7 C_4 A_5 
Stack 6
D_10 D_2 D_7 B_0 E_9 
Stack 7
B_10 C_9 C_1 A_1 C_0 
Stack 8
C_6 A_0 B_8 C_7 D_0 
Stack 9
D_5 A_8 B_2 B_5 D_9 
Stack 10
B_9 E_6 E_5 C_2 C_11 
Stack 11
B_7 C_5 A_3 B_1 
