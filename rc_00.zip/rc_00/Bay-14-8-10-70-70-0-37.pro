Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_3 B_5 G_3 A_1 C_1 
Stack 2
H_0 G_6 D_6 E_5 D_2 
Stack 3
F_2 G_0 H_1 D_4 I_3 
Stack 4
C_5 C_2 F_5 A_2 I_2 
Stack 5
G_7 F_7 H_6 A_3 G_1 
Stack 6
G_2 J_4 D_5 H_5 F_0 
Stack 7
F_1 E_8 C_0 J_0 B_0 
Stack 8
E_0 E_4 G_5 C_3 E_7 
Stack 9
F_8 I_5 B_2 D_0 J_2 
Stack 10
C_4 D_3 C_6 H_4 E_1 
Stack 11
B_1 I_1 D_1 H_3 A_4 
Stack 12
J_1 J_3 E_2 I_4 F_4 
Stack 13
A_0 F_3 E_6 F_6 B_4 
Stack 14
I_0 G_4 B_3 D_7 H_2 
