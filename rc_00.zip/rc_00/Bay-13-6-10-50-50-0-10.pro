Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 I_2 E_5 B_2 
Stack 2
C_4 E_0 H_2 I_3 
Stack 3
B_3 G_2 G_0 G_1 
Stack 4
D_5 F_0 F_3 I_0 
Stack 5
C_1 J_2 F_2 G_3 
Stack 6
B_1 D_1 A_0 H_0 
Stack 7
J_1 E_1 I_1 C_2 
Stack 8
A_2 B_0 H_4 D_3 
Stack 9
D_4 E_6 D_0 F_4 
Stack 10
F_1 H_3 F_5 F_6 
Stack 11
E_3 D_2 E_2 E_4 
Stack 12
G_4 G_5 H_1 
Stack 13
C_3 J_0 C_0 
