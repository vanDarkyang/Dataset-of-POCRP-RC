Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_13 C_16 A_0 B_3 
Stack 2
E_1 C_9 A_8 D_12 
Stack 3
A_10 E_3 E_14 D_3 
Stack 4
C_14 C_3 E_12 E_8 
Stack 5
A_14 E_5 B_8 C_13 
Stack 6
E_7 C_0 B_15 A_5 
Stack 7
B_11 C_2 C_10 D_14 
Stack 8
D_8 D_0 D_6 E_4 
Stack 9
B_2 E_2 C_1 A_3 
Stack 10
E_10 C_12 A_11 D_1 
Stack 11
A_7 D_4 C_6 B_14 
Stack 12
C_11 A_12 C_4 B_10 
Stack 13
A_4 A_9 D_10 B_4 
Stack 14
E_6 A_1 D_15 C_8 
Stack 15
B_1 D_11 C_5 D_2 
Stack 16
E_13 A_6 B_7 B_12 
Stack 17
D_9 C_7 D_5 B_0 
Stack 18
B_6 D_7 E_0 D_13 
Stack 19
B_9 A_2 E_9 B_5 
Stack 20
E_11 C_15 A_13 
