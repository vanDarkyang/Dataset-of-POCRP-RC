Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_12 D_2 A_5 B_9 
Stack 2
B_2 D_7 B_11 C_6 
Stack 3
A_4 A_13 B_15 A_12 
Stack 4
D_8 D_3 A_2 A_8 
Stack 5
A_10 D_12 B_7 D_11 
Stack 6
B_1 D_9 E_3 D_6 
Stack 7
C_7 E_9 E_12 C_2 
Stack 8
B_10 D_5 E_10 E_4 
Stack 9
D_0 B_4 A_11 C_9 
Stack 10
B_6 C_5 A_14 D_1 
Stack 11
B_12 E_0 D_4 C_15 
Stack 12
E_1 E_7 A_6 A_1 
Stack 13
A_9 C_8 E_2 B_5 
Stack 14
D_15 C_4 A_7 E_13 
Stack 15
B_13 B_8 D_10 A_3 
Stack 16
C_1 A_0 E_8 B_0 
Stack 17
C_10 B_3 C_14 D_13 
Stack 18
B_14 C_11 E_5 E_11 
Stack 19
C_3 C_0 E_14 C_16 
Stack 20
D_14 C_13 E_6 
