Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
O_1 F_3 L_3 G_0 
Stack 2
C_1 D_4 K_1 K_3 
Stack 3
J_1 E_2 J_2 G_1 
Stack 4
C_4 K_5 J_3 C_3 
Stack 5
O_2 F_0 H_3 B_2 
Stack 6
E_1 H_9 F_7 E_6 
Stack 7
G_5 J_4 J_5 H_7 
Stack 8
M_0 I_4 J_6 A_0 
Stack 9
D_1 C_0 N_3 H_6 
Stack 10
F_4 L_0 B_0 E_0 
Stack 11
K_2 H_2 D_3 N_2 
Stack 12
H_5 H_4 L_5 B_1 
Stack 13
D_5 G_2 I_5 E_4 
Stack 14
M_1 B_3 J_7 G_3 
Stack 15
G_7 A_1 M_4 F_5 
Stack 16
I_0 E_5 G_8 N_1 
Stack 17
F_6 M_3 L_4 I_7 
Stack 18
I_3 A_2 O_0 J_0 
Stack 19
L_2 G_4 M_2 I_6 
Stack 20
H_1 C_2 I_8 K_0 
Stack 21
H_0 I_1 D_2 H_8 
Stack 22
K_4 I_2 K_6 L_1 
Stack 23
F_2 D_0 E_3 
Stack 24
F_1 G_6 N_0 
