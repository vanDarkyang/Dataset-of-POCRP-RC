Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_3 G_2 J_4 K_5 I_6 E_2 
Stack 2
B_2 G_1 O_1 O_0 O_2 H_0 
Stack 3
G_3 N_3 H_3 N_2 E_0 N_0 
Stack 4
D_2 H_7 J_2 M_0 C_4 F_2 
Stack 5
A_2 B_0 D_3 G_4 J_5 
Stack 6
K_2 M_3 J_0 L_3 E_3 
Stack 7
G_7 G_8 B_3 M_1 D_1 
Stack 8
G_6 E_6 F_5 G_5 H_6 
Stack 9
C_1 A_0 B_1 D_5 L_2 
Stack 10
I_3 I_0 K_6 H_2 F_4 
Stack 11
L_5 I_2 H_5 L_4 H_9 
Stack 12
J_3 C_2 J_6 J_7 I_7 
Stack 13
E_4 F_0 L_0 C_0 G_0 
Stack 14
K_4 H_4 J_1 M_4 H_8 
Stack 15
K_1 I_1 I_4 E_1 A_1 
Stack 16
D_4 L_1 I_5 F_7 K_0 
Stack 17
F_1 I_8 D_0 F_3 C_3 
Stack 18
E_5 M_2 F_6 N_1 H_1 
