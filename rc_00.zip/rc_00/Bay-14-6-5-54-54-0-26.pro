Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_8 E_0 E_2 B_4 
Stack 2
A_0 B_10 E_8 D_7 
Stack 3
C_10 A_9 C_2 A_5 
Stack 4
C_8 D_10 D_0 C_3 
Stack 5
B_6 D_1 D_4 B_9 
Stack 6
A_7 B_2 A_6 B_1 
Stack 7
B_5 A_4 B_7 E_1 
Stack 8
A_1 D_6 C_6 E_7 
Stack 9
D_8 C_7 B_0 C_4 
Stack 10
C_9 E_9 E_5 D_3 
Stack 11
A_3 E_3 C_11 C_5 
Stack 12
A_8 E_6 A_2 D_5 
Stack 13
D_9 D_2 C_1 
Stack 14
C_0 E_4 B_3 
