Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_7 J_0 D_5 D_7 I_0 
Stack 2
B_3 H_4 E_5 J_4 D_2 
Stack 3
F_1 B_1 F_3 G_0 G_5 
Stack 4
F_6 E_0 B_0 E_3 H_3 
Stack 5
D_0 H_2 I_3 B_4 A_3 
Stack 6
F_2 D_3 C_0 J_1 D_1 
Stack 7
I_2 C_4 E_8 A_1 G_1 
Stack 8
G_2 E_2 A_4 F_5 C_3 
Stack 9
E_4 E_1 C_2 B_5 I_5 
Stack 10
H_5 I_1 J_3 D_6 F_4 
Stack 11
F_8 F_0 C_5 H_6 G_6 
Stack 12
C_6 A_0 D_4 B_2 G_7 
Stack 13
H_1 E_6 J_2 H_0 G_3 
Stack 14
G_4 A_2 F_7 C_1 I_4 
