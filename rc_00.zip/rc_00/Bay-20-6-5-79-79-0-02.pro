Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_11 B_14 A_10 D_7 
Stack 2
A_11 D_13 D_11 E_9 
Stack 3
E_3 B_2 E_10 D_5 
Stack 4
B_8 C_10 A_9 A_1 
Stack 5
D_9 E_6 D_3 A_8 
Stack 6
E_13 C_12 C_5 C_2 
Stack 7
C_13 C_3 A_14 C_8 
Stack 8
D_4 E_12 B_6 E_2 
Stack 9
B_4 E_4 E_0 B_11 
Stack 10
E_1 E_11 C_16 A_2 
Stack 11
C_15 C_14 D_15 C_1 
Stack 12
A_7 B_9 A_4 A_12 
Stack 13
A_13 D_1 A_6 D_14 
Stack 14
A_0 C_4 E_7 C_0 
Stack 15
A_3 B_10 B_12 B_13 
Stack 16
B_1 B_3 D_12 D_2 
Stack 17
C_6 B_5 D_6 D_0 
Stack 18
C_9 B_15 D_8 E_8 
Stack 19
C_7 B_7 E_5 D_10 
Stack 20
B_0 A_5 E_14 
