Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_12 H_8 A_7 G_7 J_7 A_9 
Stack 2
E_3 J_3 H_6 F_6 F_7 D_11 
Stack 3
F_0 F_13 G_3 D_0 I_8 C_4 
Stack 4
C_0 C_6 B_2 I_6 D_3 J_4 
Stack 5
E_0 D_2 F_1 B_3 H_3 C_1 
Stack 6
C_3 A_1 C_10 I_9 F_2 
Stack 7
A_5 D_6 I_4 B_1 G_4 
Stack 8
A_3 I_1 J_5 D_5 A_6 
Stack 9
E_1 C_7 G_11 F_3 A_4 
Stack 10
H_9 G_5 H_2 I_7 B_4 
Stack 11
C_5 B_7 C_11 B_5 F_11 
Stack 12
E_4 E_6 E_5 G_6 E_2 
Stack 13
B_10 G_0 B_8 F_5 B_0 
Stack 14
J_2 E_9 A_0 F_10 F_12 
Stack 15
C_2 E_13 H_7 F_9 C_8 
Stack 16
E_10 G_2 D_8 D_7 J_0 
Stack 17
G_10 D_12 H_5 I_5 E_12 
Stack 18
D_4 I_10 J_1 I_3 D_9 
Stack 19
B_6 I_2 J_8 A_2 H_11 
Stack 20
J_9 E_8 G_9 F_4 H_10 
Stack 21
G_1 D_1 B_9 I_0 F_8 
Stack 22
H_0 J_6 E_11 E_7 C_9 
Stack 23
H_4 A_8 D_10 G_8 H_1 
