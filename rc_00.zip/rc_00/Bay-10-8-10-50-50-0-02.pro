Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 J_2 C_1 H_1 I_1 
Stack 2
E_2 B_2 G_3 A_0 D_0 
Stack 3
F_1 G_1 I_2 E_0 H_2 
Stack 4
E_3 G_5 E_5 H_3 D_2 
Stack 5
C_2 D_4 C_3 G_2 J_0 
Stack 6
C_4 I_0 B_0 F_2 F_4 
Stack 7
B_3 F_6 F_5 E_1 I_3 
Stack 8
C_0 B_1 F_0 D_3 D_1 
Stack 9
F_3 D_5 G_4 E_6 G_0 
Stack 10
H_0 A_2 E_4 H_4 J_1 
