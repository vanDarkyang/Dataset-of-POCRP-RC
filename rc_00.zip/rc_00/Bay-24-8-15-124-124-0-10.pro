Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_4 F_9 H_9 M_6 N_1 C_6 
Stack 2
A_0 I_6 C_0 H_3 I_7 L_5 
Stack 3
J_4 M_1 D_6 C_1 F_7 N_2 
Stack 4
J_8 I_4 G_1 G_8 I_9 I_10 
Stack 5
F_2 G_6 J_3 L_7 D_1 
Stack 6
O_4 K_1 D_0 H_0 D_2 
Stack 7
E_5 M_5 G_9 L_4 B_1 
Stack 8
I_5 J_0 C_2 M_0 F_8 
Stack 9
C_3 H_6 D_3 O_0 K_5 
Stack 10
E_4 G_7 E_6 N_3 F_5 
Stack 11
B_0 M_3 E_8 L_0 H_11 
Stack 12
N_0 I_0 H_2 E_2 K_8 
Stack 13
O_1 J_7 D_7 D_5 E_0 
Stack 14
G_0 A_3 C_5 A_1 B_4 
Stack 15
H_1 L_6 H_8 L_2 O_2 
Stack 16
D_4 H_5 B_5 M_4 K_0 
Stack 17
I_2 G_5 E_3 E_7 M_2 
Stack 18
G_2 E_1 K_2 F_3 H_7 
Stack 19
I_1 G_4 F_0 O_3 F_1 
Stack 20
N_4 K_6 H_4 A_4 B_2 
Stack 21
G_3 J_1 H_10 I_3 B_3 
Stack 22
J_5 L_3 G_10 F_6 N_5 
Stack 23
C_4 I_8 J_9 K_3 K_7 
Stack 24
J_6 J_2 F_4 A_2 L_1 
