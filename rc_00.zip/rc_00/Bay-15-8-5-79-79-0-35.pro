Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_2 E_9 B_1 C_7 E_5 A_5 
Stack 2
C_5 E_11 C_12 D_1 D_7 A_12 
Stack 3
C_16 B_5 E_10 B_6 C_13 A_10 
Stack 4
E_2 D_15 D_12 E_14 E_7 C_0 
Stack 5
A_14 D_0 D_9 E_1 C_14 
Stack 6
A_8 D_11 B_7 E_12 A_7 
Stack 7
C_4 B_14 D_3 B_8 A_9 
Stack 8
A_3 B_11 B_12 B_13 C_2 
Stack 9
D_4 C_15 E_4 E_6 A_4 
Stack 10
D_8 A_6 E_8 B_10 B_4 
Stack 11
B_15 D_2 E_0 A_2 B_0 
Stack 12
C_9 A_1 B_3 D_13 B_9 
Stack 13
A_11 D_10 C_10 C_8 C_6 
Stack 14
D_6 A_13 D_14 A_0 E_13 
Stack 15
C_1 C_11 D_5 E_3 C_3 
