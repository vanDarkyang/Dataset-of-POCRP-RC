Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_0 D_0 G_4 G_2 E_4 
Stack 2
H_1 C_0 I_3 J_2 F_2 
Stack 3
F_1 D_2 A_0 H_3 E_1 
Stack 4
G_5 H_0 I_2 D_5 I_0 
Stack 5
I_1 G_3 C_3 F_6 E_2 
Stack 6
F_4 D_1 E_6 H_2 E_5 
Stack 7
A_2 D_4 C_1 A_1 C_4 
Stack 8
D_3 B_1 J_1 F_5 C_2 
Stack 9
J_0 F_0 F_3 B_2 E_0 
Stack 10
H_4 E_3 G_1 G_0 B_3 
