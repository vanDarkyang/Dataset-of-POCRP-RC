Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 F_4 A_3 D_3 H_2 
Stack 2
G_4 A_0 G_5 H_5 H_6 
Stack 3
E_6 J_4 C_6 G_2 B_4 
Stack 4
H_0 F_3 G_7 E_2 B_5 
Stack 5
E_0 B_0 E_7 I_3 J_2 
Stack 6
C_5 H_3 A_1 B_1 C_4 
Stack 7
C_0 F_1 D_4 I_2 G_0 
Stack 8
B_2 C_2 D_0 F_2 F_8 
Stack 9
H_1 J_3 D_5 G_6 E_4 
Stack 10
D_6 J_1 F_5 I_0 J_0 
Stack 11
E_5 G_1 I_5 F_6 G_3 
Stack 12
F_7 E_8 E_3 B_3 E_1 
Stack 13
C_1 D_2 I_4 A_2 A_4 
Stack 14
D_7 I_1 D_1 H_4 F_0 
