Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_6 F_1 D_7 A_9 J_0 D_5 
Stack 2
I_5 C_2 H_8 J_7 I_10 G_2 
Stack 3
C_9 J_9 E_11 A_1 C_4 H_10 
Stack 4
G_8 E_12 G_1 D_11 F_13 D_4 
Stack 5
J_3 C_10 C_8 A_6 E_3 E_4 
Stack 6
B_6 I_2 C_11 G_12 J_2 
Stack 7
D_12 E_5 B_1 F_6 B_3 
Stack 8
G_3 C_7 C_0 H_7 B_8 
Stack 9
F_7 F_12 D_1 C_1 F_2 
Stack 10
F_5 G_6 E_0 I_3 D_8 
Stack 11
A_2 A_7 F_9 A_4 F_4 
Stack 12
C_5 D_2 F_11 B_4 I_8 
Stack 13
C_6 D_10 G_9 H_4 B_7 
Stack 14
E_8 G_0 H_2 E_1 H_1 
Stack 15
H_3 D_9 I_1 I_0 E_7 
Stack 16
I_4 J_4 B_5 J_6 G_10 
Stack 17
D_3 G_5 B_10 H_0 A_3 
Stack 18
G_4 C_3 H_6 H_5 E_10 
Stack 19
E_6 E_9 H_11 E_13 J_1 
Stack 20
J_5 A_8 G_11 B_0 A_5 
Stack 21
H_9 B_9 I_9 F_8 G_7 
Stack 22
J_8 I_7 F_10 A_0 F_0 
Stack 23
F_3 D_0 B_2 I_6 E_2 
