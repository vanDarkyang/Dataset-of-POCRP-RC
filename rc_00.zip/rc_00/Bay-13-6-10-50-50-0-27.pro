Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 D_5 J_0 C_3 
Stack 2
C_2 E_0 F_0 C_4 
Stack 3
B_2 H_0 J_1 H_1 
Stack 4
E_2 G_4 A_0 G_2 
Stack 5
F_1 D_2 I_1 B_3 
Stack 6
I_0 B_1 C_0 F_4 
Stack 7
E_1 H_4 H_3 F_6 
Stack 8
D_1 F_5 C_1 G_3 
Stack 9
E_5 J_2 G_1 E_3 
Stack 10
D_0 F_3 I_3 H_2 
Stack 11
D_3 D_4 E_4 G_5 
Stack 12
E_6 G_0 A_2 
Stack 13
I_2 B_0 F_2 
