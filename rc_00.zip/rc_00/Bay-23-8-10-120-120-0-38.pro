Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_0 D_8 D_5 J_4 E_10 I_3 
Stack 2
C_6 G_8 E_12 F_7 I_8 C_10 
Stack 3
H_7 G_10 A_3 E_3 E_1 F_11 
Stack 4
E_13 A_0 I_4 A_6 F_9 I_1 
Stack 5
I_5 G_1 G_5 F_2 J_7 F_6 
Stack 6
F_8 I_2 A_4 D_3 D_4 
Stack 7
A_7 E_2 I_7 J_5 J_9 
Stack 8
J_2 I_0 F_10 E_6 H_11 
Stack 9
A_5 A_1 H_4 C_4 G_2 
Stack 10
G_11 H_6 D_12 E_7 B_7 
Stack 11
H_8 C_5 F_1 D_9 G_7 
Stack 12
A_2 C_0 A_8 J_1 F_13 
Stack 13
E_11 E_4 B_9 G_9 D_2 
Stack 14
D_6 G_6 A_9 B_5 B_8 
Stack 15
F_4 H_3 H_2 B_1 B_6 
Stack 16
D_0 J_0 I_9 H_5 B_2 
Stack 17
E_5 D_10 J_6 C_7 G_4 
Stack 18
F_0 I_10 F_3 B_0 D_7 
Stack 19
E_9 H_9 B_10 E_0 C_3 
Stack 20
C_8 B_4 E_8 D_1 H_10 
Stack 21
C_1 I_6 C_11 C_2 G_3 
Stack 22
F_5 G_0 C_9 F_12 H_1 
Stack 23
B_3 G_12 J_8 J_3 D_11 
