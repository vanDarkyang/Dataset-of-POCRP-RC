Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_8 E_9 C_12 D_0 A_8 B_9 
Stack 2
B_5 D_12 D_3 B_13 E_10 E_1 
Stack 3
B_4 E_3 E_7 D_9 C_2 B_10 
Stack 4
D_4 A_7 D_14 C_7 B_14 B_11 
Stack 5
A_13 E_11 A_11 B_2 B_12 
Stack 6
A_6 B_8 C_5 A_3 E_14 
Stack 7
A_5 A_2 D_11 E_12 E_13 
Stack 8
D_7 B_1 B_15 C_14 B_6 
Stack 9
C_6 D_8 C_13 A_9 B_3 
Stack 10
C_1 A_4 A_0 C_9 D_2 
Stack 11
E_0 D_15 C_4 E_8 E_2 
Stack 12
D_1 D_6 A_12 C_3 C_11 
Stack 13
D_5 C_0 C_15 D_10 C_10 
Stack 14
A_14 A_1 B_0 B_7 D_13 
Stack 15
E_6 C_16 A_10 E_4 E_5 
