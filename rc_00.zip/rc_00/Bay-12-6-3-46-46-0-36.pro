Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_8 B_2 C_10 C_3 
Stack 2
C_4 B_14 A_9 B_0 
Stack 3
A_6 A_2 C_6 C_2 
Stack 4
A_11 B_11 B_1 B_12 
Stack 5
C_0 C_7 A_14 C_11 
Stack 6
A_7 C_8 A_1 B_10 
Stack 7
A_13 B_4 B_13 C_13 
Stack 8
B_3 C_1 A_0 C_14 
Stack 9
A_8 B_15 C_5 B_5 
Stack 10
C_12 A_3 B_6 B_7 
Stack 11
B_9 A_12 C_9 
Stack 12
A_4 A_10 A_5 
