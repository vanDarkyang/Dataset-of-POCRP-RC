Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 E_0 E_8 C_9 
Stack 2
E_1 A_5 D_2 D_0 
Stack 3
A_3 C_8 C_10 D_10 
Stack 4
C_5 A_8 B_4 E_6 
Stack 5
C_4 E_2 E_4 D_5 
Stack 6
E_7 A_7 B_7 A_4 
Stack 7
B_2 B_9 D_1 D_8 
Stack 8
B_1 D_6 A_2 A_0 
Stack 9
C_11 D_3 B_0 B_3 
Stack 10
B_8 D_4 C_3 E_5 
Stack 11
E_9 C_2 E_3 C_6 
Stack 12
C_1 B_5 C_0 D_7 
Stack 13
A_6 B_10 D_9 
Stack 14
C_7 A_9 B_6 
