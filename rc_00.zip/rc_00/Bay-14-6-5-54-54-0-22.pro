Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_0 E_2 C_8 A_4 
Stack 2
C_7 D_0 C_0 D_2 
Stack 3
D_3 A_1 C_6 C_4 
Stack 4
B_2 C_1 B_6 D_9 
Stack 5
A_9 B_3 A_3 D_8 
Stack 6
C_10 E_5 B_10 D_10 
Stack 7
C_5 A_8 C_9 D_5 
Stack 8
E_9 A_0 E_4 A_5 
Stack 9
D_4 C_11 D_6 B_4 
Stack 10
D_1 E_0 B_5 A_7 
Stack 11
E_7 D_7 E_8 B_1 
Stack 12
E_6 B_9 C_3 B_7 
Stack 13
E_1 E_3 A_2 
Stack 14
C_2 B_8 A_6 
