Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_11 C_7 E_11 C_10 C_5 B_14 
Stack 2
B_2 A_10 E_13 B_0 E_2 E_14 
Stack 3
D_10 E_3 C_9 C_8 E_6 B_12 
Stack 4
B_15 C_3 C_14 A_14 D_13 B_1 
Stack 5
D_0 C_1 B_4 B_7 D_4 
Stack 6
A_3 C_6 A_12 D_7 E_0 
Stack 7
C_15 C_2 C_16 E_1 D_5 
Stack 8
A_7 D_8 D_15 E_7 E_10 
Stack 9
B_11 A_13 A_4 D_12 A_1 
Stack 10
B_3 A_2 A_9 A_6 B_5 
Stack 11
C_4 B_9 A_5 C_12 D_1 
Stack 12
E_9 B_6 E_8 E_12 E_4 
Stack 13
A_0 D_2 D_14 C_0 E_5 
Stack 14
B_13 D_11 D_3 B_8 B_10 
Stack 15
D_9 C_13 D_6 A_8 C_11 
