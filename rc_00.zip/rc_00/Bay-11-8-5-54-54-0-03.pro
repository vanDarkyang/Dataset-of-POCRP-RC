Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_9 B_4 D_4 B_6 B_10 
Stack 2
A_8 A_5 D_0 E_2 C_6 
Stack 3
D_3 C_9 D_5 E_6 B_5 
Stack 4
D_6 D_8 B_3 B_2 D_10 
Stack 5
A_0 C_3 B_7 C_5 B_0 
Stack 6
C_0 C_1 B_1 C_7 E_9 
Stack 7
C_10 A_2 E_1 C_11 A_7 
Stack 8
E_8 C_8 A_1 E_3 D_7 
Stack 9
A_6 C_2 E_5 A_3 D_1 
Stack 10
D_9 A_9 E_4 E_0 C_4 
Stack 11
B_8 D_2 A_4 E_7 
