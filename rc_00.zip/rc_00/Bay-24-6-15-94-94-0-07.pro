Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_5 G_4 D_1 B_0 
Stack 2
G_0 J_2 H_6 F_6 
Stack 3
B_1 O_1 G_3 O_2 
Stack 4
H_4 G_7 I_6 L_1 
Stack 5
I_4 O_0 H_5 F_2 
Stack 6
C_2 E_2 G_2 I_8 
Stack 7
N_0 L_2 E_3 J_3 
Stack 8
E_4 D_0 N_2 H_1 
Stack 9
J_4 M_1 I_5 I_3 
Stack 10
K_5 F_4 J_5 G_8 
Stack 11
B_3 F_1 J_7 H_3 
Stack 12
M_4 F_5 E_1 H_2 
Stack 13
L_5 I_0 E_0 N_1 
Stack 14
K_3 H_0 M_3 L_3 
Stack 15
I_7 K_0 A_2 K_1 
Stack 16
A_1 H_7 G_5 A_0 
Stack 17
D_3 C_0 F_3 I_2 
Stack 18
J_0 D_5 D_4 F_7 
Stack 19
L_0 C_3 C_1 H_8 
Stack 20
I_1 K_2 M_2 N_3 
Stack 21
H_9 E_6 B_2 G_1 
Stack 22
J_1 L_4 G_6 D_2 
Stack 23
C_4 K_6 F_0 
Stack 24
K_4 M_0 J_6 
