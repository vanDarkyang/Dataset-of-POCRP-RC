Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 A_3 E_12 C_16 A_11 E_14 
Stack 2
D_2 E_8 B_2 C_3 D_6 B_0 
Stack 3
A_13 B_1 C_0 D_0 C_15 E_10 
Stack 4
A_2 E_9 C_9 D_11 B_14 B_13 
Stack 5
E_5 B_8 D_15 A_7 E_2 
Stack 6
C_11 E_7 A_8 A_12 B_11 
Stack 7
E_3 A_5 C_8 C_7 A_14 
Stack 8
A_9 D_8 B_9 A_4 D_3 
Stack 9
D_13 D_12 A_10 A_1 C_10 
Stack 10
D_7 E_1 B_6 B_7 B_12 
Stack 11
D_9 B_3 B_5 B_4 E_6 
Stack 12
C_6 D_14 C_12 A_6 D_5 
Stack 13
C_1 C_4 E_4 A_0 B_10 
Stack 14
C_13 E_0 E_13 C_2 C_5 
Stack 15
D_4 D_10 B_15 E_11 C_14 
