Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_1 C_13 C_6 C_11 
Stack 2
C_8 A_3 A_10 B_5 
Stack 3
A_1 B_12 A_12 C_7 
Stack 4
A_7 A_2 C_12 A_6 
Stack 5
B_1 C_14 B_11 A_11 
Stack 6
B_15 B_14 A_8 B_9 
Stack 7
A_0 B_4 A_14 B_0 
Stack 8
C_9 A_4 B_8 B_10 
Stack 9
A_13 C_4 C_10 B_3 
Stack 10
C_2 C_3 C_0 B_2 
Stack 11
C_5 B_7 B_6 
Stack 12
B_13 A_9 A_5 
