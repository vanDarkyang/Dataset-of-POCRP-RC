Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_3 A_9 B_6 B_3 
Stack 2
B_5 B_9 C_9 C_5 
Stack 3
A_4 C_2 A_8 D_7 
Stack 4
E_7 D_2 E_5 E_3 
Stack 5
D_0 C_7 A_7 E_1 
Stack 6
D_9 A_5 D_8 D_5 
Stack 7
D_1 C_6 E_8 E_9 
Stack 8
A_0 E_2 B_7 D_6 
Stack 9
C_11 C_10 D_3 A_2 
Stack 10
B_1 C_1 C_0 A_6 
Stack 11
B_8 B_0 D_10 B_4 
Stack 12
C_3 C_4 B_2 D_4 
Stack 13
B_10 C_8 E_0 
Stack 14
E_6 E_4 A_1 
