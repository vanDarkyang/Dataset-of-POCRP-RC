Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_2 B_3 C_3 A_0 E_1 
Stack 2
E_0 B_8 D_2 A_9 E_2 
Stack 3
C_0 C_9 D_4 D_7 B_10 
Stack 4
A_5 C_10 D_6 E_6 A_4 
Stack 5
E_8 A_8 D_8 E_4 C_2 
Stack 6
E_7 D_5 B_5 E_9 B_7 
Stack 7
A_1 A_7 D_1 D_10 A_2 
Stack 8
B_6 B_9 E_3 D_3 D_9 
Stack 9
C_1 C_5 C_4 E_5 A_3 
Stack 10
B_4 B_0 C_6 B_1 C_8 
Stack 11
C_11 C_7 D_0 A_6 
