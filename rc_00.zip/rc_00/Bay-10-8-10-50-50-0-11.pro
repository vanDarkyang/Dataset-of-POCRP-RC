Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_5 E_0 H_0 C_4 E_6 
Stack 2
E_3 J_1 E_1 J_2 G_2 
Stack 3
C_2 D_1 I_1 I_3 C_1 
Stack 4
G_4 E_4 G_0 J_0 I_0 
Stack 5
B_1 D_0 F_0 G_3 B_3 
Stack 6
F_1 H_4 C_0 A_2 D_5 
Stack 7
D_3 G_5 F_4 E_2 H_3 
Stack 8
F_3 F_2 H_2 D_2 I_2 
Stack 9
D_4 H_1 G_1 C_3 A_0 
Stack 10
F_6 B_0 A_1 F_5 B_2 
