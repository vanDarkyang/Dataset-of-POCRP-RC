Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_3 A_3 D_5 E_0 
Stack 2
A_9 D_0 B_4 D_9 
Stack 3
C_10 D_1 B_8 C_5 
Stack 4
C_1 C_7 B_9 D_10 
Stack 5
E_1 E_3 B_3 A_0 
Stack 6
D_2 E_4 A_6 C_6 
Stack 7
E_5 B_6 D_7 E_2 
Stack 8
D_4 B_1 B_2 A_7 
Stack 9
A_5 C_4 B_0 E_9 
Stack 10
E_7 E_6 A_2 A_4 
Stack 11
C_11 D_8 E_8 C_0 
Stack 12
C_3 B_10 D_6 B_5 
Stack 13
C_2 C_9 A_1 
Stack 14
B_7 C_8 A_8 
