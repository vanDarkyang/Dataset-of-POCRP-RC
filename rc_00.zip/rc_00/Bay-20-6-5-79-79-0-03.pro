Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 E_7 B_5 A_11 
Stack 2
D_2 A_5 C_12 D_6 
Stack 3
A_13 D_8 E_4 C_15 
Stack 4
A_2 D_12 E_13 B_14 
Stack 5
E_5 E_1 B_15 E_2 
Stack 6
C_11 B_3 C_16 B_11 
Stack 7
E_3 D_14 C_3 A_14 
Stack 8
A_9 C_4 D_0 D_3 
Stack 9
D_13 E_0 D_11 C_10 
Stack 10
D_7 D_10 A_7 B_12 
Stack 11
D_9 E_12 A_12 E_6 
Stack 12
C_6 B_2 C_7 D_5 
Stack 13
C_1 C_0 A_4 B_10 
Stack 14
C_13 C_9 A_1 C_5 
Stack 15
D_4 D_15 B_7 C_14 
Stack 16
A_3 A_8 B_4 E_14 
Stack 17
E_8 C_8 A_6 B_0 
Stack 18
B_1 B_9 A_0 E_10 
Stack 19
E_9 A_10 C_2 B_13 
Stack 20
B_8 B_6 E_11 
