Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 I_2 G_5 H_0 
Stack 2
D_5 C_4 A_1 F_4 
Stack 3
D_2 G_4 D_4 H_4 
Stack 4
F_1 G_3 F_5 E_5 
Stack 5
C_3 I_3 D_3 J_2 
Stack 6
F_3 E_2 D_0 F_6 
Stack 7
J_1 H_2 E_0 A_2 
Stack 8
C_1 F_2 G_2 C_2 
Stack 9
G_0 E_6 I_0 A_0 
Stack 10
G_1 E_3 F_0 H_1 
Stack 11
C_0 B_3 B_0 D_1 
Stack 12
H_3 J_0 E_1 
Stack 13
E_4 B_2 I_1 
