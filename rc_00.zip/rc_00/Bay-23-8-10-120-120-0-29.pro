Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_11 E_6 C_2 F_11 G_3 F_3 
Stack 2
F_8 C_10 H_9 J_8 F_4 A_7 
Stack 3
E_9 E_4 A_3 H_3 I_6 E_7 
Stack 4
E_3 A_8 J_6 H_11 B_9 J_9 
Stack 5
H_7 F_12 C_7 J_7 D_2 E_11 
Stack 6
D_10 G_9 I_5 G_10 H_6 
Stack 7
E_2 A_4 C_3 I_9 G_5 
Stack 8
B_3 D_8 I_10 I_3 E_5 
Stack 9
B_10 D_7 D_1 I_7 D_6 
Stack 10
F_5 I_4 E_13 F_10 G_8 
Stack 11
C_1 H_4 A_9 J_4 E_12 
Stack 12
H_5 J_0 C_9 E_10 G_6 
Stack 13
H_0 F_13 I_1 J_3 E_1 
Stack 14
J_5 A_0 G_1 C_0 J_2 
Stack 15
A_5 B_4 B_5 D_12 E_0 
Stack 16
F_9 F_2 I_2 F_7 G_12 
Stack 17
F_1 G_7 D_4 F_6 B_7 
Stack 18
B_0 H_1 J_1 H_10 A_2 
Stack 19
C_4 D_11 G_11 D_5 I_0 
Stack 20
D_0 E_8 D_3 A_1 H_2 
Stack 21
B_2 B_6 A_6 H_8 C_8 
Stack 22
C_5 G_2 G_0 C_6 D_9 
Stack 23
F_0 B_1 B_8 I_8 G_4 
