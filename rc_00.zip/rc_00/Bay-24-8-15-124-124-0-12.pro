Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 H_5 E_0 O_2 N_5 H_6 
Stack 2
N_3 J_6 N_4 M_3 I_1 H_3 
Stack 3
F_3 O_0 I_2 I_10 G_3 G_8 
Stack 4
L_7 I_8 L_2 M_5 G_2 I_5 
Stack 5
E_3 F_2 J_9 L_0 A_3 
Stack 6
H_9 F_1 L_1 F_5 F_9 
Stack 7
D_0 F_7 D_2 B_5 E_2 
Stack 8
M_0 E_7 K_8 O_3 L_6 
Stack 9
C_2 I_3 H_8 G_7 M_2 
Stack 10
B_3 B_1 H_10 A_4 K_6 
Stack 11
J_7 F_6 J_2 M_1 C_1 
Stack 12
E_8 G_5 B_2 I_0 M_4 
Stack 13
H_1 O_1 H_0 M_6 H_4 
Stack 14
H_11 F_8 E_6 J_5 N_0 
Stack 15
F_0 F_4 K_2 K_4 G_10 
Stack 16
C_6 C_0 D_6 E_4 N_1 
Stack 17
B_0 L_5 C_3 L_4 D_1 
Stack 18
K_0 G_1 K_3 O_4 I_6 
Stack 19
G_0 D_4 I_7 D_7 K_7 
Stack 20
C_4 K_5 D_5 B_4 J_3 
Stack 21
E_5 H_2 G_4 D_3 E_1 
Stack 22
I_9 H_7 K_1 A_0 C_5 
Stack 23
J_1 L_3 A_2 G_9 G_6 
Stack 24
N_2 J_0 J_4 J_8 I_4 
