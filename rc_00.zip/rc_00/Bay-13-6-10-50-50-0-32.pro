Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_1 E_1 C_4 B_2 
Stack 2
F_5 C_3 D_1 A_0 
Stack 3
D_5 F_1 F_2 H_2 
Stack 4
D_0 E_5 B_0 D_3 
Stack 5
J_0 E_0 I_1 H_4 
Stack 6
E_3 F_6 C_1 B_3 
Stack 7
I_2 H_0 C_2 G_2 
Stack 8
F_0 I_3 A_2 J_1 
Stack 9
D_4 C_0 D_2 G_0 
Stack 10
G_3 H_3 B_1 G_5 
Stack 11
I_0 G_4 F_4 E_2 
Stack 12
A_1 F_3 G_1 
Stack 13
J_2 E_4 E_6 
