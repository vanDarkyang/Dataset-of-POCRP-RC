Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_2 F_8 E_1 H_3 
Stack 2
F_0 F_6 H_6 D_3 
Stack 3
D_6 G_2 A_4 E_3 
Stack 4
C_5 A_1 D_0 B_0 
Stack 5
A_2 G_6 J_0 J_3 
Stack 6
I_2 H_1 G_7 G_5 
Stack 7
B_5 G_0 I_4 G_4 
Stack 8
J_2 D_5 I_0 C_2 
Stack 9
C_1 F_3 B_4 E_5 
Stack 10
G_1 F_2 E_8 D_2 
Stack 11
C_0 E_6 H_5 F_4 
Stack 12
C_4 E_4 B_3 A_3 
Stack 13
G_3 D_7 C_6 A_0 
Stack 14
F_5 F_1 E_0 J_4 
Stack 15
H_2 E_7 F_7 C_3 
Stack 16
D_1 B_1 H_4 I_3 
Stack 17
D_4 I_5 J_1 
Stack 18
I_1 B_2 H_0 
