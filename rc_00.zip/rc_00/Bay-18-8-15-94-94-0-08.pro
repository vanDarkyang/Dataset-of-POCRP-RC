Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
N_0 G_6 L_5 M_1 B_0 J_1 
Stack 2
G_2 F_5 J_7 H_0 K_5 K_4 
Stack 3
C_0 A_2 G_4 K_1 C_4 M_3 
Stack 4
H_1 H_8 M_0 L_3 J_6 E_6 
Stack 5
O_0 H_4 N_3 K_0 H_9 
Stack 6
D_3 I_1 B_2 I_2 K_3 
Stack 7
F_3 I_3 J_5 I_0 E_2 
Stack 8
H_3 H_2 N_1 H_7 D_2 
Stack 9
E_1 L_0 I_5 L_4 N_2 
Stack 10
I_6 F_1 M_2 A_0 I_8 
Stack 11
A_1 H_5 G_7 G_8 E_4 
Stack 12
F_0 J_0 L_2 K_6 E_5 
Stack 13
D_5 C_3 E_0 D_4 O_1 
Stack 14
F_4 G_5 G_0 D_0 G_1 
Stack 15
J_2 L_1 G_3 I_7 F_6 
Stack 16
B_3 J_4 I_4 O_2 B_1 
Stack 17
C_1 M_4 F_2 E_3 C_2 
Stack 18
H_6 J_3 F_7 K_2 D_1 
