Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_6 A_5 A_1 C_2 
Stack 2
A_2 B_3 C_14 C_13 
Stack 3
A_14 A_7 B_12 B_10 
Stack 4
C_0 B_11 C_12 C_1 
Stack 5
B_13 B_14 B_4 C_11 
Stack 6
C_9 B_5 A_0 B_8 
Stack 7
C_3 A_9 C_6 A_3 
Stack 8
C_10 B_7 B_2 C_5 
Stack 9
B_6 A_11 C_7 C_8 
Stack 10
B_1 A_13 B_9 C_4 
Stack 11
A_12 B_15 A_4 
Stack 12
B_0 A_10 A_8 
