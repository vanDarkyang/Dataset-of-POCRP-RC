Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_4 C_4 F_0 F_7 E_0 G_7 
Stack 2
G_4 L_1 H_6 A_1 J_4 L_3 
Stack 3
J_2 B_3 A_0 A_2 H_8 M_2 
Stack 4
C_0 D_0 L_4 G_3 F_1 L_2 
Stack 5
N_1 I_1 D_5 K_6 C_2 
Stack 6
E_5 I_4 J_6 J_0 L_0 
Stack 7
I_2 J_7 I_8 I_6 E_6 
Stack 8
D_3 N_3 G_2 G_0 O_2 
Stack 9
J_3 K_3 B_2 J_5 G_8 
Stack 10
F_3 M_0 H_5 M_1 E_3 
Stack 11
K_1 N_0 M_3 I_0 E_1 
Stack 12
D_2 I_3 D_1 C_1 K_0 
Stack 13
O_1 I_5 H_9 K_5 N_2 
Stack 14
M_4 O_0 F_2 E_4 E_2 
Stack 15
F_5 K_4 L_5 K_2 G_5 
Stack 16
D_4 F_4 H_2 J_1 F_6 
Stack 17
B_1 C_3 I_7 H_1 H_7 
Stack 18
H_0 B_0 G_1 H_3 G_6 
