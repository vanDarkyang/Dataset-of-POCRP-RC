Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 D_2 A_1 F_0 
Stack 2
F_5 G_0 D_5 G_3 
Stack 3
J_1 F_3 I_2 E_6 
Stack 4
C_1 E_1 B_3 E_2 
Stack 5
E_4 I_3 D_0 F_2 
Stack 6
C_2 C_3 D_3 F_4 
Stack 7
A_0 C_4 I_0 G_5 
Stack 8
I_1 G_1 G_2 B_2 
Stack 9
C_0 D_4 J_0 F_1 
Stack 10
J_2 E_0 B_0 H_1 
Stack 11
H_3 D_1 G_4 A_2 
Stack 12
E_3 H_0 H_4 
Stack 13
E_5 H_2 F_6 
