Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 F_1 D_6 H_4 G_5 
Stack 2
C_2 G_0 I_5 B_5 B_1 
Stack 3
D_2 D_0 H_2 G_3 F_6 
Stack 4
F_4 C_6 C_0 G_4 A_0 
Stack 5
E_0 I_0 J_1 B_2 B_0 
Stack 6
G_6 H_5 A_1 E_5 A_2 
Stack 7
J_2 F_0 F_5 H_1 J_3 
Stack 8
I_2 D_5 D_4 E_4 E_7 
Stack 9
E_2 H_0 E_1 F_8 G_2 
Stack 10
B_3 E_6 J_4 C_4 I_1 
Stack 11
E_8 H_6 D_1 I_3 F_2 
Stack 12
B_4 F_3 E_3 J_0 D_3 
Stack 13
A_4 D_7 G_7 H_3 I_4 
Stack 14
C_5 F_7 A_3 C_1 G_1 
