Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
N_0 I_3 E_0 B_0 
Stack 2
G_2 H_2 G_0 K_5 
Stack 3
C_0 L_0 G_3 C_4 
Stack 4
H_1 F_1 I_4 J_6 
Stack 5
O_0 H_5 F_2 H_9 
Stack 6
D_3 J_0 F_7 K_3 
Stack 7
F_3 C_3 M_1 E_2 
Stack 8
H_3 G_5 H_0 D_2 
Stack 9
E_1 L_1 K_1 N_2 
Stack 10
I_6 J_4 L_3 I_8 
Stack 11
A_1 M_4 K_0 E_4 
Stack 12
F_0 J_3 I_2 E_5 
Stack 13
D_5 L_5 I_0 O_1 
Stack 14
F_4 J_7 H_7 G_1 
Stack 15
J_2 G_4 L_4 F_6 
Stack 16
B_3 M_0 A_0 B_1 
Stack 17
C_1 N_3 G_8 C_2 
Stack 18
H_6 B_2 K_6 D_1 
Stack 19
G_6 J_5 D_4 J_1 
Stack 20
F_5 N_1 D_0 K_4 
Stack 21
A_2 I_5 I_7 M_3 
Stack 22
H_8 M_2 O_2 E_6 
Stack 23
H_4 G_7 E_3 
Stack 24
I_1 L_2 K_2 
