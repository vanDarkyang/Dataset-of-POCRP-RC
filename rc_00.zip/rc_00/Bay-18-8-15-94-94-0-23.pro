Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
L_0 M_3 K_4 E_4 G_6 G_5 
Stack 2
K_6 I_0 H_4 E_6 G_8 B_2 
Stack 3
A_1 B_1 I_4 J_1 J_7 M_1 
Stack 4
C_3 K_3 H_7 H_6 D_4 F_6 
Stack 5
L_3 F_3 I_1 E_0 N_2 
Stack 6
E_3 G_0 M_0 H_3 H_1 
Stack 7
H_0 C_2 A_2 B_3 G_7 
Stack 8
H_8 J_3 N_1 I_6 O_1 
Stack 9
F_4 C_1 J_4 E_2 E_5 
Stack 10
E_1 L_4 K_1 G_1 G_3 
Stack 11
D_2 F_1 G_2 H_2 I_5 
Stack 12
J_2 F_5 B_0 D_5 H_9 
Stack 13
N_3 I_8 J_6 I_3 D_1 
Stack 14
I_2 D_3 H_5 M_2 N_0 
Stack 15
F_2 K_0 K_5 L_2 A_0 
Stack 16
C_4 L_5 L_1 I_7 M_4 
Stack 17
O_0 G_4 F_7 K_2 D_0 
Stack 18
J_5 C_0 F_0 O_2 J_0 
