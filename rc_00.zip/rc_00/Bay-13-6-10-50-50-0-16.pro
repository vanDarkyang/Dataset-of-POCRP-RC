Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_3 B_2 D_4 H_4 
Stack 2
F_1 J_1 H_1 I_3 
Stack 3
D_1 B_1 A_1 I_2 
Stack 4
B_3 D_5 I_0 C_2 
Stack 5
B_0 A_2 E_0 E_1 
Stack 6
G_1 C_4 C_3 D_3 
Stack 7
F_3 E_6 E_3 F_2 
Stack 8
F_5 J_0 F_6 G_0 
Stack 9
D_0 G_2 H_2 D_2 
Stack 10
E_2 F_0 I_1 J_2 
Stack 11
G_4 H_0 G_3 G_5 
Stack 12
A_0 C_0 E_5 
Stack 13
E_4 C_1 F_4 
