Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_4 D_0 B_2 F_1 I_1 
Stack 2
F_3 H_1 F_2 J_2 C_0 
Stack 3
J_1 D_2 H_0 E_3 D_5 
Stack 4
I_0 G_4 F_6 E_6 H_2 
Stack 5
C_3 E_1 D_4 F_5 J_0 
Stack 6
F_0 G_1 B_3 G_5 I_2 
Stack 7
A_2 A_1 D_3 A_0 D_1 
Stack 8
C_1 G_2 I_3 E_0 C_4 
Stack 9
G_3 E_4 G_0 E_5 E_2 
Stack 10
H_3 B_0 C_2 B_1 H_4 
