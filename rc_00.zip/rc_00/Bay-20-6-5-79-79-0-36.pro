Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_11 B_14 D_0 D_4 
Stack 2
D_8 A_6 E_9 E_1 
Stack 3
D_3 A_14 C_0 C_6 
Stack 4
B_9 A_4 E_14 E_12 
Stack 5
B_10 C_13 E_0 E_6 
Stack 6
B_8 B_1 E_8 D_2 
Stack 7
C_7 C_16 B_2 A_10 
Stack 8
A_9 A_7 B_7 D_12 
Stack 9
E_4 D_9 B_13 E_13 
Stack 10
C_9 E_7 C_3 D_7 
Stack 11
B_11 B_12 E_5 A_8 
Stack 12
A_1 D_14 C_5 E_11 
Stack 13
E_2 B_0 B_6 C_12 
Stack 14
E_3 A_2 C_1 D_1 
Stack 15
C_2 D_6 D_11 C_11 
Stack 16
A_13 A_0 C_8 D_5 
Stack 17
B_15 C_10 D_10 D_13 
Stack 18
A_5 D_15 B_3 C_4 
Stack 19
A_3 B_4 B_5 C_15 
Stack 20
A_12 E_10 C_14 
