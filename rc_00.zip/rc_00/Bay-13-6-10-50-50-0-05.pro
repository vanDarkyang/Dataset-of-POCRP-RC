Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_6 D_2 F_2 B_1 
Stack 2
D_3 H_4 C_0 A_1 
Stack 3
E_6 G_3 A_0 I_2 
Stack 4
J_2 F_3 C_3 D_5 
Stack 5
G_4 B_3 F_0 I_1 
Stack 6
C_2 E_2 I_3 G_0 
Stack 7
E_4 E_5 H_0 F_4 
Stack 8
D_1 D_4 J_1 H_2 
Stack 9
H_3 C_1 H_1 D_0 
Stack 10
C_4 G_2 F_5 G_1 
Stack 11
J_0 I_0 E_0 B_0 
Stack 12
F_1 E_1 B_2 
Stack 13
G_5 E_3 A_2 
