Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_2 E_3 I_3 J_1 
Stack 2
E_4 G_2 D_1 B_2 
Stack 3
C_0 I_0 E_5 F_6 
Stack 4
B_0 C_1 A_2 J_2 
Stack 5
D_4 C_3 E_0 E_1 
Stack 6
F_5 G_5 D_3 D_2 
Stack 7
H_3 F_0 G_4 E_6 
Stack 8
H_0 I_1 A_1 C_2 
Stack 9
A_0 F_2 J_0 C_4 
Stack 10
F_4 G_3 G_1 H_1 
Stack 11
D_0 B_3 H_4 F_1 
Stack 12
F_3 B_1 E_2 
Stack 13
I_2 G_0 D_5 
