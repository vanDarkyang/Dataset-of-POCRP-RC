Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_1 I_5 L_0 I_1 L_4 F_7 
Stack 2
E_2 G_0 F_4 G_3 O_2 G_6 
Stack 3
M_3 D_0 C_2 H_4 I_2 H_7 
Stack 4
M_4 H_9 I_7 K_6 K_3 O_1 
Stack 5
J_5 G_7 C_1 H_1 D_1 
Stack 6
B_0 H_8 H_6 K_0 K_1 
Stack 7
H_3 F_3 C_4 F_0 C_3 
Stack 8
L_2 L_3 N_2 O_0 D_4 
Stack 9
C_0 J_3 I_3 K_4 K_2 
Stack 10
M_1 N_3 A_2 D_3 E_4 
Stack 11
I_0 F_6 M_2 L_5 E_3 
Stack 12
K_5 J_7 F_5 G_2 D_2 
Stack 13
E_5 F_2 F_1 D_5 H_5 
Stack 14
A_1 I_6 I_8 E_0 J_4 
Stack 15
J_2 L_1 H_0 J_1 A_0 
Stack 16
E_6 G_4 G_1 B_2 N_0 
Stack 17
B_3 J_6 H_2 G_5 N_1 
Stack 18
J_0 B_1 I_4 G_8 M_0 
