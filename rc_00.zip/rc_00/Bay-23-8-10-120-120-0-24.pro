Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_6 H_9 C_10 H_6 E_4 B_7 
Stack 2
H_0 J_6 E_10 C_1 A_7 J_1 
Stack 3
C_2 I_4 C_3 I_9 B_4 E_5 
Stack 4
E_1 H_2 J_5 F_11 F_9 A_8 
Stack 5
I_5 E_0 B_2 D_0 E_3 F_5 
Stack 6
B_8 D_9 G_6 D_1 G_0 
Stack 7
E_9 G_7 F_4 G_11 B_10 
Stack 8
H_5 H_8 H_10 B_6 A_9 
Stack 9
D_5 A_0 I_2 E_13 E_12 
Stack 10
J_2 F_7 B_1 E_7 F_8 
Stack 11
C_7 C_5 J_3 I_3 E_8 
Stack 12
F_12 A_5 I_10 G_8 C_8 
Stack 13
F_2 F_10 D_6 H_3 G_1 
Stack 14
C_4 D_2 H_11 I_7 J_0 
Stack 15
D_7 G_10 C_0 G_12 H_1 
Stack 16
F_13 C_11 G_5 B_0 D_8 
Stack 17
B_3 J_7 C_6 A_2 H_7 
Stack 18
B_9 D_3 I_6 E_2 J_8 
Stack 19
F_6 D_12 I_0 C_9 G_4 
Stack 20
F_0 F_3 A_1 G_3 F_1 
Stack 21
A_3 H_4 A_4 J_9 J_4 
Stack 22
D_4 B_5 I_1 E_6 I_8 
Stack 23
G_2 E_11 G_9 D_11 D_10 
