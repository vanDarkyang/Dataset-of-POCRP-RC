Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_13 E_13 B_11 C_12 D_5 C_10 
Stack 2
A_14 E_12 D_4 A_0 A_9 C_16 
Stack 3
D_14 A_12 A_13 A_6 B_7 B_6 
Stack 4
C_14 A_11 D_7 E_7 D_8 E_9 
Stack 5
D_6 E_4 E_3 E_6 C_8 
Stack 6
C_9 B_14 E_10 B_13 C_13 
Stack 7
D_1 C_2 A_5 C_5 C_3 
Stack 8
E_1 A_8 C_7 E_5 D_11 
Stack 9
D_2 B_2 C_11 B_1 A_3 
Stack 10
B_15 D_0 A_2 C_0 D_15 
Stack 11
C_15 D_10 A_10 B_9 C_6 
Stack 12
B_4 D_9 B_0 E_2 A_1 
Stack 13
D_3 B_10 B_3 B_5 E_14 
Stack 14
A_7 C_4 B_8 E_0 A_4 
Stack 15
D_12 E_11 B_12 C_1 E_8 
