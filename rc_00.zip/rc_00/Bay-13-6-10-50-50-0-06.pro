Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_1 D_0 E_5 D_3 
Stack 2
C_3 E_2 E_4 F_0 
Stack 3
B_0 J_2 B_2 A_2 
Stack 4
B_3 I_1 H_1 F_3 
Stack 5
I_0 D_1 G_0 D_4 
Stack 6
A_0 E_3 A_1 E_0 
Stack 7
I_2 E_6 C_2 H_3 
Stack 8
D_5 F_1 C_4 H_2 
Stack 9
C_1 G_4 F_5 H_0 
Stack 10
F_4 G_1 B_1 F_6 
Stack 11
J_1 F_2 I_3 J_0 
Stack 12
H_4 G_3 C_0 
Stack 13
G_5 G_2 D_2 
