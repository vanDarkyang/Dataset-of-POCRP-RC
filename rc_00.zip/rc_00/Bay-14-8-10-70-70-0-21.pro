Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_3 C_4 D_1 C_6 J_1 
Stack 2
D_2 H_5 G_6 I_5 H_4 
Stack 3
E_1 A_4 D_6 E_7 I_4 
Stack 4
D_4 F_1 C_3 C_5 I_1 
Stack 5
B_2 I_0 F_8 E_8 H_2 
Stack 6
C_2 G_4 B_3 J_2 D_5 
Stack 7
D_7 E_0 A_1 J_3 D_3 
Stack 8
D_0 B_0 C_1 G_2 E_2 
Stack 9
H_3 B_1 B_4 E_6 B_5 
Stack 10
H_6 F_7 G_3 J_4 A_0 
Stack 11
G_5 I_2 F_2 F_0 C_0 
Stack 12
G_7 E_5 E_3 E_4 F_5 
Stack 13
G_1 H_0 A_2 H_1 F_4 
Stack 14
F_3 G_0 A_3 F_6 J_0 
