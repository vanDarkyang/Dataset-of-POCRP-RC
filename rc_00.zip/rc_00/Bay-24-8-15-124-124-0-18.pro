Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_0 F_2 N_3 E_2 A_0 N_4 
Stack 2
M_6 C_6 D_3 K_1 I_5 J_0 
Stack 3
E_3 G_3 A_3 M_5 N_2 M_1 
Stack 4
F_5 K_8 N_1 G_5 B_2 H_9 
Stack 5
I_1 G_6 O_3 H_11 F_6 
Stack 6
C_0 I_2 K_2 D_1 N_5 
Stack 7
D_4 G_2 J_9 I_10 O_1 
Stack 8
E_8 B_5 J_4 G_7 A_1 
Stack 9
H_6 J_6 L_0 G_10 N_0 
Stack 10
E_4 H_1 B_1 O_0 M_2 
Stack 11
M_4 A_4 I_4 D_6 L_2 
Stack 12
F_8 L_3 C_4 D_5 C_1 
Stack 13
H_8 B_3 I_3 L_1 K_3 
Stack 14
J_5 H_2 L_7 G_4 E_6 
Stack 15
J_1 L_5 L_4 K_0 H_4 
Stack 16
I_7 C_3 E_5 E_7 G_9 
Stack 17
D_2 H_0 H_10 C_5 G_8 
Stack 18
C_2 B_0 J_7 A_2 H_3 
Stack 19
K_4 G_1 B_4 F_3 G_0 
Stack 20
L_6 I_9 I_0 O_2 J_8 
Stack 21
K_7 J_3 E_0 E_1 I_8 
Stack 22
F_4 D_7 H_7 F_9 F_7 
Stack 23
M_3 H_5 M_0 K_6 F_1 
Stack 24
I_6 J_2 K_5 O_4 F_0 
