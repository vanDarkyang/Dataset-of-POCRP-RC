Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_11 D_1 D_13 E_13 D_9 C_9 
Stack 2
C_0 E_3 E_12 B_4 E_11 A_9 
Stack 3
D_2 C_5 B_3 A_2 D_12 E_10 
Stack 4
A_5 D_6 D_3 E_9 D_10 A_7 
Stack 5
C_7 D_7 A_4 D_8 E_6 
Stack 6
B_5 A_11 A_3 D_14 A_13 
Stack 7
A_14 B_1 C_11 A_12 E_4 
Stack 8
C_2 B_15 B_14 D_15 C_3 
Stack 9
E_2 C_4 D_5 B_7 D_4 
Stack 10
C_14 B_2 A_10 E_7 C_13 
Stack 11
B_0 B_6 B_12 E_8 B_9 
Stack 12
C_12 C_6 E_14 D_11 A_1 
Stack 13
B_8 E_1 A_0 A_6 E_0 
Stack 14
A_8 C_15 B_13 E_5 B_10 
Stack 15
C_8 C_1 D_0 C_10 C_16 
