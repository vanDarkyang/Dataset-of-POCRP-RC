Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_16 A_1 C_1 B_14 
Stack 2
A_10 C_14 C_15 B_13 
Stack 3
C_4 C_0 D_5 E_3 
Stack 4
B_1 E_14 C_3 E_11 
Stack 5
E_5 C_9 D_4 E_10 
Stack 6
B_7 D_14 A_7 A_12 
Stack 7
B_15 E_12 B_9 D_0 
Stack 8
B_4 B_6 A_0 D_9 
Stack 9
C_6 A_5 B_8 A_8 
Stack 10
C_12 C_11 E_0 B_11 
Stack 11
A_11 C_8 A_4 D_2 
Stack 12
E_9 C_10 D_1 C_2 
Stack 13
D_6 C_13 C_7 A_3 
Stack 14
A_14 E_7 D_13 D_10 
Stack 15
E_1 D_7 B_3 D_12 
Stack 16
B_10 D_15 A_6 B_12 
Stack 17
E_4 E_8 B_5 A_13 
Stack 18
E_13 B_0 D_8 E_2 
Stack 19
A_9 C_5 E_6 D_3 
Stack 20
D_11 B_2 A_2 
