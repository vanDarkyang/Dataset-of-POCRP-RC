Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_0 C_3 H_4 F_3 
Stack 2
D_3 D_5 A_1 F_1 
Stack 3
B_3 A_2 I_0 F_2 
Stack 4
C_6 E_3 B_5 E_6 
Stack 5
D_1 E_2 A_0 I_1 
Stack 6
C_1 H_3 F_4 E_1 
Stack 7
G_5 E_7 C_5 B_2 
Stack 8
C_2 C_0 I_3 J_1 
Stack 9
E_8 E_4 H_2 A_3 
Stack 10
F_7 H_1 J_3 D_6 
Stack 11
B_0 F_5 G_0 I_2 
Stack 12
F_8 H_5 D_0 G_6 
Stack 13
G_1 B_1 I_4 F_6 
Stack 14
I_5 A_4 B_4 F_0 
Stack 15
E_5 D_2 J_0 G_3 
Stack 16
J_4 E_0 C_4 H_6 
Stack 17
G_2 G_4 D_7 
Stack 18
D_4 J_2 G_7 
