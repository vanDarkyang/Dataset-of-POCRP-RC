Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_1 I_0 I_3 I_1 A_0 
Stack 2
F_5 A_1 C_0 C_1 H_2 
Stack 3
D_5 J_2 H_3 C_2 D_3 
Stack 4
D_0 E_1 G_4 A_2 H_4 
Stack 5
J_0 C_3 F_3 D_2 B_3 
Stack 6
E_3 F_1 E_4 B_1 G_2 
Stack 7
I_2 E_5 C_4 F_4 J_1 
Stack 8
F_0 E_0 D_1 G_1 G_0 
Stack 9
D_4 F_6 F_2 E_6 G_5 
Stack 10
G_3 H_0 B_0 B_2 E_2 
