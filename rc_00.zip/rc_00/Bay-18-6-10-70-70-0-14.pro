Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_6 G_1 H_5 D_3 
Stack 2
A_2 A_1 G_7 C_5 
Stack 3
D_4 A_3 F_7 J_0 
Stack 4
F_2 C_1 G_5 C_6 
Stack 5
H_4 B_0 J_4 E_2 
Stack 6
F_4 H_3 J_1 J_2 
Stack 7
C_0 G_0 A_4 D_5 
Stack 8
G_3 C_3 H_6 H_0 
Stack 9
A_0 F_8 D_1 E_8 
Stack 10
B_5 I_5 E_1 I_0 
Stack 11
B_2 D_2 B_4 D_6 
Stack 12
I_4 C_4 I_2 E_3 
Stack 13
E_0 E_4 F_6 J_3 
Stack 14
D_0 B_1 H_2 D_7 
Stack 15
I_1 G_4 I_3 G_2 
Stack 16
E_6 F_5 E_5 H_1 
Stack 17
F_1 C_2 F_0 
Stack 18
B_3 E_7 F_3 
