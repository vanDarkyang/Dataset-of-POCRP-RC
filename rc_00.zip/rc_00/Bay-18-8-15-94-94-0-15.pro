Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_5 K_4 D_2 F_4 G_0 D_3 
Stack 2
G_3 H_1 E_5 J_1 H_5 K_2 
Stack 3
C_3 E_3 K_5 G_8 L_3 M_3 
Stack 4
B_2 E_1 J_0 H_0 H_4 H_8 
Stack 5
G_1 N_3 E_4 K_3 C_2 
Stack 6
O_1 I_0 I_5 N_2 G_4 
Stack 7
N_1 F_7 M_4 D_5 J_6 
Stack 8
A_1 H_6 A_2 K_0 O_2 
Stack 9
D_1 G_2 G_5 N_0 D_4 
Stack 10
D_0 M_0 L_2 I_4 H_2 
Stack 11
A_0 K_6 L_0 O_0 J_3 
Stack 12
B_1 J_7 B_0 C_1 J_4 
Stack 13
I_1 E_0 J_2 M_2 L_5 
Stack 14
E_6 G_6 F_3 I_8 F_2 
Stack 15
C_0 H_7 C_4 I_3 I_2 
Stack 16
G_7 I_7 F_6 H_3 M_1 
Stack 17
F_0 I_6 L_1 L_4 F_1 
Stack 18
B_3 K_1 H_9 F_5 E_2 
