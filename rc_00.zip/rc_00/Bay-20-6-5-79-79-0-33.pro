Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_8 B_8 C_4 A_8 
Stack 2
B_5 A_2 A_12 E_10 
Stack 3
B_4 B_1 C_15 C_2 
Stack 4
D_4 D_8 B_0 B_14 
Stack 5
A_13 A_4 A_10 B_12 
Stack 6
A_6 D_15 D_0 E_14 
Stack 7
A_5 D_6 B_13 E_13 
Stack 8
D_7 C_0 D_9 B_6 
Stack 9
C_6 A_1 C_7 B_3 
Stack 10
C_1 C_16 B_2 D_2 
Stack 11
E_0 C_12 A_3 E_2 
Stack 12
D_1 D_3 E_12 C_11 
Stack 13
D_5 E_7 C_14 C_10 
Stack 14
A_14 D_14 A_9 D_13 
Stack 15
E_6 A_11 C_9 E_5 
Stack 16
E_9 C_5 E_8 B_9 
Stack 17
D_12 D_11 C_3 E_1 
Stack 18
E_3 B_15 D_10 B_10 
Stack 19
A_7 C_13 B_7 B_11 
Stack 20
E_11 A_0 E_4 
