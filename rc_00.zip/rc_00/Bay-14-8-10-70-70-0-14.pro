Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_6 I_1 D_2 A_4 J_0 
Stack 2
A_2 E_6 C_4 H_6 C_6 
Stack 3
D_4 F_1 E_4 D_1 E_2 
Stack 4
F_2 B_3 B_1 E_1 J_2 
Stack 5
H_4 G_1 G_4 B_4 D_5 
Stack 6
F_4 A_1 F_5 I_2 H_0 
Stack 7
C_0 A_3 C_2 F_6 E_8 
Stack 8
G_3 C_1 E_7 H_2 I_0 
Stack 9
A_0 B_0 H_5 I_3 D_6 
Stack 10
B_5 H_3 G_7 E_5 E_3 
Stack 11
B_2 G_0 F_7 F_0 J_3 
Stack 12
I_4 C_3 G_5 F_3 D_7 
Stack 13
E_0 F_8 J_4 D_3 G_2 
Stack 14
D_0 I_5 J_1 C_5 H_1 
