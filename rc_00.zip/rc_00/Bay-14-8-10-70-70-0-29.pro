Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_2 B_0 D_0 G_3 B_1 
Stack 2
A_4 J_3 D_1 A_0 H_6 
Stack 3
G_6 F_4 B_3 H_0 I_1 
Stack 4
C_5 B_5 F_2 A_3 F_8 
Stack 5
J_2 I_3 C_0 I_0 J_0 
Stack 6
I_4 G_7 G_2 G_1 A_1 
Stack 7
C_1 F_1 G_5 F_6 F_0 
Stack 8
H_1 H_3 H_4 B_2 H_2 
Stack 9
E_4 D_6 J_4 D_5 B_4 
Stack 10
C_4 H_5 G_4 G_0 F_3 
Stack 11
D_4 E_0 D_3 E_3 C_3 
Stack 12
F_7 E_1 E_7 C_2 D_7 
Stack 13
J_1 E_5 C_6 E_8 I_2 
Stack 14
E_2 E_6 F_5 I_5 A_2 
