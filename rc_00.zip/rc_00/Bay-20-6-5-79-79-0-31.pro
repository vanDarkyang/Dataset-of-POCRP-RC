Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_0 B_11 C_3 B_14 
Stack 2
E_6 B_15 D_4 B_6 
Stack 3
B_13 C_7 D_12 C_12 
Stack 4
B_9 E_0 E_4 C_8 
Stack 5
C_14 C_9 C_4 C_1 
Stack 6
E_13 D_2 A_14 A_6 
Stack 7
D_6 E_12 A_9 E_8 
Stack 8
D_15 B_8 D_13 B_2 
Stack 9
A_2 B_5 A_13 E_14 
Stack 10
C_16 B_12 D_0 D_3 
Stack 11
D_11 A_3 E_3 A_11 
Stack 12
A_5 A_10 E_5 A_4 
Stack 13
A_0 B_10 B_7 B_3 
Stack 14
C_5 E_2 D_9 E_1 
Stack 15
A_7 C_10 A_8 D_5 
Stack 16
D_8 E_10 B_0 D_10 
Stack 17
A_12 C_2 D_7 C_13 
Stack 18
C_15 A_1 D_1 E_7 
Stack 19
E_11 B_1 C_6 D_14 
Stack 20
E_9 C_11 B_4 
