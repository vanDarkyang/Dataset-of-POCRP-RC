Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 C_5 C_12 A_0 
Stack 2
B_5 C_1 A_5 C_6 
Stack 3
C_0 B_3 B_1 A_12 
Stack 4
B_13 B_0 B_14 A_4 
Stack 5
A_9 C_3 C_7 A_10 
Stack 6
C_2 A_14 B_2 B_4 
Stack 7
C_9 C_14 A_3 B_9 
Stack 8
B_7 B_10 B_6 B_8 
Stack 9
A_11 B_11 A_2 B_15 
Stack 10
A_6 C_11 A_13 C_8 
Stack 11
C_13 C_4 A_7 
Stack 12
C_10 B_12 A_8 
