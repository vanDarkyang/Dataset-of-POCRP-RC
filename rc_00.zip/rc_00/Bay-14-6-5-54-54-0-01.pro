Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_6 B_7 A_2 A_4 
Stack 2
B_10 D_7 E_9 A_5 
Stack 3
C_3 C_4 D_4 A_6 
Stack 4
A_8 E_0 C_11 B_8 
Stack 5
B_0 E_8 B_6 D_0 
Stack 6
A_3 E_5 E_4 D_10 
Stack 7
C_5 C_8 A_0 D_9 
Stack 8
D_2 C_1 C_7 B_1 
Stack 9
D_6 D_3 B_3 B_4 
Stack 10
E_1 C_9 D_5 E_3 
Stack 11
E_7 A_1 B_5 C_10 
Stack 12
C_2 B_2 A_9 D_1 
Stack 13
D_8 A_7 E_6 
Stack 14
C_0 E_2 B_9 
