Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
L_0 C_2 J_6 G_6 
Stack 2
K_6 J_3 H_5 G_8 
Stack 3
A_1 C_1 K_5 J_7 
Stack 4
C_3 L_4 L_1 D_4 
Stack 5
L_3 F_1 F_7 N_2 
Stack 6
E_3 F_5 F_0 H_1 
Stack 7
H_0 I_8 E_4 G_7 
Stack 8
H_8 D_3 E_6 O_1 
Stack 9
F_4 K_0 J_1 E_5 
Stack 10
E_1 L_5 H_6 G_3 
Stack 11
D_2 G_4 E_0 I_5 
Stack 12
J_2 C_0 H_3 H_9 
Stack 13
N_3 K_4 B_3 D_1 
Stack 14
I_2 H_4 I_6 N_0 
Stack 15
F_2 I_4 E_2 A_0 
Stack 16
C_4 H_7 G_1 M_4 
Stack 17
O_0 I_1 H_2 D_0 
Stack 18
J_5 M_0 D_5 J_0 
Stack 19
M_3 A_2 I_3 G_5 
Stack 20
I_0 N_1 M_2 B_2 
Stack 21
B_1 J_4 L_2 M_1 
Stack 22
K_3 K_1 I_7 F_6 
Stack 23
F_3 G_2 K_2 
Stack 24
G_0 B_0 O_2 
