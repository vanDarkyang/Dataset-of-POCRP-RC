Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_6 F_2 I_0 H_4 E_4 
Stack 2
J_1 G_5 A_0 E_3 A_2 
Stack 3
F_4 A_1 B_2 J_0 C_0 
Stack 4
D_1 F_6 B_3 G_3 F_0 
Stack 5
E_0 I_3 G_2 F_3 D_2 
Stack 6
C_4 G_4 I_2 H_3 C_2 
Stack 7
F_1 D_5 H_1 H_2 G_0 
Stack 8
C_1 D_0 H_0 E_2 G_1 
Stack 9
C_3 B_1 F_5 I_1 B_0 
Stack 10
J_2 E_1 D_4 E_5 D_3 
