Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_16 B_10 C_8 A_7 B_14 B_12 
Stack 2
A_10 E_4 C_10 B_9 B_13 A_13 
Stack 3
C_4 E_13 C_13 A_0 E_3 E_2 
Stack 4
B_1 A_9 E_7 B_8 E_11 D_3 
Stack 5
E_5 D_11 D_7 E_0 E_10 
Stack 6
B_7 A_1 D_15 A_4 A_12 
Stack 7
B_15 C_14 E_8 D_1 D_0 
Stack 8
B_4 C_0 B_0 C_7 D_9 
Stack 9
C_6 E_14 C_5 D_13 A_8 
Stack 10
C_12 C_9 B_2 B_3 B_11 
Stack 11
A_11 D_14 C_1 A_6 D_2 
Stack 12
E_9 E_12 C_15 B_5 C_2 
Stack 13
D_6 B_6 D_5 D_8 A_3 
Stack 14
A_14 A_5 C_3 E_6 D_10 
Stack 15
E_1 C_11 D_4 A_2 D_12 
