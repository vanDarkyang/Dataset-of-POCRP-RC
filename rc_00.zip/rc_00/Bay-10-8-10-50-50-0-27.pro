Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 D_3 F_5 I_1 C_4 
Stack 2
C_2 E_6 J_2 C_0 H_1 
Stack 3
B_2 I_2 F_3 H_3 G_2 
Stack 4
E_2 D_5 D_4 C_1 B_3 
Stack 5
F_1 E_0 G_0 G_1 F_4 
Stack 6
I_0 H_0 B_0 I_3 F_6 
Stack 7
E_1 G_4 J_0 E_4 G_3 
Stack 8
D_1 D_2 F_0 A_2 E_3 
Stack 9
E_5 B_1 J_1 F_2 H_2 
Stack 10
D_0 H_4 A_0 C_3 G_5 
