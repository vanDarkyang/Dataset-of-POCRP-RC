Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 D_0 J_3 H_6 M_1 G_6 
Stack 2
N_3 F_6 K_6 O_1 J_2 H_1 
Stack 3
F_7 E_4 H_2 I_4 D_5 K_0 
Stack 4
B_3 E_3 A_0 M_4 L_2 K_1 
Stack 5
C_3 M_3 K_4 H_0 N_0 
Stack 6
D_4 D_2 J_1 I_7 N_2 
Stack 7
E_2 I_1 F_3 K_3 F_0 
Stack 8
G_4 K_5 I_3 A_1 B_1 
Stack 9
G_1 H_7 O_2 I_0 N_1 
Stack 10
G_8 C_4 K_2 F_5 B_0 
Stack 11
I_5 C_0 E_1 C_1 I_2 
Stack 12
H_8 G_0 I_8 J_4 D_3 
Stack 13
L_4 L_1 L_3 F_4 M_0 
Stack 14
L_5 L_0 E_0 H_5 E_6 
Stack 15
I_6 E_5 H_4 J_0 J_6 
Stack 16
G_2 F_1 H_3 G_5 B_2 
Stack 17
F_2 J_7 G_3 J_5 H_9 
Stack 18
M_2 D_1 A_2 O_0 G_7 
