Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_0 A_0 D_4 E_8 E_3 
Stack 2
A_4 J_3 E_1 F_7 H_2 
Stack 3
A_3 J_1 E_0 F_4 I_0 
Stack 4
D_1 H_5 C_5 F_2 I_5 
Stack 5
G_2 E_4 G_7 B_1 H_6 
Stack 6
C_4 H_1 B_3 G_4 G_5 
Stack 7
C_2 F_1 H_4 B_5 H_0 
Stack 8
D_7 E_6 G_1 J_2 B_2 
Stack 9
D_5 F_8 I_3 F_3 D_0 
Stack 10
E_5 D_2 C_0 C_6 G_6 
Stack 11
J_4 B_4 F_5 J_0 H_3 
Stack 12
E_7 C_3 B_0 E_2 D_3 
Stack 13
I_4 F_0 G_3 A_2 A_1 
Stack 14
I_2 F_6 C_1 I_1 D_6 
