Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_3 A_2 C_5 D_7 
Stack 2
C_3 C_2 B_15 D_3 
Stack 3
C_12 D_1 B_13 A_1 
Stack 4
B_10 D_9 C_11 A_9 
Stack 5
A_4 E_2 D_14 E_14 
Stack 6
E_12 C_13 D_4 B_9 
Stack 7
B_1 E_10 B_11 E_9 
Stack 8
A_6 D_10 C_1 A_0 
Stack 9
B_4 E_1 D_6 B_2 
Stack 10
E_7 C_8 B_0 E_5 
Stack 11
B_8 B_3 D_2 D_11 
Stack 12
D_0 B_7 C_7 A_13 
Stack 13
B_6 A_5 E_11 A_10 
Stack 14
C_9 C_0 E_4 E_8 
Stack 15
A_14 C_16 C_14 A_7 
Stack 16
E_13 A_12 B_5 E_6 
Stack 17
A_11 D_12 E_0 C_4 
Stack 18
B_14 D_13 D_15 B_12 
Stack 19
A_8 E_3 C_10 C_15 
Stack 20
D_8 C_6 D_5 
