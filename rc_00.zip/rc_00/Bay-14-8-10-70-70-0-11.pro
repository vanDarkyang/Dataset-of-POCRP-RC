Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_0 C_4 G_3 C_5 F_8 
Stack 2
E_3 G_6 E_8 F_5 A_4 
Stack 3
C_2 J_2 J_3 C_3 G_5 
Stack 4
F_2 A_3 H_1 D_6 E_4 
Stack 5
C_1 G_1 A_1 I_0 B_1 
Stack 6
H_4 E_5 H_5 H_2 H_6 
Stack 7
D_1 A_2 B_0 D_3 F_6 
Stack 8
C_6 D_7 B_2 B_3 E_1 
Stack 9
J_1 D_5 G_2 F_7 I_5 
Stack 10
G_4 F_1 E_0 D_0 D_2 
Stack 11
B_4 F_0 F_4 E_7 H_3 
Stack 12
B_5 E_2 I_1 C_0 A_0 
Stack 13
G_0 E_6 F_3 I_3 I_2 
Stack 14
D_4 I_4 G_7 J_4 H_0 
