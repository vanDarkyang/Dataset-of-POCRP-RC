Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_13 H_6 F_8 C_3 B_1 C_9 
Stack 2
F_4 E_5 E_8 I_3 B_5 A_4 
Stack 3
J_1 H_9 E_3 J_4 E_7 F_6 
Stack 4
C_8 D_2 B_2 F_1 H_11 G_3 
Stack 5
I_9 A_7 H_4 B_9 B_6 I_10 
Stack 6
B_3 A_5 G_10 D_8 G_1 
Stack 7
A_1 B_10 D_11 B_4 D_0 
Stack 8
F_0 I_0 E_1 E_2 C_5 
Stack 9
H_10 D_9 F_11 C_0 J_7 
Stack 10
A_8 G_2 A_9 H_3 G_7 
Stack 11
D_4 E_9 G_5 C_4 C_2 
Stack 12
D_6 F_7 F_13 H_2 G_11 
Stack 13
J_3 E_0 D_3 H_1 E_10 
Stack 14
F_5 F_12 G_8 F_10 D_12 
Stack 15
I_2 C_7 H_8 J_5 J_9 
Stack 16
D_1 G_4 I_8 H_0 G_12 
Stack 17
G_6 I_4 B_8 I_5 A_3 
Stack 18
C_1 F_9 G_9 C_11 D_10 
Stack 19
E_11 I_6 E_4 F_2 C_6 
Stack 20
J_0 C_10 I_1 A_2 B_0 
Stack 21
J_8 D_5 D_7 J_2 J_6 
Stack 22
E_6 B_7 E_12 I_7 A_0 
Stack 23
G_0 F_3 H_5 A_6 H_7 
