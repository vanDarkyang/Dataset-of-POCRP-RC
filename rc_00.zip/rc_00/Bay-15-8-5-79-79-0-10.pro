Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_14 C_8 D_14 A_7 C_16 B_2 
Stack 2
C_3 B_5 E_0 A_4 C_12 E_6 
Stack 3
A_10 D_5 B_3 D_10 D_12 A_8 
Stack 4
A_3 C_7 E_2 D_15 B_10 A_11 
Stack 5
D_4 E_3 C_13 B_13 B_0 
Stack 6
D_2 E_12 C_9 A_14 A_12 
Stack 7
B_4 D_9 E_5 D_6 E_14 
Stack 8
B_11 C_10 C_1 A_13 D_8 
Stack 9
C_0 D_0 E_11 C_15 E_8 
Stack 10
B_14 C_6 B_7 D_13 C_2 
Stack 11
B_9 C_4 D_7 C_5 A_9 
Stack 12
A_6 D_3 C_11 B_8 B_1 
Stack 13
E_10 E_7 E_1 D_1 B_15 
Stack 14
E_9 A_2 A_5 A_0 E_4 
Stack 15
A_1 D_11 B_12 B_6 E_13 
