Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_11 C_6 A_5 C_5 
Stack 2
B_2 C_2 E_8 E_2 
Stack 3
D_10 D_8 D_14 E_6 
Stack 4
B_15 A_13 D_3 D_13 
Stack 5
D_0 A_2 D_6 D_4 
Stack 6
A_3 B_9 C_10 E_0 
Stack 7
C_15 B_6 B_0 D_5 
Stack 8
A_7 D_2 C_8 E_10 
Stack 9
B_11 D_11 A_14 A_1 
Stack 10
B_3 C_13 B_7 B_5 
Stack 11
C_4 E_11 D_7 D_1 
Stack 12
E_9 E_13 E_1 E_4 
Stack 13
A_0 C_9 E_7 E_5 
Stack 14
B_13 C_14 D_12 B_10 
Stack 15
D_9 B_4 A_6 C_11 
Stack 16
C_7 A_12 C_12 B_14 
Stack 17
A_10 C_16 E_12 E_14 
Stack 18
E_3 D_15 C_0 B_12 
Stack 19
C_3 A_4 B_8 B_1 
Stack 20
C_1 A_9 A_8 
