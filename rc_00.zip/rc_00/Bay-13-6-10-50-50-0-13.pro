Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_2 D_0 H_4 H_0 
Stack 2
G_3 H_2 B_1 F_3 
Stack 3
E_2 D_5 E_5 D_1 
Stack 4
G_5 C_1 G_2 G_0 
Stack 5
B_3 I_3 I_1 F_0 
Stack 6
F_5 E_6 A_2 F_1 
Stack 7
J_2 A_1 C_0 E_4 
Stack 8
G_1 B_2 F_2 E_0 
Stack 9
I_2 D_3 J_0 G_4 
Stack 10
C_4 J_1 H_3 D_4 
Stack 11
I_0 H_1 E_1 B_0 
Stack 12
A_0 C_2 E_3 
Stack 13
F_6 C_3 F_4 
