Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_2 I_3 J_4 E_8 
Stack 2
A_4 G_7 G_4 I_5 
Stack 3
G_6 F_1 D_3 B_1 
Stack 4
C_5 H_3 E_7 H_6 
Stack 5
J_2 D_6 C_6 I_1 
Stack 6
I_4 H_5 F_5 F_8 
Stack 7
C_1 E_0 G_3 J_0 
Stack 8
H_1 E_1 A_0 A_1 
Stack 9
E_4 E_5 H_0 F_0 
Stack 10
C_4 E_6 A_3 H_2 
Stack 11
D_4 D_0 I_0 B_4 
Stack 12
F_7 D_1 G_1 F_3 
Stack 13
J_1 B_3 F_6 C_3 
Stack 14
E_2 F_2 B_2 D_7 
Stack 15
B_0 C_0 D_5 I_2 
Stack 16
J_3 G_2 G_0 A_2 
Stack 17
F_4 G_5 E_3 
Stack 18
B_5 H_4 C_2 
