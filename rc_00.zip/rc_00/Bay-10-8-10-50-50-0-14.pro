Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_4 F_5 I_0 G_3 F_3 
Stack 2
E_0 D_4 H_4 D_5 I_3 
Stack 3
A_2 H_3 C_1 B_3 E_5 
Stack 4
C_2 C_0 I_2 H_2 F_2 
Stack 5
G_2 F_0 D_3 E_4 J_1 
Stack 6
F_4 A_1 F_1 G_5 E_6 
Stack 7
D_1 C_4 A_0 B_0 B_2 
Stack 8
C_3 F_6 E_2 J_0 D_2 
Stack 9
D_0 H_1 I_1 E_3 G_0 
Stack 10
G_1 H_0 E_1 B_1 J_2 
