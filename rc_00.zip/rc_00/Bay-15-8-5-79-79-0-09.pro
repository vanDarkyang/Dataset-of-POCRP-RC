Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_3 E_13 B_3 D_4 D_7 E_6 
Stack 2
C_3 A_11 B_7 B_11 D_3 C_4 
Stack 3
C_12 B_14 A_5 C_1 A_1 B_12 
Stack 4
B_10 A_8 C_0 D_6 A_9 C_15 
Stack 5
A_4 D_8 C_16 B_0 E_14 
Stack 6
E_12 A_2 A_12 D_2 B_9 
Stack 7
B_1 C_2 D_12 C_7 E_9 
Stack 8
A_6 D_1 D_13 E_11 A_0 
Stack 9
B_4 D_9 E_3 E_4 B_2 
Stack 10
E_7 E_2 C_6 C_14 E_5 
Stack 11
B_8 C_13 C_5 B_5 D_11 
Stack 12
D_0 E_10 B_15 E_0 A_13 
Stack 13
B_6 D_10 B_13 D_15 A_10 
Stack 14
C_9 E_1 C_11 C_10 E_8 
Stack 15
A_14 C_8 D_14 D_5 A_7 
