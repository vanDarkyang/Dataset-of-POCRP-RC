Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_3 D_5 E_4 I_3 I_0 
Stack 2
G_3 B_0 D_4 A_1 F_4 
Stack 3
F_2 C_0 B_3 E_5 C_4 
Stack 4
B_2 A_0 I_2 E_0 F_5 
Stack 5
D_2 E_3 F_1 E_2 G_2 
Stack 6
G_1 H_1 J_1 F_6 I_1 
Stack 7
G_5 C_3 D_1 E_6 H_0 
Stack 8
D_0 F_0 J_2 G_4 J_0 
Stack 9
G_0 B_1 C_1 A_2 E_1 
Stack 10
H_4 C_2 H_2 H_3 D_3 
