Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_1 B_3 F_6 C_2 A_1 
Stack 2
B_1 C_1 H_1 G_2 F_4 
Stack 3
B_2 F_5 G_3 I_3 J_1 
Stack 4
E_4 F_2 D_0 D_4 A_0 
Stack 5
D_2 G_4 A_2 D_1 E_6 
Stack 6
G_0 J_0 H_4 H_2 I_1 
Stack 7
J_2 B_0 F_0 C_0 E_2 
Stack 8
H_0 H_3 F_3 G_5 E_0 
Stack 9
E_5 E_3 C_3 D_5 G_1 
Stack 10
C_4 I_0 F_1 I_2 D_3 
