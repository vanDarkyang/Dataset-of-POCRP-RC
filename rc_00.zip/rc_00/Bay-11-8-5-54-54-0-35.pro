Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_4 D_9 C_5 E_4 E_9 
Stack 2
D_1 B_10 A_1 B_8 E_2 
Stack 3
D_7 D_0 D_10 A_8 C_10 
Stack 4
A_2 B_2 C_8 A_9 A_7 
Stack 5
B_0 C_4 D_4 D_3 C_0 
Stack 6
B_9 C_11 D_2 E_1 D_8 
Stack 7
C_2 B_3 B_4 B_6 E_7 
Stack 8
B_1 A_5 C_9 B_7 D_6 
Stack 9
E_5 C_3 C_7 E_0 E_6 
Stack 10
C_1 B_5 C_6 E_8 A_3 
Stack 11
E_3 A_0 D_5 A_6 
