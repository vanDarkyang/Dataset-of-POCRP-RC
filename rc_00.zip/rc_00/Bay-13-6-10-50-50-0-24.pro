Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_0 B_1 D_5 D_1 
Stack 2
C_0 G_4 H_1 B_2 
Stack 3
E_1 J_2 A_1 H_3 
Stack 4
E_0 E_5 I_0 F_0 
Stack 5
G_5 J_0 C_1 D_4 
Stack 6
G_1 B_3 A_2 H_4 
Stack 7
G_2 C_4 D_0 E_6 
Stack 8
F_3 C_2 D_3 I_1 
Stack 9
E_3 F_2 G_3 I_2 
Stack 10
F_1 E_2 A_0 F_5 
Stack 11
H_0 F_4 H_2 I_3 
Stack 12
J_1 F_6 D_2 
Stack 13
G_0 E_4 C_3 
