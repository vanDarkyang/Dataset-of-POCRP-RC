Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_12 D_14 E_11 D_1 
Stack 2
B_6 A_7 C_9 E_0 
Stack 3
C_16 B_13 D_6 E_10 
Stack 4
B_9 A_6 C_14 C_5 
Stack 5
C_6 B_11 D_5 A_14 
Stack 6
C_8 C_11 B_3 D_9 
Stack 7
B_0 E_7 B_15 B_5 
Stack 8
C_13 B_7 A_3 D_0 
Stack 9
E_14 D_3 D_11 C_15 
Stack 10
B_1 B_8 D_4 C_1 
Stack 11
E_6 A_10 E_13 A_2 
Stack 12
C_7 A_1 E_9 A_9 
Stack 13
A_13 E_5 B_10 A_4 
Stack 14
B_4 A_5 C_10 D_8 
Stack 15
E_8 A_8 E_1 D_13 
Stack 16
D_12 E_2 E_4 C_2 
Stack 17
B_14 D_7 C_0 A_0 
Stack 18
C_4 A_12 D_2 C_3 
Stack 19
A_11 B_2 C_12 E_3 
Stack 20
D_10 B_12 D_15 
