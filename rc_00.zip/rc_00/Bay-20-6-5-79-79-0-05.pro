Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_10 C_1 D_10 D_11 
Stack 2
C_16 A_11 C_2 B_6 
Stack 3
B_0 A_8 C_0 C_3 
Stack 4
A_0 B_4 E_9 D_12 
Stack 5
E_5 C_14 D_9 E_7 
Stack 6
B_10 C_6 C_8 B_11 
Stack 7
D_6 D_15 C_5 A_4 
Stack 8
B_15 D_2 B_5 E_10 
Stack 9
D_8 E_6 A_10 E_11 
Stack 10
B_12 D_0 C_4 E_14 
Stack 11
B_1 B_9 B_8 A_12 
Stack 12
A_14 E_4 D_3 A_3 
Stack 13
E_1 B_14 C_13 E_0 
Stack 14
A_2 A_9 D_7 E_12 
Stack 15
B_3 B_2 C_9 C_12 
Stack 16
D_1 D_5 A_7 C_15 
Stack 17
A_13 D_13 D_14 B_13 
Stack 18
A_1 E_8 D_4 E_3 
Stack 19
C_7 A_5 C_11 A_6 
Stack 20
E_2 E_13 B_7 
