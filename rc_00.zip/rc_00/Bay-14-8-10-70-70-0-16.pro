Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_3 A_4 H_4 H_0 A_1 
Stack 2
J_2 B_3 E_2 B_4 H_2 
Stack 3
B_2 C_1 D_0 C_3 C_4 
Stack 4
E_3 G_2 G_7 F_1 D_5 
Stack 5
G_4 D_1 I_1 E_6 D_6 
Stack 6
J_1 F_7 G_3 H_1 E_4 
Stack 7
F_3 E_8 G_1 G_6 I_3 
Stack 8
E_7 I_2 I_5 A_2 E_0 
Stack 9
C_5 D_7 A_0 D_3 F_4 
Stack 10
H_5 F_2 I_4 A_3 B_5 
Stack 11
C_2 H_6 G_5 D_2 J_0 
Stack 12
C_6 B_0 J_3 F_5 D_4 
Stack 13
C_0 B_1 E_5 J_4 F_0 
Stack 14
I_0 G_0 F_6 E_1 F_8 
