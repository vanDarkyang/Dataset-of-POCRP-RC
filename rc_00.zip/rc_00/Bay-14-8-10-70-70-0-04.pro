Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_1 A_1 I_5 E_7 H_0 
Stack 2
F_4 D_2 C_1 A_2 H_2 
Stack 3
B_0 H_5 B_4 A_4 B_3 
Stack 4
B_1 H_1 J_0 E_0 G_3 
Stack 5
E_6 B_2 D_3 G_4 C_3 
Stack 6
E_1 C_0 D_7 I_3 G_0 
Stack 7
G_7 H_6 D_5 J_1 D_6 
Stack 8
I_0 F_8 D_0 H_4 F_1 
Stack 9
G_2 I_4 E_2 I_2 C_4 
Stack 10
J_3 G_1 J_2 A_0 F_7 
Stack 11
C_5 E_4 F_0 F_3 E_8 
Stack 12
F_6 F_2 D_4 C_6 G_5 
Stack 13
F_5 A_3 E_5 C_2 E_3 
Stack 14
J_4 H_3 B_5 G_6 D_1 
