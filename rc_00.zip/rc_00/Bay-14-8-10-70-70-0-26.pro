Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_2 G_2 C_4 F_2 I_5 
Stack 2
C_0 E_0 B_3 D_4 F_3 
Stack 3
A_4 G_7 D_5 E_5 I_0 
Stack 4
C_6 J_2 G_6 E_2 G_4 
Stack 5
D_3 H_4 H_2 F_7 E_7 
Stack 6
B_5 J_4 G_3 I_4 F_8 
Stack 7
G_0 B_0 B_4 G_1 A_3 
Stack 8
H_5 G_5 C_1 I_2 F_0 
Stack 9
F_4 C_3 H_0 E_1 E_8 
Stack 10
B_2 D_7 E_3 E_4 H_1 
Stack 11
F_1 D_2 J_1 A_0 D_0 
Stack 12
F_6 J_0 I_3 C_2 H_3 
Stack 13
D_1 D_6 A_1 I_1 J_3 
Stack 14
H_6 F_5 C_5 B_1 E_6 
