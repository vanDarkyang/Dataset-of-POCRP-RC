Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_3 F_7 B_2 F_6 
Stack 2
H_0 J_4 C_6 D_7 
Stack 3
F_2 E_8 D_1 C_1 
Stack 4
C_5 E_4 E_2 D_2 
Stack 5
G_7 I_5 E_6 I_3 
Stack 6
G_2 D_3 B_3 I_2 
Stack 7
F_1 I_1 A_1 G_1 
Stack 8
E_0 J_3 E_5 F_0 
Stack 9
F_8 F_3 D_4 B_0 
Stack 10
C_4 G_4 A_2 E_7 
Stack 11
B_1 G_3 A_3 J_2 
Stack 12
J_1 D_6 H_5 E_1 
Stack 13
A_0 H_1 J_0 A_4 
Stack 14
I_0 F_5 C_3 F_4 
Stack 15
B_5 H_6 D_0 B_4 
Stack 16
G_6 D_5 H_4 H_2 
Stack 17
G_0 C_0 H_3 
Stack 18
C_2 G_5 I_4 
