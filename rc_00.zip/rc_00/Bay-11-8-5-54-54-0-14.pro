Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_9 C_4 A_2 B_4 E_6 
Stack 2
D_0 B_9 A_9 E_8 A_8 
Stack 3
C_3 A_3 A_1 C_8 D_2 
Stack 4
C_11 E_1 A_5 C_0 B_6 
Stack 5
A_6 E_3 E_0 E_9 A_7 
Stack 6
C_10 C_6 C_1 E_5 B_0 
Stack 7
C_2 D_6 D_10 C_5 C_7 
Stack 8
D_8 B_8 D_1 D_4 B_7 
Stack 9
B_10 D_7 A_0 D_3 D_5 
Stack 10
B_2 E_2 E_7 D_9 B_1 
Stack 11
E_4 B_3 A_4 B_5 
