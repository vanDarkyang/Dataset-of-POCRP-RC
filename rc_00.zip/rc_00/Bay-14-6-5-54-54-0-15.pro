Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_2 C_10 D_1 B_1 
Stack 2
E_0 A_8 E_3 A_6 
Stack 3
C_0 D_5 C_4 E_1 
Stack 4
A_5 A_7 C_6 E_2 
Stack 5
E_8 B_9 D_0 B_10 
Stack 6
E_7 C_5 A_0 A_4 
Stack 7
A_1 B_0 A_9 C_2 
Stack 8
B_6 C_7 D_7 B_7 
Stack 9
C_1 C_3 E_6 A_2 
Stack 10
B_4 D_2 E_4 D_9 
Stack 11
C_11 D_4 E_9 A_3 
Stack 12
B_3 D_6 D_10 C_8 
Stack 13
B_8 D_8 D_3 
Stack 14
C_9 B_5 E_5 
