Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_3 A_0 D_1 H_3 
Stack 2
G_3 E_3 J_2 I_0 
Stack 3
F_2 H_1 C_1 F_4 
Stack 4
B_2 C_3 H_2 C_4 
Stack 5
D_2 F_0 I_3 F_5 
Stack 6
G_1 B_1 A_1 G_2 
Stack 7
G_5 C_2 E_5 I_1 
Stack 8
D_0 E_4 E_0 H_0 
Stack 9
G_0 D_4 E_2 J_0 
Stack 10
H_4 B_3 F_6 E_1 
Stack 11
D_5 I_2 E_6 D_3 
Stack 12
B_0 F_1 G_4 
Stack 13
C_0 J_1 A_2 
