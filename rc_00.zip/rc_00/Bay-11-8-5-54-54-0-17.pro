Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_3 C_3 C_4 A_6 C_5 
Stack 2
A_9 C_2 E_6 D_7 D_10 
Stack 3
C_10 B_7 D_8 B_2 A_0 
Stack 4
C_1 A_3 B_10 B_0 C_6 
Stack 5
E_1 D_0 C_9 A_2 E_2 
Stack 6
D_2 D_1 C_8 E_8 A_7 
Stack 7
E_5 C_7 D_5 D_6 E_9 
Stack 8
D_4 E_3 B_4 A_1 A_4 
Stack 9
A_5 E_4 B_8 A_8 C_0 
Stack 10
E_7 B_6 B_9 E_0 B_5 
Stack 11
C_11 B_1 B_3 D_9 
