Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_1 B_0 H_3 J_1 H_2 
Stack 2
B_2 I_1 F_6 D_4 F_5 
Stack 3
G_3 D_0 E_2 E_1 G_4 
Stack 4
D_1 F_1 I_3 C_3 H_0 
Stack 5
F_0 J_2 F_2 G_0 E_4 
Stack 6
C_4 I_0 D_3 A_0 D_5 
Stack 7
G_1 C_0 E_5 E_6 G_2 
Stack 8
H_4 B_3 D_2 H_1 B_1 
Stack 9
C_2 F_4 I_2 A_2 F_3 
Stack 10
G_5 E_3 A_1 J_0 E_0 
