Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 D_11 D_9 C_12 B_5 D_14 
Stack 2
D_1 A_12 B_14 B_8 C_8 A_9 
Stack 3
E_12 E_13 A_5 B_6 C_3 C_14 
Stack 4
D_4 D_2 C_16 E_5 D_5 B_15 
Stack 5
B_11 D_8 E_3 B_3 A_7 
Stack 6
B_7 C_13 C_11 C_6 A_6 
Stack 7
E_9 A_14 C_5 B_9 A_2 
Stack 8
B_13 C_10 C_7 E_7 C_2 
Stack 9
B_2 E_2 D_15 C_1 B_1 
Stack 10
E_10 D_0 A_4 E_4 C_9 
Stack 11
B_0 D_6 E_8 A_13 A_8 
Stack 12
D_13 D_7 A_3 A_10 A_0 
Stack 13
D_10 E_1 E_6 C_4 C_0 
Stack 14
C_15 D_3 E_11 E_0 B_10 
Stack 15
B_12 D_12 B_4 A_11 E_14 
