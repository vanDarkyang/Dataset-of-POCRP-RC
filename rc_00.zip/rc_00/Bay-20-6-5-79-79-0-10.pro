Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_14 E_12 D_7 C_16 
Stack 2
C_3 D_9 C_11 C_12 
Stack 3
A_10 C_10 E_1 D_12 
Stack 4
A_3 D_0 A_5 B_10 
Stack 5
D_4 C_6 B_12 B_0 
Stack 6
D_2 C_4 A_7 A_12 
Stack 7
B_4 D_3 A_4 E_14 
Stack 8
B_11 E_7 D_10 D_8 
Stack 9
C_0 A_2 D_15 E_8 
Stack 10
B_14 D_11 B_13 C_2 
Stack 11
B_9 D_14 A_14 A_9 
Stack 12
A_6 E_0 D_6 B_1 
Stack 13
E_10 B_3 A_13 B_15 
Stack 14
E_9 E_2 C_15 E_4 
Stack 15
A_1 C_13 D_13 E_13 
Stack 16
C_8 C_9 C_5 B_2 
Stack 17
B_5 E_5 B_8 E_6 
Stack 18
D_5 C_1 D_1 A_8 
Stack 19
C_7 E_11 A_0 A_11 
Stack 20
E_3 B_7 B_6 
