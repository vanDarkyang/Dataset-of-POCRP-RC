Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
L_0 J_1 L_1 G_2 G_1 K_5 
Stack 2
N_2 E_0 C_4 B_3 K_6 E_2 
Stack 3
K_1 E_6 H_0 K_3 F_4 N_1 
Stack 4
I_6 J_4 E_1 L_5 A_1 E_4 
Stack 5
E_5 C_0 H_4 M_0 D_0 
Stack 6
G_4 B_2 J_2 F_0 O_1 
Stack 7
D_5 G_7 N_0 D_3 M_2 
Stack 8
F_6 L_3 B_0 J_3 M_3 
Stack 9
O_2 H_9 H_5 I_5 H_2 
Stack 10
D_4 M_4 F_5 G_3 J_0 
Stack 11
F_1 H_3 H_1 L_2 I_3 
Stack 12
O_0 C_2 K_4 A_2 H_7 
Stack 13
F_3 I_2 D_2 H_8 K_0 
Stack 14
D_1 F_7 B_1 M_1 I_1 
Stack 15
J_6 I_4 C_3 J_5 I_7 
Stack 16
G_0 N_3 E_3 G_6 A_0 
Stack 17
C_1 L_4 F_2 G_8 J_7 
Stack 18
K_2 G_5 I_8 I_0 H_6 
