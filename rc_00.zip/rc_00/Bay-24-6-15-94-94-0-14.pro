Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_3 O_0 B_0 D_0 
Stack 2
H_5 F_3 C_4 I_4 
Stack 3
D_1 I_8 E_1 K_0 
Stack 4
H_9 K_4 J_7 F_1 
Stack 5
E_3 L_2 E_5 H_8 
Stack 6
I_3 E_4 D_5 M_3 
Stack 7
B_3 H_6 N_3 G_8 
Stack 8
E_0 K_3 H_3 H_4 
Stack 9
H_7 D_3 K_2 C_0 
Stack 10
G_4 G_6 L_5 F_5 
Stack 11
G_1 E_2 I_6 J_4 
Stack 12
J_6 A_1 I_5 F_0 
Stack 13
F_6 L_3 I_1 G_2 
Stack 14
A_2 L_4 L_1 J_0 
Stack 15
G_0 O_2 J_1 E_6 
Stack 16
J_5 J_2 B_2 D_2 
Stack 17
A_0 B_1 M_2 M_1 
Stack 18
C_2 H_2 L_0 M_0 
Stack 19
G_5 I_2 H_1 G_7 
Stack 20
K_5 C_1 D_4 M_4 
Stack 21
G_3 O_1 F_4 F_2 
Stack 22
F_7 N_0 C_3 N_1 
Stack 23
H_0 K_1 I_0 
Stack 24
K_6 I_7 N_2 
