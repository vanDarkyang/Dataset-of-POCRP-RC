Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_5 I_6 G_4 N_2 
Stack 2
J_0 H_2 G_5 I_0 
Stack 3
J_7 F_4 F_0 M_2 
Stack 4
J_4 J_1 J_2 E_2 
Stack 5
C_1 A_1 L_1 N_0 
Stack 6
H_7 M_3 H_3 L_3 
Stack 7
E_0 H_6 G_7 I_1 
Stack 8
I_7 O_0 L_5 H_9 
Stack 9
F_3 L_4 F_1 I_3 
Stack 10
F_6 K_4 A_0 C_0 
Stack 11
G_8 M_0 C_4 C_3 
Stack 12
C_2 O_1 K_1 A_2 
Stack 13
H_4 H_8 B_1 N_1 
Stack 14
D_5 H_0 B_3 I_4 
Stack 15
G_1 I_8 E_4 F_5 
Stack 16
D_3 D_0 K_6 G_6 
Stack 17
E_1 M_1 J_3 E_3 
Stack 18
L_0 G_2 K_0 I_2 
Stack 19
F_2 O_2 K_3 M_4 
Stack 20
H_5 D_2 J_5 L_2 
Stack 21
F_7 B_2 D_1 D_4 
Stack 22
K_2 N_3 G_0 B_0 
Stack 23
E_5 G_3 E_6 
Stack 24
I_5 J_6 H_1 
