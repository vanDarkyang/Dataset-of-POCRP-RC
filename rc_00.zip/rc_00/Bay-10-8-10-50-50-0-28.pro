Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 F_0 E_1 C_3 H_4 
Stack 2
D_0 E_2 F_1 G_5 E_4 
Stack 3
H_0 D_4 B_2 H_2 D_5 
Stack 4
F_3 E_5 D_2 I_0 I_3 
Stack 5
C_0 A_1 F_2 E_3 G_3 
Stack 6
C_4 E_0 H_3 B_3 J_2 
Stack 7
D_3 I_2 A_0 B_1 C_1 
Stack 8
E_6 G_0 G_2 H_1 I_1 
Stack 9
G_4 C_2 F_4 F_6 G_1 
Stack 10
B_0 J_1 J_0 A_2 F_5 
