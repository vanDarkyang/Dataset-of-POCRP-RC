Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_8 C_11 E_11 E_8 
Stack 2
E_10 C_4 E_5 D_12 
Stack 3
A_9 D_13 A_6 C_13 
Stack 4
A_7 E_12 A_4 B_4 
Stack 5
D_4 B_0 D_10 B_15 
Stack 6
A_5 A_3 E_3 A_2 
Stack 7
C_6 D_5 B_11 B_13 
Stack 8
C_15 E_1 A_11 D_6 
Stack 9
C_0 C_10 C_1 B_14 
Stack 10
A_12 E_2 B_7 C_8 
Stack 11
D_2 C_2 E_9 A_8 
Stack 12
D_8 C_5 B_5 C_16 
Stack 13
A_13 C_3 E_14 D_9 
Stack 14
A_14 D_7 B_12 A_0 
Stack 15
B_6 D_15 D_11 D_3 
Stack 16
A_1 B_1 C_12 B_9 
Stack 17
C_9 D_14 C_7 E_4 
Stack 18
C_14 E_6 D_0 B_3 
Stack 19
A_10 B_10 D_1 E_7 
Stack 20
B_2 E_13 E_0 
