Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 B_13 C_11 B_8 
Stack 2
B_5 B_4 A_3 A_8 
Stack 3
B_9 B_3 A_2 C_13 
Stack 4
B_15 B_2 C_14 A_4 
Stack 5
A_14 B_7 B_1 C_9 
Stack 6
A_1 B_10 C_12 C_6 
Stack 7
B_0 C_2 A_12 A_10 
Stack 8
C_8 A_13 A_0 A_6 
Stack 9
B_11 C_1 B_12 C_7 
Stack 10
A_11 C_10 C_0 C_4 
Stack 11
B_14 A_9 A_7 
Stack 12
C_5 B_6 A_5 
