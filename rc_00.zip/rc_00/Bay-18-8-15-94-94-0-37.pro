Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_0 D_3 I_4 N_3 E_0 O_0 
Stack 2
K_3 I_1 H_5 L_2 N_2 I_0 
Stack 3
H_2 C_3 D_2 H_1 B_1 K_6 
Stack 4
D_0 I_6 A_2 J_3 F_2 L_4 
Stack 5
G_3 F_5 J_6 I_2 I_3 
Stack 6
D_5 H_8 L_5 I_7 L_1 
Stack 7
E_2 M_0 K_5 J_1 G_0 
Stack 8
D_1 H_7 B_2 J_5 G_5 
Stack 9
J_2 K_1 O_2 M_3 G_2 
Stack 10
H_6 H_4 J_4 F_6 F_7 
Stack 11
H_9 L_3 B_0 C_2 N_0 
Stack 12
B_3 E_5 A_0 I_5 M_1 
Stack 13
H_0 M_4 K_4 C_4 C_1 
Stack 14
F_4 C_0 K_2 D_4 G_7 
Stack 15
E_4 F_0 G_6 M_2 I_8 
Stack 16
E_6 A_1 E_1 H_3 G_8 
Stack 17
L_0 N_1 F_3 O_1 J_7 
Stack 18
E_3 K_0 G_1 F_1 G_4 
