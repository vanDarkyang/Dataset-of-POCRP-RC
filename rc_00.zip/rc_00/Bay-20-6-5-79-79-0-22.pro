Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_1 D_15 C_15 E_14 
Stack 2
B_15 A_8 B_12 B_6 
Stack 3
D_5 B_8 D_11 C_1 
Stack 4
D_8 E_4 A_9 C_6 
Stack 5
E_9 C_9 C_5 E_0 
Stack 6
A_12 C_12 D_0 D_13 
Stack 7
A_0 D_12 A_3 A_4 
Stack 8
C_13 C_11 D_4 D_3 
Stack 9
B_2 D_6 A_11 E_12 
Stack 10
D_10 E_7 A_6 A_10 
Stack 11
E_6 A_5 B_4 D_9 
Stack 12
C_8 D_1 A_1 E_8 
Stack 13
D_7 C_10 B_9 D_2 
Stack 14
B_1 C_2 E_11 C_7 
Stack 15
A_14 B_13 D_14 B_5 
Stack 16
E_13 C_16 C_0 E_2 
Stack 17
A_2 E_10 B_3 E_3 
Stack 18
C_14 B_11 E_5 B_7 
Stack 19
B_10 B_14 A_7 C_3 
Stack 20
A_13 B_0 C_4 
