Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 B_7 B_13 A_0 
Stack 2
B_3 A_14 A_13 A_10 
Stack 3
C_4 B_10 A_8 C_1 
Stack 4
B_6 B_14 C_13 C_10 
Stack 5
C_6 A_11 C_9 C_12 
Stack 6
B_12 A_9 C_14 A_7 
Stack 7
C_2 C_3 C_0 B_4 
Stack 8
A_6 C_7 A_1 B_0 
Stack 9
B_5 B_15 C_5 A_5 
Stack 10
A_4 C_11 B_2 A_3 
Stack 11
B_8 B_11 A_2 
Stack 12
B_9 C_8 A_12 
