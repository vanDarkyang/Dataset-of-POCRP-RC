Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_0 E_6 C_11 B_10 C_4 
Stack 2
C_7 E_1 E_0 C_9 D_9 
Stack 3
D_3 C_2 D_7 E_4 D_8 
Stack 4
B_2 E_2 B_9 D_6 D_10 
Stack 5
A_9 D_0 E_3 B_5 D_5 
Stack 6
C_10 A_1 B_8 E_8 A_5 
Stack 7
C_5 C_1 C_8 C_3 B_4 
Stack 8
E_9 B_3 C_0 A_2 A_7 
Stack 9
D_4 E_5 C_6 A_6 B_1 
Stack 10
D_1 A_8 B_6 A_4 B_7 
Stack 11
E_7 A_0 A_3 D_2 
