Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_3 F_0 A_2 D_3 D_2 
Stack 2
F_6 E_1 H_0 G_1 E_5 
Stack 3
G_2 H_2 F_4 B_3 I_0 
Stack 4
C_0 E_4 D_0 G_4 E_6 
Stack 5
A_0 F_1 J_1 F_5 G_3 
Stack 6
B_1 D_4 G_0 I_3 F_3 
Stack 7
I_1 J_0 E_3 G_5 D_1 
Stack 8
C_2 B_2 H_1 C_4 F_2 
Stack 9
J_2 I_2 B_0 C_3 A_1 
Stack 10
D_5 E_2 H_4 E_0 C_1 
