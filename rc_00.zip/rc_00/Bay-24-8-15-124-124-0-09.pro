Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
L_4 D_6 E_3 I_9 B_4 I_2 
Stack 2
N_2 F_6 C_5 L_1 B_0 I_3 
Stack 3
F_7 G_2 K_0 C_6 D_5 O_2 
Stack 4
E_8 M_1 D_4 K_2 K_1 N_4 
Stack 5
K_3 F_3 J_6 L_3 L_2 
Stack 6
I_5 E_5 I_7 E_2 G_1 
Stack 7
J_3 L_7 F_9 M_0 O_1 
Stack 8
M_6 I_6 H_2 H_8 E_1 
Stack 9
A_1 J_4 G_8 K_7 A_3 
Stack 10
G_7 M_5 N_0 I_8 L_6 
Stack 11
B_5 I_0 D_7 J_0 C_0 
Stack 12
H_4 B_2 C_2 L_5 M_2 
Stack 13
F_0 G_4 H_6 D_1 F_1 
Stack 14
D_2 B_1 F_5 C_1 F_8 
Stack 15
K_4 H_9 A_0 G_3 H_0 
Stack 16
J_2 E_4 K_6 M_4 B_3 
Stack 17
I_1 H_10 J_9 O_4 H_11 
Stack 18
J_7 D_0 E_6 N_1 H_7 
Stack 19
H_1 G_9 E_0 N_3 G_0 
Stack 20
M_3 D_3 G_6 O_0 N_5 
Stack 21
F_2 E_7 J_5 H_5 G_5 
Stack 22
A_4 K_8 K_5 J_1 H_3 
Stack 23
G_10 I_10 L_0 C_4 J_8 
Stack 24
F_4 A_2 I_4 O_3 C_3 
