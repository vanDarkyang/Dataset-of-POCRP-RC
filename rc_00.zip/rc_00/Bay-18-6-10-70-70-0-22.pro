Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_0 D_3 I_2 F_4 
Stack 2
D_5 E_1 H_5 A_1 
Stack 3
F_7 F_3 F_5 B_2 
Stack 4
J_1 H_3 B_0 E_6 
Stack 5
F_0 D_7 C_1 G_4 
Stack 6
F_6 J_2 G_2 C_0 
Stack 7
D_4 H_2 I_3 C_4 
Stack 8
F_8 D_0 A_4 E_8 
Stack 9
B_5 E_7 B_1 E_2 
Stack 10
E_4 F_1 I_4 C_5 
Stack 11
E_3 J_0 G_6 J_4 
Stack 12
G_3 G_5 D_2 I_5 
Stack 13
A_3 C_3 A_2 A_0 
Stack 14
I_1 E_0 D_6 E_5 
Stack 15
C_6 H_0 G_7 I_0 
Stack 16
J_3 B_3 H_6 D_1 
Stack 17
C_2 B_4 F_2 
Stack 18
H_1 H_4 G_1 
