Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_2 H_5 J_6 M_4 
Stack 2
L_4 D_5 D_4 G_7 
Stack 3
N_2 H_8 J_0 H_6 
Stack 4
G_6 K_5 B_0 K_3 
Stack 5
C_1 K_1 N_3 F_5 
Stack 6
D_1 H_2 G_5 K_0 
Stack 7
G_8 E_0 E_3 H_7 
Stack 8
J_3 K_4 I_4 M_2 
Stack 9
I_6 I_8 J_1 I_0 
Stack 10
F_1 B_2 L_5 L_1 
Stack 11
G_0 F_0 E_2 C_4 
Stack 12
I_2 G_1 G_2 N_0 
Stack 13
E_6 D_0 A_1 C_2 
Stack 14
E_4 H_4 J_7 C_0 
Stack 15
F_7 G_3 O_2 O_1 
Stack 16
K_6 A_0 J_4 M_1 
Stack 17
F_6 I_5 D_3 F_2 
Stack 18
I_1 I_3 F_3 H_1 
Stack 19
F_4 L_0 B_1 A_2 
Stack 20
B_3 J_2 L_2 M_0 
Stack 21
M_3 J_5 H_3 O_0 
Stack 22
H_0 D_2 G_4 N_1 
Stack 23
I_7 L_3 E_1 
Stack 24
C_3 H_9 E_5 
