Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_2 I_7 K_3 E_0 B_1 E_1 
Stack 2
I_0 K_4 H_1 I_6 G_8 D_2 
Stack 3
F_1 K_5 H_8 L_1 H_2 C_4 
Stack 4
F_3 M_4 K_6 M_1 L_4 M_3 
Stack 5
H_0 J_5 A_0 B_3 N_0 
Stack 6
E_2 D_3 N_1 M_2 G_6 
Stack 7
G_0 F_5 H_4 J_7 A_1 
Stack 8
E_5 H_6 D_4 J_3 J_0 
Stack 9
C_2 O_1 H_3 J_6 G_5 
Stack 10
L_2 I_1 J_4 E_4 M_0 
Stack 11
C_1 G_1 I_5 G_3 O_2 
Stack 12
H_5 F_0 D_5 I_4 D_0 
Stack 13
D_1 F_6 F_4 K_0 H_7 
Stack 14
I_3 C_0 G_2 J_1 N_3 
Stack 15
B_0 L_3 G_4 K_1 L_5 
Stack 16
N_2 H_9 A_2 I_8 L_0 
Stack 17
B_2 I_2 G_7 E_6 E_3 
Stack 18
F_7 O_0 J_2 F_2 C_3 
