Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 C_7 B_14 C_1 
Stack 2
A_7 D_14 E_1 A_0 
Stack 3
C_15 C_2 D_7 C_12 
Stack 4
A_9 C_4 B_4 B_15 
Stack 5
B_11 D_0 B_7 D_4 
Stack 6
B_1 E_12 C_9 A_8 
Stack 7
A_2 C_16 E_11 E_8 
Stack 8
B_2 C_8 E_5 E_4 
Stack 9
B_0 D_10 D_5 A_14 
Stack 10
D_9 B_8 D_13 A_4 
Stack 11
B_5 C_6 E_3 E_13 
Stack 12
D_6 D_1 E_6 A_13 
Stack 13
C_11 C_5 D_12 C_10 
Stack 14
E_14 C_14 E_7 C_13 
Stack 15
A_6 D_11 C_3 E_9 
Stack 16
C_0 A_10 D_8 A_5 
Stack 17
D_2 D_3 E_10 B_9 
Stack 18
B_12 B_6 A_12 A_3 
Stack 19
E_0 D_15 A_11 B_13 
Stack 20
B_3 B_10 E_2 
