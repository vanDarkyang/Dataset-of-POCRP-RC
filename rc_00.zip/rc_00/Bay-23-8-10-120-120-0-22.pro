Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_7 D_4 H_8 B_7 J_9 E_13 
Stack 2
B_9 E_8 E_2 H_6 G_1 I_8 
Stack 3
F_12 C_7 D_1 E_9 D_8 A_6 
Stack 4
E_10 H_10 B_4 I_5 J_2 E_3 
Stack 5
I_1 J_6 F_8 F_13 H_2 B_5 
Stack 6
E_0 F_6 I_9 J_8 G_9 
Stack 7
I_7 H_7 F_2 F_11 D_10 
Stack 8
G_4 A_9 I_10 F_7 E_12 
Stack 9
B_0 A_1 D_9 C_4 H_1 
Stack 10
H_5 D_3 D_0 G_3 H_4 
Stack 11
I_4 F_1 A_0 H_3 C_2 
Stack 12
G_8 C_1 B_2 C_11 G_0 
Stack 13
A_5 H_11 A_3 E_11 J_5 
Stack 14
J_0 G_2 E_6 B_6 C_6 
Stack 15
E_7 J_7 B_3 D_6 G_6 
Stack 16
F_9 F_0 G_10 C_5 C_8 
Stack 17
G_12 B_8 E_4 A_8 D_12 
Stack 18
J_4 G_11 D_11 C_3 B_10 
Stack 19
C_0 E_1 H_9 C_10 B_1 
Stack 20
I_2 F_4 A_4 J_3 E_5 
Stack 21
I_3 F_3 A_7 H_0 J_1 
Stack 22
C_9 G_5 G_7 D_2 I_6 
Stack 23
F_5 D_5 I_0 A_2 F_10 
