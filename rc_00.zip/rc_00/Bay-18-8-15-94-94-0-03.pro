Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
N_0 C_1 D_4 H_8 E_5 G_1 
Stack 2
F_1 H_5 H_7 G_7 M_4 C_2 
Stack 3
D_1 L_3 M_1 L_2 J_0 H_0 
Stack 4
E_6 B_3 D_3 K_0 M_2 B_0 
Stack 5
C_4 F_5 K_2 O_2 F_2 
Stack 6
G_2 H_3 N_1 D_5 J_6 
Stack 7
G_5 B_1 I_7 J_1 E_3 
Stack 8
J_7 M_0 K_1 L_5 H_6 
Stack 9
O_1 F_0 E_2 F_4 B_2 
Stack 10
F_6 L_1 I_2 K_5 I_5 
Stack 11
J_5 I_0 I_3 I_8 F_7 
Stack 12
K_6 E_0 I_6 L_4 I_4 
Stack 13
E_4 G_3 L_0 I_1 E_1 
Stack 14
A_0 G_8 J_2 G_4 H_1 
Stack 15
N_2 J_4 A_1 F_3 H_4 
Stack 16
G_6 M_3 H_9 O_0 D_2 
Stack 17
D_0 H_2 J_3 A_2 C_0 
Stack 18
N_3 K_4 C_3 K_3 G_0 
