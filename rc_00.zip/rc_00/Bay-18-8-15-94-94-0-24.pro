Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_0 F_6 J_4 A_1 C_3 G_6 
Stack 2
G_1 M_4 H_2 C_2 H_9 A_2 
Stack 3
J_5 J_2 K_1 C_1 F_5 C_0 
Stack 4
N_1 I_8 I_5 D_5 D_3 F_4 
Stack 5
F_1 J_3 I_2 N_2 M_2 
Stack 6
H_0 O_0 H_8 E_4 O_2 
Stack 7
K_6 G_2 F_0 F_7 H_6 
Stack 8
H_3 B_1 O_1 G_5 E_6 
Stack 9
B_0 L_1 H_5 D_4 M_1 
Stack 10
G_4 K_5 D_1 J_0 K_2 
Stack 11
D_0 B_2 G_0 L_4 F_3 
Stack 12
H_1 I_4 H_7 A_0 I_1 
Stack 13
E_5 H_4 K_0 N_3 L_5 
Stack 14
K_4 D_2 K_3 J_1 C_4 
Stack 15
E_1 J_6 L_2 L_0 E_0 
Stack 16
B_3 G_7 F_2 N_0 M_0 
Stack 17
E_3 I_6 G_3 J_7 I_7 
Stack 18
E_2 G_8 I_3 M_3 L_3 
