Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_8 C_4 D_2 B_4 
Stack 2
A_10 B_14 D_0 D_7 
Stack 3
D_12 A_12 B_9 C_12 
Stack 4
E_8 A_11 A_9 C_1 
Stack 5
B_11 D_15 D_6 C_6 
Stack 6
A_6 D_14 B_2 E_3 
Stack 7
E_12 C_0 D_3 E_0 
Stack 8
B_0 B_6 D_5 E_1 
Stack 9
A_1 C_10 C_2 D_1 
Stack 10
B_1 A_0 C_14 A_14 
Stack 11
E_9 C_9 E_6 E_13 
Stack 12
B_5 C_7 C_16 A_4 
Stack 13
C_13 A_2 C_3 C_11 
Stack 14
E_2 D_9 D_10 E_7 
Stack 15
E_10 D_4 C_8 A_13 
Stack 16
B_3 B_7 E_11 C_15 
Stack 17
A_7 E_14 A_5 B_8 
Stack 18
B_12 C_5 D_8 E_4 
Stack 19
D_11 B_15 A_3 B_10 
Stack 20
B_13 E_5 D_13 
