Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_1 J_1 F_1 G_0 F_0 
Stack 2
C_3 H_4 G_4 A_1 A_2 
Stack 3
B_0 G_5 G_1 C_2 F_3 
Stack 4
B_3 D_0 F_2 C_4 D_4 
Stack 5
I_0 E_2 G_3 F_5 E_0 
Stack 6
A_0 J_2 G_2 B_1 H_3 
Stack 7
I_2 I_1 E_5 I_3 H_2 
Stack 8
D_5 D_1 E_4 C_0 H_0 
Stack 9
C_1 E_3 B_2 D_2 F_6 
Stack 10
F_4 E_6 H_1 D_3 J_0 
