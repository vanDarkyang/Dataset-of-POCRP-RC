Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 J_3 C_1 F_7 M_1 G_3 
Stack 2
L_4 G_8 I_1 E_1 H_4 H_5 
Stack 3
H_3 A_0 H_2 C_4 L_0 A_2 
Stack 4
G_6 F_1 C_2 L_1 H_0 L_3 
Stack 5
B_3 G_5 K_1 F_5 E_4 
Stack 6
G_2 E_6 B_0 E_5 I_2 
Stack 7
M_0 D_5 D_1 J_4 E_2 
Stack 8
D_3 B_2 M_4 F_0 H_8 
Stack 9
I_0 G_7 F_2 M_3 E_3 
Stack 10
D_0 D_2 F_3 H_6 J_1 
Stack 11
J_5 G_1 K_2 F_6 I_7 
Stack 12
C_0 G_0 D_4 K_5 I_4 
Stack 13
J_6 H_7 N_0 L_2 J_7 
Stack 14
L_5 B_1 N_3 J_2 N_1 
Stack 15
O_2 I_8 O_1 K_4 G_4 
Stack 16
H_9 J_0 K_0 O_0 I_6 
Stack 17
I_3 M_2 I_5 H_1 E_0 
Stack 18
F_4 N_2 K_6 K_3 C_3 
