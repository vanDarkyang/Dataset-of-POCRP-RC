Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 E_6 A_2 A_0 G_1 H_2 
Stack 2
K_3 F_3 J_0 I_4 L_0 I_0 
Stack 3
H_6 J_2 M_0 D_4 D_0 E_3 
Stack 4
H_8 I_1 H_5 B_2 J_4 M_2 
Stack 5
F_2 H_4 C_3 F_7 F_5 
Stack 6
H_7 I_5 K_5 K_1 C_2 
Stack 7
E_2 H_9 G_2 K_6 M_3 
Stack 8
M_4 L_2 L_5 G_4 H_0 
Stack 9
N_0 D_5 I_6 H_3 J_5 
Stack 10
L_1 D_3 G_0 E_0 F_1 
Stack 11
F_6 I_2 C_1 E_4 N_2 
Stack 12
B_1 E_1 J_7 I_3 N_1 
Stack 13
G_8 O_2 H_1 J_6 G_3 
Stack 14
O_1 K_0 E_5 L_4 F_0 
Stack 15
G_5 C_4 K_4 I_7 D_2 
Stack 16
J_3 K_2 J_1 C_0 B_0 
Stack 17
B_3 G_6 F_4 L_3 N_3 
Stack 18
M_1 O_0 A_1 I_8 G_7 
