Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 D_6 D_4 G_0 
Stack 2
F_0 F_6 F_4 H_2 
Stack 3
D_7 B_5 D_0 A_3 
Stack 4
J_4 G_1 F_5 I_2 
Stack 5
C_4 B_0 F_2 B_1 
Stack 6
E_2 E_8 G_3 H_5 
Stack 7
H_1 G_5 C_0 I_5 
Stack 8
F_7 J_0 A_0 C_6 
Stack 9
F_1 C_3 C_5 I_3 
Stack 10
J_3 D_2 G_7 A_1 
Stack 11
J_2 D_3 I_4 I_1 
Stack 12
A_2 A_4 C_2 G_6 
Stack 13
E_5 B_4 E_3 D_5 
Stack 14
J_1 B_3 E_1 E_4 
Stack 15
C_1 F_3 E_0 H_4 
Stack 16
G_4 B_2 H_6 G_2 
Stack 17
H_0 E_6 I_0 
Stack 18
E_7 F_8 H_3 
