Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_5 B_3 A_0 H_1 G_5 
Stack 2
C_5 A_2 E_2 F_4 F_0 
Stack 3
E_3 D_0 F_8 J_0 H_2 
Stack 4
D_2 C_3 B_1 G_2 B_2 
Stack 5
H_0 I_4 G_6 A_1 E_7 
Stack 6
I_0 A_4 D_5 F_1 G_1 
Stack 7
D_4 I_5 J_2 E_1 G_7 
Stack 8
F_7 D_7 E_6 G_0 G_3 
Stack 9
F_2 H_6 J_1 C_4 C_0 
Stack 10
E_0 C_1 B_4 B_5 D_1 
Stack 11
F_6 F_3 I_3 C_6 G_4 
Stack 12
A_3 F_5 I_1 H_3 I_2 
Stack 13
B_0 D_3 E_4 J_3 D_6 
Stack 14
C_2 H_4 H_5 J_4 E_8 
