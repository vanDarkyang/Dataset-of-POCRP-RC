Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
M_1 D_1 H_0 L_1 
Stack 2
D_3 G_1 L_0 F_5 
Stack 3
L_3 I_8 J_7 E_0 
Stack 4
L_4 E_6 M_2 O_1 
Stack 5
J_3 I_5 H_8 K_1 
Stack 6
F_6 B_1 J_5 F_0 
Stack 7
E_4 J_0 H_2 N_0 
Stack 8
C_3 G_0 K_2 G_7 
Stack 9
I_4 F_1 G_3 L_5 
Stack 10
B_0 H_5 B_2 N_3 
Stack 11
D_4 I_6 A_1 G_2 
Stack 12
M_4 H_3 E_5 E_1 
Stack 13
D_0 F_2 K_3 I_7 
Stack 14
M_3 C_4 B_3 H_1 
Stack 15
G_8 J_2 L_2 J_6 
Stack 16
M_0 C_2 N_1 K_5 
Stack 17
C_0 F_7 I_1 D_2 
Stack 18
H_4 K_6 I_2 A_0 
Stack 19
I_0 I_3 K_0 J_4 
Stack 20
F_4 G_5 A_2 H_6 
Stack 21
G_4 N_2 D_5 E_3 
Stack 22
E_2 G_6 F_3 O_2 
Stack 23
K_4 J_1 C_1 
Stack 24
H_9 O_0 H_7 
