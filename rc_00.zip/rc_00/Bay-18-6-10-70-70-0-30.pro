Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_0 J_2 G_5 F_0 
Stack 2
D_5 I_5 F_2 H_1 
Stack 3
C_5 B_2 H_3 F_5 
Stack 4
C_2 B_5 F_7 D_4 
Stack 5
D_1 B_4 F_8 D_7 
Stack 6
G_3 G_6 I_3 E_6 
Stack 7
E_4 C_3 F_6 I_1 
Stack 8
G_1 E_1 H_6 D_3 
Stack 9
C_0 A_0 B_3 D_2 
Stack 10
F_1 I_0 A_4 G_0 
Stack 11
A_1 J_1 E_0 G_7 
Stack 12
E_5 E_7 C_4 J_3 
Stack 13
H_4 J_0 A_2 C_6 
Stack 14
J_4 B_1 H_5 B_0 
Stack 15
F_3 G_4 I_2 C_1 
Stack 16
E_8 I_4 D_6 F_4 
Stack 17
E_3 H_2 E_2 
Stack 18
A_3 G_2 H_0 
