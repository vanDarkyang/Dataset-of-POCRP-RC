Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_3 G_4 J_0 E_0 I_3 
Stack 2
F_1 A_0 G_2 C_3 I_2 
Stack 3
D_1 E_4 F_0 E_3 C_2 
Stack 4
B_3 B_2 H_0 F_6 E_1 
Stack 5
B_0 J_1 C_0 H_2 D_3 
Stack 6
G_1 B_1 C_1 I_1 F_2 
Stack 7
F_3 D_5 D_4 G_3 G_0 
Stack 8
F_5 A_2 H_1 E_5 D_2 
Stack 9
D_0 C_4 A_1 F_4 J_2 
Stack 10
E_2 E_6 I_0 H_4 G_5 
