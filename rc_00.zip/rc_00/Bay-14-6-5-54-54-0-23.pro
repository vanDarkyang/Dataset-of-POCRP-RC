Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_3 B_6 E_5 B_10 
Stack 2
D_0 B_7 C_1 A_9 
Stack 3
E_1 C_0 C_3 D_8 
Stack 4
D_6 A_3 E_9 D_9 
Stack 5
B_2 C_4 D_4 B_5 
Stack 6
A_1 C_6 A_4 B_9 
Stack 7
B_0 E_8 A_0 A_5 
Stack 8
E_6 A_8 D_5 C_8 
Stack 9
D_3 C_10 A_6 E_2 
Stack 10
B_8 A_2 C_7 D_10 
Stack 11
E_7 C_5 D_7 C_11 
Stack 12
B_4 C_2 E_0 C_9 
Stack 13
A_7 D_2 E_3 
Stack 14
E_4 B_1 D_1 
