Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_1 E_13 A_5 D_0 E_14 E_2 
Stack 2
B_15 A_2 D_1 A_3 B_6 E_3 
Stack 3
D_5 C_14 C_10 D_4 C_1 B_7 
Stack 4
D_8 B_10 C_2 A_11 C_6 C_3 
Stack 5
E_9 A_13 B_13 A_6 E_0 
Stack 6
A_12 D_15 C_16 B_4 D_13 
Stack 7
A_0 A_8 E_10 A_1 A_4 
Stack 8
C_13 B_8 B_11 B_9 D_3 
Stack 9
B_2 E_4 B_14 E_11 E_12 
Stack 10
D_10 C_9 B_0 D_14 A_10 
Stack 11
E_6 C_12 C_15 C_0 D_9 
Stack 12
C_8 D_12 B_12 B_3 E_8 
Stack 13
D_7 C_11 D_11 E_5 D_2 
Stack 14
B_1 D_6 A_9 A_7 C_7 
Stack 15
A_14 E_7 C_5 C_4 B_5 
