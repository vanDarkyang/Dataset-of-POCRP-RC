Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_1 B_4 G_11 A_8 F_6 F_9 
Stack 2
C_1 F_10 G_12 E_10 J_6 G_4 
Stack 3
D_11 E_8 G_0 C_9 C_5 A_1 
Stack 4
E_0 C_6 A_3 J_4 I_0 I_2 
Stack 5
D_5 A_2 A_6 H_3 D_10 E_2 
Stack 6
E_6 D_8 I_10 G_2 C_2 
Stack 7
B_7 B_6 G_5 E_5 G_6 
Stack 8
B_2 C_8 I_1 H_4 B_1 
Stack 9
D_6 B_10 I_9 F_8 F_5 
Stack 10
E_11 F_4 E_13 H_7 A_4 
Stack 11
E_7 J_0 I_8 D_12 J_2 
Stack 12
E_4 C_11 G_3 H_9 F_1 
Stack 13
F_3 G_9 B_8 J_3 H_6 
Stack 14
D_7 E_9 G_10 H_10 F_13 
Stack 15
H_2 G_8 J_7 D_3 D_0 
Stack 16
B_9 A_0 I_5 G_7 H_5 
Stack 17
I_3 B_0 H_8 I_4 F_0 
Stack 18
A_9 B_5 E_1 H_1 F_11 
Stack 19
A_7 C_10 D_4 D_2 J_1 
Stack 20
A_5 I_7 J_8 C_0 H_0 
Stack 21
D_1 J_5 F_12 C_7 F_7 
Stack 22
C_3 B_3 I_6 D_9 C_4 
Stack 23
J_9 F_2 E_3 H_11 E_12 
