Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 E_3 B_0 F_2 I_3 
Stack 2
C_4 G_4 E_6 A_0 G_1 
Stack 3
B_3 C_3 H_3 I_1 I_0 
Stack 4
D_5 I_2 D_2 H_4 G_3 
Stack 5
C_1 E_0 G_5 D_0 H_0 
Stack 6
B_1 G_2 J_0 F_5 C_2 
Stack 7
J_1 F_0 E_5 E_2 D_3 
Stack 8
A_2 J_2 H_2 H_1 F_4 
Stack 9
D_4 D_1 G_0 C_0 F_6 
Stack 10
F_1 E_1 F_3 B_2 E_4 
