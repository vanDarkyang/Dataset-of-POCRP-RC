Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_4 F_6 B_2 A_3 J_3 
Stack 2
D_1 E_1 H_6 G_6 A_4 
Stack 3
C_2 D_5 C_0 A_0 E_8 
Stack 4
E_2 D_4 D_7 G_0 E_5 
Stack 5
J_0 I_2 G_1 H_0 G_2 
Stack 6
I_0 E_7 E_4 C_6 H_1 
Stack 7
F_0 J_1 I_5 D_0 B_5 
Stack 8
F_4 B_4 J_4 J_2 H_2 
Stack 9
F_8 G_7 H_4 H_3 E_0 
Stack 10
B_1 G_5 G_4 H_5 G_3 
Stack 11
F_3 F_2 B_3 F_1 C_1 
Stack 12
A_1 I_3 F_5 A_2 I_1 
Stack 13
I_4 D_6 B_0 F_7 E_3 
Stack 14
C_5 C_3 E_6 D_2 D_3 
