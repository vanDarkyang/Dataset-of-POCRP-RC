Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_5 E_1 C_0 D_0 C_3 
Stack 2
B_1 D_4 C_2 F_6 I_0 
Stack 3
J_2 I_1 J_1 F_2 E_2 
Stack 4
H_1 E_3 E_6 D_2 G_5 
Stack 5
D_1 E_0 F_1 G_4 A_1 
Stack 6
I_3 B_3 A_0 J_0 F_0 
Stack 7
F_5 G_2 G_1 D_3 B_2 
Stack 8
G_3 D_5 E_4 G_0 H_0 
Stack 9
C_4 F_3 F_4 I_2 A_2 
Stack 10
H_2 C_1 H_3 H_4 B_0 
