Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_0 D_8 A_3 A_14 B_14 D_10 
Stack 2
E_6 A_12 A_10 A_9 B_6 C_13 
Stack 3
B_13 C_15 B_10 D_13 C_12 E_7 
Stack 4
B_9 E_11 E_2 A_13 C_8 D_14 
Stack 5
C_14 E_9 C_10 D_0 C_1 
Stack 6
E_13 B_11 E_10 E_3 A_6 
Stack 7
D_6 B_15 C_2 E_5 E_8 
Stack 8
D_15 C_7 A_1 B_7 B_2 
Stack 9
A_2 E_0 B_1 D_9 E_14 
Stack 10
C_16 C_9 C_11 A_8 D_3 
Stack 11
D_11 D_2 C_3 B_0 A_11 
Stack 12
A_5 E_12 D_4 D_7 A_4 
Stack 13
A_0 B_8 D_12 D_1 B_3 
Stack 14
C_5 B_5 E_4 C_6 E_1 
Stack 15
A_7 B_12 C_4 B_4 D_5 
