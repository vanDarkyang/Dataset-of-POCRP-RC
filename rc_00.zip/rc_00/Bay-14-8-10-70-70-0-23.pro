Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_4 G_6 F_2 A_0 C_0 
Stack 2
H_6 F_3 E_5 I_4 F_8 
Stack 3
G_5 E_4 E_0 D_3 G_0 
Stack 4
D_5 D_1 E_8 D_7 I_5 
Stack 5
C_4 E_3 J_0 C_1 C_2 
Stack 6
C_3 J_1 F_0 G_1 A_4 
Stack 7
A_3 H_4 D_2 F_4 D_4 
Stack 8
B_5 F_1 I_2 F_6 A_1 
Stack 9
E_7 H_1 E_6 D_6 I_3 
Stack 10
E_1 H_0 J_2 B_2 F_5 
Stack 11
G_4 J_3 B_4 B_0 C_5 
Stack 12
F_7 I_1 G_7 B_3 H_5 
Stack 13
B_1 G_2 H_3 E_2 D_0 
Stack 14
C_6 A_2 G_3 H_2 I_0 
