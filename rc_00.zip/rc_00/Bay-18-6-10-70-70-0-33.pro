Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_3 D_5 E_6 F_2 
Stack 2
E_4 I_0 B_5 J_0 
Stack 3
I_3 H_5 J_4 F_6 
Stack 4
G_7 E_2 A_2 A_3 
Stack 5
A_1 B_3 G_2 I_1 
Stack 6
B_2 E_0 I_2 J_1 
Stack 7
H_3 H_0 D_1 G_6 
Stack 8
B_0 G_5 I_5 G_3 
Stack 9
A_0 F_7 G_0 F_5 
Stack 10
F_4 C_4 J_2 F_8 
Stack 11
F_3 C_5 D_7 E_1 
Stack 12
E_7 D_0 D_6 C_6 
Stack 13
C_3 G_4 I_4 B_1 
Stack 14
H_4 F_0 H_2 E_3 
Stack 15
D_2 D_4 H_6 E_5 
Stack 16
F_1 C_0 A_4 G_1 
Stack 17
B_4 C_2 C_1 
Stack 18
D_3 H_1 E_8 
