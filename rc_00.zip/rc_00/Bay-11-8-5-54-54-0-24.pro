Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_3 C_3 C_10 D_8 D_7 
Stack 2
B_5 B_10 C_1 E_8 E_3 
Stack 3
A_4 E_6 B_0 B_7 E_1 
Stack 4
E_7 A_9 C_4 D_3 D_5 
Stack 5
D_0 B_9 C_8 C_0 E_9 
Stack 6
D_9 C_2 E_4 D_10 D_6 
Stack 7
D_1 D_2 B_6 B_2 A_2 
Stack 8
A_0 C_7 C_9 E_0 A_6 
Stack 9
C_11 A_5 A_8 A_1 B_4 
Stack 10
B_1 C_6 E_5 B_3 D_4 
Stack 11
B_8 E_2 A_7 C_5 
