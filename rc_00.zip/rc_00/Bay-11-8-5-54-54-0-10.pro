Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_7 B_4 C_11 D_5 E_6 
Stack 2
B_0 C_5 D_4 E_9 D_9 
Stack 3
A_9 A_8 D_7 A_2 B_3 
Stack 4
C_9 B_10 A_1 E_1 C_10 
Stack 5
B_6 E_8 C_6 D_2 D_3 
Stack 6
A_3 A_5 B_9 C_4 C_3 
Stack 7
E_2 C_1 E_7 D_8 B_5 
Stack 8
B_8 D_1 E_3 D_0 A_7 
Stack 9
A_0 C_2 A_6 C_0 C_7 
Stack 10
A_4 C_8 B_1 D_10 E_5 
Stack 11
E_4 D_6 B_2 E_0 
