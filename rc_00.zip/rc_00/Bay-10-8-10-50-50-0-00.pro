Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_0 E_5 F_0 B_0 C_0 
Stack 2
E_4 H_1 G_4 F_5 C_4 
Stack 3
B_2 B_1 G_0 I_1 D_3 
Stack 4
F_3 G_2 G_5 I_3 F_2 
Stack 5
F_4 E_0 E_2 J_2 E_6 
Stack 6
D_2 F_1 H_2 H_3 E_3 
Stack 7
C_1 I_2 A_0 B_3 A_2 
Stack 8
D_4 E_1 D_1 J_1 F_6 
Stack 9
C_2 A_1 H_4 G_1 D_5 
Stack 10
J_0 D_0 G_3 I_0 C_3 
