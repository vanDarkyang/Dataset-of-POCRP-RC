Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_3 I_2 A_8 G_6 J_4 G_2 
Stack 2
C_3 C_2 G_9 B_8 F_10 H_10 
Stack 3
H_8 E_11 F_1 B_1 E_7 E_12 
Stack 4
D_9 D_1 I_4 A_9 J_9 J_7 
Stack 5
C_4 F_8 F_12 D_2 E_13 D_3 
Stack 6
F_6 B_6 B_9 H_9 I_5 
Stack 7
G_8 B_3 D_10 B_10 E_2 
Stack 8
E_5 H_6 F_4 E_10 I_6 
Stack 9
D_5 E_0 A_2 F_13 I_8 
Stack 10
B_5 H_7 I_0 J_3 D_7 
Stack 11
I_7 C_0 H_3 G_1 J_0 
Stack 12
H_1 D_4 F_2 C_8 C_9 
Stack 13
A_4 J_2 D_8 D_0 A_0 
Stack 14
F_0 E_6 C_10 C_7 I_1 
Stack 15
F_7 H_0 J_5 A_7 G_11 
Stack 16
J_6 G_5 C_5 B_7 I_9 
Stack 17
D_11 A_6 I_3 C_11 B_4 
Stack 18
H_11 E_4 G_3 G_10 C_1 
Stack 19
A_1 H_5 F_3 F_11 J_8 
Stack 20
E_1 B_2 I_10 H_2 H_4 
Stack 21
D_12 G_12 D_6 F_5 B_0 
Stack 22
E_3 J_1 C_6 G_0 E_8 
Stack 23
A_5 F_9 G_4 G_7 E_9 
