Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_8 C_6 A_0 A_14 
Stack 2
A_3 C_2 A_5 B_8 
Stack 3
A_1 B_6 C_12 C_10 
Stack 4
A_13 B_10 A_10 B_12 
Stack 5
C_1 B_9 C_5 B_1 
Stack 6
C_3 A_9 B_4 B_15 
Stack 7
B_7 B_5 A_12 C_9 
Stack 8
A_7 A_11 C_4 B_13 
Stack 9
B_14 A_6 A_4 C_7 
Stack 10
A_2 C_14 B_11 C_11 
Stack 11
B_0 B_3 C_8 
Stack 12
C_0 B_2 C_13 
