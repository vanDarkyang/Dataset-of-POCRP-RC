Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_11 A_11 B_12 D_9 
Stack 2
C_0 B_1 E_14 E_11 
Stack 3
D_2 B_15 A_0 D_12 
Stack 4
A_5 C_4 B_13 D_10 
Stack 5
C_7 B_2 D_0 E_6 
Stack 6
B_5 B_6 E_13 A_13 
Stack 7
A_14 C_6 B_4 E_4 
Stack 8
C_2 E_1 A_2 C_3 
Stack 9
E_2 C_15 E_9 D_4 
Stack 10
C_14 C_1 D_8 C_13 
Stack 11
B_0 D_13 D_14 B_9 
Stack 12
C_12 E_12 A_12 A_1 
Stack 13
B_8 B_3 D_15 E_0 
Stack 14
A_8 D_3 B_7 B_10 
Stack 15
C_8 A_4 E_7 C_16 
Stack 16
D_1 A_3 E_8 C_9 
Stack 17
E_3 C_11 D_11 A_9 
Stack 18
C_5 B_14 A_6 E_10 
Stack 19
D_6 D_5 E_5 A_7 
Stack 20
D_7 A_10 C_10 
