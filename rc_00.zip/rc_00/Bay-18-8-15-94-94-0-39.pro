Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
L_4 B_3 L_3 G_1 H_9 G_0 
Stack 2
M_3 A_2 M_1 E_1 H_0 M_4 
Stack 3
A_0 I_6 H_1 H_8 M_0 H_4 
Stack 4
E_6 K_5 O_1 L_0 D_4 H_6 
Stack 5
F_5 G_6 I_1 M_2 J_7 
Stack 6
A_1 I_4 K_6 C_0 C_3 
Stack 7
F_6 F_4 I_5 H_2 J_1 
Stack 8
B_2 J_5 F_2 F_0 N_1 
Stack 9
N_0 D_3 C_1 C_4 J_4 
Stack 10
F_3 G_8 K_4 L_2 E_0 
Stack 11
H_7 I_2 J_3 K_2 G_4 
Stack 12
N_2 J_2 B_0 E_3 J_0 
Stack 13
I_7 E_5 L_5 E_4 G_7 
Stack 14
C_2 J_6 G_2 O_2 H_5 
Stack 15
G_5 N_3 I_0 K_0 F_1 
Stack 16
K_1 D_5 I_3 K_3 B_1 
Stack 17
L_1 F_7 D_2 G_3 I_8 
Stack 18
E_2 O_0 H_3 D_0 D_1 
