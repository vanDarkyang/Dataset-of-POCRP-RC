Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 D_1 B_4 A_1 A_3 
Stack 2
D_2 D_4 A_2 H_5 I_0 
Stack 3
A_4 F_4 C_4 F_1 E_3 
Stack 4
E_7 B_3 H_0 C_1 E_1 
Stack 5
E_6 B_1 H_2 G_7 E_8 
Stack 6
I_2 D_5 B_0 C_6 J_2 
Stack 7
G_0 J_1 F_6 G_4 E_4 
Stack 8
B_2 I_1 F_7 A_0 E_0 
Stack 9
D_3 F_5 F_3 D_7 J_4 
Stack 10
J_3 G_3 J_0 I_5 E_5 
Stack 11
G_2 G_5 C_5 C_0 G_6 
Stack 12
H_1 E_2 D_0 H_3 F_8 
Stack 13
H_6 G_1 I_4 C_3 I_3 
Stack 14
F_2 F_0 D_6 B_5 H_4 
