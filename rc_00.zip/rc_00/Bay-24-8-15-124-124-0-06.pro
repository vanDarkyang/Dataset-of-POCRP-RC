Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_3 K_4 I_10 G_4 N_1 J_4 
Stack 2
H_0 F_3 G_8 O_2 B_3 L_0 
Stack 3
A_4 N_0 I_3 M_2 O_1 M_0 
Stack 4
D_5 K_1 L_7 F_9 K_0 I_1 
Stack 5
H_6 J_6 H_2 I_2 L_6 
Stack 6
H_10 B_5 E_0 O_4 C_3 
Stack 7
E_4 C_4 K_8 B_4 D_0 
Stack 8
L_1 F_6 I_5 G_5 J_7 
Stack 9
I_7 F_7 N_3 K_2 K_6 
Stack 10
G_0 F_4 H_11 M_6 C_1 
Stack 11
H_9 F_1 C_5 M_4 N_2 
Stack 12
L_5 G_3 N_4 I_9 J_1 
Stack 13
M_5 H_1 D_3 F_5 D_7 
Stack 14
J_8 O_3 M_1 F_8 O_0 
Stack 15
L_4 G_1 J_2 I_6 E_2 
Stack 16
A_2 C_2 J_9 E_7 H_7 
Stack 17
E_1 H_4 C_0 A_1 E_8 
Stack 18
K_7 C_6 G_6 M_3 A_0 
Stack 19
I_0 D_4 J_5 K_3 I_8 
Stack 20
E_5 H_3 H_5 D_6 N_5 
Stack 21
E_6 F_0 L_3 D_1 G_9 
Stack 22
B_0 G_10 E_3 D_2 F_2 
Stack 23
B_2 H_8 J_0 G_2 K_5 
Stack 24
G_7 J_3 I_4 B_1 L_2 
