Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
M_4 G_3 G_1 F_2 
Stack 2
K_1 L_5 H_1 A_2 
Stack 3
N_0 G_6 F_3 F_7 
Stack 4
I_8 C_0 I_4 J_1 
Stack 5
C_2 H_3 D_5 M_3 
Stack 6
B_3 K_5 C_3 A_1 
Stack 7
M_0 G_5 J_5 H_9 
Stack 8
C_1 I_5 J_0 L_0 
Stack 9
C_4 E_3 M_1 L_1 
Stack 10
O_2 J_4 O_0 G_8 
Stack 11
A_0 F_1 D_1 E_1 
Stack 12
I_6 E_6 L_3 O_1 
Stack 13
H_2 N_1 D_4 N_3 
Stack 14
L_4 K_2 N_2 E_2 
Stack 15
M_2 H_4 I_7 G_0 
Stack 16
B_1 I_2 E_0 G_7 
Stack 17
H_5 B_2 J_6 H_8 
Stack 18
H_0 F_0 K_0 D_2 
Stack 19
D_3 I_1 I_0 J_7 
Stack 20
J_2 I_3 L_2 K_6 
Stack 21
H_7 E_4 K_4 F_5 
Stack 22
H_6 D_0 E_5 G_4 
Stack 23
J_3 B_0 K_3 
Stack 24
F_4 F_6 G_2 
