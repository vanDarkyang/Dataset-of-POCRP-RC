Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_6 C_9 E_0 E_2 
Stack 2
C_8 C_16 D_6 E_5 
Stack 3
B_5 E_10 C_5 D_1 
Stack 4
C_1 B_13 A_11 B_11 
Stack 5
A_14 D_5 D_15 E_3 
Stack 6
B_14 B_10 C_4 A_2 
Stack 7
A_1 E_8 C_10 B_6 
Stack 8
B_4 C_2 E_4 C_13 
Stack 9
B_8 C_15 C_12 E_7 
Stack 10
E_9 A_9 A_0 E_6 
Stack 11
B_0 A_10 E_14 E_11 
Stack 12
D_14 E_12 A_5 A_4 
Stack 13
D_0 D_10 B_2 E_1 
Stack 14
D_2 C_11 B_1 A_3 
Stack 15
C_3 B_12 B_7 A_12 
Stack 16
A_13 E_13 C_7 A_8 
Stack 17
D_9 D_3 D_4 D_12 
Stack 18
B_9 D_13 C_0 C_6 
Stack 19
B_3 D_7 D_11 C_14 
Stack 20
D_8 A_7 B_15 
