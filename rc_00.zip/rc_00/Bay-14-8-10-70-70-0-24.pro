Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_3 G_2 F_7 D_7 C_3 
Stack 2
A_4 D_0 E_7 C_6 I_5 
Stack 3
E_3 D_4 D_5 I_2 H_4 
Stack 4
B_3 G_1 J_2 D_2 J_3 
Stack 5
H_2 A_0 H_5 D_6 H_0 
Stack 6
F_1 C_0 E_0 A_2 E_2 
Stack 7
J_0 G_5 H_3 E_1 B_0 
Stack 8
E_6 G_4 I_3 J_4 E_5 
Stack 9
F_3 A_3 B_4 H_6 F_0 
Stack 10
C_5 J_1 C_1 F_4 E_4 
Stack 11
C_4 F_5 B_5 C_2 F_2 
Stack 12
F_6 F_8 D_1 E_8 G_7 
Stack 13
A_1 H_1 I_4 B_2 G_6 
Stack 14
I_0 G_3 B_1 I_1 G_0 
