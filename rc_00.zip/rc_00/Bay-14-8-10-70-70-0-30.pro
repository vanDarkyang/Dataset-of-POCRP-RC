Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_0 F_3 J_1 F_6 F_5 
Stack 2
D_5 E_8 E_7 H_6 D_4 
Stack 3
C_5 E_3 J_0 B_3 D_7 
Stack 4
C_2 A_3 B_1 A_4 E_6 
Stack 5
D_1 J_2 G_4 E_0 I_1 
Stack 6
G_3 I_5 I_4 C_4 D_3 
Stack 7
E_4 B_2 H_2 A_2 D_2 
Stack 8
G_1 B_5 G_2 H_5 G_0 
Stack 9
C_0 B_4 G_5 I_2 G_7 
Stack 10
F_1 G_6 F_2 D_6 J_3 
Stack 11
A_1 C_3 H_3 E_2 C_6 
Stack 12
E_5 E_1 F_7 H_0 B_0 
Stack 13
H_4 A_0 F_8 F_0 C_1 
Stack 14
J_4 I_0 I_3 H_1 F_4 
