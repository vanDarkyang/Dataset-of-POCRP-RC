Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 C_3 A_2 B_6 
Stack 2
E_8 E_7 C_4 E_6 
Stack 3
A_3 D_3 E_3 C_7 
Stack 4
B_3 A_1 A_5 D_0 
Stack 5
A_9 A_4 D_6 D_5 
Stack 6
B_9 B_10 D_7 C_9 
Stack 7
D_8 C_2 B_1 A_7 
Stack 8
D_4 E_9 B_2 C_8 
Stack 9
E_4 C_5 E_1 B_5 
Stack 10
B_0 C_0 A_8 B_7 
Stack 11
C_10 D_9 E_2 C_6 
Stack 12
C_1 C_11 A_0 D_10 
Stack 13
E_0 B_8 D_2 
Stack 14
B_4 A_6 E_5 
