Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_7 B_10 E_7 D_10 
Stack 2
B_0 E_8 E_3 E_0 
Stack 3
A_9 A_5 A_6 E_6 
Stack 4
C_9 C_1 B_1 D_9 
Stack 5
B_6 D_1 B_2 B_3 
Stack 6
A_3 C_2 D_5 C_10 
Stack 7
E_2 C_8 E_9 D_3 
Stack 8
B_8 D_6 A_2 C_3 
Stack 9
A_0 C_11 E_1 B_5 
Stack 10
A_4 D_4 D_2 A_7 
Stack 11
E_4 D_7 C_4 C_7 
Stack 12
B_4 A_1 D_8 E_5 
Stack 13
C_5 C_6 D_0 
Stack 14
A_8 B_9 C_0 
