Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_0 B_4 H_11 E_3 A_3 J_0 
Stack 2
O_3 N_1 F_5 N_0 K_0 G_1 
Stack 3
G_8 L_2 L_6 A_2 L_3 H_4 
Stack 4
D_7 J_9 N_5 F_1 C_2 A_4 
Stack 5
F_9 F_4 J_1 M_0 N_2 
Stack 6
J_5 I_10 B_5 E_1 D_5 
Stack 7
F_3 G_3 H_2 A_0 I_7 
Stack 8
G_5 J_4 E_6 J_8 F_2 
Stack 9
E_2 I_0 H_7 K_7 I_5 
Stack 10
I_4 C_3 F_0 L_5 E_4 
Stack 11
K_4 H_10 B_1 G_4 G_9 
Stack 12
E_8 M_3 O_1 K_1 F_8 
Stack 13
I_8 B_3 J_7 O_4 K_2 
Stack 14
D_6 E_0 L_0 C_6 E_5 
Stack 15
M_5 M_4 D_4 I_9 G_0 
Stack 16
J_6 O_0 D_3 K_3 H_9 
Stack 17
M_2 L_7 I_3 B_2 G_2 
Stack 18
L_4 D_1 L_1 H_5 C_0 
Stack 19
C_5 H_6 K_5 E_7 K_6 
Stack 20
H_3 J_3 I_2 G_7 M_1 
Stack 21
D_0 D_2 I_1 J_2 A_1 
Stack 22
G_10 C_4 B_0 H_1 F_6 
Stack 23
N_3 O_2 K_8 H_8 I_6 
Stack 24
C_1 F_7 G_6 N_4 M_6 
