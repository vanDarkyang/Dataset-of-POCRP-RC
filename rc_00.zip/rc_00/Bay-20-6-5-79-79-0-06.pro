Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_4 C_6 B_15 E_11 
Stack 2
B_13 D_0 C_16 E_0 
Stack 3
A_0 E_3 A_10 C_3 
Stack 4
D_7 C_1 D_11 D_15 
Stack 5
C_9 D_3 B_12 B_14 
Stack 6
D_5 A_6 E_14 E_10 
Stack 7
C_7 A_2 A_5 A_8 
Stack 8
C_2 C_11 A_14 E_4 
Stack 9
E_9 B_6 E_8 D_8 
Stack 10
A_9 C_15 D_2 B_10 
Stack 11
C_12 B_7 A_3 B_0 
Stack 12
C_0 B_2 D_10 B_11 
Stack 13
C_8 D_14 D_6 E_7 
Stack 14
D_4 E_13 C_5 D_9 
Stack 15
B_5 E_12 A_11 E_2 
Stack 16
C_14 B_3 D_13 E_1 
Stack 17
A_13 A_1 C_13 D_12 
Stack 18
B_4 E_5 A_12 B_9 
Stack 19
C_10 D_1 B_1 A_7 
Stack 20
B_8 E_6 C_4 
