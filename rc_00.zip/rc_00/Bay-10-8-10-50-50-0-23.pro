Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_4 F_2 C_0 G_4 E_1 
Stack 2
H_1 A_1 D_0 D_2 F_3 
Stack 3
F_6 E_3 E_4 G_2 J_2 
Stack 4
E_0 F_1 B_2 I_2 E_5 
Stack 5
B_3 J_0 A_2 H_4 D_3 
Stack 6
G_1 G_0 H_2 I_3 I_1 
Stack 7
D_1 F_0 J_1 E_6 F_4 
Stack 8
A_0 I_0 C_1 H_3 H_0 
Stack 9
C_4 B_1 G_5 C_2 G_3 
Stack 10
D_5 B_0 E_2 F_5 C_3 
