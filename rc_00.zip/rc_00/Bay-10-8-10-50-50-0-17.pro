Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 B_1 G_5 I_2 D_5 
Stack 2
D_0 B_3 B_0 A_0 C_0 
Stack 3
D_2 E_0 F_0 I_0 F_1 
Stack 4
I_1 E_1 A_1 H_1 J_1 
Stack 5
F_6 G_4 J_2 E_6 E_3 
Stack 6
G_3 A_2 H_4 H_3 I_3 
Stack 7
C_2 E_5 H_2 F_5 F_4 
Stack 8
E_4 C_3 G_0 D_4 H_0 
Stack 9
D_3 E_2 F_2 B_2 F_3 
Stack 10
C_4 C_1 J_0 G_1 G_2 
