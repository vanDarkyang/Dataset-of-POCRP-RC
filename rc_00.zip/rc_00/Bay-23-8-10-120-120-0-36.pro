Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_12 E_0 B_3 F_13 C_3 B_10 
Stack 2
D_11 E_3 H_9 H_6 H_11 D_10 
Stack 3
D_5 D_8 D_6 G_5 E_12 F_10 
Stack 4
A_3 F_1 J_5 A_6 A_0 J_1 
Stack 5
B_1 D_1 J_4 C_0 E_8 B_8 
Stack 6
H_10 I_7 D_7 E_1 F_3 
Stack 7
C_4 G_10 C_2 A_8 I_10 
Stack 8
C_11 I_1 E_4 H_1 G_0 
Stack 9
G_4 D_9 H_8 C_10 A_2 
Stack 10
I_0 E_10 B_5 H_2 F_6 
Stack 11
C_6 A_1 J_9 F_0 I_5 
Stack 12
A_4 G_12 H_5 B_2 F_9 
Stack 13
H_3 H_0 B_0 J_7 D_12 
Stack 14
B_6 C_9 F_11 E_7 C_1 
Stack 15
G_8 E_11 G_11 E_5 G_9 
Stack 16
E_9 G_3 J_8 A_5 B_9 
Stack 17
I_3 F_8 B_4 J_0 F_5 
Stack 18
A_7 E_6 I_2 H_7 J_3 
Stack 19
F_7 B_7 D_3 I_8 F_4 
Stack 20
C_5 G_1 D_4 D_0 J_6 
Stack 21
E_2 G_7 F_2 E_13 G_6 
Stack 22
I_9 D_2 A_9 C_8 I_4 
Stack 23
C_7 I_6 H_4 J_2 G_2 
