Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_2 G_0 I_5 F_1 N_5 E_3 
Stack 2
D_3 H_9 J_9 E_8 L_7 H_6 
Stack 3
E_7 D_0 M_5 F_8 M_4 B_4 
Stack 4
F_2 L_1 H_2 H_8 C_1 H_7 
Stack 5
F_4 I_3 I_4 D_4 K_2 
Stack 6
N_1 J_7 D_7 G_1 H_3 
Stack 7
C_3 G_3 A_2 A_1 C_2 
Stack 8
F_7 K_1 E_5 K_4 H_1 
Stack 9
J_3 B_5 J_4 A_4 I_1 
Stack 10
G_5 G_4 O_3 I_10 D_1 
Stack 11
J_1 M_1 E_2 K_0 J_8 
Stack 12
L_6 H_5 H_11 I_6 G_9 
Stack 13
B_1 I_7 J_0 M_0 I_2 
Stack 14
N_3 G_7 B_3 N_0 K_8 
Stack 15
E_0 B_0 J_5 J_2 L_0 
Stack 16
F_5 F_0 O_1 E_1 O_2 
Stack 17
F_6 C_6 E_6 J_6 O_0 
Stack 18
I_8 K_5 H_10 O_4 A_0 
Stack 19
C_4 F_9 I_9 L_4 D_5 
Stack 20
M_6 M_3 K_6 G_10 N_2 
Stack 21
I_0 F_3 D_6 L_5 K_7 
Stack 22
N_4 E_4 A_3 K_3 L_3 
Stack 23
M_2 C_5 C_0 G_6 L_2 
Stack 24
G_2 G_8 H_0 B_2 H_4 
