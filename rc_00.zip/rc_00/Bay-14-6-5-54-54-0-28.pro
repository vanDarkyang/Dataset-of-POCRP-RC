Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_10 A_0 D_2 E_3 
Stack 2
C_0 B_8 E_6 E_5 
Stack 3
B_7 C_3 B_10 A_9 
Stack 4
C_8 D_5 D_6 C_7 
Stack 5
C_4 D_7 E_7 E_8 
Stack 6
B_5 E_1 E_2 B_6 
Stack 7
A_6 A_1 D_4 A_8 
Stack 8
C_9 C_5 C_10 D_3 
Stack 9
A_4 B_4 B_2 A_7 
Stack 10
C_11 E_9 C_1 B_1 
Stack 11
C_2 B_9 B_0 E_4 
Stack 12
B_3 D_0 E_0 A_3 
Stack 13
A_2 D_9 C_6 
Stack 14
D_1 A_5 D_8 
