Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_6 C_2 D_3 E_4 A_6 
Stack 2
B_10 D_8 C_9 A_0 B_8 
Stack 3
C_3 C_0 A_1 C_7 D_0 
Stack 4
A_8 B_7 B_2 B_3 D_10 
Stack 5
B_0 D_7 A_7 D_5 D_9 
Stack 6
A_3 C_4 E_2 B_5 B_1 
Stack 7
C_5 E_0 A_2 A_9 B_4 
Stack 8
D_2 E_8 E_9 E_6 E_3 
Stack 9
D_6 E_5 D_4 B_9 C_10 
Stack 10
E_1 C_8 C_11 A_4 D_1 
Stack 11
E_7 C_1 B_6 A_5 
