Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_9 E_1 D_10 D_9 
Stack 2
D_0 E_3 D_1 B_5 
Stack 3
C_3 C_6 A_0 E_6 
Stack 4
C_11 D_6 E_7 A_8 
Stack 5
A_6 B_8 A_4 D_2 
Stack 6
C_10 D_7 B_4 B_6 
Stack 7
C_2 E_2 E_8 A_7 
Stack 8
D_8 B_3 C_8 B_0 
Stack 9
B_10 A_2 C_0 C_7 
Stack 10
B_2 A_9 E_9 B_7 
Stack 11
E_4 A_1 E_5 D_5 
Stack 12
C_4 A_5 C_5 B_1 
Stack 13
B_9 E_0 D_4 
Stack 14
A_3 C_1 D_3 
