Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_2 B_2 G_3 J_2 C_0 
Stack 2
I_1 E_5 H_1 E_3 E_2 
Stack 3
D_1 I_0 E_4 F_1 G_0 
Stack 4
I_2 B_3 F_6 E_0 A_0 
Stack 5
B_1 C_4 A_2 E_6 H_2 
Stack 6
A_1 J_1 F_3 C_3 D_3 
Stack 7
D_2 H_3 F_2 G_1 F_0 
Stack 8
I_3 G_4 D_4 H_0 C_1 
Stack 9
H_4 E_1 C_2 F_4 B_0 
Stack 10
G_5 D_0 J_0 D_5 F_5 
