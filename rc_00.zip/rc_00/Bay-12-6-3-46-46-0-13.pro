Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_6 B_4 B_1 C_9 
Stack 2
B_12 A_1 B_14 C_2 
Stack 3
A_4 B_11 A_7 A_13 
Stack 4
B_6 B_9 C_8 A_10 
Stack 5
B_0 A_0 C_7 A_2 
Stack 6
B_3 A_12 A_14 B_15 
Stack 7
C_1 A_9 C_11 C_4 
Stack 8
A_5 B_8 A_3 C_5 
Stack 9
A_11 C_12 A_8 B_5 
Stack 10
B_10 B_7 C_13 C_3 
Stack 11
C_10 B_13 C_6 
Stack 12
C_0 B_2 C_14 
