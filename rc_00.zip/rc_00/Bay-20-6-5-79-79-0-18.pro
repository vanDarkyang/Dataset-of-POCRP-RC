Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_9 E_4 C_2 E_13 
Stack 2
D_5 D_15 E_12 A_12 
Stack 3
C_9 B_2 B_15 E_7 
Stack 4
A_0 A_1 C_6 C_5 
Stack 5
C_14 E_8 A_5 B_11 
Stack 6
A_6 D_11 A_9 E_5 
Stack 7
E_10 D_1 D_3 E_11 
Stack 8
C_12 A_11 B_14 B_0 
Stack 9
C_11 C_13 C_1 C_15 
Stack 10
B_1 A_8 C_8 E_1 
Stack 11
A_4 C_10 B_8 A_2 
Stack 12
A_7 B_5 E_9 E_3 
Stack 13
C_0 D_4 A_13 B_3 
Stack 14
C_16 B_13 A_10 A_3 
Stack 15
D_10 B_7 E_2 D_2 
Stack 16
D_12 D_14 E_0 E_14 
Stack 17
D_0 A_14 C_3 C_7 
Stack 18
D_6 B_10 C_4 B_9 
Stack 19
B_6 E_6 D_13 D_7 
Stack 20
B_12 D_8 B_4 
