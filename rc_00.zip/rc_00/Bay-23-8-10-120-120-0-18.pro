Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_8 H_5 I_2 F_11 J_4 D_2 
Stack 2
B_8 G_2 A_1 D_8 C_0 B_7 
Stack 3
E_11 D_7 A_6 C_9 E_10 D_6 
Stack 4
G_5 I_8 C_3 E_12 H_2 B_4 
Stack 5
C_5 A_0 F_7 G_4 H_0 G_6 
Stack 6
D_0 A_3 C_4 E_9 J_5 
Stack 7
B_0 A_7 E_8 G_9 H_6 
Stack 8
C_8 H_8 C_1 D_11 B_2 
Stack 9
G_12 I_10 B_5 G_0 A_4 
Stack 10
F_1 F_9 E_13 B_10 D_3 
Stack 11
I_1 E_1 G_1 H_10 F_12 
Stack 12
F_2 H_4 J_2 D_9 A_8 
Stack 13
E_2 F_13 I_5 B_6 B_9 
Stack 14
C_11 F_6 J_8 H_11 J_1 
Stack 15
H_7 A_9 F_8 A_5 F_3 
Stack 16
G_3 E_5 F_10 J_3 E_7 
Stack 17
C_10 I_3 D_4 B_1 D_10 
Stack 18
F_4 I_9 J_7 C_2 I_6 
Stack 19
I_0 A_2 I_4 H_9 F_5 
Stack 20
J_6 H_3 G_10 C_7 E_0 
Stack 21
D_1 D_12 B_3 D_5 G_11 
Stack 22
E_3 C_6 F_0 J_0 E_6 
Stack 23
G_7 J_9 E_4 I_7 H_1 
