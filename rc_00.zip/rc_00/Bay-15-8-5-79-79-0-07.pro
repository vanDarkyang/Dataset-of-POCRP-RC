Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_5 D_11 D_8 B_5 D_14 A_0 
Stack 2
A_8 D_0 D_2 E_10 E_0 E_13 
Stack 3
A_12 C_16 A_3 A_13 E_6 C_6 
Stack 4
E_8 D_7 A_11 A_1 E_11 A_6 
Stack 5
B_13 B_2 D_5 C_1 E_9 
Stack 6
B_7 C_13 D_10 E_5 B_1 
Stack 7
D_1 C_7 E_12 D_13 D_9 
Stack 8
D_12 B_8 C_2 A_10 A_4 
Stack 9
B_3 D_3 C_14 D_6 A_14 
Stack 10
B_6 B_9 A_7 A_2 C_0 
Stack 11
C_15 B_11 D_15 C_9 E_7 
Stack 12
B_10 E_14 B_12 C_8 E_4 
Stack 13
C_12 B_4 B_14 B_15 A_9 
Stack 14
E_1 E_3 C_10 C_3 E_2 
Stack 15
B_0 C_4 C_11 C_5 D_4 
