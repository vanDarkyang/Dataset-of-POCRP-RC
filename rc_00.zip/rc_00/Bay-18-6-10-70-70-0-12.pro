Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_5 D_7 B_2 H_2 
Stack 2
D_3 D_1 C_2 G_6 
Stack 3
F_6 D_0 F_3 B_3 
Stack 4
B_1 A_2 J_3 H_0 
Stack 5
B_5 I_3 E_0 C_0 
Stack 6
G_0 E_2 I_1 C_3 
Stack 7
C_6 G_5 I_5 F_0 
Stack 8
D_4 G_7 J_0 F_2 
Stack 9
A_3 E_1 H_3 I_2 
Stack 10
E_7 D_5 I_4 C_4 
Stack 11
J_2 J_4 B_4 C_5 
Stack 12
G_4 E_6 C_1 J_1 
Stack 13
F_7 B_0 D_6 E_4 
Stack 14
E_8 A_4 G_1 E_3 
Stack 15
F_4 H_6 H_4 A_1 
Stack 16
E_5 H_1 G_3 F_1 
Stack 17
F_5 F_8 A_0 
Stack 18
D_2 G_2 I_0 
