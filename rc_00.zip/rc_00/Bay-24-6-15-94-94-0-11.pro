Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
K_0 G_5 A_0 M_1 
Stack 2
I_3 D_4 F_4 K_4 
Stack 3
C_0 N_0 F_3 H_5 
Stack 4
K_1 L_2 H_1 K_6 
Stack 5
D_5 G_3 M_2 E_3 
Stack 6
H_4 J_1 E_5 I_7 
Stack 7
C_4 J_6 H_3 K_2 
Stack 8
N_3 F_5 G_1 C_2 
Stack 9
K_5 G_6 I_4 H_0 
Stack 10
E_0 L_1 M_3 L_5 
Stack 11
B_2 E_2 I_8 H_2 
Stack 12
F_6 L_4 M_4 A_2 
Stack 13
G_7 J_4 O_0 F_7 
Stack 14
H_6 J_5 H_7 G_2 
Stack 15
D_1 E_6 L_3 I_6 
Stack 16
E_4 C_1 A_1 F_0 
Stack 17
H_9 J_0 D_0 L_0 
Stack 18
F_2 K_3 N_2 C_3 
Stack 19
D_2 G_0 O_2 E_1 
Stack 20
N_1 I_2 H_8 I_5 
Stack 21
J_7 O_1 G_4 I_1 
Stack 22
G_8 B_0 M_0 J_3 
Stack 23
F_1 I_0 B_1 
Stack 24
D_3 B_3 J_2 
