Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 F_5 B_5 E_8 
Stack 2
B_2 E_5 F_0 I_5 
Stack 3
C_4 J_3 D_6 A_3 
Stack 4
C_6 A_0 C_2 F_2 
Stack 5
J_2 F_6 G_1 C_5 
Stack 6
H_5 F_8 F_4 H_4 
Stack 7
B_3 I_0 I_1 B_4 
Stack 8
E_1 B_0 H_6 G_0 
Stack 9
C_1 H_3 E_0 D_1 
Stack 10
E_6 H_1 E_7 D_3 
Stack 11
D_2 G_6 C_0 J_0 
Stack 12
F_1 G_2 G_5 E_2 
Stack 13
D_5 A_4 A_2 J_1 
Stack 14
G_3 E_4 C_3 G_4 
Stack 15
G_7 I_4 F_7 D_4 
Stack 16
D_0 D_7 H_0 E_3 
Stack 17
J_4 I_3 H_2 
Stack 18
I_2 F_3 B_1 
