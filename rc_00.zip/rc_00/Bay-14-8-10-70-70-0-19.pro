Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_2 D_4 J_1 H_4 A_2 
Stack 2
E_6 D_3 I_4 H_2 C_6 
Stack 3
H_0 G_4 F_8 B_4 B_0 
Stack 4
H_1 H_6 G_2 A_0 F_0 
Stack 5
E_2 G_6 F_4 G_5 C_1 
Stack 6
B_1 J_4 C_5 B_3 E_8 
Stack 7
I_5 C_2 I_2 D_2 C_0 
Stack 8
E_0 F_6 I_1 E_4 E_5 
Stack 9
J_2 G_3 B_2 J_0 D_5 
Stack 10
D_1 D_6 A_3 G_1 E_3 
Stack 11
B_5 G_0 A_1 H_3 E_1 
Stack 12
H_5 F_3 F_7 F_5 J_3 
Stack 13
G_7 C_3 A_4 D_0 C_4 
Stack 14
F_1 D_7 I_0 I_3 E_7 
