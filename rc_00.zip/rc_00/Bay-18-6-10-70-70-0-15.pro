Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 B_1 F_3 C_3 
Stack 2
D_2 D_5 J_0 B_5 
Stack 3
A_4 J_1 C_5 A_3 
Stack 4
E_7 I_1 D_0 I_0 
Stack 5
E_6 F_5 I_4 E_3 
Stack 6
I_2 G_3 D_6 E_1 
Stack 7
G_0 G_5 A_1 E_8 
Stack 8
B_2 E_2 H_5 J_2 
Stack 9
D_3 G_1 F_1 E_4 
Stack 10
J_3 F_0 C_1 E_0 
Stack 11
G_2 B_4 G_7 J_4 
Stack 12
H_1 A_2 C_6 E_5 
Stack 13
H_6 C_4 G_4 G_6 
Stack 14
F_2 H_0 A_0 F_8 
Stack 15
D_1 H_2 D_7 I_3 
Stack 16
D_4 B_0 I_5 H_4 
Stack 17
F_4 F_6 C_0 
Stack 18
B_3 F_7 H_3 
