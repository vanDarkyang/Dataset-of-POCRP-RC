Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_1 H_0 B_5 F_0 D_3 H_3 
Stack 2
K_4 N_3 I_8 J_5 O_4 K_1 
Stack 3
J_6 G_5 N_4 L_2 H_9 G_9 
Stack 4
I_10 F_7 C_5 N_5 A_0 F_2 
Stack 5
G_1 B_0 N_1 D_4 L_7 
Stack 6
A_2 H_5 D_1 B_3 F_8 
Stack 7
D_6 G_3 K_8 J_3 K_6 
Stack 8
E_0 M_3 I_2 H_7 G_0 
Stack 9
H_11 H_8 F_5 F_3 I_6 
Stack 10
O_3 G_4 F_9 D_0 N_0 
Stack 11
K_0 M_5 I_4 G_6 F_6 
Stack 12
I_3 E_1 H_2 J_7 O_2 
Stack 13
L_5 D_2 H_1 J_4 M_6 
Stack 14
B_4 M_0 L_3 L_1 J_2 
Stack 15
C_4 E_7 H_4 M_2 G_8 
Stack 16
E_6 J_8 K_2 I_9 G_2 
Stack 17
J_1 F_1 M_4 A_3 E_4 
Stack 18
H_10 I_7 N_2 A_4 I_5 
Stack 19
K_3 E_5 M_1 K_7 C_3 
Stack 20
C_0 J_0 D_5 L_0 G_10 
Stack 21
D_7 H_6 G_7 C_2 I_1 
Stack 22
C_6 L_4 B_2 E_3 I_0 
Stack 23
O_0 L_6 J_9 K_5 B_1 
Stack 24
O_1 E_2 E_8 A_1 F_4 
