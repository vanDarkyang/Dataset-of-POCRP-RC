Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_13 B_14 A_10 D_5 
Stack 2
A_14 C_2 B_0 A_9 
Stack 3
D_14 A_8 B_3 B_7 
Stack 4
C_14 B_2 B_8 D_8 
Stack 5
D_6 D_0 B_12 C_8 
Stack 6
C_9 D_10 C_12 C_13 
Stack 7
D_1 D_9 A_0 C_3 
Stack 8
E_1 B_10 A_6 D_11 
Stack 9
D_2 C_4 E_7 A_3 
Stack 10
B_15 E_11 E_6 D_15 
Stack 11
C_15 B_11 B_13 C_6 
Stack 12
B_4 D_4 C_5 A_1 
Stack 13
D_3 A_13 E_5 E_14 
Stack 14
A_7 D_7 B_1 A_4 
Stack 15
D_12 E_3 C_0 E_8 
Stack 16
E_13 E_10 B_9 C_10 
Stack 17
E_12 A_5 E_2 C_16 
Stack 18
A_12 C_7 B_5 B_6 
Stack 19
A_11 C_11 E_0 E_9 
Stack 20
E_4 A_2 C_1 
