Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_4 D_7 B_0 D_5 
Stack 2
C_7 A_0 E_7 E_5 
Stack 3
C_8 A_5 B_7 D_4 
Stack 4
D_3 C_5 E_1 B_9 
Stack 5
A_2 A_1 D_10 E_3 
Stack 6
A_8 D_8 C_10 C_11 
Stack 7
D_2 E_6 B_6 A_6 
Stack 8
C_6 D_1 A_3 E_9 
Stack 9
B_4 A_9 C_1 A_7 
Stack 10
C_0 B_1 C_4 B_10 
Stack 11
A_4 C_2 B_5 D_6 
Stack 12
B_2 C_3 E_2 D_0 
Stack 13
B_3 E_0 C_9 
Stack 14
E_8 B_8 D_9 
