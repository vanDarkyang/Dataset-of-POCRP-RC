Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_1 I_2 D_4 C_1 
Stack 2
H_2 J_4 G_3 E_4 
Stack 3
D_3 F_0 G_5 I_0 
Stack 4
B_0 B_1 G_7 H_5 
Stack 5
G_0 J_0 I_1 C_4 
Stack 6
F_2 G_6 B_3 F_6 
Stack 7
C_3 D_5 E_3 F_1 
Stack 8
C_5 E_6 D_2 F_7 
Stack 9
I_3 J_2 H_3 A_2 
Stack 10
A_3 D_6 A_1 H_0 
Stack 11
E_8 C_2 F_3 F_8 
Stack 12
C_6 D_7 G_4 A_0 
Stack 13
I_4 F_4 E_5 E_7 
Stack 14
B_4 A_4 B_2 H_1 
Stack 15
H_4 F_5 I_5 H_6 
Stack 16
G_1 E_0 G_2 B_5 
Stack 17
E_2 E_1 J_3 
Stack 18
D_0 D_1 C_0 
