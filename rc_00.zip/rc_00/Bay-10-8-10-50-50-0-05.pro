Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_6 J_0 D_4 F_0 A_1 
Stack 2
D_3 F_1 C_1 I_3 I_2 
Stack 3
E_6 G_5 G_2 H_0 D_5 
Stack 4
J_2 D_2 I_0 J_1 I_1 
Stack 5
G_4 H_4 E_1 H_1 G_0 
Stack 6
C_2 G_3 E_3 F_5 F_4 
Stack 7
E_4 F_3 F_2 E_0 H_2 
Stack 8
D_1 B_3 C_0 B_2 D_0 
Stack 9
H_3 E_2 A_0 A_2 G_1 
Stack 10
C_4 E_5 C_3 B_1 B_0 
