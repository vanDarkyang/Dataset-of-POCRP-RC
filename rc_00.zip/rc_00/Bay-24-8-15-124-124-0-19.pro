Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
M_3 F_8 E_5 C_0 A_0 G_7 
Stack 2
K_2 F_2 O_0 E_4 E_8 H_0 
Stack 3
D_2 E_0 G_5 E_7 C_6 I_2 
Stack 4
L_0 J_3 A_4 H_2 M_0 F_4 
Stack 5
I_6 G_3 J_0 N_0 K_4 
Stack 6
C_5 G_9 I_3 D_7 D_0 
Stack 7
H_6 K_6 M_4 I_10 L_1 
Stack 8
L_4 H_11 M_6 F_9 I_0 
Stack 9
G_8 H_10 J_7 F_7 J_4 
Stack 10
C_2 M_5 L_3 L_6 H_3 
Stack 11
H_9 J_8 H_5 O_4 E_3 
Stack 12
K_7 F_5 O_1 L_2 G_10 
Stack 13
H_4 B_5 A_1 J_6 B_2 
Stack 14
I_8 H_7 H_1 I_9 N_2 
Stack 15
D_3 K_0 D_4 J_1 F_1 
Stack 16
I_7 H_8 B_4 M_1 E_1 
Stack 17
B_1 C_3 K_5 K_3 L_5 
Stack 18
N_5 G_6 I_1 K_1 M_2 
Stack 19
G_4 D_6 G_2 F_3 C_1 
Stack 20
D_5 N_4 I_4 F_0 C_4 
Stack 21
J_5 N_3 J_9 G_1 J_2 
Stack 22
G_0 E_2 N_1 B_0 A_2 
Stack 23
L_7 B_3 I_5 K_8 E_6 
Stack 24
F_6 O_3 A_3 D_1 O_2 
