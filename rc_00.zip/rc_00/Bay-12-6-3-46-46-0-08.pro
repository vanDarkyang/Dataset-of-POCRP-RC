Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_7 B_5 A_8 B_13 
Stack 2
B_2 B_7 B_9 B_12 
Stack 3
C_3 B_3 C_9 A_1 
Stack 4
A_10 B_1 A_9 C_0 
Stack 5
C_5 B_0 C_10 C_7 
Stack 6
C_13 C_8 C_4 C_11 
Stack 7
B_11 A_12 B_4 C_12 
Stack 8
A_2 B_6 A_5 A_14 
Stack 9
B_15 B_8 C_14 B_10 
Stack 10
A_11 A_3 C_6 C_1 
Stack 11
C_2 A_4 B_14 
Stack 12
A_13 A_0 A_6 
