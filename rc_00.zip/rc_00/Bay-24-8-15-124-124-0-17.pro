Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_2 L_3 J_9 J_3 O_0 J_5 
Stack 2
K_8 G_3 G_0 I_10 G_10 D_6 
Stack 3
F_6 C_5 M_0 E_6 F_4 C_2 
Stack 4
J_7 I_8 E_8 K_0 M_4 H_0 
Stack 5
N_2 G_8 L_0 L_6 B_1 
Stack 6
H_1 G_6 L_2 J_1 E_5 
Stack 7
I_1 H_4 E_4 J_8 J_2 
Stack 8
B_2 H_7 J_6 L_1 M_2 
Stack 9
B_0 F_8 M_1 F_3 M_6 
Stack 10
B_5 M_5 E_1 M_3 H_8 
Stack 11
F_5 K_2 I_5 F_1 G_4 
Stack 12
H_6 D_4 I_4 D_5 B_3 
Stack 13
F_2 O_3 I_9 H_11 I_2 
Stack 14
E_3 D_2 C_6 K_4 A_3 
Stack 15
C_4 N_4 N_1 G_5 I_0 
Stack 16
K_1 L_5 N_3 L_7 A_1 
Stack 17
G_9 C_3 N_0 D_7 K_6 
Stack 18
I_7 F_0 K_5 J_4 O_4 
Stack 19
H_9 H_5 I_3 L_4 H_2 
Stack 20
E_0 K_3 G_7 F_9 B_4 
Stack 21
G_1 A_4 H_3 C_0 A_0 
Stack 22
H_10 D_0 F_7 J_0 O_2 
Stack 23
E_2 I_6 C_1 O_1 D_3 
Stack 24
K_7 E_7 G_2 D_1 N_5 
