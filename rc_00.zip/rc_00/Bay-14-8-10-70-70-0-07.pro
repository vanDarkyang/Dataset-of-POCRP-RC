Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 E_5 F_4 D_0 J_2 
Stack 2
B_0 B_3 E_7 F_5 I_5 
Stack 3
D_6 C_3 A_0 G_7 C_4 
Stack 4
D_5 F_2 J_0 I_3 A_2 
Stack 5
E_0 A_3 E_4 A_4 C_2 
Stack 6
F_3 D_4 F_6 J_1 I_4 
Stack 7
G_0 H_2 E_6 G_1 G_4 
Stack 8
H_6 I_1 C_6 B_2 D_3 
Stack 9
I_0 J_4 H_0 H_3 J_3 
Stack 10
E_1 B_1 F_7 F_0 G_3 
Stack 11
E_3 C_1 C_0 F_1 D_7 
Stack 12
D_1 G_2 G_5 E_8 B_4 
Stack 13
H_4 I_2 B_5 G_6 H_5 
Stack 14
E_2 C_5 D_2 H_1 F_8 
