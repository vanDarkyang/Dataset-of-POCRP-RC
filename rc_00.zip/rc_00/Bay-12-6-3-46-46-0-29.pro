Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_9 C_5 A_11 A_8 
Stack 2
B_5 B_6 C_10 C_6 
Stack 3
A_6 C_11 A_5 C_12 
Stack 4
C_2 C_13 C_14 B_0 
Stack 5
B_11 A_1 B_4 B_1 
Stack 6
C_1 B_15 A_13 B_10 
Stack 7
C_7 C_4 C_8 B_13 
Stack 8
A_9 B_12 B_3 A_3 
Stack 9
B_2 A_4 A_7 A_0 
Stack 10
B_14 A_2 A_14 A_10 
Stack 11
B_9 A_12 C_0 
Stack 12
C_3 B_7 B_8 
