Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_2 G_6 B_2 D_0 
Stack 2
E_6 J_4 A_3 I_3 
Stack 3
H_0 C_2 A_1 A_2 
Stack 4
H_1 F_6 F_7 C_6 
Stack 5
E_2 G_3 A_4 B_0 
Stack 6
B_1 D_6 I_0 F_0 
Stack 7
I_5 G_0 H_4 C_1 
Stack 8
E_0 F_3 H_2 E_8 
Stack 9
J_2 C_3 B_4 C_0 
Stack 10
D_1 D_7 A_0 E_5 
Stack 11
B_5 J_1 G_5 D_5 
Stack 12
H_5 I_4 B_3 E_3 
Stack 13
G_7 F_8 D_2 E_1 
Stack 14
F_1 G_2 E_4 J_3 
Stack 15
D_4 F_4 J_0 C_4 
Stack 16
D_3 C_5 G_1 E_7 
Stack 17
G_4 I_2 H_3 
Stack 18
H_6 I_1 F_5 
