Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_1 C_11 D_8 D_3 
Stack 2
A_2 B_2 D_4 E_3 
Stack 3
A_7 B_4 A_3 B_6 
Stack 4
A_6 D_5 D_6 C_0 
Stack 5
A_0 D_9 C_4 D_2 
Stack 6
C_1 B_0 E_6 B_9 
Stack 7
E_8 C_9 E_0 E_5 
Stack 8
A_4 B_10 C_6 E_7 
Stack 9
B_3 A_9 D_0 C_3 
Stack 10
A_5 A_8 B_1 E_4 
Stack 11
C_10 B_5 C_7 C_8 
Stack 12
B_7 B_8 D_7 D_10 
Stack 13
C_2 C_5 E_9 
Stack 14
D_1 E_2 A_1 
