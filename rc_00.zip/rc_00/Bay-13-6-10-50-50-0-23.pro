Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_4 F_1 J_1 F_5 
Stack 2
H_1 J_0 C_1 E_1 
Stack 3
F_6 G_0 G_5 F_3 
Stack 4
E_0 F_0 E_2 J_2 
Stack 5
B_3 I_0 G_4 E_5 
Stack 6
G_1 B_1 D_2 D_3 
Stack 7
D_1 B_0 G_2 I_1 
Stack 8
A_0 C_0 I_2 F_4 
Stack 9
C_4 D_0 H_4 H_0 
Stack 10
D_5 E_4 I_3 G_3 
Stack 11
F_2 B_2 E_6 C_3 
Stack 12
A_1 A_2 H_3 
Stack 13
E_3 H_2 C_2 
