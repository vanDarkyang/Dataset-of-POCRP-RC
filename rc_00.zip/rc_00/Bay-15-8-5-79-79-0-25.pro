Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_8 D_8 B_7 C_13 D_5 C_15 
Stack 2
E_9 A_6 D_9 B_4 B_13 C_9 
Stack 3
B_0 D_6 B_5 A_0 E_12 D_13 
Stack 4
E_3 C_11 A_1 D_12 A_9 B_8 
Stack 5
C_3 B_6 A_14 B_3 E_14 
Stack 6
A_3 A_10 E_0 D_0 B_2 
Stack 7
B_15 E_8 C_14 C_16 C_7 
Stack 8
A_4 E_11 E_4 D_2 B_10 
Stack 9
C_0 D_3 C_1 E_7 E_5 
Stack 10
C_5 D_11 A_5 D_14 C_6 
Stack 11
A_12 C_12 D_7 B_11 E_13 
Stack 12
E_6 B_12 D_15 B_1 E_1 
Stack 13
D_4 A_11 B_14 A_13 C_8 
Stack 14
C_10 A_2 A_7 C_2 E_2 
Stack 15
D_1 C_4 D_10 E_10 B_9 
