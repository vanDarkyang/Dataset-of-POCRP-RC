Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 D_5 N_0 M_1 
Stack 2
L_4 B_2 N_3 H_4 
Stack 3
H_3 G_7 O_1 L_0 
Stack 4
G_6 D_2 K_0 H_0 
Stack 5
B_3 G_1 I_5 E_4 
Stack 6
G_2 G_0 K_6 I_2 
Stack 7
M_0 H_7 F_7 E_2 
Stack 8
D_3 B_1 E_1 H_8 
Stack 9
I_0 I_8 C_4 E_3 
Stack 10
D_0 J_0 L_1 J_1 
Stack 11
J_5 M_2 F_5 I_7 
Stack 12
C_0 N_2 E_5 I_4 
Stack 13
J_6 C_1 J_4 J_7 
Stack 14
L_5 I_1 F_0 N_1 
Stack 15
O_2 H_2 M_3 G_4 
Stack 16
H_9 C_2 H_6 I_6 
Stack 17
I_3 K_1 F_6 E_0 
Stack 18
F_4 B_0 K_5 C_3 
Stack 19
J_3 D_1 L_2 G_3 
Stack 20
G_8 M_4 J_2 H_5 
Stack 21
A_0 F_2 K_4 A_2 
Stack 22
F_1 F_3 O_0 L_3 
Stack 23
G_5 K_2 H_1 
Stack 24
E_6 D_4 K_3 
