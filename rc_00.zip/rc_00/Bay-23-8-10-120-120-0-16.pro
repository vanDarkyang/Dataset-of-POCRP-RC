Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_0 E_5 B_0 A_4 G_6 B_3 
Stack 2
H_10 F_4 A_5 G_9 J_6 I_8 
Stack 3
J_3 I_1 I_7 J_5 B_7 C_2 
Stack 4
J_4 E_12 B_6 B_8 G_12 F_7 
Stack 5
C_0 F_9 F_11 I_0 C_4 H_9 
Stack 6
E_9 H_0 G_8 H_5 C_11 
Stack 7
C_7 F_3 D_12 E_10 D_2 
Stack 8
H_4 B_10 D_7 J_2 C_3 
Stack 9
E_4 A_0 I_10 F_6 E_7 
Stack 10
G_3 C_9 A_6 I_3 G_4 
Stack 11
J_9 B_9 B_2 D_9 E_1 
Stack 12
A_1 H_8 D_10 J_8 I_4 
Stack 13
H_1 E_8 H_2 I_2 G_2 
Stack 14
A_2 C_5 H_11 D_11 D_0 
Stack 15
D_8 D_5 A_7 E_3 H_7 
Stack 16
C_8 E_2 D_6 F_5 J_0 
Stack 17
C_1 E_0 F_12 I_6 F_2 
Stack 18
F_1 I_5 G_5 G_10 A_9 
Stack 19
F_8 G_1 B_5 D_1 F_13 
Stack 20
E_11 E_6 G_7 J_1 H_6 
Stack 21
G_11 A_8 F_10 F_0 D_4 
Stack 22
I_9 B_4 B_1 J_7 D_3 
Stack 23
A_3 H_3 C_6 C_10 E_13 
