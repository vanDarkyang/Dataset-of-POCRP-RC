Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 E_13 E_12 A_0 E_9 A_13 
Stack 2
B_6 A_10 D_5 B_7 C_2 E_10 
Stack 3
A_4 C_1 C_7 D_11 C_8 A_11 
Stack 4
C_9 C_15 D_7 A_6 B_0 D_8 
Stack 5
B_2 B_4 A_5 A_7 C_11 
Stack 6
A_9 E_2 C_12 D_12 E_14 
Stack 7
D_14 E_4 C_14 D_6 A_12 
Stack 8
E_6 B_11 D_4 D_13 B_10 
Stack 9
B_3 C_0 B_9 E_0 B_8 
Stack 10
D_9 A_14 D_15 E_1 C_6 
Stack 11
A_3 D_10 C_16 A_8 E_7 
Stack 12
E_8 C_10 A_1 D_1 C_13 
Stack 13
D_2 D_3 A_2 E_3 B_1 
Stack 14
E_5 B_12 C_4 B_13 D_0 
Stack 15
B_14 C_5 B_15 E_11 B_5 
