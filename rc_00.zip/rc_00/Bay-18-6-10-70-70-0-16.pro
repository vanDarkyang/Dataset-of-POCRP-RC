Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_3 D_1 A_0 J_4 
Stack 2
J_2 F_7 I_4 E_1 
Stack 3
B_2 E_8 G_5 A_1 
Stack 4
E_3 I_2 J_3 H_2 
Stack 5
G_4 D_7 E_5 C_4 
Stack 6
J_1 F_2 F_6 D_5 
Stack 7
F_3 H_6 H_0 D_6 
Stack 8
E_7 B_0 B_4 E_4 
Stack 9
C_5 B_1 C_3 I_3 
Stack 10
H_5 G_0 F_1 E_0 
Stack 11
C_2 H_4 E_6 F_4 
Stack 12
C_6 E_2 H_1 B_5 
Stack 13
C_0 D_0 G_6 J_0 
Stack 14
I_0 G_7 A_2 D_4 
Stack 15
A_4 I_1 D_3 F_0 
Stack 16
B_3 G_3 A_3 F_8 
Stack 17
C_1 G_1 D_2 
Stack 18
G_2 I_5 F_5 
