Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 B_0 B_8 C_7 
Stack 2
B_9 C_4 B_12 C_13 
Stack 3
C_14 A_5 A_11 B_7 
Stack 4
A_0 C_12 B_15 C_5 
Stack 5
A_8 C_8 C_1 A_6 
Stack 6
C_3 A_1 C_9 A_4 
Stack 7
B_4 B_14 B_13 C_6 
Stack 8
C_11 B_6 C_0 B_10 
Stack 9
B_2 A_2 A_13 A_12 
Stack 10
B_5 A_3 B_3 B_11 
Stack 11
A_7 A_9 C_10 
Stack 12
C_2 A_14 A_10 
