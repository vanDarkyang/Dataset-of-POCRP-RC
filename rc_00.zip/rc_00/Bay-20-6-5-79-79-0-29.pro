Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_2 A_2 C_16 D_9 
Stack 2
E_11 A_7 D_7 A_10 
Stack 3
B_11 C_5 E_2 A_1 
Stack 4
B_5 E_6 B_14 B_0 
Stack 5
A_14 D_13 E_0 D_3 
Stack 6
B_13 C_9 C_0 B_4 
Stack 7
A_9 D_1 E_7 E_5 
Stack 8
D_8 B_15 C_10 D_15 
Stack 9
A_3 B_8 D_12 C_6 
Stack 10
A_11 A_5 C_15 B_2 
Stack 11
C_4 A_8 C_14 E_13 
Stack 12
B_3 D_4 E_3 A_0 
Stack 13
B_6 C_11 D_11 A_12 
Stack 14
D_14 E_9 E_14 C_3 
Stack 15
C_8 A_4 D_0 C_2 
Stack 16
E_1 B_10 B_12 A_6 
Stack 17
A_13 D_6 E_10 C_12 
Stack 18
B_1 E_8 E_4 C_1 
Stack 19
B_9 C_7 D_10 C_13 
Stack 20
B_7 E_12 D_5 
