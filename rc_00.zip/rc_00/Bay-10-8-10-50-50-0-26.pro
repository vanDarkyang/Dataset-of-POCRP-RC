Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_3 D_4 I_2 H_2 J_1 
Stack 2
F_1 H_3 F_2 D_0 B_2 
Stack 3
E_6 D_2 J_2 E_1 G_4 
Stack 4
E_3 F_0 E_5 D_5 G_3 
Stack 5
F_5 I_0 H_4 C_2 C_1 
Stack 6
G_0 D_3 F_3 E_4 C_0 
Stack 7
F_6 D_1 A_2 H_0 B_0 
Stack 8
G_1 J_0 I_3 A_0 C_3 
Stack 9
G_5 A_1 F_4 G_2 E_2 
Stack 10
E_0 H_1 B_1 I_1 C_4 
