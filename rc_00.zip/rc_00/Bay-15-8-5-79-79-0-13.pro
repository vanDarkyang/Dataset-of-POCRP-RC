Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_11 A_12 A_10 C_2 C_15 B_13 
Stack 2
C_5 E_5 A_6 D_15 D_9 E_8 
Stack 3
E_10 A_5 E_13 D_3 A_2 A_8 
Stack 4
D_2 B_12 C_6 E_11 E_12 D_5 
Stack 5
B_3 C_12 E_2 B_9 C_4 
Stack 6
A_4 B_11 B_1 A_7 A_14 
Stack 7
D_12 E_7 A_1 C_8 D_1 
Stack 8
B_6 E_0 D_7 B_7 E_9 
Stack 9
D_11 A_9 A_3 B_0 C_3 
Stack 10
A_13 C_9 B_15 B_5 C_14 
Stack 11
D_10 D_8 C_16 C_7 B_4 
Stack 12
C_1 D_13 B_10 B_8 E_1 
Stack 13
A_11 D_14 C_13 C_0 E_6 
Stack 14
A_0 B_14 C_10 D_4 B_2 
Stack 15
D_6 E_14 E_3 E_4 D_0 
