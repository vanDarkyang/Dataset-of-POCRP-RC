Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_3 E_4 B_15 E_9 B_12 A_1 
Stack 2
D_15 A_10 C_11 C_14 B_13 D_6 
Stack 3
B_14 C_13 A_13 E_8 B_8 E_12 
Stack 4
C_3 E_2 A_9 C_5 D_11 E_10 
Stack 5
B_11 A_6 E_6 C_9 C_1 
Stack 6
A_3 D_12 E_1 D_8 A_5 
Stack 7
C_12 B_10 E_5 D_9 C_10 
Stack 8
E_13 D_4 C_0 D_0 D_2 
Stack 9
C_4 A_0 C_2 A_8 A_4 
Stack 10
B_9 A_14 D_14 B_3 B_4 
Stack 11
B_7 C_16 E_3 B_5 A_12 
Stack 12
D_1 B_2 C_15 C_7 A_2 
Stack 13
A_7 B_6 B_1 B_0 E_0 
Stack 14
C_6 A_11 D_7 E_7 D_13 
Stack 15
C_8 E_14 D_10 E_11 D_5 
