Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_11 A_7 B_6 A_2 
Stack 2
A_3 A_10 C_12 C_8 
Stack 3
C_6 C_5 A_9 B_4 
Stack 4
A_1 C_1 C_2 C_4 
Stack 5
B_14 C_3 B_12 A_12 
Stack 6
A_6 C_11 A_8 B_8 
Stack 7
B_1 A_14 B_13 C_0 
Stack 8
C_7 C_9 B_10 B_3 
Stack 9
A_13 A_4 B_11 B_9 
Stack 10
B_0 A_0 B_15 A_5 
Stack 11
C_13 B_2 B_7 
Stack 12
B_5 C_10 C_14 
