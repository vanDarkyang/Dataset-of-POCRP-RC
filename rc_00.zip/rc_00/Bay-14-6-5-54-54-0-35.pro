Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_4 B_2 B_4 E_8 
Stack 2
D_1 C_4 C_9 A_6 
Stack 3
D_7 C_11 C_7 E_9 
Stack 4
A_2 B_3 C_6 E_2 
Stack 5
B_0 A_5 D_5 C_10 
Stack 6
B_9 C_3 E_4 A_7 
Stack 7
C_2 B_5 B_8 C_0 
Stack 8
B_1 A_0 A_8 D_8 
Stack 9
E_5 C_5 A_9 E_7 
Stack 10
C_1 A_1 D_3 D_6 
Stack 11
E_3 D_10 E_1 E_6 
Stack 12
D_9 C_8 B_6 A_3 
Stack 13
B_10 D_4 B_7 
Stack 14
D_0 D_2 E_0 
