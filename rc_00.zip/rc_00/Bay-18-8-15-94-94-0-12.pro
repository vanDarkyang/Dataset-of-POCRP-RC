Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_5 J_3 G_2 G_8 D_5 M_0 
Stack 2
E_5 H_1 D_0 M_1 L_2 C_2 
Stack 3
K_3 F_2 J_2 K_5 H_6 L_1 
Stack 4
N_0 F_4 F_6 E_6 J_5 D_4 
Stack 5
A_1 E_1 I_5 K_6 L_4 
Stack 6
D_1 F_3 C_1 M_2 D_2 
Stack 7
F_1 F_0 I_6 K_4 G_4 
Stack 8
H_2 F_5 J_1 N_3 H_8 
Stack 9
C_4 H_0 B_0 H_5 C_0 
Stack 10
A_2 H_9 O_0 E_0 I_1 
Stack 11
O_2 G_6 K_0 J_6 J_7 
Stack 12
A_0 G_7 N_1 M_4 B_1 
Stack 13
E_4 L_5 L_3 G_1 I_8 
Stack 14
J_4 B_2 E_2 M_3 B_3 
Stack 15
I_0 F_7 I_7 D_3 H_3 
Stack 16
H_4 H_7 I_3 O_1 I_4 
Stack 17
K_2 N_2 I_2 L_0 E_3 
Stack 18
C_3 G_0 G_3 J_0 K_1 
