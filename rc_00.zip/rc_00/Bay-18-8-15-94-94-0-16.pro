Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
M_1 I_0 F_2 H_2 L_1 J_4 
Stack 2
D_3 F_4 C_4 K_2 F_5 H_6 
Stack 3
L_3 G_4 J_2 G_3 E_0 E_3 
Stack 4
L_4 E_2 C_2 B_2 O_1 O_2 
Stack 5
J_3 K_4 F_7 A_1 K_1 
Stack 6
F_6 H_9 K_6 E_5 F_0 
Stack 7
E_4 D_1 I_3 K_3 N_0 
Stack 8
C_3 G_1 G_5 B_3 G_7 
Stack 9
I_4 I_8 N_2 L_2 L_5 
Stack 10
B_0 E_6 G_6 N_1 N_3 
Stack 11
D_4 I_5 J_1 I_1 G_2 
Stack 12
M_4 B_1 O_0 I_2 E_1 
Stack 13
D_0 J_0 H_0 K_0 I_7 
Stack 14
M_3 G_0 L_0 A_2 H_1 
Stack 15
G_8 F_1 J_7 D_5 J_6 
Stack 16
M_0 H_5 M_2 F_3 K_5 
Stack 17
C_0 I_6 H_8 C_1 D_2 
Stack 18
H_4 H_3 J_5 H_7 A_0 
