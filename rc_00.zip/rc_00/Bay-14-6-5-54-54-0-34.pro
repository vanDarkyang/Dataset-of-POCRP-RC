Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 E_1 D_8 A_7 
Stack 2
C_6 D_0 E_2 B_8 
Stack 3
B_10 D_3 B_3 E_4 
Stack 4
D_10 B_1 B_9 C_9 
Stack 5
B_7 E_7 E_0 C_4 
Stack 6
A_8 C_11 C_10 A_2 
Stack 7
B_5 A_6 C_1 A_0 
Stack 8
A_5 A_9 A_4 B_0 
Stack 9
C_5 E_3 A_1 D_1 
Stack 10
E_9 B_4 E_6 C_8 
Stack 11
B_2 D_6 D_7 D_5 
Stack 12
B_6 C_7 E_5 A_3 
Stack 13
C_0 C_2 D_9 
Stack 14
D_2 D_4 E_8 
