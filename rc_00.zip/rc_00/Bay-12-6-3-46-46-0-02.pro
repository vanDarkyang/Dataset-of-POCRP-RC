Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_10 C_8 B_7 B_1 
Stack 2
C_11 C_2 A_12 C_6 
Stack 3
C_4 A_5 A_2 B_3 
Stack 4
A_11 B_10 A_7 A_14 
Stack 5
C_9 B_11 A_0 C_1 
Stack 6
C_0 A_10 A_8 C_14 
Stack 7
B_13 C_13 C_5 A_9 
Stack 8
B_2 C_3 B_12 C_12 
Stack 9
B_8 B_9 B_15 B_6 
Stack 10
B_5 A_6 B_14 C_7 
Stack 11
B_4 A_4 A_13 
Stack 12
B_0 A_1 A_3 
