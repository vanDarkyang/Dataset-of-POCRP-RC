Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_3 A_0 B_4 B_2 
Stack 2
A_4 C_0 C_1 I_1 
Stack 3
E_3 G_5 B_5 C_3 
Stack 4
B_3 G_4 D_1 I_5 
Stack 5
H_2 A_3 I_4 H_4 
Stack 6
F_1 J_1 B_1 J_3 
Stack 7
J_0 F_5 D_7 H_0 
Stack 8
E_6 F_8 C_6 E_2 
Stack 9
F_3 H_1 I_2 B_0 
Stack 10
C_5 G_3 D_2 E_5 
Stack 11
C_4 F_7 D_6 F_0 
Stack 12
F_6 E_7 A_2 E_4 
Stack 13
A_1 D_5 E_1 F_2 
Stack 14
I_0 J_2 J_4 G_7 
Stack 15
G_2 H_5 H_6 G_6 
Stack 16
D_0 E_0 F_4 G_0 
Stack 17
D_4 H_3 C_2 
Stack 18
G_1 I_3 E_8 
