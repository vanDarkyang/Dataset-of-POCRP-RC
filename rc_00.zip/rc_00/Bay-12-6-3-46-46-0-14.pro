Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_6 B_15 B_9 B_4 
Stack 2
A_7 A_1 B_8 C_14 
Stack 3
A_13 A_0 B_6 A_4 
Stack 4
A_10 B_1 C_6 B_0 
Stack 5
B_14 A_8 B_7 A_5 
Stack 6
C_8 C_4 A_11 A_3 
Stack 7
B_10 B_12 C_12 C_10 
Stack 8
A_12 A_9 C_2 A_14 
Stack 9
C_13 C_11 B_2 B_11 
Stack 10
B_13 A_2 C_9 C_0 
Stack 11
C_3 C_1 C_5 
Stack 12
B_3 C_7 B_5 
