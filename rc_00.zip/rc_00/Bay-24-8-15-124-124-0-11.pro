Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_8 E_3 H_7 C_0 N_5 L_1 
Stack 2
A_3 F_9 E_2 C_5 M_3 F_6 
Stack 3
G_10 E_4 I_9 F_2 M_4 M_6 
Stack 4
B_3 A_2 H_3 B_1 F_0 A_0 
Stack 5
G_6 G_2 F_1 I_1 O_2 
Stack 6
L_0 O_1 J_0 H_8 C_3 
Stack 7
G_4 D_5 K_8 D_6 E_6 
Stack 8
H_4 F_8 H_0 B_2 H_2 
Stack 9
B_5 L_6 L_7 J_6 J_7 
Stack 10
N_2 M_1 L_4 G_3 B_0 
Stack 11
I_4 C_1 G_9 K_3 J_2 
Stack 12
B_4 J_3 I_2 I_7 M_5 
Stack 13
F_4 K_2 N_1 H_1 D_7 
Stack 14
E_5 L_3 J_1 O_3 O_4 
Stack 15
M_2 G_5 K_1 D_3 F_7 
Stack 16
M_0 A_1 C_6 J_9 D_0 
Stack 17
I_8 H_11 J_8 F_5 G_7 
Stack 18
N_0 D_2 O_0 H_9 D_1 
Stack 19
A_4 I_6 C_2 E_7 I_0 
Stack 20
G_1 C_4 E_0 I_5 N_3 
Stack 21
N_4 H_5 K_5 G_0 K_4 
Stack 22
K_0 L_2 F_3 K_7 H_6 
Stack 23
I_3 J_4 J_5 E_1 L_5 
Stack 24
D_4 I_10 K_6 E_8 H_10 
