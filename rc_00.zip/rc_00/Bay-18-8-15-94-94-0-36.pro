Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_4 G_8 J_2 I_1 L_4 C_1 
Stack 2
G_6 L_3 F_6 J_0 H_2 E_4 
Stack 3
D_1 K_5 H_0 D_3 F_2 O_2 
Stack 4
G_7 G_0 F_3 K_6 O_0 L_0 
Stack 5
H_8 A_1 I_0 H_1 B_3 
Stack 6
H_4 F_7 J_7 I_4 H_5 
Stack 7
E_1 J_5 O_1 I_5 E_0 
Stack 8
K_2 E_2 L_5 K_4 N_2 
Stack 9
L_1 D_5 H_3 B_1 B_2 
Stack 10
I_6 I_2 N_0 F_4 E_3 
Stack 11
H_9 J_4 K_0 N_3 D_2 
Stack 12
G_2 D_4 C_0 A_0 J_6 
Stack 13
L_2 E_6 C_2 F_5 H_6 
Stack 14
G_5 K_1 C_3 A_2 M_2 
Stack 15
B_0 M_4 J_3 I_3 N_1 
Stack 16
F_1 G_3 D_0 F_0 E_5 
Stack 17
J_1 M_3 K_3 G_1 M_0 
Stack 18
I_7 I_8 H_7 C_4 M_1 
