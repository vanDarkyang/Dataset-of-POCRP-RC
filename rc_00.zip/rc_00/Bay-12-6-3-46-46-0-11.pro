Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_7 A_5 A_13 A_7 
Stack 2
B_0 B_11 C_2 C_4 
Stack 3
A_9 C_1 C_9 A_8 
Stack 4
C_0 A_11 A_14 C_11 
Stack 5
A_12 B_3 C_3 B_13 
Stack 6
A_0 C_6 A_3 A_10 
Stack 7
B_12 C_14 B_4 B_1 
Stack 8
B_5 C_7 B_9 A_2 
Stack 9
B_2 B_6 C_13 B_14 
Stack 10
B_8 C_5 C_12 A_4 
Stack 11
A_6 B_10 C_10 
Stack 12
A_1 C_8 B_15 
