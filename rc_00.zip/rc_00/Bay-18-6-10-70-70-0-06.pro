Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 B_0 D_5 A_2 
Stack 2
G_4 H_3 F_5 H_4 
Stack 3
E_6 F_1 I_5 H_2 
Stack 4
H_0 C_2 E_3 H_6 
Stack 5
E_0 J_3 I_4 B_4 
Stack 6
C_5 J_1 D_1 B_5 
Stack 7
C_0 G_1 D_3 J_2 
Stack 8
B_2 E_8 H_5 C_4 
Stack 9
H_1 D_2 G_2 G_0 
Stack 10
D_6 I_1 E_2 F_8 
Stack 11
E_5 A_3 I_3 E_4 
Stack 12
F_7 G_5 B_1 J_0 
Stack 13
C_1 C_6 I_2 G_3 
Stack 14
D_7 G_7 F_2 E_1 
Stack 15
F_4 E_7 G_6 A_4 
Stack 16
A_0 A_1 I_0 F_0 
Stack 17
J_4 D_4 F_6 
Stack 18
F_3 D_0 B_3 
