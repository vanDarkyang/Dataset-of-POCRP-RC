Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_3 I_0 B_4 H_1 
Stack 2
D_2 G_4 G_3 F_6 
Stack 3
E_1 E_0 F_2 J_1 
Stack 4
D_4 B_0 E_3 H_4 
Stack 5
B_2 B_1 A_2 I_4 
Stack 6
C_2 F_7 A_3 I_1 
Stack 7
D_7 I_2 C_6 H_2 
Stack 8
D_0 E_5 I_5 D_5 
Stack 9
H_3 H_0 E_7 D_3 
Stack 10
H_6 G_0 C_5 E_2 
Stack 11
G_5 D_1 E_8 B_5 
Stack 12
G_7 G_6 J_2 A_0 
Stack 13
G_1 D_6 J_3 C_0 
Stack 14
F_3 C_3 G_2 F_5 
Stack 15
C_4 F_8 E_6 F_4 
Stack 16
H_5 B_3 J_4 J_0 
Stack 17
A_4 A_1 F_0 
Stack 18
F_1 C_1 E_4 
