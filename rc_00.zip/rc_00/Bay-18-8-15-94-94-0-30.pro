Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 H_9 C_1 M_1 K_6 F_6 
Stack 2
M_2 L_4 K_2 E_1 C_0 B_3 
Stack 3
I_5 G_1 I_3 D_2 J_6 N_0 
Stack 4
A_2 H_0 H_3 K_4 H_8 O_1 
Stack 5
K_3 G_4 A_1 G_5 C_4 
Stack 6
B_1 L_2 G_7 C_3 F_1 
Stack 7
H_7 F_0 N_2 E_6 G_3 
Stack 8
G_8 E_4 H_4 E_3 J_2 
Stack 9
J_3 O_2 B_2 F_2 L_5 
Stack 10
F_3 O_0 H_2 H_5 G_2 
Stack 11
D_3 H_6 J_5 L_1 N_3 
Stack 12
I_0 G_0 J_0 D_0 N_1 
Stack 13
M_4 D_4 M_0 F_5 D_5 
Stack 14
J_4 E_5 G_6 K_0 I_8 
Stack 15
I_4 M_3 I_1 K_1 E_2 
Stack 16
F_4 F_7 I_2 L_3 J_7 
Stack 17
D_1 L_0 I_6 A_0 J_1 
Stack 18
I_7 E_0 B_0 H_1 K_5 
