Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_7 F_6 D_1 H_2 
Stack 2
E_5 C_5 E_3 D_5 
Stack 3
J_1 E_7 J_4 F_2 
Stack 4
J_0 B_5 D_2 J_3 
Stack 5
D_4 C_4 E_1 E_8 
Stack 6
E_6 H_6 H_0 I_4 
Stack 7
D_6 F_7 H_3 B_1 
Stack 8
I_3 J_2 B_2 G_5 
Stack 9
H_5 F_0 B_0 C_3 
Stack 10
G_7 A_3 C_1 A_0 
Stack 11
G_4 A_1 F_1 H_1 
Stack 12
H_4 A_2 G_2 B_3 
Stack 13
G_1 A_4 G_6 D_0 
Stack 14
I_5 F_4 I_2 D_3 
Stack 15
E_2 C_6 E_0 F_5 
Stack 16
F_3 B_4 E_4 I_1 
Stack 17
G_3 G_0 C_0 
Stack 18
C_2 F_8 I_0 
