Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
N_3 I_1 J_2 N_2 
Stack 2
K_3 J_6 E_4 E_5 
Stack 3
L_2 K_4 J_7 M_0 
Stack 4
J_4 M_4 H_8 I_8 
Stack 5
E_6 N_1 G_8 E_2 
Stack 6
G_2 G_7 I_6 M_1 
Stack 7
E_3 I_0 C_0 H_5 
Stack 8
O_0 D_0 M_2 N_0 
Stack 9
C_3 H_1 G_1 F_1 
Stack 10
C_4 I_2 H_0 O_1 
Stack 11
L_4 M_3 J_5 H_6 
Stack 12
G_4 F_4 L_1 H_4 
Stack 13
I_7 K_2 H_2 H_3 
Stack 14
G_3 I_5 K_1 G_5 
Stack 15
H_9 O_2 E_0 B_0 
Stack 16
B_3 D_4 J_0 D_3 
Stack 17
K_5 J_3 I_4 C_1 
Stack 18
D_1 F_7 I_3 K_6 
Stack 19
L_0 F_6 D_2 F_3 
Stack 20
H_7 F_5 G_0 A_2 
Stack 21
B_1 A_0 L_5 F_2 
Stack 22
J_1 A_1 C_2 L_3 
Stack 23
B_2 G_6 D_5 
Stack 24
E_1 F_0 K_0 
