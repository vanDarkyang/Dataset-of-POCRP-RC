Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_2 D_0 I_1 E_0 B_2 
Stack 2
E_4 F_3 F_2 D_3 F_6 
Stack 3
C_0 I_2 G_3 G_4 J_2 
Stack 4
B_0 E_3 B_3 A_1 E_1 
Stack 5
D_4 G_2 B_1 J_0 D_2 
Stack 6
F_5 I_0 G_0 G_1 E_6 
Stack 7
H_3 C_1 I_3 H_4 C_2 
Stack 8
H_0 C_3 D_1 E_2 C_4 
Stack 9
A_0 G_5 E_5 D_5 H_1 
Stack 10
F_4 F_0 A_2 J_1 F_1 
