Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_4 J_0 D_6 J_4 
Stack 2
H_1 I_4 I_0 I_3 
Stack 3
A_3 G_7 C_2 B_1 
Stack 4
C_6 J_3 G_5 C_3 
Stack 5
H_2 E_1 H_6 G_4 
Stack 6
E_8 F_7 C_0 I_2 
Stack 7
F_8 G_3 E_0 F_0 
Stack 8
J_2 D_2 E_6 A_1 
Stack 9
C_4 E_5 I_5 F_5 
Stack 10
H_4 E_4 E_3 C_5 
Stack 11
D_0 A_2 H_0 D_7 
Stack 12
F_6 E_7 F_4 G_0 
Stack 13
D_4 D_1 I_1 G_2 
Stack 14
J_1 B_2 D_5 C_1 
Stack 15
B_3 B_0 F_3 F_1 
Stack 16
B_4 A_0 G_6 B_5 
Stack 17
E_2 G_1 F_2 
Stack 18
D_3 H_5 H_3 
