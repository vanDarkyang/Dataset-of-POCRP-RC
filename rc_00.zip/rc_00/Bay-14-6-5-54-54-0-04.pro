Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_6 B_2 A_4 C_6 
Stack 2
E_9 C_11 C_9 E_0 
Stack 3
A_8 A_2 A_5 E_7 
Stack 4
E_8 C_7 B_4 C_1 
Stack 5
A_0 E_2 D_4 C_10 
Stack 6
A_9 C_2 B_9 E_4 
Stack 7
B_10 A_3 D_5 C_0 
Stack 8
D_8 D_0 E_5 E_1 
Stack 9
C_3 D_9 D_6 D_2 
Stack 10
B_5 E_3 C_5 C_8 
Stack 11
C_4 B_1 D_1 A_6 
Stack 12
D_7 A_1 B_8 B_0 
Stack 13
D_3 A_7 B_3 
Stack 14
B_7 B_6 D_10 
