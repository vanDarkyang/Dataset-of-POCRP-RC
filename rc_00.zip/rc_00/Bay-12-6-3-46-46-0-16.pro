Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_11 A_3 B_14 A_14 
Stack 2
C_11 C_7 C_1 C_14 
Stack 3
B_0 A_9 C_4 A_2 
Stack 4
A_4 C_12 C_13 A_10 
Stack 5
C_3 A_12 A_7 B_6 
Stack 6
A_11 B_5 A_5 C_5 
Stack 7
B_7 B_10 B_9 B_4 
Stack 8
A_0 C_2 B_1 B_15 
Stack 9
B_8 C_6 B_2 A_13 
Stack 10
B_12 A_1 C_0 B_3 
Stack 11
A_6 C_9 C_10 
Stack 12
A_8 B_13 C_8 
