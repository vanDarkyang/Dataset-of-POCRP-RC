Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_6 E_0 C_8 B_10 
Stack 2
C_1 D_3 C_11 A_0 
Stack 3
B_9 C_9 C_3 E_7 
Stack 4
D_9 B_0 A_5 E_2 
Stack 5
A_9 C_5 C_4 A_6 
Stack 6
B_6 B_8 C_7 A_3 
Stack 7
D_1 D_2 B_4 A_1 
Stack 8
D_0 A_8 E_9 E_3 
Stack 9
D_7 C_10 A_2 D_10 
Stack 10
C_2 E_6 E_1 B_2 
Stack 11
A_7 E_8 B_3 D_4 
Stack 12
B_5 B_7 B_1 C_6 
Stack 13
C_0 A_4 E_5 
Stack 14
E_4 D_8 D_5 
