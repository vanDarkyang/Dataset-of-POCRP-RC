Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_5 G_3 D_0 I_3 F_3 
Stack 2
B_0 F_8 J_3 H_3 E_2 
Stack 3
B_3 G_6 G_0 J_2 I_2 
Stack 4
B_2 E_3 C_4 I_1 I_5 
Stack 5
C_5 E_1 G_1 J_1 B_4 
Stack 6
D_4 H_4 J_0 C_0 D_2 
Stack 7
E_6 E_0 B_5 A_0 A_2 
Stack 8
H_0 G_7 J_4 I_0 F_5 
Stack 9
F_2 H_1 F_7 G_4 A_4 
Stack 10
H_5 E_7 D_6 E_4 F_1 
Stack 11
A_1 C_2 F_0 I_4 G_2 
Stack 12
D_5 F_4 A_3 E_5 H_2 
Stack 13
D_1 E_8 F_6 C_1 C_6 
Stack 14
H_6 D_7 D_3 C_3 B_1 
