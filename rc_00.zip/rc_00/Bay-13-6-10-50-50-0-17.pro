Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_1 E_1 H_2 G_1 
Stack 2
D_0 G_4 G_0 D_5 
Stack 3
D_2 A_2 F_2 C_0 
Stack 4
I_1 E_5 J_0 F_1 
Stack 5
F_6 C_3 I_2 J_1 
Stack 6
G_3 E_2 A_0 E_3 
Stack 7
C_2 C_1 I_0 I_3 
Stack 8
E_4 G_5 H_1 F_4 
Stack 9
D_3 B_0 E_6 H_0 
Stack 10
C_4 F_0 H_3 F_3 
Stack 11
B_1 A_1 F_5 G_2 
Stack 12
B_3 J_2 D_4 
Stack 13
E_0 H_4 B_2 
