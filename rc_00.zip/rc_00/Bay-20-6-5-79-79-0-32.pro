Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 C_13 E_8 B_5 
Stack 2
D_1 A_14 A_3 C_8 
Stack 3
E_12 C_10 E_6 C_3 
Stack 4
D_4 E_2 E_11 D_5 
Stack 5
B_11 D_0 B_4 A_7 
Stack 6
B_7 D_6 C_12 A_6 
Stack 7
E_9 D_7 B_8 A_2 
Stack 8
B_13 E_1 B_6 C_2 
Stack 9
B_2 D_3 E_5 B_1 
Stack 10
E_10 D_12 B_3 C_9 
Stack 11
B_0 D_9 C_6 A_8 
Stack 12
D_13 B_14 B_9 A_0 
Stack 13
D_10 A_5 E_7 C_0 
Stack 14
C_15 C_16 C_1 B_10 
Stack 15
B_12 E_3 E_4 E_14 
Stack 16
D_11 C_11 A_13 D_14 
Stack 17
A_12 C_5 A_10 A_9 
Stack 18
E_13 C_7 C_4 C_14 
Stack 19
D_2 D_15 E_0 B_15 
Stack 20
D_8 A_4 A_11 
