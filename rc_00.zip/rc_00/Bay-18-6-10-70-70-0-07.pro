Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 A_3 H_0 G_6 
Stack 2
B_0 D_4 F_7 H_1 
Stack 3
D_6 H_2 C_0 J_2 
Stack 4
D_5 I_1 G_5 I_5 
Stack 5
E_0 J_4 B_5 C_4 
Stack 6
F_3 B_1 D_2 A_2 
Stack 7
G_0 C_1 D_0 C_2 
Stack 8
H_6 G_2 F_5 I_4 
Stack 9
I_0 I_2 G_7 G_4 
Stack 10
E_1 C_5 I_3 D_3 
Stack 11
E_3 F_4 A_4 J_3 
Stack 12
D_1 E_7 J_1 G_3 
Stack 13
H_4 A_0 G_1 D_7 
Stack 14
E_2 J_0 B_2 B_4 
Stack 15
E_5 E_4 H_3 H_5 
Stack 16
B_3 F_6 F_0 F_8 
Stack 17
C_3 E_6 F_1 
Stack 18
F_2 C_6 E_8 
