Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_15 E_0 C_1 C_16 
Stack 2
C_7 D_8 B_2 D_10 
Stack 3
A_4 D_11 A_7 A_12 
Stack 4
D_5 B_9 B_13 D_3 
Stack 5
C_8 C_10 D_1 D_9 
Stack 6
E_4 C_6 C_2 A_0 
Stack 7
B_14 A_1 C_13 D_13 
Stack 8
E_2 A_10 C_0 C_12 
Stack 9
A_9 B_15 A_5 E_7 
Stack 10
D_4 B_1 A_11 A_2 
Stack 11
B_10 C_9 B_6 E_13 
Stack 12
B_4 E_5 C_5 E_10 
Stack 13
A_6 B_11 D_15 B_3 
Stack 14
C_14 D_6 E_1 D_7 
Stack 15
E_12 B_7 B_0 A_8 
Stack 16
E_3 C_4 A_13 E_14 
Stack 17
C_3 A_3 D_14 E_8 
Stack 18
B_12 B_8 E_11 C_11 
Stack 19
E_9 E_6 A_14 D_12 
Stack 20
D_2 B_5 D_0 
