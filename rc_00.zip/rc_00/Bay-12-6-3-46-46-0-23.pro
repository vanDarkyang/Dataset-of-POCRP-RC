Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_10 A_13 C_4 A_0 
Stack 2
A_2 C_7 B_11 B_9 
Stack 3
A_10 C_5 A_6 B_6 
Stack 4
B_4 C_1 C_0 B_7 
Stack 5
B_13 A_7 A_4 C_3 
Stack 6
A_11 C_8 A_8 C_2 
Stack 7
B_12 B_5 B_2 C_6 
Stack 8
C_14 A_9 A_5 A_12 
Stack 9
B_15 C_10 B_8 B_3 
Stack 10
C_12 C_9 C_13 A_3 
Stack 11
B_0 B_14 B_1 
Stack 12
A_14 C_11 A_1 
