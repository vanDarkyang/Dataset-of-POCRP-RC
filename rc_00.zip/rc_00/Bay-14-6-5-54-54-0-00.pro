Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_8 E_3 E_8 D_6 
Stack 2
B_0 C_10 D_1 B_9 
Stack 3
B_5 B_10 E_1 A_8 
Stack 4
A_5 C_1 D_3 E_6 
Stack 5
E_5 A_0 E_2 A_1 
Stack 6
C_11 B_6 C_0 C_6 
Stack 7
D_9 A_9 E_0 B_3 
Stack 8
C_7 C_4 E_9 D_8 
Stack 9
C_2 A_2 B_1 C_3 
Stack 10
A_4 C_9 B_4 E_4 
Stack 11
D_2 A_6 E_7 D_4 
Stack 12
D_10 A_7 B_7 B_2 
Stack 13
D_0 D_7 C_5 
Stack 14
A_3 D_5 C_8 
