Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_8 I_3 D_6 E_1 H_4 D_4 
Stack 2
J_6 J_4 A_9 A_3 D_1 G_9 
Stack 3
B_4 F_4 E_4 E_11 J_3 A_1 
Stack 4
D_0 C_11 I_7 C_1 G_4 E_2 
Stack 5
I_4 F_2 G_0 F_11 C_7 E_10 
Stack 6
F_5 F_1 J_0 G_10 F_10 
Stack 7
G_12 C_2 F_3 H_7 D_5 
Stack 8
D_10 H_11 J_9 E_13 G_3 
Stack 9
D_11 C_5 C_4 B_8 E_6 
Stack 10
B_9 A_8 E_9 A_0 E_8 
Stack 11
I_0 D_2 E_0 G_7 A_7 
Stack 12
B_10 G_8 E_5 C_9 D_12 
Stack 13
C_8 H_3 F_0 H_9 J_8 
Stack 14
C_0 D_8 I_2 I_1 D_7 
Stack 15
B_3 I_6 J_1 B_7 F_12 
Stack 16
E_3 F_7 B_5 F_9 A_6 
Stack 17
J_2 G_2 B_0 C_6 B_6 
Stack 18
H_0 E_7 E_12 F_6 G_6 
Stack 19
H_8 B_1 B_2 H_10 H_1 
Stack 20
D_9 H_2 A_5 I_9 H_5 
Stack 21
I_5 C_3 J_7 G_11 C_10 
Stack 22
H_6 F_13 J_5 A_4 I_10 
Stack 23
I_8 G_5 G_1 A_2 D_3 
