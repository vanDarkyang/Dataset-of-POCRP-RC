Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_9 A_0 D_12 D_2 B_14 E_6 
Stack 2
B_8 E_1 E_11 A_12 B_13 C_4 
Stack 3
E_5 B_0 B_11 E_10 E_2 E_14 
Stack 4
B_12 A_4 A_9 D_4 B_10 C_12 
Stack 5
A_3 A_8 D_14 D_13 C_8 
Stack 6
A_7 D_9 A_13 B_5 B_9 
Stack 7
A_6 C_6 C_0 B_4 E_7 
Stack 8
E_0 E_13 D_10 D_0 C_3 
Stack 9
A_14 B_2 E_12 D_6 E_3 
Stack 10
A_11 D_1 B_3 C_1 D_3 
Stack 11
E_8 A_5 B_6 B_15 C_16 
Stack 12
D_11 C_10 D_8 C_14 A_2 
Stack 13
C_11 C_15 C_13 D_7 B_1 
Stack 14
C_7 D_15 C_9 A_10 C_2 
Stack 15
C_5 D_5 A_1 E_4 B_7 
