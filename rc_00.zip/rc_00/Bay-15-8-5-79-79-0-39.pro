Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_4 D_13 A_14 D_11 C_3 A_11 
Stack 2
A_13 B_12 A_10 A_5 E_1 D_8 
Stack 3
D_4 D_12 D_15 A_0 B_0 E_13 
Stack 4
C_2 C_14 C_10 C_15 C_9 E_5 
Stack 5
D_5 B_13 E_14 E_7 B_7 
Stack 6
D_2 B_10 C_0 A_2 E_12 
Stack 7
D_3 A_7 C_13 A_9 B_14 
Stack 8
C_11 D_10 E_2 D_9 D_14 
Stack 9
B_5 A_1 E_0 C_7 E_11 
Stack 10
D_0 B_2 E_3 C_12 C_8 
Stack 11
A_8 A_6 B_9 D_1 B_8 
Stack 12
E_9 A_3 B_1 D_7 E_6 
Stack 13
B_6 E_8 D_6 B_11 B_15 
Stack 14
E_4 A_12 C_16 C_6 B_4 
Stack 15
A_4 E_10 C_1 C_5 B_3 
