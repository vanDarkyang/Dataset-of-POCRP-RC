Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_2 H_1 H_8 I_7 D_9 H_7 
Stack 2
D_11 A_1 G_1 F_9 C_0 F_11 
Stack 3
B_0 H_11 E_8 J_6 E_9 A_6 
Stack 4
A_9 D_6 I_3 G_10 I_0 G_12 
Stack 5
H_5 I_9 H_10 D_1 D_12 D_8 
Stack 6
C_7 E_0 C_4 C_8 C_10 
Stack 7
G_4 G_6 E_12 B_3 E_3 
Stack 8
J_2 B_6 F_3 F_10 J_9 
Stack 9
C_6 D_3 G_8 I_4 D_5 
Stack 10
J_8 F_4 I_6 E_11 C_5 
Stack 11
F_5 E_2 I_1 E_1 H_6 
Stack 12
C_1 E_7 A_7 F_1 F_13 
Stack 13
B_9 A_5 G_5 E_4 I_8 
Stack 14
D_2 E_6 B_5 A_4 J_5 
Stack 15
H_9 E_10 B_7 C_11 A_2 
Stack 16
H_0 A_3 D_0 B_4 B_10 
Stack 17
G_2 D_4 J_1 J_3 C_3 
Stack 18
I_5 H_2 G_0 B_8 A_0 
Stack 19
I_2 H_3 F_0 G_7 E_5 
Stack 20
E_13 C_9 D_10 F_7 G_9 
Stack 21
F_6 J_4 B_1 I_10 H_4 
Stack 22
A_8 G_11 B_2 F_2 F_8 
Stack 23
F_12 G_3 D_7 J_0 J_7 
