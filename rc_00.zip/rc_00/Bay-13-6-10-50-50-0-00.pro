Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_0 G_2 A_0 I_0 
Stack 2
E_4 E_0 D_1 C_0 
Stack 3
B_2 F_1 H_4 C_4 
Stack 4
F_3 I_2 G_3 D_3 
Stack 5
F_4 E_1 B_0 F_2 
Stack 6
D_2 A_1 F_5 E_6 
Stack 7
C_1 D_0 I_1 E_3 
Stack 8
D_4 F_0 I_3 A_2 
Stack 9
C_2 G_4 J_2 F_6 
Stack 10
J_0 G_0 H_3 D_5 
Stack 11
E_5 G_5 B_3 C_3 
Stack 12
H_1 E_2 J_1 
Stack 13
B_1 H_2 G_1 
