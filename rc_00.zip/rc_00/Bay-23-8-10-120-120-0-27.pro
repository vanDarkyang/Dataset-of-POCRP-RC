Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_2 G_3 D_6 G_4 D_12 E_0 
Stack 2
C_8 B_10 F_2 G_10 J_7 A_0 
Stack 3
B_8 A_3 A_1 I_10 F_11 B_7 
Stack 4
B_9 F_8 I_7 J_2 J_9 G_9 
Stack 5
C_6 B_0 I_2 I_1 C_4 G_7 
Stack 6
F_12 E_11 A_6 I_0 D_8 
Stack 7
B_4 D_11 F_7 A_9 D_4 
Stack 8
J_8 H_7 E_9 D_5 F_9 
Stack 9
C_2 E_4 F_6 H_11 I_4 
Stack 10
G_6 E_13 H_5 A_8 B_6 
Stack 11
F_0 B_5 D_1 H_10 F_4 
Stack 12
E_10 H_6 C_9 J_4 B_2 
Stack 13
I_5 G_2 C_0 H_2 G_0 
Stack 14
I_6 D_3 H_1 H_9 C_5 
Stack 15
E_6 H_4 G_11 E_8 A_7 
Stack 16
G_12 F_5 G_1 H_0 E_12 
Stack 17
I_3 F_1 A_4 E_3 A_2 
Stack 18
E_7 F_3 A_5 F_10 D_2 
Stack 19
D_0 E_5 I_8 B_3 C_1 
Stack 20
C_11 J_1 H_3 J_0 D_10 
Stack 21
D_7 J_5 H_8 J_6 C_7 
Stack 22
D_9 C_10 G_8 I_9 C_3 
Stack 23
G_5 B_1 J_3 E_1 F_13 
