Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_3 D_12 E_3 B_12 
Stack 2
D_15 B_10 C_15 B_13 
Stack 3
B_14 D_4 B_1 B_8 
Stack 4
C_3 A_0 D_7 D_11 
Stack 5
B_11 A_14 D_10 C_1 
Stack 6
A_3 C_16 E_9 A_5 
Stack 7
C_12 B_2 C_14 C_10 
Stack 8
E_13 B_6 E_8 D_2 
Stack 9
C_4 A_11 C_5 A_4 
Stack 10
B_9 E_14 C_9 B_4 
Stack 11
B_7 B_15 D_8 A_12 
Stack 12
D_1 C_11 D_9 A_2 
Stack 13
A_7 A_13 D_0 E_0 
Stack 14
C_6 A_9 A_8 D_13 
Stack 15
C_8 E_6 B_3 D_5 
Stack 16
E_4 E_1 B_5 A_1 
Stack 17
A_10 E_5 C_7 D_6 
Stack 18
C_13 C_0 B_0 E_12 
Stack 19
E_2 C_2 E_7 E_10 
Stack 20
A_6 D_14 E_11 
