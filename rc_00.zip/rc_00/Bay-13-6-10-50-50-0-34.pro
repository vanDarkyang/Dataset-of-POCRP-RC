Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_3 G_5 B_0 D_4 
Stack 2
C_2 I_0 J_2 E_0 
Stack 3
E_6 C_0 C_4 G_4 
Stack 4
B_1 A_1 C_3 F_2 
Stack 5
F_0 H_2 H_3 D_3 
Stack 6
E_1 D_1 F_4 J_1 
Stack 7
F_6 B_3 H_1 D_5 
Stack 8
F_1 E_5 G_0 G_2 
Stack 9
F_3 H_4 H_0 J_0 
Stack 10
A_0 G_1 C_1 D_2 
Stack 11
E_4 G_3 B_2 D_0 
Stack 12
I_1 F_5 I_2 
Stack 13
E_2 A_2 E_3 
