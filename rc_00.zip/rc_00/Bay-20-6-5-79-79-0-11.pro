Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_11 E_4 D_10 C_5 
Stack 2
C_9 A_5 D_6 E_1 
Stack 3
B_0 C_8 E_8 C_4 
Stack 4
C_16 B_3 D_0 E_11 
Stack 5
C_2 C_0 A_4 E_5 
Stack 6
A_14 C_13 B_2 A_1 
Stack 7
E_12 B_11 A_11 A_7 
Stack 8
A_13 D_12 D_5 E_10 
Stack 9
E_2 C_7 E_3 C_15 
Stack 10
D_7 B_8 D_8 D_3 
Stack 11
B_12 B_7 D_15 B_14 
Stack 12
B_9 B_4 C_3 B_13 
Stack 13
A_0 A_10 D_4 E_6 
Stack 14
C_10 A_2 B_15 A_3 
Stack 15
B_10 C_1 D_13 A_8 
Stack 16
E_13 E_14 C_11 B_6 
Stack 17
C_14 D_1 D_9 B_5 
Stack 18
A_6 C_12 D_14 E_9 
Stack 19
C_6 E_7 A_9 B_1 
Stack 20
A_12 E_0 D_2 
