Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_8 C_0 D_2 C_7 
Stack 2
D_10 B_0 D_0 B_1 
Stack 3
C_5 B_3 B_5 E_2 
Stack 4
A_9 C_11 D_9 B_10 
Stack 5
C_6 B_2 D_7 B_4 
Stack 6
C_8 E_6 A_6 E_4 
Stack 7
E_1 C_3 E_3 E_5 
Stack 8
D_1 C_2 B_7 B_8 
Stack 9
D_5 E_7 A_2 D_6 
Stack 10
A_5 B_9 E_9 C_10 
Stack 11
A_7 A_1 E_8 C_4 
Stack 12
C_1 A_4 D_4 D_8 
Stack 13
D_3 A_3 A_0 
Stack 14
C_9 B_6 E_0 
