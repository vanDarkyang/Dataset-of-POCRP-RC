Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_4 B_2 A_9 C_10 D_4 
Stack 2
C_7 B_3 B_1 B_6 B_9 
Stack 3
C_8 E_8 C_2 A_3 E_3 
Stack 4
D_3 D_7 C_3 C_1 C_11 
Stack 5
A_2 A_0 E_0 C_4 A_6 
Stack 6
A_8 A_5 B_8 B_5 E_9 
Stack 7
D_2 C_5 B_0 E_2 A_7 
Stack 8
C_6 A_1 E_7 C_9 B_10 
Stack 9
B_4 D_8 B_7 D_9 D_6 
Stack 10
C_0 E_6 E_1 D_5 D_0 
Stack 11
A_4 D_1 D_10 E_5 
