Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 E_4 F_5 I_1 
Stack 2
D_5 E_1 G_4 I_3 
Stack 3
H_3 D_3 I_2 G_2 
Stack 4
E_6 J_0 F_1 F_0 
Stack 5
A_1 J_1 E_5 H_4 
Stack 6
E_2 C_1 A_0 D_0 
Stack 7
E_0 A_2 C_2 G_3 
Stack 8
D_1 I_0 G_1 G_0 
Stack 9
H_2 F_4 H_1 C_4 
Stack 10
C_0 B_2 H_0 B_1 
Stack 11
E_3 B_3 B_0 D_4 
Stack 12
F_2 D_2 J_2 
Stack 13
G_5 F_6 F_3 
