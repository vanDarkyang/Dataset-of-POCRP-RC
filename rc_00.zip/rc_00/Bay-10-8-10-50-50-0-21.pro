Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_1 E_4 E_3 D_3 H_3 
Stack 2
B_2 D_1 E_2 D_2 C_2 
Stack 3
A_2 H_2 C_1 G_2 E_6 
Stack 4
A_0 E_0 H_4 G_5 H_1 
Stack 5
F_6 G_3 F_2 J_1 J_0 
Stack 6
D_0 B_1 I_2 B_0 C_3 
Stack 7
D_4 B_3 F_3 F_4 E_5 
Stack 8
F_5 G_4 G_0 I_1 D_5 
Stack 9
G_1 E_1 I_3 A_1 C_0 
Stack 10
C_4 F_0 J_2 I_0 H_0 
