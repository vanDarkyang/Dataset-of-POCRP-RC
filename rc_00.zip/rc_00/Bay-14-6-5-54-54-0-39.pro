Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_8 D_7 C_11 B_9 
Stack 2
E_5 D_2 B_6 B_2 
Stack 3
D_1 C_1 A_0 E_2 
Stack 4
D_3 E_7 D_5 B_8 
Stack 5
C_2 D_6 C_6 A_5 
Stack 6
A_8 B_7 E_9 E_3 
Stack 7
D_0 A_6 A_1 B_4 
Stack 8
C_7 A_4 B_5 A_7 
Stack 9
B_10 C_5 C_0 B_3 
Stack 10
B_0 A_3 D_9 C_4 
Stack 11
C_8 D_8 E_1 D_10 
Stack 12
C_10 E_4 D_4 E_0 
Stack 13
E_6 A_2 C_3 
Stack 14
C_9 A_9 B_1 
