Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_12 C_1 E_0 E_3 B_9 B_0 
Stack 2
B_2 C_10 E_7 E_12 C_6 D_13 
Stack 3
A_4 B_14 C_8 E_10 A_12 E_11 
Stack 4
D_8 C_3 C_4 A_11 A_8 C_16 
Stack 5
A_10 D_14 B_8 A_14 D_11 
Stack 6
B_1 D_2 A_0 D_4 D_6 
Stack 7
C_7 D_7 B_3 A_6 C_2 
Stack 8
B_10 A_13 C_11 E_2 E_4 
Stack 9
D_0 D_3 C_0 A_7 C_9 
Stack 10
B_6 D_12 C_13 D_10 D_1 
Stack 11
B_12 D_9 A_5 E_8 C_15 
Stack 12
E_1 E_9 B_11 C_14 A_1 
Stack 13
A_9 D_5 B_15 E_5 B_5 
Stack 14
D_15 B_4 A_2 E_14 E_13 
Stack 15
B_13 C_5 B_7 E_6 A_3 
