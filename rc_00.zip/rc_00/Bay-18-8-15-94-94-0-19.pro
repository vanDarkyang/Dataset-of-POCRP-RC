Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
N_1 E_1 B_2 K_2 J_2 J_5 
Stack 2
C_3 M_0 G_7 H_6 K_5 F_4 
Stack 3
G_4 H_0 D_2 C_0 H_4 H_3 
Stack 4
F_0 O_2 N_3 H_5 L_2 I_1 
Stack 5
K_3 L_1 J_1 G_2 N_2 
Stack 6
D_3 C_2 H_7 K_0 A_0 
Stack 7
G_3 G_0 A_2 E_2 M_4 
Stack 8
D_0 J_3 F_3 D_1 B_0 
Stack 9
F_5 H_1 H_8 K_1 F_6 
Stack 10
L_0 N_0 I_6 K_4 C_1 
Stack 11
L_3 E_0 B_3 D_5 F_2 
Stack 12
I_0 A_1 C_4 I_3 J_6 
Stack 13
G_6 E_4 J_7 E_5 G_5 
Stack 14
L_4 H_9 J_0 L_5 E_6 
Stack 15
I_2 J_4 I_4 E_3 B_1 
Stack 16
I_5 I_7 K_6 G_8 O_0 
Stack 17
M_3 G_1 F_7 M_2 D_4 
Stack 18
H_2 I_8 M_1 F_1 O_1 
