Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
I_7 J_3 E_0 D_5 F_8 F_6 
Stack 2
J_6 E_8 I_4 E_6 B_10 F_9 
Stack 3
B_9 B_5 B_8 E_7 I_9 J_8 
Stack 4
B_2 F_2 D_12 G_1 G_6 G_10 
Stack 5
A_0 G_5 C_3 G_2 E_11 D_11 
Stack 6
D_1 C_1 G_4 G_7 E_9 
Stack 7
E_4 D_6 C_5 C_7 D_0 
Stack 8
E_1 D_8 H_8 J_0 D_2 
Stack 9
A_8 A_1 H_0 H_1 H_6 
Stack 10
B_1 A_4 E_12 C_9 C_2 
Stack 11
H_3 G_0 F_13 C_8 H_2 
Stack 12
D_9 B_3 E_5 D_3 C_6 
Stack 13
E_13 G_9 I_5 C_10 H_4 
Stack 14
H_10 C_0 A_2 I_1 J_5 
Stack 15
J_9 H_7 F_7 E_10 F_4 
Stack 16
D_4 C_4 F_0 J_4 J_2 
Stack 17
J_7 A_5 B_4 I_6 A_7 
Stack 18
F_12 E_2 I_0 G_3 F_11 
Stack 19
E_3 A_9 I_2 A_6 B_7 
Stack 20
C_11 A_3 G_8 B_6 I_8 
Stack 21
H_5 B_0 I_10 J_1 H_9 
Stack 22
G_12 D_7 H_11 F_5 G_11 
Stack 23
D_10 F_1 F_3 F_10 I_3 
