Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_3 E_7 F_7 C_8 I_0 I_1 
Stack 2
A_5 I_10 G_6 I_7 I_2 B_8 
Stack 3
F_6 I_3 J_4 B_10 J_0 E_13 
Stack 4
D_0 E_9 C_4 F_0 E_10 C_10 
Stack 5
C_6 B_3 B_6 G_5 E_12 E_6 
Stack 6
H_10 E_8 A_4 C_2 I_9 
Stack 7
D_6 D_1 E_3 A_9 H_2 
Stack 8
A_1 H_8 B_1 F_2 G_3 
Stack 9
H_9 E_1 D_9 G_7 D_2 
Stack 10
F_5 C_5 F_8 H_5 G_12 
Stack 11
J_2 J_1 B_4 G_0 G_8 
Stack 12
A_3 E_4 F_3 A_7 D_10 
Stack 13
J_9 F_12 G_4 D_11 F_9 
Stack 14
I_6 B_0 F_11 C_9 F_10 
Stack 15
G_10 I_8 D_5 G_9 G_11 
Stack 16
H_4 B_7 F_1 B_2 H_11 
Stack 17
D_7 A_8 J_8 H_1 I_4 
Stack 18
C_7 E_2 J_6 E_5 A_6 
Stack 19
E_11 F_13 A_0 H_7 B_9 
Stack 20
C_0 A_2 F_4 D_4 C_3 
Stack 21
H_0 D_8 C_1 I_5 H_6 
Stack 22
G_1 G_2 D_12 J_5 J_7 
Stack 23
C_11 D_3 J_3 E_0 B_5 
