Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_6 F_3 A_3 H_6 
Stack 2
B_3 J_2 I_3 D_2 
Stack 3
G_1 B_4 B_5 C_1 
Stack 4
C_4 D_3 J_1 E_7 
Stack 5
J_3 G_6 F_4 E_6 
Stack 6
A_0 G_7 I_2 F_1 
Stack 7
D_0 E_2 J_4 H_3 
Stack 8
E_1 A_4 B_0 H_5 
Stack 9
F_5 H_4 F_2 C_0 
Stack 10
E_8 G_0 D_5 B_1 
Stack 11
H_0 C_2 D_1 E_4 
Stack 12
F_6 G_4 A_1 H_1 
Stack 13
J_0 I_0 D_4 G_5 
Stack 14
B_2 E_3 C_3 I_1 
Stack 15
C_5 A_2 E_0 C_6 
Stack 16
I_4 E_5 F_0 G_2 
Stack 17
F_8 I_5 H_2 
Stack 18
D_7 F_7 G_3 
