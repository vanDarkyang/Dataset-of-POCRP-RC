Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_5 L_0 I_0 E_3 B_0 H_8 
Stack 2
G_0 I_1 H_0 N_2 F_6 N_3 
Stack 3
B_1 H_9 K_0 I_5 O_2 G_1 
Stack 4
H_4 J_1 H_7 J_5 L_1 D_2 
Stack 5
I_4 C_4 C_0 J_7 F_2 
Stack 6
C_2 K_4 D_5 E_1 I_8 
Stack 7
N_0 G_4 C_3 E_0 J_3 
Stack 8
E_4 J_2 K_2 M_3 H_1 
Stack 9
J_4 O_1 E_6 A_2 I_3 
Stack 10
K_5 G_7 L_4 G_5 G_8 
Stack 11
B_3 O_0 K_6 F_3 H_3 
Stack 12
M_4 E_2 M_0 D_4 H_2 
Stack 13
L_5 L_2 D_1 C_1 N_1 
Stack 14
K_3 D_0 H_6 M_2 L_3 
Stack 15
I_7 M_1 G_3 B_2 K_1 
Stack 16
A_1 F_4 I_6 G_6 A_0 
Stack 17
D_3 F_1 H_5 F_0 I_2 
Stack 18
J_0 F_5 G_2 J_6 F_7 
