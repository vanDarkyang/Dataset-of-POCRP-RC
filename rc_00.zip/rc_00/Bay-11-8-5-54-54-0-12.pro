Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_10 B_0 D_10 E_0 E_4 
Stack 2
B_3 D_8 C_7 B_2 B_10 
Stack 3
E_7 B_6 C_5 B_5 D_2 
Stack 4
C_11 B_4 C_1 C_2 E_5 
Stack 5
D_3 E_6 C_0 C_8 A_7 
Stack 6
A_8 A_0 D_9 D_7 D_4 
Stack 7
D_1 C_3 A_5 A_3 B_9 
Stack 8
E_1 E_3 D_5 B_1 C_4 
Stack 9
A_9 C_9 A_2 B_8 A_4 
Stack 10
B_7 E_8 C_6 D_6 E_2 
Stack 11
A_1 D_0 E_9 A_6 
