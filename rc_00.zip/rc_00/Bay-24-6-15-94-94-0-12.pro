Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_5 F_0 L_3 D_5 
Stack 2
E_5 F_5 E_2 L_2 
Stack 3
K_3 H_0 I_7 H_6 
Stack 4
N_0 H_9 I_3 J_5 
Stack 5
A_1 G_6 I_2 L_4 
Stack 6
D_1 G_7 G_3 D_2 
Stack 7
F_1 L_5 G_8 G_4 
Stack 8
H_2 B_2 M_1 H_8 
Stack 9
C_4 F_7 K_5 C_0 
Stack 10
A_2 H_7 E_6 I_1 
Stack 11
O_2 N_2 K_6 J_7 
Stack 12
A_0 G_0 M_2 B_1 
Stack 13
E_4 G_2 K_4 I_8 
Stack 14
J_4 D_0 N_3 B_3 
Stack 15
I_0 J_2 H_5 H_3 
Stack 16
H_4 F_6 E_0 I_4 
Stack 17
K_2 I_5 J_6 E_3 
Stack 18
C_3 C_1 M_4 K_1 
Stack 19
J_3 I_6 G_1 M_0 
Stack 20
H_1 J_1 M_3 C_2 
Stack 21
F_2 B_0 D_3 L_1 
Stack 22
F_4 O_0 O_1 D_4 
Stack 23
E_1 K_0 L_0 
Stack 24
F_3 N_1 J_0 
