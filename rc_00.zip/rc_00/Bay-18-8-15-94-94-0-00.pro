Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
O_1 L_2 G_2 J_5 G_0 I_6 
Stack 2
C_1 H_1 B_3 J_6 K_3 K_0 
Stack 3
J_1 H_0 A_1 N_3 G_1 H_8 
Stack 4
C_4 K_4 E_5 B_0 C_3 L_1 
Stack 5
O_2 F_2 M_3 D_3 B_2 
Stack 6
E_1 F_1 A_2 L_5 E_6 
Stack 7
G_5 F_3 G_4 I_5 H_7 
Stack 8
M_0 D_4 C_2 J_7 A_0 
Stack 9
D_1 E_2 I_1 M_4 H_6 
Stack 10
F_4 K_5 I_2 G_8 E_0 
Stack 11
K_2 F_0 D_0 L_4 N_2 
Stack 12
H_5 H_9 G_6 O_0 B_1 
Stack 13
D_5 J_4 L_3 M_2 E_4 
Stack 14
M_1 I_4 K_1 I_8 G_3 
Stack 15
G_7 C_0 J_2 D_2 F_5 
Stack 16
I_0 L_0 J_3 K_6 N_1 
Stack 17
F_6 H_2 H_3 E_3 I_7 
Stack 18
I_3 H_4 F_7 N_0 J_0 
