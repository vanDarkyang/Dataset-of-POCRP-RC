Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_7 B_13 A_5 B_7 
Stack 2
C_8 B_0 B_4 B_1 
Stack 3
A_4 A_3 A_7 B_11 
Stack 4
A_11 C_2 A_14 B_6 
Stack 5
A_9 C_5 A_6 B_3 
Stack 6
A_10 C_3 C_4 A_1 
Stack 7
B_10 B_5 A_8 B_8 
Stack 8
C_0 B_14 C_1 B_15 
Stack 9
C_6 A_12 A_0 A_2 
Stack 10
B_2 C_9 C_14 C_13 
Stack 11
B_12 C_10 C_11 
Stack 12
C_12 B_9 A_13 
