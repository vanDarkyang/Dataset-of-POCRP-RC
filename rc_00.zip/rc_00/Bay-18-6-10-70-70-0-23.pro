Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_4 E_3 E_6 E_2 
Stack 2
H_6 J_1 J_2 H_2 
Stack 3
G_5 H_4 B_4 C_0 
Stack 4
D_5 F_1 G_7 F_8 
Stack 5
C_4 H_1 H_3 G_0 
Stack 6
C_3 H_0 G_3 I_5 
Stack 7
A_3 J_3 A_0 C_2 
Stack 8
B_5 I_1 I_4 A_4 
Stack 9
E_7 G_2 D_3 D_4 
Stack 10
E_1 A_2 D_7 A_1 
Stack 11
G_4 F_2 C_1 I_3 
Stack 12
F_7 E_5 G_1 F_5 
Stack 13
B_1 E_0 F_4 C_5 
Stack 14
C_6 E_8 F_6 H_5 
Stack 15
G_6 J_0 D_6 D_0 
Stack 16
F_3 F_0 B_2 I_0 
Stack 17
E_4 D_2 B_0 
Stack 18
D_1 I_2 B_3 
