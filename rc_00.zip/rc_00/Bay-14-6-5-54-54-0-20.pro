Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_7 E_3 C_5 B_4 
Stack 2
A_1 A_8 E_0 C_1 
Stack 3
A_3 B_10 D_7 D_2 
Stack 4
E_5 D_8 D_0 C_4 
Stack 5
B_6 C_10 E_8 C_2 
Stack 6
C_11 B_9 D_10 D_9 
Stack 7
B_7 C_3 C_6 D_4 
Stack 8
E_6 A_9 A_2 D_5 
Stack 9
B_8 B_3 A_5 C_7 
Stack 10
C_8 B_2 A_4 A_0 
Stack 11
C_9 E_2 A_6 B_0 
Stack 12
D_6 E_9 D_3 E_4 
Stack 13
D_1 A_7 E_1 
Stack 14
B_1 B_5 C_0 
