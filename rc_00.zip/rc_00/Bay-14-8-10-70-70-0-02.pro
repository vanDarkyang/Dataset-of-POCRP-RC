Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_6 C_5 C_2 J_4 C_1 
Stack 2
B_3 I_4 G_4 B_0 E_7 
Stack 3
G_1 F_8 I_0 F_2 E_6 
Stack 4
C_4 D_7 E_3 D_5 F_1 
Stack 5
J_3 F_3 A_2 D_1 H_3 
Stack 6
A_0 J_2 E_5 A_1 H_5 
Stack 7
D_0 B_4 I_5 D_4 C_0 
Stack 8
E_1 D_3 F_7 C_3 B_1 
Stack 9
F_5 G_6 A_3 E_0 E_4 
Stack 10
E_8 G_7 I_3 F_0 H_1 
Stack 11
H_0 E_2 B_5 H_2 G_5 
Stack 12
F_6 A_4 J_1 G_3 I_1 
Stack 13
J_0 H_4 F_4 H_6 C_6 
Stack 14
B_2 G_0 I_2 D_2 G_2 
