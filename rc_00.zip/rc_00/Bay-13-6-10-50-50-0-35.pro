Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_0 F_2 H_1 B_2 
Stack 2
B_0 D_3 D_4 E_2 
Stack 3
B_3 G_5 C_3 F_4 
Stack 4
J_0 H_2 I_2 F_3 
Stack 5
E_1 A_0 A_2 F_6 
Stack 6
G_3 C_1 B_1 E_6 
Stack 7
D_5 F_0 G_2 G_4 
Stack 8
D_0 D_1 I_0 I_1 
Stack 9
H_0 I_3 F_1 H_4 
Stack 10
H_3 C_0 D_2 J_2 
Stack 11
E_4 E_5 G_1 G_0 
Stack 12
J_1 E_3 C_4 
Stack 13
F_5 A_1 C_2 
