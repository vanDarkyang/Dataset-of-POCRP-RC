Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_2 D_2 D_8 A_9 C_2 
Stack 2
D_3 C_4 B_5 E_9 A_8 
Stack 3
B_0 E_1 B_2 C_11 A_5 
Stack 4
B_3 A_2 C_7 B_7 D_4 
Stack 5
D_10 C_9 D_6 D_9 D_0 
Stack 6
A_6 E_3 C_10 B_4 D_1 
Stack 7
A_1 E_4 D_7 B_10 D_5 
Stack 8
A_4 C_3 B_8 C_0 B_9 
Stack 9
E_7 C_8 E_6 E_5 B_6 
Stack 10
A_7 E_0 C_6 B_1 E_8 
Stack 11
A_0 C_1 C_5 A_3 
