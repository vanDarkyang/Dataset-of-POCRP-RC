Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_2 G_11 I_10 D_6 J_1 E_4 
Stack 2
E_2 I_6 E_1 F_11 C_8 J_9 
Stack 3
J_3 G_3 F_5 B_2 F_0 I_4 
Stack 4
D_3 G_7 B_0 C_6 J_2 G_12 
Stack 5
I_8 E_9 G_4 H_11 B_5 D_12 
Stack 6
B_3 G_10 B_1 J_7 C_10 
Stack 7
H_5 J_0 C_1 F_4 H_4 
Stack 8
D_8 A_9 H_7 D_11 H_6 
Stack 9
I_5 G_8 J_6 E_7 J_8 
Stack 10
B_8 D_10 A_7 A_4 H_2 
Stack 11
A_3 A_0 H_8 E_11 A_2 
Stack 12
B_9 G_1 H_9 E_5 I_9 
Stack 13
I_7 D_4 C_11 G_6 C_5 
Stack 14
E_0 I_3 D_1 F_3 G_0 
Stack 15
J_4 D_7 H_1 J_5 B_6 
Stack 16
G_9 F_9 G_2 I_0 D_0 
Stack 17
A_5 D_5 C_3 F_1 H_3 
Stack 18
C_2 D_9 F_12 C_9 E_8 
Stack 19
E_6 F_2 B_10 C_7 B_4 
Stack 20
E_10 E_13 I_2 H_10 A_6 
Stack 21
A_1 C_0 E_3 A_8 F_7 
Stack 22
F_13 F_8 I_1 F_6 B_7 
Stack 23
G_5 C_4 F_10 E_12 H_0 
