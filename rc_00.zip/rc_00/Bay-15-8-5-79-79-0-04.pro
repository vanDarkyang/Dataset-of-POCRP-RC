Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_8 A_1 C_2 E_3 E_8 B_9 
Stack 2
E_10 C_9 C_5 B_11 D_12 E_4 
Stack 3
A_9 C_14 C_3 A_11 C_13 B_3 
Stack 4
A_7 A_10 D_7 C_1 B_4 E_7 
Stack 5
D_4 B_2 D_15 B_7 B_15 
Stack 6
A_5 C_11 B_1 E_9 A_2 
Stack 7
C_6 C_4 D_14 B_5 B_13 
Stack 8
C_15 D_13 E_6 E_14 D_6 
Stack 9
C_0 E_12 B_10 B_12 B_14 
Stack 10
A_12 B_0 E_13 D_11 C_8 
Stack 11
D_2 A_3 E_11 C_12 A_8 
Stack 12
D_8 D_5 E_5 C_7 C_16 
Stack 13
A_13 E_1 A_6 D_0 D_9 
Stack 14
A_14 C_10 A_4 D_1 A_0 
Stack 15
B_6 E_2 D_10 E_0 D_3 
