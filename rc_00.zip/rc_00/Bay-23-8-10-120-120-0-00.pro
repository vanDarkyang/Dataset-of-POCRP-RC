Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_0 G_6 A_6 I_9 I_2 D_3 
Stack 2
G_7 B_8 B_10 G_9 H_9 F_8 
Stack 3
E_0 F_10 H_4 C_9 H_2 I_1 
Stack 4
B_6 J_6 F_4 D_11 E_4 C_1 
Stack 5
I_10 A_7 B_2 G_4 A_0 H_5 
Stack 6
J_7 B_1 C_2 D_7 J_5 
Stack 7
H_3 B_4 J_8 D_1 G_10 
Stack 8
E_1 B_5 E_2 F_0 H_8 
Stack 9
D_5 A_5 I_6 J_2 A_4 
Stack 10
C_11 G_8 G_5 F_7 H_1 
Stack 11
G_11 C_0 C_4 H_10 I_8 
Stack 12
D_9 F_6 G_12 A_2 H_11 
Stack 13
B_3 B_9 J_4 B_7 C_3 
Stack 14
G_3 H_0 J_0 I_0 I_3 
Stack 15
G_0 D_10 C_8 C_6 F_12 
Stack 16
I_5 J_1 G_2 F_2 I_4 
Stack 17
F_11 A_3 C_5 E_7 E_13 
Stack 18
C_10 I_7 H_7 F_9 E_8 
Stack 19
F_3 J_9 D_2 D_12 D_4 
Stack 20
E_5 E_12 C_7 D_6 F_1 
Stack 21
F_13 A_1 J_3 F_5 D_8 
Stack 22
H_6 E_3 E_9 E_11 G_1 
Stack 23
E_6 A_9 E_10 B_0 A_8 
