Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_3 E_4 E_3 E_0 
Stack 2
F_6 F_1 H_1 D_2 
Stack 3
G_2 D_4 B_0 E_5 
Stack 4
C_0 J_0 H_4 I_0 
Stack 5
A_0 B_2 D_3 E_6 
Stack 6
B_1 I_2 G_1 G_3 
Stack 7
I_1 E_2 B_3 F_3 
Stack 8
C_2 A_2 G_4 D_1 
Stack 9
J_2 H_0 F_5 F_2 
Stack 10
D_5 F_4 I_3 A_1 
Stack 11
F_0 D_0 G_5 C_1 
Stack 12
E_1 J_1 C_4 
Stack 13
H_2 G_0 C_3 
