Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 A_8 D_1 C_13 
Stack 2
A_14 B_2 C_7 A_4 
Stack 3
A_0 E_5 D_4 D_7 
Stack 4
B_11 D_6 E_12 C_2 
Stack 5
B_0 D_2 D_3 E_8 
Stack 6
B_15 E_3 C_12 C_15 
Stack 7
A_7 B_13 C_9 A_5 
Stack 8
A_13 D_15 A_10 D_5 
Stack 9
D_8 C_14 A_9 B_12 
Stack 10
A_11 B_14 E_9 E_0 
Stack 11
A_1 C_11 A_2 D_0 
Stack 12
C_3 B_8 D_12 D_13 
Stack 13
B_3 E_14 B_4 C_16 
Stack 14
B_5 C_1 E_2 C_8 
Stack 15
B_9 C_0 B_10 C_10 
Stack 16
A_12 D_11 C_4 C_6 
Stack 17
A_3 B_6 E_10 C_5 
Stack 18
E_6 E_1 D_14 E_7 
Stack 19
E_4 A_6 E_13 E_11 
Stack 20
B_7 D_10 D_9 
