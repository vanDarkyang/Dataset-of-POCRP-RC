Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_12 D_12 A_10 B_3 D_1 C_2 
Stack 2
B_6 B_14 A_1 B_15 E_0 A_0 
Stack 3
C_16 C_4 E_5 A_3 E_10 C_3 
Stack 4
B_9 A_11 A_5 D_11 C_5 E_3 
Stack 5
C_6 D_10 A_8 D_4 A_14 
Stack 6
C_8 D_14 E_2 E_13 D_9 
Stack 7
B_0 A_7 D_7 E_9 B_5 
Stack 8
C_13 B_13 A_12 B_10 D_0 
Stack 9
E_14 A_6 B_2 C_10 C_15 
Stack 10
B_1 B_11 B_12 E_1 C_1 
Stack 11
E_6 C_11 E_11 E_4 A_2 
Stack 12
C_7 E_7 C_9 C_0 A_9 
Stack 13
A_13 B_7 D_6 D_2 A_4 
Stack 14
B_4 D_3 C_14 C_12 D_8 
Stack 15
E_8 B_8 D_5 D_15 D_13 
