Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_8 I_3 I_0 E_7 F_2 H_1 
Stack 2
F_5 K_0 I_2 O_0 N_2 E_5 
Stack 3
H_2 N_0 I_6 G_10 I_8 D_6 
Stack 4
A_0 D_4 E_3 D_1 H_0 C_3 
Stack 5
B_3 O_1 C_1 G_9 J_5 
Stack 6
F_8 J_2 H_5 D_7 B_4 
Stack 7
F_4 K_7 G_8 F_9 F_1 
Stack 8
E_0 C_5 H_7 A_1 N_3 
Stack 9
B_5 H_4 I_7 J_0 A_4 
Stack 10
D_2 L_3 E_6 G_5 I_5 
Stack 11
H_11 F_3 H_6 F_6 K_3 
Stack 12
A_2 N_4 G_6 C_4 G_3 
Stack 13
K_5 L_5 I_9 E_4 D_0 
Stack 14
J_9 L_0 K_8 M_4 K_2 
Stack 15
D_5 G_1 M_2 O_2 K_1 
Stack 16
I_4 C_0 H_8 K_4 M_6 
Stack 17
D_3 H_3 J_6 E_1 B_0 
Stack 18
G_4 F_7 J_7 I_10 L_2 
Stack 19
G_7 F_0 M_5 B_2 H_9 
Stack 20
E_2 O_3 N_1 H_10 C_6 
Stack 21
M_3 M_1 M_0 G_2 I_1 
Stack 22
L_1 L_4 K_6 N_5 E_8 
Stack 23
J_3 B_1 C_2 J_4 O_4 
Stack 24
L_6 A_3 L_7 J_1 G_0 
