Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 I_0 E_1 H_3 
Stack 2
C_2 H_5 J_4 C_1 
Stack 3
D_2 F_0 D_1 G_5 
Stack 4
F_4 D_5 E_3 B_1 
Stack 5
E_0 H_0 G_7 F_6 
Stack 6
G_6 E_6 A_3 A_0 
Stack 7
J_2 H_6 H_4 B_0 
Stack 8
I_2 F_3 B_5 A_2 
Stack 9
E_2 D_7 G_3 J_3 
Stack 10
B_3 F_7 G_4 E_7 
Stack 11
E_8 D_6 B_2 G_2 
Stack 12
B_4 I_5 E_5 I_1 
Stack 13
A_4 H_2 H_1 F_2 
Stack 14
C_5 C_0 E_4 D_3 
Stack 15
F_1 J_1 F_8 I_4 
Stack 16
G_0 A_1 C_4 G_1 
Stack 17
D_0 F_5 I_3 
Stack 18
C_6 D_4 J_0 
