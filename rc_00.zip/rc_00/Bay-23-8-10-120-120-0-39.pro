Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_3 C_6 J_2 H_11 E_9 D_7 
Stack 2
G_8 E_4 J_6 H_9 D_8 E_3 
Stack 3
E_5 B_7 B_1 C_0 I_0 J_7 
Stack 4
A_8 D_6 J_8 E_8 H_10 G_5 
Stack 5
I_8 I_7 C_8 A_0 H_0 H_2 
Stack 6
J_0 G_0 A_7 B_4 F_5 
Stack 7
J_1 E_2 E_11 E_6 D_3 
Stack 8
I_10 I_3 D_9 C_9 E_1 
Stack 9
B_2 D_1 G_1 G_9 H_8 
Stack 10
H_4 B_6 D_2 A_3 B_5 
Stack 11
J_3 J_9 H_1 I_1 H_6 
Stack 12
D_10 D_11 F_12 D_12 A_2 
Stack 13
A_6 C_1 I_4 E_7 I_5 
Stack 14
B_8 C_7 G_4 D_4 E_12 
Stack 15
F_2 B_9 E_0 C_10 G_7 
Stack 16
H_7 F_9 C_5 F_3 I_2 
Stack 17
F_6 G_10 F_4 F_0 D_5 
Stack 18
I_9 B_3 J_4 G_12 C_2 
Stack 19
C_4 A_9 F_1 I_6 H_3 
Stack 20
D_0 F_10 H_5 A_4 A_5 
Stack 21
C_11 G_11 J_5 E_13 F_8 
Stack 22
G_6 E_10 F_13 A_1 G_3 
Stack 23
G_2 F_7 B_10 B_0 F_11 
