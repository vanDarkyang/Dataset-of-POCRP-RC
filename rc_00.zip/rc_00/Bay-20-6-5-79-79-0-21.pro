Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_9 C_0 D_3 E_7 
Stack 2
C_3 B_10 C_15 A_7 
Stack 3
E_8 C_4 B_11 E_3 
Stack 4
B_4 E_14 C_13 E_11 
Stack 5
D_14 B_2 E_13 B_7 
Stack 6
C_5 C_8 B_6 A_3 
Stack 7
A_5 A_14 B_15 D_8 
Stack 8
C_2 C_10 C_7 D_0 
Stack 9
D_1 E_12 C_11 C_16 
Stack 10
E_4 D_13 A_6 D_12 
Stack 11
D_11 E_6 E_0 D_10 
Stack 12
B_9 D_2 A_10 C_14 
Stack 13
A_4 C_1 A_1 E_10 
Stack 14
B_5 C_6 A_2 B_3 
Stack 15
D_6 B_1 C_9 D_9 
Stack 16
C_12 D_5 E_2 A_11 
Stack 17
B_13 A_8 B_8 B_14 
Stack 18
B_12 E_1 B_0 E_9 
Stack 19
A_0 E_5 A_13 A_12 
Stack 20
D_15 D_7 D_4 
