Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_5 J_1 M_2 A_0 H_2 N_3 
Stack 2
A_2 G_3 G_1 B_0 G_8 O_2 
Stack 3
K_1 H_8 H_1 H_0 D_1 D_0 
Stack 4
F_4 K_0 K_4 F_0 D_3 J_7 
Stack 5
H_3 L_0 J_2 J_3 I_7 
Stack 6
H_9 O_1 G_2 G_4 I_6 
Stack 7
K_6 I_3 A_1 B_2 M_4 
Stack 8
K_3 J_6 D_5 G_7 C_1 
Stack 9
E_5 F_3 E_6 F_7 G_6 
Stack 10
O_0 N_0 I_2 H_4 E_2 
Stack 11
M_0 D_2 H_7 J_0 E_0 
Stack 12
C_0 J_5 M_1 L_2 F_6 
Stack 13
K_2 B_1 K_5 I_4 L_4 
Stack 14
J_4 G_5 N_1 M_3 F_5 
Stack 15
L_1 N_2 F_1 C_2 F_2 
Stack 16
H_6 C_3 I_1 I_8 D_4 
Stack 17
E_4 L_5 B_3 C_4 I_0 
Stack 18
E_1 G_0 I_5 L_3 E_3 
