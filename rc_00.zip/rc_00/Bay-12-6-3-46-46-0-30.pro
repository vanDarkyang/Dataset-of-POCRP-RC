Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_4 B_1 C_6 C_0 
Stack 2
C_11 A_10 A_2 C_9 
Stack 3
C_2 A_4 B_15 B_2 
Stack 4
C_8 B_5 A_0 B_13 
Stack 5
A_3 C_13 B_7 B_6 
Stack 6
A_1 C_12 A_13 A_5 
Stack 7
C_3 C_7 C_14 A_7 
Stack 8
B_10 C_1 B_8 A_14 
Stack 9
A_11 B_11 B_12 B_9 
Stack 10
B_14 C_10 A_6 A_12 
Stack 11
C_5 C_4 A_8 
Stack 12
B_3 A_9 B_0 
