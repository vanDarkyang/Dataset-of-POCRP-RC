Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_9 D_9 B_6 B_14 
Stack 2
B_8 C_6 D_8 B_13 
Stack 3
E_5 E_13 C_13 E_2 
Stack 4
B_12 B_2 C_9 B_10 
Stack 5
A_3 D_1 A_1 C_8 
Stack 6
A_7 A_5 D_2 B_9 
Stack 7
A_6 C_10 A_12 E_7 
Stack 8
E_0 C_15 E_10 C_3 
Stack 9
A_14 D_15 D_4 E_3 
Stack 10
A_11 D_5 D_13 D_3 
Stack 11
E_8 D_12 B_5 C_16 
Stack 12
D_11 E_11 B_4 A_2 
Stack 13
C_11 B_11 D_0 B_1 
Stack 14
C_7 A_9 D_6 C_2 
Stack 15
C_5 D_14 C_1 B_7 
Stack 16
A_0 A_13 B_15 E_6 
Stack 17
E_1 C_0 C_14 C_4 
Stack 18
B_0 D_10 D_7 E_14 
Stack 19
A_4 E_12 A_10 C_12 
Stack 20
A_8 B_3 E_4 
