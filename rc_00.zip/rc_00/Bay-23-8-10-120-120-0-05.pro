Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_10 E_2 J_3 J_7 E_8 I_4 
Stack 2
I_0 E_6 B_6 C_8 G_3 H_11 
Stack 3
D_4 J_4 E_9 C_0 F_0 G_8 
Stack 4
D_1 D_8 A_3 C_10 J_5 H_8 
Stack 5
E_5 E_12 J_2 F_7 B_2 A_0 
Stack 6
E_7 B_9 C_7 C_5 F_1 
Stack 7
D_9 I_5 F_10 G_6 F_11 
Stack 8
F_13 G_11 E_1 I_7 H_3 
Stack 9
B_7 A_1 G_12 I_8 G_2 
Stack 10
B_1 J_8 F_8 B_5 B_8 
Stack 11
F_9 C_9 F_5 H_4 A_9 
Stack 12
H_2 D_0 D_7 G_1 H_9 
Stack 13
E_11 D_6 J_1 E_3 H_1 
Stack 14
F_4 J_0 G_5 G_0 I_9 
Stack 15
C_1 H_6 D_2 C_11 H_7 
Stack 16
G_4 E_10 D_11 C_2 A_7 
Stack 17
A_5 B_4 H_10 G_7 A_4 
Stack 18
G_9 F_2 J_9 A_8 B_3 
Stack 19
C_3 C_6 I_10 E_4 C_4 
Stack 20
H_0 I_1 F_12 D_10 D_5 
Stack 21
I_6 E_13 A_2 F_6 B_0 
Stack 22
H_5 I_3 D_3 D_12 I_2 
Stack 23
A_6 J_6 E_0 F_3 G_10 
