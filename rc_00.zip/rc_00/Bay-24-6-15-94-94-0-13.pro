Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
N_1 N_0 N_3 M_4 
Stack 2
F_3 D_0 K_1 A_1 
Stack 3
I_2 G_3 E_2 J_3 
Stack 4
E_5 I_5 E_0 C_3 
Stack 5
H_4 G_2 J_2 J_5 
Stack 6
B_2 C_0 O_1 H_8 
Stack 7
J_6 E_3 J_0 K_0 
Stack 8
C_2 I_8 D_1 F_0 
Stack 9
I_0 M_2 K_2 M_0 
Stack 10
D_5 H_2 D_3 C_4 
Stack 11
A_2 G_8 H_7 B_3 
Stack 12
B_1 L_5 A_0 G_4 
Stack 13
C_1 G_1 J_4 I_7 
Stack 14
M_1 H_5 J_1 K_3 
Stack 15
I_4 D_2 E_6 K_4 
Stack 16
G_7 F_7 I_6 G_6 
Stack 17
F_1 H_0 L_1 N_2 
Stack 18
H_6 D_4 H_3 O_0 
Stack 19
F_6 G_5 K_5 K_6 
Stack 20
E_1 L_3 J_7 O_2 
Stack 21
I_1 I_3 E_4 M_3 
Stack 22
G_0 F_4 H_9 F_5 
Stack 23
L_2 L_4 H_1 
Stack 24
F_2 B_0 L_0 
