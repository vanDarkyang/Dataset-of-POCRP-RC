Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_11 B_1 C_14 C_5 D_7 D_2 
Stack 2
A_11 C_6 B_9 A_14 E_9 D_0 
Stack 3
E_3 C_9 D_1 B_6 D_5 E_8 
Stack 4
B_8 C_7 C_4 E_0 A_1 D_10 
Stack 5
D_9 B_0 B_10 C_16 A_8 
Stack 6
E_13 B_14 B_3 D_15 C_2 
Stack 7
C_13 D_13 B_5 A_4 C_8 
Stack 8
D_4 B_2 B_15 A_6 E_2 
Stack 9
B_4 C_10 B_7 E_7 B_11 
Stack 10
E_1 E_6 A_5 B_12 A_2 
Stack 11
C_15 C_12 A_10 D_12 C_1 
Stack 12
A_7 C_3 D_11 D_6 A_12 
Stack 13
A_13 E_12 E_10 D_8 D_14 
Stack 14
A_0 E_4 A_9 E_5 C_0 
Stack 15
A_3 E_11 D_3 E_14 B_13 
