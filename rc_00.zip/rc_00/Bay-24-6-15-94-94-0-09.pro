Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
L_0 G_7 D_2 G_1 
Stack 2
N_2 L_3 B_1 K_6 
Stack 3
K_1 H_9 C_3 F_4 
Stack 4
I_6 M_4 E_3 A_1 
Stack 5
E_5 H_3 F_2 D_0 
Stack 6
G_4 C_2 I_8 O_1 
Stack 7
D_5 I_2 G_2 M_2 
Stack 8
F_6 F_7 B_3 M_3 
Stack 9
O_2 I_4 K_3 H_2 
Stack 10
D_4 N_3 L_5 J_0 
Stack 11
F_1 L_4 M_0 I_3 
Stack 12
O_0 G_5 F_0 H_7 
Stack 13
F_3 L_1 D_3 K_0 
Stack 14
D_1 C_4 J_3 I_1 
Stack 15
J_6 H_0 I_5 I_7 
Stack 16
G_0 E_1 G_3 A_0 
Stack 17
C_1 H_4 L_2 J_7 
Stack 18
K_2 J_2 A_2 H_6 
Stack 19
J_1 N_0 H_8 K_5 
Stack 20
E_0 B_0 M_1 E_2 
Stack 21
E_6 H_5 J_5 N_1 
Stack 22
J_4 F_5 G_6 E_4 
Stack 23
C_0 H_1 G_8 
Stack 24
B_2 K_4 I_0 
