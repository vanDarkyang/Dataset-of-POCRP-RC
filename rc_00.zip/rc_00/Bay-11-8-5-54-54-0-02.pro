Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
D_7 A_3 C_10 E_9 E_7 
Stack 2
B_3 D_1 A_9 B_10 E_6 
Stack 3
E_1 B_0 C_7 D_6 B_8 
Stack 4
A_6 D_8 A_5 E_2 E_4 
Stack 5
D_9 B_4 B_9 D_4 B_2 
Stack 6
D_0 A_2 A_0 A_1 D_3 
Stack 7
C_8 C_6 A_7 B_5 D_2 
Stack 8
C_2 B_1 C_9 C_4 B_7 
Stack 9
C_3 D_10 E_3 C_0 B_6 
Stack 10
A_8 C_1 A_4 E_5 E_8 
Stack 11
C_5 E_0 D_5 C_11 
