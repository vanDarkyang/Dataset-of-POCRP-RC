Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_1 F_2 F_0 I_2 
Stack 2
B_1 G_4 F_3 A_1 
Stack 3
B_2 J_0 C_3 F_4 
Stack 4
E_4 B_0 F_1 J_1 
Stack 5
D_2 H_3 C_2 A_0 
Stack 6
G_0 E_3 G_2 E_6 
Stack 7
J_2 I_0 I_3 I_1 
Stack 8
H_0 F_6 D_4 E_2 
Stack 9
E_5 H_1 D_1 E_0 
Stack 10
C_4 G_3 H_2 G_1 
Stack 11
B_3 D_0 C_0 D_3 
Stack 12
C_1 A_2 G_5 
Stack 13
F_5 H_4 D_5 
