Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
46
Number Of Shutout Containers
0
Yard Bay
Stack 1
B_1 A_0 B_11 A_3 
Stack 2
C_7 C_8 C_9 A_2 
Stack 3
B_5 C_12 C_3 A_13 
Stack 4
C_2 A_9 A_14 C_10 
Stack 5
C_13 C_6 A_1 B_2 
Stack 6
A_6 C_0 C_14 B_7 
Stack 7
B_10 B_6 B_9 B_13 
Stack 8
B_3 A_7 B_0 C_5 
Stack 9
A_10 A_11 A_8 B_8 
Stack 10
C_11 B_12 A_12 C_1 
Stack 11
B_15 C_4 A_5 
Stack 12
A_4 B_4 B_14 
