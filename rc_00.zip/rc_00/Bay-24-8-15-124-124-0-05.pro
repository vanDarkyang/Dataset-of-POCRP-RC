Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_9 L_0 H_1 J_3 K_3 M_4 
Stack 2
B_3 C_1 N_2 J_0 D_0 F_6 
Stack 3
E_3 H_11 H_8 N_3 K_1 E_6 
Stack 4
F_8 H_2 K_2 B_0 F_9 M_3 
Stack 5
G_5 D_5 O_3 O_1 L_3 
Stack 6
G_1 B_1 C_3 F_7 E_5 
Stack 7
G_8 K_7 M_1 N_5 I_8 
Stack 8
K_8 N_4 H_10 K_6 O_2 
Stack 9
C_6 D_1 I_5 G_4 I_2 
Stack 10
E_7 M_5 I_4 A_4 I_1 
Stack 11
G_9 J_8 D_2 I_6 I_0 
Stack 12
G_0 E_8 J_4 M_6 B_2 
Stack 13
C_5 G_10 L_7 B_4 G_7 
Stack 14
H_5 H_6 E_1 D_7 N_0 
Stack 15
F_2 F_0 F_1 C_0 J_6 
Stack 16
H_3 M_2 O_4 J_1 G_6 
Stack 17
A_1 J_9 O_0 K_4 D_4 
Stack 18
D_6 A_0 G_3 A_2 A_3 
Stack 19
F_5 H_0 E_2 L_5 I_10 
Stack 20
D_3 F_3 E_4 K_0 L_2 
Stack 21
J_2 H_7 I_9 E_0 L_6 
Stack 22
M_0 I_7 C_4 F_4 B_5 
Stack 23
L_1 N_1 J_7 G_2 I_3 
Stack 24
H_4 J_5 K_5 C_2 L_4 
