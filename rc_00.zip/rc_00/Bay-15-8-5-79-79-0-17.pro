Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_6 A_13 A_10 C_4 E_2 A_8 
Stack 2
C_8 D_9 E_12 C_10 E_5 D_12 
Stack 3
B_5 B_9 D_10 E_4 D_1 C_6 
Stack 4
C_1 B_3 C_11 C_12 B_11 C_14 
Stack 5
A_14 D_8 B_12 A_0 E_3 
Stack 6
B_14 C_9 E_13 E_14 A_2 
Stack 7
A_1 C_16 D_3 A_5 B_6 
Stack 8
B_4 E_10 D_13 B_2 C_13 
Stack 9
B_8 B_13 D_7 B_1 E_7 
Stack 10
E_9 D_5 A_7 B_7 E_6 
Stack 11
B_0 B_10 E_0 C_7 E_11 
Stack 12
D_14 E_8 D_6 D_4 A_4 
Stack 13
D_0 C_2 C_5 C_0 E_1 
Stack 14
D_2 C_15 A_11 D_11 A_3 
Stack 15
C_3 A_9 D_15 B_15 A_12 
