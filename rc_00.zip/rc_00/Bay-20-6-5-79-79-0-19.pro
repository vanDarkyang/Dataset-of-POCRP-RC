Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
79
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_12 E_1 A_7 E_0 
Stack 2
E_9 C_11 C_0 E_3 
Stack 3
C_15 B_9 A_9 E_4 
Stack 4
E_12 C_7 B_6 D_0 
Stack 5
A_14 C_1 B_4 E_14 
Stack 6
C_5 C_3 D_8 C_4 
Stack 7
A_8 B_11 E_10 B_2 
Stack 8
D_7 D_9 C_10 A_1 
Stack 9
E_8 C_16 E_11 B_12 
Stack 10
B_3 E_2 A_6 A_3 
Stack 11
A_13 A_10 D_12 B_14 
Stack 12
D_4 D_3 C_9 B_8 
Stack 13
E_7 D_2 B_1 D_10 
Stack 14
A_2 D_13 A_11 C_6 
Stack 15
B_0 A_5 B_15 D_1 
Stack 16
E_13 D_14 B_10 C_8 
Stack 17
A_4 A_0 E_6 B_7 
Stack 18
D_5 B_13 C_13 D_15 
Stack 19
C_14 C_12 D_6 E_5 
Stack 20
B_5 C_2 D_11 
