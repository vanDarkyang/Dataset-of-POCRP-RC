Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_4 G_4 D_3 B_1 
Stack 2
F_3 E_1 I_3 I_1 
Stack 3
J_1 G_1 G_0 C_0 
Stack 4
I_0 A_1 C_2 D_5 
Stack 5
C_3 G_2 F_1 H_2 
Stack 6
F_0 E_4 J_2 J_0 
Stack 7
A_2 B_0 E_3 I_2 
Stack 8
C_1 B_2 E_6 D_1 
Stack 9
G_3 F_2 F_5 C_4 
Stack 10
H_3 H_0 G_5 E_2 
Stack 11
D_0 F_6 A_0 H_4 
Stack 12
H_1 D_4 E_0 
Stack 13
D_2 B_3 E_5 
