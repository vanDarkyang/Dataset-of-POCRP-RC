Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
H_4 J_7 H_9 E_0 
Stack 2
G_4 N_3 F_2 J_4 
Stack 3
J_2 K_3 L_5 H_8 
Stack 4
C_0 M_0 H_2 F_1 
Stack 5
N_1 N_0 I_7 C_2 
Stack 6
E_5 I_3 G_1 L_0 
Stack 7
I_2 I_5 F_7 E_6 
Stack 8
D_3 O_0 A_1 O_2 
Stack 9
J_3 K_4 A_2 G_8 
Stack 10
F_3 F_4 G_3 E_3 
Stack 11
K_1 C_3 K_6 E_1 
Stack 12
D_2 B_0 J_0 K_0 
Stack 13
O_1 F_0 I_6 N_2 
Stack 14
M_4 H_6 G_0 E_2 
Stack 15
F_5 A_0 J_5 G_5 
Stack 16
D_4 L_4 M_1 F_6 
Stack 17
B_1 D_5 I_0 H_7 
Stack 18
H_0 J_6 C_1 G_6 
Stack 19
C_4 I_8 K_5 G_7 
Stack 20
L_1 G_2 E_4 L_3 
Stack 21
B_3 B_2 K_2 M_2 
Stack 22
D_0 H_5 J_1 L_2 
Stack 23
I_1 M_3 H_1 
Stack 24
I_4 D_1 H_3 
