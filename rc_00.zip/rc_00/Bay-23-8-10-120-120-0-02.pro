Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
120
Number Of Shutout Containers
0
Yard Bay
Stack 1
E_6 E_5 H_6 F_3 F_11 I_6 
Stack 2
B_7 H_11 C_0 C_6 H_2 I_3 
Stack 3
J_0 J_8 E_4 A_0 D_11 A_6 
Stack 4
G_3 I_7 A_8 H_8 C_8 D_10 
Stack 5
I_9 H_4 G_8 F_7 I_8 E_8 
Stack 6
G_1 F_0 C_1 I_1 C_7 
Stack 7
G_4 D_6 H_10 B_3 I_5 
Stack 8
E_1 B_2 A_3 H_3 D_4 
Stack 9
D_5 E_11 F_12 G_0 D_1 
Stack 10
D_7 J_2 H_1 G_9 D_9 
Stack 11
H_7 D_2 E_7 J_7 G_2 
Stack 12
B_4 B_5 C_10 G_7 B_1 
Stack 13
E_0 F_1 I_0 D_0 B_9 
Stack 14
G_6 E_12 B_10 E_13 D_3 
Stack 15
B_6 J_5 D_12 I_10 D_8 
Stack 16
A_4 B_0 I_4 A_9 J_6 
Stack 17
E_9 F_13 E_10 G_5 G_10 
Stack 18
C_4 E_2 F_9 A_1 C_11 
Stack 19
F_8 A_5 G_12 F_10 J_3 
Stack 20
A_2 E_3 H_5 C_5 F_4 
Stack 21
C_3 B_8 G_11 F_2 J_9 
Stack 22
A_7 H_0 F_6 F_5 J_4 
Stack 23
J_1 C_9 C_2 H_9 I_2 
