Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
70
Number Of Shutout Containers
0
Yard Bay
Stack 1
J_4 F_8 H_3 A_1 H_6 
Stack 2
C_4 F_0 G_5 D_4 H_1 
Stack 3
H_5 A_0 D_0 E_3 G_6 
Stack 4
G_7 H_0 C_2 C_3 B_2 
Stack 5
C_5 F_6 G_4 H_2 E_4 
Stack 6
E_5 B_0 J_3 G_3 F_4 
Stack 7
A_2 D_6 E_1 A_4 E_2 
Stack 8
E_7 G_2 B_1 E_8 D_1 
Stack 9
C_0 F_2 B_5 D_3 J_2 
Stack 10
I_4 F_3 E_6 J_1 F_5 
Stack 11
C_6 F_1 I_5 D_7 E_0 
Stack 12
C_1 G_0 I_1 F_7 B_4 
Stack 13
J_0 B_3 A_3 I_3 I_0 
Stack 14
D_5 I_2 G_1 H_4 D_2 
