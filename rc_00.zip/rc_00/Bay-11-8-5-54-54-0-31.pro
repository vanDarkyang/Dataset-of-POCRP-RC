Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_1 C_1 D_3 B_7 D_10 
Stack 2
E_1 A_6 D_4 D_1 E_6 
Stack 3
A_3 C_7 C_2 A_2 D_5 
Stack 4
C_5 E_0 B_5 B_0 A_4 
Stack 5
C_4 A_5 B_10 C_3 D_8 
Stack 6
E_7 C_8 A_9 E_3 A_0 
Stack 7
B_2 A_8 E_8 C_0 B_3 
Stack 8
B_1 E_2 D_2 D_9 E_5 
Stack 9
C_11 A_7 C_10 B_6 C_6 
Stack 10
B_8 B_9 B_4 C_9 D_7 
Stack 11
E_9 D_6 E_4 D_0 
