Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
94
Number Of Shutout Containers
0
Yard Bay
Stack 1
F_3 G_3 I_1 F_4 K_3 N_2 
Stack 2
A_1 L_3 F_0 K_1 L_1 N_1 
Stack 3
E_0 F_7 I_5 C_0 G_1 H_2 
Stack 4
I_8 K_5 G_5 O_0 H_6 E_6 
Stack 5
N_0 G_2 L_2 E_2 L_4 
Stack 6
F_1 C_2 I_3 H_9 H_0 
Stack 7
C_1 L_0 E_3 B_3 J_0 
Stack 8
D_4 H_4 J_3 B_2 F_6 
Stack 9
J_6 J_5 E_1 J_2 F_5 
Stack 10
H_7 H_1 D_1 A_2 D_2 
Stack 11
J_7 L_5 G_7 B_0 F_2 
Stack 12
H_5 E_4 I_7 G_4 A_0 
Stack 13
J_4 H_3 K_4 C_3 I_0 
Stack 14
G_6 B_1 I_6 D_5 K_0 
Stack 15
M_0 D_3 H_8 M_2 M_1 
Stack 16
C_4 O_2 I_2 J_1 K_2 
Stack 17
D_0 O_1 E_5 K_6 M_4 
Stack 18
I_4 G_0 G_8 M_3 N_3 
