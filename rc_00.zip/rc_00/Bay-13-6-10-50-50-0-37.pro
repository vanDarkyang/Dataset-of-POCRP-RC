Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
50
Number Of Shutout Containers
0
Yard Bay
Stack 1
A_0 C_3 H_4 G_1 
Stack 2
H_2 F_1 H_0 F_5 
Stack 3
D_2 D_3 G_5 A_2 
Stack 4
D_4 E_6 E_3 F_3 
Stack 5
I_1 C_1 J_2 B_1 
Stack 6
E_4 I_0 F_2 E_0 
Stack 7
F_6 G_3 F_4 D_1 
Stack 8
I_3 G_4 F_0 J_1 
Stack 9
H_3 G_0 C_4 I_2 
Stack 10
E_5 B_2 G_2 J_0 
Stack 11
E_1 A_1 H_1 E_2 
Stack 12
D_0 B_0 D_5 
Stack 13
C_2 C_0 B_3 
