Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
54
Number Of Shutout Containers
0
Yard Bay
Stack 1
C_0 A_9 B_9 B_10 
Stack 2
D_9 E_5 D_5 A_0 
Stack 3
A_1 D_2 A_5 E_7 
Stack 4
B_3 B_0 A_2 E_9 
Stack 5
E_3 C_8 E_6 E_2 
Stack 6
B_5 E_1 D_8 B_8 
Stack 7
C_3 C_9 C_5 C_7 
Stack 8
E_0 E_4 D_0 A_7 
Stack 9
B_7 B_6 E_8 C_11 
Stack 10
B_1 C_1 D_3 C_4 
Stack 11
A_6 B_2 A_3 D_6 
Stack 12
A_8 A_4 C_10 D_7 
Stack 13
D_10 B_4 D_1 
Stack 14
C_2 D_4 C_6 
