Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
124
Number Of Shutout Containers
0
Yard Bay
Stack 1
G_0 L_4 C_0 F_8 K_0 J_8 
Stack 2
L_1 F_3 F_2 H_3 G_6 G_9 
Stack 3
B_0 C_5 O_2 C_4 M_3 N_5 
Stack 4
O_3 G_5 G_7 J_5 D_0 L_0 
Stack 5
E_6 A_2 B_3 J_6 O_1 
Stack 6
B_5 A_1 F_9 E_2 J_9 
Stack 7
I_9 I_2 G_10 N_3 F_5 
Stack 8
D_2 G_3 H_4 E_3 C_1 
Stack 9
A_0 F_4 I_7 H_9 I_4 
Stack 10
H_1 L_6 H_5 I_1 A_3 
Stack 11
K_2 M_2 I_0 N_0 D_3 
Stack 12
E_0 K_1 K_6 O_4 L_5 
Stack 13
E_4 I_3 E_5 J_3 F_6 
Stack 14
F_7 M_0 I_8 G_4 B_4 
Stack 15
C_6 I_10 G_1 M_4 H_6 
Stack 16
D_4 K_8 H_10 H_11 F_0 
Stack 17
D_7 K_4 M_6 N_1 E_7 
Stack 18
C_3 G_2 J_2 N_4 L_3 
Stack 19
K_7 H_0 K_3 C_2 J_4 
Stack 20
B_1 F_1 E_8 G_8 M_5 
Stack 21
I_6 J_7 D_5 J_0 D_6 
Stack 22
H_7 L_2 A_4 O_0 J_1 
Stack 23
B_2 I_5 K_5 D_1 L_7 
Stack 24
M_1 E_1 N_2 H_2 H_8 
