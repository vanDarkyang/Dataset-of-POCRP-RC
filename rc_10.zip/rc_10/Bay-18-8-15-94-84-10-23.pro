Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
L_0 M_3 K_3 E_3 G_6 G_5 
Stack 1
K_5 I_0 H_3 E_5 G_8 B_2 
Stack 2
A_1 B_1 I_3 J_1 Z_100 M_1 
Stack 3
C_3 K_2 H_5 H_4 D_4 F_5 
Stack 4
L_3 Z_101 I_1 Z_102 N_2 
Stack 5
E_2 G_0 M_0 H_2 Z_103 
Stack 6
H_0 C_2 A_2 B_3 G_7 
Stack 7
H_6 J_3 N_1 I_5 O_0 
Stack 8
F_3 C_1 J_4 E_1 E_4 
Stack 9
E_0 L_4 K_0 G_1 G_3 
Stack 10
D_2 F_1 G_2 H_1 I_4 
Stack 11
J_2 F_4 B_0 D_5 H_7 
Stack 12
N_3 Z_104 J_6 Z_105 D_1 
Stack 13
I_2 D_3 Z_106 M_2 N_0 
Stack 14
F_2 Z_107 K_4 L_2 A_0 
Stack 15
Z_108 L_5 L_1 I_6 M_4 
Stack 16
Z_109 G_4 F_6 K_1 D_0 
Stack 17
J_5 C_0 F_0 O_1 J_0 
