Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_6 C_4 C_2 J_4 C_1 
Stack 1
B_2 I_4 G_3 B_0 E_5 
Stack 2
Z_100 F_8 I_0 F_2 E_4 
Stack 3
Z_101 D_7 E_2 D_5 F_1 
Stack 4
J_3 F_3 A_2 D_1 Z_102 
Stack 5
A_0 J_2 Z_103 A_1 H_3 
Stack 6
D_0 B_3 I_5 D_4 C_0 
Stack 7
E_0 D_3 F_7 C_3 Z_104 
Stack 8
F_5 G_5 A_3 Z_105 E_3 
Stack 9
E_6 G_6 I_3 F_0 Z_106 
Stack 10
H_0 E_1 B_4 H_1 G_4 
Stack 11
F_6 A_4 J_1 G_2 I_1 
Stack 12
J_0 H_2 F_4 H_4 C_5 
Stack 13
B_1 G_0 I_2 D_2 G_1 
