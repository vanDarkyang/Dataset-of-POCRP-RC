Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
C_0 H_7 E_11 F_0 D_1 B_2 
Stack 1
D_11 J_8 C_5 I_9 J_6 E_12 
Stack 2
E_2 Z_100 F_5 H_4 I_4 D_5 
Stack 3
I_0 I_5 J_3 Z_101 D_0 G_9 
Stack 4
B_7 Z_102 I_2 H_6 F_4 I_3 
Stack 5
D_12 E_8 G_8 A_7 H_5 
Stack 6
H_2 J_2 A_1 C_8 D_10 
Stack 7
F_12 B_5 D_2 G_1 I_7 
Stack 8
G_7 C_7 Z_103 F_2 Z_104 
Stack 9
C_1 G_4 E_1 Z_105 C_4 
Stack 10
D_8 J_7 H_8 F_8 J_4 
Stack 11
F_9 F_3 F_6 E_4 B_8 
Stack 12
E_5 E_9 B_6 B_3 C_9 
Stack 13
I_6 H_10 G_5 I_1 A_2 
Stack 14
F_1 D_6 A_4 G_6 A_0 
Stack 15
F_7 Z_106 E_0 E_7 E_10 
Stack 16
B_1 Z_107 C_2 J_5 H_0 
Stack 17
D_3 C_3 A_6 D_4 D_9 
Stack 18
B_0 G_0 G_2 I_8 Z_108 
Stack 19
H_1 Z_109 F_11 H_3 A_3 
Stack 20
Z_110 J_1 E_6 Z_111 F_10 
Stack 21
C_6 B_9 H_9 A_5 G_3 
Stack 22
E_3 B_4 J_0 J_9 D_7 
