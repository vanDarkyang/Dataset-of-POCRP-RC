Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_0 B_5 B_0 D_7 C_0 
Stack 1
A_8 A_4 C_9 B_2 A_1 
Stack 2
A_2 B_7 C_5 C_7 C_6 
Stack 3
C_3 D_4 Z_100 B_6 D_3 
Stack 4
E_5 C_4 D_2 E_6 B_3 
Stack 5
D_1 A_6 C_1 A_5 Z_101 
Stack 6
A_7 Z_102 D_10 E_7 D_6 
Stack 7
Z_103 B_1 B_4 D_5 D_9 
Stack 8
E_2 D_0 B_8 C_2 E_8 
Stack 9
C_8 E_3 E_4 E_1 D_8 
Stack 10
A_3 A_0 Z_104 Z_105 
