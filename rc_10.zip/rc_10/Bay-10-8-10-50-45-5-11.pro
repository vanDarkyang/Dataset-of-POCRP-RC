Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_4 E_0 H_0 C_3 E_5 
Stack 1
E_2 J_1 Z_100 J_2 G_2 
Stack 2
C_1 D_1 I_1 I_3 C_0 
Stack 3
G_4 E_3 G_0 J_0 I_0 
Stack 4
B_1 D_0 F_0 G_3 B_3 
Stack 5
Z_101 Z_102 Z_103 A_2 D_4 
Stack 6
D_2 G_5 F_3 E_1 H_3 
Stack 7
F_2 F_1 H_2 Z_104 I_2 
Stack 8
D_3 H_1 G_1 C_2 A_0 
Stack 9
F_5 B_0 A_1 F_4 B_2 
