Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_6 B_5 A_7 B_11 
Stack 1
B_2 B_7 B_8 B_10 
Stack 2
C_2 B_3 C_8 A_1 
Stack 3
A_9 B_1 A_8 C_0 
Stack 4
C_4 B_0 C_9 C_6 
Stack 5
C_12 C_7 C_3 C_10 
Stack 6
B_9 Z_100 B_4 C_11 
Stack 7
A_2 B_6 A_4 A_12 
Stack 8
B_13 Z_101 C_13 Z_102 
Stack 9
A_10 Z_103 C_5 C_1 
Stack 10
Z_104 A_3 B_12 
Stack 11
A_11 A_0 A_5 
