Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_6 G_6 B_1 Z_100 L_1 K_1 
Stack 1
F_5 C_3 D_4 H_1 N_0 D_0 
Stack 2
B_0 E_3 C_1 H_4 D_3 I_1 
Stack 3
Z_101 L_5 Z_102 L_3 I_5 E_4 
Stack 4
M_2 N_3 C_0 K_2 H_0 
Stack 5
L_2 Z_103 M_0 J_6 I_4 
Stack 6
M_4 J_0 Z_104 G_2 G_5 
Stack 7
I_6 H_5 I_3 G_4 E_0 
Stack 8
H_7 F_7 Z_105 F_4 D_2 
Stack 9
G_3 G_1 M_3 K_3 D_1 
Stack 10
F_0 F_1 O_0 O_1 J_4 
Stack 11
I_0 A_2 G_0 E_2 H_6 
Stack 12
F_2 C_4 H_2 K_0 J_3 
Stack 13
G_7 J_5 B_3 B_2 L_4 
Stack 14
Z_106 H_3 H_8 M_1 Z_107 
Stack 15
C_2 F_3 K_4 A_0 J_1 
Stack 16
N_1 N_2 E_1 Z_108 Z_109 
Stack 17
A_1 J_2 I_2 L_0 K_5 
