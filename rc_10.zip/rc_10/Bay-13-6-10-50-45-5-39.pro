Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_1 F_1 Z_100 I_2 
Stack 1
B_1 G_2 F_2 A_1 
Stack 2
B_2 J_0 C_3 F_3 
Stack 3
E_4 B_0 F_0 J_1 
Stack 4
D_1 H_3 C_2 A_0 
Stack 5
Z_101 E_3 G_0 E_6 
Stack 6
J_2 I_0 I_3 I_1 
Stack 7
H_0 F_4 D_3 E_2 
Stack 8
E_5 H_1 Z_102 E_0 
Stack 9
C_4 G_1 H_2 Z_103 
Stack 10
B_3 D_0 C_0 D_2 
Stack 11
C_1 A_2 G_3 
Stack 12
Z_104 H_4 D_4 
