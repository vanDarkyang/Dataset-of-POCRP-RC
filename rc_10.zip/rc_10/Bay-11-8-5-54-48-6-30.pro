Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
Z_100 A_4 Z_101 D_2 E_4 
Stack 1
A_3 B_1 D_5 D_1 B_2 
Stack 2
C_8 A_5 B_5 E_6 D_3 
Stack 3
D_6 B_0 C_0 B_4 A_2 
Stack 4
B_7 Z_102 C_5 C_2 D_9 
Stack 5
A_1 A_0 Z_103 A_7 A_9 
Stack 6
E_2 E_0 C_9 D_8 C_3 
Stack 7
C_4 B_8 D_7 C_6 Z_104 
Stack 8
Z_105 B_6 C_7 D_4 D_0 
Stack 9
E_5 E_1 A_8 E_7 E_8 
Stack 10
B_3 A_6 C_1 E_3 
