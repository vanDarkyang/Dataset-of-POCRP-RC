Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_2 G_5 M_3 G_0 L_3 F_7 
Stack 1
I_4 M_1 Z_100 K_4 Z_101 O_2 
Stack 2
J_2 G_4 N_3 J_3 L_1 M_4 
Stack 3
E_4 L_0 J_1 F_4 H_3 A_0 
Stack 4
K_5 G_1 C_3 G_3 Z_102 
Stack 5
E_0 E_1 Z_103 H_6 K_3 
Stack 6
G_8 F_0 K_2 J_7 D_0 
Stack 7
J_6 Z_104 I_0 C_0 Z_105 
Stack 8
D_1 L_2 A_1 I_3 Z_106 
Stack 9
J_0 H_0 J_4 D_2 F_2 
Stack 10
K_6 I_1 K_1 O_1 N_2 
Stack 11
O_0 K_0 F_6 Z_107 F_3 
Stack 12
H_7 M_0 F_5 H_5 H_4 
Stack 13
Z_108 E_5 Z_109 J_5 H_2 
Stack 14
B_0 I_5 M_2 L_4 E_3 
Stack 15
E_2 B_1 F_1 G_7 I_2 
Stack 16
H_1 C_1 N_1 N_0 B_2 
Stack 17
G_6 D_3 L_5 G_2 A_2 
