Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
G_8 E_2 C_2 D_1 
Stack 1
G_3 Z_100 E_5 Z_101 
Stack 2
Z_102 G_7 C_3 Z_103 
Stack 3
E_4 I_1 D_2 D_3 
Stack 4
G_1 J_3 M_4 L_0 
Stack 5
L_3 M_2 A_1 J_2 
Stack 6
I_2 I_3 D_4 O_1 
Stack 7
H_9 L_2 F_0 G_0 
Stack 8
G_6 Z_104 H_5 M_0 
Stack 9
D_0 L_1 N_1 J_1 
Stack 10
A_2 K_3 A_0 O_0 
Stack 11
H_2 F_4 K_0 H_3 
Stack 12
L_5 E_0 I_4 M_1 
Stack 13
G_5 Z_105 G_4 F_3 
Stack 14
H_7 L_4 E_3 F_6 
Stack 15
F_2 B_2 I_6 C_0 
Stack 16
K_4 M_3 K_1 Z_106 
Stack 17
C_1 B_0 J_4 N_0 
Stack 18
I_7 F_1 Z_107 H_4 
Stack 19
H_0 H_1 D_5 E_1 
Stack 20
H_6 I_5 I_0 J_0 
Stack 21
N_3 E_6 H_8 N_2 
Stack 22
K_2 F_5 Z_108 
Stack 23
G_2 B_1 Z_109 
