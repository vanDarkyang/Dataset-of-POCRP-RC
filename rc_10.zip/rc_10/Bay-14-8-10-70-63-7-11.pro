Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
J_0 C_4 Z_100 Z_101 F_8 
Stack 1
E_2 G_4 E_7 F_5 A_4 
Stack 2
C_2 J_2 Z_102 C_3 G_3 
Stack 3
F_2 A_3 H_1 D_4 E_3 
Stack 4
C_1 Z_103 A_1 I_0 B_1 
Stack 5
H_4 E_4 H_5 H_2 H_6 
Stack 6
Z_104 A_2 B_0 D_2 F_6 
Stack 7
C_5 D_5 B_2 B_3 Z_105 
Stack 8
J_1 D_3 G_1 F_7 I_5 
Stack 9
G_2 F_1 E_0 D_0 D_1 
Stack 10
B_4 F_0 F_4 E_6 H_3 
Stack 11
B_5 E_1 I_1 C_0 A_0 
Stack 12
G_0 E_5 F_3 I_3 I_2 
Stack 13
Z_106 I_4 G_5 J_3 H_0 
