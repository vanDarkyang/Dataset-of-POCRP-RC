Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
G_2 Z_100 I_1 E_5 E_11 B_7 
Stack 1
C_8 G_5 H_8 Z_101 F_6 Z_102 
Stack 2
Z_103 Z_104 G_3 D_6 G_7 G_1 
Stack 3
G_9 D_9 C_2 H_2 Z_105 Z_106 
Stack 4
A_2 A_1 I_6 B_1 G_0 A_5 
Stack 5
C_1 B_9 F_7 B_5 I_7 
Stack 6
J_9 G_10 B_8 J_2 B_6 
Stack 7
I_4 F_10 G_8 H_5 H_7 
Stack 8
E_7 C_7 I_5 H_3 H_10 
Stack 9
B_4 H_1 D_7 J_0 Z_107 
Stack 10
F_4 E_12 F_0 E_10 J_3 
Stack 11
Z_108 I_2 C_4 H_6 D_4 
Stack 12
E_0 E_1 A_3 H_9 A_4 
Stack 13
E_8 I_0 J_4 F_2 C_6 
Stack 14
D_8 E_3 I_3 C_5 G_6 
Stack 15
D_1 Z_109 B_2 D_5 I_9 
Stack 16
J_6 I_8 D_2 C_11 D_3 
Stack 17
A_0 J_7 C_9 E_2 G_11 
Stack 18
F_12 D_0 F_5 F_8 B_3 
Stack 19
H_0 B_0 C_10 G_4 E_9 
Stack 20
E_6 A_6 C_3 Z_110 E_4 
Stack 21
J_5 J_8 F_11 F_9 F_3 
Stack 22
J_1 H_4 C_0 F_1 Z_111 
