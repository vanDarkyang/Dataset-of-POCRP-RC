Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
K_4 F_8 H_9 M_5 N_1 C_6 
Stack 1
Z_100 I_5 C_0 H_3 I_6 L_4 
Stack 2
J_3 M_1 D_5 C_1 Z_101 N_2 
Stack 3
J_6 I_3 G_1 G_8 I_8 Z_102 
Stack 4
F_2 G_6 Z_103 L_6 D_1 
Stack 5
O_4 K_1 D_0 H_0 D_2 
Stack 6
E_5 M_4 G_9 Z_104 B_1 
Stack 7
I_4 J_0 C_2 M_0 F_7 
Stack 8
C_3 H_6 Z_105 O_0 K_5 
Stack 9
E_4 G_7 E_6 N_3 F_5 
Stack 10
B_0 M_3 E_8 L_0 Z_106 
Stack 11
N_0 I_0 H_2 E_2 K_6 
Stack 12
O_1 Z_107 D_6 D_4 E_0 
Stack 13
G_0 Z_108 C_5 A_0 B_4 
Stack 14
H_1 L_5 H_8 L_2 O_2 
Stack 15
D_3 H_5 B_5 Z_109 K_0 
Stack 16
I_1 G_5 E_3 E_7 M_2 
Stack 17
G_2 E_1 K_2 F_3 H_7 
Stack 18
Z_110 G_4 F_0 O_3 F_1 
Stack 19
N_4 Z_111 H_4 A_2 B_2 
Stack 20
G_3 J_1 H_10 I_2 B_3 
Stack 21
J_4 L_3 G_10 F_6 N_5 
Stack 22
C_4 I_7 J_7 K_3 Z_112 
Stack 23
J_5 J_2 F_4 A_1 L_1 
