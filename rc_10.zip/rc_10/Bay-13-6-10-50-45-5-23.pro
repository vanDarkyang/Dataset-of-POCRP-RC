Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
Z_100 F_1 J_0 F_4 
Stack 1
H_1 Z_101 C_1 E_1 
Stack 2
F_5 G_0 G_5 F_3 
Stack 3
E_0 F_0 E_2 J_1 
Stack 4
B_3 I_0 G_4 E_4 
Stack 5
G_1 B_1 D_2 D_3 
Stack 6
D_1 B_0 G_2 I_1 
Stack 7
A_0 C_0 I_2 Z_102 
Stack 8
C_4 D_0 H_3 H_0 
Stack 9
D_4 E_3 I_3 G_3 
Stack 10
F_2 B_2 E_5 C_3 
Stack 11
A_1 A_2 H_2 
Stack 12
Z_103 Z_104 C_2 
