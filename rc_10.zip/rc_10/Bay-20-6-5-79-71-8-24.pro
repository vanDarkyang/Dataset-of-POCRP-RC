Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_14 E_0 C_1 C_15 
Stack 1
C_6 D_7 B_2 Z_100 
Stack 2
A_4 D_9 A_7 A_11 
Stack 3
D_5 B_7 B_11 D_3 
Stack 4
C_7 C_9 D_1 D_8 
Stack 5
E_4 C_5 Z_101 A_0 
Stack 6
B_12 A_1 C_12 D_11 
Stack 7
E_2 Z_102 C_0 C_11 
Stack 8
A_9 B_13 A_5 E_6 
Stack 9
D_4 B_1 A_10 A_2 
Stack 10
B_8 C_8 B_5 E_12 
Stack 11
B_4 E_5 C_4 E_9 
Stack 12
A_6 B_9 D_13 B_3 
Stack 13
C_13 D_6 E_1 Z_103 
Stack 14
E_11 Z_104 B_0 A_8 
Stack 15
E_3 C_3 A_12 E_13 
Stack 16
C_2 A_3 D_12 E_7 
Stack 17
B_10 B_6 E_10 C_10 
Stack 18
E_8 Z_105 Z_106 D_10 
Stack 19
D_2 Z_107 D_0 
