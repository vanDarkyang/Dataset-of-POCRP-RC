Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
D_9 E_4 C_2 E_13 
Stack 1
D_5 Z_100 E_12 A_10 
Stack 2
C_8 B_2 B_13 E_7 
Stack 3
A_0 A_1 C_6 C_5 
Stack 4
C_13 E_8 A_4 B_11 
Stack 5
A_5 Z_101 A_7 E_5 
Stack 6
E_10 D_1 D_3 E_11 
Stack 7
C_11 A_9 Z_102 B_0 
Stack 8
C_10 C_12 C_1 C_14 
Stack 9
B_1 A_6 Z_103 E_1 
Stack 10
Z_104 C_9 B_8 A_2 
Stack 11
Z_105 B_5 E_9 E_3 
Stack 12
C_0 D_4 A_11 B_3 
Stack 13
C_15 B_12 A_8 A_3 
Stack 14
D_10 B_7 E_2 D_2 
Stack 15
D_11 Z_106 E_0 E_14 
Stack 16
D_0 A_12 C_3 C_7 
Stack 17
D_6 B_10 C_4 B_9 
Stack 18
B_6 E_6 D_12 D_7 
Stack 19
Z_107 D_8 B_4 
