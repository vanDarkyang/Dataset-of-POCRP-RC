Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
D_2 G_9 I_8 D_6 J_1 E_3 
Stack 1
E_1 I_5 Z_100 F_10 C_7 J_8 
Stack 2
Z_101 G_3 F_5 B_2 F_0 I_4 
Stack 3
D_3 Z_102 B_0 C_5 J_2 G_10 
Stack 4
Z_103 E_8 G_4 H_11 B_4 D_12 
Stack 5
Z_104 Z_105 B_1 J_6 C_9 
Stack 6
H_5 J_0 Z_106 F_4 H_4 
Stack 7
D_8 Z_107 H_7 D_11 H_6 
Stack 8
Z_108 G_7 J_5 E_6 J_7 
Stack 9
B_7 D_10 A_6 A_4 H_2 
Stack 10
A_3 A_0 H_8 E_10 A_2 
Stack 11
Z_109 G_1 H_9 E_4 I_7 
Stack 12
I_6 D_4 C_10 G_6 C_4 
Stack 13
E_0 I_3 D_1 F_3 G_0 
Stack 14
J_3 D_7 H_1 J_4 B_5 
Stack 15
G_8 F_8 G_2 I_0 D_0 
Stack 16
Z_110 D_5 C_2 F_1 H_3 
Stack 17
C_1 D_9 F_11 C_8 E_7 
Stack 18
E_5 F_2 B_8 C_6 B_3 
Stack 19
E_9 E_12 I_2 H_10 A_5 
Stack 20
A_1 C_0 E_2 A_7 F_7 
Stack 21
F_12 Z_111 I_1 F_6 B_6 
Stack 22
G_5 C_3 F_9 E_11 H_0 
