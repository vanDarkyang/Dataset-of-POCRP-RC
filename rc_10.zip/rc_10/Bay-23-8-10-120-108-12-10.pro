Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
I_2 H_2 F_1 A_5 E_5 E_7 
Stack 1
D_3 Z_100 Z_101 F_3 J_4 H_8 
Stack 2
E_2 C_8 G_1 Z_102 I_3 H_5 
Stack 3
H_0 C_4 A_2 H_1 Z_103 J_6 
Stack 4
J_8 D_6 Z_104 Z_105 E_12 I_9 
Stack 5
C_1 E_0 I_0 I_10 A_7 
Stack 6
E_8 Z_106 D_5 I_8 Z_107 
Stack 7
E_3 J_7 C_5 F_10 D_8 
Stack 8
F_4 F_7 A_4 G_6 B_3 
Stack 9
Z_108 D_1 I_4 A_3 D_0 
Stack 10
F_12 D_11 B_0 G_9 A_1 
Stack 11
A_0 A_6 F_2 I_5 E_9 
Stack 12
D_10 F_6 F_0 G_2 J_3 
Stack 13
D_2 H_6 G_5 G_8 I_7 
Stack 14
F_8 J_0 H_9 C_10 B_2 
Stack 15
Z_109 B_4 F_9 C_3 G_4 
Stack 16
E_11 E_6 G_7 B_5 J_1 
Stack 17
H_4 G_3 B_6 E_1 E_4 
Stack 18
E_10 B_9 C_9 C_6 C_2 
Stack 19
F_5 J_5 D_9 J_2 C_0 
Stack 20
D_7 F_11 Z_110 Z_111 B_7 
Stack 21
H_7 G_0 B_1 I_6 H_3 
Stack 22
C_7 B_8 G_10 I_1 D_4 
