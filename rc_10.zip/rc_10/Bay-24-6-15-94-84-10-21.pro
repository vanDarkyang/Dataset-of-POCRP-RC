Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_2 F_0 F_4 L_3 
Stack 1
I_6 H_5 D_0 I_8 
Stack 2
J_2 L_2 M_1 L_1 
Stack 3
E_4 H_1 F_1 H_4 
Stack 4
K_5 I_1 N_1 D_1 
Stack 5
E_0 K_0 L_5 K_3 
Stack 6
G_8 M_0 G_0 Z_100 
Stack 7
J_6 E_5 K_4 E_1 
Stack 8
Z_101 I_7 J_3 I_5 
Stack 9
J_0 Z_102 F_3 Z_103 
Stack 10
K_6 C_1 G_3 N_2 
Stack 11
O_0 Z_104 H_8 F_2 
Stack 12
H_9 M_2 J_7 H_6 
Stack 13
H_0 I_3 C_0 H_3 
Stack 14
B_0 N_3 I_4 Z_105 
Stack 15
E_3 J_1 Z_106 I_2 
Stack 16
H_2 C_3 O_1 B_1 
Stack 17
G_6 Z_107 Z_108 A_2 
Stack 18
G_5 K_2 H_7 F_6 
Stack 19
Z_109 I_0 J_5 O_2 
Stack 20
G_4 A_1 L_4 M_3 
Stack 21
L_0 J_4 G_7 A_0 
Stack 22
G_1 K_1 N_0 
Stack 23
E_2 F_5 G_2 
