Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
G_8 H_4 I_2 F_10 J_4 Z_100 
Stack 1
B_8 G_2 A_1 Z_101 C_0 B_7 
Stack 2
Z_102 D_6 A_5 C_8 E_9 D_5 
Stack 3
G_5 Z_103 C_2 E_10 H_2 B_4 
Stack 4
C_4 A_0 F_6 G_4 H_0 G_6 
Stack 5
D_0 A_3 C_3 E_8 J_5 
Stack 6
B_0 A_6 E_7 Z_104 H_5 
Stack 7
C_7 H_7 Z_105 Z_106 B_2 
Stack 8
G_11 I_9 B_5 G_0 A_4 
Stack 9
F_1 F_8 E_11 B_10 D_2 
Stack 10
I_1 E_1 G_1 H_9 F_11 
Stack 11
Z_107 Z_108 J_2 D_7 A_7 
Stack 12
E_2 Z_109 I_5 B_6 B_9 
Stack 13
C_10 F_5 J_8 H_10 J_1 
Stack 14
H_6 A_8 F_7 Z_110 F_2 
Stack 15
G_3 E_4 F_9 J_3 E_6 
Stack 16
C_9 I_3 D_3 B_1 D_8 
Stack 17
F_3 I_8 J_7 C_1 I_6 
Stack 18
I_0 A_2 I_4 H_8 F_4 
Stack 19
J_6 H_3 G_9 C_6 E_0 
Stack 20
D_1 D_9 B_3 D_4 G_10 
Stack 21
E_3 C_5 F_0 J_0 E_5 
Stack 22
G_7 J_9 Z_111 I_7 H_1 
