Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_5 A_4 A_1 C_2 
Stack 1
A_2 Z_100 C_13 C_12 
Stack 2
Z_101 Z_102 B_11 B_9 
Stack 3
C_0 B_10 C_11 C_1 
Stack 4
B_12 B_13 B_3 C_10 
Stack 5
Z_103 B_4 A_0 B_7 
Stack 6
C_3 A_7 C_6 A_3 
Stack 7
C_9 B_6 B_2 C_5 
Stack 8
B_5 A_9 C_7 C_8 
Stack 9
B_1 A_11 B_8 C_4 
Stack 10
A_10 B_14 Z_104 
Stack 11
B_0 A_8 A_6 
