Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_0 J_1 G_3 F_0 
Stack 1
D_5 I_5 F_2 H_1 
Stack 2
Z_100 B_2 H_3 F_5 
Stack 3
C_2 B_5 F_7 D_4 
Stack 4
D_1 B_4 F_8 D_7 
Stack 5
G_1 G_4 I_3 Z_101 
Stack 6
E_3 Z_102 F_6 I_1 
Stack 7
Z_103 E_0 H_6 D_3 
Stack 8
C_0 A_0 B_3 D_2 
Stack 9
F_1 I_0 A_4 G_0 
Stack 10
A_1 J_0 Z_104 G_5 
Stack 11
E_4 E_5 C_3 J_2 
Stack 12
H_4 Z_105 A_2 C_4 
Stack 13
J_3 B_1 H_5 B_0 
Stack 14
F_3 G_2 I_2 C_1 
Stack 15
E_6 I_4 D_6 F_4 
Stack 16
E_2 H_2 E_1 
Stack 17
A_3 Z_106 H_0 
