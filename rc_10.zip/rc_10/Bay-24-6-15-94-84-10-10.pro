Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
I_7 N_2 G_7 E_3 
Stack 1
C_2 H_0 A_0 L_3 
Stack 2
Z_100 I_5 M_0 C_0 
Stack 3
E_4 E_0 O_1 Z_101 
Stack 4
Z_102 H_1 J_4 H_3 
Stack 5
B_3 L_1 C_3 E_1 
Stack 6
H_6 H_7 C_1 F_0 
Stack 7
H_8 D_2 Z_103 I_3 
Stack 8
F_2 E_2 F_1 F_3 
Stack 9
Z_104 O_0 L_2 Z_105 
Stack 10
I_8 H_2 M_1 A_1 
Stack 11
G_0 F_5 O_2 N_0 
Stack 12
G_2 K_2 G_5 J_2 
Stack 13
K_1 K_4 G_8 G_4 
Stack 14
J_0 L_0 L_4 N_3 
Stack 15
N_1 D_3 D_1 F_4 
Stack 16
Z_106 H_4 M_4 I_0 
Stack 17
B_1 Z_107 G_3 A_2 
Stack 18
L_5 K_5 J_3 K_0 
Stack 19
G_6 Z_108 B_0 B_2 
Stack 20
I_4 H_5 J_1 D_0 
Stack 21
I_1 Z_109 G_1 E_5 
Stack 22
I_6 K_3 M_2 
Stack 23
J_5 M_3 I_2 
