Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_4 Z_100 A_5 C_1 
Stack 1
A_3 B_12 A_4 B_8 
Stack 2
A_11 B_9 C_6 Z_101 
Stack 3
A_12 Z_102 C_11 A_9 
Stack 4
C_2 A_13 A_10 C_9 
Stack 5
A_2 B_2 B_7 Z_103 
Stack 6
B_1 A_0 B_3 C_5 
Stack 7
C_3 Z_104 C_10 C_8 
Stack 8
A_8 C_12 B_11 B_6 
Stack 9
C_4 B_13 B_0 C_7 
Stack 10
C_0 A_1 B_10 
Stack 11
B_5 A_6 A_7 
