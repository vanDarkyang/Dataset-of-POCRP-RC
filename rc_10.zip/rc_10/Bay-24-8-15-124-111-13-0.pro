Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
H_4 L_1 F_0 H_10 J_2 F_6 
Stack 1
Z_100 Z_101 K_4 H_3 E_7 G_3 
Stack 2
G_7 K_1 Z_102 L_6 F_3 O_1 
Stack 3
F_1 G_2 J_1 J_4 A_3 E_0 
Stack 4
O_2 Z_103 L_3 H_5 E_6 
Stack 5
B_0 I_7 A_4 D_7 O_0 
Stack 6
H_1 F_4 L_4 A_1 Z_104 
Stack 7
N_0 J_3 C_4 K_2 I_9 
Stack 8
K_7 C_3 I_3 B_4 M_3 
Stack 9
L_0 Z_105 C_1 E_2 M_2 
Stack 10
A_0 I_1 Z_106 I_0 A_2 
Stack 11
K_0 O_3 J_9 G_4 I_10 
Stack 12
C_5 O_4 J_0 D_1 K_6 
Stack 13
D_0 K_3 D_2 B_1 Z_107 
Stack 14
I_6 G_8 H_2 I_8 N_2 
Stack 15
B_3 F_7 Z_108 Z_109 E_4 
Stack 16
H_7 C_0 D_3 G_5 G_0 
Stack 17
F_5 G_9 D_6 B_5 J_7 
Stack 18
E_5 N_3 E_1 G_6 D_4 
Stack 19
J_8 K_5 N_1 H_8 I_4 
Stack 20
C_2 I_5 I_2 H_9 Z_110 
Stack 21
M_0 B_2 F_2 L_5 D_5 
Stack 22
E_3 M_1 J_5 L_2 H_6 
Stack 23
G_1 H_0 Z_111 Z_112 J_6 
