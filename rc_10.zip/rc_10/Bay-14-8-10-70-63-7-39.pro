Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
F_8 Z_100 H_3 F_5 C_1 
Stack 1
A_2 G_6 B_4 I_1 E_0 
Stack 2
B_2 G_4 A_3 J_1 I_3 
Stack 3
D_5 I_0 H_2 G_5 J_3 
Stack 4
E_2 D_1 F_6 F_1 B_3 
Stack 5
D_0 D_4 C_0 F_7 C_2 
Stack 6
Z_101 D_3 Z_102 G_1 I_2 
Stack 7
G_7 H_0 D_2 Z_103 C_3 
Stack 8
I_4 G_2 F_2 Z_104 E_6 
Stack 9
Z_105 F_0 E_1 I_5 G_0 
Stack 10
F_4 E_3 C_4 B_5 B_1 
Stack 11
H_1 J_0 A_1 F_3 J_2 
Stack 12
A_4 A_0 Z_106 E_4 B_0 
Stack 13
H_5 G_3 H_4 D_6 E_5 
