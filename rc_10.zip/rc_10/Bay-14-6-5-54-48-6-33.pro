Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_2 A_1 D_6 B_1 
Stack 1
D_3 C_8 B_8 Z_100 
Stack 2
B_0 E_3 E_6 C_2 
Stack 3
B_3 E_4 C_5 A_5 
Stack 4
D_9 C_3 C_4 A_3 
Stack 5
A_4 C_7 A_6 Z_101 
Stack 6
Z_102 E_0 E_9 D_0 
Stack 7
A_2 C_1 C_10 D_1 
Stack 8
E_7 D_7 B_7 D_4 
Stack 9
Z_103 B_5 D_8 B_9 
Stack 10
A_0 B_2 B_4 B_6 
Stack 11
D_2 C_6 Z_104 E_8 
Stack 12
Z_105 D_5 C_0 
Stack 13
E_1 C_9 E_5 
