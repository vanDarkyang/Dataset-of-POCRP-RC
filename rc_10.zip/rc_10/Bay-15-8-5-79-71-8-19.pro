Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_11 E_12 A_9 D_8 E_0 C_6 
Stack 1
E_9 A_4 D_3 E_10 E_3 B_7 
Stack 2
C_13 D_5 D_2 C_8 E_4 D_14 
Stack 3
Z_100 C_12 D_13 E_11 D_0 E_5 
Stack 4
A_13 B_5 Z_101 A_5 Z_102 
Stack 5
C_4 E_1 Z_103 D_12 C_3 
Stack 6
A_7 C_9 A_0 C_7 B_2 
Stack 7
D_7 Z_104 B_11 B_1 A_1 
Stack 8
E_8 C_5 C_10 A_10 Z_105 
Stack 9
B_3 Z_106 C_1 B_13 A_3 
Stack 10
A_12 C_2 A_6 B_9 B_12 
Stack 11
D_4 B_10 C_0 E_6 B_8 
Stack 12
E_7 D_9 A_8 C_11 D_10 
Stack 13
A_2 C_14 B_6 D_6 Z_107 
Stack 14
B_0 E_2 B_4 D_11 D_1 
