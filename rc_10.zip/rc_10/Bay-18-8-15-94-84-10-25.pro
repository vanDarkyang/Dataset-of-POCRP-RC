Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
M_3 D_3 N_1 J_2 F_2 J_4 
Stack 1
K_1 Z_100 K_2 Z_101 A_2 K_6 
Stack 2
N_0 H_7 H_4 M_1 F_7 F_5 
Stack 3
I_8 H_6 I_2 O_0 Z_102 G_4 
Stack 4
C_1 J_0 B_2 D_1 Z_103 
Stack 5
Z_104 F_4 F_0 L_2 A_1 
Stack 6
M_0 G_3 I_1 D_4 H_8 
Stack 7
Z_105 L_3 I_3 N_2 L_0 
Stack 8
C_3 G_6 E_3 I_7 L_1 
Stack 9
O_2 C_0 D_0 Z_106 G_8 
Stack 10
A_0 H_3 B_0 J_3 E_0 
Stack 11
I_6 K_5 F_6 K_0 O_1 
Stack 12
H_2 G_5 G_1 I_0 N_3 
Stack 13
Z_107 I_5 H_1 Z_108 E_1 
Stack 14
M_2 E_2 F_3 K_4 G_0 
Stack 15
B_1 J_1 I_4 E_4 G_7 
Stack 16
H_5 F_1 D_5 K_3 Z_109 
Stack 17
H_0 E_5 C_2 G_2 D_2 
