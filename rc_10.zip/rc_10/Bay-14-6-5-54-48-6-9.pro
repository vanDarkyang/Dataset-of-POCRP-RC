Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_1 Z_100 Z_101 B_6 
Stack 1
E_8 E_7 C_2 E_6 
Stack 2
Z_102 D_3 E_3 C_5 
Stack 3
B_3 A_1 Z_103 D_0 
Stack 4
A_5 A_2 D_6 D_5 
Stack 5
B_9 B_10 D_7 C_7 
Stack 6
D_8 C_1 B_1 A_3 
Stack 7
D_4 E_9 B_2 C_6 
Stack 8
E_4 C_3 E_1 B_5 
Stack 9
B_0 C_0 A_4 B_7 
Stack 10
C_8 D_9 E_2 C_4 
Stack 11
Z_104 C_9 A_0 D_10 
Stack 12
E_0 B_8 D_2 
Stack 13
B_4 Z_105 E_5 
