Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_2 A_8 B_5 B_2 
Stack 1
B_4 B_8 C_7 Z_100 
Stack 2
A_3 C_2 A_7 D_6 
Stack 3
E_6 D_2 E_4 Z_101 
Stack 4
D_0 C_5 A_6 E_1 
Stack 5
D_8 A_4 D_7 D_4 
Stack 6
D_1 C_4 E_7 E_8 
Stack 7
A_0 E_2 B_6 D_5 
Stack 8
C_9 C_8 Z_102 Z_103 
Stack 9
Z_104 C_1 C_0 A_5 
Stack 10
B_7 B_0 D_9 B_3 
Stack 11
Z_105 C_3 B_1 D_3 
Stack 12
B_9 C_6 E_0 
Stack 13
E_5 E_3 A_1 
