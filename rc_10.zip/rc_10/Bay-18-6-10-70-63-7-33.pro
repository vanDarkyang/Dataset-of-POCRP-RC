Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
J_3 D_3 E_5 F_2 
Stack 1
E_3 I_0 B_4 J_0 
Stack 2
I_3 H_5 J_4 F_5 
Stack 3
G_6 E_2 A_2 A_3 
Stack 4
A_1 B_2 G_2 I_1 
Stack 5
Z_100 E_0 I_2 J_1 
Stack 6
H_3 H_0 Z_101 G_5 
Stack 7
B_0 G_4 I_5 G_3 
Stack 8
A_0 F_6 G_0 Z_102 
Stack 9
F_4 C_4 J_2 F_7 
Stack 10
F_3 C_5 Z_103 E_1 
Stack 11
E_6 D_0 D_4 C_6 
Stack 12
C_3 Z_104 I_4 B_1 
Stack 13
H_4 F_0 H_2 Z_105 
Stack 14
D_1 Z_106 H_6 E_4 
Stack 15
F_1 C_0 A_4 G_1 
Stack 16
B_3 C_2 C_1 
Stack 17
D_2 H_1 E_7 
