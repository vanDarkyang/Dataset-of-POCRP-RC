Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
H_3 A_3 H_4 H_0 A_0 
Stack 1
J_2 B_2 E_2 B_3 H_2 
Stack 2
B_1 C_1 D_0 C_3 C_4 
Stack 3
E_3 Z_100 G_5 F_1 D_5 
Stack 4
G_3 D_1 I_1 Z_101 D_6 
Stack 5
J_1 F_6 G_2 H_1 E_4 
Stack 6
Z_102 E_7 G_1 G_4 I_3 
Stack 7
E_6 I_2 I_5 A_1 E_0 
Stack 8
C_5 Z_103 Z_104 D_3 F_3 
Stack 9
H_5 F_2 I_4 A_2 B_4 
Stack 10
C_2 H_6 Z_105 D_2 J_0 
Stack 11
C_6 B_0 J_3 F_4 D_4 
Stack 12
C_0 Z_106 E_5 J_4 F_0 
Stack 13
I_0 G_0 F_5 E_1 F_7 
