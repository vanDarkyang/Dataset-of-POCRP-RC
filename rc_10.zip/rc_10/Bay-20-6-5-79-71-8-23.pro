Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
B_10 C_14 A_0 B_2 
Stack 1
E_1 C_9 A_7 D_12 
Stack 2
A_9 E_3 E_13 D_3 
Stack 3
Z_100 C_3 Z_101 E_8 
Stack 4
A_13 E_5 Z_102 C_13 
Stack 5
E_7 C_0 B_12 A_4 
Stack 6
B_8 C_2 C_10 Z_103 
Stack 7
D_8 D_0 D_6 E_4 
Stack 8
B_1 E_2 C_1 Z_104 
Stack 9
E_10 C_12 A_10 D_1 
Stack 10
A_6 D_4 C_6 B_11 
Stack 11
C_11 A_11 C_4 B_7 
Stack 12
A_3 A_8 D_10 B_3 
Stack 13
E_6 A_1 D_14 C_8 
Stack 14
Z_105 D_11 C_5 D_2 
Stack 15
E_12 A_5 B_5 B_9 
Stack 16
D_9 C_7 D_5 B_0 
Stack 17
B_4 D_7 E_0 D_13 
Stack 18
B_6 A_2 E_9 Z_106 
Stack 19
E_11 Z_107 A_12 
