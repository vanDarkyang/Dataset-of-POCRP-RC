Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_2 Z_100 E_7 C_11 
Stack 1
B_2 B_8 C_5 A_6 
Stack 2
C_8 B_0 C_3 A_2 
Stack 3
C_1 A_1 Z_101 Z_102 
Stack 4
Z_103 E_4 B_4 C_9 
Stack 5
B_9 A_7 C_10 D_6 
Stack 6
E_6 D_7 C_0 B_7 
Stack 7
D_1 B_1 E_0 B_3 
Stack 8
B_6 C_6 C_4 E_8 
Stack 9
D_0 Z_104 D_5 C_2 
Stack 10
C_7 E_5 A_0 A_5 
Stack 11
E_3 E_1 D_4 D_3 
Stack 12
D_8 A_3 E_2 
Stack 13
B_5 Z_105 A_4 
