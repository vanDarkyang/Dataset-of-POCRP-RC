Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_6 B_13 A_4 B_7 
Stack 1
C_7 B_0 B_4 B_1 
Stack 2
Z_100 A_3 A_6 B_11 
Stack 3
Z_101 C_1 A_12 B_6 
Stack 4
A_8 C_4 A_5 B_3 
Stack 5
A_9 C_2 C_3 A_1 
Stack 6
B_10 B_5 A_7 B_8 
Stack 7
Z_102 B_14 C_0 Z_103 
Stack 8
C_5 A_10 A_0 A_2 
Stack 9
B_2 C_8 C_12 C_11 
Stack 10
B_12 C_9 C_10 
Stack 11
Z_104 B_9 A_11 
