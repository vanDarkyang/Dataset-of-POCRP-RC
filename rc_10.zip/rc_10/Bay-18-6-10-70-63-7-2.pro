Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_5 F_2 A_3 H_6 
Stack 1
B_3 J_2 I_3 Z_100 
Stack 2
G_1 B_4 B_5 C_1 
Stack 3
C_4 D_2 J_1 E_5 
Stack 4
J_3 G_6 Z_101 E_4 
Stack 5
A_0 G_7 I_2 F_0 
Stack 6
D_0 Z_102 J_4 H_3 
Stack 7
E_1 A_4 B_0 H_5 
Stack 8
F_3 H_4 F_1 C_0 
Stack 9
E_6 G_0 D_4 B_1 
Stack 10
H_0 C_2 D_1 Z_103 
Stack 11
F_4 G_4 A_1 H_1 
Stack 12
J_0 I_0 D_3 G_5 
Stack 13
B_2 E_2 C_3 I_1 
Stack 14
Z_104 A_2 E_0 C_5 
Stack 15
Z_105 E_3 Z_106 G_2 
Stack 16
F_6 I_4 H_2 
Stack 17
D_6 F_5 G_3 
