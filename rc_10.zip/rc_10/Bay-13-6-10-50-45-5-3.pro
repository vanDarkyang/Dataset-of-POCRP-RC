Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
F_4 G_3 D_3 Z_100 
Stack 1
F_3 E_1 I_2 I_1 
Stack 2
Z_101 G_1 G_0 C_0 
Stack 3
I_0 A_1 C_2 D_5 
Stack 4
C_3 Z_102 F_1 H_2 
Stack 5
F_0 E_4 J_1 J_0 
Stack 6
A_2 B_0 E_3 Z_103 
Stack 7
C_1 B_1 E_6 D_1 
Stack 8
G_2 F_2 F_5 C_4 
Stack 9
H_3 H_0 G_4 E_2 
Stack 10
D_0 F_6 A_0 H_4 
Stack 11
H_1 D_4 E_0 
Stack 12
D_2 Z_104 E_5 
