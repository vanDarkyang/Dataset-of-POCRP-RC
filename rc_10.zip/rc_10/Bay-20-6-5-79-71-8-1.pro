Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_14 A_1 C_1 B_14 
Stack 1
Z_100 Z_101 C_13 B_13 
Stack 2
C_4 C_0 D_5 E_2 
Stack 3
B_1 E_11 C_3 E_8 
Stack 4
E_4 Z_102 D_4 E_7 
Stack 5
B_7 D_12 A_7 A_11 
Stack 6
B_15 E_9 B_9 D_0 
Stack 7
B_4 B_6 A_0 D_8 
Stack 8
C_6 A_5 B_8 A_8 
Stack 9
C_11 C_10 Z_103 B_11 
Stack 10
A_10 C_8 A_4 D_2 
Stack 11
E_6 C_9 D_1 C_2 
Stack 12
D_6 C_12 C_7 A_3 
Stack 13
A_13 E_5 D_11 Z_104 
Stack 14
E_0 Z_105 B_3 D_10 
Stack 15
B_10 D_13 A_6 B_12 
Stack 16
E_3 Z_106 B_5 A_12 
Stack 17
E_10 B_0 D_7 E_1 
Stack 18
A_9 C_5 Z_107 D_3 
Stack 19
D_9 B_2 A_2 
