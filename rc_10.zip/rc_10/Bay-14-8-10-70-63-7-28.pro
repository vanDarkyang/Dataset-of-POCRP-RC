Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_2 G_0 A_2 J_3 A_1 
Stack 1
F_7 Z_100 C_0 J_1 Z_101 
Stack 2
E_5 B_4 J_2 E_7 E_8 
Stack 3
D_0 H_0 Z_102 H_5 F_2 
Stack 4
E_1 G_1 D_5 F_1 H_1 
Stack 5
H_2 I_3 D_3 F_0 G_4 
Stack 6
B_1 E_0 C_3 Z_103 Z_104 
Stack 7
B_2 D_1 G_2 E_3 C_5 
Stack 8
G_3 F_4 H_4 J_0 I_4 
Stack 9
Z_105 D_2 H_3 D_4 C_1 
Stack 10
G_5 J_4 E_4 C_6 D_7 
Stack 11
I_2 I_1 B_3 I_0 Z_106 
Stack 12
F_6 F_5 D_6 B_0 C_4 
Stack 13
A_0 F_3 E_2 A_3 E_6 
