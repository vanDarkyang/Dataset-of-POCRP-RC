Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
Z_100 C_5 Z_101 A_11 
Stack 1
A_2 Z_102 A_4 B_7 
Stack 2
A_0 B_5 C_11 C_9 
Stack 3
A_10 B_9 A_8 B_11 
Stack 4
C_1 B_8 C_4 B_1 
Stack 5
C_2 A_7 B_3 B_14 
Stack 6
B_6 B_4 Z_103 C_8 
Stack 7
A_6 A_9 C_3 B_12 
Stack 8
B_13 A_5 A_3 C_6 
Stack 9
A_1 C_13 B_10 C_10 
Stack 10
B_0 Z_104 C_7 
Stack 11
C_0 B_2 C_12 
