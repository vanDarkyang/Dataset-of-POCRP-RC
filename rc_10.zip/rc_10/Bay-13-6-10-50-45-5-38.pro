Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
F_2 A_0 Z_100 H_3 
Stack 1
G_3 E_3 J_2 I_0 
Stack 2
F_1 H_1 C_1 F_3 
Stack 3
B_2 Z_101 H_2 C_3 
Stack 4
D_1 F_0 I_3 F_4 
Stack 5
G_1 B_1 A_1 G_2 
Stack 6
G_5 C_2 E_5 I_1 
Stack 7
D_0 E_4 E_0 H_0 
Stack 8
G_0 D_2 E_2 J_0 
Stack 9
Z_102 B_3 F_5 E_1 
Stack 10
D_3 I_2 E_6 Z_103 
Stack 11
B_0 Z_104 G_4 
Stack 12
C_0 J_1 A_2 
