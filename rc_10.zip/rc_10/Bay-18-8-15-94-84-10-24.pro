Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
I_0 F_5 J_3 A_1 C_3 G_5 
Stack 1
G_0 M_3 H_2 C_2 H_9 A_2 
Stack 2
J_4 J_2 Z_100 C_1 F_4 C_0 
Stack 3
N_1 I_8 I_5 Z_101 D_3 Z_102 
Stack 4
F_1 Z_103 I_2 N_2 M_2 
Stack 5
H_0 O_0 H_8 E_2 O_2 
Stack 6
K_5 G_1 F_0 F_6 H_6 
Stack 7
H_3 Z_104 O_1 G_4 E_4 
Stack 8
B_0 L_1 H_5 D_4 M_1 
Stack 9
G_3 K_4 D_1 J_0 K_1 
Stack 10
D_0 B_1 Z_105 L_4 F_3 
Stack 11
H_1 I_4 H_7 A_0 I_1 
Stack 12
E_3 H_4 K_0 N_3 L_5 
Stack 13
K_3 D_2 K_2 J_1 C_4 
Stack 14
E_0 Z_106 L_2 L_0 Z_107 
Stack 15
B_2 G_6 F_2 N_0 M_0 
Stack 16
Z_108 I_6 G_2 J_5 I_7 
Stack 17
E_1 G_7 I_3 Z_109 L_3 
