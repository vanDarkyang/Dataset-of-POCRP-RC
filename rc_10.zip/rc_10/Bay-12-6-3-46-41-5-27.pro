Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_13 Z_100 A_6 B_0 
Stack 1
A_9 C_7 A_13 C_3 
Stack 2
C_4 A_2 A_1 A_10 
Stack 3
A_12 B_3 B_8 C_10 
Stack 4
B_2 C_0 C_9 B_10 
Stack 5
C_1 A_0 A_14 C_5 
Stack 6
B_4 C_6 A_8 Z_101 
Stack 7
B_6 Z_102 C_2 B_11 
Stack 8
B_5 Z_103 Z_104 B_7 
Stack 9
C_11 B_9 A_3 C_8 
Stack 10
A_11 B_1 A_7 
Stack 11
A_5 A_4 C_12 
