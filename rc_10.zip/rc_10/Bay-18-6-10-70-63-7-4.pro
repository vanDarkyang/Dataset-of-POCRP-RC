Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
I_1 B_2 E_2 C_1 
Stack 1
F_4 C_0 J_2 G_6 
Stack 2
B_0 H_5 F_0 H_0 
Stack 3
B_1 F_7 D_4 H_1 
Stack 4
E_5 I_3 E_4 B_3 
Stack 5
E_1 G_1 B_5 G_3 
Stack 6
G_7 Z_100 E_6 C_2 
Stack 7
I_0 F_2 Z_101 G_0 
Stack 8
G_2 A_2 A_3 D_6 
Stack 9
J_3 H_2 E_0 F_1 
Stack 10
C_3 I_4 G_4 Z_102 
Stack 11
F_6 Z_103 Z_104 Z_105 
Stack 12
F_5 B_4 J_1 E_7 
Stack 13
J_4 J_0 H_3 G_5 
Stack 14
A_1 D_3 I_2 E_3 
Stack 15
D_2 D_7 A_0 D_1 
Stack 16
H_4 D_5 F_3 
Stack 17
Z_106 D_0 C_4 
