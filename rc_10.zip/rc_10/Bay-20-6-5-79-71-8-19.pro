Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_12 E_1 A_7 E_0 
Stack 1
E_9 C_9 C_0 E_3 
Stack 2
Z_100 B_8 A_9 E_4 
Stack 3
Z_101 C_6 B_5 Z_102 
Stack 4
A_14 C_1 B_3 E_13 
Stack 5
C_4 C_3 D_7 Z_103 
Stack 6
A_8 B_10 E_10 B_1 
Stack 7
D_6 D_8 Z_104 A_1 
Stack 8
E_8 C_12 E_11 B_11 
Stack 9
B_2 E_2 A_6 A_3 
Stack 10
A_13 A_10 D_11 B_13 
Stack 11
D_3 D_2 C_8 B_7 
Stack 12
E_7 D_1 B_0 D_9 
Stack 13
A_2 D_12 A_11 C_5 
Stack 14
Z_105 A_5 Z_106 D_0 
Stack 15
E_12 D_13 B_9 C_7 
Stack 16
A_4 A_0 E_6 B_6 
Stack 17
D_4 B_12 C_10 D_14 
Stack 18
C_11 Z_107 D_5 E_5 
Stack 19
B_4 C_2 D_10 
