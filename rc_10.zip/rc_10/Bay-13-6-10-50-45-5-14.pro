Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
G_4 Z_100 A_0 B_1 
Stack 1
E_0 F_0 E_2 F_3 
Stack 2
A_2 A_1 I_1 I_3 
Stack 3
Z_101 C_2 E_1 E_4 
Stack 4
G_2 F_6 G_3 F_2 
Stack 5
F_4 H_1 D_5 Z_102 
Stack 6
D_1 H_0 B_3 Z_103 
Stack 7
C_1 I_0 H_2 B_2 
Stack 8
D_0 H_4 E_3 D_2 
Stack 9
G_1 C_0 G_5 G_0 
Stack 10
F_5 I_2 B_0 J_1 
Stack 11
D_4 D_3 J_0 
Stack 12
H_3 F_1 Z_104 
