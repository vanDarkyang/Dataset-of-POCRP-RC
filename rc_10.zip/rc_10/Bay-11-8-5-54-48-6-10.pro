Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_7 B_4 Z_100 D_4 E_4 
Stack 1
B_0 C_5 D_3 E_7 Z_101 
Stack 2
A_9 A_8 D_6 A_2 B_3 
Stack 3
C_9 B_9 A_1 E_1 C_10 
Stack 4
B_6 E_6 C_6 D_1 D_2 
Stack 5
A_3 A_5 B_8 C_4 C_3 
Stack 6
Z_102 C_1 E_5 D_7 B_5 
Stack 7
Z_103 Z_104 E_2 D_0 A_7 
Stack 8
A_0 C_2 A_6 C_0 C_7 
Stack 9
A_4 C_8 B_1 D_8 E_3 
Stack 10
Z_105 D_5 B_2 E_0 
