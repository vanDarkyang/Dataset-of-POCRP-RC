Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
C_11 E_5 C_2 F_9 Z_100 F_3 
Stack 1
F_6 C_10 H_8 J_8 F_4 A_7 
Stack 2
Z_101 Z_102 A_3 Z_103 I_6 E_6 
Stack 3
E_3 Z_104 J_6 Z_105 B_7 J_9 
Stack 4
H_6 F_10 C_7 J_7 D_2 E_9 
Stack 5
D_10 G_7 I_5 G_8 H_5 
Stack 6
E_2 A_4 C_3 I_9 G_3 
Stack 7
B_2 D_8 I_10 I_3 E_4 
Stack 8
B_8 D_7 D_1 I_7 D_6 
Stack 9
Z_106 I_4 E_11 F_8 G_6 
Stack 10
C_1 H_3 A_8 J_4 E_10 
Stack 11
H_4 J_0 C_9 E_8 G_4 
Stack 12
H_0 Z_107 I_1 J_3 E_1 
Stack 13
J_5 A_0 G_1 C_0 J_2 
Stack 14
A_5 Z_108 B_3 D_12 E_0 
Stack 15
F_7 F_2 I_2 F_5 G_10 
Stack 16
F_1 G_5 D_4 Z_109 B_5 
Stack 17
Z_110 H_1 J_1 H_9 A_2 
Stack 18
C_4 D_11 G_9 D_5 I_0 
Stack 19
D_0 E_7 D_3 A_1 H_2 
Stack 20
B_1 B_4 A_6 H_7 C_8 
Stack 21
C_5 G_2 G_0 C_6 D_9 
Stack 22
F_0 B_0 B_6 I_8 Z_111 
