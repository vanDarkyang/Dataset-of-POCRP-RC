Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_4 C_3 D_1 Z_100 
Stack 1
D_8 B_4 E_5 E_6 
Stack 2
E_7 B_8 D_2 C_5 
Stack 3
A_6 C_8 Z_101 C_2 
Stack 4
C_1 A_2 Z_102 D_7 
Stack 5
E_0 Z_103 B_2 B_5 
Stack 6
D_6 B_6 A_7 C_4 
Stack 7
E_4 D_9 E_2 Z_104 
Stack 8
C_9 B_7 D_5 C_6 
Stack 9
E_3 D_10 C_0 E_1 
Stack 10
A_5 A_0 D_0 D_3 
Stack 11
A_4 B_3 B_0 C_7 
Stack 12
A_3 A_1 B_9 
Stack 13
B_1 E_8 Z_105 
