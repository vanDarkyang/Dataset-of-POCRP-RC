Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_6 Z_100 I_0 Z_101 E_4 
Stack 1
J_1 G_5 A_0 E_3 A_2 
Stack 2
F_2 A_1 B_2 J_0 C_0 
Stack 3
D_1 F_4 B_3 G_3 Z_102 
Stack 4
E_0 I_3 G_2 F_1 D_2 
Stack 5
C_3 G_4 I_2 H_3 Z_103 
Stack 6
F_0 D_4 H_1 H_2 G_0 
Stack 7
C_1 D_0 H_0 E_2 G_1 
Stack 8
C_2 B_1 F_3 I_1 B_0 
Stack 9
J_2 E_1 D_3 E_5 Z_104 
