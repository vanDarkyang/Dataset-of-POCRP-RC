Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
Z_100 D_0 C_3 C_0 D_5 G_2 
Stack 1
E_9 C_6 I_9 I_3 B_6 H_4 
Stack 2
B_1 Z_101 E_8 H_7 D_9 D_2 
Stack 3
A_3 F_7 E_10 I_5 I_6 B_5 
Stack 4
I_8 F_8 H_0 D_10 F_10 E_5 
Stack 5
Z_102 I_4 J_6 B_0 I_1 
Stack 6
D_6 Z_103 F_12 H_2 Z_104 
Stack 7
C_5 D_3 B_8 E_11 E_2 
Stack 8
H_10 E_4 J_2 Z_105 J_5 
Stack 9
I_0 F_0 J_8 G_7 E_1 
Stack 10
F_1 B_7 Z_106 G_8 C_1 
Stack 11
Z_107 B_10 F_6 A_5 E_12 
Stack 12
H_9 F_3 J_1 H_11 A_4 
Stack 13
G_3 D_1 I_7 C_7 H_8 
Stack 14
H_1 G_5 B_9 D_11 F_4 
Stack 15
E_0 Z_108 G_1 A_0 Z_109 
Stack 16
F_2 H_6 H_3 C_2 A_1 
Stack 17
F_9 G_0 B_4 F_5 G_11 
Stack 18
G_6 H_5 J_7 J_0 I_2 
Stack 19
C_4 J_4 J_3 E_7 D_8 
Stack 20
E_3 G_4 Z_110 J_9 A_2 
Stack 21
F_11 B_2 E_6 G_10 D_7 
Stack 22
G_9 Z_111 A_6 B_3 D_4 
