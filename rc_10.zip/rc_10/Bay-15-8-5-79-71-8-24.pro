Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_14 E_3 C_8 C_2 C_15 E_12 
Stack 1
C_6 C_3 E_5 C_12 D_9 E_7 
Stack 2
A_4 B_9 Z_100 C_0 A_12 C_10 
Stack 3
D_5 Z_101 D_6 A_5 D_3 D_11 
Stack 4
C_7 D_2 B_6 A_11 Z_102 
Stack 5
E_4 E_0 C_4 B_5 A_0 
Stack 6
B_11 D_8 A_3 C_5 D_12 
Stack 7
E_2 D_10 B_7 D_14 C_11 
Stack 8
A_9 Z_103 E_6 E_1 Z_104 
Stack 9
D_4 C_9 B_4 Z_105 A_2 
Stack 10
B_8 Z_106 C_1 Z_107 E_11 
Stack 11
B_3 A_1 B_1 D_13 E_8 
Stack 12
A_6 A_10 A_7 E_9 B_2 
Stack 13
C_13 B_12 B_10 A_13 D_7 
Stack 14
E_10 B_0 D_1 D_0 A_8 
