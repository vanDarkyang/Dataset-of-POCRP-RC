Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_2 Z_100 D_0 Z_101 B_0 
Stack 1
A_4 J_3 D_1 A_0 H_5 
Stack 2
G_4 F_4 B_2 H_0 I_1 
Stack 3
C_5 B_3 F_2 A_3 F_8 
Stack 4
J_2 I_3 C_0 I_0 J_0 
Stack 5
I_4 G_5 G_2 G_1 A_1 
Stack 6
C_1 F_1 Z_102 F_6 F_0 
Stack 7
H_1 H_3 Z_103 B_1 H_2 
Stack 8
E_4 D_5 J_4 D_4 Z_104 
Stack 9
C_4 H_4 G_3 G_0 F_3 
Stack 10
D_3 E_0 Z_105 E_3 C_3 
Stack 11
F_7 E_1 E_6 C_2 D_6 
Stack 12
J_1 E_5 C_6 E_7 I_2 
Stack 13
E_2 Z_106 F_5 I_5 A_2 
