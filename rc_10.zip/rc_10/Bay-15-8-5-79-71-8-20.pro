Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
B_1 A_11 C_8 C_9 C_10 C_5 
Stack 1
A_13 A_2 B_8 C_7 A_3 C_4 
Stack 2
Z_100 E_6 E_13 A_9 D_7 E_7 
Stack 3
B_11 E_4 C_1 A_8 Z_101 Z_102 
Stack 4
B_0 B_7 C_0 E_9 E_8 
Stack 5
B_14 A_7 D_10 A_1 Z_103 
Stack 6
A_6 B_2 B_6 D_11 A_4 
Stack 7
A_12 E_5 E_1 B_4 D_5 
Stack 8
Z_104 D_6 A_5 E_2 B_12 
Stack 9
A_10 D_2 D_9 B_10 E_0 
Stack 10
A_0 E_3 D_1 C_3 D_0 
Stack 11
C_2 Z_105 C_6 E_10 D_12 
Stack 12
B_3 D_14 D_4 D_13 C_12 
Stack 13
B_5 C_11 E_11 E_12 Z_106 
Stack 14
B_9 B_13 D_3 D_8 Z_107 
