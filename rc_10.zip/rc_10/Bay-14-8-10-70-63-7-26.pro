Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
A_2 Z_100 C_4 F_2 I_4 
Stack 1
C_0 E_0 B_3 D_4 F_3 
Stack 2
Z_101 G_5 D_5 E_4 I_0 
Stack 3
C_6 J_2 G_4 E_2 Z_102 
Stack 4
D_3 H_3 H_1 F_7 E_6 
Stack 5
Z_103 J_4 G_2 Z_104 F_8 
Stack 6
G_0 B_0 B_4 G_1 A_3 
Stack 7
H_4 G_3 C_1 I_2 F_0 
Stack 8
F_4 C_3 H_0 E_1 E_7 
Stack 9
B_2 D_7 Z_105 E_3 Z_106 
Stack 10
F_1 D_2 J_1 A_0 D_0 
Stack 11
F_6 J_0 I_3 C_2 H_2 
Stack 12
D_1 D_6 A_1 I_1 J_3 
Stack 13
H_5 F_5 C_5 B_1 E_5 
