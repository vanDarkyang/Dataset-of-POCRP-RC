Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
E_8 D_7 B_5 B_13 
Stack 1
B_7 C_6 Z_100 B_12 
Stack 2
E_4 E_12 C_13 E_1 
Stack 3
B_11 B_2 C_9 B_9 
Stack 4
A_2 Z_101 Z_102 C_8 
Stack 5
A_4 A_3 D_1 B_8 
Stack 6
Z_103 C_10 A_9 E_6 
Stack 7
Z_104 C_15 E_9 C_3 
Stack 8
A_11 D_12 D_3 E_2 
Stack 9
A_8 D_4 D_10 D_2 
Stack 10
E_7 D_9 B_4 C_16 
Stack 11
D_8 E_10 B_3 A_1 
Stack 12
C_11 B_10 D_0 B_1 
Stack 13
C_7 A_6 D_5 C_2 
Stack 14
C_5 D_11 C_1 B_6 
Stack 15
A_0 A_10 B_14 E_5 
Stack 16
E_0 C_0 C_14 C_4 
Stack 17
B_0 Z_105 D_6 E_13 
Stack 18
Z_106 E_11 A_7 C_12 
Stack 19
A_5 Z_107 E_3 
