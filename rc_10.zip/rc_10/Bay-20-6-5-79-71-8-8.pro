Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
B_1 Z_100 D_2 B_3 
Stack 1
D_14 Z_101 B_6 B_4 
Stack 2
A_1 C_2 Z_102 E_12 
Stack 3
D_11 D_13 B_10 D_7 
Stack 4
B_0 D_5 Z_103 D_1 
Stack 5
C_1 A_0 E_0 E_6 
Stack 6
E_8 C_3 A_5 D_12 
Stack 7
B_11 E_4 C_0 C_4 
Stack 8
E_5 D_15 Z_104 D_3 
Stack 9
B_13 C_12 E_1 E_10 
Stack 10
Z_105 D_10 D_6 A_3 
Stack 11
B_5 D_9 C_10 C_6 
Stack 12
E_2 A_7 A_11 B_7 
Stack 13
E_7 C_8 C_11 E_3 
Stack 14
D_0 A_2 A_8 E_11 
Stack 15
Z_106 C_7 C_14 Z_107 
Stack 16
A_6 C_13 E_9 C_5 
Stack 17
A_12 D_8 B_2 A_10 
Stack 18
B_12 D_4 A_9 A_4 
Stack 19
B_8 B_9 C_9 
