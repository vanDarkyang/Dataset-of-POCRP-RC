Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
J_5 J_1 I_8 Z_100 O_1 H_8 
Stack 1
E_2 E_4 B_0 L_2 H_3 D_3 
Stack 2
B_2 N_5 L_3 O_4 A_0 B_1 
Stack 3
E_5 H_11 M_5 K_7 A_4 J_2 
Stack 4
G_0 A_2 F_5 J_0 H_2 
Stack 5
G_2 H_0 H_1 O_0 M_4 
Stack 6
F_3 N_4 H_4 L_0 N_1 
Stack 7
K_2 H_6 H_5 G_4 J_4 
Stack 8
F_1 I_1 J_6 C_4 E_6 
Stack 9
M_1 I_7 I_5 F_6 G_5 
Stack 10
H_7 N_0 L_6 F_7 C_5 
Stack 11
D_6 F_4 Z_101 Z_102 L_7 
Stack 12
C_0 G_9 Z_103 F_0 Z_104 
Stack 13
C_3 G_7 G_3 Z_105 L_5 
Stack 14
I_3 D_4 K_1 D_5 K_0 
Stack 15
I_4 J_3 B_3 Z_106 A_3 
Stack 16
E_1 A_1 L_4 G_1 D_0 
Stack 17
O_3 J_7 I_0 N_2 G_6 
Stack 18
C_1 E_0 M_0 I_2 Z_107 
Stack 19
G_8 E_3 C_2 F_2 I_6 
Stack 20
C_6 Z_108 M_2 K_3 K_4 
Stack 21
Z_109 B_4 D_2 N_3 H_10 
Stack 22
H_9 Z_110 K_5 Z_111 M_3 
Stack 23
O_2 D_1 Z_112 K_6 L_1 
