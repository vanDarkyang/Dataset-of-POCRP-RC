Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
F_1 E_3 E_2 D_2 H_3 
Stack 1
B_2 D_0 E_1 D_1 C_2 
Stack 2
A_2 H_2 C_1 G_2 E_5 
Stack 3
A_0 Z_100 H_4 G_5 H_1 
Stack 4
F_6 G_3 F_2 J_1 J_0 
Stack 5
Z_101 B_1 Z_102 B_0 C_3 
Stack 6
Z_103 B_3 F_3 F_4 E_4 
Stack 7
F_5 G_4 G_0 I_1 D_3 
Stack 8
G_1 E_0 I_2 A_1 C_0 
Stack 9
Z_104 F_0 J_2 I_0 H_0 
