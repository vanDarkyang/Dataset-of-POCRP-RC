Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_12 E_11 D_7 C_14 
Stack 1
Z_100 Z_101 C_10 Z_102 
Stack 2
Z_103 C_9 E_1 Z_104 
Stack 3
A_3 D_0 A_5 B_10 
Stack 4
D_4 C_5 Z_105 B_0 
Stack 5
D_2 C_3 A_7 A_10 
Stack 6
B_4 D_3 A_4 E_13 
Stack 7
B_11 E_7 D_9 D_8 
Stack 8
C_0 A_2 D_13 E_8 
Stack 9
B_13 D_10 B_12 C_2 
Stack 10
B_9 D_12 A_12 A_9 
Stack 11
A_6 E_0 D_6 B_1 
Stack 12
Z_106 B_3 A_11 B_14 
Stack 13
E_9 E_2 C_13 E_4 
Stack 14
A_1 C_11 D_11 E_12 
Stack 15
C_7 C_8 C_4 B_2 
Stack 16
B_5 E_5 B_8 E_6 
Stack 17
D_5 C_1 D_1 A_8 
Stack 18
C_6 E_10 A_0 Z_107 
Stack 19
E_3 B_7 B_6 
