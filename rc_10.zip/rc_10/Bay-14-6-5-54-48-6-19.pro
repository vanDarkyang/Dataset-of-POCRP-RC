Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_3 D_6 B_0 D_4 
Stack 1
C_6 A_0 E_6 E_4 
Stack 2
C_7 A_4 B_6 D_3 
Stack 3
D_2 C_4 E_0 B_7 
Stack 4
A_1 Z_100 D_9 E_2 
Stack 5
A_7 D_7 C_9 C_10 
Stack 6
D_1 E_5 Z_101 A_5 
Stack 7
C_5 Z_102 A_2 E_8 
Stack 8
B_4 A_8 C_1 A_6 
Stack 9
C_0 B_1 C_3 B_8 
Stack 10
A_3 Z_103 B_5 D_5 
Stack 11
B_2 C_2 E_1 D_0 
Stack 12
B_3 Z_104 C_8 
Stack 13
E_7 Z_105 D_8 
