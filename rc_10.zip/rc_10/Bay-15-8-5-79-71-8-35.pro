Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
B_1 E_9 Z_100 C_6 E_5 A_4 
Stack 1
C_4 Z_101 C_10 D_1 D_7 A_10 
Stack 2
C_14 B_4 E_10 B_5 C_11 Z_102 
Stack 3
E_2 D_14 D_12 E_13 E_7 C_0 
Stack 4
Z_103 D_0 D_9 E_1 C_12 
Stack 5
A_7 D_11 B_6 E_11 A_6 
Stack 6
Z_104 B_13 D_3 B_7 A_8 
Stack 7
A_2 B_10 B_11 B_12 C_2 
Stack 8
D_4 C_13 E_4 E_6 A_3 
Stack 9
D_8 A_5 E_8 B_9 B_3 
Stack 10
B_14 D_2 E_0 A_1 B_0 
Stack 11
C_8 Z_105 B_2 D_13 B_8 
Stack 12
A_9 D_10 Z_106 C_7 C_5 
Stack 13
D_6 A_11 Z_107 A_0 E_12 
Stack 14
C_1 C_9 D_5 E_3 C_3 
