Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_11 C_5 D_13 A_7 C_13 B_2 
Stack 1
C_2 B_5 E_0 A_4 C_9 E_5 
Stack 2
A_9 D_5 B_3 D_9 D_11 A_8 
Stack 3
A_3 Z_100 E_1 D_14 B_10 A_10 
Stack 4
D_4 E_2 C_10 B_13 B_0 
Stack 5
D_2 E_10 C_6 A_12 A_11 
Stack 6
B_4 D_8 E_4 D_6 E_12 
Stack 7
B_11 C_7 C_0 Z_101 Z_102 
Stack 8
Z_103 D_0 Z_104 C_12 E_7 
Stack 9
B_14 Z_105 B_7 D_12 C_1 
Stack 10
B_9 C_3 D_7 C_4 Z_106 
Stack 11
A_6 D_3 C_8 B_8 B_1 
Stack 12
E_9 E_6 Z_107 D_1 B_15 
Stack 13
E_8 A_2 A_5 A_0 E_3 
Stack 14
A_1 D_10 B_12 B_6 E_11 
