Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
D_2 E_1 A_8 C_0 D_8 A_6 
Stack 1
E_10 A_13 D_4 E_6 A_10 C_11 
Stack 2
B_8 Z_100 C_10 C_9 A_1 C_1 
Stack 3
B_3 B_6 E_8 D_10 B_0 C_12 
Stack 4
A_14 Z_101 A_4 C_14 D_3 
Stack 5
Z_102 A_2 B_7 C_13 Z_103 
Stack 6
A_9 A_7 Z_104 E_3 Z_105 
Stack 7
D_7 Z_106 E_7 Z_107 D_13 
Stack 8
A_3 E_5 C_6 E_13 C_5 
Stack 9
A_11 D_11 E_11 D_0 B_1 
Stack 10
C_4 C_8 C_15 B_9 E_12 
Stack 11
B_2 D_1 D_6 E_9 A_0 
Stack 12
B_4 B_11 E_2 E_4 A_12 
Stack 13
D_12 B_5 B_10 D_9 C_3 
Stack 14
C_7 A_5 E_0 D_5 C_2 
