Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_10 B_9 Z_100 A_3 
Stack 1
E_8 C_5 B_4 A_8 
Stack 2
C_4 Z_101 B_13 Z_102 
Stack 3
B_7 Z_103 A_14 C_11 
Stack 4
C_6 C_8 E_6 Z_104 
Stack 5
D_7 C_3 Z_105 A_1 
Stack 6
C_9 A_9 Z_106 A_7 
Stack 7
B_6 B_10 E_10 B_1 
Stack 8
D_4 C_10 D_6 E_4 
Stack 9
C_14 A_11 B_2 C_13 
Stack 10
B_8 C_2 C_1 D_12 
Stack 11
A_5 D_13 E_7 B_5 
Stack 12
B_0 D_5 D_10 A_13 
Stack 13
D_3 E_12 D_11 E_9 
Stack 14
D_2 E_11 B_3 C_0 
Stack 15
B_11 C_12 Z_107 E_0 
Stack 16
D_9 B_12 E_2 D_0 
Stack 17
D_1 E_1 D_8 A_4 
Stack 18
E_3 C_7 A_0 A_6 
Stack 19
A_2 A_12 E_5 
