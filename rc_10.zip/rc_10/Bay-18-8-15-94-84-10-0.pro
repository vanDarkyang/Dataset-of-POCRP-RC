Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
O_1 L_2 G_2 J_5 G_0 I_5 
Stack 1
C_1 H_1 B_3 J_6 K_2 K_0 
Stack 2
J_1 H_0 A_0 N_2 G_1 H_7 
Stack 3
C_4 K_3 Z_100 B_0 C_3 L_1 
Stack 4
Z_101 F_2 M_3 D_3 B_2 
Stack 5
E_1 F_1 A_1 L_4 E_5 
Stack 6
G_5 F_3 G_4 I_4 H_6 
Stack 7
M_0 D_4 C_2 J_7 Z_102 
Stack 8
D_1 E_2 I_1 M_4 H_5 
Stack 9
F_4 K_4 I_2 G_8 E_0 
Stack 10
K_1 F_0 D_0 L_3 Z_103 
Stack 11
Z_104 H_8 G_6 O_0 B_1 
Stack 12
Z_105 J_4 Z_106 M_2 E_4 
Stack 13
M_1 Z_107 Z_108 I_7 G_3 
Stack 14
G_7 C_0 J_2 D_2 F_5 
Stack 15
I_0 L_0 J_3 K_5 N_1 
Stack 16
F_6 H_2 H_3 E_3 I_6 
Stack 17
I_3 H_4 Z_109 N_0 J_0 
