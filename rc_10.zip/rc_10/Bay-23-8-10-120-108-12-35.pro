Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
A_3 I_2 A_8 G_5 J_3 G_1 
Stack 1
C_3 C_2 G_8 B_6 F_10 H_7 
Stack 2
H_5 E_10 F_1 B_1 E_6 Z_100 
Stack 3
D_9 D_1 I_4 A_9 J_7 J_5 
Stack 4
C_4 F_8 F_12 D_2 E_11 D_3 
Stack 5
F_6 Z_101 B_7 H_6 I_5 
Stack 6
G_7 Z_102 D_10 B_8 E_2 
Stack 7
E_4 H_4 F_4 E_9 I_6 
Stack 8
D_5 E_0 A_2 F_13 I_8 
Stack 9
B_4 Z_103 I_0 J_2 D_7 
Stack 10
I_7 C_0 H_2 G_0 Z_104 
Stack 11
Z_105 D_4 F_2 C_7 C_8 
Stack 12
A_4 J_1 D_8 D_0 A_0 
Stack 13
F_0 E_5 C_9 Z_106 I_1 
Stack 14
F_7 H_0 J_4 A_7 G_10 
Stack 15
Z_107 G_4 C_5 B_5 I_9 
Stack 16
D_11 A_6 I_3 C_10 B_3 
Stack 17
H_8 Z_108 G_2 G_9 C_1 
Stack 18
A_1 Z_109 F_3 F_11 J_6 
Stack 19
E_1 B_2 I_10 H_1 H_3 
Stack 20
Z_110 G_11 D_6 F_5 B_0 
Stack 21
E_3 J_0 C_6 Z_111 E_7 
Stack 22
A_5 F_9 G_3 G_6 E_8 
