Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_5 B_5 C_1 C_2 
Stack 1
D_7 D_5 B_7 B_1 
Stack 2
E_1 D_1 B_2 Z_100 
Stack 3
A_8 C_8 E_3 Z_101 
Stack 4
Z_102 A_0 A_3 E_6 
Stack 5
D_9 A_7 B_3 A_4 
Stack 6
B_9 E_4 D_2 Z_103 
Stack 7
C_6 C_5 D_3 E_7 
Stack 8
D_4 C_3 Z_104 C_0 
Stack 9
B_8 C_9 C_4 Z_105 
Stack 10
B_6 E_0 B_0 D_8 
Stack 11
D_0 E_2 A_1 C_10 
Stack 12
E_5 A_6 C_7 
Stack 13
A_2 D_6 B_4 
