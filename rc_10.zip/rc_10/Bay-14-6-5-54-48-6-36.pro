Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_5 C_7 C_8 B_2 
Stack 1
E_8 C_6 E_1 A_2 
Stack 2
Z_100 D_7 Z_101 E_3 
Stack 3
A_7 B_7 B_4 C_5 
Stack 4
A_4 A_1 E_5 D_9 
Stack 5
D_10 D_4 C_3 D_6 
Stack 6
D_8 C_4 B_8 Z_102 
Stack 7
E_0 Z_103 B_3 B_6 
Stack 8
D_1 D_0 E_2 A_5 
Stack 9
D_3 D_5 D_2 E_6 
Stack 10
C_0 C_2 C_9 A_6 
Stack 11
B_1 B_0 Z_104 C_1 
Stack 12
A_3 E_4 B_9 
Stack 13
E_7 A_0 Z_105 
