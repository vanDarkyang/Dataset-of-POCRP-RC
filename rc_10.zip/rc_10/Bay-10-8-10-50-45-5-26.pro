Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_3 Z_100 I_2 H_2 J_1 
Stack 1
F_1 H_3 F_2 D_0 B_2 
Stack 2
E_5 D_2 J_2 Z_101 G_4 
Stack 3
E_2 F_0 E_4 D_3 G_3 
Stack 4
F_4 I_0 H_4 Z_102 C_1 
Stack 5
G_0 Z_103 Z_104 E_3 C_0 
Stack 6
F_5 D_1 A_2 H_0 B_0 
Stack 7
G_1 J_0 I_3 A_0 C_2 
Stack 8
G_5 A_1 F_3 G_2 E_1 
Stack 9
E_0 H_1 B_1 I_1 C_3 
