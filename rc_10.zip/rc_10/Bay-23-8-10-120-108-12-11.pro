Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
J_3 D_3 Z_100 B_6 F_0 B_3 
Stack 1
B_1 A_5 H_8 G_3 E_3 F_7 
Stack 2
E_11 A_7 G_5 G_9 G_2 Z_101 
Stack 3
H_9 C_1 A_3 G_1 C_0 D_4 
Stack 4
I_6 F_2 E_2 Z_102 I_4 G_11 
Stack 5
D_9 D_1 E_5 Z_103 H_10 
Stack 6
B_8 D_5 C_9 D_7 J_0 
Stack 7
D_0 B_0 H_1 E_10 C_8 
Stack 8
E_9 A_1 Z_104 A_0 F_4 
Stack 9
B_4 J_6 J_9 H_0 J_2 
Stack 10
J_1 D_10 D_2 A_2 F_5 
Stack 11
F_1 Z_105 C_2 B_7 H_7 
Stack 12
E_6 D_11 C_10 J_5 F_6 
Stack 13
Z_106 H_5 I_7 G_7 D_6 
Stack 14
I_3 J_8 D_8 A_4 A_8 
Stack 15
I_1 Z_107 C_7 A_6 G_6 
Stack 16
Z_108 I_0 G_10 E_7 B_2 
Stack 17
J_4 G_4 G_0 G_12 C_6 
Stack 18
E_1 I_8 B_5 E_8 H_3 
Stack 19
C_4 I_5 E_0 F_9 C_3 
Stack 20
J_7 F_8 C_5 F_3 G_8 
Stack 21
H_6 Z_109 Z_110 H_4 H_2 
Stack 22
I_2 E_4 B_9 F_10 Z_111 
