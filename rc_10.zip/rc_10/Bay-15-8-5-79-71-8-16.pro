Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_10 C_1 E_0 E_3 B_9 B_0 
Stack 1
B_2 C_8 E_7 E_12 Z_100 D_12 
Stack 2
Z_101 B_14 Z_102 E_10 A_9 E_11 
Stack 3
D_7 C_3 C_4 A_8 A_5 Z_103 
Stack 4
A_7 D_13 B_8 A_11 D_10 
Stack 5
B_1 D_1 Z_104 D_3 D_5 
Stack 6
C_6 D_6 B_3 A_3 C_2 
Stack 7
B_10 A_10 C_9 E_2 E_4 
Stack 8
Z_105 D_2 C_0 A_4 C_7 
Stack 9
B_6 D_11 C_11 D_9 D_0 
Stack 10
B_12 D_8 A_2 E_8 C_13 
Stack 11
E_1 E_9 B_11 C_12 A_0 
Stack 12
A_6 D_4 B_15 E_5 B_5 
Stack 13
Z_106 B_4 A_1 E_14 E_13 
Stack 14
B_13 C_5 B_7 E_6 Z_107 
