Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_6 M_3 I_0 B_1 
Stack 1
K_2 G_5 J_0 J_5 
Stack 2
I_6 Z_100 I_1 B_3 
Stack 3
O_1 H_4 K_0 F_0 
Stack 4
H_8 D_4 F_5 K_4 
Stack 5
A_2 I_7 M_2 K_3 
Stack 6
D_3 G_4 F_3 H_6 
Stack 7
N_1 E_4 C_3 G_2 
Stack 8
G_7 D_0 A_1 J_3 
Stack 9
H_7 G_6 B_0 H_2 
Stack 10
Z_101 G_3 L_5 L_1 
Stack 11
C_2 M_4 Z_102 D_1 
Stack 12
I_5 C_1 K_5 L_0 
Stack 13
F_1 H_0 M_1 E_0 
Stack 14
Z_103 Z_104 H_1 A_0 
Stack 15
Z_105 I_2 F_4 J_1 
Stack 16
E_1 I_4 L_3 L_2 
Stack 17
E_2 M_0 F_2 Z_106 
Stack 18
Z_107 H_5 K_1 N_0 
Stack 19
O_2 Z_108 J_6 G_0 
Stack 20
D_2 N_2 B_2 C_0 
Stack 21
J_2 L_4 I_3 E_3 
Stack 22
C_4 Z_109 H_3 
Stack 23
O_0 J_4 G_1 
