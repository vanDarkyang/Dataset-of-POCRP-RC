Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_3 Z_100 C_9 A_4 D_7 
Stack 1
D_0 A_6 A_2 A_0 D_8 
Stack 2
E_1 E_4 C_4 D_5 B_4 
Stack 3
Z_101 B_5 C_1 Z_102 B_8 
Stack 4
B_2 B_6 D_2 C_6 A_5 
Stack 5
A_1 C_0 B_1 D_6 C_7 
Stack 6
B_0 A_3 Z_103 E_0 E_2 
Stack 7
Z_104 C_3 Z_105 E_3 D_9 
Stack 8
D_3 C_5 C_2 D_1 C_10 
Stack 9
B_7 E_6 E_7 B_9 C_8 
Stack 10
E_5 A_7 D_4 A_8 
