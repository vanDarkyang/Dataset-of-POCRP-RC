Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_4 E_8 D_8 A_3 Z_100 
Stack 1
A_7 Z_101 Z_102 B_1 D_3 
Stack 2
E_6 B_4 B_0 D_10 A_4 
Stack 3
E_2 C_0 A_0 C_3 B_2 
Stack 4
C_1 A_8 D_6 C_2 Z_103 
Stack 5
B_5 E_5 A_2 D_4 D_5 
Stack 6
E_0 E_7 D_2 E_1 D_9 
Stack 7
A_9 A_1 C_8 A_5 A_6 
Stack 8
C_4 C_7 E_3 D_1 B_6 
Stack 9
Z_104 D_0 C_10 D_7 B_3 
Stack 10
C_9 C_5 C_6 Z_105 
