Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
D_4 F_1 C_0 G_4 E_1 
Stack 1
H_1 A_0 D_0 D_2 F_2 
Stack 2
F_5 E_3 E_4 G_2 J_2 
Stack 3
E_0 Z_100 B_2 Z_101 E_5 
Stack 4
B_3 J_0 A_1 H_3 D_3 
Stack 5
G_1 G_0 Z_102 I_2 I_1 
Stack 6
D_1 F_0 J_1 E_6 F_3 
Stack 7
Z_103 I_0 Z_104 H_2 H_0 
Stack 8
C_3 B_1 G_5 C_1 G_3 
Stack 9
D_5 B_0 E_2 F_4 C_2 
