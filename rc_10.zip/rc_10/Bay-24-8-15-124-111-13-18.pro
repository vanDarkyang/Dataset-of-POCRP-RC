Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
D_0 Z_100 N_3 E_2 A_0 N_4 
Stack 1
M_5 C_5 D_3 K_1 I_5 J_0 
Stack 2
Z_101 Z_102 A_3 M_4 N_2 M_1 
Stack 3
F_4 K_6 N_1 G_2 B_2 H_9 
Stack 4
I_1 G_3 O_1 H_11 F_5 
Stack 5
Z_103 I_2 K_2 D_1 Z_104 
Stack 6
D_4 G_0 J_9 I_10 O_0 
Stack 7
E_7 B_5 J_4 G_4 A_1 
Stack 8
H_6 J_6 L_0 G_7 N_0 
Stack 9
E_3 H_1 B_1 Z_105 M_2 
Stack 10
Z_106 A_4 I_4 D_6 L_2 
Stack 11
F_7 L_3 C_3 D_5 C_0 
Stack 12
H_8 B_3 I_3 L_1 K_3 
Stack 13
J_5 H_2 L_7 G_1 E_5 
Stack 14
J_1 L_5 L_4 K_0 H_4 
Stack 15
I_7 C_2 E_4 E_6 G_6 
Stack 16
D_2 H_0 H_10 C_4 G_5 
Stack 17
C_1 B_0 J_7 A_2 H_3 
Stack 18
Z_107 Z_108 B_4 F_2 Z_109 
Stack 19
L_6 I_9 I_0 Z_110 J_8 
Stack 20
K_5 J_3 E_0 E_1 I_8 
Stack 21
F_3 Z_111 H_7 F_8 F_6 
Stack 22
M_3 H_5 M_0 K_4 F_1 
Stack 23
I_6 J_2 Z_112 O_2 F_0 
