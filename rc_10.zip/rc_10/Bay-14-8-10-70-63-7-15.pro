Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_2 Z_100 B_4 A_1 A_2 
Stack 1
D_0 D_1 Z_101 H_5 I_0 
Stack 2
A_3 F_4 Z_102 F_1 E_3 
Stack 3
E_7 B_3 H_0 C_1 E_1 
Stack 4
E_6 B_1 H_2 G_6 E_8 
Stack 5
I_2 D_2 B_0 C_4 J_2 
Stack 6
G_0 J_1 F_6 G_3 E_4 
Stack 7
B_2 I_1 F_7 A_0 E_0 
Stack 8
Z_103 F_5 F_3 D_4 J_4 
Stack 9
J_3 G_2 J_0 I_5 E_5 
Stack 10
G_1 G_4 Z_104 C_0 G_5 
Stack 11
H_1 E_2 Z_105 H_3 F_8 
Stack 12
H_6 Z_106 I_4 C_3 I_3 
Stack 13
F_2 F_0 D_3 B_5 H_4 
