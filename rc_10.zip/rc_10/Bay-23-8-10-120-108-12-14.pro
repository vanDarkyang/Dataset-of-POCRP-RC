Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
D_3 C_8 Z_100 B_7 I_0 G_7 
Stack 1
B_1 Z_101 E_10 C_5 H_10 E_7 
Stack 2
D_7 F_1 B_3 D_6 Z_102 I_5 
Stack 3
Z_103 F_7 F_6 A_0 I_4 J_5 
Stack 4
I_6 F_2 H_2 A_4 I_7 C_2 
Stack 5
J_8 G_8 J_1 H_9 D_10 
Stack 6
E_6 E_2 H_6 B_5 Z_104 
Stack 7
Z_105 H_3 G_5 G_9 Z_106 
Stack 8
E_0 E_4 C_3 C_10 J_4 
Stack 9
I_1 A_8 D_0 B_4 B_8 
Stack 10
F_3 F_10 G_4 Z_107 F_0 
Stack 11
E_9 J_3 G_1 H_7 H_5 
Stack 12
E_11 E_1 A_2 H_4 I_8 
Stack 13
G_0 D_8 F_8 I_3 I_10 
Stack 14
Z_108 A_5 G_2 E_8 B_2 
Stack 15
H_1 D_9 J_6 F_4 B_6 
Stack 16
H_0 J_0 D_5 A_3 A_6 
Stack 17
C_0 E_5 C_9 G_10 G_6 
Stack 18
G_11 C_7 G_3 E_3 Z_109 
Stack 19
A_7 I_9 Z_110 Z_111 E_12 
Stack 20
J_2 H_8 D_2 B_9 C_4 
Stack 21
F_9 A_1 J_7 D_4 F_5 
Stack 22
I_2 C_1 D_1 C_6 B_0 
