Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_1 Z_100 Z_101 D_3 F_3 
Stack 1
D_5 H_3 E_5 D_0 H_4 
Stack 2
D_2 E_3 Z_102 E_0 E_4 
Stack 3
F_1 I_2 B_3 G_2 Z_103 
Stack 4
C_2 C_3 J_0 I_0 F_5 
Stack 5
F_2 G_4 B_2 F_0 A_1 
Stack 6
J_1 G_3 G_5 B_0 C_1 
Stack 7
C_0 I_3 A_0 E_1 Z_104 
Stack 8
G_0 E_2 D_4 I_1 H_1 
Stack 9
G_1 H_2 F_4 H_0 D_1 
