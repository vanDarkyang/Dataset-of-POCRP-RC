Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_10 A_6 B_6 A_2 
Stack 1
A_3 A_9 C_10 C_6 
Stack 2
C_5 Z_100 A_8 B_4 
Stack 3
A_1 C_1 C_2 C_4 
Stack 4
B_12 C_3 B_10 A_11 
Stack 5
A_5 C_9 A_7 B_8 
Stack 6
B_1 A_13 B_11 C_0 
Stack 7
Z_101 C_7 B_9 B_3 
Stack 8
A_12 Z_102 Z_103 Z_104 
Stack 9
B_0 A_0 B_13 A_4 
Stack 10
C_11 B_2 B_7 
Stack 11
B_5 C_8 C_12 
