Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
Z_100 B_1 B_8 A_10 
Stack 1
B_5 C_0 C_1 C_6 
Stack 2
A_7 B_11 B_3 Z_101 
Stack 3
Z_102 Z_103 C_4 C_13 
Stack 4
A_2 C_12 C_2 A_12 
Stack 5
B_2 A_8 C_11 B_10 
Stack 6
C_5 B_7 C_3 Z_104 
Stack 7
B_4 A_1 B_12 C_8 
Stack 8
A_3 A_0 A_4 A_9 
Stack 9
C_10 A_13 A_11 A_6 
Stack 10
C_9 B_9 B_6 
Stack 11
B_0 C_7 A_5 
