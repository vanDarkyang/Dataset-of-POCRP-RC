Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_5 B_1 D_0 C_3 Z_100 
Stack 1
E_8 A_3 Z_101 B_8 C_5 
Stack 2
A_6 E_7 C_2 B_3 Z_102 
Stack 3
A_9 C_7 B_0 E_3 D_4 
Stack 4
A_4 C_6 E_4 D_2 Z_103 
Stack 5
D_7 D_5 A_0 C_9 B_6 
Stack 6
D_6 B_7 C_8 E_0 A_5 
Stack 7
E_1 A_1 E_2 B_9 E_6 
Stack 8
D_1 D_3 B_10 A_7 A_8 
Stack 9
Z_104 C_4 B_4 B_2 C_1 
Stack 10
C_0 Z_105 E_5 A_2 
