Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_3 E_4 F_5 Z_100 
Stack 1
D_5 E_1 Z_101 I_2 
Stack 2
H_3 D_3 I_1 Z_102 
Stack 3
E_6 J_0 F_1 F_0 
Stack 4
A_1 J_1 E_5 H_4 
Stack 5
E_2 C_1 A_0 D_0 
Stack 6
E_0 A_2 C_2 G_1 
Stack 7
D_1 I_0 G_0 Z_103 
Stack 8
H_2 F_4 H_1 Z_104 
Stack 9
C_0 B_2 H_0 B_1 
Stack 10
E_3 B_3 B_0 D_4 
Stack 11
F_2 D_2 J_2 
Stack 12
G_2 F_6 F_3 
