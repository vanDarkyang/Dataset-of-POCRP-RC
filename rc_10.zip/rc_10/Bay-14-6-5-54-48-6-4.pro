Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_5 B_1 A_4 C_5 
Stack 1
E_8 C_9 C_8 E_0 
Stack 2
A_8 A_2 A_5 E_6 
Stack 3
E_7 C_6 B_3 C_1 
Stack 4
A_0 E_2 D_3 Z_100 
Stack 5
A_9 Z_101 B_8 E_4 
Stack 6
B_9 A_3 D_4 C_0 
Stack 7
D_7 Z_102 Z_103 E_1 
Stack 8
C_2 D_8 D_5 D_1 
Stack 9
B_4 E_3 C_4 C_7 
Stack 10
C_3 Z_104 D_0 A_6 
Stack 11
D_6 A_1 B_7 B_0 
Stack 12
D_2 A_7 B_2 
Stack 13
B_6 B_5 Z_105 
