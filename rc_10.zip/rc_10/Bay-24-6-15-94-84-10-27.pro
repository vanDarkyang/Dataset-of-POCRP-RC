Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_1 F_2 F_0 L_3 
Stack 1
E_2 L_2 I_7 O_2 
Stack 2
M_3 J_3 H_0 I_2 
Stack 3
M_4 N_3 G_1 K_2 
Stack 4
J_5 F_5 H_2 D_1 
Stack 5
B_0 J_7 I_3 K_0 
Stack 6
H_3 F_1 I_1 C_2 
Stack 7
L_1 I_5 G_3 D_4 
Stack 8
C_0 Z_100 H_4 K_1 
Stack 9
M_1 G_4 K_5 E_4 
Stack 10
I_0 J_6 H_1 E_3 
Stack 11
K_4 B_1 Z_101 D_2 
Stack 12
E_5 L_0 Z_102 H_5 
Stack 13
Z_103 F_3 O_0 J_4 
Stack 14
J_2 C_1 K_3 A_0 
Stack 15
E_6 I_6 D_3 N_0 
Stack 16
B_2 Z_104 Z_105 N_1 
Stack 17
J_0 H_6 G_2 M_0 
Stack 18
I_4 C_3 D_5 F_6 
Stack 19
G_0 N_2 E_0 G_6 
Stack 20
D_0 Z_106 J_1 H_7 
Stack 21
Z_107 A_1 Z_108 O_1 
Stack 22
G_7 M_2 G_5 
Stack 23
Z_109 F_4 G_8 
