Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
H_5 F_4 J_4 I_4 B_2 
Stack 1
Z_100 Z_101 E_5 J_0 H_0 
Stack 2
F_6 F_5 Z_102 H_3 Z_103 
Stack 3
B_0 D_2 A_4 I_3 C_1 
Stack 4
B_4 D_6 H_6 B_3 F_0 
Stack 5
G_0 D_1 H_1 C_0 F_2 
Stack 6
C_4 D_0 F_7 D_5 I_1 
Stack 7
D_3 A_2 G_2 G_1 C_2 
Stack 8
A_3 I_2 B_1 H_4 C_3 
Stack 9
E_6 E_2 Z_104 G_3 J_1 
Stack 10
J_2 G_5 F_3 A_0 E_4 
Stack 11
G_4 G_7 J_3 Z_105 E_3 
Stack 12
Z_106 E_1 E_0 H_2 A_1 
Stack 13
E_7 D_4 I_0 G_6 F_1 
