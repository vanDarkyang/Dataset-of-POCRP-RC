Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_2 F_3 A_3 D_3 H_2 
Stack 1
G_3 A_0 G_4 H_4 Z_100 
Stack 2
E_6 J_4 C_5 G_1 B_4 
Stack 3
H_0 F_2 G_6 E_2 B_5 
Stack 4
E_0 B_0 E_7 I_3 J_2 
Stack 5
C_4 Z_101 A_1 B_1 C_3 
Stack 6
C_0 F_1 D_4 I_2 Z_102 
Stack 7
B_2 C_1 D_0 Z_103 F_6 
Stack 8
H_1 J_3 D_5 G_5 E_4 
Stack 9
D_6 J_1 F_4 I_0 J_0 
Stack 10
E_5 G_0 I_5 F_5 G_2 
Stack 11
Z_104 Z_105 E_3 B_3 E_1 
Stack 12
Z_106 D_2 I_4 A_2 A_4 
Stack 13
D_7 I_1 D_1 H_3 F_0 
