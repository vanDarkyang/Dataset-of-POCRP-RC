Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_0 D_4 Z_100 E_1 
Stack 1
A_6 C_6 Z_101 E_2 
Stack 2
Z_102 A_4 B_9 C_0 
Stack 3
C_4 C_5 E_5 A_0 
Stack 4
E_6 B_1 C_2 Z_103 
Stack 5
D_1 D_0 D_7 D_3 
Stack 6
A_5 E_4 B_2 B_3 
Stack 7
B_8 Z_104 C_8 Z_105 
Stack 8
E_3 B_0 B_6 D_6 
Stack 9
C_9 C_10 E_7 D_9 
Stack 10
A_1 C_7 A_3 E_9 
Stack 11
B_4 B_5 E_8 D_8 
Stack 12
A_2 D_2 D_5 
Stack 13
B_7 C_1 C_3 
