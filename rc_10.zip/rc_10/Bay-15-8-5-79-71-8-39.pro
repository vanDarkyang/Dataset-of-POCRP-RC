Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_2 D_11 A_13 D_9 C_1 A_10 
Stack 1
A_12 B_11 A_9 A_4 E_1 D_6 
Stack 2
D_2 D_10 D_13 A_0 B_0 E_13 
Stack 3
Z_100 C_11 C_8 C_12 C_7 E_5 
Stack 4
D_3 B_12 E_14 E_7 B_7 
Stack 5
D_0 Z_101 Z_102 A_2 E_12 
Stack 6
D_1 A_6 C_10 A_8 Z_103 
Stack 7
C_9 D_8 E_2 D_7 D_12 
Stack 8
B_5 A_1 E_0 C_5 E_11 
Stack 9
Z_104 B_2 E_3 Z_105 C_6 
Stack 10
A_7 A_5 B_9 Z_106 B_8 
Stack 11
E_9 A_3 B_1 D_5 E_6 
Stack 12
B_6 E_8 D_4 B_10 B_13 
Stack 13
E_4 A_11 C_13 C_4 B_4 
Stack 14
Z_107 E_10 C_0 C_3 B_3 
