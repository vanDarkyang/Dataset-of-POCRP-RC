Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
Z_100 Z_101 E_3 B_12 
Stack 1
D_12 B_10 C_14 B_13 
Stack 2
B_14 D_2 B_1 B_8 
Stack 3
C_3 A_0 D_5 D_9 
Stack 4
B_11 A_12 D_8 C_1 
Stack 5
A_3 C_15 E_8 A_4 
Stack 6
C_11 B_2 C_13 C_9 
Stack 7
Z_102 B_6 E_7 Z_103 
Stack 8
C_4 A_9 C_5 Z_104 
Stack 9
B_9 E_12 Z_105 B_4 
Stack 10
B_7 B_15 D_6 A_10 
Stack 11
D_1 C_10 D_7 A_2 
Stack 12
A_6 A_11 D_0 E_0 
Stack 13
C_6 A_8 A_7 D_10 
Stack 14
C_8 E_5 B_3 D_3 
Stack 15
Z_106 E_1 B_5 A_1 
Stack 16
Z_107 E_4 C_7 D_4 
Stack 17
C_12 C_0 B_0 E_11 
Stack 18
E_2 C_2 E_6 E_9 
Stack 19
A_5 D_11 E_10 
