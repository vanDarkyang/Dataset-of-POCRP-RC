Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 G_3 I_1 F_3 Z_101 N_2 
Stack 1
A_1 L_2 F_0 K_1 Z_102 N_1 
Stack 2
E_0 F_5 Z_103 C_0 G_1 H_2 
Stack 3
I_7 K_4 G_5 O_0 H_5 E_5 
Stack 4
N_0 G_2 L_1 E_2 L_3 
Stack 5
F_1 C_2 I_3 H_7 H_0 
Stack 6
C_1 L_0 E_3 B_3 Z_104 
Stack 7
D_4 H_4 J_1 B_2 Z_105 
Stack 8
J_4 J_3 E_1 Z_106 F_4 
Stack 9
Z_107 H_1 D_1 A_2 D_2 
Stack 10
J_5 L_4 G_7 B_0 F_2 
Stack 11
Z_108 E_4 I_6 G_4 A_0 
Stack 12
J_2 H_3 K_3 C_3 I_0 
Stack 13
G_6 B_1 I_5 D_5 K_0 
Stack 14
M_0 D_3 H_6 M_2 M_1 
Stack 15
C_4 O_2 I_2 J_0 K_2 
Stack 16
D_0 O_1 Z_109 K_5 M_4 
Stack 17
I_4 G_0 G_8 M_3 N_3 
