Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_7 E_1 D_9 D_8 
Stack 1
D_0 E_3 D_1 Z_100 
Stack 2
C_3 C_5 A_0 E_6 
Stack 3
C_9 Z_101 E_7 A_8 
Stack 4
A_6 B_6 A_4 D_2 
Stack 5
C_8 D_6 B_4 Z_102 
Stack 6
C_2 E_2 E_8 A_7 
Stack 7
D_7 B_3 Z_103 B_0 
Stack 8
Z_104 A_2 C_0 C_6 
Stack 9
B_2 A_9 E_9 B_5 
Stack 10
E_4 A_1 E_5 D_5 
Stack 11
Z_105 A_5 C_4 B_1 
Stack 12
B_7 E_0 D_4 
Stack 13
A_3 C_1 D_3 
