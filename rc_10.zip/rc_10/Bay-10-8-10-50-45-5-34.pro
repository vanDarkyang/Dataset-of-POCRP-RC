Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
I_2 E_3 E_4 H_3 E_0 
Stack 1
C_2 I_1 H_4 F_3 G_3 
Stack 2
E_5 Z_100 G_1 H_1 F_1 
Stack 3
B_1 G_4 Z_101 G_0 D_3 
Stack 4
Z_102 I_0 F_4 H_0 J_1 
Stack 5
E_1 C_0 A_2 C_1 D_5 
Stack 6
F_5 A_1 B_0 B_2 G_2 
Stack 7
F_0 H_2 J_2 Z_103 J_0 
Stack 8
F_2 D_1 C_4 E_2 D_2 
Stack 9
A_0 Z_104 C_3 D_4 D_0 
