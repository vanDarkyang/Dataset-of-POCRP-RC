Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_0 Z_100 C_11 Z_101 
Stack 1
B_2 B_4 C_3 B_10 
Stack 2
Z_102 A_3 Z_103 B_9 
Stack 3
A_5 C_1 C_4 C_10 
Stack 4
B_3 A_4 C_9 C_12 
Stack 5
B_5 A_11 C_13 A_6 
Stack 6
Z_104 B_13 A_1 C_5 
Stack 7
A_12 B_12 C_0 A_7 
Stack 8
C_8 C_6 C_7 A_8 
Stack 9
C_2 A_2 B_7 A_0 
Stack 10
B_11 A_9 A_10 
Stack 11
B_6 B_8 B_1 
