Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
C_3 C_6 J_2 H_10 E_9 D_4 
Stack 1
G_7 E_4 Z_100 H_8 D_5 E_3 
Stack 2
E_5 B_6 B_1 C_0 I_0 J_4 
Stack 3
A_8 D_3 J_5 E_8 H_9 G_4 
Stack 4
I_8 I_7 C_7 A_0 H_0 H_2 
Stack 5
J_0 G_0 A_7 Z_101 F_5 
Stack 6
J_1 E_2 E_11 E_6 D_2 
Stack 7
I_10 I_3 D_6 C_8 E_1 
Stack 8
B_2 Z_102 G_1 G_8 Z_103 
Stack 9
H_4 B_5 D_1 A_3 B_4 
Stack 10
Z_104 J_6 H_1 I_1 H_6 
Stack 11
D_7 D_8 F_12 D_9 A_2 
Stack 12
A_6 C_1 I_4 E_7 I_5 
Stack 13
B_7 Z_105 Z_106 Z_107 E_12 
Stack 14
F_2 B_8 E_0 C_9 G_6 
Stack 15
H_7 F_9 C_5 F_3 I_2 
Stack 16
F_6 G_9 F_4 F_0 Z_108 
Stack 17
I_9 B_3 J_3 G_10 C_2 
Stack 18
C_4 Z_109 F_1 I_6 H_3 
Stack 19
D_0 F_10 H_5 A_4 A_5 
Stack 20
C_10 Z_110 Z_111 E_13 F_8 
Stack 21
G_5 E_10 F_13 A_1 G_3 
Stack 22
G_2 F_7 B_9 B_0 F_11 
