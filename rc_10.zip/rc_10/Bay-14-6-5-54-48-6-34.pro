Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_1 E_0 Z_100 A_6 
Stack 1
C_4 D_0 E_1 B_7 
Stack 2
B_9 D_3 B_3 E_3 
Stack 3
D_9 B_1 B_8 C_7 
Stack 4
Z_101 E_6 Z_102 C_2 
Stack 5
A_7 C_9 C_8 Z_103 
Stack 6
B_5 A_5 Z_104 A_0 
Stack 7
A_4 A_8 A_3 B_0 
Stack 8
C_3 E_2 A_1 D_1 
Stack 9
E_8 B_4 E_5 C_6 
Stack 10
B_2 D_6 D_7 D_5 
Stack 11
B_6 C_5 E_4 A_2 
Stack 12
C_0 Z_105 D_8 
Stack 13
D_2 D_4 E_7 
