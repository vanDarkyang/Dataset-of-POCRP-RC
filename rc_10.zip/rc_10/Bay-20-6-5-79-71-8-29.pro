Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
D_2 A_2 C_14 D_9 
Stack 1
E_8 A_7 D_7 A_10 
Stack 2
B_10 C_4 Z_100 A_1 
Stack 3
Z_101 Z_102 Z_103 B_0 
Stack 4
A_14 D_13 E_0 D_3 
Stack 5
B_11 C_7 C_0 B_4 
Stack 6
A_9 D_1 E_5 E_4 
Stack 7
D_8 B_12 C_8 D_15 
Stack 8
A_3 B_7 D_12 C_5 
Stack 9
A_11 A_5 C_13 B_2 
Stack 10
C_3 A_8 C_12 E_10 
Stack 11
B_3 D_4 E_2 A_0 
Stack 12
B_5 C_9 D_11 A_12 
Stack 13
D_14 E_6 E_11 Z_104 
Stack 14
Z_105 A_4 D_0 C_2 
Stack 15
E_1 B_9 Z_106 A_6 
Stack 16
A_13 D_6 E_7 C_10 
Stack 17
B_1 Z_107 E_3 C_1 
Stack 18
B_8 C_6 D_10 C_11 
Stack 19
B_6 E_9 D_5 
