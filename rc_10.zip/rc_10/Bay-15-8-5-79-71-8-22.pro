Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
E_0 E_10 A_5 D_0 E_11 Z_100 
Stack 1
B_14 A_2 D_1 A_3 B_5 E_1 
Stack 2
Z_101 C_13 C_9 D_4 C_1 B_6 
Stack 3
D_7 B_9 C_2 A_11 C_6 C_3 
Stack 4
E_6 A_13 B_12 A_6 Z_102 
Stack 5
A_12 D_13 Z_103 B_4 D_11 
Stack 6
A_0 A_8 E_7 A_1 A_4 
Stack 7
C_12 B_7 B_10 B_8 D_3 
Stack 8
B_2 Z_104 B_13 E_8 E_9 
Stack 9
D_8 Z_105 B_0 D_12 A_10 
Stack 10
E_3 C_11 C_14 C_0 Z_106 
Stack 11
C_8 D_10 B_11 B_3 E_5 
Stack 12
D_6 C_10 D_9 E_2 D_2 
Stack 13
B_1 D_5 A_9 A_7 C_7 
Stack 14
A_14 E_4 C_5 C_4 Z_107 
