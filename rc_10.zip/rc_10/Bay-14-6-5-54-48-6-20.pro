Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_7 E_3 C_3 B_4 
Stack 1
A_1 A_7 E_0 C_1 
Stack 2
A_3 B_9 D_5 D_1 
Stack 3
E_5 D_6 Z_100 Z_101 
Stack 4
B_6 C_8 E_8 C_2 
Stack 5
C_9 B_8 D_8 D_7 
Stack 6
B_7 Z_102 C_4 Z_103 
Stack 7
E_6 A_8 A_2 D_3 
Stack 8
Z_104 B_3 A_5 C_5 
Stack 9
C_6 B_2 A_4 A_0 
Stack 10
C_7 E_2 A_6 B_0 
Stack 11
D_4 E_9 D_2 E_4 
Stack 12
D_0 Z_105 E_1 
Stack 13
B_1 B_5 C_0 
