Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_7 Z_100 A_2 B_4 E_6 
Stack 1
D_0 B_9 Z_101 E_8 A_7 
Stack 2
C_2 A_3 A_1 C_6 D_2 
Stack 3
Z_102 E_1 Z_103 Z_104 B_6 
Stack 4
A_5 E_3 E_0 E_9 A_6 
Stack 5
C_8 C_4 C_0 E_5 B_0 
Stack 6
C_1 D_5 D_9 C_3 C_5 
Stack 7
D_7 B_8 D_1 D_4 B_7 
Stack 8
B_10 D_6 A_0 D_3 Z_105 
Stack 9
B_2 E_2 E_7 D_8 B_1 
Stack 10
E_4 B_3 A_4 B_5 
