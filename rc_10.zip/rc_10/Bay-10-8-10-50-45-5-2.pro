Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_1 J_2 C_1 H_1 I_1 
Stack 1
E_2 B_1 G_3 A_0 D_0 
Stack 2
F_1 G_1 I_2 E_0 Z_100 
Stack 3
E_3 G_5 E_5 H_2 D_2 
Stack 4
C_2 Z_101 Z_102 G_2 J_0 
Stack 5
C_3 I_0 B_0 F_2 F_4 
Stack 6
B_2 F_5 Z_103 E_1 I_3 
Stack 7
C_0 Z_104 F_0 D_3 D_1 
Stack 8
F_3 D_4 G_4 E_6 G_0 
Stack 9
H_0 A_2 E_4 H_3 J_1 
