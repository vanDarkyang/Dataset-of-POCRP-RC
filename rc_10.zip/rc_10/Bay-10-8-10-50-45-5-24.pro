Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_0 Z_100 C_2 C_1 B_2 
Stack 1
C_0 J_1 F_2 A_1 H_2 
Stack 2
E_1 G_0 E_2 D_0 F_0 
Stack 3
E_0 B_1 F_4 D_3 Z_101 
Stack 4
G_5 G_4 F_6 G_3 Z_102 
Stack 5
G_1 J_2 E_4 Z_103 E_6 
Stack 6
G_2 E_5 D_4 H_1 Z_104 
Stack 7
F_3 J_0 H_0 D_2 I_1 
Stack 8
E_3 B_3 A_0 C_3 F_5 
Stack 9
F_1 C_4 I_0 D_1 I_2 
