Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
E_12 D_11 A_8 B_3 D_0 Z_100 
Stack 1
B_5 Z_101 A_1 B_13 E_0 A_0 
Stack 2
C_14 Z_102 E_5 A_3 E_10 C_2 
Stack 3
B_8 A_9 A_5 D_10 C_3 E_3 
Stack 4
C_4 D_9 Z_103 D_3 A_11 
Stack 5
C_6 D_13 E_2 E_13 D_8 
Stack 6
B_0 Z_104 D_6 E_9 B_4 
Stack 7
C_11 B_12 Z_105 B_9 Z_106 
Stack 8
E_14 A_6 B_2 C_8 C_13 
Stack 9
B_1 B_10 B_11 E_1 C_1 
Stack 10
E_6 C_9 E_11 E_4 A_2 
Stack 11
C_5 E_7 C_7 C_0 A_7 
Stack 12
A_10 B_6 D_5 D_1 A_4 
Stack 13
Z_107 D_2 C_12 C_10 D_7 
Stack 14
E_8 B_7 D_4 D_14 D_12 
