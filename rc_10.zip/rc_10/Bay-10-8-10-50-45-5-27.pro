Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
Z_100 Z_101 F_4 I_1 C_4 
Stack 1
C_2 E_6 J_2 C_0 H_1 
Stack 2
B_2 I_2 F_2 H_3 G_2 
Stack 3
E_2 D_4 D_3 C_1 B_3 
Stack 4
F_0 E_0 G_0 G_1 F_3 
Stack 5
I_0 H_0 B_0 I_3 F_5 
Stack 6
E_1 Z_102 J_0 E_4 G_3 
Stack 7
D_1 D_2 Z_103 A_0 E_3 
Stack 8
E_5 B_1 J_1 F_1 H_2 
Stack 9
D_0 H_4 Z_104 C_3 G_4 
