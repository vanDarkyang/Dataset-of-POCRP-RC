Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_0 H_0 C_1 Z_100 
Stack 1
H_1 G_2 J_1 E_4 
Stack 2
F_1 D_1 F_2 Z_101 
Stack 3
G_4 D_3 G_0 E_1 
Stack 4
I_1 B_1 G_1 I_0 
Stack 5
F_3 F_0 J_2 E_2 
Stack 6
Z_102 E_3 H_3 E_5 
Stack 7
Z_103 G_3 D_4 C_3 
Stack 8
J_0 I_3 F_5 Z_104 
Stack 9
H_4 A_0 H_2 E_0 
Stack 10
D_0 I_2 A_1 B_3 
Stack 11
C_0 C_2 F_4 
Stack 12
D_2 E_6 B_2 
