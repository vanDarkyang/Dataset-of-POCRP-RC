Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
D_1 E_7 Z_100 Z_101 
Stack 1
D_2 A_5 C_11 D_6 
Stack 2
Z_102 D_8 E_4 C_14 
Stack 3
A_2 D_10 E_13 B_12 
Stack 4
E_5 E_1 B_13 E_2 
Stack 5
C_10 B_2 C_15 B_9 
Stack 6
E_3 D_12 C_3 A_11 
Stack 7
Z_103 C_4 D_0 D_3 
Stack 8
D_11 E_0 Z_104 Z_105 
Stack 9
D_7 D_9 A_7 B_10 
Stack 10
Z_106 E_12 A_10 E_6 
Stack 11
C_6 Z_107 C_7 D_5 
Stack 12
C_1 C_0 A_4 B_8 
Stack 13
C_12 C_9 A_1 C_5 
Stack 14
D_4 D_13 B_5 C_13 
Stack 15
A_3 A_8 B_3 E_14 
Stack 16
E_8 C_8 A_6 B_0 
Stack 17
B_1 B_7 A_0 E_10 
Stack 18
E_9 A_9 C_2 B_11 
Stack 19
B_6 B_4 E_11 
