Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
J_1 F_7 D_2 J_4 
Stack 1
E_0 F_8 Z_100 H_2 
Stack 2
Z_101 E_5 I_2 A_3 
Stack 3
Z_102 C_4 E_6 B_4 
Stack 4
Z_103 I_0 Z_104 G_3 
Stack 5
F_4 J_0 I_1 D_4 
Stack 6
C_0 Z_105 G_6 C_2 
Stack 7
C_6 C_5 C_3 D_6 
Stack 8
D_0 I_3 E_2 E_1 
Stack 9
G_4 E_3 G_1 J_3 
Stack 10
F_6 F_5 H_4 H_0 
Stack 11
E_4 B_2 B_3 F_0 
Stack 12
A_2 A_1 H_3 I_4 
Stack 13
J_2 G_0 C_1 I_5 
Stack 14
F_2 F_1 D_5 B_0 
Stack 15
G_2 D_3 F_3 H_5 
Stack 16
Z_106 G_5 H_1 
Stack 17
A_0 B_1 D_1 
