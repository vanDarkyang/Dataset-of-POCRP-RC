Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_3 C_12 B_7 Z_100 E_10 E_1 
Stack 1
B_12 A_12 B_2 A_4 E_0 D_10 
Stack 2
A_0 B_4 D_12 A_13 C_2 B_9 
Stack 3
D_6 C_9 E_12 E_7 D_13 A_6 
Stack 4
C_8 B_8 E_11 D_2 B_13 
Stack 5
D_4 C_5 B_3 A_2 E_9 
Stack 6
C_6 D_0 Z_101 D_8 A_7 
Stack 7
C_1 E_2 E_4 D_5 E_3 
Stack 8
E_8 Z_102 D_1 C_4 D_7 
Stack 9
A_8 D_3 E_5 A_10 B_10 
Stack 10
C_10 A_5 B_14 D_11 B_0 
Stack 11
C_0 A_1 C_14 C_11 Z_103 
Stack 12
C_7 Z_104 A_9 A_11 E_6 
Stack 13
Z_105 B_6 D_9 B_1 Z_106 
Stack 14
B_5 C_13 B_11 C_3 Z_107 
