Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
E_3 B_5 G_2 A_1 C_1 
Stack 1
H_0 Z_100 D_6 E_5 D_2 
Stack 2
F_2 G_0 H_1 D_4 I_3 
Stack 3
Z_101 C_2 F_5 Z_102 I_2 
Stack 4
Z_103 F_7 H_6 Z_104 Z_105 
Stack 5
G_1 J_4 D_5 H_5 F_0 
Stack 6
F_1 E_8 C_0 J_0 B_0 
Stack 7
E_0 E_4 G_4 C_3 E_7 
Stack 8
F_8 I_5 B_2 D_0 J_2 
Stack 9
Z_106 D_3 C_4 H_4 E_1 
Stack 10
B_1 I_1 D_1 H_3 A_2 
Stack 11
J_1 J_3 E_2 I_4 F_4 
Stack 12
A_0 F_3 E_6 F_6 B_4 
Stack 13
I_0 G_3 B_3 D_7 H_2 
