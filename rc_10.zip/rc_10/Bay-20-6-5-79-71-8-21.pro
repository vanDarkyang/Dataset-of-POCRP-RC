Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_9 C_0 D_3 E_6 
Stack 1
C_2 B_8 C_14 A_7 
Stack 2
E_7 C_3 B_9 E_3 
Stack 3
B_4 E_13 C_12 E_10 
Stack 4
D_12 B_2 E_12 B_5 
Stack 5
C_4 C_7 Z_100 A_3 
Stack 6
A_5 A_14 B_12 D_8 
Stack 7
C_1 C_9 C_6 D_0 
Stack 8
D_1 E_11 C_10 Z_101 
Stack 9
E_4 D_11 A_6 Z_102 
Stack 10
Z_103 Z_104 E_0 D_10 
Stack 11
B_7 D_2 A_10 C_13 
Stack 12
A_4 Z_105 A_1 E_9 
Stack 13
Z_106 C_5 A_2 B_3 
Stack 14
D_6 B_1 C_8 D_9 
Stack 15
C_11 D_5 E_2 A_11 
Stack 16
B_11 A_8 B_6 Z_107 
Stack 17
B_10 E_1 B_0 E_8 
Stack 18
A_0 E_5 A_13 A_12 
Stack 19
D_13 D_7 D_4 
