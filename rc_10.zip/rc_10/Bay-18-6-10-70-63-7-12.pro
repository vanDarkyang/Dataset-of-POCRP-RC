Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
Z_100 D_7 B_2 H_2 
Stack 1
D_3 D_1 C_1 G_5 
Stack 2
F_4 D_0 F_1 B_3 
Stack 3
B_1 A_2 J_3 H_0 
Stack 4
B_5 I_3 E_0 Z_101 
Stack 5
Z_102 E_2 I_1 C_2 
Stack 6
C_5 G_4 I_5 Z_103 
Stack 7
D_4 Z_104 J_0 Z_105 
Stack 8
A_3 E_1 H_3 I_2 
Stack 9
E_7 D_5 I_4 C_3 
Stack 10
J_2 J_4 B_4 C_4 
Stack 11
G_3 E_6 C_0 J_1 
Stack 12
F_5 B_0 D_6 E_4 
Stack 13
E_8 Z_106 G_0 E_3 
Stack 14
F_2 H_5 H_4 A_1 
Stack 15
E_5 H_1 G_2 F_0 
Stack 16
F_3 F_6 A_0 
Stack 17
D_2 G_1 I_0 
