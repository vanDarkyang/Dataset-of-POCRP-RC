Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
J_1 A_0 I_1 F_1 
Stack 1
E_3 D_2 I_0 Z_100 
Stack 2
D_1 F_3 F_0 H_0 
Stack 3
J_0 J_2 C_2 D_3 
Stack 4
D_5 A_2 I_2 C_4 
Stack 5
G_4 B_2 E_1 Z_101 
Stack 6
F_4 I_3 D_4 H_3 
Stack 7
B_0 D_0 G_2 C_1 
Stack 8
G_3 F_2 B_1 E_5 
Stack 9
B_3 Z_102 H_2 E_0 
Stack 10
C_3 G_0 E_4 E_2 
Stack 11
Z_103 C_0 A_1 
Stack 12
H_1 G_1 Z_104 
