Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_2 I_1 L_2 M_1 
Stack 1
N_3 K_4 E_0 Z_100 
Stack 2
F_6 H_7 H_4 D_4 
Stack 3
B_3 Z_101 H_3 L_1 
Stack 4
C_3 C_0 Z_102 N_0 
Stack 5
D_3 G_0 A_2 N_2 
Stack 6
Z_103 L_0 H_6 F_0 
Stack 7
G_3 Z_104 O_0 B_1 
Stack 8
G_1 E_4 I_4 N_1 
Stack 9
G_7 F_1 M_4 B_0 
Stack 10
I_5 J_5 H_0 I_2 
Stack 11
H_8 D_1 I_7 D_2 
Stack 12
L_3 J_2 Z_105 M_0 
Stack 13
L_4 K_5 A_1 E_5 
Stack 14
I_6 H_2 I_0 J_4 
Stack 15
G_2 A_0 F_4 B_2 
Stack 16
F_2 K_3 C_1 H_9 
Stack 17
M_2 J_1 J_3 G_6 
Stack 18
D_0 F_3 Z_106 G_5 
Stack 19
F_5 I_3 H_5 H_1 
Stack 20
E_3 O_1 J_0 K_0 
Stack 21
E_2 K_2 G_4 K_1 
Stack 22
M_3 E_1 Z_107 
Stack 23
Z_108 I_8 Z_109 
