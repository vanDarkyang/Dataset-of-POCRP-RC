Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_2 F_0 M_0 K_5 
Stack 1
M_2 E_3 G_5 C_0 
Stack 2
Z_100 Z_101 I_1 J_5 
Stack 3
A_2 O_0 I_2 H_8 
Stack 4
K_3 H_6 I_4 C_4 
Stack 5
B_1 G_0 B_0 F_1 
Stack 6
H_7 D_4 M_1 G_2 
Stack 7
G_7 E_4 E_1 J_1 
Stack 8
J_2 M_3 D_2 Z_102 
Stack 9
F_3 F_6 Z_103 Z_104 
Stack 10
D_3 L_0 G_4 N_3 
Stack 11
I_0 E_0 C_3 N_1 
Stack 12
M_4 C_1 E_5 Z_105 
Stack 13
J_3 K_2 Z_106 I_6 
Stack 14
Z_107 I_3 F_2 E_2 
Stack 15
F_4 H_3 H_5 J_6 
Stack 16
D_1 A_1 L_1 Z_108 
Stack 17
I_5 G_6 D_0 K_4 
Stack 18
H_9 N_2 Z_109 F_5 
Stack 19
L_4 H_4 K_0 B_3 
Stack 20
G_1 B_2 K_1 N_0 
Stack 21
H_0 H_2 L_3 O_1 
Stack 22
G_3 J_4 A_0 
Stack 23
L_2 J_0 H_1 
