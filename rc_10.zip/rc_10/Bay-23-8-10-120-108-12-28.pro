Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
B_3 B_0 I_6 A_8 E_7 F_1 
Stack 1
H_4 E_11 J_7 G_10 F_9 C_0 
Stack 2
A_7 B_6 J_2 E_0 C_8 C_7 
Stack 3
E_2 C_2 D_4 I_4 G_3 D_3 
Stack 4
I_7 H_6 Z_100 Z_101 J_0 A_3 
Stack 5
Z_102 G_8 F_12 B_9 C_5 
Stack 6
J_3 Z_103 G_7 C_10 A_0 
Stack 7
Z_104 D_7 B_2 A_2 B_7 
Stack 8
Z_105 D_0 E_12 J_6 I_3 
Stack 9
B_10 F_8 B_8 E_8 H_0 
Stack 10
I_2 A_1 D_8 E_6 E_3 
Stack 11
G_9 D_2 A_5 I_0 F_5 
Stack 12
Z_106 Z_107 C_6 Z_108 G_1 
Stack 13
F_0 C_1 H_2 H_10 G_4 
Stack 14
J_4 H_5 I_1 J_5 F_7 
Stack 15
D_5 G_6 F_6 I_5 A_6 
Stack 16
E_5 G_5 E_1 H_1 G_0 
Stack 17
D_9 E_10 F_10 Z_109 E_9 
Stack 18
Z_110 H_9 H_8 B_4 C_9 
Stack 19
C_3 F_2 A_4 A_9 H_3 
Stack 20
C_4 G_2 J_1 G_11 B_5 
Stack 21
B_1 D_10 H_7 F_3 D_1 
Stack 22
D_6 F_11 Z_111 E_4 F_4 
