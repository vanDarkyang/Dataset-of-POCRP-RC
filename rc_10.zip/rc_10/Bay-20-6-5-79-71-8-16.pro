Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_11 D_2 A_5 B_7 
Stack 1
B_1 Z_100 B_9 C_6 
Stack 2
A_4 A_12 B_12 A_11 
Stack 3
D_7 D_3 A_2 A_7 
Stack 4
A_9 D_11 B_5 D_10 
Stack 5
B_0 D_8 E_3 D_6 
Stack 6
C_7 E_9 E_12 C_2 
Stack 7
B_8 D_5 E_10 E_4 
Stack 8
D_0 B_2 A_10 C_9 
Stack 9
B_4 C_5 A_13 D_1 
Stack 10
B_10 E_0 D_4 C_13 
Stack 11
E_1 E_7 Z_101 A_1 
Stack 12
A_8 C_8 E_2 B_3 
Stack 13
D_14 C_4 A_6 E_13 
Stack 14
B_11 B_6 D_9 A_3 
Stack 15
C_1 A_0 E_8 Z_102 
Stack 16
C_10 Z_103 Z_104 D_12 
Stack 17
Z_105 Z_106 E_5 E_11 
Stack 18
C_3 C_0 Z_107 C_14 
Stack 19
D_13 C_12 E_6 
