Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
D_5 F_1 D_6 A_8 J_0 D_4 
Stack 1
I_5 C_2 H_7 J_5 I_9 G_2 
Stack 2
C_9 J_7 E_11 A_0 C_4 Z_100 
Stack 3
G_7 E_12 G_1 D_9 Z_101 D_3 
Stack 4
J_2 C_10 C_8 A_5 E_3 E_4 
Stack 5
B_6 I_2 C_11 G_11 Z_102 
Stack 6
D_10 E_5 B_1 F_5 B_3 
Stack 7
G_3 C_7 C_0 H_6 Z_103 
Stack 8
F_6 F_11 D_0 C_1 F_2 
Stack 9
Z_104 G_5 E_0 I_3 D_7 
Stack 10
A_1 A_6 F_8 A_3 F_4 
Stack 11
C_5 D_1 F_10 B_4 I_7 
Stack 12
C_6 Z_105 G_8 H_3 B_7 
Stack 13
E_8 G_0 Z_106 E_1 H_1 
Stack 14
H_2 D_8 I_1 I_0 E_7 
Stack 15
I_4 J_3 B_5 Z_107 G_9 
Stack 16
D_2 Z_108 B_9 H_0 A_2 
Stack 17
G_4 C_3 H_5 H_4 E_10 
Stack 18
E_6 E_9 H_9 E_13 J_1 
Stack 19
J_4 A_7 G_10 B_0 A_4 
Stack 20
H_8 B_8 I_8 F_7 G_6 
Stack 21
J_6 I_6 F_9 Z_109 F_0 
Stack 22
F_3 Z_110 B_2 Z_111 E_2 
