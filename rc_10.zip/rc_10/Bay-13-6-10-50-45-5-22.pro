Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_0 H_2 D_0 F_0 
Stack 1
H_3 F_4 I_3 F_3 
Stack 2
B_1 E_1 I_2 Z_100 
Stack 3
F_1 E_3 J_2 A_1 
Stack 4
B_2 D_2 F_2 J_0 
Stack 5
H_4 D_3 F_5 G_5 
Stack 6
E_2 C_3 Z_101 Z_102 
Stack 7
C_0 D_1 H_0 D_4 
Stack 8
B_3 Z_103 G_3 E_0 
Stack 9
G_2 H_1 G_4 C_1 
Stack 10
Z_104 G_0 G_1 E_4 
Stack 11
I_0 I_1 E_5 
Stack 12
B_0 J_1 C_2 
