Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
B_3 H_3 E_7 F_6 B_1 
Stack 1
A_1 D_1 I_5 I_1 I_3 
Stack 2
G_1 Z_100 H_5 D_5 G_4 
Stack 3
F_3 G_3 E_0 D_4 E_1 
Stack 4
Z_101 G_0 B_0 H_0 C_5 
Stack 5
F_0 F_1 B_4 F_5 J_2 
Stack 6
C_2 A_4 J_0 C_0 E_8 
Stack 7
A_2 H_1 I_0 D_6 C_3 
Stack 8
Z_102 Z_103 H_6 H_4 E_6 
Stack 9
Z_104 G_2 Z_105 F_4 H_2 
Stack 10
A_3 J_1 F_2 B_2 D_3 
Stack 11
D_0 E_4 G_6 C_1 D_2 
Stack 12
G_5 C_4 E_3 B_5 I_2 
Stack 13
A_0 I_4 E_5 Z_106 E_2 
