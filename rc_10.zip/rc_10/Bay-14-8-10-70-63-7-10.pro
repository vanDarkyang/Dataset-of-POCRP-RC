Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
A_2 Z_100 A_1 Z_101 B_1 
Stack 1
H_1 B_3 E_6 E_5 C_3 
Stack 2
Z_102 E_1 D_1 I_5 G_4 
Stack 3
C_6 D_3 B_2 E_2 I_2 
Stack 4
H_2 J_0 B_0 H_0 F_0 
Stack 5
E_7 I_4 Z_103 F_4 A_0 
Stack 6
F_8 G_7 G_1 I_1 F_5 
Stack 7
J_2 J_3 H_4 D_5 C_5 
Stack 8
C_4 E_0 D_6 F_3 D_7 
Stack 9
Z_104 F_7 I_0 G_6 G_0 
Stack 10
D_0 G_3 C_2 F_2 G_2 
Stack 11
F_6 D_2 G_5 H_3 C_1 
Stack 12
D_4 E_4 Z_105 J_4 F_1 
Stack 13
J_1 E_3 C_0 I_3 Z_106 
