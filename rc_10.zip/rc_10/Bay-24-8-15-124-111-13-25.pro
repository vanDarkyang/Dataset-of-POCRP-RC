Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
H_2 G_8 B_2 M_4 G_6 K_1 
Stack 1
Z_100 D_2 F_1 B_3 D_4 I_6 
Stack 2
H_6 H_8 E_4 E_2 H_9 Z_101 
Stack 3
F_2 H_1 J_6 I_5 J_2 D_6 
Stack 4
N_0 K_0 M_0 F_7 F_3 
Stack 5
G_2 K_7 D_7 M_3 J_1 
Stack 6
A_1 Z_102 A_3 O_2 N_3 
Stack 7
N_2 M_1 I_1 I_4 E_0 
Stack 8
I_0 F_0 C_6 K_3 L_3 
Stack 9
G_1 M_5 E_6 Z_103 Z_104 
Stack 10
C_3 N_1 J_7 E_7 D_0 
Stack 11
F_8 Z_105 Z_106 B_0 K_6 
Stack 12
O_0 F_4 Z_107 F_5 K_5 
Stack 13
K_2 Z_108 N_4 L_2 N_5 
Stack 14
O_4 E_5 H_4 O_3 J_5 
Stack 15
E_3 O_1 L_6 B_1 D_5 
Stack 16
G_5 M_2 H_7 D_1 J_3 
Stack 17
J_8 A_0 C_0 I_7 C_1 
Stack 18
J_4 C_4 L_4 I_3 D_3 
Stack 19
F_6 E_1 G_0 K_4 Z_109 
Stack 20
Z_110 H_0 L_5 I_2 G_4 
Stack 21
Z_111 Z_112 A_2 M_6 J_0 
Stack 22
H_5 H_3 G_3 C_5 L_7 
Stack 23
L_1 B_4 G_7 C_2 L_0 
