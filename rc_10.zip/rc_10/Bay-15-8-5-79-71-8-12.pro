Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
Z_100 E_10 B_9 C_12 D_4 C_10 
Stack 1
A_13 E_9 Z_101 Z_102 A_8 C_16 
Stack 2
D_12 A_11 A_12 A_5 B_7 B_6 
Stack 3
C_14 A_10 D_6 E_5 D_7 E_7 
Stack 4
D_5 E_2 E_1 E_4 C_8 
Stack 5
C_9 B_12 Z_103 B_11 C_13 
Stack 6
D_1 C_2 A_4 C_5 C_3 
Stack 7
Z_104 A_7 C_7 E_3 D_10 
Stack 8
D_2 B_2 C_11 B_1 A_2 
Stack 9
B_13 D_0 A_1 C_0 D_13 
Stack 10
C_15 D_9 A_9 B_8 C_6 
Stack 11
B_4 D_8 B_0 E_0 A_0 
Stack 12
D_3 Z_105 B_3 B_5 E_11 
Stack 13
A_6 C_4 Z_106 Z_107 A_3 
Stack 14
D_11 E_8 B_10 C_1 E_6 
