Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
Z_100 Z_101 C_4 F_8 J_5 I_6 
Stack 1
J_3 E_4 G_5 D_2 A_0 E_0 
Stack 2
C_0 E_7 Z_102 H_6 J_2 D_1 
Stack 3
J_4 H_0 B_8 Z_103 F_0 B_5 
Stack 4
A_4 H_2 I_1 E_6 Z_104 F_10 
Stack 5
F_11 I_9 J_8 C_1 F_4 
Stack 6
A_2 G_3 Z_105 A_7 B_3 
Stack 7
D_7 I_0 G_9 D_5 A_5 
Stack 8
F_1 A_1 F_12 G_4 G_8 
Stack 9
E_3 J_7 E_10 F_6 I_2 
Stack 10
G_11 B_4 G_6 B_0 H_4 
Stack 11
E_9 H_7 G_7 E_5 H_9 
Stack 12
H_5 D_6 A_3 D_4 E_2 
Stack 13
I_3 F_2 D_11 B_2 E_1 
Stack 14
H_1 A_6 C_8 J_0 C_2 
Stack 15
Z_106 G_2 D_8 I_4 C_7 
Stack 16
H_10 Z_107 B_6 C_6 G_1 
Stack 17
H_8 D_0 I_7 B_9 J_6 
Stack 18
D_9 I_8 G_10 I_5 D_3 
Stack 19
C_9 F_7 B_7 C_5 G_0 
Stack 20
C_11 B_1 F_3 C_3 Z_108 
Stack 21
H_3 E_8 Z_109 C_10 F_9 
Stack 22
Z_110 D_10 J_1 Z_111 F_5 
