Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
D_2 D_0 Z_100 H_0 
Stack 1
G_3 H_2 B_0 F_3 
Stack 2
E_2 D_5 E_5 D_1 
Stack 3
G_5 C_0 G_2 G_0 
Stack 4
B_2 I_3 I_1 F_0 
Stack 5
F_5 E_6 A_2 F_1 
Stack 6
Z_101 A_1 Z_102 E_4 
Stack 7
G_1 B_1 F_2 E_0 
Stack 8
I_2 D_3 J_0 G_4 
Stack 9
C_2 J_1 H_3 D_4 
Stack 10
I_0 H_1 E_1 Z_103 
Stack 11
A_0 C_1 E_3 
Stack 12
F_6 Z_104 F_4 
