Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
Z_100 F_4 B_5 E_7 
Stack 1
B_2 Z_101 Z_102 I_5 
Stack 2
Z_103 J_3 D_6 A_1 
Stack 3
C_5 Z_104 C_2 F_1 
Stack 4
J_2 F_5 G_1 C_4 
Stack 5
H_5 F_7 F_3 H_4 
Stack 6
B_3 I_0 I_1 B_4 
Stack 7
E_1 B_0 H_6 G_0 
Stack 8
C_1 H_3 E_0 D_1 
Stack 9
E_5 H_1 E_6 D_3 
Stack 10
D_2 G_4 C_0 J_0 
Stack 11
F_0 G_2 G_3 E_2 
Stack 12
D_5 A_2 A_0 J_1 
Stack 13
Z_105 E_4 C_3 Z_106 
Stack 14
G_5 I_4 F_6 D_4 
Stack 15
D_0 D_7 H_0 E_3 
Stack 16
J_4 I_3 H_2 
Stack 17
I_2 F_2 B_1 
