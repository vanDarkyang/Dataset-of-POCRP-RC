Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_3 E_3 I_0 E_5 I_3 
Stack 1
D_5 F_2 F_4 A_0 G_1 
Stack 2
H_2 Z_100 B_2 C_2 F_0 
Stack 3
Z_101 E_4 B_3 G_0 H_3 
Stack 4
A_1 E_1 D_2 H_1 D_0 
Stack 5
E_2 D_3 F_6 H_0 G_2 
Stack 6
E_0 Z_102 F_5 B_0 Z_103 
Stack 7
D_1 J_0 G_3 J_1 C_4 
Stack 8
Z_104 C_1 I_2 F_3 B_1 
Stack 9
C_0 A_2 F_1 I_1 D_4 
