Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_0 E_5 C_10 B_9 C_3 
Stack 1
C_6 E_1 E_0 C_8 Z_100 
Stack 2
D_3 C_1 D_6 Z_101 D_7 
Stack 3
B_2 E_2 B_8 D_5 D_8 
Stack 4
Z_102 D_0 E_3 B_5 Z_103 
Stack 5
C_9 A_1 B_7 E_7 A_5 
Stack 6
C_4 C_0 C_7 C_2 B_4 
Stack 7
E_8 B_3 Z_104 A_2 A_7 
Stack 8
D_4 E_4 C_5 A_6 B_1 
Stack 9
D_1 A_8 Z_105 A_4 B_6 
Stack 10
E_6 A_0 A_3 D_2 
