Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_5 C_1 E_7 Z_100 E_2 
Stack 1
D_8 D_2 B_9 E_3 B_10 
Stack 2
C_4 C_8 Z_101 B_7 B_4 
Stack 3
A_6 C_0 A_3 A_1 E_4 
Stack 4
C_5 B_0 A_2 E_9 E_5 
Stack 5
C_7 B_3 B_6 E_8 B_8 
Stack 6
E_1 C_10 D_1 D_3 D_5 
Stack 7
Z_102 B_2 D_0 A_0 C_9 
Stack 8
D_4 E_6 B_5 E_0 Z_103 
Stack 9
Z_104 C_3 Z_105 C_6 D_7 
Stack 10
A_4 C_2 D_6 B_1 
