Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
I_0 G_2 K_0 C_3 
Stack 1
G_1 B_1 K_3 H_8 
Stack 2
J_4 L_1 L_2 F_5 
Stack 3
N_1 K_5 F_2 D_3 
Stack 4
F_1 B_2 G_3 M_1 
Stack 5
H_0 I_3 I_2 O_2 
Stack 6
K_6 H_3 A_1 H_5 
Stack 7
Z_100 D_2 C_2 E_4 
Stack 8
B_0 J_5 C_1 Z_101 
Stack 9
G_4 G_7 D_5 K_2 
Stack 10
D_0 I_5 N_2 F_3 
Stack 11
H_1 G_8 E_2 Z_102 
Stack 12
E_3 Z_103 Z_104 L_4 
Stack 13
K_4 H_2 G_5 Z_105 
Stack 14
E_1 K_1 D_4 E_0 
Stack 15
B_3 I_4 J_0 M_0 
Stack 16
Z_106 I_1 L_3 I_6 
Stack 17
Z_107 H_7 A_0 Z_108 
Stack 18
F_6 F_0 N_3 G_6 
Stack 19
M_3 O_1 J_1 A_2 
Stack 20
J_2 H_4 L_0 C_0 
Stack 21
I_7 D_1 N_0 F_4 
Stack 22
J_3 G_0 Z_109 
Stack 23
O_0 H_6 M_2 
