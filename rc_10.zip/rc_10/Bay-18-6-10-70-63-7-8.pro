Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_2 G_4 E_3 Z_100 
Stack 1
D_7 D_6 F_3 D_3 
Stack 2
A_0 C_5 J_0 Z_101 
Stack 3
B_1 I_0 C_4 D_0 
Stack 4
F_5 A_3 Z_102 B_4 
Stack 5
I_1 D_1 H_4 H_3 
Stack 6
E_8 C_3 G_5 A_4 
Stack 7
G_2 H_1 A_1 E_2 
Stack 8
Z_103 D_5 I_3 G_3 
Stack 9
D_4 H_2 F_6 E_7 
Stack 10
I_2 F_0 E_6 J_2 
Stack 11
C_6 E_0 I_4 J_3 
Stack 12
E_1 B_0 A_2 B_2 
Stack 13
J_1 G_0 G_1 E_5 
Stack 14
B_3 F_1 Z_104 F_4 
Stack 15
C_2 C_1 H_0 Z_105 
Stack 16
C_0 I_5 E_4 
Stack 17
Z_106 F_2 H_5 
