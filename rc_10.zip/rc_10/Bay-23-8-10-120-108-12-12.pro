Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
C_1 H_1 Z_100 I_7 D_8 H_7 
Stack 1
D_10 A_1 G_1 F_9 Z_101 F_11 
Stack 2
B_0 Z_102 E_8 J_5 E_9 A_5 
Stack 3
A_8 D_5 I_3 G_9 I_0 G_11 
Stack 4
H_5 Z_103 H_9 D_1 D_11 D_7 
Stack 5
C_5 E_0 C_3 C_6 C_8 
Stack 6
G_4 G_6 E_12 B_3 E_3 
Stack 7
J_1 B_6 F_3 F_10 J_8 
Stack 8
Z_104 Z_105 G_8 I_4 D_4 
Stack 9
J_7 F_4 I_6 E_11 C_4 
Stack 10
F_5 E_2 I_1 E_1 H_6 
Stack 11
C_0 E_7 A_6 F_1 Z_106 
Stack 12
B_8 A_4 G_5 E_4 Z_107 
Stack 13
D_2 E_6 B_5 A_3 J_4 
Stack 14
H_8 E_10 B_7 C_9 Z_108 
Stack 15
H_0 A_2 D_0 B_4 B_9 
Stack 16
G_2 D_3 Z_109 J_2 C_2 
Stack 17
I_5 H_2 G_0 Z_110 A_0 
Stack 18
I_2 H_3 F_0 G_7 E_5 
Stack 19
E_13 C_7 D_9 F_7 Z_111 
Stack 20
F_6 J_3 B_1 I_8 H_4 
Stack 21
A_7 G_10 B_2 F_2 F_8 
Stack 22
F_12 G_3 D_6 J_0 J_6 
