Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
J_5 F_6 J_2 G_0 
Stack 1
G_3 H_6 F_2 H_5 
Stack 2
C_3 G_2 C_4 Z_100 
Stack 3
B_2 M_0 F_5 H_4 
Stack 4
G_1 K_4 L_1 C_2 
Stack 5
O_1 J_6 H_8 Z_101 
Stack 6
N_1 E_0 F_3 Z_102 
Stack 7
A_1 G_5 J_1 O_2 
Stack 8
D_1 H_7 G_7 D_4 
Stack 9
D_0 Z_103 H_0 H_2 
Stack 10
A_0 I_6 K_2 J_3 
Stack 11
B_1 Z_104 N_2 J_4 
Stack 12
I_1 D_2 D_5 L_3 
Stack 13
Z_105 E_5 K_0 F_1 
Stack 14
C_0 K_3 N_0 I_2 
Stack 15
G_6 J_0 I_4 M_1 
Stack 16
Z_106 E_4 O_0 F_0 
Stack 17
B_3 I_5 C_1 E_2 
Stack 18
Z_107 M_4 M_2 D_3 
Stack 19
H_1 A_2 I_7 K_1 
Stack 20
E_3 G_4 I_3 M_3 
Stack 21
E_1 L_2 H_3 Z_108 
Stack 22
N_3 L_0 Z_109 
Stack 23
I_0 B_0 F_4 
