Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
Z_100 A_1 I_3 E_7 H_0 
Stack 1
F_4 D_2 C_1 A_2 H_1 
Stack 2
B_0 H_4 B_4 A_4 B_3 
Stack 3
B_1 Z_101 J_0 E_0 Z_102 
Stack 4
E_6 B_2 D_3 G_3 C_3 
Stack 5
E_1 C_0 D_7 I_1 G_0 
Stack 6
G_6 H_5 D_5 J_1 D_6 
Stack 7
Z_103 F_8 D_0 H_3 F_1 
Stack 8
G_2 I_2 E_2 I_0 Z_104 
Stack 9
J_2 G_1 Z_105 A_0 F_7 
Stack 10
C_4 E_4 F_0 F_3 Z_106 
Stack 11
F_6 F_2 D_4 C_5 G_4 
Stack 12
F_5 A_3 E_5 C_2 E_3 
Stack 13
J_3 H_2 B_5 G_5 D_1 
