Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_4 Z_100 A_8 B_1 
Stack 1
C_10 A_11 B_5 C_6 
Stack 2
B_12 B_2 B_14 C_8 
Stack 3
A_12 B_6 C_11 A_9 
Stack 4
C_4 C_2 A_13 A_2 
Stack 5
A_1 B_4 A_3 A_0 
Stack 6
C_0 C_7 B_8 B_7 
Stack 7
C_3 Z_101 B_3 Z_102 
Stack 8
A_7 A_10 A_6 B_0 
Stack 9
C_9 B_13 B_10 B_11 
Stack 10
C_1 Z_103 Z_104 
Stack 11
A_5 C_5 B_9 
