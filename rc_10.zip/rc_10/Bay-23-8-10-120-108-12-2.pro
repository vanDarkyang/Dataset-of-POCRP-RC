Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
E_6 E_5 H_6 F_2 F_10 I_6 
Stack 1
B_7 Z_100 C_0 C_4 H_2 I_3 
Stack 2
J_0 J_8 E_4 A_0 D_11 Z_101 
Stack 3
G_2 I_7 A_7 H_8 C_6 D_10 
Stack 4
I_8 H_4 G_7 F_6 Z_102 E_8 
Stack 5
G_0 F_0 C_1 I_1 C_5 
Stack 6
G_3 D_6 H_10 B_3 I_5 
Stack 7
E_1 B_2 A_3 H_3 D_4 
Stack 8
D_5 E_11 F_11 Z_103 D_1 
Stack 9
D_7 J_2 H_1 Z_104 D_9 
Stack 10
H_7 D_2 E_7 J_7 G_1 
Stack 11
B_4 B_5 C_8 G_6 B_1 
Stack 12
E_0 F_1 I_0 D_0 B_9 
Stack 13
G_5 E_12 B_10 Z_105 D_3 
Stack 14
B_6 J_5 Z_106 I_9 D_8 
Stack 15
A_4 B_0 I_4 Z_107 J_6 
Stack 16
E_9 F_12 E_10 G_4 G_8 
Stack 17
Z_108 E_2 F_8 A_1 C_9 
Stack 18
F_7 A_5 G_10 F_9 J_3 
Stack 19
A_2 E_3 H_5 C_3 F_3 
Stack 20
Z_109 B_8 G_9 Z_110 Z_111 
Stack 21
A_6 H_0 F_5 F_4 J_4 
Stack 22
J_1 C_7 C_2 H_9 I_2 
