Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
H_2 F_0 A_2 D_3 D_2 
Stack 1
F_6 E_1 H_0 G_1 Z_100 
Stack 2
G_2 H_1 F_4 B_3 I_0 
Stack 3
Z_101 E_4 D_0 G_4 Z_102 
Stack 4
A_0 F_1 J_1 F_5 G_3 
Stack 5
B_1 D_4 G_0 I_3 F_3 
Stack 6
I_1 J_0 E_3 G_5 D_1 
Stack 7
Z_103 B_2 Z_104 C_2 F_2 
Stack 8
J_2 I_2 B_0 C_1 A_1 
Stack 9
D_5 E_2 H_3 E_0 C_0 
