Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_10 B_13 A_9 D_7 
Stack 1
Z_100 D_13 D_11 E_8 
Stack 2
E_3 B_2 E_9 D_5 
Stack 3
B_8 Z_101 A_8 A_1 
Stack 4
D_9 E_5 D_3 Z_102 
Stack 5
E_11 C_11 C_5 C_2 
Stack 6
Z_103 C_3 A_12 C_8 
Stack 7
D_4 E_10 B_6 E_2 
Stack 8
B_4 E_4 E_0 Z_104 
Stack 9
E_1 Z_105 Z_106 A_2 
Stack 10
C_13 C_12 D_15 C_1 
Stack 11
A_7 B_9 A_4 A_10 
Stack 12
A_11 D_1 A_6 D_14 
Stack 13
A_0 C_4 E_6 C_0 
Stack 14
A_3 B_10 B_11 B_12 
Stack 15
B_1 B_3 D_12 D_2 
Stack 16
C_6 B_5 D_6 D_0 
Stack 17
C_9 B_14 D_8 E_7 
Stack 18
C_7 B_7 Z_107 D_10 
Stack 19
B_0 A_5 E_12 
