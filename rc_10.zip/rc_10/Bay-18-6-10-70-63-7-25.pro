Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_0 H_2 D_1 Z_100 
Stack 1
H_1 G_0 C_4 C_5 
Stack 2
B_5 J_2 Z_101 G_2 
Stack 3
E_0 D_5 I_1 B_1 
Stack 4
F_2 J_1 I_0 I_2 
Stack 5
H_6 A_3 G_6 I_3 
Stack 6
A_0 B_0 H_0 A_2 
Stack 7
G_7 E_3 Z_102 Z_103 
Stack 8
F_1 D_6 E_2 H_5 
Stack 9
G_1 H_3 Z_104 B_4 
Stack 10
E_6 A_1 Z_105 G_3 
Stack 11
D_4 H_4 F_5 G_4 
Stack 12
B_3 E_5 E_1 F_3 
Stack 13
J_0 C_1 C_2 J_4 
Stack 14
C_3 F_0 E_4 B_2 
Stack 15
D_2 F_6 G_5 F_8 
Stack 16
F_4 D_3 Z_106 
Stack 17
J_3 F_7 C_0 
