Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
F_1 E_5 O_1 F_2 Z_100 G_2 
Stack 1
G_6 D_4 I_1 H_8 L_5 A_3 
Stack 2
E_3 C_1 N_4 G_4 N_5 H_4 
Stack 3
H_10 E_0 F_3 C_0 K_0 I_6 
Stack 4
Z_101 J_0 Z_102 F_0 D_2 
Stack 5
Z_103 I_7 I_5 B_0 I_4 
Stack 6
A_2 A_1 H_7 B_4 N_0 
Stack 7
F_7 D_0 F_6 J_2 I_8 
Stack 8
E_7 K_6 D_1 H_2 Z_104 
Stack 9
Z_105 M_5 K_2 G_3 B_1 
Stack 10
K_8 M_4 G_8 E_6 A_4 
Stack 11
H_9 I_0 G_0 O_3 M_2 
Stack 12
C_4 L_4 O_2 G_5 N_1 
Stack 13
G_10 F_4 M_0 F_8 Z_106 
Stack 14
J_4 F_5 J_3 K_4 J_1 
Stack 15
Z_107 D_3 H_6 O_0 H_3 
Stack 16
G_9 L_1 L_2 K_1 B_2 
Stack 17
M_3 M_6 C_3 A_0 Z_108 
Stack 18
Z_109 I_2 J_6 G_1 E_2 
Stack 19
K_7 L_6 K_5 J_7 N_3 
Stack 20
B_3 G_7 Z_110 H_5 E_4 
Stack 21
C_2 J_8 L_0 H_1 I_3 
Stack 22
J_5 N_2 L_3 E_1 Z_111 
Stack 23
H_0 Z_112 K_3 M_1 L_7 
