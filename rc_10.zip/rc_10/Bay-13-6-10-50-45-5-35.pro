Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_0 F_1 H_1 B_2 
Stack 1
B_0 D_3 D_4 E_2 
Stack 2
B_3 G_4 C_2 F_3 
Stack 3
J_0 H_2 I_2 F_2 
Stack 4
E_1 A_0 A_2 Z_100 
Stack 5
G_2 C_1 B_1 Z_101 
Stack 6
D_5 F_0 Z_102 G_3 
Stack 7
D_0 D_1 I_0 I_1 
Stack 8
H_0 I_3 Z_103 H_4 
Stack 9
H_3 C_0 D_2 J_2 
Stack 10
E_4 E_5 G_1 G_0 
Stack 11
J_1 E_3 C_3 
Stack 12
F_4 A_1 Z_104 
