Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_3 E_12 B_2 D_3 D_6 E_6 
Stack 1
C_3 Z_100 B_6 B_10 D_2 C_4 
Stack 2
C_10 B_13 A_5 C_1 A_1 B_11 
Stack 3
B_9 A_8 C_0 D_5 A_9 C_13 
Stack 4
A_4 D_7 C_14 Z_101 E_13 
Stack 5
E_11 A_2 Z_102 D_1 B_8 
Stack 6
B_0 C_2 D_10 C_7 Z_103 
Stack 7
A_6 D_0 D_11 E_10 A_0 
Stack 8
B_3 D_8 E_3 E_4 B_1 
Stack 9
E_7 E_2 C_6 C_12 E_5 
Stack 10
B_7 C_11 C_5 B_4 D_9 
Stack 11
Z_104 E_9 B_14 E_0 A_11 
Stack 12
B_5 Z_105 B_12 D_13 A_10 
Stack 13
C_8 E_1 C_9 Z_106 E_8 
Stack 14
A_12 Z_107 D_12 D_4 A_7 
