Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
G_5 G_1 H_5 D_2 
Stack 1
Z_100 A_0 G_6 C_5 
Stack 2
D_3 A_1 F_6 J_0 
Stack 3
Z_101 C_1 G_4 C_6 
Stack 4
H_4 B_0 J_4 E_2 
Stack 5
F_3 H_3 J_1 J_2 
Stack 6
C_0 G_0 A_2 D_4 
Stack 7
G_3 C_3 H_6 H_0 
Stack 8
Z_102 F_7 Z_103 E_8 
Stack 9
Z_104 I_4 E_1 I_0 
Stack 10
B_2 D_1 B_4 D_5 
Stack 11
Z_105 C_4 I_2 E_3 
Stack 12
E_0 E_4 F_5 J_3 
Stack 13
D_0 B_1 H_2 D_6 
Stack 14
I_1 Z_106 I_3 G_2 
Stack 15
E_6 F_4 E_5 H_1 
Stack 16
F_1 C_2 F_0 
Stack 17
B_3 E_7 F_2 
