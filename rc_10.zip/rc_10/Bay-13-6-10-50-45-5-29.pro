Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_0 F_1 D_4 E_5 
Stack 1
C_0 D_0 C_1 C_3 
Stack 2
E_2 E_0 E_3 B_1 
Stack 3
B_3 F_3 G_1 A_1 
Stack 4
D_2 A_0 F_2 E_1 
Stack 5
Z_100 I_2 H_0 H_4 
Stack 6
I_3 D_3 J_0 J_1 
Stack 7
E_4 F_4 A_2 B_2 
Stack 8
C_2 H_2 H_1 G_4 
Stack 9
G_2 I_1 Z_101 H_3 
Stack 10
Z_102 J_2 Z_103 G_0 
Stack 11
F_5 D_1 I_0 
Stack 12
F_0 G_3 Z_104 
