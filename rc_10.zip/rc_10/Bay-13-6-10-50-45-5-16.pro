Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
H_3 B_1 D_3 Z_100 
Stack 1
F_1 J_1 H_1 I_3 
Stack 2
D_0 B_0 A_1 I_2 
Stack 3
B_2 D_4 I_0 Z_101 
Stack 4
Z_102 A_2 E_0 E_1 
Stack 5
G_1 C_2 C_1 D_2 
Stack 6
F_3 E_6 E_3 F_2 
Stack 7
F_5 J_0 F_6 G_0 
Stack 8
Z_103 G_2 H_2 D_1 
Stack 9
E_2 F_0 I_1 J_2 
Stack 10
G_4 H_0 G_3 G_5 
Stack 11
A_0 C_0 E_5 
Stack 12
E_4 Z_104 F_4 
