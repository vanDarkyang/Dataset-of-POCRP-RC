Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
I_4 Z_100 I_0 D_2 E_3 G_2 
Stack 1
G_7 L_0 I_3 D_5 J_0 D_1 
Stack 2
E_0 F_3 M_2 C_2 H_1 C_0 
Stack 3
J_5 M_1 J_2 E_4 L_2 M_0 
Stack 4
D_0 F_6 E_2 J_6 G_1 
Stack 5
I_2 F_0 Z_101 F_2 F_1 
Stack 6
E_5 G_0 H_2 D_4 K_2 
Stack 7
G_4 Z_102 B_2 O_0 J_3 
Stack 8
K_0 I_1 L_1 A_1 D_3 
Stack 9
H_7 K_3 E_1 G_8 J_1 
Stack 10
Z_103 L_4 N_0 H_0 Z_104 
Stack 11
N_1 Z_105 C_3 F_5 C_4 
Stack 12
I_8 G_6 I_5 E_6 H_5 
Stack 13
F_4 H_3 J_4 G_3 Z_106 
Stack 14
N_2 H_4 G_5 K_1 H_6 
Stack 15
B_1 O_1 L_3 K_4 Z_107 
Stack 16
M_3 C_1 I_6 Z_108 I_7 
Stack 17
A_0 K_6 K_5 Z_109 B_0 
