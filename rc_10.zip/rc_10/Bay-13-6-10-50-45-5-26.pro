Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_2 F_0 A_2 Z_100 
Stack 1
F_1 I_0 I_2 J_1 
Stack 2
E_6 D_3 F_3 B_1 
Stack 3
E_3 D_1 B_0 G_4 
Stack 4
F_4 J_0 H_2 G_3 
Stack 5
G_0 A_1 D_0 C_1 
Stack 6
Z_101 H_1 E_1 C_0 
Stack 7
G_1 I_1 D_5 Z_102 
Stack 8
G_5 F_2 C_2 Z_103 
Stack 9
E_0 J_2 E_4 E_2 
Stack 10
D_4 E_5 H_0 C_3 
Stack 11
H_3 H_4 A_0 
Stack 12
D_2 Z_104 G_2 
