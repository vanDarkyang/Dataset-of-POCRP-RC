Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
I_7 L_5 K_2 C_2 E_4 K_0 
Stack 1
C_3 G_6 K_4 F_5 L_3 B_2 
Stack 2
Z_100 I_4 L_0 F_1 C_1 D_0 
Stack 3
E_5 I_1 Z_101 L_2 H_2 E_6 
Stack 4
C_0 I_6 H_5 Z_102 H_4 
Stack 5
B_3 J_3 K_6 O_2 E_1 
Stack 6
H_6 N_2 K_5 G_5 F_0 
Stack 7
H_8 H_0 Z_103 G_8 I_3 
Stack 8
F_2 I_5 Z_104 L_4 F_3 
Stack 9
D_3 E_0 E_3 D_1 J_4 
Stack 10
I_8 H_1 K_3 Z_105 A_1 
Stack 11
G_0 L_1 M_2 G_3 N_0 
Stack 12
G_2 H_7 G_7 J_1 J_0 
Stack 13
K_1 Z_106 A_0 B_0 G_4 
Stack 14
Z_107 E_2 M_0 Z_108 N_3 
Stack 15
N_1 O_0 O_1 G_1 F_4 
Stack 16
D_2 H_3 J_2 M_1 I_0 
Stack 17
B_1 F_6 C_4 I_2 Z_109 
