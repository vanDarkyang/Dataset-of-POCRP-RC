Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
F_10 Z_100 C_2 D_3 B_2 J_6 
Stack 1
B_1 G_2 B_0 H_0 A_2 Z_101 
Stack 2
G_1 E_2 E_3 G_6 J_1 F_1 
Stack 3
Z_102 Z_103 A_3 I_7 G_3 A_7 
Stack 4
D_1 I_8 C_10 H_8 B_10 G_8 
Stack 5
C_7 F_4 J_7 H_10 I_4 
Stack 6
A_8 H_9 F_12 F_6 B_9 
Stack 7
J_4 D_8 A_5 Z_104 H_4 
Stack 8
J_0 H_7 E_5 D_0 C_0 
Stack 9
C_8 Z_105 E_6 B_6 B_8 
Stack 10
I_0 H_3 J_8 B_4 C_6 
Stack 11
F_7 J_2 J_3 D_4 E_9 
Stack 12
I_6 J_5 E_11 D_2 I_5 
Stack 13
F_3 B_3 F_5 A_6 B_5 
Stack 14
F_13 D_7 G_5 E_12 Z_106 
Stack 15
Z_107 C_5 Z_108 C_4 G_7 
Stack 16
A_1 D_9 H_6 E_1 F_9 
Stack 17
G_4 Z_109 C_3 Z_110 C_9 
Stack 18
F_8 A_4 H_5 I_1 E_10 
Stack 19
E_8 I_2 E_4 F_11 E_7 
Stack 20
C_1 G_9 E_0 D_6 I_3 
Stack 21
F_0 D_5 H_2 A_0 G_0 
Stack 22
A_9 H_1 B_7 F_2 Z_111 
