Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_1 D_5 Z_100 M_1 
Stack 1
L_4 B_2 N_2 H_3 
Stack 2
H_2 Z_101 O_1 L_0 
Stack 3
G_6 D_2 K_0 H_0 
Stack 4
B_3 G_1 I_4 E_4 
Stack 5
G_2 G_0 K_5 I_1 
Stack 6
M_0 H_6 Z_102 E_2 
Stack 7
D_3 B_1 E_1 H_7 
Stack 8
Z_103 I_7 C_3 E_3 
Stack 9
D_0 J_0 L_1 J_1 
Stack 10
J_4 M_2 F_5 I_6 
Stack 11
C_0 N_1 Z_104 I_3 
Stack 12
Z_105 C_1 Z_106 J_5 
Stack 13
L_5 I_0 F_0 N_0 
Stack 14
O_2 H_1 M_3 G_4 
Stack 15
H_8 C_2 H_5 I_5 
Stack 16
I_2 K_1 F_6 E_0 
Stack 17
F_4 B_0 K_4 Z_107 
Stack 18
J_3 D_1 L_2 G_3 
Stack 19
G_7 M_4 J_2 H_4 
Stack 20
A_0 F_2 K_3 A_2 
Stack 21
F_1 F_3 O_0 L_3 
Stack 22
G_5 Z_108 Z_109 
Stack 23
E_5 D_4 K_2 
