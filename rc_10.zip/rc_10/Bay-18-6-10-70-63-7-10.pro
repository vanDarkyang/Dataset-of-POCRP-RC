Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
A_4 J_0 D_4 Z_100 
Stack 1
H_1 I_4 I_0 I_3 
Stack 2
A_3 G_6 C_2 B_0 
Stack 3
Z_101 J_3 G_4 C_3 
Stack 4
H_2 E_1 H_6 G_3 
Stack 5
E_8 F_6 C_0 I_2 
Stack 6
F_7 G_2 E_0 Z_102 
Stack 7
J_2 D_1 E_6 A_1 
Stack 8
C_4 E_5 I_5 F_4 
Stack 9
H_4 E_4 E_3 C_5 
Stack 10
D_0 A_2 H_0 D_5 
Stack 11
F_5 E_7 F_3 G_0 
Stack 12
D_3 Z_103 I_1 G_1 
Stack 13
J_1 B_1 Z_104 C_1 
Stack 14
B_2 Z_105 F_2 F_0 
Stack 15
B_3 A_0 G_5 B_4 
Stack 16
E_2 Z_106 F_1 
Stack 17
D_2 H_5 H_3 
