Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
D_1 B_1 G_3 I_2 D_5 
Stack 1
D_0 B_3 B_0 A_0 C_0 
Stack 2
D_2 Z_100 F_0 I_0 F_1 
Stack 3
I_1 E_0 A_1 H_1 Z_101 
Stack 4
F_6 G_2 J_1 E_5 E_2 
Stack 5
G_1 A_2 Z_102 H_3 I_3 
Stack 6
C_2 E_4 H_2 F_5 F_4 
Stack 7
E_3 C_3 Z_103 D_4 H_0 
Stack 8
D_3 E_1 F_2 B_2 F_3 
Stack 9
C_4 C_1 J_0 Z_104 G_0 
