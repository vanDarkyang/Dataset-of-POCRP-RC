Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_2 C_3 C_4 A_6 C_5 
Stack 1
A_9 C_2 E_5 D_5 D_8 
Stack 2
C_9 B_6 D_6 B_2 A_0 
Stack 3
C_1 A_3 Z_100 B_0 C_6 
Stack 4
E_1 D_0 C_8 A_2 Z_101 
Stack 5
D_1 Z_102 Z_103 E_7 A_7 
Stack 6
E_4 C_7 Z_104 D_4 E_8 
Stack 7
D_3 E_2 B_4 A_1 A_4 
Stack 8
A_5 E_3 B_7 A_8 C_0 
Stack 9
E_6 Z_105 B_8 E_0 B_5 
Stack 10
C_10 B_1 B_3 D_7 
