Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
D_1 F_0 E_0 C_3 H_4 
Stack 1
D_0 E_1 F_1 G_4 E_3 
Stack 2
H_0 D_4 B_2 H_2 Z_100 
Stack 3
F_3 Z_101 D_2 Z_102 I_2 
Stack 4
C_0 A_1 F_2 E_2 G_2 
Stack 5
C_4 Z_103 H_3 B_3 J_2 
Stack 6
D_3 I_1 A_0 B_1 C_1 
Stack 7
E_4 G_0 G_1 H_1 I_0 
Stack 8
G_3 C_2 F_4 F_6 Z_104 
Stack 9
B_0 J_1 J_0 A_2 F_5 
