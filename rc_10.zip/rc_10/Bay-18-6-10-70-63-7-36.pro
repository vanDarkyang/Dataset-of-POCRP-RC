Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_0 D_5 D_3 G_0 
Stack 1
F_0 F_6 F_4 H_2 
Stack 2
D_6 B_4 Z_100 Z_101 
Stack 3
Z_102 G_1 F_5 I_2 
Stack 4
Z_103 B_0 F_2 B_1 
Stack 5
E_2 E_7 G_3 H_5 
Stack 6
H_1 G_5 C_0 I_5 
Stack 7
F_7 J_0 A_0 C_5 
Stack 8
F_1 C_3 C_4 I_3 
Stack 9
J_3 D_1 Z_104 A_1 
Stack 10
J_2 D_2 I_4 I_1 
Stack 11
A_2 A_3 C_2 G_6 
Stack 12
E_5 B_3 E_3 D_4 
Stack 13
J_1 B_2 E_1 E_4 
Stack 14
C_1 F_3 E_0 H_4 
Stack 15
G_4 Z_105 H_6 G_2 
Stack 16
H_0 Z_106 I_0 
Stack 17
E_6 F_8 H_3 
