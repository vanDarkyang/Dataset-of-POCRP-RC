Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
N_1 Z_100 B_2 K_2 Z_101 J_4 
Stack 1
C_2 M_0 Z_102 H_3 K_5 F_4 
Stack 2
G_4 Z_103 D_2 Z_104 H_1 Z_105 
Stack 3
F_0 O_2 N_2 H_2 L_2 I_1 
Stack 4
K_3 L_1 J_1 G_2 Z_106 
Stack 5
D_3 C_1 H_4 K_0 A_0 
Stack 6
G_3 G_0 A_2 E_1 M_4 
Stack 7
D_0 J_2 F_3 D_1 B_0 
Stack 8
F_5 Z_107 H_5 K_1 F_6 
Stack 9
L_0 N_0 I_6 K_4 C_0 
Stack 10
L_3 E_0 B_3 D_5 F_2 
Stack 11
I_0 A_1 C_3 I_3 J_5 
Stack 12
G_6 E_3 Z_108 E_4 G_5 
Stack 13
L_4 Z_109 J_0 L_5 E_5 
Stack 14
I_2 J_3 I_4 E_2 B_1 
Stack 15
I_5 I_7 K_6 G_7 O_0 
Stack 16
M_3 G_1 F_7 M_2 D_4 
Stack 17
H_0 I_8 M_1 F_1 O_1 
