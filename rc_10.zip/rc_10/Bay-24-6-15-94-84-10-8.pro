Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
N_0 I_2 E_0 B_0 
Stack 1
G_2 H_2 G_0 K_4 
Stack 2
C_0 L_0 G_3 C_2 
Stack 3
H_1 F_1 I_3 J_6 
Stack 4
Z_100 H_5 F_2 H_9 
Stack 5
D_3 J_0 F_7 K_2 
Stack 6
F_3 Z_101 Z_102 E_2 
Stack 7
H_3 Z_103 H_0 D_2 
Stack 8
E_1 L_1 Z_104 N_2 
Stack 9
Z_105 J_4 L_3 I_6 
Stack 10
A_1 M_3 K_0 E_4 
Stack 11
F_0 J_3 I_1 E_5 
Stack 12
D_5 L_5 Z_106 O_0 
Stack 13
F_4 J_7 H_7 G_1 
Stack 14
J_2 G_4 L_4 F_6 
Stack 15
B_3 M_0 A_0 B_1 
Stack 16
Z_107 N_3 G_7 C_1 
Stack 17
H_6 B_2 Z_108 D_1 
Stack 18
G_5 J_5 D_4 J_1 
Stack 19
F_5 N_1 D_0 K_3 
Stack 20
A_2 I_4 I_5 M_2 
Stack 21
H_8 M_1 Z_109 E_6 
Stack 22
H_4 G_6 E_3 
Stack 23
I_0 L_2 K_1 
