Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
N_0 G_6 L_5 M_1 Z_100 J_1 
Stack 1
G_2 F_5 J_7 H_0 K_5 K_4 
Stack 2
C_0 A_2 G_4 K_1 C_3 M_3 
Stack 3
H_1 H_8 M_0 L_3 J_6 Z_101 
Stack 4
O_0 H_4 Z_102 K_0 H_9 
Stack 5
D_1 I_0 B_1 I_1 K_3 
Stack 6
F_3 I_2 J_5 Z_103 E_2 
Stack 7
H_3 H_2 N_1 H_7 D_0 
Stack 8
E_1 L_0 I_4 L_4 N_2 
Stack 9
Z_104 F_1 M_2 A_0 I_6 
Stack 10
A_1 H_5 G_7 G_8 E_4 
Stack 11
F_0 J_0 L_2 K_6 E_5 
Stack 12
D_3 C_2 E_0 D_2 Z_105 
Stack 13
F_4 G_5 G_0 Z_106 G_1 
Stack 14
J_2 L_1 G_3 I_5 Z_107 
Stack 15
B_2 J_4 I_3 O_1 B_0 
Stack 16
C_1 M_4 F_2 E_3 Z_108 
Stack 17
H_6 J_3 F_6 K_2 Z_109 
