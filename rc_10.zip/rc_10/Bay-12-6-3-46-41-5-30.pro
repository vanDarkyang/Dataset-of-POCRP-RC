Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_4 B_1 C_5 C_0 
Stack 1
C_10 A_9 A_2 C_8 
Stack 2
C_1 A_4 B_13 B_2 
Stack 3
C_7 Z_100 A_0 B_11 
Stack 4
A_3 C_12 B_6 B_5 
Stack 5
A_1 C_11 A_11 Z_101 
Stack 6
C_2 C_6 C_13 A_6 
Stack 7
B_9 Z_102 B_7 A_12 
Stack 8
A_10 B_10 Z_103 B_8 
Stack 9
B_12 C_9 A_5 Z_104 
Stack 10
C_4 C_3 A_7 
Stack 11
B_3 A_8 B_0 
