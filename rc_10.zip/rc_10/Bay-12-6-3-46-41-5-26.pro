Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_1 B_5 A_6 A_3 
Stack 1
Z_100 Z_101 A_2 C_3 
Stack 2
A_8 C_10 B_9 C_4 
Stack 3
A_5 A_4 B_0 C_7 
Stack 4
B_12 C_5 Z_102 B_7 
Stack 5
A_7 B_4 B_3 C_9 
Stack 6
Z_103 B_11 B_6 B_2 
Stack 7
Z_104 A_11 A_10 C_6 
Stack 8
A_13 C_0 A_1 B_13 
Stack 9
A_0 B_8 C_12 B_10 
Stack 10
C_1 C_8 A_9 
Stack 11
C_2 C_11 A_12 
