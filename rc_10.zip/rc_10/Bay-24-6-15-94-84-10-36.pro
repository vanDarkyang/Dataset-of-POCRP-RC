Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
G_4 Z_100 C_1 L_4 
Stack 1
G_6 E_2 C_2 H_2 
Stack 2
Z_101 D_4 J_3 F_2 
Stack 3
G_7 I_2 D_0 O_0 
Stack 4
H_7 J_4 K_2 B_2 
Stack 5
H_4 D_3 H_6 H_5 
Stack 6
E_1 E_5 I_1 E_0 
Stack 7
K_1 K_0 J_0 N_2 
Stack 8
L_1 Z_102 D_2 B_1 
Stack 9
I_5 G_3 K_4 E_3 
Stack 10
H_8 M_3 H_1 D_1 
Stack 11
G_2 I_7 Z_103 J_5 
Stack 12
L_2 J_2 I_4 Z_104 
Stack 13
G_5 F_6 Z_105 M_2 
Stack 14
Z_106 H_0 B_0 N_1 
Stack 15
F_1 F_3 F_4 Z_107 
Stack 16
J_1 I_0 N_3 M_0 
Stack 17
I_6 J_6 A_0 M_1 
Stack 18
G_8 O_1 F_5 C_0 
Stack 19
L_3 L_5 A_2 E_4 
Stack 20
K_3 H_3 I_3 O_2 
Stack 21
G_0 N_0 F_0 L_0 
Stack 22
A_1 Z_108 G_1 
Stack 23
F_7 Z_109 C_3 
