Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
E_2 G_2 Z_100 G_3 D_9 E_0 
Stack 1
C_8 B_9 F_2 G_9 J_7 A_0 
Stack 2
Z_101 A_3 A_1 I_9 F_11 B_7 
Stack 3
B_8 F_8 I_6 J_2 J_9 G_8 
Stack 4
C_6 B_0 I_2 I_1 C_4 G_6 
Stack 5
F_12 E_10 A_5 I_0 D_6 
Stack 6
B_4 Z_102 F_7 A_7 D_3 
Stack 7
J_8 Z_103 E_9 D_4 F_9 
Stack 8
C_2 E_4 F_6 H_10 Z_104 
Stack 9
G_5 E_12 H_5 A_6 B_6 
Stack 10
F_0 B_5 D_1 H_9 F_4 
Stack 11
Z_105 H_6 Z_106 J_4 B_2 
Stack 12
I_4 Z_107 C_0 H_2 G_0 
Stack 13
I_5 Z_108 H_1 H_8 C_5 
Stack 14
E_6 H_4 G_10 E_8 Z_109 
Stack 15
G_11 F_5 G_1 H_0 E_11 
Stack 16
I_3 F_1 Z_110 E_3 A_2 
Stack 17
E_7 F_3 A_4 F_10 D_2 
Stack 18
D_0 E_5 I_7 B_3 C_1 
Stack 19
Z_111 J_1 H_3 J_0 D_8 
Stack 20
D_5 J_5 H_7 J_6 C_7 
Stack 21
D_7 C_9 G_7 I_8 C_3 
Stack 22
G_4 B_1 J_3 E_1 F_13 
