Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
G_5 G_3 D_0 I_3 F_3 
Stack 1
B_0 F_6 J_3 H_3 E_2 
Stack 2
B_3 G_6 G_0 J_2 I_2 
Stack 3
B_2 E_3 C_3 I_1 I_5 
Stack 4
C_4 E_1 G_1 J_1 B_4 
Stack 5
D_4 H_4 J_0 Z_100 D_2 
Stack 6
Z_101 E_0 B_5 A_0 Z_102 
Stack 7
H_0 G_7 J_4 I_0 F_4 
Stack 8
F_2 H_1 F_5 G_4 Z_103 
Stack 9
H_5 Z_104 D_6 E_4 F_1 
Stack 10
A_1 C_1 F_0 I_4 G_2 
Stack 11
D_5 Z_105 A_2 E_5 H_2 
Stack 12
D_1 E_6 Z_106 C_0 C_5 
Stack 13
H_6 D_7 D_3 C_2 B_1 
