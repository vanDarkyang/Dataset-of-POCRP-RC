Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_4 G_1 B_0 I_1 
Stack 1
E_2 B_2 H_3 J_0 
Stack 2
G_2 C_4 H_1 E_1 
Stack 3
Z_100 A_2 C_2 D_2 
Stack 4
E_0 D_1 H_2 H_0 
Stack 5
F_6 Z_101 F_0 A_1 
Stack 6
Z_102 B_3 B_1 Z_103 
Stack 7
I_0 G_0 G_3 E_3 
Stack 8
F_5 D_0 C_3 F_3 
Stack 9
D_4 D_5 J_2 C_0 
Stack 10
I_2 C_1 F_2 J_1 
Stack 11
E_5 A_0 F_4 
Stack 12
F_1 Z_104 D_3 
