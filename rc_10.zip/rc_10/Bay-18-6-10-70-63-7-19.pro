Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
F_2 G_6 B_2 D_0 
Stack 1
E_5 J_3 A_3 Z_100 
Stack 2
H_0 C_2 A_1 A_2 
Stack 3
H_1 F_6 F_7 C_6 
Stack 4
E_2 G_3 A_4 B_0 
Stack 5
B_1 D_5 I_0 F_0 
Stack 6
I_3 G_0 Z_101 C_1 
Stack 7
E_0 F_3 H_2 E_7 
Stack 8
Z_102 C_3 B_4 C_0 
Stack 9
D_1 D_6 A_0 E_4 
Stack 10
B_5 J_1 G_5 D_4 
Stack 11
H_4 Z_103 B_3 Z_104 
Stack 12
G_7 F_8 D_2 E_1 
Stack 13
F_1 G_2 E_3 J_2 
Stack 14
Z_105 F_4 J_0 C_4 
Stack 15
D_3 C_5 G_1 E_6 
Stack 16
G_4 I_2 H_3 
Stack 17
Z_106 I_1 F_5 
