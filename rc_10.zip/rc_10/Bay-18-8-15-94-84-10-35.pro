Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
G_8 I_7 E_0 D_4 D_1 H_4 
Stack 1
G_3 H_0 I_0 F_0 B_3 E_1 
Stack 2
C_0 H_6 L_4 H_5 O_0 J_0 
Stack 3
E_4 N_2 B_2 N_1 D_3 Z_100 
Stack 4
G_1 K_2 M_3 A_0 L_0 
Stack 5
L_3 G_2 B_0 K_0 J_1 
Stack 6
I_2 E_2 Z_101 I_4 O_2 
Stack 7
H_9 J_6 H_1 G_4 G_0 
Stack 8
G_6 G_7 I_5 E_3 M_0 
Stack 9
D_0 I_1 E_6 I_6 Z_102 
Stack 10
A_2 J_3 Z_103 K_1 O_1 
Stack 11
H_2 M_2 B_1 J_4 H_3 
Stack 12
Z_104 I_3 C_3 J_5 M_1 
Stack 13
G_5 L_2 E_5 D_5 F_1 
Stack 14
H_7 K_3 C_4 Z_105 F_3 
Stack 15
Z_106 L_1 D_2 H_8 C_1 
Stack 16
Z_107 Z_108 M_4 J_2 Z_109 
Stack 17
C_2 F_2 A_1 K_4 N_0 
