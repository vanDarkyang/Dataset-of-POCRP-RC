Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_5 D_11 D_8 B_3 D_14 A_0 
Stack 1
A_8 D_0 D_2 E_6 Z_100 Z_101 
Stack 2
A_12 C_15 A_3 A_13 Z_102 C_6 
Stack 3
E_5 D_7 A_11 A_1 E_7 A_6 
Stack 4
B_11 Z_103 D_5 C_1 Z_104 
Stack 5
B_5 C_12 D_10 Z_105 B_1 
Stack 6
D_1 C_7 E_8 D_13 D_9 
Stack 7
D_12 B_6 C_2 A_10 A_4 
Stack 8
B_2 D_3 C_13 D_6 A_14 
Stack 9
B_4 B_7 A_7 A_2 C_0 
Stack 10
C_14 B_9 D_15 C_9 E_4 
Stack 11
B_8 E_9 B_10 C_8 E_3 
Stack 12
C_11 Z_106 B_12 B_13 A_9 
Stack 13
E_0 E_2 Z_107 C_3 E_1 
Stack 14
B_0 C_4 C_10 C_5 D_4 
