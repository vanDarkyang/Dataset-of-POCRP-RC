Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
Z_100 E_4 F_3 F_4 
Stack 1
E_3 D_0 H_2 E_5 
Stack 2
C_2 H_4 G_1 G_2 
Stack 3
G_3 G_4 A_1 C_1 
Stack 4
B_1 Z_101 C_4 I_0 
Stack 5
F_1 H_1 J_2 B_3 
Stack 6
D_2 B_0 Z_102 D_4 
Stack 7
F_2 H_0 J_0 H_3 
Stack 8
D_3 E_1 Z_103 I_2 
Stack 9
F_5 I_1 A_2 A_0 
Stack 10
E_0 G_0 E_2 B_2 
Stack 11
J_1 F_0 D_1 
Stack 12
Z_104 C_0 C_3 
