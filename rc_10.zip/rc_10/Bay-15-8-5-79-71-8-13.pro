Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
Z_100 A_10 A_8 Z_101 C_12 B_12 
Stack 1
C_3 E_5 A_5 D_14 D_8 E_8 
Stack 2
E_10 Z_102 E_13 D_3 A_2 Z_103 
Stack 3
D_2 B_11 C_4 E_11 E_12 D_5 
Stack 4
B_3 C_9 E_2 B_8 C_2 
Stack 5
A_4 B_10 B_1 A_6 A_12 
Stack 6
D_11 E_7 A_1 C_6 D_1 
Stack 7
B_5 E_0 D_7 B_6 E_9 
Stack 8
D_10 A_7 A_3 B_0 C_1 
Stack 9
A_11 C_7 Z_104 B_4 C_11 
Stack 10
D_9 Z_105 C_13 C_5 Z_106 
Stack 11
C_0 D_12 B_9 B_7 E_1 
Stack 12
A_9 D_13 C_10 Z_107 E_6 
Stack 13
A_0 B_13 C_8 D_4 B_2 
Stack 14
D_6 E_14 E_3 E_4 D_0 
