Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_1 G_5 F_5 H_3 
Stack 1
E_2 D_4 F_0 I_1 
Stack 2
F_1 I_0 G_4 D_0 
Stack 3
E_3 F_6 E_4 H_2 
Stack 4
Z_100 B_1 H_1 D_2 
Stack 5
C_2 Z_101 A_0 J_0 
Stack 6
Z_102 A_2 E_0 F_4 
Stack 7
Z_103 C_0 Z_104 I_3 
Stack 8
F_3 G_3 G_2 D_1 
Stack 9
H_0 I_2 F_2 G_0 
Stack 10
J_2 E_5 E_1 J_1 
Stack 11
B_2 C_1 D_3 
Stack 12
G_1 B_0 E_6 
