Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
O_1 F_2 L_3 G_0 
Stack 1
C_1 D_4 Z_100 K_2 
Stack 2
J_1 E_2 J_2 G_1 
Stack 3
C_4 K_3 J_3 C_3 
Stack 4
O_2 Z_101 Z_102 Z_103 
Stack 5
E_1 H_7 F_6 E_6 
Stack 6
G_5 J_4 J_5 H_5 
Stack 7
M_0 I_4 Z_104 A_0 
Stack 8
D_1 C_0 N_3 H_4 
Stack 9
F_3 L_0 B_0 E_0 
Stack 10
K_1 Z_105 D_3 N_2 
Stack 11
H_3 H_2 L_5 B_1 
Stack 12
D_5 G_2 I_5 E_4 
Stack 13
M_1 B_2 Z_106 G_3 
Stack 14
G_7 A_1 M_3 F_4 
Stack 15
I_0 E_5 G_8 N_1 
Stack 16
F_5 M_2 L_4 Z_107 
Stack 17
I_3 A_2 O_0 J_0 
Stack 18
L_2 G_4 Z_108 I_6 
Stack 19
H_1 C_2 I_7 K_0 
Stack 20
H_0 I_1 D_2 H_6 
Stack 21
Z_109 I_2 K_4 L_1 
Stack 22
F_1 D_0 E_3 
Stack 23
F_0 G_6 N_0 
