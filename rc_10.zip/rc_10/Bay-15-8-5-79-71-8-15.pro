Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_8 C_7 E_9 C_10 C_5 B_13 
Stack 1
B_2 Z_100 E_11 B_0 E_2 E_12 
Stack 2
D_10 Z_101 C_9 C_8 E_4 B_11 
Stack 3
B_14 C_3 C_13 A_11 D_13 B_1 
Stack 4
D_0 C_1 B_4 Z_102 D_4 
Stack 5
A_2 C_6 A_9 D_7 E_0 
Stack 6
C_14 C_2 Z_103 E_1 D_5 
Stack 7
Z_104 D_8 D_15 E_5 E_8 
Stack 8
B_10 A_10 A_3 D_12 A_0 
Stack 9
B_3 A_1 A_7 A_5 B_5 
Stack 10
C_4 B_8 A_4 C_12 D_1 
Stack 11
E_7 B_6 E_6 E_10 E_3 
Stack 12
Z_105 D_2 D_14 C_0 Z_106 
Stack 13
B_12 D_11 D_3 B_7 B_9 
Stack 14
D_9 Z_107 D_6 A_6 C_11 
