Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
Z_100 E_1 D_1 H_2 
Stack 1
F_4 C_0 E_2 A_0 
Stack 2
Z_101 F_2 Z_102 E_5 
Stack 3
G_0 F_0 D_2 Z_103 
Stack 4
A_1 I_3 Z_104 D_5 
Stack 5
G_2 F_5 E_0 B_0 
Stack 6
H_0 G_1 I_0 J_1 
Stack 7
J_0 C_1 I_1 I_2 
Stack 8
C_3 E_4 D_3 A_2 
Stack 9
F_1 B_2 D_0 C_2 
Stack 10
B_1 G_3 E_3 F_3 
Stack 11
H_3 H_1 G_5 
Stack 12
G_4 D_4 J_2 
