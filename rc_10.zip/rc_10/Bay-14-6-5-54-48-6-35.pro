Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_4 B_1 B_2 E_8 
Stack 1
D_1 C_4 C_8 A_5 
Stack 2
D_6 C_10 C_7 E_9 
Stack 3
A_2 Z_100 C_6 E_2 
Stack 4
B_0 Z_101 D_4 C_9 
Stack 5
B_7 C_3 E_4 Z_102 
Stack 6
C_2 B_3 B_6 C_0 
Stack 7
Z_103 A_0 A_6 D_7 
Stack 8
E_5 C_5 A_7 E_7 
Stack 9
C_1 A_1 Z_104 D_5 
Stack 10
E_3 D_9 E_1 E_6 
Stack 11
D_8 Z_105 B_4 A_3 
Stack 12
B_8 D_3 B_5 
Stack 13
D_0 D_2 E_0 
