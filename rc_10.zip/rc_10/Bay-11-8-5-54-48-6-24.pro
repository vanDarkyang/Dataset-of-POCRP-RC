Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_3 C_3 C_9 D_7 D_6 
Stack 1
B_3 B_8 C_1 E_6 E_2 
Stack 2
A_4 E_5 B_0 B_5 Z_100 
Stack 3
Z_101 A_9 Z_102 D_3 D_4 
Stack 4
D_0 B_7 C_7 C_0 E_7 
Stack 5
D_8 C_2 E_3 D_9 D_5 
Stack 6
D_1 D_2 B_4 Z_103 A_2 
Stack 7
A_0 C_6 C_8 E_0 A_6 
Stack 8
C_10 A_5 A_8 A_1 B_2 
Stack 9
B_1 C_5 E_4 Z_104 Z_105 
Stack 10
B_6 E_1 A_7 C_4 
