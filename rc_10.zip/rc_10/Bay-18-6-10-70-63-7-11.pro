Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
J_0 Z_100 G_1 I_2 
Stack 1
E_3 E_5 E_0 J_3 
Stack 2
Z_101 A_2 F_3 F_7 
Stack 3
F_1 D_6 I_1 A_4 
Stack 4
C_1 Z_102 F_2 G_4 
Stack 5
H_4 F_0 Z_103 E_4 
Stack 6
D_1 Z_104 C_4 B_1 
Stack 7
C_5 E_2 F_4 H_6 
Stack 8
J_1 E_6 C_2 F_5 
Stack 9
G_3 I_3 D_5 E_1 
Stack 10
B_4 G_2 I_0 I_4 
Stack 11
B_5 E_8 H_2 D_2 
Stack 12
G_0 Z_105 D_3 H_3 
Stack 13
D_4 H_1 B_3 A_0 
Stack 14
C_3 A_1 F_6 Z_106 
Stack 15
G_5 H_5 D_0 H_0 
Stack 16
J_2 B_0 E_7 
Stack 17
A_3 B_2 C_0 
