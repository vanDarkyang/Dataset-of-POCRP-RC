Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
F_1 D_4 J_1 H_4 A_2 
Stack 1
E_4 D_3 Z_100 H_2 C_5 
Stack 2
H_0 G_4 F_7 Z_101 B_0 
Stack 3
H_1 H_6 G_2 A_0 F_0 
Stack 4
E_0 G_6 F_3 G_5 C_1 
Stack 5
B_1 J_4 C_4 B_3 E_6 
Stack 6
I_3 Z_102 I_1 D_2 C_0 
Stack 7
Z_103 F_5 I_0 E_2 E_3 
Stack 8
J_2 G_3 B_2 J_0 D_5 
Stack 9
D_1 D_6 A_3 G_1 E_1 
Stack 10
B_4 G_0 A_1 H_3 Z_104 
Stack 11
H_5 F_2 F_6 F_4 J_3 
Stack 12
G_7 C_2 A_4 D_0 C_3 
Stack 13
Z_105 D_7 Z_106 I_2 E_5 
