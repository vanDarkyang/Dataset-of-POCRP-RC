Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_4 Z_100 B_14 E_8 
Stack 1
B_12 D_0 Z_101 Z_102 
Stack 2
A_0 Z_103 A_10 C_3 
Stack 3
D_6 C_1 D_10 D_14 
Stack 4
Z_104 D_3 B_11 B_13 
Stack 5
D_5 A_6 E_11 Z_105 
Stack 6
C_6 A_2 A_5 A_8 
Stack 7
C_2 C_9 A_14 E_2 
Stack 8
E_7 B_6 E_6 D_7 
Stack 9
A_9 C_13 D_2 B_9 
Stack 10
C_10 B_7 A_3 B_0 
Stack 11
C_0 B_2 D_9 B_10 
Stack 12
C_7 D_13 Z_106 E_5 
Stack 13
D_4 E_10 C_5 D_8 
Stack 14
B_5 E_9 A_11 E_1 
Stack 15
C_12 B_3 D_12 E_0 
Stack 16
A_13 A_1 C_11 D_11 
Stack 17
B_4 E_3 A_12 Z_107 
Stack 18
C_8 D_1 B_1 A_7 
Stack 19
B_8 E_4 C_4 
