Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
J_7 B_2 H_3 Z_100 J_5 D_8 
Stack 1
D_3 A_8 C_5 Z_101 D_1 F_7 
Stack 2
H_9 J_6 J_0 B_5 E_10 C_3 
Stack 3
G_9 F_11 F_9 Z_102 B_1 B_9 
Stack 4
Z_103 C_7 I_6 B_4 C_9 F_5 
Stack 5
F_0 E_5 E_8 E_12 B_0 
Stack 6
G_7 I_5 H_4 C_8 Z_104 
Stack 7
J_9 G_2 I_4 Z_105 Z_106 
Stack 8
D_5 A_1 E_13 I_2 B_6 
Stack 9
I_8 I_1 A_7 H_5 B_7 
Stack 10
D_9 Z_107 B_3 D_4 E_0 
Stack 11
D_6 H_6 I_0 J_2 Z_108 
Stack 12
C_1 D_7 A_0 E_2 F_1 
Stack 13
J_1 G_0 A_3 G_6 J_4 
Stack 14
G_3 H_8 D_10 I_3 A_6 
Stack 15
C_4 D_11 B_10 Z_109 C_0 
Stack 16
B_8 A_5 G_5 C_6 H_7 
Stack 17
G_1 C_2 E_4 H_1 I_7 
Stack 18
D_0 J_8 F_2 F_4 H_2 
Stack 19
G_8 F_10 A_2 I_9 F_3 
Stack 20
A_4 E_3 F_6 E_9 Z_110 
Stack 21
D_2 E_1 F_8 E_6 Z_111 
Stack 22
H_0 J_3 G_4 E_7 E_11 
