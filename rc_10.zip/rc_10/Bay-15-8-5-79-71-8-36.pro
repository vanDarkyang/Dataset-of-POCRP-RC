Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_10 A_12 B_10 E_8 D_4 D_5 
Stack 1
D_7 B_12 D_12 Z_100 E_1 D_11 
Stack 2
D_3 A_4 B_0 B_5 C_6 C_4 
Stack 3
B_7 Z_101 A_2 Z_102 E_12 C_14 
Stack 4
B_8 A_11 Z_103 C_3 E_6 
Stack 5
B_6 B_11 A_0 E_5 D_2 
Stack 6
C_7 A_5 C_10 C_5 A_9 
Stack 7
A_8 Z_104 D_13 B_4 D_10 
Stack 8
E_4 A_3 B_3 C_1 E_13 
Stack 9
C_9 C_12 E_10 D_9 D_6 
Stack 10
B_9 B_1 D_0 C_8 A_7 
Stack 11
A_1 C_15 E_9 Z_105 E_11 
Stack 12
E_2 A_6 C_0 B_2 C_11 
Stack 13
E_3 D_8 E_14 Z_106 D_1 
Stack 14
C_2 E_7 E_0 C_13 Z_107 
