Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_3 A_6 B_5 B_1 C_5 
Stack 1
D_7 A_5 Z_100 A_9 C_2 
Stack 2
E_8 Z_101 A_0 E_2 D_6 
Stack 3
A_8 Z_102 Z_103 D_4 B_3 
Stack 4
C_1 B_2 A_2 C_0 C_4 
Stack 5
E_0 B_6 E_9 D_0 B_8 
Stack 6
D_5 Z_104 D_1 B_0 C_6 
Stack 7
E_5 A_4 E_6 B_7 E_1 
Stack 8
C_9 C_3 D_2 C_8 Z_105 
Stack 9
E_4 B_4 A_1 A_3 C_7 
Stack 10
A_7 D_8 E_3 E_7 
