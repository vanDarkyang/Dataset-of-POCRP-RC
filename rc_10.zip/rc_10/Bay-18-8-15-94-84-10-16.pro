Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
M_1 I_0 F_2 H_2 L_1 J_4 
Stack 1
D_3 F_3 C_4 K_1 F_4 H_6 
Stack 2
Z_100 G_4 J_2 G_3 E_0 E_3 
Stack 3
L_3 E_2 C_2 B_2 Z_101 O_1 
Stack 4
J_3 K_3 F_6 A_1 K_0 
Stack 5
F_5 Z_102 K_5 E_5 F_0 
Stack 6
E_4 D_1 I_3 K_2 N_0 
Stack 7
C_3 G_1 G_5 B_3 G_7 
Stack 8
I_4 I_8 Z_103 L_2 L_4 
Stack 9
B_0 Z_104 G_6 N_1 N_2 
Stack 10
Z_105 I_5 J_1 I_1 G_2 
Stack 11
M_4 B_1 O_0 I_2 E_1 
Stack 12
D_0 J_0 H_0 Z_106 I_7 
Stack 13
M_3 G_0 L_0 Z_107 H_1 
Stack 14
G_8 F_1 J_6 D_4 Z_108 
Stack 15
M_0 H_5 M_2 Z_109 K_4 
Stack 16
C_0 I_6 H_8 C_1 D_2 
Stack 17
H_4 H_3 J_5 H_7 A_0 
