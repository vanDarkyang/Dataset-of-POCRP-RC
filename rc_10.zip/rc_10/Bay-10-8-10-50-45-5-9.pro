Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_1 F_0 G_2 D_3 I_2 
Stack 1
Z_100 D_1 F_2 H_1 Z_101 
Stack 2
E_0 Z_102 J_0 E_2 B_1 
Stack 3
B_0 I_1 J_2 F_5 C_1 
Stack 4
B_2 H_2 D_2 C_3 I_0 
Stack 5
E_3 Z_103 F_6 D_4 A_2 
Stack 6
C_0 F_1 C_2 H_3 F_3 
Stack 7
E_4 E_1 F_4 G_3 E_5 
Stack 8
G_1 J_1 C_4 G_4 G_0 
Stack 9
A_0 H_0 Z_104 D_0 D_5 
