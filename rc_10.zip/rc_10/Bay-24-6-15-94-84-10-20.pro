Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
K_2 F_5 F_4 B_1 
Stack 1
I_0 H_6 G_2 G_8 
Stack 2
F_1 O_1 G_4 H_2 
Stack 3
F_3 I_1 Z_100 L_4 
Stack 4
H_0 G_1 G_7 N_0 
Stack 5
E_2 F_0 J_2 G_6 
Stack 6
G_0 F_6 E_0 A_0 
Stack 7
E_4 C_0 I_6 J_0 
Stack 8
C_2 L_3 L_1 G_5 
Stack 9
L_2 H_9 M_1 M_0 
Stack 10
C_1 I_2 B_2 O_2 
Stack 11
H_5 O_0 M_2 Z_101 
Stack 12
D_0 K_3 J_6 H_7 
Stack 13
I_3 H_1 J_3 Z_102 
Stack 14
B_0 H_8 J_5 L_5 
Stack 15
N_2 K_5 Z_103 L_0 
Stack 16
Z_104 Z_105 G_3 E_3 
Stack 17
F_7 N_1 I_4 C_3 
Stack 18
I_7 H_4 K_0 E_1 
Stack 19
K_4 D_1 J_1 Z_106 
Stack 20
Z_107 H_3 K_1 C_4 
Stack 21
M_4 Z_108 I_8 M_3 
Stack 22
J_4 I_5 E_5 
Stack 23
Z_109 D_2 F_2 
