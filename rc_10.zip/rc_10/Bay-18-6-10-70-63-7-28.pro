Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_2 G_2 H_4 B_0 
Stack 1
F_7 I_3 H_3 A_2 
Stack 2
E_5 E_0 E_4 Z_100 
Stack 3
D_0 D_1 B_3 I_5 
Stack 4
E_1 F_4 D_5 E_8 
Stack 5
H_2 Z_101 E_2 F_2 
Stack 6
B_2 J_4 J_3 H_1 
Stack 7
Z_102 I_1 J_1 G_6 
Stack 8
G_5 F_5 E_7 G_3 
Stack 9
G_0 F_3 H_5 Z_103 
Stack 10
G_7 A_1 F_0 I_4 
Stack 11
I_2 C_0 Z_104 C_1 
Stack 12
F_6 J_2 B_1 D_6 
Stack 13
A_0 H_6 E_3 F_1 
Stack 14
G_1 D_4 J_0 Z_105 
Stack 15
Z_106 D_2 D_3 E_6 
Stack 16
B_4 C_3 C_4 
Stack 17
H_0 G_4 I_0 
