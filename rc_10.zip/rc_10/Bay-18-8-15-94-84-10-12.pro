Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
G_4 J_2 G_1 G_7 D_4 M_0 
Stack 1
E_4 H_1 D_0 M_1 L_2 C_2 
Stack 2
K_3 Z_100 J_1 K_5 H_6 L_1 
Stack 3
N_0 F_3 F_5 E_5 J_4 D_3 
Stack 4
A_1 E_1 Z_101 Z_102 L_4 
Stack 5
D_1 F_2 C_1 M_2 Z_103 
Stack 6
F_1 F_0 I_4 K_4 G_3 
Stack 7
H_2 F_4 J_0 N_2 H_8 
Stack 8
C_4 H_0 B_0 H_5 C_0 
Stack 9
A_2 H_9 O_0 E_0 I_1 
Stack 10
O_2 G_5 K_0 J_5 J_6 
Stack 11
A_0 G_6 N_1 M_4 B_1 
Stack 12
Z_104 Z_105 L_3 Z_106 I_6 
Stack 13
J_3 B_2 E_2 M_3 B_3 
Stack 14
I_0 F_6 I_5 D_2 H_3 
Stack 15
H_4 H_7 I_3 O_1 Z_107 
Stack 16
K_2 Z_108 I_2 L_0 E_3 
Stack 17
C_3 G_0 G_2 Z_109 K_1 
