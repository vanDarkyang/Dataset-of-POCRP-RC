Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_2 Z_100 B_1 Z_101 
Stack 1
D_0 F_4 C_0 J_2 
Stack 2
A_1 F_2 D_2 F_0 
Stack 3
D_6 Z_102 I_0 I_2 
Stack 4
G_6 F_1 E_2 D_7 
Stack 5
F_5 B_5 C_3 I_5 
Stack 6
G_2 B_4 Z_103 H_1 
Stack 7
F_7 D_4 Z_104 B_2 
Stack 8
B_0 G_3 E_6 A_4 
Stack 9
Z_105 F_6 J_0 I_1 
Stack 10
C_4 H_0 E_5 F_3 
Stack 11
G_4 E_0 H_2 I_3 
Stack 12
C_1 G_0 E_3 D_5 
Stack 13
H_3 G_5 D_3 H_5 
Stack 14
C_5 A_2 E_4 A_0 
Stack 15
D_1 A_3 Z_106 G_1 
Stack 16
B_3 J_1 H_6 
Stack 17
E_1 I_4 H_4 
