Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_5 E_0 E_2 Z_100 
Stack 1
A_0 B_7 E_7 D_7 
Stack 2
C_9 A_8 C_2 A_4 
Stack 3
C_7 D_10 D_0 C_3 
Stack 4
B_3 D_1 D_4 B_6 
Stack 5
A_6 B_1 A_5 Z_101 
Stack 6
Z_102 A_3 B_4 E_1 
Stack 7
A_1 D_6 C_5 E_6 
Stack 8
D_8 C_6 B_0 Z_103 
Stack 9
C_8 E_8 Z_104 D_3 
Stack 10
Z_105 E_3 C_10 C_4 
Stack 11
A_7 E_5 A_2 D_5 
Stack 12
D_9 D_2 C_1 
Stack 13
C_0 E_4 B_2 
