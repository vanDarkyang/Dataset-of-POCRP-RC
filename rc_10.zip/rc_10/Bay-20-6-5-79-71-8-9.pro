Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_2 Z_100 C_5 D_7 
Stack 1
C_3 C_2 Z_101 D_3 
Stack 2
C_10 D_1 B_12 A_1 
Stack 3
B_9 D_8 Z_102 A_8 
Stack 4
A_3 E_2 D_13 E_14 
Stack 5
E_12 C_11 D_4 B_8 
Stack 6
B_1 E_10 B_10 E_9 
Stack 7
A_5 D_9 C_1 A_0 
Stack 8
Z_103 E_1 D_6 B_2 
Stack 9
E_7 C_7 B_0 E_5 
Stack 10
B_7 B_3 D_2 D_10 
Stack 11
D_0 B_6 C_6 A_11 
Stack 12
B_5 A_4 E_11 A_9 
Stack 13
C_8 C_0 E_4 E_8 
Stack 14
A_12 C_14 C_12 A_6 
Stack 15
E_13 A_10 B_4 E_6 
Stack 16
Z_104 D_11 E_0 C_4 
Stack 17
B_13 D_12 Z_105 B_11 
Stack 18
A_7 E_3 C_9 C_13 
Stack 19
Z_106 Z_107 D_5 
