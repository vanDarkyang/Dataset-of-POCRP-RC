Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
N_0 B_1 L_0 E_4 
Stack 1
F_1 M_0 Z_100 M_4 
Stack 2
D_1 F_0 A_1 J_0 
Stack 3
E_5 L_1 H_7 M_2 
Stack 4
C_3 I_0 Z_101 F_2 
Stack 5
G_2 E_0 C_2 J_4 
Stack 6
G_4 Z_102 Z_103 E_3 
Stack 7
J_5 G_7 G_6 H_5 
Stack 8
O_1 J_2 L_2 B_2 
Stack 9
F_6 M_3 K_0 I_4 
Stack 10
J_3 H_2 O_2 F_7 
Stack 11
K_4 K_2 D_5 I_3 
Stack 12
Z_104 D_4 J_1 E_1 
Stack 13
A_0 H_6 L_5 H_1 
Stack 14
N_2 M_1 F_4 H_4 
Stack 15
G_5 D_3 K_3 D_2 
Stack 16
D_0 Z_105 I_7 C_0 
Stack 17
N_3 N_1 L_4 G_0 
Stack 18
Z_106 I_6 Z_107 G_1 
Stack 19
Z_108 Z_109 G_3 C_1 
Stack 20
L_3 E_2 F_3 H_0 
Stack 21
B_3 I_1 O_0 B_0 
Stack 22
F_5 I_2 A_2 
Stack 23
H_3 I_5 K_1 
