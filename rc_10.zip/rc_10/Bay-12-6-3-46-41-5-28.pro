Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_2 A_0 A_6 C_0 
Stack 1
B_11 A_3 B_7 B_0 
Stack 2
A_10 Z_100 B_4 Z_101 
Stack 3
B_5 Z_102 B_14 A_1 
Stack 4
C_9 A_12 A_7 B_9 
Stack 5
Z_103 A_9 B_10 C_5 
Stack 6
C_6 Z_104 B_12 C_12 
Stack 7
A_8 A_4 A_5 C_2 
Stack 8
C_10 A_11 B_8 C_8 
Stack 9
C_7 C_4 A_2 B_3 
Stack 10
B_1 C_1 C_11 
Stack 11
C_3 B_6 B_13 
