Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_7 B_10 E_7 D_10 
Stack 1
B_0 Z_100 E_3 E_0 
Stack 2
A_6 A_3 Z_101 E_6 
Stack 3
C_8 C_1 B_1 D_9 
Stack 4
B_6 D_1 B_2 B_3 
Stack 5
Z_102 C_2 D_5 C_9 
Stack 6
E_2 C_7 Z_103 D_3 
Stack 7
B_8 D_6 A_2 Z_104 
Stack 8
A_0 C_10 E_1 B_5 
Stack 9
Z_105 D_4 D_2 A_4 
Stack 10
E_4 D_7 C_3 C_6 
Stack 11
B_4 A_1 D_8 E_5 
Stack 12
C_4 C_5 D_0 
Stack 13
A_5 B_9 C_0 
