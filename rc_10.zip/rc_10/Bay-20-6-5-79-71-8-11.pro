Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
D_11 E_3 D_10 Z_100 
Stack 1
C_7 A_4 D_6 Z_101 
Stack 2
B_0 C_6 Z_102 C_3 
Stack 3
C_14 B_3 D_0 E_9 
Stack 4
C_1 C_0 A_3 E_4 
Stack 5
A_12 C_11 B_2 A_0 
Stack 6
E_10 B_11 A_9 Z_103 
Stack 7
A_11 D_12 D_5 E_8 
Stack 8
E_1 C_5 E_2 C_13 
Stack 9
D_7 B_8 D_8 D_3 
Stack 10
B_12 B_7 D_14 Z_104 
Stack 11
B_9 B_4 C_2 B_13 
Stack 12
Z_105 A_8 D_4 E_5 
Stack 13
C_8 A_1 B_14 A_2 
Stack 14
B_10 Z_106 Z_107 A_6 
Stack 15
E_11 E_12 C_9 B_6 
Stack 16
C_12 D_1 D_9 B_5 
Stack 17
A_5 C_10 D_13 E_7 
Stack 18
C_4 E_6 A_7 B_1 
Stack 19
A_10 E_0 D_2 
