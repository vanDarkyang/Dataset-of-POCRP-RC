Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
H_0 G_2 A_0 I_0 
Stack 1
E_4 E_0 D_1 C_0 
Stack 2
Z_100 F_1 H_4 C_4 
Stack 3
F_2 I_2 G_3 D_3 
Stack 4
Z_101 E_1 B_0 Z_102 
Stack 5
D_2 A_1 F_3 E_5 
Stack 6
C_1 D_0 I_1 E_3 
Stack 7
D_4 F_0 I_3 A_2 
Stack 8
C_2 G_4 J_2 F_4 
Stack 9
J_0 G_0 H_3 Z_103 
Stack 10
Z_104 G_5 B_2 C_3 
Stack 11
H_1 E_2 J_1 
Stack 12
B_1 H_2 G_1 
