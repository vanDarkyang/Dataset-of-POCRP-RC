Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_0 Z_100 F_3 F_1 C_4 
Stack 1
C_0 F_4 H_2 H_0 B_1 
Stack 2
E_2 Z_101 I_1 J_0 A_1 
Stack 3
B_3 F_0 J_2 A_2 E_1 
Stack 4
D_2 D_0 D_1 H_1 H_3 
Stack 5
C_1 E_0 G_4 G_1 J_1 
Stack 6
I_3 F_2 D_4 Z_102 B_2 
Stack 7
E_4 A_0 C_2 I_0 G_5 
Stack 8
C_3 I_2 E_3 Z_103 Z_104 
Stack 9
G_3 D_3 G_2 E_5 G_0 
