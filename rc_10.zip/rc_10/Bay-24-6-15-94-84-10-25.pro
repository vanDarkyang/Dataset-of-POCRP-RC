Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
M_3 G_3 G_1 F_2 
Stack 1
K_1 L_4 H_1 A_1 
Stack 2
N_0 G_6 F_3 Z_100 
Stack 3
I_8 C_0 I_4 J_1 
Stack 4
C_2 H_3 D_5 M_2 
Stack 5
B_1 Z_101 C_3 A_0 
Stack 6
M_0 G_5 J_4 H_8 
Stack 7
C_1 I_5 J_0 L_0 
Stack 8
C_4 E_3 M_1 L_1 
Stack 9
O_2 J_3 O_0 G_8 
Stack 10
Z_102 F_1 D_1 E_1 
Stack 11
I_6 E_6 Z_103 O_1 
Stack 12
H_2 N_1 D_4 N_3 
Stack 13
L_3 K_2 N_2 E_2 
Stack 14
Z_104 H_4 I_7 G_0 
Stack 15
Z_105 I_2 E_0 G_7 
Stack 16
H_5 B_0 J_5 H_7 
Stack 17
H_0 F_0 K_0 D_2 
Stack 18
D_3 I_1 I_0 J_6 
Stack 19
J_2 I_3 L_2 K_4 
Stack 20
H_6 E_4 K_3 F_5 
Stack 21
Z_106 D_0 E_5 G_4 
Stack 22
Z_107 Z_108 Z_109 
Stack 23
F_4 F_6 G_2 
