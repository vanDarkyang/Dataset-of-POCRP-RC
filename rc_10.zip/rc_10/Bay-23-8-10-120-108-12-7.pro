Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
G_1 B_4 G_11 A_8 F_5 F_8 
Stack 1
C_0 F_9 Z_100 E_9 J_6 G_4 
Stack 2
D_9 E_7 G_0 Z_101 C_3 A_1 
Stack 3
E_0 C_4 A_3 J_4 I_0 I_2 
Stack 4
D_3 A_2 A_6 H_3 D_8 E_1 
Stack 5
E_5 D_6 I_10 G_2 Z_102 
Stack 6
B_6 Z_103 G_5 E_4 G_6 
Stack 7
B_2 C_6 I_1 H_4 B_1 
Stack 8
D_4 B_9 I_9 F_7 Z_104 
Stack 9
Z_105 F_4 E_10 H_6 A_4 
Stack 10
E_6 J_0 I_8 D_10 J_2 
Stack 11
E_3 C_8 G_3 H_8 F_1 
Stack 12
F_3 G_9 B_7 J_3 H_5 
Stack 13
D_5 E_8 G_10 H_9 F_12 
Stack 14
H_2 G_8 J_7 Z_106 D_0 
Stack 15
B_8 A_0 I_5 G_7 Z_107 
Stack 16
I_3 B_0 H_7 I_4 F_0 
Stack 17
A_9 B_5 Z_108 H_1 F_10 
Stack 18
A_7 C_7 D_2 D_1 J_1 
Stack 19
A_5 I_7 J_8 Z_109 H_0 
Stack 20
Z_110 J_5 F_11 C_5 F_6 
Stack 21
C_1 B_3 I_6 D_7 C_2 
Stack 22
J_9 F_2 E_2 H_10 Z_111 
