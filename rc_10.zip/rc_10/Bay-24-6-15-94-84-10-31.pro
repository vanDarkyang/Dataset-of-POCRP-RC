Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
K_1 H_4 J_5 M_2 
Stack 1
L_4 D_4 Z_100 G_6 
Stack 2
N_2 H_7 J_0 H_5 
Stack 3
G_5 K_4 B_0 K_2 
Stack 4
C_0 Z_101 N_3 F_5 
Stack 5
D_1 Z_102 G_4 K_0 
Stack 6
G_7 E_0 E_2 H_6 
Stack 7
J_2 K_3 I_4 Z_103 
Stack 8
I_6 I_8 Z_104 I_0 
Stack 9
F_1 B_2 L_5 L_1 
Stack 10
G_0 F_0 Z_105 C_3 
Stack 11
I_2 G_1 G_2 N_0 
Stack 12
E_5 D_0 A_1 C_1 
Stack 13
E_3 H_3 J_6 Z_106 
Stack 14
F_7 G_3 O_1 O_0 
Stack 15
K_5 A_0 J_3 Z_107 
Stack 16
F_6 I_5 D_3 F_2 
Stack 17
I_1 I_3 F_3 H_1 
Stack 18
F_4 L_0 B_1 A_2 
Stack 19
B_3 J_1 L_2 M_0 
Stack 20
M_1 J_4 H_2 Z_108 
Stack 21
H_0 D_2 Z_109 N_1 
Stack 22
I_7 L_3 E_1 
Stack 23
C_2 H_8 E_4 
