Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_10 B_10 C_15 C_14 
Stack 1
C_4 E_7 B_9 D_8 
Stack 2
Z_100 E_0 C_12 A_2 
Stack 3
D_1 A_8 C_9 E_10 
Stack 4
B_3 C_8 E_3 C_3 
Stack 5
A_4 D_7 C_1 A_13 
Stack 6
D_11 D_12 Z_101 D_0 
Stack 7
B_6 D_13 D_2 E_9 
Stack 8
D_10 B_13 Z_102 C_2 
Stack 9
A_12 E_11 B_8 C_13 
Stack 10
D_9 A_9 Z_103 B_4 
Stack 11
C_0 A_6 C_7 E_1 
Stack 12
A_10 Z_104 Z_105 E_6 
Stack 13
A_0 C_5 B_0 B_2 
Stack 14
D_5 E_2 B_5 Z_106 
Stack 15
A_11 B_1 C_6 B_12 
Stack 16
E_5 A_1 B_7 E_8 
Stack 17
A_5 D_6 Z_107 A_7 
Stack 18
B_11 A_3 D_3 D_4 
Stack 19
C_11 B_14 E_4 
