Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_2 B_6 E_3 Z_100 E_4 
Stack 1
C_4 Z_101 B_4 C_0 Z_102 
Stack 2
B_10 D_2 D_6 A_3 Z_103 
Stack 3
D_10 E_1 C_5 Z_104 A_1 
Stack 4
B_7 D_0 C_1 Z_105 A_0 
Stack 5
A_7 D_3 D_4 D_7 B_0 
Stack 6
B_5 B_1 D_8 E_5 D_1 
Stack 7
A_4 E_6 E_2 D_9 C_6 
Stack 8
C_3 C_7 B_3 E_7 D_5 
Stack 9
E_8 A_5 B_9 A_6 A_2 
Stack 10
B_2 A_8 E_0 B_8 
