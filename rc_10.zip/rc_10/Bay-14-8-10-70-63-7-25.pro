Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_0 C_2 A_1 H_0 G_2 
Stack 1
H_1 D_3 H_4 I_1 B_1 
Stack 2
B_3 F_4 Z_100 E_3 I_4 
Stack 3
E_1 J_2 C_0 E_5 I_5 
Stack 4
F_2 H_2 F_0 D_2 A_2 
Stack 5
H_6 G_0 F_6 F_5 C_4 
Stack 6
A_0 J_1 D_4 E_2 H_5 
Stack 7
G_6 D_6 F_7 C_1 Z_101 
Stack 8
F_1 J_0 D_1 Z_102 G_3 
Stack 9
G_1 A_4 C_3 G_5 G_4 
Stack 10
E_6 B_0 E_0 I_3 F_3 
Stack 11
D_5 E_4 I_2 Z_103 J_3 
Stack 12
B_2 D_7 I_0 A_3 Z_104 
Stack 13
Z_105 H_3 Z_106 C_5 F_8 
