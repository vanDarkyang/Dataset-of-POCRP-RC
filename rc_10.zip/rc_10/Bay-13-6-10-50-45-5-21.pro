Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
F_1 E_0 Z_100 I_0 
Stack 1
B_2 Z_101 G_0 Z_102 
Stack 2
A_2 B_1 I_3 C_1 
Stack 3
A_0 B_3 J_2 E_6 
Stack 4
F_5 G_3 D_3 H_1 
Stack 5
D_0 E_1 D_2 J_0 
Stack 6
D_4 F_0 G_2 C_2 
Stack 7
F_4 E_3 G_4 E_5 
Stack 8
G_1 E_2 J_1 D_5 
Stack 9
C_3 C_0 B_0 Z_103 
Stack 10
E_4 Z_104 F_3 H_0 
Stack 11
D_1 F_2 I_1 
Stack 12
H_2 I_2 A_1 
