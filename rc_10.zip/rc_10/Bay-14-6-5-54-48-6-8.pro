Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_4 Z_100 Z_101 E_5 
Stack 1
Z_102 E_8 C_6 B_10 
Stack 2
B_0 A_0 E_0 Z_103 
Stack 3
B_9 D_4 D_8 D_7 
Stack 4
A_4 D_5 D_2 C_7 
Stack 5
C_9 C_4 B_1 E_4 
Stack 6
A_7 E_2 A_3 B_7 
Stack 7
C_8 C_5 D_3 B_5 
Stack 8
A_5 C_2 C_0 E_7 
Stack 9
B_6 Z_104 A_6 B_8 
Stack 10
D_1 C_1 Z_105 D_6 
Stack 11
B_2 C_3 E_1 A_2 
Stack 12
B_3 A_1 E_6 
Stack 13
D_0 C_10 E_3 
