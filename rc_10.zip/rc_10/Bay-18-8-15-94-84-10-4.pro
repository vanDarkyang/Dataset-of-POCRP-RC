Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
K_0 H_8 E_5 K_1 Z_100 Z_101 
Stack 1
B_0 F_7 J_2 E_6 E_4 G_0 
Stack 2
L_1 J_1 F_1 H_2 Z_102 G_1 
Stack 3
H_6 K_2 O_1 I_5 D_1 A_0 
Stack 4
Z_103 B_1 K_6 M_0 E_1 
Stack 5
O_2 F_0 H_1 G_7 C_3 
Stack 6
Z_104 G_5 L_2 C_2 L_3 
Stack 7
J_0 H_7 A_1 J_4 A_2 
Stack 8
E_0 F_6 F_2 J_3 G_6 
Stack 9
N_1 H_3 D_0 H_9 M_1 
Stack 10
K_4 L_0 F_4 J_5 L_4 
Stack 11
D_2 I_4 G_8 I_3 F_3 
Stack 12
I_0 E_2 K_3 H_0 Z_105 
Stack 13
I_1 Z_106 C_1 H_5 Z_107 
Stack 14
D_3 E_3 B_2 K_5 G_4 
Stack 15
G_3 Z_108 I_6 M_2 O_0 
Stack 16
G_2 D_4 N_0 N_2 C_4 
Stack 17
H_4 F_5 C_0 I_2 Z_109 
