Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 G_4 A_0 M_1 
Stack 1
I_3 Z_101 F_3 K_3 
Stack 2
C_0 N_0 F_2 Z_102 
Stack 3
K_0 L_2 H_1 K_4 
Stack 4
D_3 G_2 M_2 E_3 
Stack 5
H_4 J_1 E_4 I_7 
Stack 6
C_4 J_6 H_3 K_1 
Stack 7
N_2 Z_103 Z_104 C_2 
Stack 8
Z_105 G_5 I_4 H_0 
Stack 9
E_0 L_1 M_3 L_5 
Stack 10
B_2 E_2 I_8 H_2 
Stack 11
F_4 L_4 M_4 A_2 
Stack 12
G_6 J_4 O_0 F_5 
Stack 13
H_5 J_5 H_6 G_1 
Stack 14
Z_106 E_5 L_3 I_6 
Stack 15
Z_107 C_1 A_1 F_0 
Stack 16
H_8 J_0 D_0 L_0 
Stack 17
Z_108 K_2 Z_109 C_3 
Stack 18
D_1 G_0 O_2 E_1 
Stack 19
N_1 I_2 H_7 I_5 
Stack 20
J_7 O_1 G_3 I_1 
Stack 21
G_7 B_0 M_0 J_3 
Stack 22
F_1 I_0 B_1 
Stack 23
D_2 B_3 J_2 
