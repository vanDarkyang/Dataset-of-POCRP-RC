Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_3 Z_100 D_3 E_4 A_6 
Stack 1
B_9 D_8 C_6 A_0 B_7 
Stack 2
C_1 C_0 A_1 C_4 D_0 
Stack 3
Z_101 B_6 B_2 Z_102 D_10 
Stack 4
B_0 D_7 Z_103 D_5 D_9 
Stack 5
A_3 C_2 E_2 B_4 B_1 
Stack 6
Z_104 E_0 A_2 A_7 B_3 
Stack 7
D_2 E_8 E_9 E_6 E_3 
Stack 8
D_6 E_5 D_4 B_8 C_7 
Stack 9
E_1 C_5 C_8 A_4 D_1 
Stack 10
E_7 Z_105 B_5 A_5 
