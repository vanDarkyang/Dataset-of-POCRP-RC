Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
N_3 I_1 J_2 N_2 
Stack 1
K_2 J_6 E_1 E_2 
Stack 2
L_2 K_3 J_7 M_0 
Stack 3
J_4 M_4 H_6 I_7 
Stack 4
E_3 N_1 G_8 Z_100 
Stack 5
G_2 G_7 I_6 M_1 
Stack 6
Z_101 I_0 C_0 H_4 
Stack 7
O_0 D_0 M_2 N_0 
Stack 8
C_2 H_1 G_1 F_1 
Stack 9
Z_102 I_2 H_0 O_1 
Stack 10
L_4 M_3 J_5 Z_103 
Stack 11
G_4 F_4 L_1 H_3 
Stack 12
Z_104 K_1 H_2 Z_105 
Stack 13
G_3 I_5 K_0 G_5 
Stack 14
H_7 O_2 E_0 B_0 
Stack 15
B_3 D_4 J_0 D_3 
Stack 16
K_4 J_3 I_4 Z_106 
Stack 17
D_1 Z_107 I_3 K_5 
Stack 18
L_0 F_6 D_2 F_3 
Stack 19
H_5 F_5 G_0 A_2 
Stack 20
B_1 A_0 L_5 F_2 
Stack 21
J_1 A_1 C_1 L_3 
Stack 22
B_2 G_6 D_5 
Stack 23
Z_108 F_0 Z_109 
