Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
E_2 F_6 B_2 F_5 
Stack 1
H_0 J_4 C_5 D_7 
Stack 2
F_1 E_6 D_1 C_1 
Stack 3
Z_100 E_3 E_1 D_2 
Stack 4
G_4 I_5 Z_101 I_3 
Stack 5
Z_102 D_3 B_3 I_2 
Stack 6
Z_103 I_1 A_1 G_0 
Stack 7
Z_104 J_3 E_4 F_0 
Stack 8
F_7 F_2 D_4 B_0 
Stack 9
C_4 G_2 A_2 E_5 
Stack 10
B_1 G_1 A_3 J_2 
Stack 11
J_1 D_6 H_5 E_0 
Stack 12
A_0 H_1 J_0 A_4 
Stack 13
I_0 F_4 C_3 F_3 
Stack 14
B_5 H_6 D_0 B_4 
Stack 15
Z_105 D_5 H_4 H_2 
Stack 16
Z_106 C_0 H_3 
Stack 17
C_2 G_3 I_4 
