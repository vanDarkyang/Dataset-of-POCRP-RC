Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
L_3 L_5 H_8 L_2 Z_100 D_3 
Stack 1
I_0 Z_101 D_5 N_4 Z_102 C_3 
Stack 2
D_0 E_3 I_5 H_4 G_3 E_6 
Stack 3
I_6 Z_103 L_0 Z_104 A_1 G_6 
Stack 4
N_3 K_0 E_4 I_7 F_4 
Stack 5
J_2 F_1 Z_105 K_7 F_6 
Stack 6
D_4 K_1 D_2 E_2 H_9 
Stack 7
J_8 E_5 Z_106 J_5 G_5 
Stack 8
E_0 G_0 M_2 O_1 M_6 
Stack 9
C_2 M_5 G_7 C_4 H_6 
Stack 10
O_2 K_4 I_10 K_6 I_9 
Stack 11
O_4 I_8 H_5 Z_107 I_1 
Stack 12
L_4 M_0 I_3 A_3 H_3 
Stack 13
I_4 F_5 B_3 C_5 E_1 
Stack 14
D_1 E_7 N_2 H_2 F_7 
Stack 15
K_3 J_0 M_4 Z_108 N_1 
Stack 16
Z_109 B_2 J_3 L_7 O_3 
Stack 17
G_1 B_1 J_7 F_3 F_0 
Stack 18
M_3 B_0 Z_110 L_6 J_9 
Stack 19
A_2 Z_111 N_0 G_4 F_2 
Stack 20
G_2 G_9 M_1 H_7 Z_112 
Stack 21
A_0 K_2 J_1 H_1 C_1 
Stack 22
J_6 H_0 L_1 K_5 J_4 
Stack 23
G_8 I_2 N_5 C_0 O_0 
