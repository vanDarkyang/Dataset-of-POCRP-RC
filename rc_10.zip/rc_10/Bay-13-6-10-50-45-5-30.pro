Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_5 E_3 G_1 H_4 
Stack 1
Z_100 E_0 E_4 C_2 
Stack 2
J_2 B_1 Z_101 I_0 
Stack 3
H_1 Z_102 H_3 E_2 
Stack 4
D_1 D_5 D_0 G_4 
Stack 5
I_3 F_3 F_5 A_1 
Stack 6
F_4 C_0 F_2 F_0 
Stack 7
G_2 Z_103 D_2 Z_104 
Stack 8
C_3 C_1 G_3 H_0 
Stack 9
H_2 J_1 J_0 A_2 
Stack 10
E_1 E_6 D_3 B_0 
Stack 11
D_4 F_1 G_0 
Stack 12
I_1 A_0 I_2 
