Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_0 E_2 C_7 A_4 
Stack 1
Z_100 D_0 C_0 D_2 
Stack 2
D_3 A_1 C_6 C_4 
Stack 3
B_2 C_1 B_6 D_9 
Stack 4
A_7 B_3 A_3 D_8 
Stack 5
C_9 E_3 Z_101 D_10 
Stack 6
C_5 Z_102 C_8 D_5 
Stack 7
E_7 A_0 Z_103 A_5 
Stack 8
D_4 C_10 D_6 B_4 
Stack 9
D_1 E_0 B_5 A_6 
Stack 10
E_5 D_7 E_6 B_1 
Stack 11
E_4 B_9 C_3 B_7 
Stack 12
E_1 Z_104 A_2 
Stack 13
C_2 B_8 Z_105 
