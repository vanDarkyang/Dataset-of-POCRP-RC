Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_0 E_1 G_3 J_2 Z_100 
Stack 1
H_2 D_0 Z_101 F_2 A_2 
Stack 2
D_2 C_2 B_2 F_4 F_3 
Stack 3
D_4 Z_102 A_1 F_0 B_1 
Stack 4
I_1 F_1 B_0 C_3 E_0 
Stack 5
E_3 D_3 C_0 G_1 D_1 
Stack 6
F_5 E_5 H_4 H_1 J_1 
Stack 7
I_3 C_1 H_0 D_5 I_2 
Stack 8
H_3 I_0 Z_103 B_3 J_0 
Stack 9
E_4 G_2 Z_104 G_0 E_2 
