Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
G_8 E_3 H_7 C_0 N_5 L_1 
Stack 1
A_2 F_8 E_2 C_5 M_3 F_6 
Stack 2
G_9 E_4 I_5 F_2 M_4 M_5 
Stack 3
B_3 A_1 H_3 B_1 F_0 A_0 
Stack 4
G_6 G_2 F_1 I_1 O_2 
Stack 5
L_0 O_1 J_0 H_8 C_3 
Stack 6
G_4 D_5 Z_100 D_6 E_6 
Stack 7
H_4 F_7 H_0 B_2 H_2 
Stack 8
B_5 Z_101 L_5 J_6 J_7 
Stack 9
N_2 M_1 L_3 G_3 B_0 
Stack 10
Z_102 C_1 Z_103 K_2 J_2 
Stack 11
B_4 J_3 Z_104 Z_105 Z_106 
Stack 12
F_4 Z_107 N_1 H_1 D_7 
Stack 13
E_5 Z_108 J_1 O_3 O_4 
Stack 14
M_2 G_5 K_1 D_3 Z_109 
Stack 15
M_0 Z_110 C_6 J_9 D_0 
Stack 16
I_4 H_11 J_8 F_5 G_7 
Stack 17
N_0 D_2 O_0 H_9 D_1 
Stack 18
A_3 I_3 C_2 E_7 I_0 
Stack 19
G_1 C_4 E_0 I_2 N_3 
Stack 20
N_4 H_5 K_3 G_0 Z_111 
Stack 21
K_0 L_2 F_3 K_5 H_6 
Stack 22
Z_112 J_4 J_5 E_1 L_4 
Stack 23
D_4 I_6 K_4 E_8 H_10 
