Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
B_6 C_10 E_11 E_8 
Stack 1
E_10 C_4 E_5 D_12 
Stack 2
A_6 D_13 A_4 C_12 
Stack 3
Z_100 E_12 A_3 B_3 
Stack 4
D_4 B_0 D_10 B_12 
Stack 5
Z_101 A_2 E_3 Z_102 
Stack 6
C_5 D_5 B_8 B_10 
Stack 7
C_14 E_1 A_8 D_6 
Stack 8
C_0 C_9 C_1 B_11 
Stack 9
A_9 E_2 B_5 C_7 
Stack 10
D_2 C_2 E_9 A_5 
Stack 11
D_8 Z_103 Z_104 C_15 
Stack 12
A_10 C_3 E_14 D_9 
Stack 13
A_11 D_7 B_9 A_0 
Stack 14
B_4 D_14 D_11 D_3 
Stack 15
A_1 B_1 C_11 Z_105 
Stack 16
C_8 Z_106 C_6 E_4 
Stack 17
C_13 E_6 D_0 B_2 
Stack 18
A_7 B_7 D_1 E_7 
Stack 19
Z_107 E_13 E_0 
