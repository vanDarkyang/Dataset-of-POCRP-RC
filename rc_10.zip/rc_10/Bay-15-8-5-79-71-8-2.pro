Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_8 B_1 C_11 Z_100 D_7 D_2 
Stack 1
A_10 C_5 B_8 Z_101 E_8 D_0 
Stack 2
E_3 C_7 D_1 B_5 D_5 E_7 
Stack 3
B_7 Z_102 C_4 E_0 A_1 D_10 
Stack 4
D_9 B_0 B_9 C_13 A_7 
Stack 5
Z_103 B_13 B_3 D_15 C_2 
Stack 6
C_10 D_13 Z_104 A_4 C_6 
Stack 7
D_4 B_2 B_14 A_5 E_2 
Stack 8
B_4 Z_105 B_6 E_6 B_10 
Stack 9
E_1 E_5 Z_106 B_11 A_2 
Stack 10
C_12 C_9 A_9 D_12 C_1 
Stack 11
A_6 C_3 D_11 D_6 A_11 
Stack 12
A_12 E_11 E_9 D_8 D_14 
Stack 13
A_0 Z_107 A_8 E_4 C_0 
Stack 14
A_3 E_10 D_3 E_12 B_12 
