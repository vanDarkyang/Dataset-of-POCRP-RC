Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
G_3 G_7 J_2 I_1 L_4 C_0 
Stack 1
G_5 L_3 F_5 J_0 H_1 E_4 
Stack 2
D_1 K_4 H_0 D_3 F_1 O_2 
Stack 3
G_6 G_0 F_2 K_5 O_0 L_0 
Stack 4
H_7 A_1 I_0 Z_100 B_2 
Stack 5
H_3 F_6 Z_101 Z_102 H_4 
Stack 6
E_1 Z_103 O_1 I_4 E_0 
Stack 7
K_1 E_2 L_5 K_3 N_2 
Stack 8
L_1 D_5 H_2 Z_104 B_1 
Stack 9
I_5 I_2 N_0 F_3 E_3 
Stack 10
H_8 J_4 Z_105 N_3 D_2 
Stack 11
G_2 D_4 Z_106 A_0 J_5 
Stack 12
L_2 E_5 C_1 F_4 H_5 
Stack 13
G_4 K_0 C_2 A_2 M_2 
Stack 14
B_0 M_4 J_3 I_3 N_1 
Stack 15
F_0 Z_107 D_0 Z_108 Z_109 
Stack 16
J_1 M_3 K_2 G_1 M_0 
Stack 17
I_6 I_7 H_6 C_3 M_1 
