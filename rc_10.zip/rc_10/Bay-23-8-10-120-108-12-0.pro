Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
D_0 G_6 A_6 I_8 I_1 D_3 
Stack 1
G_7 B_8 Z_100 Z_101 H_9 Z_102 
Stack 2
E_0 F_7 H_4 C_8 H_2 I_0 
Stack 3
B_6 J_4 F_3 D_10 Z_103 C_0 
Stack 4
I_9 A_7 B_2 G_4 A_0 H_5 
Stack 5
J_5 B_1 C_1 D_6 J_3 
Stack 6
H_3 B_4 J_6 D_1 G_9 
Stack 7
E_1 B_5 E_2 F_0 H_8 
Stack 8
D_4 A_5 I_5 J_1 A_4 
Stack 9
C_10 G_8 G_5 F_5 H_1 
Stack 10
G_10 Z_104 C_3 H_10 I_7 
Stack 11
D_8 Z_105 Z_106 A_2 H_11 
Stack 12
B_3 B_9 Z_107 B_7 C_2 
Stack 13
G_3 H_0 J_0 Z_108 I_2 
Stack 14
G_0 D_9 C_7 C_5 F_9 
Stack 15
I_4 Z_109 G_2 F_2 I_3 
Stack 16
F_8 A_3 C_4 E_6 E_12 
Stack 17
C_9 I_6 H_7 F_6 E_7 
Stack 18
Z_110 J_7 D_2 D_11 Z_111 
Stack 19
E_4 E_11 C_6 D_5 F_1 
Stack 20
F_10 A_1 J_2 F_4 D_7 
Stack 21
H_6 E_3 E_8 E_10 G_1 
Stack 22
E_5 A_9 E_9 B_0 A_8 
