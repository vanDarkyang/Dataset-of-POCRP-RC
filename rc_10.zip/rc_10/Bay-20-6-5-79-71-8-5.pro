Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_9 C_1 D_9 D_10 
Stack 1
Z_100 A_11 C_2 B_5 
Stack 2
B_0 A_8 C_0 C_3 
Stack 3
A_0 Z_101 E_7 D_11 
Stack 4
E_3 C_13 D_8 E_5 
Stack 5
B_9 Z_102 C_7 B_10 
Stack 6
D_5 D_14 C_5 A_4 
Stack 7
B_13 D_2 B_4 Z_103 
Stack 8
D_7 E_4 A_10 E_8 
Stack 9
B_11 D_0 C_4 E_11 
Stack 10
B_1 B_8 B_7 A_12 
Stack 11
A_14 E_2 D_3 A_3 
Stack 12
E_0 B_12 C_12 Z_104 
Stack 13
A_2 A_9 D_6 E_9 
Stack 14
B_3 B_2 C_8 C_11 
Stack 15
D_1 Z_105 A_7 C_14 
Stack 16
A_13 D_12 D_13 Z_106 
Stack 17
A_1 E_6 D_4 Z_107 
Stack 18
C_6 A_5 C_10 A_6 
Stack 19
E_1 E_10 B_6 
