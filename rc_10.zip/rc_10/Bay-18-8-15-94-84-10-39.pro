Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
L_3 B_2 L_2 G_1 H_8 G_0 
Stack 1
M_3 A_2 M_1 E_0 H_0 M_4 
Stack 2
A_0 I_6 H_1 H_7 M_0 H_4 
Stack 3
E_4 K_5 O_1 L_0 D_2 Z_100 
Stack 4
F_5 G_6 I_1 M_2 J_7 
Stack 5
A_1 I_4 K_6 C_0 C_3 
Stack 6
F_6 F_4 I_5 H_2 J_1 
Stack 7
Z_101 J_5 F_2 F_0 Z_102 
Stack 8
N_0 Z_103 C_1 C_4 J_4 
Stack 9
F_3 G_8 K_4 L_1 Z_104 
Stack 10
H_6 I_2 J_3 K_2 G_4 
Stack 11
N_1 J_2 B_0 E_1 J_0 
Stack 12
I_7 E_3 L_4 E_2 G_7 
Stack 13
C_2 J_6 G_2 O_2 H_5 
Stack 14
G_5 Z_105 I_0 K_0 F_1 
Stack 15
K_1 D_3 I_3 K_3 B_1 
Stack 16
Z_106 F_7 D_1 G_3 Z_107 
Stack 17
Z_108 O_0 H_3 D_0 Z_109 
