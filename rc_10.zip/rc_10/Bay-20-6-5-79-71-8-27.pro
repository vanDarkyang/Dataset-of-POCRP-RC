Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
Z_100 D_13 E_9 D_1 
Stack 1
B_5 A_7 C_9 Z_101 
Stack 2
C_14 B_12 D_6 E_8 
Stack 3
B_8 A_6 C_13 C_5 
Stack 4
C_6 B_10 D_5 A_14 
Stack 5
C_8 C_11 Z_102 D_9 
Stack 6
B_0 E_6 B_14 B_4 
Stack 7
C_12 B_6 A_3 D_0 
Stack 8
E_10 D_3 D_10 Z_103 
Stack 9
B_1 B_7 D_4 C_1 
Stack 10
E_5 A_10 Z_104 A_2 
Stack 11
C_7 A_1 Z_105 A_9 
Stack 12
A_13 E_4 B_9 A_4 
Stack 13
B_3 A_5 C_10 D_8 
Stack 14
E_7 A_8 E_0 D_12 
Stack 15
D_11 E_1 E_3 C_2 
Stack 16
B_13 D_7 C_0 A_0 
Stack 17
C_4 A_12 D_2 C_3 
Stack 18
A_11 B_2 Z_106 E_2 
Stack 19
Z_107 B_11 D_14 
