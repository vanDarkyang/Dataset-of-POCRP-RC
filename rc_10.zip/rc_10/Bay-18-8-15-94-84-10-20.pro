Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
K_1 I_6 K_2 E_0 B_1 E_1 
Stack 1
I_0 K_3 H_1 I_5 G_8 D_2 
Stack 2
Z_100 Z_101 H_8 L_1 H_2 C_4 
Stack 3
F_2 M_3 K_4 M_1 L_4 M_2 
Stack 4
H_0 J_4 Z_102 B_3 N_0 
Stack 5
E_2 D_3 N_1 Z_103 G_6 
Stack 6
G_0 F_4 H_4 Z_104 A_0 
Stack 7
E_4 H_6 Z_105 J_2 J_0 
Stack 8
C_2 O_1 H_3 J_5 G_5 
Stack 9
L_2 I_1 J_3 Z_106 M_0 
Stack 10
C_1 G_1 Z_107 G_3 O_2 
Stack 11
H_5 F_0 D_4 I_4 D_0 
Stack 12
D_1 F_5 F_3 Z_108 H_7 
Stack 13
I_3 C_0 G_2 J_1 N_3 
Stack 14
B_0 L_3 G_4 K_0 L_5 
Stack 15
N_2 H_9 A_1 I_7 L_0 
Stack 16
B_2 I_2 G_7 E_5 E_3 
Stack 17
F_6 O_0 Z_109 F_1 C_3 
