Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_9 D_7 Z_100 E_0 
Stack 1
A_8 C_3 A_1 Z_101 
Stack 2
D_2 C_1 E_3 B_10 
Stack 3
D_5 A_2 E_2 Z_102 
Stack 4
A_0 C_7 A_4 B_5 
Stack 5
C_0 C_2 B_6 Z_103 
Stack 6
C_9 A_9 Z_104 B_0 
Stack 7
E_5 Z_105 E_4 E_6 
Stack 8
A_6 D_3 B_2 A_7 
Stack 9
D_8 D_0 C_5 D_6 
Stack 10
B_8 D_4 C_6 D_1 
Stack 11
B_4 B_3 C_10 C_4 
Stack 12
A_5 B_7 E_1 
Stack 13
C_8 B_1 A_3 
