Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_1 A_0 B_10 A_3 
Stack 1
C_6 Z_100 C_7 A_2 
Stack 2
B_4 C_9 C_2 A_12 
Stack 3
C_1 Z_101 A_13 Z_102 
Stack 4
C_10 C_5 A_1 Z_103 
Stack 5
A_6 Z_104 C_11 B_6 
Stack 6
B_9 B_5 B_8 B_12 
Stack 7
B_2 A_7 B_0 C_4 
Stack 8
A_9 A_10 A_8 B_7 
Stack 9
C_8 B_11 A_11 C_0 
Stack 10
B_14 C_3 A_5 
Stack 11
A_4 B_3 B_13 
