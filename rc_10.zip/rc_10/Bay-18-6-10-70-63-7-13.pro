Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_1 I_0 E_1 H_3 
Stack 1
Z_100 H_5 J_3 Z_101 
Stack 2
D_2 F_0 D_1 G_5 
Stack 3
F_4 D_5 E_3 B_1 
Stack 4
E_0 H_0 G_7 F_5 
Stack 5
G_6 E_6 A_2 A_0 
Stack 6
J_1 H_6 H_4 B_0 
Stack 7
I_1 F_3 Z_102 Z_103 
Stack 8
E_2 D_7 G_3 J_2 
Stack 9
B_3 F_6 G_4 E_7 
Stack 10
E_8 D_6 B_2 G_2 
Stack 11
B_4 I_4 E_5 Z_104 
Stack 12
A_3 H_2 H_1 F_2 
Stack 13
C_3 C_0 E_4 D_3 
Stack 14
F_1 J_0 F_7 I_3 
Stack 15
G_0 A_1 C_2 G_1 
Stack 16
D_0 Z_105 I_2 
Stack 17
C_4 D_4 Z_106 
