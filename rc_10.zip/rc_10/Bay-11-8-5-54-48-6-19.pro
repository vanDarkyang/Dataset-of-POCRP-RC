Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_3 B_1 A_8 Z_100 D_4 
Stack 1
C_6 B_2 B_0 B_5 B_8 
Stack 2
Z_101 E_7 C_1 A_3 E_2 
Stack 3
D_3 D_7 C_2 Z_102 C_8 
Stack 4
A_2 A_0 E_0 C_3 A_6 
Stack 5
Z_103 A_5 B_7 B_4 E_8 
Stack 6
D_2 C_4 Z_104 E_1 A_7 
Stack 7
C_5 A_1 E_6 C_7 B_9 
Stack 8
B_3 D_8 B_6 D_9 D_6 
Stack 9
C_0 E_5 Z_105 D_5 D_0 
Stack 10
A_4 D_1 D_10 E_4 
