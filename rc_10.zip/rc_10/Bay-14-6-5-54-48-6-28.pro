Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_9 A_0 Z_100 E_3 
Stack 1
Z_101 B_7 E_6 E_5 
Stack 2
B_6 C_2 B_9 A_7 
Stack 3
C_7 D_4 D_5 C_6 
Stack 4
C_3 D_6 E_7 E_8 
Stack 5
B_4 E_1 E_2 B_5 
Stack 6
A_5 A_1 D_3 A_6 
Stack 7
C_8 C_4 Z_102 D_2 
Stack 8
Z_103 B_3 Z_104 Z_105 
Stack 9
C_9 E_9 C_0 B_1 
Stack 10
C_1 B_8 B_0 E_4 
Stack 11
B_2 D_0 E_0 A_3 
Stack 12
A_2 D_8 C_5 
Stack 13
D_1 A_4 D_7 
