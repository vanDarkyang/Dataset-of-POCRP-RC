Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
Z_100 Z_101 D_5 D_1 
Stack 1
C_0 G_4 H_1 B_0 
Stack 2
Z_102 J_2 A_1 H_3 
Stack 3
E_0 E_4 Z_103 F_0 
Stack 4
G_5 J_0 C_1 D_4 
Stack 5
G_1 Z_104 A_2 H_4 
Stack 6
G_2 C_4 D_0 E_5 
Stack 7
F_3 C_2 D_3 I_0 
Stack 8
E_2 F_2 G_3 I_1 
Stack 9
F_1 E_1 A_0 F_5 
Stack 10
H_0 F_4 H_2 I_2 
Stack 11
J_1 F_6 D_2 
Stack 12
G_0 E_3 C_3 
