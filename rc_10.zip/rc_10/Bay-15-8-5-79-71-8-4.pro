Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
B_8 A_1 C_2 E_3 E_8 Z_100 
Stack 1
E_10 C_9 C_5 B_10 D_9 E_4 
Stack 2
A_8 Z_101 C_3 A_10 Z_102 B_3 
Stack 3
A_7 A_9 D_5 C_1 B_4 E_7 
Stack 4
D_3 B_2 D_12 B_7 B_13 
Stack 5
A_5 C_11 B_1 E_9 A_2 
Stack 6
C_6 C_4 D_11 B_5 B_11 
Stack 7
C_13 D_10 E_6 E_14 D_4 
Stack 8
C_0 E_12 B_9 Z_103 B_12 
Stack 9
A_11 B_0 E_13 D_8 C_8 
Stack 10
D_1 A_3 E_11 C_12 Z_104 
Stack 11
D_6 Z_105 E_5 C_7 C_14 
Stack 12
A_12 E_1 A_6 Z_106 Z_107 
Stack 13
A_13 C_10 A_4 D_0 A_0 
Stack 14
B_6 E_2 D_7 E_0 D_2 
