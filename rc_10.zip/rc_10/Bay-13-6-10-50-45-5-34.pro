Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
I_2 G_5 B_0 D_4 
Stack 1
C_2 Z_100 J_2 E_0 
Stack 2
E_6 C_0 C_4 G_4 
Stack 3
B_1 A_0 C_3 Z_101 
Stack 4
F_0 H_2 H_3 D_3 
Stack 5
E_1 D_1 F_2 J_1 
Stack 6
Z_102 B_3 H_1 D_5 
Stack 7
Z_103 E_5 G_0 G_2 
Stack 8
F_1 H_4 H_0 J_0 
Stack 9
Z_104 G_1 C_1 D_2 
Stack 10
E_4 G_3 B_2 D_0 
Stack 11
I_0 F_3 I_1 
Stack 12
E_2 A_1 E_3 
