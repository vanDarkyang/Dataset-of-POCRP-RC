Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_8 Z_100 B_8 A_0 
Stack 1
B_4 A_4 B_2 C_0 
Stack 2
C_12 B_5 C_7 B_7 
Stack 3
A_1 A_2 B_10 C_10 
Stack 4
Z_101 B_3 A_7 C_2 
Stack 5
Z_102 Z_103 A_10 B_9 
Stack 6
C_4 A_12 B_0 C_11 
Stack 7
C_6 B_12 B_11 C_3 
Stack 8
C_1 C_8 Z_104 A_6 
Stack 9
B_6 B_14 B_13 C_5 
Stack 10
C_9 A_5 A_11 
Stack 11
A_9 B_1 A_3 
