Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_3 E_10 E_9 A_0 E_6 A_13 
Stack 1
B_4 A_10 D_5 B_5 C_2 E_7 
Stack 2
A_4 C_1 C_7 D_11 C_8 A_11 
Stack 3
C_9 C_15 D_7 A_6 B_0 D_8 
Stack 4
B_1 B_3 A_5 A_7 C_11 
Stack 5
A_9 E_1 C_12 D_12 E_11 
Stack 6
Z_100 Z_101 C_14 D_6 A_12 
Stack 7
E_3 B_8 D_4 D_13 Z_102 
Stack 8
B_2 C_0 B_7 Z_103 B_6 
Stack 9
D_9 A_14 D_14 E_0 C_6 
Stack 10
A_3 D_10 C_16 A_8 E_4 
Stack 11
E_5 C_10 A_1 D_1 C_13 
Stack 12
D_2 D_3 A_2 E_2 Z_104 
Stack 13
Z_105 B_9 C_4 B_10 D_0 
Stack 14
Z_106 C_5 B_11 E_8 Z_107 
