Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_1 B_0 H_2 J_1 Z_100 
Stack 1
B_2 I_1 Z_101 Z_102 F_4 
Stack 2
G_3 D_0 E_2 E_1 G_4 
Stack 3
D_1 F_0 I_3 C_3 H_0 
Stack 4
Z_103 J_2 F_1 G_0 E_4 
Stack 5
C_4 I_0 D_2 A_0 D_3 
Stack 6
G_1 C_0 E_5 E_6 G_2 
Stack 7
H_3 B_3 Z_104 H_1 B_1 
Stack 8
C_2 F_3 I_2 A_2 F_2 
Stack 9
G_5 E_3 A_1 J_0 E_0 
