Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
G_2 B_2 F_2 D_5 
Stack 1
I_1 Z_100 D_4 C_0 
Stack 2
D_1 J_1 C_2 E_2 
Stack 3
I_2 H_2 J_0 G_0 
Stack 4
B_0 Z_101 J_2 A_0 
Stack 5
A_1 E_1 E_3 H_1 
Stack 6
D_2 D_0 F_1 D_3 
Stack 7
I_3 G_3 E_0 F_0 
Stack 8
H_3 Z_102 E_6 C_1 
Stack 9
G_4 E_4 C_3 Z_103 
Stack 10
B_1 F_6 G_1 F_5 
Stack 11
E_5 Z_104 H_0 
Stack 12
I_0 F_3 F_4 
