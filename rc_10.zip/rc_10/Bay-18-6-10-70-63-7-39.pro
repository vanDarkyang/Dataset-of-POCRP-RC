Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
F_6 D_1 Z_100 Z_101 
Stack 1
A_1 D_5 E_1 D_7 
Stack 2
B_1 D_3 C_6 C_3 
Stack 3
D_6 H_0 A_0 E_0 
Stack 4
E_2 G_2 J_0 I_3 
Stack 5
D_0 F_0 H_5 J_4 
Stack 6
C_0 E_3 F_4 B_2 
Stack 7
G_7 J_1 I_1 C_4 
Stack 8
I_4 Z_102 J_2 I_2 
Stack 9
C_1 G_3 G_5 C_5 
Stack 10
F_3 H_4 F_1 E_6 
Stack 11
H_1 B_3 F_5 G_0 
Stack 12
A_3 A_2 G_1 Z_103 
Stack 13
H_6 H_2 H_3 J_3 
Stack 14
D_4 Z_104 E_5 B_0 
Stack 15
G_6 C_2 Z_105 Z_106 
Stack 16
G_4 E_4 B_4 
Stack 17
I_0 D_2 F_2 
