Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
E_7 I_0 F_2 J_5 G_7 G_8 
Stack 1
H_1 D_11 C_0 B_6 H_4 B_9 
Stack 2
H_9 A_9 C_1 C_2 I_1 F_9 
Stack 3
J_8 A_1 F_6 D_2 I_4 C_9 
Stack 4
C_6 B_0 E_8 E_5 E_10 A_4 
Stack 5
B_8 E_0 D_7 Z_100 F_10 
Stack 6
A_0 I_8 Z_101 C_7 A_6 
Stack 7
Z_102 Z_103 C_3 E_9 I_5 
Stack 8
J_1 G_3 F_4 F_1 H_2 
Stack 9
H_10 B_1 A_8 C_8 D_8 
Stack 10
I_7 Z_104 I_6 B_5 F_11 
Stack 11
B_7 D_10 G_5 H_5 Z_105 
Stack 12
I_9 G_4 Z_106 A_5 C_4 
Stack 13
I_3 J_7 Z_107 G_6 J_3 
Stack 14
G_0 D_6 D_5 J_9 G_1 
Stack 15
Z_108 J_0 D_4 E_3 E_6 
Stack 16
F_12 H_3 A_2 H_0 C_5 
Stack 17
J_2 B_2 E_2 D_1 G_2 
Stack 18
A_3 H_7 H_6 F_0 D_3 
Stack 19
F_3 J_6 G_10 D_0 Z_109 
Stack 20
I_2 B_3 J_4 Z_110 B_4 
Stack 21
F_7 Z_111 G_9 D_9 F_5 
Stack 22
E_4 E_1 A_7 H_8 F_8 
