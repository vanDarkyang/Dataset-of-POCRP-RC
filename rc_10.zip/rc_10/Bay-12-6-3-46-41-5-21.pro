Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_12 A_2 Z_100 B_3 
Stack 1
C_9 C_13 A_9 C_4 
Stack 2
C_10 B_0 C_3 C_5 
Stack 3
A_3 A_7 C_7 Z_101 
Stack 4
B_7 A_0 C_0 A_1 
Stack 5
A_6 C_12 A_4 Z_102 
Stack 6
B_4 C_11 B_1 A_10 
Stack 7
Z_103 Z_104 C_2 B_2 
Stack 8
C_6 C_1 B_5 B_12 
Stack 9
B_10 B_13 C_8 A_8 
Stack 10
A_11 B_9 A_5 
Stack 11
B_8 B_11 B_6 
