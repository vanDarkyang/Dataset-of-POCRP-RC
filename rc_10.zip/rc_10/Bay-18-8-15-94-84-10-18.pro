Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
M_0 Z_100 J_1 O_2 L_4 B_3 
Stack 1
C_1 H_5 G_8 Z_101 K_5 I_2 
Stack 2
H_3 D_2 L_5 E_5 Z_102 N_2 
Stack 3
C_0 N_0 K_0 G_0 L_0 E_1 
Stack 4
G_2 C_2 D_1 B_0 M_3 
Stack 5
H_4 Z_103 J_4 A_1 F_6 
Stack 6
D_0 M_2 I_3 B_2 D_5 
Stack 7
Z_104 D_4 Z_105 N_1 L_1 
Stack 8
Z_106 J_5 K_4 F_5 E_0 
Stack 9
C_4 I_4 H_8 E_4 G_7 
Stack 10
C_3 J_2 J_0 K_3 I_5 
Stack 11
E_3 Z_107 I_0 G_3 F_0 
Stack 12
F_3 Z_108 F_1 L_3 H_0 
Stack 13
I_1 O_1 Z_109 E_6 F_4 
Stack 14
D_3 H_1 H_7 G_6 A_0 
Stack 15
K_1 E_2 G_4 L_2 H_6 
Stack 16
B_1 G_5 H_2 K_2 O_0 
Stack 17
F_2 M_4 G_1 J_3 M_1 
