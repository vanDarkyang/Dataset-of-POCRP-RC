Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_6 C_4 A_10 A_7 
Stack 1
B_5 B_6 C_7 C_5 
Stack 2
A_5 C_8 A_4 C_9 
Stack 3
C_2 C_10 C_11 B_0 
Stack 4
B_10 A_1 B_4 B_1 
Stack 5
C_1 B_14 A_12 B_9 
Stack 6
Z_100 Z_101 Z_102 B_12 
Stack 7
A_8 B_11 B_3 Z_103 
Stack 8
B_2 A_3 A_6 A_0 
Stack 9
B_13 A_2 A_13 A_9 
Stack 10
B_8 A_11 C_0 
Stack 11
C_3 Z_104 B_7 
