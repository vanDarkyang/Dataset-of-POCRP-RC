Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
H_4 J_1 M_2 A_0 H_2 N_3 
Stack 1
A_2 Z_100 G_1 B_0 G_7 O_2 
Stack 2
K_1 H_6 H_1 H_0 D_1 D_0 
Stack 3
F_3 K_0 Z_101 F_0 D_3 J_5 
Stack 4
H_3 L_0 J_2 Z_102 I_6 
Stack 5
H_7 O_1 G_2 G_3 I_5 
Stack 6
Z_103 I_3 A_1 B_2 M_4 
Stack 7
K_3 Z_104 Z_105 G_6 C_1 
Stack 8
E_5 F_2 E_6 F_6 G_5 
Stack 9
O_0 N_0 I_2 Z_106 E_2 
Stack 10
M_0 D_2 H_5 J_0 E_0 
Stack 11
C_0 J_4 M_1 L_2 F_5 
Stack 12
K_2 B_1 K_4 Z_107 L_4 
Stack 13
J_3 G_4 N_1 M_3 F_4 
Stack 14
L_1 N_2 Z_108 C_2 F_1 
Stack 15
Z_109 C_3 I_1 I_7 D_4 
Stack 16
E_4 L_5 B_3 C_4 I_0 
Stack 17
E_1 G_0 I_4 L_3 E_3 
