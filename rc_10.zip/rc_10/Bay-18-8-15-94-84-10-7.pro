Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 Z_101 I_0 E_3 Z_102 H_6 
Stack 1
G_0 I_1 H_0 N_2 F_6 N_3 
Stack 2
B_0 Z_103 K_0 I_4 O_2 G_1 
Stack 3
H_2 J_1 H_5 J_5 L_0 D_2 
Stack 4
Z_104 C_4 C_0 Z_105 F_2 
Stack 5
C_2 K_4 D_4 E_1 I_7 
Stack 6
N_0 G_4 C_3 E_0 J_3 
Stack 7
E_4 J_2 K_2 M_3 H_1 
Stack 8
J_4 O_1 E_5 A_2 I_3 
Stack 9
K_5 G_7 L_3 G_5 G_8 
Stack 10
B_2 O_0 K_6 F_3 Z_106 
Stack 11
M_4 E_2 M_0 D_3 Z_107 
Stack 12
L_4 L_1 D_1 C_1 N_1 
Stack 13
K_3 D_0 H_4 M_2 L_2 
Stack 14
I_6 M_1 G_3 B_1 K_1 
Stack 15
A_1 F_4 I_5 G_6 A_0 
Stack 16
Z_108 F_1 H_3 F_0 I_2 
Stack 17
J_0 F_5 G_2 J_6 Z_109 
