Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
B_3 H_0 F_6 G_8 A_5 H_8 
Stack 1
C_6 B_0 C_5 B_10 B_4 A_8 
Stack 2
J_5 Z_100 I_0 Z_101 I_5 C_9 
Stack 3
I_3 Z_102 Z_103 H_9 D_10 A_6 
Stack 4
C_0 D_8 E_5 F_11 G_1 H_1 
Stack 5
B_1 F_2 J_6 E_7 H_5 
Stack 6
D_3 D_6 E_4 C_8 I_4 
Stack 7
A_1 B_8 G_6 J_1 H_4 
Stack 8
E_2 A_7 I_8 G_9 D_12 
Stack 9
G_10 A_4 H_7 D_9 I_6 
Stack 10
Z_104 F_12 F_9 G_2 H_3 
Stack 11
I_1 H_2 H_6 Z_105 Z_106 
Stack 12
D_0 B_9 F_10 F_4 B_2 
Stack 13
E_9 J_4 J_3 A_2 Z_107 
Stack 14
G_3 E_8 F_8 B_7 G_5 
Stack 15
Z_108 J_7 E_10 C_3 D_4 
Stack 16
A_9 F_7 G_4 C_2 E_1 
Stack 17
D_11 A_0 G_0 D_5 I_7 
Stack 18
Z_109 F_0 F_1 D_7 C_7 
Stack 19
E_6 G_7 C_1 Z_110 J_0 
Stack 20
C_10 E_3 E_0 I_9 D_1 
Stack 21
I_2 Z_111 F_3 F_5 B_6 
Stack 22
J_2 C_4 B_5 A_3 D_2 
