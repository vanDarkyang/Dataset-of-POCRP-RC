Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_9 B_4 D_4 B_6 B_10 
Stack 1
A_8 A_5 D_0 E_1 C_5 
Stack 2
D_3 C_7 D_5 E_4 B_5 
Stack 3
D_6 D_8 B_3 B_2 D_9 
Stack 4
A_0 C_2 B_7 C_4 B_0 
Stack 5
C_0 Z_100 B_1 C_6 E_7 
Stack 6
C_8 A_2 Z_101 C_9 A_7 
Stack 7
E_6 Z_102 A_1 E_2 D_7 
Stack 8
A_6 C_1 Z_103 A_3 D_1 
Stack 9
Z_104 Z_105 E_3 E_0 C_3 
Stack 10
B_8 D_2 A_4 E_5 
