Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_7 A_9 D_6 Z_100 
Stack 1
E_8 E_7 D_14 B_12 
Stack 2
B_0 E_10 B_13 E_11 
Stack 3
E_3 D_3 A_6 A_8 
Stack 4
C_2 D_10 D_9 Z_101 
Stack 5
Z_102 C_11 C_12 B_2 
Stack 6
B_14 B_11 B_4 C_6 
Stack 7
A_3 A_10 A_0 B_9 
Stack 8
Z_103 A_2 D_11 E_5 
Stack 9
C_4 C_3 B_3 C_5 
Stack 10
A_11 B_6 D_0 E_12 
Stack 11
Z_104 D_8 C_14 E_1 
Stack 12
D_4 Z_105 D_2 C_7 
Stack 13
C_9 A_1 E_6 E_2 
Stack 14
D_1 Z_106 D_13 B_8 
Stack 15
D_7 E_0 B_10 C_13 
Stack 16
A_5 Z_107 B_1 C_8 
Stack 17
D_5 E_4 A_12 D_12 
Stack 18
C_10 C_0 C_1 B_7 
Stack 19
B_5 A_4 E_9 
