Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
Z_100 C_6 J_0 I_3 B_2 
Stack 1
D_4 Z_101 G_4 A_4 E_6 
Stack 2
F_6 C_2 C_3 B_1 G_3 
Stack 3
J_1 H_1 E_0 I_4 C_0 
Stack 4
F_0 D_2 H_0 G_5 C_4 
Stack 5
F_5 E_1 B_3 D_1 E_8 
Stack 6
D_3 F_3 B_4 A_2 E_2 
Stack 7
Z_102 H_3 H_4 D_5 C_5 
Stack 8
Z_103 D_6 I_2 Z_104 J_3 
Stack 9
E_4 J_2 H_5 H_6 I_5 
Stack 10
E_3 H_2 Z_105 F_2 A_0 
Stack 11
G_2 D_0 B_0 G_0 E_5 
Stack 12
A_3 E_7 C_1 F_4 I_0 
Stack 13
I_1 F_1 G_1 A_1 Z_106 
