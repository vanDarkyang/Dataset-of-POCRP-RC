Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
D_2 D_5 E_3 C_1 Z_100 A_0 
Stack 1
E_2 F_4 M_3 M_1 N_1 Z_101 
Stack 2
J_3 K_0 J_4 F_2 I_1 H_2 
Stack 3
E_6 H_9 K_1 Z_102 J_0 G_7 
Stack 4
G_3 H_6 G_5 E_5 G_2 
Stack 5
F_3 I_3 O_2 C_4 D_1 
Stack 6
H_4 L_2 I_7 D_4 H_0 
Stack 7
I_5 D_0 K_5 K_2 G_0 
Stack 8
H_3 I_4 G_4 C_3 F_6 
Stack 9
F_0 Z_103 H_7 C_0 F_1 
Stack 10
Z_104 E_4 B_3 O_0 L_3 
Stack 11
L_4 H_5 J_5 L_1 J_2 
Stack 12
Z_105 H_8 E_1 Z_106 H_1 
Stack 13
J_1 O_1 N_0 B_2 Z_107 
Stack 14
K_3 G_1 D_3 G_6 M_0 
Stack 15
I_2 B_0 I_6 K_4 I_0 
Stack 16
J_6 A_1 C_2 L_0 M_2 
Stack 17
E_0 Z_108 Z_109 B_1 F_5 
