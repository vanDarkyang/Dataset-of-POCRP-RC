Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
H_3 Z_100 Z_101 F_5 E_0 G_7 
Stack 1
G_4 L_1 H_5 A_1 J_4 L_3 
Stack 2
J_2 B_3 A_0 A_2 H_7 M_1 
Stack 3
C_0 D_0 L_4 G_3 F_0 L_2 
Stack 4
N_1 I_1 D_5 K_6 C_2 
Stack 5
E_4 I_4 Z_102 J_0 L_0 
Stack 6
I_2 J_6 Z_103 I_5 E_5 
Stack 7
D_3 N_3 G_2 G_0 Z_104 
Stack 8
J_3 K_3 B_2 J_5 G_8 
Stack 9
Z_105 Z_106 H_4 M_0 Z_107 
Stack 10
K_1 N_0 M_2 I_0 E_1 
Stack 11
D_2 I_3 D_1 C_1 K_0 
Stack 12
O_1 Z_108 H_8 K_5 N_2 
Stack 13
M_3 O_0 F_1 E_3 E_2 
Stack 14
F_3 K_4 L_5 K_2 G_5 
Stack 15
D_4 F_2 H_1 J_1 F_4 
Stack 16
B_1 C_3 I_6 H_0 H_6 
Stack 17
Z_109 B_0 G_1 H_2 G_6 
