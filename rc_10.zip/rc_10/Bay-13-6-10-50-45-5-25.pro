Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_3 F_5 E_5 C_1 
Stack 1
I_0 C_4 G_3 D_0 
Stack 2
G_0 F_4 B_2 E_3 
Stack 3
B_3 E_4 H_1 C_0 
Stack 4
C_2 Z_100 G_2 F_3 
Stack 5
J_1 J_2 F_0 D_1 
Stack 6
I_1 G_1 H_3 Z_101 
Stack 7
Z_102 E_0 Z_103 E_1 
Stack 8
I_3 G_4 H_2 B_1 
Stack 9
Z_104 D_2 A_0 B_0 
Stack 10
I_2 A_1 F_2 J_0 
Stack 11
D_3 E_2 D_4 
Stack 12
H_0 A_2 F_1 
