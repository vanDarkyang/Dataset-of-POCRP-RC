Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
H_3 J_6 H_7 E_0 
Stack 1
G_4 Z_100 F_2 J_4 
Stack 2
J_2 K_3 L_5 H_6 
Stack 3
C_0 M_0 Z_101 F_1 
Stack 4
Z_102 N_0 Z_103 Z_104 
Stack 5
E_5 I_3 G_1 L_0 
Stack 6
I_2 I_5 F_7 E_6 
Stack 7
D_2 O_0 A_1 O_2 
Stack 8
J_3 K_4 Z_105 G_8 
Stack 9
F_3 F_4 G_3 E_3 
Stack 10
K_1 C_2 K_6 E_1 
Stack 11
Z_106 B_0 J_0 K_0 
Stack 12
O_1 F_0 I_6 N_1 
Stack 13
M_4 Z_107 G_0 E_2 
Stack 14
F_5 A_0 J_5 G_5 
Stack 15
D_3 L_4 M_1 F_6 
Stack 16
Z_108 D_4 I_0 H_5 
Stack 17
H_0 Z_109 C_1 G_6 
Stack 18
C_3 I_7 K_5 G_7 
Stack 19
L_1 G_2 E_4 L_3 
Stack 20
B_2 B_1 K_2 M_2 
Stack 21
D_0 H_4 J_1 L_2 
Stack 22
I_1 M_3 H_1 
Stack 23
I_4 D_1 H_2 
