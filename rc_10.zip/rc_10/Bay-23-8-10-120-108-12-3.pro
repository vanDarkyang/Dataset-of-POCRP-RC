Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
Z_100 H_9 J_1 J_6 D_10 I_7 
Stack 1
A_6 D_11 Z_101 J_0 D_1 A_8 
Stack 2
C_7 C_0 F_11 F_2 I_8 B_6 
Stack 3
A_5 G_0 A_3 D_7 E_0 J_5 
Stack 4
E_3 E_1 E_6 D_6 H_4 Z_102 
Stack 5
F_10 F_12 A_2 E_5 Z_103 
Stack 6
G_8 H_2 F_8 E_11 D_9 
Stack 7
E_12 B_5 F_1 F_7 D_2 
Stack 8
Z_104 H_0 Z_105 C_6 I_6 
Stack 9
H_8 F_3 F_9 J_3 B_1 
Stack 10
D_8 C_4 I_5 A_0 B_2 
Stack 11
B_4 C_3 A_1 F_5 E_9 
Stack 12
B_9 F_0 G_11 B_8 J_2 
Stack 13
D_3 G_4 F_4 G_9 D_0 
Stack 14
F_6 G_3 A_7 C_8 C_1 
Stack 15
D_5 B_0 C_2 C_9 Z_106 
Stack 16
G_2 G_10 Z_107 H_6 Z_108 
Stack 17
E_13 G_1 G_7 Z_109 E_7 
Stack 18
I_9 I_0 H_7 E_8 F_13 
Stack 19
D_4 E_2 E_4 I_4 H_5 
Stack 20
H_3 B_3 B_7 I_3 I_2 
Stack 21
J_4 Z_110 I_1 A_4 H_1 
Stack 22
Z_111 G_5 E_10 G_6 C_5 
