Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_3 B_0 D_3 Z_100 
Stack 1
G_3 H_3 F_5 H_4 
Stack 2
E_6 F_1 I_3 H_2 
Stack 3
H_0 C_2 E_3 H_6 
Stack 4
E_0 J_3 Z_101 B_4 
Stack 5
C_5 J_1 D_1 B_5 
Stack 6
C_0 G_1 Z_102 J_2 
Stack 7
B_2 E_8 H_5 C_4 
Stack 8
H_1 Z_103 Z_104 G_0 
Stack 9
Z_105 I_1 E_2 F_8 
Stack 10
E_5 A_2 Z_106 E_4 
Stack 11
F_7 G_4 B_1 J_0 
Stack 12
C_1 C_6 I_2 G_2 
Stack 13
D_4 G_6 F_2 E_1 
Stack 14
F_4 E_7 G_5 A_3 
Stack 15
A_0 A_1 I_0 F_0 
Stack 16
J_4 D_2 F_6 
Stack 17
F_3 D_0 B_3 
