Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
D_9 Z_100 C_10 A_9 E_10 E_11 
Stack 1
D_5 D_0 B_2 D_3 Z_101 C_7 
Stack 2
C_9 D_6 D_4 B_11 E_4 B_6 
Stack 3
A_0 B_3 B_10 C_1 C_5 D_7 
Stack 4
C_14 B_9 B_4 C_8 B_8 
Stack 5
A_6 E_3 D_13 B_5 Z_102 
Stack 6
E_7 D_14 A_13 E_6 E_8 
Stack 7
C_12 Z_103 B_7 A_12 B_0 
Stack 8
C_11 A_1 Z_104 A_10 C_15 
Stack 9
Z_105 E_5 D_8 Z_106 E_1 
Stack 10
A_4 D_11 C_2 E_0 A_2 
Stack 11
A_7 D_1 E_9 C_3 E_2 
Stack 12
C_0 A_11 B_12 C_4 B_1 
Stack 13
C_16 C_13 C_6 D_12 A_3 
Stack 14
D_10 A_8 A_5 Z_107 D_2 
