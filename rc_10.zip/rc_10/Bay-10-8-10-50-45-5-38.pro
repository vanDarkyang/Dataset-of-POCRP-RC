Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
F_3 D_4 E_4 I_3 I_0 
Stack 1
G_3 B_0 D_3 A_1 F_4 
Stack 2
F_2 C_0 B_3 E_5 C_4 
Stack 3
B_2 A_0 I_2 E_0 F_5 
Stack 4
D_1 E_3 F_1 E_2 G_2 
Stack 5
G_1 H_1 Z_100 F_6 I_1 
Stack 6
G_4 C_3 Z_101 E_6 H_0 
Stack 7
D_0 F_0 J_1 Z_102 J_0 
Stack 8
G_0 B_1 C_1 Z_103 E_1 
Stack 9
H_3 C_2 Z_104 H_2 D_2 
