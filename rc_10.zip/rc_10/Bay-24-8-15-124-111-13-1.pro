Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
J_8 I_2 Z_100 E_7 F_2 Z_101 
Stack 1
F_5 K_0 I_1 Z_102 N_2 E_5 
Stack 2
H_1 N_0 Z_103 G_9 I_5 D_5 
Stack 3
A_0 D_3 E_3 D_1 H_0 C_3 
Stack 4
B_3 O_0 C_1 G_8 J_5 
Stack 5
F_8 J_2 H_4 D_6 Z_104 
Stack 6
F_4 Z_105 G_7 F_9 F_1 
Stack 7
E_0 Z_106 H_6 A_1 N_3 
Stack 8
B_4 H_3 I_4 J_0 A_4 
Stack 9
Z_107 L_2 E_6 G_4 I_3 
Stack 10
H_10 F_3 H_5 F_6 K_3 
Stack 11
A_2 N_4 G_5 C_4 G_2 
Stack 12
K_4 L_4 I_6 E_4 D_0 
Stack 13
J_9 Z_108 K_6 M_4 K_2 
Stack 14
D_4 Z_109 M_2 O_1 K_1 
Stack 15
Z_110 C_0 H_7 Z_111 M_6 
Stack 16
D_2 H_2 J_6 E_1 B_0 
Stack 17
G_3 F_7 J_7 I_7 L_1 
Stack 18
G_6 F_0 M_5 B_2 H_8 
Stack 19
E_2 O_2 N_1 H_9 C_5 
Stack 20
M_3 M_1 M_0 G_1 I_0 
Stack 21
L_0 L_3 K_5 N_5 Z_112 
Stack 22
J_3 B_1 C_2 J_4 O_3 
Stack 23
L_5 A_3 L_6 J_1 G_0 
