Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
J_0 M_0 K_4 Z_100 
Stack 1
K_3 H_7 K_2 N_2 
Stack 2
H_2 K_1 G_4 B_1 
Stack 3
Z_101 H_4 E_0 F_1 
Stack 4
G_1 L_3 F_2 I_3 
Stack 5
Z_102 E_3 G_0 L_1 
Stack 6
E_1 M_4 N_3 Z_103 
Stack 7
D_0 Z_104 L_2 G_3 
Stack 8
Z_105 F_0 H_1 Z_106 
Stack 9
H_6 A_1 J_2 F_6 
Stack 10
H_9 N_1 I_2 N_0 
Stack 11
B_3 K_0 I_7 M_1 
Stack 12
H_0 I_4 J_1 C_0 
Stack 13
F_3 H_5 J_4 G_5 
Stack 14
Z_107 D_1 M_3 I_8 
Stack 15
E_4 A_2 F_5 G_6 
Stack 16
L_0 J_5 C_1 J_6 
Stack 17
E_2 L_5 I_5 G_2 
Stack 18
Z_108 K_5 C_3 O_0 
Stack 19
I_1 B_2 D_2 I_0 
Stack 20
C_2 O_2 M_2 K_6 
Stack 21
I_6 J_3 H_3 L_4 
Stack 22
F_4 B_0 O_1 
Stack 23
H_8 A_0 Z_109 
