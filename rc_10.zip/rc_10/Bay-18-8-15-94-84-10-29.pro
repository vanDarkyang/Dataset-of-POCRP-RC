Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 D_0 J_2 H_6 Z_101 G_5 
Stack 1
N_3 F_6 K_6 Z_102 J_1 H_1 
Stack 2
F_7 E_4 H_2 I_4 D_3 K_0 
Stack 3
B_3 E_3 A_0 Z_103 L_1 K_1 
Stack 4
C_2 M_2 K_4 H_0 N_0 
Stack 5
Z_104 D_1 J_0 I_7 N_2 
Stack 6
E_2 I_1 F_3 K_3 F_0 
Stack 7
G_3 K_5 I_3 A_1 B_1 
Stack 8
G_1 H_7 O_1 I_0 N_1 
Stack 9
G_7 C_3 K_2 F_5 B_0 
Stack 10
I_5 C_0 E_1 C_1 I_2 
Stack 11
H_8 G_0 I_8 J_3 D_2 
Stack 12
L_3 L_0 L_2 F_4 M_0 
Stack 13
Z_105 Z_106 E_0 H_5 E_6 
Stack 14
I_6 E_5 H_4 Z_107 J_5 
Stack 15
G_2 F_1 H_3 G_4 B_2 
Stack 16
F_2 J_6 Z_108 J_4 H_9 
Stack 17
M_1 Z_109 A_2 O_0 G_6 
