Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
Z_100 B_2 A_0 H_0 G_5 
Stack 1
Z_101 A_2 E_2 F_4 F_0 
Stack 2
E_3 D_0 F_8 J_0 H_1 
Stack 3
D_2 C_3 Z_102 G_2 B_1 
Stack 4
Z_103 I_3 Z_104 A_1 E_6 
Stack 5
Z_105 A_3 D_5 F_1 G_1 
Stack 6
D_4 I_4 J_2 E_1 G_6 
Stack 7
F_7 D_7 E_5 G_0 G_3 
Stack 8
F_2 H_5 J_1 C_4 C_0 
Stack 9
E_0 C_1 B_3 B_4 D_1 
Stack 10
F_6 F_3 I_2 C_5 G_4 
Stack 11
Z_106 F_5 I_0 H_2 I_1 
Stack 12
B_0 D_3 E_4 J_3 D_6 
Stack 13
C_2 H_3 H_4 J_4 E_7 
