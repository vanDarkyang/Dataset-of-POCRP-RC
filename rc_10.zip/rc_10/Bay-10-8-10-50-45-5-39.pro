Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_0 B_3 F_4 C_2 A_1 
Stack 1
B_1 C_1 H_1 G_2 Z_100 
Stack 2
B_2 F_3 G_3 I_3 J_1 
Stack 3
Z_101 F_1 D_0 D_4 A_0 
Stack 4
D_2 G_4 Z_102 D_1 E_4 
Stack 5
G_0 J_0 H_4 H_2 I_1 
Stack 6
J_2 B_0 F_0 C_0 E_1 
Stack 7
H_0 H_3 F_2 G_5 Z_103 
Stack 8
E_3 E_2 C_3 D_5 G_1 
Stack 9
C_4 I_0 Z_104 I_2 D_3 
