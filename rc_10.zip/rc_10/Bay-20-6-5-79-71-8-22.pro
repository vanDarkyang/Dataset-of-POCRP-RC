Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
E_0 D_12 C_15 E_11 
Stack 1
B_14 A_7 B_11 B_5 
Stack 2
D_3 B_7 D_8 C_1 
Stack 3
Z_100 E_3 A_8 C_6 
Stack 4
E_6 C_9 C_5 Z_101 
Stack 5
A_11 C_12 Z_102 D_10 
Stack 6
A_0 D_9 A_3 A_4 
Stack 7
C_13 C_11 D_2 Z_103 
Stack 8
B_2 D_4 A_10 E_9 
Stack 9
D_7 E_5 A_5 A_9 
Stack 10
E_4 Z_104 B_3 D_6 
Stack 11
C_8 D_0 A_1 Z_105 
Stack 12
D_5 C_10 B_8 D_1 
Stack 13
B_1 C_2 E_8 C_7 
Stack 14
A_13 B_12 D_11 B_4 
Stack 15
E_10 C_16 C_0 E_1 
Stack 16
A_2 E_7 Z_106 E_2 
Stack 17
C_14 B_10 Z_107 B_6 
Stack 18
B_9 B_13 A_6 C_3 
Stack 19
A_12 B_0 C_4 
