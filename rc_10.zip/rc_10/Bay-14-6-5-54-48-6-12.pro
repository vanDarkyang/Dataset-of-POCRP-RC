Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_10 B_2 A_5 D_5 
Stack 1
B_1 Z_100 D_4 A_6 
Stack 2
E_5 A_0 A_2 E_4 
Stack 3
C_11 C_3 C_6 B_7 
Stack 4
D_3 E_3 E_7 D_2 
Stack 5
A_8 C_9 E_0 Z_101 
Stack 6
D_1 E_6 B_0 A_7 
Stack 7
E_1 D_0 B_3 Z_102 
Stack 8
A_9 D_9 C_2 B_6 
Stack 9
Z_103 C_7 C_8 C_4 
Stack 10
A_1 C_5 D_6 A_4 
Stack 11
Z_104 C_1 A_3 E_2 
Stack 12
D_7 C_0 Z_105 
Stack 13
B_4 D_8 B_5 
