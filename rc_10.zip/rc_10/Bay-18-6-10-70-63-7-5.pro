Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
J_4 F_5 Z_100 I_3 
Stack 1
C_4 B_0 Z_101 H_4 
Stack 2
H_5 D_6 I_5 H_6 
Stack 3
G_5 Z_102 I_1 H_1 
Stack 4
C_5 F_1 A_3 G_4 
Stack 5
E_5 F_2 G_1 B_2 
Stack 6
A_2 Z_103 A_1 E_4 
Stack 7
E_6 G_0 D_4 F_3 
Stack 8
C_0 B_3 E_3 E_2 
Stack 9
I_4 I_2 C_3 D_1 
Stack 10
Z_104 H_3 H_2 J_2 
Stack 11
C_1 G_3 Z_105 F_4 
Stack 12
J_0 D_0 A_4 E_0 
Stack 13
D_5 C_2 E_7 B_4 
Stack 14
Z_106 G_2 D_3 I_0 
Stack 15
F_0 J_3 J_1 D_2 
Stack 16
A_0 E_1 D_7 
Stack 17
H_0 B_1 F_6 
