Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_1 D_10 D_8 C_11 B_5 D_12 
Stack 1
D_1 A_8 B_14 B_8 C_8 A_7 
Stack 2
E_11 E_12 A_3 B_6 C_3 C_13 
Stack 3
D_4 D_2 C_15 E_5 Z_100 B_15 
Stack 4
B_11 D_7 E_3 B_3 A_5 
Stack 5
B_7 C_12 Z_101 C_6 A_4 
Stack 6
E_8 A_10 C_5 B_9 Z_102 
Stack 7
B_13 C_10 C_7 Z_103 C_2 
Stack 8
B_2 E_2 D_13 C_1 B_1 
Stack 9
E_9 D_0 A_2 E_4 C_9 
Stack 10
B_0 D_5 E_7 A_9 A_6 
Stack 11
Z_104 D_6 Z_105 Z_106 A_0 
Stack 12
D_9 E_1 E_6 C_4 C_0 
Stack 13
C_14 D_3 E_10 E_0 B_10 
Stack 14
B_12 D_11 B_4 Z_107 E_13 
