Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
M_1 D_1 Z_100 L_1 
Stack 1
D_2 G_1 L_0 Z_101 
Stack 2
L_3 I_7 J_7 E_0 
Stack 3
L_4 E_5 M_2 O_1 
Stack 4
J_3 I_4 H_7 K_1 
Stack 5
F_5 B_1 J_5 F_0 
Stack 6
Z_102 J_0 H_1 Z_103 
Stack 7
C_3 G_0 K_2 G_7 
Stack 8
Z_104 F_1 G_3 L_5 
Stack 9
B_0 H_4 B_2 Z_105 
Stack 10
Z_106 I_5 A_1 G_2 
Stack 11
M_4 H_2 E_4 E_1 
Stack 12
D_0 F_2 K_3 I_6 
Stack 13
M_3 C_4 B_3 H_0 
Stack 14
G_8 J_2 L_2 J_6 
Stack 15
M_0 C_2 Z_107 K_5 
Stack 16
C_0 F_6 I_1 Z_108 
Stack 17
H_3 K_6 I_2 A_0 
Stack 18
I_0 I_3 K_0 J_4 
Stack 19
F_4 G_5 A_2 H_5 
Stack 20
G_4 N_0 Z_109 E_3 
Stack 21
E_2 G_6 F_3 O_2 
Stack 22
K_4 J_1 C_1 
Stack 23
H_8 O_0 H_6 
