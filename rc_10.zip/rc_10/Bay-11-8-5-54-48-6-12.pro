Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_8 B_0 D_10 E_0 E_4 
Stack 1
B_3 D_8 C_6 B_2 B_8 
Stack 2
E_7 B_6 C_5 B_5 D_2 
Stack 3
C_9 B_4 C_1 C_2 E_5 
Stack 4
D_3 E_6 C_0 C_7 A_6 
Stack 5
A_7 A_0 D_9 D_7 D_4 
Stack 6
D_1 C_3 A_5 A_3 Z_100 
Stack 7
E_1 E_3 D_5 B_1 C_4 
Stack 8
A_8 Z_101 A_2 Z_102 A_4 
Stack 9
B_7 E_8 Z_103 D_6 E_2 
Stack 10
A_1 D_0 Z_104 Z_105 
