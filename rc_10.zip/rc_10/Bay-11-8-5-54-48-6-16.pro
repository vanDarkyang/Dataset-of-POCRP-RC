Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_1 C_5 B_0 A_8 Z_100 
Stack 1
D_4 D_1 D_10 D_2 D_3 
Stack 2
E_5 B_5 A_5 Z_101 C_4 
Stack 3
Z_102 D_6 D_5 A_3 B_3 
Stack 4
C_8 C_7 C_3 C_9 C_1 
Stack 5
B_8 A_2 D_9 E_2 B_7 
Stack 6
C_6 E_7 D_7 E_6 B_4 
Stack 7
A_7 B_2 C_2 E_3 A_4 
Stack 8
E_8 D_0 Z_103 Z_104 A_0 
Stack 9
D_8 C_0 B_1 E_1 Z_105 
Stack 10
E_4 A_6 E_0 B_6 
