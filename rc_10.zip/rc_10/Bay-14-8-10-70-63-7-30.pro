Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_0 F_3 J_1 F_6 F_5 
Stack 1
D_4 Z_100 Z_101 H_6 Z_102 
Stack 2
C_3 E_3 J_0 B_3 D_6 
Stack 3
Z_103 A_3 B_1 A_4 E_6 
Stack 4
D_1 J_2 G_4 E_0 I_1 
Stack 5
G_3 I_5 I_4 C_2 D_3 
Stack 6
E_4 B_2 H_2 A_2 D_2 
Stack 7
G_1 B_5 G_2 H_5 G_0 
Stack 8
Z_104 B_4 G_5 I_2 G_7 
Stack 9
F_1 G_6 F_2 D_5 J_3 
Stack 10
A_1 C_1 H_3 E_2 C_4 
Stack 11
E_5 E_1 Z_105 H_0 B_0 
Stack 12
H_4 A_0 F_7 F_0 C_0 
Stack 13
Z_106 I_0 I_3 H_1 F_4 
