Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_9 A_2 B_12 Z_100 
Stack 1
C_11 C_7 C_1 Z_101 
Stack 2
B_0 A_8 C_4 A_1 
Stack 3
A_3 C_12 C_13 A_9 
Stack 4
C_3 A_11 A_6 B_4 
Stack 5
A_10 B_3 A_4 C_5 
Stack 6
B_5 B_8 B_7 Z_102 
Stack 7
A_0 C_2 B_1 B_13 
Stack 8
B_6 C_6 B_2 A_12 
Stack 9
B_10 Z_103 C_0 Z_104 
Stack 10
A_5 C_9 C_10 
Stack 11
A_7 B_11 C_8 
