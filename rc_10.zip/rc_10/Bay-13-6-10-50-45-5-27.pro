Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_1 D_4 J_0 C_3 
Stack 1
C_2 E_0 Z_100 C_4 
Stack 2
Z_101 H_0 J_1 H_1 
Stack 3
E_2 G_4 A_0 G_2 
Stack 4
F_0 D_2 I_1 B_2 
Stack 5
I_0 B_1 C_0 F_3 
Stack 6
E_1 H_4 H_3 Z_102 
Stack 7
D_1 F_4 C_1 G_3 
Stack 8
E_4 J_2 G_1 E_3 
Stack 9
D_0 F_2 I_3 H_2 
Stack 10
D_3 Z_103 Z_104 G_5 
Stack 11
E_5 G_0 A_2 
Stack 12
I_2 B_0 F_1 
