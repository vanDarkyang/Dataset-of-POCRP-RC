Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
J_2 Z_100 L_3 N_3 D_0 G_5 
Stack 1
H_5 K_5 L_4 H_3 I_3 Z_101 
Stack 2
D_1 G_2 O_2 K_2 K_0 F_2 
Stack 3
H_8 F_6 J_1 L_5 F_1 N_1 
Stack 4
E_3 H_0 B_1 Z_102 H_7 
Stack 5
I_2 K_6 H_2 I_4 M_3 
Stack 6
B_3 O_0 Z_103 I_1 G_6 
Stack 7
E_0 F_3 C_1 L_1 H_4 
Stack 8
Z_104 I_6 O_1 J_0 C_0 
Stack 9
G_3 K_4 N_0 B_2 F_5 
Stack 10
G_0 L_2 K_1 M_2 Z_105 
Stack 11
J_4 E_4 I_5 L_0 F_0 
Stack 12
Z_106 H_6 B_0 H_1 G_1 
Stack 13
A_2 K_3 C_4 Z_107 Z_108 
Stack 14
Z_109 D_3 E_1 F_4 E_6 
Stack 15
J_3 G_4 J_5 C_3 D_2 
Stack 16
A_0 E_2 E_5 I_0 M_1 
Stack 17
C_2 A_1 D_4 N_2 M_0 
