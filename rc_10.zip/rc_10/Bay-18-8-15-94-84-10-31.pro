Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
K_2 F_4 D_0 Z_100 M_4 A_1 
Stack 1
L_4 B_3 H_4 Z_101 G_6 M_0 
Stack 2
N_2 M_3 G_2 J_0 H_6 Z_102 
Stack 3
G_5 H_0 A_0 L_5 K_3 N_1 
Stack 4
C_1 I_4 I_3 E_2 F_5 
Stack 5
D_1 Z_103 I_2 G_1 K_0 
Stack 6
G_7 H_5 L_0 Z_104 H_7 
Stack 7
J_2 D_4 J_1 J_6 M_2 
Stack 8
Z_105 H_8 J_4 O_1 I_0 
Stack 9
F_1 K_5 Z_106 J_3 L_1 
Stack 10
G_0 K_1 L_3 D_2 C_3 
Stack 11
Z_107 H_2 H_9 F_3 N_0 
Stack 12
E_5 E_0 J_5 B_1 C_2 
Stack 13
E_3 K_4 D_3 L_2 C_0 
Stack 14
F_7 I_5 Z_108 H_3 O_0 
Stack 15
K_6 B_2 B_0 G_3 M_1 
Stack 16
F_6 F_0 N_3 E_1 F_2 
Stack 17
I_1 Z_109 G_4 E_4 H_1 
