Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
B_10 A_9 B_11 D_7 
Stack 1
C_0 B_1 E_13 E_11 
Stack 2
D_1 Z_100 Z_101 Z_102 
Stack 3
A_4 C_4 B_12 D_8 
Stack 4
C_7 B_2 D_0 E_6 
Stack 5
B_4 B_5 E_12 A_11 
Stack 6
A_12 C_6 B_3 E_4 
Stack 7
C_2 E_1 A_1 C_3 
Stack 8
E_2 C_15 E_9 D_3 
Stack 9
C_14 C_1 D_6 C_13 
Stack 10
B_0 D_10 D_11 B_8 
Stack 11
C_12 Z_103 A_10 A_0 
Stack 12
B_7 Z_104 D_12 E_0 
Stack 13
Z_105 D_2 B_6 B_9 
Stack 14
C_8 A_3 E_7 C_16 
Stack 15
Z_106 A_2 E_8 C_9 
Stack 16
E_3 C_11 D_9 A_7 
Stack 17
C_5 B_13 A_5 E_10 
Stack 18
Z_107 D_4 E_5 A_6 
Stack 19
D_5 A_8 C_10 
