Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_1 C_4 C_10 A_0 
Stack 1
B_5 C_1 Z_100 C_5 
Stack 2
C_0 B_3 B_1 A_10 
Stack 3
B_13 B_0 Z_101 A_4 
Stack 4
A_7 C_2 C_6 A_8 
Stack 5
Z_102 A_12 B_2 B_4 
Stack 6
C_7 C_12 A_3 B_9 
Stack 7
B_7 B_10 B_6 B_8 
Stack 8
A_9 B_11 A_2 B_14 
Stack 9
A_5 C_9 A_11 Z_103 
Stack 10
C_11 C_3 Z_104 
Stack 11
C_8 B_12 A_6 
