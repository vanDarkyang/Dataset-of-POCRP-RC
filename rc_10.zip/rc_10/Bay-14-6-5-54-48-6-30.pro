Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
Z_100 B_1 C_9 E_8 
Stack 1
A_3 C_3 Z_101 E_3 
Stack 2
C_8 A_0 Z_102 E_4 
Stack 3
D_7 E_0 A_7 B_3 
Stack 4
B_7 B_8 C_1 D_3 
Stack 5
A_1 B_6 D_2 A_2 
Stack 6
E_2 E_1 D_1 D_9 
Stack 7
C_6 A_6 E_7 A_8 
Stack 8
D_4 C_2 Z_103 C_5 
Stack 9
E_6 D_6 C_4 E_5 
Stack 10
B_4 B_5 Z_104 D_0 
Stack 11
A_4 C_0 D_8 E_9 
Stack 12
B_2 C_7 Z_105 
Stack 13
A_5 B_0 D_5 
