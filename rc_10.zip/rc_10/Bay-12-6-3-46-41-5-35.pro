Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
Z_100 A_11 B_3 B_5 
Stack 1
C_12 Z_101 B_7 A_0 
Stack 2
C_3 Z_102 B_0 B_1 
Stack 3
A_9 B_4 B_8 A_13 
Stack 4
C_7 A_3 Z_103 B_12 
Stack 5
A_14 Z_104 C_10 A_10 
Stack 6
A_8 B_11 A_5 C_8 
Stack 7
C_1 A_12 A_6 C_9 
Stack 8
B_9 A_4 C_5 B_10 
Stack 9
B_6 C_4 C_6 A_2 
Stack 10
C_11 A_1 B_2 
Stack 11
C_2 C_0 A_7 
