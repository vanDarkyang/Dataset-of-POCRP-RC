Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
K_0 Z_100 K_3 M_4 
Stack 1
B_0 Z_101 C_1 E_4 
Stack 2
L_1 Z_102 B_3 Z_103 
Stack 3
H_6 H_3 I_8 D_1 
Stack 4
N_2 L_0 N_0 E_1 
Stack 5
O_2 I_6 C_0 C_2 
Stack 6
L_2 E_2 K_1 Z_104 
Stack 7
Z_105 I_2 E_6 A_2 
Stack 8
E_0 E_3 H_2 G_4 
Stack 9
Z_106 M_3 I_7 M_1 
Stack 10
K_4 D_5 M_0 L_4 
Stack 11
D_2 F_4 G_5 F_3 
Stack 12
I_0 E_5 Z_107 D_3 
Stack 13
I_1 J_2 J_4 J_1 
Stack 14
D_4 F_1 J_3 G_3 
Stack 15
G_2 O_1 H_8 O_0 
Stack 16
G_1 K_6 J_5 C_3 
Stack 17
H_4 H_1 I_4 I_5 
Stack 18
H_7 L_3 H_0 B_2 
Stack 19
F_5 A_1 H_5 G_0 
Stack 20
J_0 F_2 K_5 Z_108 
Stack 21
K_2 D_0 M_2 A_0 
Stack 22
B_1 Z_109 N_1 
Stack 23
F_0 G_6 I_3 
