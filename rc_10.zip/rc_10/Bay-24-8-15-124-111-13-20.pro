Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
I_1 I_8 H_1 Z_100 Z_101 N_1 
Stack 1
G_5 E_1 Z_102 J_5 I_0 E_2 
Stack 2
Z_103 F_2 Z_104 O_3 M_2 H_8 
Stack 3
G_4 F_5 K_7 A_3 M_5 D_3 
Stack 4
L_1 I_5 A_1 H_4 C_0 
Stack 5
H_10 I_4 Z_105 A_4 O_1 
Stack 6
J_4 J_2 K_3 N_0 I_2 
Stack 7
E_3 F_1 J_0 O_0 L_0 
Stack 8
G_3 E_0 I_10 G_6 N_3 
Stack 9
I_9 O_2 F_9 I_7 F_0 
Stack 10
G_7 B_4 M_0 Z_106 G_8 
Stack 11
M_3 Z_107 E_5 I_3 C_6 
Stack 12
B_3 M_1 F_8 L_3 G_2 
Stack 13
G_1 H_2 J_1 K_2 D_1 
Stack 14
Z_108 C_1 N_4 E_4 N_2 
Stack 15
L_4 J_7 A_0 C_4 D_4 
Stack 16
K_4 G_0 Z_109 K_1 Z_110 
Stack 17
F_6 Z_111 C_3 D_0 J_6 
Stack 18
L_5 H_3 E_6 H_6 O_4 
Stack 19
M_4 F_4 D_2 K_6 D_5 
Stack 20
F_7 B_1 H_9 J_3 D_6 
Stack 21
K_0 H_0 L_2 C_5 I_6 
Stack 22
Z_112 B_2 A_2 K_5 F_3 
Stack 23
D_7 C_2 H_7 B_0 H_5 
