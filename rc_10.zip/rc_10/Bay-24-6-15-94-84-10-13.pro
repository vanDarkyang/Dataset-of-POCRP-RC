Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
N_1 N_0 N_3 M_3 
Stack 1
F_3 D_0 K_1 A_1 
Stack 2
I_2 G_3 E_2 J_2 
Stack 3
E_5 I_5 E_0 C_2 
Stack 4
H_4 G_2 J_1 J_3 
Stack 5
B_2 Z_100 O_0 H_8 
Stack 6
J_4 E_3 Z_101 K_0 
Stack 7
C_1 I_8 D_1 F_0 
Stack 8
I_0 M_1 K_2 Z_102 
Stack 9
D_4 H_2 D_3 C_3 
Stack 10
A_2 G_8 H_7 B_3 
Stack 11
B_1 L_3 A_0 G_4 
Stack 12
C_0 G_1 Z_103 I_7 
Stack 13
M_0 H_5 J_0 K_3 
Stack 14
I_4 D_2 E_6 Z_104 
Stack 15
G_7 F_6 I_6 G_6 
Stack 16
F_1 H_0 Z_105 N_2 
Stack 17
H_6 Z_106 H_3 Z_107 
Stack 18
F_5 G_5 K_4 K_5 
Stack 19
E_1 L_1 J_5 O_1 
Stack 20
I_1 I_3 E_4 M_2 
Stack 21
G_0 Z_108 H_9 F_4 
Stack 22
L_0 L_2 H_1 
Stack 23
F_2 B_0 Z_109 
