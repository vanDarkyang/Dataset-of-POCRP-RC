Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_8 B_2 C_10 C_3 
Stack 1
C_4 B_14 A_7 B_0 
Stack 2
A_5 A_1 C_6 C_2 
Stack 3
A_9 B_11 B_1 B_12 
Stack 4
C_0 C_7 Z_100 C_11 
Stack 5
Z_101 C_8 A_0 B_10 
Stack 6
A_11 B_4 B_13 C_13 
Stack 7
B_3 C_1 Z_102 Z_103 
Stack 8
A_6 Z_104 C_5 B_5 
Stack 9
C_12 A_2 B_6 B_7 
Stack 10
B_9 A_10 C_9 
Stack 11
A_3 A_8 A_4 
