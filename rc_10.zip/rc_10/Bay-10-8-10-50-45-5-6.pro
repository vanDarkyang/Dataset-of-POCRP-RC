Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_1 J_1 F_1 G_0 F_0 
Stack 1
C_2 H_4 G_4 A_1 A_2 
Stack 2
B_0 Z_100 G_1 Z_101 F_3 
Stack 3
B_2 D_0 F_2 C_3 D_3 
Stack 4
I_0 E_2 G_3 F_5 E_0 
Stack 5
A_0 J_2 G_2 Z_102 H_3 
Stack 6
I_2 I_1 E_5 I_3 H_2 
Stack 7
D_4 D_1 E_4 C_0 H_0 
Stack 8
C_1 E_3 B_1 D_2 Z_103 
Stack 9
F_4 E_6 H_1 Z_104 J_0 
