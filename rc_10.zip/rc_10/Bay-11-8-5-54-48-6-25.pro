Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_1 E_3 E_0 D_0 E_2 
Stack 1
C_3 B_9 D_5 B_4 E_5 
Stack 2
D_9 A_2 A_8 D_3 A_3 
Stack 3
A_6 D_8 A_1 A_9 B_0 
Stack 4
C_7 Z_100 A_7 E_4 C_2 
Stack 5
C_5 D_4 B_2 A_4 Z_101 
Stack 6
B_5 Z_102 C_0 E_1 E_6 
Stack 7
B_3 A_0 E_7 B_7 C_6 
Stack 8
B_8 D_1 D_2 B_6 D_7 
Stack 9
B_10 Z_103 Z_104 E_8 C_4 
Stack 10
Z_105 C_1 D_6 A_5 
