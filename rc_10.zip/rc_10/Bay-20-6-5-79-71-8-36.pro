Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
Z_100 B_13 D_0 D_4 
Stack 1
D_8 A_4 E_7 E_1 
Stack 2
D_3 A_11 C_0 C_5 
Stack 3
B_9 A_3 E_12 E_10 
Stack 4
B_10 C_12 E_0 Z_101 
Stack 5
B_8 B_1 E_6 D_2 
Stack 6
C_6 C_15 B_2 A_8 
Stack 7
A_7 A_5 B_7 D_12 
Stack 8
E_4 D_9 Z_102 E_11 
Stack 9
C_8 Z_103 C_3 D_7 
Stack 10
B_11 B_12 E_5 A_6 
Stack 11
A_1 Z_104 C_4 E_9 
Stack 12
E_2 B_0 B_6 C_11 
Stack 13
E_3 A_2 C_1 D_1 
Stack 14
C_2 D_6 D_11 C_10 
Stack 15
A_10 A_0 C_7 D_5 
Stack 16
B_14 C_9 D_10 D_13 
Stack 17
Z_105 D_14 B_3 Z_106 
Stack 18
Z_107 B_4 B_5 C_14 
Stack 19
A_9 E_8 C_13 
