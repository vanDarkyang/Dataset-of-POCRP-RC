Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_1 B_11 A_4 B_10 
Stack 1
C_0 A_10 A_2 B_4 
Stack 2
A_7 A_8 B_3 C_5 
Stack 3
B_0 C_7 C_11 C_3 
Stack 4
A_3 B_5 A_0 Z_100 
Stack 5
C_4 C_10 C_13 A_1 
Stack 6
Z_101 A_11 C_9 B_9 
Stack 7
B_8 Z_102 C_2 C_1 
Stack 8
A_6 A_13 Z_103 A_12 
Stack 9
B_6 B_7 C_6 C_12 
Stack 10
Z_104 A_5 A_14 
Stack 11
A_9 B_2 C_8 
