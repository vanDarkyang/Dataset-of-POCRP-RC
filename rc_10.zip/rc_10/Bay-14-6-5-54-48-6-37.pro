Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_5 Z_100 B_5 C_0 
Stack 1
E_2 A_4 D_4 E_8 
Stack 2
B_7 B_1 C_9 D_1 
Stack 3
C_1 D_9 B_2 B_0 
Stack 4
C_8 E_7 Z_101 B_8 
Stack 5
D_2 C_10 A_0 A_3 
Stack 6
B_3 D_5 Z_102 A_1 
Stack 7
E_4 E_0 Z_103 E_6 
Stack 8
D_8 A_6 D_3 C_7 
Stack 9
D_0 E_9 E_3 C_5 
Stack 10
C_3 A_2 C_4 B_4 
Stack 11
E_1 Z_104 C_6 C_2 
Stack 12
Z_105 D_7 D_6 
Stack 13
B_6 A_7 A_5 
