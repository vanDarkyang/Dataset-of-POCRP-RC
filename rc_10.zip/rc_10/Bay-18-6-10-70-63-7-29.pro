Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_2 I_2 J_4 E_5 
Stack 1
A_2 G_7 G_4 I_4 
Stack 2
G_6 F_1 D_3 B_1 
Stack 3
C_5 H_3 E_4 H_6 
Stack 4
J_2 Z_100 C_6 Z_101 
Stack 5
I_3 H_5 F_5 F_8 
Stack 6
C_1 E_0 G_3 J_0 
Stack 7
H_1 Z_102 A_0 Z_103 
Stack 8
E_2 E_3 H_0 F_0 
Stack 9
C_4 Z_104 A_1 H_2 
Stack 10
D_4 D_0 I_0 B_4 
Stack 11
F_7 D_1 G_1 F_3 
Stack 12
J_1 B_3 F_6 C_3 
Stack 13
E_1 F_2 B_2 D_6 
Stack 14
B_0 C_0 D_5 I_1 
Stack 15
J_3 G_2 G_0 Z_105 
Stack 16
F_4 G_5 Z_106 
Stack 17
B_5 H_4 C_2 
