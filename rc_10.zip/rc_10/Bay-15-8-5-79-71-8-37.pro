Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
B_9 Z_100 D_12 E_11 D_8 Z_101 
Stack 1
C_0 E_3 E_10 B_2 E_9 A_9 
Stack 2
D_1 C_5 B_1 A_2 D_11 Z_102 
Stack 3
A_5 D_5 D_2 E_8 D_9 A_7 
Stack 4
C_7 D_6 A_4 D_7 E_6 
Stack 5
B_3 Z_103 A_3 D_13 A_12 
Stack 6
A_13 Z_104 C_9 A_11 E_4 
Stack 7
C_2 B_13 B_12 D_14 C_3 
Stack 8
E_2 C_4 D_4 B_5 D_3 
Stack 9
C_12 Z_105 A_10 E_7 C_11 
Stack 10
B_0 B_4 B_10 Z_106 B_7 
Stack 11
C_10 C_6 E_12 D_10 A_1 
Stack 12
B_6 E_1 A_0 A_6 E_0 
Stack 13
A_8 C_13 B_11 E_5 B_8 
Stack 14
Z_107 C_1 D_0 C_8 C_14 
