Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
D_11 E_13 B_6 B_2 Z_100 B_5 
Stack 1
C_7 C_12 B_4 A_10 E_1 Z_101 
Stack 2
B_0 A_6 Z_102 D_5 C_3 E_9 
Stack 3
C_14 C_4 A_2 E_3 E_11 B_1 
Stack 4
C_1 A_11 Z_103 D_8 E_5 
Stack 5
A_12 E_4 E_14 D_14 A_1 
Stack 6
E_12 A_5 D_1 C_2 A_7 
Stack 7
Z_104 C_6 C_10 D_4 E_10 
Stack 8
E_2 B_3 E_7 Z_105 C_13 
Stack 9
D_7 C_0 E_0 Z_106 D_3 
Stack 10
B_10 C_11 D_10 C_9 B_12 
Stack 11
B_8 Z_107 D_6 D_9 B_11 
Stack 12
A_0 D_12 E_8 D_13 E_6 
Stack 13
C_8 C_5 D_0 A_9 A_3 
Stack 14
B_9 B_7 A_4 D_2 A_8 
