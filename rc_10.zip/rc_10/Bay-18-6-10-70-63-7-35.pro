Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
B_2 Z_100 H_6 B_4 
Stack 1
A_1 F_1 J_0 D_5 
Stack 2
G_1 A_3 F_3 B_1 
Stack 3
F_4 H_1 G_5 I_3 
Stack 4
F_2 Z_101 E_2 Z_102 
Stack 5
F_0 G_2 E_4 E_0 
Stack 6
C_2 J_2 F_8 Z_103 
Stack 7
Z_104 E_3 I_1 J_3 
Stack 8
J_4 C_4 D_6 E_7 
Stack 9
G_0 I_4 D_4 C_3 
Stack 10
A_2 E_6 H_0 E_5 
Stack 11
D_0 I_5 F_6 H_2 
Stack 12
G_4 H_5 C_0 D_3 
Stack 13
A_0 Z_105 D_7 D_2 
Stack 14
H_3 B_0 H_4 I_2 
Stack 15
D_1 B_3 F_5 E_1 
Stack 16
F_7 J_1 Z_106 
Stack 17
G_3 I_0 C_1 
