Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_3 A_0 B_4 B_2 
Stack 1
A_4 C_0 Z_100 I_1 
Stack 2
E_3 G_4 B_5 C_2 
Stack 3
B_3 Z_101 D_1 I_5 
Stack 4
H_2 A_3 I_4 Z_102 
Stack 5
F_1 Z_103 B_1 J_1 
Stack 6
J_0 F_5 D_7 H_0 
Stack 7
E_6 F_8 C_4 E_2 
Stack 8
F_3 H_1 I_2 B_0 
Stack 9
C_3 G_3 D_2 E_5 
Stack 10
Z_104 F_7 D_6 F_0 
Stack 11
F_6 E_7 A_2 E_4 
Stack 12
A_1 D_5 E_1 F_2 
Stack 13
I_0 Z_105 Z_106 G_6 
Stack 14
G_2 H_4 H_5 G_5 
Stack 15
D_0 E_0 F_4 G_0 
Stack 16
D_4 H_3 C_1 
Stack 17
G_1 I_3 E_8 
