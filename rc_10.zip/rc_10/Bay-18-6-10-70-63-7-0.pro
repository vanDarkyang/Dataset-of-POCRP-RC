Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
E_7 H_2 C_2 H_0 
Stack 1
B_2 Z_100 J_2 C_1 
Stack 2
F_1 C_4 Z_101 I_0 
Stack 3
F_5 E_2 D_3 D_2 
Stack 4
D_0 E_1 J_1 G_5 
Stack 5
F_2 I_1 F_6 H_3 
Stack 6
Z_102 F_0 D_6 A_2 
Stack 7
G_2 A_0 J_3 D_1 
Stack 8
E_4 E_6 G_0 G_1 
Stack 9
H_5 Z_103 E_3 C_3 
Stack 10
F_7 D_4 B_3 I_4 
Stack 11
C_5 E_5 J_0 Z_104 
Stack 12
H_1 F_3 A_1 G_6 
Stack 13
G_4 B_0 F_4 G_7 
Stack 14
Z_105 I_2 B_4 G_3 
Stack 15
H_4 C_0 D_5 I_3 
Stack 16
Z_106 E_8 H_6 
Stack 17
E_0 A_3 B_1 
