Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
J_0 D_2 I_4 N_2 E_0 O_0 
Stack 1
K_3 I_1 H_4 L_2 N_1 I_0 
Stack 2
H_2 C_2 D_1 H_1 B_1 K_6 
Stack 3
Z_100 I_6 A_2 J_2 F_2 L_4 
Stack 4
G_3 F_5 J_3 I_2 I_3 
Stack 5
D_4 H_7 L_5 I_7 L_1 
Stack 6
E_1 M_0 K_5 J_1 G_0 
Stack 7
D_0 H_6 B_2 Z_101 G_4 
Stack 8
Z_102 K_1 O_2 M_3 G_2 
Stack 9
H_5 Z_103 Z_104 F_6 F_7 
Stack 10
H_8 L_3 B_0 C_1 Z_105 
Stack 11
B_3 E_4 A_0 I_5 M_1 
Stack 12
H_0 M_4 K_4 C_3 Z_106 
Stack 13
F_4 C_0 K_2 D_3 G_6 
Stack 14
E_3 F_0 G_5 M_2 I_8 
Stack 15
E_5 A_1 Z_107 H_3 Z_108 
Stack 16
L_0 N_0 F_3 O_1 J_4 
Stack 17
E_2 K_0 G_1 F_1 Z_109 
