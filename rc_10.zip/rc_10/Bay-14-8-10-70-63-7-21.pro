Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
I_3 C_4 D_1 C_5 Z_100 
Stack 1
D_2 H_5 G_6 I_5 H_4 
Stack 2
E_1 A_3 D_5 E_5 I_4 
Stack 3
Z_101 F_1 C_3 Z_102 I_1 
Stack 4
B_2 I_0 F_8 E_6 H_2 
Stack 5
C_2 G_4 B_3 J_1 D_4 
Stack 6
D_6 E_0 Z_103 Z_104 D_3 
Stack 7
D_0 B_0 C_1 G_2 E_2 
Stack 8
H_3 B_1 B_4 E_4 B_5 
Stack 9
H_6 F_7 G_3 J_2 A_0 
Stack 10
G_5 I_2 F_2 F_0 C_0 
Stack 11
G_7 Z_105 Z_106 E_3 F_5 
Stack 12
G_1 H_0 A_1 H_1 F_4 
Stack 13
F_3 G_0 A_2 F_6 J_0 
