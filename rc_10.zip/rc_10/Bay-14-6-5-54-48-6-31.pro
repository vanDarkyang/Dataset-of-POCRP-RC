Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_1 E_0 E_8 Z_100 
Stack 1
E_1 Z_101 D_2 D_0 
Stack 2
A_3 C_8 C_9 D_8 
Stack 3
C_5 Z_102 B_4 E_6 
Stack 4
C_4 E_2 E_4 D_4 
Stack 5
E_7 A_5 B_7 Z_103 
Stack 6
B_2 B_9 D_1 D_6 
Stack 7
B_1 Z_104 A_2 A_0 
Stack 8
C_10 D_3 B_0 B_3 
Stack 9
B_8 Z_105 C_3 E_5 
Stack 10
E_9 C_2 E_3 C_6 
Stack 11
C_1 B_5 C_0 D_5 
Stack 12
A_4 B_10 D_7 
Stack 13
C_7 A_6 B_6 
