Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
D_2 E_3 B_14 E_8 B_11 A_1 
Stack 1
D_11 A_10 C_11 C_14 B_12 Z_100 
Stack 2
B_13 C_13 A_13 E_7 B_8 E_11 
Stack 3
C_3 Z_101 A_9 C_5 Z_102 E_9 
Stack 4
B_10 A_6 E_5 C_9 C_1 
Stack 5
A_3 D_9 E_1 D_6 A_5 
Stack 6
C_12 Z_103 E_4 D_7 C_10 
Stack 7
E_12 D_3 C_0 D_0 Z_104 
Stack 8
C_4 A_0 C_2 A_8 A_4 
Stack 9
B_9 A_14 Z_105 B_3 B_4 
Stack 10
B_7 C_15 E_2 B_5 A_12 
Stack 11
D_1 B_2 Z_106 C_7 A_2 
Stack 12
A_7 B_6 B_1 B_0 E_0 
Stack 13
C_6 A_11 D_5 E_6 D_10 
Stack 14
C_8 Z_107 D_8 E_10 D_4 
