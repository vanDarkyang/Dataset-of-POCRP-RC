Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
D_2 I_0 B_1 I_1 F_3 
Stack 1
G_3 A_0 D_3 Z_100 D_1 
Stack 2
E_2 F_5 J_1 C_0 G_0 
Stack 3
G_5 D_0 H_0 F_2 F_0 
Stack 4
B_2 H_1 C_1 J_0 F_1 
Stack 5
F_4 D_5 C_2 H_2 E_4 
Stack 6
J_2 Z_101 H_3 E_1 E_0 
Stack 7
G_1 I_3 Z_102 E_3 G_4 
Stack 8
I_2 E_6 E_5 Z_103 D_4 
Stack 9
C_3 A_1 G_2 Z_104 B_0 
