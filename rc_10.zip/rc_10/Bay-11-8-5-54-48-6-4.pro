Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_5 D_6 D_8 B_8 E_6 
Stack 1
E_8 D_2 E_3 D_4 C_1 
Stack 2
A_6 B_6 B_1 E_4 C_10 
Stack 3
E_7 B_2 A_1 D_5 Z_100 
Stack 4
A_0 Z_101 Z_102 C_5 C_0 
Stack 5
A_7 Z_103 Z_104 Z_105 E_1 
Stack 6
B_9 C_7 A_3 B_7 D_1 
Stack 7
D_7 E_2 C_9 B_3 C_8 
Stack 8
C_3 C_2 A_4 D_9 A_5 
Stack 9
B_5 A_2 B_4 C_6 B_0 
Stack 10
C_4 D_0 D_3 E_0 
