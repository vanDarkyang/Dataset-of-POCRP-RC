Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_3 A_3 Z_100 E_0 
Stack 1
A_9 D_0 B_4 D_8 
Stack 2
C_6 D_1 B_8 C_3 
Stack 3
Z_101 C_4 B_9 D_9 
Stack 4
E_1 E_3 B_3 A_0 
Stack 5
D_2 E_4 A_6 Z_102 
Stack 6
E_5 B_6 D_6 E_2 
Stack 7
D_4 B_1 B_2 A_7 
Stack 8
A_5 C_2 B_0 E_9 
Stack 9
E_7 E_6 A_2 A_4 
Stack 10
Z_103 D_7 E_8 Z_104 
Stack 11
C_1 B_10 D_5 B_5 
Stack 12
C_0 Z_105 A_1 
Stack 13
B_7 C_5 A_8 
