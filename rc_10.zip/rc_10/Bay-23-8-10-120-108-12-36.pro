Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
Z_100 E_0 B_3 F_11 C_3 B_10 
Stack 1
D_9 Z_101 H_9 H_6 Z_102 D_8 
Stack 2
D_3 D_6 D_4 G_5 E_11 F_9 
Stack 3
A_2 F_0 J_3 A_5 A_0 J_1 
Stack 4
B_1 D_0 Z_103 C_0 E_7 B_8 
Stack 5
H_10 I_6 D_5 E_1 F_2 
Stack 6
C_4 G_10 C_2 A_7 I_9 
Stack 7
C_10 I_0 E_3 H_1 G_0 
Stack 8
G_4 D_7 H_8 C_9 A_1 
Stack 9
Z_104 E_9 B_5 H_2 F_5 
Stack 10
C_6 Z_105 J_7 Z_106 I_4 
Stack 11
A_3 G_12 H_5 B_2 F_8 
Stack 12
H_3 H_0 B_0 J_5 D_10 
Stack 13
B_6 C_8 F_10 E_6 C_1 
Stack 14
G_8 E_10 G_11 E_4 G_9 
Stack 15
E_8 G_3 J_6 A_4 B_9 
Stack 16
I_2 F_7 B_4 J_0 F_4 
Stack 17
A_6 E_5 I_1 H_7 J_2 
Stack 18
F_6 B_7 Z_107 I_7 F_3 
Stack 19
C_5 G_1 D_2 Z_108 J_4 
Stack 20
E_2 G_7 F_1 Z_109 G_6 
Stack 21
I_8 D_1 A_8 Z_110 I_3 
Stack 22
C_7 I_5 H_4 Z_111 G_2 
