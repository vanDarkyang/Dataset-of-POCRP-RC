Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_1 C_7 Z_100 C_1 
Stack 1
A_7 D_12 E_1 A_0 
Stack 2
C_14 C_2 D_6 C_12 
Stack 3
A_9 C_4 B_4 B_13 
Stack 4
Z_101 D_0 B_7 D_4 
Stack 5
B_1 E_11 C_9 A_8 
Stack 6
A_2 C_15 E_10 E_7 
Stack 7
B_2 C_8 E_4 E_3 
Stack 8
B_0 D_9 Z_102 Z_103 
Stack 9
D_8 B_8 D_11 A_4 
Stack 10
B_5 C_6 Z_104 E_12 
Stack 11
D_5 D_1 E_5 A_12 
Stack 12
C_11 C_5 Z_105 C_10 
Stack 13
E_13 C_13 E_6 Z_106 
Stack 14
A_6 D_10 C_3 E_8 
Stack 15
C_0 A_10 D_7 A_5 
Stack 16
D_2 D_3 E_9 B_9 
Stack 17
B_11 B_6 Z_107 A_3 
Stack 18
E_0 D_13 A_11 B_12 
Stack 19
B_3 B_10 E_2 
