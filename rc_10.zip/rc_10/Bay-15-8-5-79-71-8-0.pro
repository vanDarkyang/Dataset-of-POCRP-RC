Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_8 B_13 C_2 C_4 A_3 E_0 
Stack 1
E_9 D_9 D_13 B_5 A_7 D_0 
Stack 2
C_5 D_1 D_5 E_11 C_3 A_4 
Stack 3
B_9 E_3 E_13 D_6 C_12 A_6 
Stack 4
C_7 A_2 E_12 B_2 D_14 
Stack 5
D_7 B_11 C_13 C_1 A_1 
Stack 6
C_10 C_6 Z_100 E_8 Z_101 
Stack 7
B_7 D_2 E_1 D_10 B_1 
Stack 8
D_4 Z_102 C_8 D_11 E_4 
Stack 9
C_15 C_9 A_9 B_3 C_14 
Stack 10
B_10 Z_103 B_8 E_5 D_12 
Stack 11
A_5 Z_104 B_4 E_2 B_6 
Stack 12
B_0 B_12 B_14 D_8 A_10 
Stack 13
D_3 C_11 Z_105 A_0 E_10 
Stack 14
Z_106 Z_107 E_7 E_6 C_0 
