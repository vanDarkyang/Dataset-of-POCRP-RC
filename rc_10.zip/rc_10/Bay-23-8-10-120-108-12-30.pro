Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
D_11 F_9 D_5 C_0 D_6 Z_100 
Stack 1
C_9 Z_101 G_7 I_4 G_0 C_3 
Stack 2
J_2 E_1 I_9 A_8 G_8 H_4 
Stack 3
J_5 Z_102 C_8 F_12 I_3 G_2 
Stack 4
I_0 H_0 E_6 E_2 E_9 F_1 
Stack 5
G_9 C_1 Z_103 Z_104 D_10 
Stack 6
D_8 D_9 Z_105 F_8 E_13 
Stack 7
B_7 F_7 J_3 G_4 B_3 
Stack 8
H_3 F_0 C_4 D_2 I_1 
Stack 9
E_11 E_12 H_6 E_0 F_4 
Stack 10
E_3 D_7 Z_106 B_10 A_7 
Stack 11
B_1 B_2 E_4 E_5 I_6 
Stack 12
E_10 G_1 F_6 A_2 G_3 
Stack 13
B_9 G_6 I_7 H_7 J_0 
Stack 14
H_9 B_6 A_1 I_2 F_10 
Stack 15
A_9 F_3 Z_107 A_3 H_1 
Stack 16
F_2 H_8 B_4 D_3 C_7 
Stack 17
Z_108 A_4 A_5 F_11 D_0 
Stack 18
F_5 G_5 H_5 H_2 J_1 
Stack 19
Z_109 E_7 I_5 D_12 D_1 
Stack 20
C_6 J_4 G_10 I_8 B_5 
Stack 21
A_6 D_4 Z_110 Z_111 E_8 
Stack 22
A_0 B_0 B_8 C_2 C_5 
