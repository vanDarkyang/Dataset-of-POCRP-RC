Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_8 C_11 Z_100 B_6 E_6 A_10 
Stack 1
C_3 B_10 D_2 B_12 A_7 B_11 
Stack 2
E_7 Z_101 C_1 C_7 E_3 E_8 
Stack 3
B_4 A_0 C_6 C_10 E_10 A_11 
Stack 4
D_14 D_15 B_1 A_6 B_7 
Stack 5
C_5 C_0 D_5 E_0 A_3 
Stack 6
A_5 B_9 Z_102 A_9 D_8 
Stack 7
C_2 C_4 E_1 A_1 D_0 
Stack 8
D_1 E_13 E_5 A_2 Z_103 
Stack 9
E_4 B_2 D_7 C_9 D_12 
Stack 10
D_11 C_8 D_3 E_2 D_10 
Stack 11
Z_104 Z_105 C_14 B_8 C_13 
Stack 12
A_4 Z_106 Z_107 B_0 E_9 
Stack 13
B_5 E_11 C_12 A_12 B_3 
Stack 14
D_6 D_13 E_12 D_4 D_9 
