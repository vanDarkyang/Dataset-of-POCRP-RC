Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
D_0 E_6 A_2 A_0 G_1 H_2 
Stack 1
K_2 Z_100 J_0 I_2 L_0 Z_101 
Stack 2
H_6 J_2 M_0 Z_102 Z_103 E_3 
Stack 3
H_8 I_0 H_5 B_2 J_3 M_2 
Stack 4
F_2 H_4 C_3 F_6 F_4 
Stack 5
H_7 I_3 K_4 Z_104 C_2 
Stack 6
E_2 H_9 G_2 K_5 M_3 
Stack 7
M_4 L_2 L_4 G_4 H_0 
Stack 8
N_0 D_3 I_4 H_3 J_4 
Stack 9
L_1 D_2 G_0 E_0 F_1 
Stack 10
F_5 I_1 C_1 E_4 N_2 
Stack 11
B_1 E_1 J_6 Z_105 N_1 
Stack 12
G_8 O_2 H_1 J_5 G_3 
Stack 13
O_1 K_0 E_5 Z_106 F_0 
Stack 14
G_5 C_4 K_3 I_5 D_1 
Stack 15
Z_107 K_1 J_1 C_0 B_0 
Stack 16
Z_108 G_6 F_3 L_3 Z_109 
Stack 17
M_1 O_0 A_1 I_6 G_7 
