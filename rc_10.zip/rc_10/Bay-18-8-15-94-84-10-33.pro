Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
N_3 L_0 K_2 C_0 N_2 F_3 
Stack 1
K_3 H_7 I_5 M_2 E_5 Z_100 
Stack 2
L_2 B_1 Z_101 G_0 M_0 F_2 
Stack 3
J_4 J_1 Z_102 H_0 I_8 L_3 
Stack 4
E_6 B_2 J_3 J_5 E_2 
Stack 5
G_1 E_1 F_7 L_1 M_1 
Stack 6
E_3 I_1 F_6 H_2 H_5 
Stack 7
O_0 J_6 F_5 K_1 N_0 
Stack 8
C_2 K_4 A_0 E_0 F_1 
Stack 9
Z_103 M_3 A_1 J_0 O_1 
Stack 10
L_4 N_1 Z_104 I_4 H_6 
Stack 11
G_3 G_5 F_0 I_3 H_4 
Stack 12
I_7 I_0 J_2 D_2 H_3 
Stack 13
G_2 D_0 E_4 Z_105 G_4 
Stack 14
H_9 H_1 J_7 Z_106 B_0 
Stack 15
B_3 I_2 H_8 C_1 D_3 
Stack 16
K_5 Z_107 G_6 Z_108 Z_109 
Stack 17
D_1 F_4 I_6 K_0 K_6 
