Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_1 H_7 Z_100 M_1 K_4 F_5 
Stack 1
M_2 L_3 K_1 E_1 C_0 B_2 
Stack 2
I_5 Z_101 I_3 D_2 J_6 N_0 
Stack 3
A_2 H_0 H_3 K_3 H_6 O_1 
Stack 4
K_2 G_3 A_1 G_4 C_3 
Stack 5
Z_102 L_1 G_6 C_2 F_1 
Stack 6
H_5 F_0 N_2 E_6 G_2 
Stack 7
G_7 E_4 Z_103 E_3 J_2 
Stack 8
J_3 O_2 B_1 F_2 L_4 
Stack 9
Z_104 O_0 H_2 Z_105 G_1 
Stack 10
D_3 H_4 J_5 L_0 Z_106 
Stack 11
I_0 G_0 J_0 D_0 N_1 
Stack 12
M_4 D_4 M_0 F_4 D_5 
Stack 13
J_4 E_5 G_5 K_0 I_8 
Stack 14
I_4 M_3 I_1 Z_107 E_2 
Stack 15
F_3 F_6 I_2 L_2 J_7 
Stack 16
D_1 Z_108 I_6 A_0 J_1 
Stack 17
I_7 E_0 B_0 H_1 Z_109 
