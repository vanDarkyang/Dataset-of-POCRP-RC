Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_1 C_12 E_7 B_5 
Stack 1
D_1 A_12 A_3 C_7 
Stack 2
E_10 C_9 E_5 C_2 
Stack 3
D_4 E_2 E_9 Z_100 
Stack 4
B_10 D_0 B_4 A_6 
Stack 5
Z_101 D_5 C_11 A_5 
Stack 6
Z_102 D_6 B_7 A_2 
Stack 7
B_12 E_1 B_6 Z_103 
Stack 8
B_2 D_3 E_4 B_1 
Stack 9
E_8 D_11 B_3 C_8 
Stack 10
B_0 D_8 C_5 A_7 
Stack 11
D_12 B_13 B_8 A_0 
Stack 12
D_9 A_4 E_6 C_0 
Stack 13
C_14 C_15 C_1 B_9 
Stack 14
B_11 E_3 Z_104 E_12 
Stack 15
D_10 C_10 A_11 D_13 
Stack 16
A_10 C_4 Z_105 A_8 
Stack 17
E_11 C_6 C_3 C_13 
Stack 18
D_2 D_14 E_0 Z_106 
Stack 19
D_7 Z_107 A_9 
