Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
G_1 B_2 Z_100 J_2 C_0 
Stack 1
I_1 E_4 H_1 E_2 Z_101 
Stack 2
D_1 I_0 E_3 F_1 G_0 
Stack 3
I_2 B_3 F_5 E_0 Z_102 
Stack 4
B_1 C_4 A_1 E_5 H_2 
Stack 5
A_0 J_1 F_2 C_3 D_3 
Stack 6
D_2 H_3 Z_103 Z_104 F_0 
Stack 7
I_3 G_2 D_4 H_0 C_1 
Stack 8
H_4 E_1 C_2 F_3 B_0 
Stack 9
G_3 D_0 J_0 D_5 F_4 
