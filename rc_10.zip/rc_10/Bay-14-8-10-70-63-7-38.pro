Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
E_2 H_2 E_6 I_4 E_3 
Stack 1
F_0 D_1 E_4 I_0 B_0 
Stack 2
D_6 D_4 D_7 B_3 J_1 
Stack 3
C_5 I_1 F_1 E_8 G_5 
Stack 4
A_1 F_7 E_7 H_4 G_4 
Stack 5
I_2 F_6 B_1 Z_100 C_2 
Stack 6
B_4 G_2 I_5 C_6 E_5 
Stack 7
J_0 Z_101 B_2 E_0 D_2 
Stack 8
C_1 G_6 E_1 Z_102 F_4 
Stack 9
G_1 H_1 H_5 H_3 A_2 
Stack 10
C_0 G_0 Z_103 Z_104 A_0 
Stack 11
C_4 D_5 D_0 H_0 J_2 
Stack 12
G_3 F_3 Z_105 Z_106 C_3 
Stack 13
F_5 F_2 G_7 D_3 I_3 
