Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
J_4 E_2 Z_100 Z_101 
Stack 1
Z_102 J_1 J_2 H_2 
Stack 2
G_5 H_4 B_4 C_0 
Stack 3
D_5 F_1 G_7 F_6 
Stack 4
C_4 H_1 H_3 G_0 
Stack 5
C_3 H_0 G_3 I_4 
Stack 6
A_3 J_3 A_0 C_2 
Stack 7
B_5 I_1 Z_103 A_4 
Stack 8
E_5 G_2 D_3 D_4 
Stack 9
E_1 A_2 D_7 A_1 
Stack 10
G_4 F_2 C_1 I_3 
Stack 11
F_5 E_4 G_1 Z_104 
Stack 12
B_1 E_0 F_4 C_5 
Stack 13
Z_105 E_6 Z_106 H_5 
Stack 14
G_6 J_0 D_6 D_0 
Stack 15
F_3 F_0 B_2 I_0 
Stack 16
E_3 D_2 B_0 
Stack 17
D_1 I_2 B_3 
