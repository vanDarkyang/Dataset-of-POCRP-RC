Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_0 A_7 C_5 B_7 
Stack 1
A_12 C_9 A_5 B_11 
Stack 2
B_0 B_12 A_8 C_8 
Stack 3
C_6 Z_100 A_14 B_3 
Stack 4
A_3 B_5 B_9 C_2 
Stack 5
B_13 A_11 Z_101 Z_102 
Stack 6
B_14 C_7 B_15 B_1 
Stack 7
Z_103 Z_104 C_4 C_3 
Stack 8
B_2 A_6 A_9 C_1 
Stack 9
B_8 A_1 B_4 A_10 
Stack 10
A_4 B_10 B_6 
Stack 11
A_0 A_13 A_2 
