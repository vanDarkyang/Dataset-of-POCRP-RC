Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
Z_100 E_5 F_5 Z_101 F_2 
Stack 1
D_3 J_3 H_4 I_3 E_6 
Stack 2
B_3 G_1 B_1 H_1 I_1 
Stack 3
C_4 D_4 A_3 Z_102 E_1 
Stack 4
D_1 C_3 D_2 Z_103 B_2 
Stack 5
C_1 D_5 E_0 D_0 J_1 
Stack 6
G_4 A_1 G_3 I_4 A_2 
Stack 7
C_2 E_3 J_2 B_4 D_6 
Stack 8
E_8 E_2 H_3 J_0 I_2 
Stack 9
F_7 H_2 A_0 Z_104 G_5 
Stack 10
B_0 E_7 I_0 Z_105 F_6 
Stack 11
F_8 C_0 B_5 G_6 F_0 
Stack 12
G_0 E_4 Z_106 F_3 G_2 
Stack 13
I_5 H_0 F_4 F_1 H_5 
