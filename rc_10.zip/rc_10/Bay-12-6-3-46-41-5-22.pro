Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_1 C_11 C_4 C_9 
Stack 1
C_6 A_3 A_9 B_5 
Stack 2
A_1 Z_100 A_11 C_5 
Stack 3
A_6 A_2 C_10 A_5 
Stack 4
B_1 C_12 Z_101 A_10 
Stack 5
B_13 B_12 A_7 B_9 
Stack 6
A_0 B_4 A_13 B_0 
Stack 7
C_7 A_4 B_8 B_10 
Stack 8
A_12 C_3 C_8 B_3 
Stack 9
Z_102 C_2 C_0 B_2 
Stack 10
Z_103 B_7 B_6 
Stack 11
B_11 A_8 Z_104 
