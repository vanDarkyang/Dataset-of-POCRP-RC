Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
O_1 B_3 A_4 A_1 J_3 F_1 
Stack 1
I_6 M_3 O_4 D_6 E_5 L_2 
Stack 2
J_8 H_8 O_2 E_0 J_2 I_8 
Stack 3
H_3 C_5 Z_100 J_4 I_7 M_2 
Stack 4
D_2 F_7 F_6 A_2 M_5 
Stack 5
G_1 H_4 J_5 H_6 M_6 
Stack 6
E_3 F_5 G_0 H_9 Z_101 
Stack 7
E_2 K_5 K_4 L_1 O_0 
Stack 8
G_4 E_1 M_0 B_1 E_6 
Stack 9
O_3 G_2 Z_102 F_8 D_4 
Stack 10
H_1 K_1 Z_103 L_3 B_2 
Stack 11
Z_104 H_0 C_2 J_7 I_3 
Stack 12
G_3 I_9 Z_105 D_0 A_0 
Stack 13
B_0 H_2 N_3 C_3 F_4 
Stack 14
J_0 I_4 G_5 F_0 Z_106 
Stack 15
C_0 N_2 D_3 E_4 L_5 
Stack 16
C_1 Z_107 I_2 M_4 H_5 
Stack 17
I_1 F_3 J_6 D_5 D_1 
Stack 18
Z_108 Z_109 B_4 M_1 N_4 
Stack 19
L_7 J_1 C_4 L_6 F_2 
Stack 20
N_0 K_6 H_7 Z_110 K_0 
Stack 21
I_0 L_4 I_5 Z_111 B_5 
Stack 22
K_3 A_3 L_0 K_7 K_2 
Stack 23
N_5 N_1 G_6 H_10 Z_112 
