Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
A_1 Z_100 G_6 I_1 A_3 
Stack 1
B_2 D_0 G_2 H_6 Z_101 
Stack 2
C_3 J_4 A_4 E_0 C_4 
Stack 3
C_5 I_2 E_3 Z_102 H_4 
Stack 4
J_2 F_3 I_4 C_0 B_4 
Stack 5
H_5 E_4 D_6 G_5 G_0 
Stack 6
B_3 J_3 I_3 A_2 D_1 
Stack 7
Z_103 A_0 F_2 C_2 D_2 
Stack 8
Z_104 F_4 B_5 F_5 J_0 
Stack 9
E_5 F_6 F_0 H_0 E_1 
Stack 10
Z_105 I_0 D_5 H_2 J_1 
Stack 11
F_1 B_0 C_1 B_1 G_4 
Stack 12
D_4 H_3 G_1 E_6 D_3 
Stack 13
G_3 H_1 Z_106 I_5 E_2 
