Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
A_1 E_4 Z_100 D_0 Z_101 
Stack 1
B_0 B_3 E_6 F_4 I_4 
Stack 2
D_4 C_3 A_0 G_7 C_4 
Stack 3
D_3 F_2 J_0 Z_102 A_2 
Stack 4
E_0 A_3 E_3 A_4 C_2 
Stack 5
F_3 Z_103 F_5 J_1 I_3 
Stack 6
G_0 H_2 E_5 G_1 G_4 
Stack 7
H_6 I_1 Z_104 B_2 D_2 
Stack 8
I_0 J_3 H_0 H_3 J_2 
Stack 9
Z_105 B_1 F_6 F_0 G_3 
Stack 10
E_2 C_1 C_0 F_1 D_5 
Stack 11
Z_106 G_2 G_5 E_7 B_4 
Stack 12
H_4 I_2 B_5 G_6 H_5 
Stack 13
E_1 C_5 D_1 H_1 F_7 
