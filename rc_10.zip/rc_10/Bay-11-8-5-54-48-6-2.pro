Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_6 A_3 C_8 E_8 Z_100 
Stack 1
Z_101 D_0 A_9 B_8 E_6 
Stack 2
E_1 B_0 C_6 D_5 Z_102 
Stack 3
A_6 D_7 A_5 E_2 E_4 
Stack 4
D_8 B_3 B_7 D_3 B_2 
Stack 5
Z_103 A_2 A_0 A_1 D_2 
Stack 6
Z_104 Z_105 A_7 B_4 D_1 
Stack 7
C_2 B_1 C_7 C_4 B_6 
Stack 8
C_3 D_9 E_3 C_0 B_5 
Stack 9
A_8 C_1 A_4 E_5 E_7 
Stack 10
C_5 E_0 D_4 C_9 
