Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
Z_100 D_1 B_7 C_6 D_11 C_11 
Stack 1
C_12 A_13 E_4 C_5 B_5 B_10 
Stack 2
Z_101 A_1 B_11 B_4 C_3 E_3 
Stack 3
A_0 Z_102 A_9 A_10 D_12 A_6 
Stack 4
E_5 E_2 B_1 C_4 E_7 
Stack 5
B_8 C_1 D_5 Z_103 Z_104 
Stack 6
D_6 A_11 D_13 D_3 A_4 
Stack 7
Z_105 A_8 E_8 C_9 E_10 
Stack 8
D_8 B_3 A_5 D_7 E_11 
Stack 9
B_9 C_10 E_13 C_7 E_14 
Stack 10
B_0 Z_106 D_10 A_7 A_12 
Stack 11
A_14 D_15 C_2 D_14 A_3 
Stack 12
E_1 D_2 C_0 D_4 E_0 
Stack 13
A_2 E_6 E_9 Z_107 E_12 
Stack 14
B_2 D_0 D_9 B_6 C_8 
