Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_8 C_0 Z_100 C_5 
Stack 1
D_9 B_0 D_0 B_1 
Stack 2
C_3 B_3 B_4 E_2 
Stack 3
A_9 C_7 D_8 B_9 
Stack 4
C_4 B_2 D_6 Z_101 
Stack 5
Z_102 E_6 A_6 E_4 
Stack 6
E_1 Z_103 E_3 E_5 
Stack 7
D_1 Z_104 B_6 B_7 
Stack 8
D_4 E_7 A_2 D_5 
Stack 9
A_5 B_8 E_9 C_6 
Stack 10
A_7 A_1 E_8 C_2 
Stack 11
C_1 A_4 D_3 D_7 
Stack 12
D_2 A_3 A_0 
Stack 13
Z_105 B_5 E_0 
