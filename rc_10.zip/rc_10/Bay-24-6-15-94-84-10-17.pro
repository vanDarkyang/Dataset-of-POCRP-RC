Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
K_3 G_6 L_0 I_6 
Stack 1
B_2 E_5 J_1 O_2 
Stack 2
G_2 Z_100 I_4 E_0 
Stack 3
D_2 I_0 I_5 C_4 
Stack 4
A_1 I_2 D_0 J_5 
Stack 5
K_2 C_2 F_5 E_2 
Stack 6
Z_101 F_0 K_5 D_1 
Stack 7
G_5 Z_102 O_0 H_4 
Stack 8
C_1 I_1 N_2 L_2 
Stack 9
I_3 L_1 M_0 Z_103 
Stack 10
L_5 I_8 G_3 H_6 
Stack 11
J_3 M_2 L_3 I_7 
Stack 12
E_3 J_4 M_1 G_0 
Stack 13
K_4 O_1 G_4 H_5 
Stack 14
K_1 H_2 D_4 A_0 
Stack 15
D_3 J_2 Z_104 K_0 
Stack 16
F_1 Z_105 L_4 C_3 
Stack 17
E_4 J_0 J_7 H_1 
Stack 18
G_1 Z_106 C_0 Z_107 
Stack 19
Z_108 F_4 M_4 H_0 
Stack 20
N_3 B_1 E_1 N_0 
Stack 21
Z_109 K_6 F_6 F_2 
Stack 22
B_0 H_3 F_3 
Stack 23
M_3 J_6 N_1 
