Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
B_12 E_9 D_3 B_14 Z_100 B_11 
Stack 1
E_1 D_8 A_12 Z_101 D_11 B_0 
Stack 2
A_10 B_5 A_9 D_5 Z_102 D_12 
Stack 3
C_12 B_8 A_1 C_0 E_6 B_4 
Stack 4
A_14 E_8 D_10 A_11 C_11 
Stack 5
Z_103 C_14 A_6 C_5 A_5 
Stack 6
B_10 C_8 C_6 C_3 D_13 
Stack 7
D_7 E_3 D_6 D_9 Z_104 
Stack 8
B_2 C_2 A_2 D_14 A_3 
Stack 9
Z_105 E_4 C_13 C_4 D_1 
Stack 10
A_7 Z_106 A_0 B_6 B_13 
Stack 11
C_9 C_1 A_8 D_4 B_9 
Stack 12
A_4 D_0 E_10 E_0 B_3 
Stack 13
E_5 E_2 Z_107 E_7 C_7 
Stack 14
B_1 C_10 B_7 A_13 D_2 
