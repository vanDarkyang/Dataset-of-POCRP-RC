Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
Z_100 C_3 G_6 G_2 D_6 G_5 
Stack 1
B_0 F_11 Z_101 D_10 C_0 E_0 
Stack 2
B_5 A_5 H_8 F_8 D_0 I_8 
Stack 3
C_2 A_8 I_7 J_4 G_11 B_8 
Stack 4
F_6 Z_102 G_10 H_7 H_9 J_3 
Stack 5
A_2 Z_103 E_10 D_8 G_1 
Stack 6
H_10 F_3 J_1 C_1 J_6 
Stack 7
C_6 H_3 A_0 D_5 F_2 
Stack 8
G_4 G_7 I_3 D_1 C_7 
Stack 9
G_8 A_1 C_4 J_5 B_3 
Stack 10
Z_104 G_9 B_6 D_4 B_4 
Stack 11
A_3 D_7 I_0 D_12 F_4 
Stack 12
D_2 F_0 Z_105 F_5 C_9 
Stack 13
F_1 H_6 Z_106 Z_107 H_0 
Stack 14
I_4 A_4 E_2 Z_108 E_11 
Stack 15
Z_109 E_4 A_6 D_11 I_1 
Stack 16
A_7 F_10 C_10 I_2 J_2 
Stack 17
Z_110 C_5 E_1 E_3 F_7 
Stack 18
H_2 H_1 D_3 I_6 E_8 
Stack 19
C_8 B_9 E_9 H_5 B_2 
Stack 20
A_9 G_0 J_0 G_3 E_7 
Stack 21
E_12 I_5 B_1 B_7 D_9 
Stack 22
E_5 F_9 Z_111 H_4 E_6 
