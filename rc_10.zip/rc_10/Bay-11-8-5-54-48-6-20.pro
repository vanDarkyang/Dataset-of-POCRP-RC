Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_7 D_6 B_3 D_9 D_2 
Stack 1
Z_100 D_1 B_2 C_6 C_4 
Stack 2
A_1 B_1 E_2 A_0 C_2 
Stack 3
E_5 E_3 E_8 Z_101 D_8 
Stack 4
B_6 A_5 A_4 A_2 D_4 
Stack 5
C_11 B_10 B_5 A_3 D_5 
Stack 6
B_7 D_7 C_5 D_3 C_7 
Stack 7
E_6 C_10 E_0 E_1 Z_102 
Stack 8
B_8 B_9 Z_103 C_0 B_0 
Stack 9
C_8 C_3 D_0 B_4 E_4 
Stack 10
C_9 Z_104 Z_105 C_1 
