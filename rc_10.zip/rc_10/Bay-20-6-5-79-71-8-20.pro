Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
Z_100 A_8 D_0 C_11 
Stack 1
A_13 B_1 C_5 A_4 
Stack 2
A_0 E_5 D_3 D_6 
Stack 3
B_10 D_5 E_12 C_1 
Stack 4
B_0 D_1 D_2 E_8 
Stack 5
B_13 E_3 C_10 C_13 
Stack 6
A_7 B_11 C_7 A_5 
Stack 7
A_12 D_13 A_10 D_4 
Stack 8
D_7 C_12 A_9 Z_101 
Stack 9
Z_102 B_12 E_9 E_0 
Stack 10
A_1 C_9 A_2 Z_103 
Stack 11
C_2 B_7 D_11 Z_104 
Stack 12
B_2 E_13 B_3 C_14 
Stack 13
B_4 Z_105 E_2 C_6 
Stack 14
B_8 C_0 B_9 C_8 
Stack 15
A_11 D_10 Z_106 C_4 
Stack 16
A_3 B_5 E_10 C_3 
Stack 17
E_6 E_1 D_12 E_7 
Stack 18
E_4 A_6 Z_107 E_11 
Stack 19
B_6 D_9 D_8 
