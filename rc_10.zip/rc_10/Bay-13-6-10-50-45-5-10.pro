Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_1 I_2 E_5 B_2 
Stack 1
C_3 E_0 H_1 I_3 
Stack 2
B_3 G_2 G_0 G_1 
Stack 3
D_4 F_0 F_3 I_0 
Stack 4
C_0 J_2 F_2 G_3 
Stack 5
B_1 D_1 A_0 H_0 
Stack 6
J_1 E_1 I_1 C_1 
Stack 7
A_2 B_0 Z_100 D_2 
Stack 8
D_3 Z_101 D_0 F_4 
Stack 9
F_1 H_2 F_5 F_6 
Stack 10
E_3 Z_102 E_2 E_4 
Stack 11
G_4 G_5 Z_103 
Stack 12
C_2 J_0 Z_104 
