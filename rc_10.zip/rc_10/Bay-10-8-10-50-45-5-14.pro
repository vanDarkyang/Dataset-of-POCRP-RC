Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
G_4 F_5 I_0 G_3 F_3 
Stack 1
E_0 D_3 H_3 D_4 I_2 
Stack 2
A_2 H_2 Z_100 B_2 E_5 
Stack 3
C_1 C_0 Z_101 H_1 F_2 
Stack 4
G_2 F_0 D_2 E_4 J_1 
Stack 5
F_4 A_1 F_1 G_5 E_6 
Stack 6
D_0 C_3 A_0 Z_102 B_1 
Stack 7
C_2 F_6 E_2 J_0 D_1 
Stack 8
Z_103 H_0 I_1 E_3 G_0 
Stack 9
G_1 Z_104 E_1 B_0 J_2 
