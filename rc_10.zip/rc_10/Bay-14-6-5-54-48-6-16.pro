Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_1 D_4 D_5 E_0 
Stack 1
D_2 C_7 C_2 B_7 
Stack 2
E_5 Z_100 Z_101 E_4 
Stack 3
C_10 E_7 B_1 D_1 
Stack 4
C_8 B_2 Z_102 C_4 
Stack 5
B_9 D_0 A_8 B_3 
Stack 6
C_6 C_0 Z_103 Z_104 
Stack 7
A_7 A_5 A_6 B_8 
Stack 8
E_8 B_0 A_2 B_4 
Stack 9
D_6 D_8 C_9 A_3 
Stack 10
E_3 A_4 E_1 A_0 
Stack 11
C_5 D_3 E_6 B_5 
Stack 12
Z_105 C_3 E_2 
Stack 13
B_6 D_7 C_1 
