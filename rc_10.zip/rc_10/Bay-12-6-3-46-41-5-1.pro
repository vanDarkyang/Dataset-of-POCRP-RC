Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_3 Z_100 A_10 A_7 
Stack 1
A_13 A_4 C_11 A_6 
Stack 2
A_1 C_1 Z_101 A_5 
Stack 3
Z_102 B_4 A_2 B_8 
Stack 4
Z_103 C_8 C_4 B_1 
Stack 5
B_7 A_8 A_0 A_12 
Stack 6
B_13 B_6 C_9 C_6 
Stack 7
B_12 C_3 A_11 B_5 
Stack 8
B_2 C_0 B_0 Z_104 
Stack 9
A_9 C_2 C_5 B_9 
Stack 10
A_3 B_10 C_7 
Stack 11
C_12 B_11 C_10 
