Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_5 A_12 A_5 B_8 
Stack 1
B_7 A_7 B_1 B_0 
Stack 2
A_4 A_1 C_8 C_7 
Stack 3
A_0 B_2 C_13 B_12 
Stack 4
A_10 C_3 B_9 C_6 
Stack 5
B_3 B_13 A_6 Z_100 
Stack 6
C_12 C_5 C_10 A_3 
Stack 7
Z_101 B_6 B_4 C_1 
Stack 8
C_11 B_11 Z_102 Z_103 
Stack 9
A_2 A_9 B_10 C_2 
Stack 10
Z_104 C_0 C_9 
Stack 11
A_11 C_4 A_8 
