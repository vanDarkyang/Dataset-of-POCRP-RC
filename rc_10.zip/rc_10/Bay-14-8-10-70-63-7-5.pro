Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
J_3 Z_100 H_2 A_1 H_5 
Stack 1
C_4 F_0 G_4 D_4 H_1 
Stack 2
H_4 A_0 D_0 E_2 G_5 
Stack 3
G_6 H_0 C_2 C_3 B_2 
Stack 4
C_5 F_6 G_3 Z_101 E_3 
Stack 5
E_4 B_0 J_2 G_2 F_4 
Stack 6
A_2 D_6 E_1 A_4 Z_102 
Stack 7
E_6 G_1 B_1 E_7 D_1 
Stack 8
C_0 F_2 Z_103 D_3 J_1 
Stack 9
I_4 F_3 E_5 J_0 F_5 
Stack 10
Z_104 F_1 I_5 D_7 E_0 
Stack 11
C_1 G_0 I_1 F_7 B_4 
Stack 12
Z_105 B_3 A_3 I_3 I_0 
Stack 13
D_5 I_2 Z_106 H_3 D_2 
