Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
Z_100 Z_101 A_2 A_4 
Stack 1
B_8 Z_102 E_9 A_5 
Stack 2
C_3 C_4 D_4 Z_103 
Stack 3
A_7 E_0 C_9 Z_104 
Stack 4
B_0 E_8 B_6 D_0 
Stack 5
A_3 E_5 E_4 D_9 
Stack 6
C_5 C_7 A_0 D_8 
Stack 7
D_2 C_1 C_6 B_1 
Stack 8
D_6 D_3 B_3 B_4 
Stack 9
E_1 Z_105 D_5 E_3 
Stack 10
E_7 A_1 B_5 C_8 
Stack 11
C_2 B_2 A_8 D_1 
Stack 12
D_7 A_6 E_6 
Stack 13
C_0 E_2 B_7 
