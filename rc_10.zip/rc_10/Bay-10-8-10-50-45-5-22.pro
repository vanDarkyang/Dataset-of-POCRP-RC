Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_0 C_1 D_1 F_2 F_3 
Stack 1
H_2 I_0 E_3 F_6 D_2 
Stack 2
B_1 B_0 H_1 F_5 A_2 
Stack 3
F_1 Z_100 Z_101 H_0 J_0 
Stack 4
B_2 F_4 I_1 G_1 G_3 
Stack 5
H_3 E_1 Z_102 G_2 A_1 
Stack 6
E_2 E_4 D_0 Z_103 D_4 
Stack 7
C_0 Z_104 I_3 E_6 E_0 
Stack 8
B_3 D_3 I_2 C_3 C_2 
Stack 9
G_0 C_4 J_1 F_0 E_5 
