Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
D_1 E_4 A_0 A_1 
Stack 1
D_0 Z_100 G_2 H_4 
Stack 2
H_0 E_0 F_4 Z_101 
Stack 3
F_3 I_1 J_0 D_5 
Stack 4
C_0 G_0 C_3 I_2 
Stack 5
Z_102 C_2 G_4 Z_103 
Stack 6
D_3 J_1 H_2 J_2 
Stack 7
E_5 E_1 Z_104 C_1 
Stack 8
G_3 F_1 E_3 I_0 
Stack 9
B_0 B_2 B_3 G_1 
Stack 10
F_0 D_2 B_1 F_5 
Stack 11
E_2 F_2 H_1 
Stack 12
D_4 H_3 F_6 
