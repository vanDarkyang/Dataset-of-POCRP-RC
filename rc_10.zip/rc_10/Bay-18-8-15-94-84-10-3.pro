Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
N_0 C_1 D_3 H_8 E_4 G_0 
Stack 1
F_1 H_5 H_7 G_6 M_3 C_2 
Stack 2
Z_100 L_3 M_1 L_2 Z_101 H_0 
Stack 3
E_5 B_3 D_2 K_0 Z_102 B_0 
Stack 4
C_3 F_5 K_2 O_2 F_2 
Stack 5
G_1 H_3 N_1 D_4 J_5 
Stack 6
G_4 B_1 I_6 J_0 E_3 
Stack 7
Z_103 M_0 K_1 L_5 H_6 
Stack 8
O_1 F_0 E_2 F_4 B_2 
Stack 9
F_6 L_1 I_2 K_5 Z_104 
Stack 10
J_4 I_0 I_3 Z_105 F_7 
Stack 11
K_6 E_0 I_5 L_4 I_4 
Stack 12
Z_106 G_2 L_0 I_1 E_1 
Stack 13
A_0 G_7 J_1 G_3 H_1 
Stack 14
N_2 J_3 Z_107 F_3 H_4 
Stack 15
G_5 M_2 H_9 O_0 D_1 
Stack 16
D_0 H_2 J_2 A_1 C_0 
Stack 17
N_3 K_4 Z_108 K_3 Z_109 
