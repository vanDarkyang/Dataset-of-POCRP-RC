Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
H_2 Z_100 I_1 E_0 B_2 
Stack 1
E_4 F_3 F_2 D_1 F_6 
Stack 2
C_0 I_2 G_3 G_4 J_2 
Stack 3
B_0 E_3 B_3 A_0 E_1 
Stack 4
D_2 G_2 B_1 J_0 Z_101 
Stack 5
F_5 I_0 G_0 G_1 E_6 
Stack 6
Z_102 C_1 I_3 H_3 C_2 
Stack 7
H_0 C_3 D_0 E_2 C_4 
Stack 8
Z_103 Z_104 E_5 D_3 H_1 
Stack 9
F_4 F_0 A_1 J_1 F_1 
