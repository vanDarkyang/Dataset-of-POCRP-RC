Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_0 E_3 D_1 A_2 E_2 
Stack 1
B_0 J_1 I_3 B_1 F_4 
Stack 2
Z_100 F_5 C_0 G_2 F_3 
Stack 3
J_0 F_2 E_4 I_0 F_6 
Stack 4
E_1 D_3 Z_101 F_1 E_5 
Stack 5
G_3 G_5 A_1 D_2 G_4 
Stack 6
D_5 H_1 H_0 G_1 I_1 
Stack 7
D_0 A_0 D_4 C_3 H_3 
Stack 8
Z_102 Z_103 C_2 C_1 J_2 
Stack 9
H_2 F_0 I_2 Z_104 G_0 
