Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_6 F_6 Z_100 E_5 
Stack 1
J_1 I_3 H_0 E_4 
Stack 2
F_4 G_1 F_5 A_2 
Stack 3
D_1 D_5 D_4 C_0 
Stack 4
E_0 D_0 H_3 F_0 
Stack 5
C_3 B_1 E_3 D_2 
Stack 6
F_1 E_1 J_0 C_2 
Stack 7
C_1 I_0 Z_101 G_0 
Stack 8
Z_102 A_0 F_3 Z_103 
Stack 9
J_2 B_2 H_2 B_0 
Stack 10
F_2 B_3 H_1 D_3 
Stack 11
G_2 Z_104 E_2 
Stack 12
A_1 I_2 I_1 
