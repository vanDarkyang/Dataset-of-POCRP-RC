Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_1 B_1 F_3 C_2 
Stack 1
Z_100 D_4 J_0 B_5 
Stack 2
A_4 Z_101 C_3 A_3 
Stack 3
E_7 I_0 D_0 Z_102 
Stack 4
E_6 F_5 I_3 E_3 
Stack 5
I_1 G_3 D_5 E_1 
Stack 6
G_0 G_5 A_1 E_8 
Stack 7
B_2 E_2 H_5 J_1 
Stack 8
D_2 G_1 F_1 E_4 
Stack 9
Z_103 F_0 C_0 E_0 
Stack 10
G_2 B_4 G_7 J_2 
Stack 11
H_1 A_2 C_4 E_5 
Stack 12
H_6 Z_104 G_4 G_6 
Stack 13
F_2 H_0 A_0 F_8 
Stack 14
D_1 H_2 D_6 I_2 
Stack 15
D_3 B_0 Z_105 H_4 
Stack 16
F_4 F_6 Z_106 
Stack 17
B_3 F_7 H_3 
