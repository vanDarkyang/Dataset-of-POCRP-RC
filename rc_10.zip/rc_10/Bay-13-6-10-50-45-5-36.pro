Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_1 F_1 E_5 J_0 
Stack 1
B_2 Z_100 D_2 Z_101 
Stack 2
G_3 I_0 I_2 F_5 
Stack 3
D_1 C_0 A_1 G_4 
Stack 4
F_0 Z_102 J_1 H_0 
Stack 5
C_4 F_4 D_4 E_4 
Stack 6
G_1 E_3 E_1 D_5 
Stack 7
Z_103 H_1 C_3 G_2 
Stack 8
C_2 F_6 G_0 B_1 
Stack 9
G_5 E_2 A_0 F_3 
Stack 10
B_0 I_3 E_6 E_0 
Stack 11
I_1 F_2 Z_104 
Stack 12
D_0 D_3 A_2 
