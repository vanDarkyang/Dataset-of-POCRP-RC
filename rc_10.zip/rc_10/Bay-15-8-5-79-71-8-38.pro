Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
Z_100 A_0 D_12 D_2 B_12 E_4 
Stack 1
Z_101 E_1 E_8 A_11 B_11 C_4 
Stack 2
Z_102 B_0 B_10 E_7 E_2 E_11 
Stack 3
Z_103 A_3 A_8 D_4 B_9 C_10 
Stack 4
Z_104 A_7 D_14 D_13 Z_105 
Stack 5
A_6 D_9 A_12 B_5 B_8 
Stack 6
A_5 C_5 C_0 B_4 E_5 
Stack 7
E_0 E_10 D_10 D_0 C_3 
Stack 8
A_13 B_2 E_9 D_6 Z_106 
Stack 9
A_10 D_1 B_3 C_1 D_3 
Stack 10
E_6 A_4 B_6 B_13 C_14 
Stack 11
D_11 C_8 D_8 C_12 A_2 
Stack 12
C_9 C_13 C_11 D_7 B_1 
Stack 13
C_6 D_15 C_7 A_9 C_2 
Stack 14
Z_107 D_5 A_1 E_3 B_7 
