Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_0 C_1 C_4 D_5 C_6 
Stack 1
E_8 E_0 C_0 B_1 Z_100 
Stack 2
A_3 B_4 D_7 B_2 Z_101 
Stack 3
B_3 C_2 Z_102 E_1 C_8 
Stack 4
A_9 E_7 B_8 A_8 A_7 
Stack 5
Z_103 D_2 A_6 E_2 C_7 
Stack 6
D_6 A_1 A_2 A_0 B_5 
Stack 7
D_3 A_4 C_3 D_1 B_7 
Stack 8
E_4 B_9 E_3 E_5 C_5 
Stack 9
B_0 Z_104 A_5 B_6 Z_105 
Stack 10
C_9 E_9 D_4 E_6 
