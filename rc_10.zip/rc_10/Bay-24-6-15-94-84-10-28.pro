Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 G_0 I_4 E_3 
Stack 1
G_7 F_1 J_5 J_0 
Stack 2
E_0 I_1 G_5 H_1 
Stack 3
J_6 K_3 L_4 L_2 
Stack 4
D_0 L_5 Z_101 G_1 
Stack 5
I_2 H_2 K_5 Z_102 
Stack 6
E_5 G_6 D_1 K_2 
Stack 7
G_4 H_4 Z_103 J_4 
Stack 8
K_0 H_5 C_2 D_2 
Stack 9
H_8 O_1 E_4 J_2 
Stack 10
L_3 C_1 Z_104 Z_105 
Stack 11
N_1 K_6 F_2 C_4 
Stack 12
I_6 I_0 D_3 H_6 
Stack 13
F_4 I_3 O_0 Z_106 
Stack 14
N_2 M_2 A_0 H_7 
Stack 15
B_1 J_3 G_8 O_2 
Stack 16
M_3 E_2 H_0 I_5 
Stack 17
Z_107 M_4 F_5 B_0 
Stack 18
H_3 Z_108 E_6 G_2 
Stack 19
L_0 B_3 G_3 Z_109 
Stack 20
F_3 L_1 K_1 C_0 
Stack 21
M_1 E_1 K_4 M_0 
Stack 22
F_6 N_0 J_1 
Stack 23
F_0 C_3 B_2 
