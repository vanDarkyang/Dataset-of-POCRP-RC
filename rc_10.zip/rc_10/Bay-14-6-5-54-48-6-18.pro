Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_5 A_2 Z_100 A_1 
Stack 1
E_9 D_1 D_5 D_7 
Stack 2
A_8 Z_101 C_6 C_0 
Stack 3
E_5 D_4 Z_102 A_6 
Stack 4
C_2 A_7 C_4 C_8 
Stack 5
A_4 A_0 E_3 D_6 
Stack 6
Z_103 B_0 C_7 E_7 
Stack 7
Z_104 C_10 C_1 E_6 
Stack 8
B_3 A_5 D_0 Z_105 
Stack 9
E_8 E_0 B_7 E_2 
Stack 10
C_3 D_8 B_5 B_6 
Stack 11
B_4 C_9 D_2 D_3 
Stack 12
B_2 B_8 E_4 
Stack 13
A_3 E_1 B_1 
