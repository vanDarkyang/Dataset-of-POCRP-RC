Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
E_2 E_10 H_9 G_9 C_9 E_1 
Stack 1
B_8 F_9 C_0 J_6 B_7 Z_100 
Stack 2
G_6 I_0 B_4 D_5 H_8 F_12 
Stack 3
D_6 H_3 I_2 E_6 H_2 A_5 
Stack 4
J_1 E_3 D_3 F_1 H_6 J_2 
Stack 5
F_13 H_4 D_1 F_7 Z_101 
Stack 6
B_9 H_0 G_2 Z_102 H_5 
Stack 7
B_0 D_4 J_5 Z_103 D_12 
Stack 8
B_5 D_11 D_9 A_0 F_0 
Stack 9
C_3 A_7 Z_104 A_8 D_0 
Stack 10
F_6 C_5 E_8 A_4 B_6 
Stack 11
B_3 G_4 J_4 B_2 Z_105 
Stack 12
E_4 E_7 E_9 I_5 Z_106 
Stack 13
G_10 E_5 H_1 G_7 D_8 
Stack 14
E_0 C_7 I_4 J_7 C_10 
Stack 15
J_0 C_1 C_8 I_7 C_4 
Stack 16
D_7 D_2 Z_107 F_5 F_8 
Stack 17
F_2 G_0 F_3 I_6 C_6 
Stack 18
I_1 I_3 Z_108 G_8 J_3 
Stack 19
H_7 H_10 G_3 F_11 Z_109 
Stack 20
F_10 F_4 D_10 G_1 A_3 
Stack 21
C_2 B_1 Z_110 Z_111 G_11 
Stack 22
A_2 G_5 A_6 J_8 A_1 
