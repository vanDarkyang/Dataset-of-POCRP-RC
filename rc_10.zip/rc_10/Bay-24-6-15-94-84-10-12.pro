Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
G_5 Z_100 L_3 D_5 
Stack 1
Z_101 F_2 E_2 L_2 
Stack 2
K_3 H_0 Z_102 H_5 
Stack 3
N_0 Z_103 I_3 J_5 
Stack 4
A_1 Z_104 I_2 L_4 
Stack 5
D_1 G_6 G_3 D_2 
Stack 6
Z_105 L_5 G_7 G_4 
Stack 7
Z_106 B_2 Z_107 H_7 
Stack 8
C_4 F_4 K_5 C_0 
Stack 9
A_2 H_6 E_4 I_1 
Stack 10
O_2 N_2 K_6 J_7 
Stack 11
A_0 G_0 M_1 B_1 
Stack 12
E_3 G_2 K_4 I_7 
Stack 13
J_4 D_0 N_3 B_3 
Stack 14
I_0 J_2 H_4 H_2 
Stack 15
H_3 F_3 E_0 I_4 
Stack 16
K_2 I_5 J_6 Z_108 
Stack 17
C_3 C_1 M_3 K_1 
Stack 18
J_3 I_6 G_1 M_0 
Stack 19
H_1 J_1 M_2 C_2 
Stack 20
F_0 B_0 D_3 L_1 
Stack 21
Z_109 O_0 O_1 D_4 
Stack 22
E_1 K_0 L_0 
Stack 23
F_1 N_1 J_0 
