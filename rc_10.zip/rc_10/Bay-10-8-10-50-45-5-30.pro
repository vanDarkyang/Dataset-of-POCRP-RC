Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_4 E_1 C_0 D_0 C_2 
Stack 1
Z_100 D_4 C_1 F_5 I_0 
Stack 2
J_2 I_1 J_1 F_2 E_2 
Stack 3
H_1 Z_101 Z_102 D_2 G_5 
Stack 4
D_1 E_0 F_1 G_4 A_1 
Stack 5
I_3 B_2 A_0 J_0 F_0 
Stack 6
F_4 G_2 G_1 D_3 B_1 
Stack 7
G_3 D_5 E_3 G_0 H_0 
Stack 8
C_3 F_3 Z_103 I_2 A_2 
Stack 9
H_2 Z_104 H_3 H_4 B_0 
