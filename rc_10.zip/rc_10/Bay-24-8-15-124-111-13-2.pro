Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
F_2 K_3 M_5 L_3 M_1 E_2 
Stack 1
G_8 E_1 L_0 H_8 I_6 F_5 
Stack 2
Z_100 I_9 L_4 C_4 I_4 H_1 
Stack 3
C_6 G_2 H_5 M_4 I_5 G_10 
Stack 4
J_1 G_1 Z_101 O_1 D_4 
Stack 5
Z_102 A_1 D_6 D_3 I_3 
Stack 6
E_0 A_4 I_2 I_8 J_4 
Stack 7
O_0 Z_103 H_7 E_5 G_6 
Stack 8
I_7 Z_104 H_9 K_8 A_0 
Stack 9
H_3 G_4 B_1 Z_105 L_2 
Stack 10
I_1 E_7 L_1 C_5 O_2 
Stack 11
A_2 F_6 M_3 B_4 Z_106 
Stack 12
L_6 Z_107 D_5 M_2 G_9 
Stack 13
E_4 O_4 N_2 E_8 C_2 
Stack 14
F_1 I_0 B_0 M_0 K_1 
Stack 15
F_4 J_3 D_7 L_5 J_5 
Stack 16
K_6 B_2 H_6 F_3 Z_108 
Stack 17
H_2 H_0 N_3 E_3 D_2 
Stack 18
C_0 K_5 Z_109 H_4 K_4 
Stack 19
Z_110 A_3 G_0 D_0 K_2 
Stack 20
G_7 J_0 N_4 Z_111 F_0 
Stack 21
K_0 O_3 N_0 C_3 K_7 
Stack 22
G_5 F_7 G_3 J_2 E_6 
Stack 23
Z_112 D_1 B_3 N_1 C_1 
