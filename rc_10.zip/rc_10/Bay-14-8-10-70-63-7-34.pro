Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
J_1 F_2 F_5 G_5 A_4 
Stack 1
E_0 G_2 B_2 C_3 B_5 
Stack 2
D_4 E_5 A_2 E_2 Z_100 
Stack 3
G_1 A_1 G_0 Z_101 D_5 
Stack 4
A_0 F_7 F_1 H_4 C_2 
Stack 5
F_4 F_8 D_3 B_3 Z_102 
Stack 6
C_0 E_6 G_4 H_3 E_1 
Stack 7
C_5 Z_103 B_1 C_1 J_3 
Stack 8
D_0 I_0 D_2 D_6 H_0 
Stack 9
G_3 J_0 B_4 F_3 F_0 
Stack 10
F_6 E_8 I_2 H_1 Z_104 
Stack 11
E_4 C_4 E_7 D_1 Z_105 
Stack 12
A_3 I_3 H_5 J_4 B_0 
Stack 13
J_2 E_3 I_1 H_2 Z_106 
