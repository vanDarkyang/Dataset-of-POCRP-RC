Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
K_5 F_2 Z_100 G_5 N_2 Z_101 
Stack 1
J_0 Z_102 H_0 L_5 I_0 L_2 
Stack 2
J_7 Z_103 I_8 F_1 M_2 D_4 
Stack 3
J_4 K_2 D_0 A_0 Z_104 B_0 
Stack 4
C_1 E_3 M_1 C_4 N_0 
Stack 5
H_6 I_5 G_1 K_1 L_3 
Stack 6
E_0 I_6 O_2 B_1 I_1 
Stack 7
I_7 H_2 D_2 Z_105 H_7 
Stack 8
F_3 F_4 B_2 E_2 I_3 
Stack 9
F_6 J_1 N_3 Z_106 C_0 
Stack 10
G_6 A_1 Z_107 J_3 C_3 
Stack 11
C_2 M_3 J_6 K_0 A_2 
Stack 12
H_4 H_5 G_2 K_3 N_1 
Stack 13
D_5 O_0 G_3 J_5 I_4 
Stack 14
Z_108 L_4 F_0 D_1 F_5 
Stack 15
D_3 K_4 J_2 G_0 G_4 
Stack 16
E_1 M_0 L_1 E_4 Z_109 
Stack 17
L_0 O_1 H_3 H_1 I_2 
