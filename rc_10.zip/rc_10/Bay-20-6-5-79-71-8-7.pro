Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_3 Z_100 D_15 D_14 
Stack 1
Z_101 C_6 B_11 E_0 
Stack 2
A_9 Z_102 B_13 Z_103 
Stack 3
E_6 D_3 C_9 E_9 
Stack 4
B_12 B_8 C_10 E_7 
Stack 5
B_7 B_10 B_5 B_1 
Stack 6
D_1 E_12 E_8 D_9 
Stack 7
D_12 B_4 A_10 A_2 
Stack 8
B_3 E_3 Z_104 A_11 
Stack 9
B_6 C_3 Z_105 C_0 
Stack 10
C_13 D_8 E_5 Z_106 
Stack 11
B_9 D_2 D_13 E_4 
Stack 12
C_11 A_1 A_7 A_6 
Stack 13
E_1 A_8 D_6 E_2 
Stack 14
B_0 D_5 Z_107 D_4 
Stack 15
D_11 D_10 C_8 A_0 
Stack 16
D_0 E_10 C_7 E_11 
Stack 17
C_14 C_1 B_14 C_5 
Stack 18
D_7 C_12 C_2 A_4 
Stack 19
B_2 A_5 C_4 
