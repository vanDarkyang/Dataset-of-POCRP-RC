Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_0 D_8 A_2 A_12 B_11 D_10 
Stack 1
E_4 A_10 A_8 A_7 Z_100 C_13 
Stack 2
B_10 C_15 B_8 D_13 C_12 E_5 
Stack 3
B_7 E_8 E_1 A_11 C_8 D_14 
Stack 4
C_14 E_6 C_10 D_0 C_1 
Stack 5
E_10 B_9 E_7 E_2 Z_101 
Stack 6
D_6 B_12 C_2 E_3 Z_102 
Stack 7
D_15 C_7 A_0 B_5 B_1 
Stack 8
A_1 Z_103 B_0 D_9 E_11 
Stack 9
C_16 C_9 C_11 A_6 D_3 
Stack 10
D_11 D_2 C_3 Z_104 A_9 
Stack 11
A_4 E_9 D_4 D_7 A_3 
Stack 12
Z_105 B_6 D_12 D_1 B_2 
Stack 13
C_5 B_4 Z_106 C_6 E_0 
Stack 14
A_5 Z_107 C_4 B_3 D_5 
