Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
A_1 L_2 J_9 J_3 O_0 J_5 
Stack 1
K_7 Z_100 G_0 I_9 G_8 D_6 
Stack 2
F_5 C_5 M_0 E_6 Z_101 C_2 
Stack 3
J_7 I_8 E_7 K_0 M_4 H_0 
Stack 4
N_2 G_6 L_0 L_5 B_1 
Stack 5
H_1 G_4 Z_102 J_1 E_5 
Stack 6
I_1 H_4 E_4 J_8 J_2 
Stack 7
B_2 H_7 J_6 L_1 M_2 
Stack 8
B_0 F_7 M_1 F_3 Z_103 
Stack 9
B_5 Z_104 E_1 M_3 Z_105 
Stack 10
F_4 K_2 I_5 F_1 G_2 
Stack 11
H_6 D_4 I_4 D_5 B_3 
Stack 12
F_2 O_3 Z_106 H_9 I_2 
Stack 13
E_3 D_2 C_6 K_4 A_2 
Stack 14
C_4 N_4 N_1 G_3 I_0 
Stack 15
K_1 L_4 N_3 L_6 Z_107 
Stack 16
G_7 C_3 N_0 D_7 K_5 
Stack 17
I_7 F_0 Z_108 J_4 Z_109 
Stack 18
Z_110 H_5 I_3 L_3 H_2 
Stack 19
E_0 K_3 G_5 F_8 B_4 
Stack 20
Z_111 A_3 H_3 C_0 A_0 
Stack 21
H_8 D_0 F_6 J_0 O_2 
Stack 22
E_2 I_6 C_1 O_1 D_3 
Stack 23
K_6 Z_112 G_1 D_1 N_5 
