Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_5 A_5 A_13 A_7 
Stack 1
B_0 B_9 C_1 C_3 
Stack 2
A_9 Z_100 C_7 A_8 
Stack 3
C_0 A_11 A_14 C_9 
Stack 4
A_12 Z_101 C_2 B_11 
Stack 5
A_0 C_4 A_3 A_10 
Stack 6
B_10 C_12 B_3 B_1 
Stack 7
B_4 C_5 B_7 A_2 
Stack 8
B_2 Z_102 C_11 B_12 
Stack 9
B_6 Z_103 C_10 A_4 
Stack 10
A_6 B_8 C_8 
Stack 11
A_1 C_6 Z_104 
