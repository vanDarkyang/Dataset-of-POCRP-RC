Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_7 E_2 A_1 H_3 F_2 
Stack 1
E_5 Z_100 A_2 B_2 J_1 
Stack 2
Z_101 G_3 A_4 B_0 E_8 
Stack 3
Z_102 C_1 F_3 Z_103 I_4 
Stack 4
D_4 F_5 Z_104 F_1 B_1 
Stack 5
E_6 C_4 B_3 G_2 G_5 
Stack 6
D_6 E_7 G_0 G_6 C_2 
Stack 7
I_3 B_4 F_7 I_2 A_0 
Stack 8
H_5 C_3 D_1 E_0 H_1 
Stack 9
G_7 H_6 E_3 E_4 Z_105 
Stack 10
G_4 F_6 J_2 C_0 D_0 
Stack 11
H_4 J_0 D_2 I_0 D_3 
Stack 12
G_1 F_0 E_1 H_2 F_4 
Stack 13
Z_106 A_3 H_0 D_5 I_1 
