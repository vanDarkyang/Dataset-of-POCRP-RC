Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_9 B_7 A_4 A_3 
Stack 1
C_1 B_8 A_10 C_11 
Stack 2
Z_100 Z_101 C_4 C_5 
Stack 3
A_7 C_7 C_9 B_5 
Stack 4
A_6 Z_102 B_11 A_2 
Stack 5
C_8 C_3 B_9 C_10 
Stack 6
B_0 B_2 B_4 A_0 
Stack 7
B_1 B_13 Z_103 A_13 
Stack 8
C_0 B_14 A_11 B_12 
Stack 9
B_10 C_2 B_3 A_1 
Stack 10
A_8 B_6 Z_104 
Stack 11
A_12 A_5 C_6 
