Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
K_5 I_5 G_4 N_2 
Stack 1
J_0 H_1 G_5 I_0 
Stack 2
J_6 F_4 F_0 M_2 
Stack 3
J_4 J_1 J_2 E_2 
Stack 4
C_1 Z_100 L_0 N_0 
Stack 5
H_6 M_3 H_2 L_2 
Stack 6
E_0 H_5 G_7 I_1 
Stack 7
I_6 O_0 L_3 H_8 
Stack 8
F_3 Z_101 F_1 Z_102 
Stack 9
Z_103 K_4 A_0 C_0 
Stack 10
G_8 M_0 C_3 Z_104 
Stack 11
C_2 O_1 K_1 A_1 
Stack 12
H_3 H_7 B_1 N_1 
Stack 13
D_5 H_0 B_3 I_3 
Stack 14
G_1 I_7 E_4 F_5 
Stack 15
D_3 D_0 K_6 G_6 
Stack 16
E_1 M_1 J_3 E_3 
Stack 17
Z_105 G_2 K_0 I_2 
Stack 18
F_2 O_2 K_3 Z_106 
Stack 19
H_4 D_2 Z_107 L_1 
Stack 20
F_6 B_2 D_1 D_4 
Stack 21
K_2 N_3 G_0 B_0 
Stack 22
E_5 G_3 Z_108 
Stack 23
I_4 J_5 Z_109 
