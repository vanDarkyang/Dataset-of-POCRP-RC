Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_2 C_9 D_0 B_1 
Stack 1
E_0 Z_100 E_3 Z_101 
Stack 2
C_0 D_3 C_3 E_1 
Stack 3
A_5 A_6 C_5 E_2 
Stack 4
E_8 B_8 Z_102 B_9 
Stack 5
E_7 C_4 A_0 A_4 
Stack 6
A_1 B_0 A_7 Z_103 
Stack 7
B_6 C_6 D_5 Z_104 
Stack 8
C_1 C_2 E_6 A_2 
Stack 9
B_4 D_1 E_4 D_7 
Stack 10
C_10 Z_105 E_9 A_3 
Stack 11
B_3 D_4 D_8 C_7 
Stack 12
B_7 D_6 D_2 
Stack 13
C_8 B_5 E_5 
