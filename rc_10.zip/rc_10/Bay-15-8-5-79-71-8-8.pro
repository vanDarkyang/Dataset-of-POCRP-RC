Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
B_1 A_8 D_10 E_1 B_3 B_12 
Stack 1
D_14 Z_100 D_9 A_6 B_4 C_5 
Stack 2
A_1 A_12 A_7 C_0 E_12 A_11 
Stack 3
D_11 B_13 C_8 E_0 D_7 A_4 
Stack 4
B_0 B_8 A_2 E_2 D_1 
Stack 5
C_1 E_11 C_7 D_6 E_6 
Stack 6
E_8 C_9 Z_101 C_11 D_12 
Stack 7
B_11 C_2 D_8 Z_102 C_4 
Stack 8
E_5 D_13 D_4 C_12 D_3 
Stack 9
B_14 D_5 B_9 A_9 E_10 
Stack 10
Z_103 A_0 D_2 C_13 A_3 
Stack 11
B_5 C_3 B_6 E_9 C_6 
Stack 12
E_3 Z_104 Z_105 B_2 B_7 
Stack 13
E_7 D_15 B_10 A_10 E_4 
Stack 14
D_0 Z_106 A_5 C_10 Z_107 
