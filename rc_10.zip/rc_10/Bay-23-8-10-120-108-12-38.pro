Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
Z_100 D_6 D_3 J_4 E_10 I_2 
Stack 1
C_6 G_6 E_12 F_5 I_7 C_10 
Stack 2
H_6 Z_101 A_3 E_3 E_1 F_9 
Stack 3
E_13 A_0 I_3 A_6 F_7 I_1 
Stack 4
I_4 Z_102 G_3 Z_103 J_6 F_4 
Stack 5
F_6 Z_104 A_4 D_1 D_2 
Stack 6
Z_105 E_2 I_6 Z_106 J_8 
Stack 7
J_2 I_0 F_8 E_6 H_10 
Stack 8
A_5 A_1 H_3 C_4 G_0 
Stack 9
G_8 H_5 D_10 E_7 B_7 
Stack 10
H_7 C_5 Z_107 D_7 G_5 
Stack 11
A_2 C_0 Z_108 J_1 F_11 
Stack 12
E_11 E_4 B_9 G_7 D_0 
Stack 13
D_4 G_4 A_7 B_5 B_8 
Stack 14
F_2 H_2 H_1 B_1 B_6 
Stack 15
Z_109 J_0 I_8 H_4 B_2 
Stack 16
E_5 D_8 J_5 C_7 G_2 
Stack 17
F_0 I_9 F_1 B_0 D_5 
Stack 18
E_9 H_8 B_10 E_0 C_3 
Stack 19
C_8 B_4 E_8 Z_110 H_9 
Stack 20
C_1 I_5 C_11 C_2 G_1 
Stack 21
F_3 Z_111 C_9 F_10 H_0 
Stack 22
B_3 G_9 J_7 J_3 D_9 
