Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_6 D_1 C_3 B_2 Z_100 
Stack 1
D_6 E_6 C_10 Z_101 C_8 
Stack 2
E_3 A_2 E_1 Z_102 E_7 
Stack 3
A_9 B_4 E_4 E_2 A_4 
Stack 4
E_0 D_4 A_7 C_4 A_5 
Stack 5
D_8 D_2 D_5 B_0 Z_103 
Stack 6
B_8 C_9 C_1 A_1 C_0 
Stack 7
C_6 A_0 B_6 C_7 D_0 
Stack 8
D_3 A_8 Z_104 B_3 D_7 
Stack 9
B_7 Z_105 E_5 C_2 C_11 
Stack 10
B_5 C_5 A_3 B_1 
