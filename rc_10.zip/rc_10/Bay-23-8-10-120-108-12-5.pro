Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
B_8 E_2 J_3 J_7 Z_100 I_4 
Stack 1
I_0 E_6 B_5 C_5 Z_101 H_10 
Stack 2
D_4 J_4 E_8 Z_102 F_0 Z_103 
Stack 3
D_1 D_8 A_3 C_7 J_5 Z_104 
Stack 4
E_5 E_11 J_2 F_7 B_1 A_0 
Stack 5
E_7 Z_105 C_4 C_2 F_1 
Stack 6
D_9 I_5 F_10 G_5 F_11 
Stack 7
F_13 G_8 E_1 I_7 H_3 
Stack 8
B_6 A_1 G_9 I_8 G_2 
Stack 9
Z_106 J_8 F_8 B_4 B_7 
Stack 10
F_9 C_6 F_5 H_4 A_8 
Stack 11
H_2 D_0 D_7 G_1 H_8 
Stack 12
E_10 D_6 J_1 E_3 H_1 
Stack 13
F_4 J_0 G_4 G_0 I_9 
Stack 14
C_0 H_6 D_2 C_8 H_7 
Stack 15
G_3 E_9 D_10 C_1 Z_107 
Stack 16
A_5 B_3 H_9 G_6 A_4 
Stack 17
G_7 F_2 J_9 A_7 B_2 
Stack 18
Z_108 C_3 I_10 E_4 Z_109 
Stack 19
H_0 I_1 F_12 Z_110 D_5 
Stack 20
I_6 E_12 A_2 F_6 B_0 
Stack 21
H_5 I_3 D_3 D_11 I_2 
Stack 22
A_6 J_6 E_0 F_3 Z_111 
