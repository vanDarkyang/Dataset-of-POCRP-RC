Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_2 C_5 H_0 J_3 F_0 
Stack 1
D_0 D_1 Z_100 C_6 I_1 
Stack 2
A_1 B_1 G_1 E_5 D_7 
Stack 3
D_6 E_0 G_6 J_0 I_4 
Stack 4
G_7 E_2 A_2 E_4 H_1 
Stack 5
F_6 F_5 A_3 H_2 B_0 
Stack 6
G_3 F_2 J_2 Z_101 A_4 
Stack 7
F_8 G_0 I_3 D_3 I_0 
Stack 8
Z_102 F_1 Z_103 E_3 F_3 
Stack 9
F_4 B_2 C_0 E_6 I_2 
Stack 10
C_4 Z_104 D_2 H_5 D_5 
Stack 11
G_5 D_4 Z_105 H_3 H_4 
Stack 12
C_1 G_4 E_1 J_1 A_0 
Stack 13
Z_106 F_7 C_3 J_4 G_2 
