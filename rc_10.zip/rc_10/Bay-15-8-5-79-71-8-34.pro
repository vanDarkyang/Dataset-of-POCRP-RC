Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_2 D_15 C_4 A_7 E_6 D_5 
Stack 1
E_8 C_12 A_3 D_14 D_11 E_5 
Stack 2
C_15 Z_100 A_5 B_6 B_4 D_8 
Stack 3
D_12 D_1 E_3 Z_101 C_3 B_12 
Stack 4
E_9 A_2 Z_102 B_11 B_2 
Stack 5
D_0 D_10 E_11 B_9 E_10 
Stack 6
Z_103 E_1 Z_104 E_7 A_0 
Stack 7
C_11 B_1 D_9 A_11 D_3 
Stack 8
B_5 B_10 E_2 A_1 Z_105 
Stack 9
D_13 C_7 D_6 B_7 C_1 
Stack 10
B_3 A_6 A_8 C_9 C_10 
Stack 11
Z_106 C_13 E_0 C_5 E_4 
Stack 12
E_12 C_6 A_4 B_8 C_8 
Stack 13
Z_107 C_0 C_14 E_13 D_2 
Stack 14
D_7 D_4 A_9 A_10 B_0 
