Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
H_0 C_3 Z_100 F_3 
Stack 1
D_3 D_5 A_1 F_1 
Stack 2
B_3 A_2 I_0 F_2 
Stack 3
C_6 Z_101 B_5 E_4 
Stack 4
D_1 E_1 A_0 I_1 
Stack 5
C_1 H_3 F_4 Z_102 
Stack 6
G_5 E_5 C_5 B_2 
Stack 7
C_2 C_0 I_3 Z_103 
Stack 8
E_6 E_2 H_2 A_3 
Stack 9
Z_104 H_1 Z_105 D_6 
Stack 10
B_0 F_5 G_0 I_2 
Stack 11
F_7 H_4 D_0 G_6 
Stack 12
G_1 B_1 I_4 F_6 
Stack 13
I_5 A_4 B_4 F_0 
Stack 14
E_3 D_2 J_0 G_3 
Stack 15
J_2 E_0 C_4 H_5 
Stack 16
G_2 G_4 D_7 
Stack 17
D_4 J_1 Z_106 
