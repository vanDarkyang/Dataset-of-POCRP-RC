Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
G_0 E_5 B_0 A_3 G_6 B_2 
Stack 1
H_9 F_2 A_4 G_9 J_6 I_8 
Stack 2
J_3 I_1 I_7 J_5 B_6 C_2 
Stack 3
J_4 E_11 B_5 B_7 G_12 Z_100 
Stack 4
C_0 F_5 F_7 I_0 Z_101 H_8 
Stack 5
E_9 H_0 G_8 H_5 C_9 
Stack 6
Z_102 F_1 D_12 Z_103 D_2 
Stack 7
H_4 B_9 D_7 J_2 C_3 
Stack 8
E_4 Z_104 I_10 F_3 E_7 
Stack 9
G_3 C_7 Z_105 I_3 G_4 
Stack 10
J_8 B_8 B_1 D_9 E_1 
Stack 11
A_0 Z_106 D_10 Z_107 I_4 
Stack 12
H_1 E_8 H_2 I_2 G_2 
Stack 13
A_1 C_4 H_10 D_11 D_0 
Stack 14
D_8 D_5 A_5 E_3 H_7 
Stack 15
C_6 E_2 D_6 Z_108 J_0 
Stack 16
C_1 E_0 F_8 I_6 F_0 
Stack 17
Z_109 I_5 G_5 G_10 A_7 
Stack 18
F_4 G_1 B_4 D_1 F_9 
Stack 19
E_10 E_6 G_7 J_1 H_6 
Stack 20
G_11 A_6 F_6 Z_110 D_4 
Stack 21
I_9 B_3 Z_111 J_7 D_3 
Stack 22
A_2 H_3 C_5 C_8 E_12 
