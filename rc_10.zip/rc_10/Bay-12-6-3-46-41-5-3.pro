Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_12 C_1 B_5 B_7 
Stack 1
B_10 Z_100 A_13 A_10 
Stack 2
C_2 A_4 A_5 C_3 
Stack 3
B_6 C_0 C_4 B_4 
Stack 4
C_12 Z_101 A_3 A_8 
Stack 5
B_8 B_1 B_13 B_9 
Stack 6
A_11 A_0 Z_102 A_7 
Stack 7
B_3 C_6 B_12 C_11 
Stack 8
C_10 A_9 C_9 B_11 
Stack 9
A_1 Z_103 Z_104 A_2 
Stack 10
C_5 C_7 B_2 
Stack 11
B_0 C_8 A_6 
