Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_8 D_7 C_11 Z_100 
Stack 1
E_5 D_2 B_4 Z_101 
Stack 2
D_1 C_1 A_0 E_2 
Stack 3
D_3 E_7 D_5 B_6 
Stack 4
C_2 D_6 C_6 A_4 
Stack 5
A_7 B_5 E_9 E_3 
Stack 6
D_0 A_5 Z_102 Z_103 
Stack 7
C_7 A_3 B_3 A_6 
Stack 8
Z_104 C_5 C_0 B_2 
Stack 9
B_0 A_2 D_9 C_4 
Stack 10
C_8 D_8 E_1 Z_105 
Stack 11
C_10 E_4 D_4 E_0 
Stack 12
E_6 A_1 C_3 
Stack 13
C_9 A_8 B_1 
