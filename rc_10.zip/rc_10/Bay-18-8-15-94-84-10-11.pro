Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
K_0 D_2 J_3 H_3 M_1 E_1 
Stack 1
I_3 N_1 J_4 G_1 K_4 I_5 
Stack 2
C_0 J_6 E_6 I_4 H_5 I_1 
Stack 3
K_1 G_7 C_1 M_3 K_6 J_2 
Stack 4
Z_100 Z_101 J_0 I_7 E_3 
Stack 5
H_4 D_3 K_3 M_4 Z_102 
Stack 6
Z_103 Z_104 G_0 O_0 K_2 
Stack 7
N_3 D_4 I_2 Z_105 C_2 
Stack 8
K_5 N_0 O_1 L_1 H_0 
Stack 9
E_0 Z_106 B_0 A_1 L_3 
Stack 10
B_2 G_3 I_0 D_0 H_2 
Stack 11
F_4 Z_107 B_3 N_2 A_2 
Stack 12
G_6 J_5 A_0 O_2 F_5 
Stack 13
H_6 F_3 Z_108 H_7 G_2 
Stack 14
D_1 G_5 F_2 G_4 I_6 
Stack 15
E_4 Z_109 H_1 M_0 F_0 
Stack 16
H_8 E_2 M_2 B_1 L_0 
Stack 17
F_1 L_2 E_5 J_1 C_3 
