Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
C_1 H_0 B_5 F_0 Z_100 H_3 
Stack 1
K_4 Z_101 I_7 J_5 O_3 K_1 
Stack 2
J_6 G_5 Z_102 L_2 H_9 G_9 
Stack 3
I_8 Z_103 C_5 N_3 Z_104 F_2 
Stack 4
G_1 B_0 N_1 D_3 L_7 
Stack 5
A_0 H_5 D_1 B_3 F_7 
Stack 6
D_5 G_3 K_7 J_3 Z_105 
Stack 7
E_0 M_2 I_1 H_7 G_0 
Stack 8
H_11 H_8 F_5 F_3 I_5 
Stack 9
O_2 G_4 F_8 D_0 N_0 
Stack 10
K_0 M_3 I_3 G_6 F_6 
Stack 11
I_2 E_1 H_2 J_7 Z_106 
Stack 12
L_5 D_2 H_1 J_4 M_4 
Stack 13
B_4 M_0 L_3 L_1 J_2 
Stack 14
C_4 E_7 H_4 Z_107 G_8 
Stack 15
E_6 J_8 K_2 Z_108 G_2 
Stack 16
J_1 F_1 Z_109 A_1 E_4 
Stack 17
H_10 I_6 N_2 A_2 I_4 
Stack 18
K_3 E_5 M_1 K_6 C_3 
Stack 19
C_0 J_0 D_4 L_0 G_10 
Stack 20
D_6 H_6 G_7 C_2 Z_110 
Stack 21
C_6 L_4 B_2 E_3 I_0 
Stack 22
O_0 L_6 J_9 K_5 B_1 
Stack 23
O_1 E_2 Z_111 Z_112 F_4 
