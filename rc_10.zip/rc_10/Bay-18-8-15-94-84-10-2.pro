Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 J_2 C_1 F_7 M_1 G_2 
Stack 1
L_4 G_7 I_1 E_0 H_4 H_5 
Stack 2
H_3 A_0 H_2 C_4 L_0 A_1 
Stack 3
G_5 F_1 C_2 L_1 H_0 L_3 
Stack 4
B_2 G_4 K_0 F_5 E_3 
Stack 5
Z_101 E_4 Z_102 Z_103 I_2 
Stack 6
M_0 D_5 D_1 J_3 E_1 
Stack 7
D_3 B_1 M_3 F_0 H_7 
Stack 8
I_0 G_6 F_2 M_2 E_2 
Stack 9
D_0 D_2 F_3 H_6 Z_104 
Stack 10
J_4 G_1 K_1 F_6 I_7 
Stack 11
C_0 G_0 D_4 K_4 I_4 
Stack 12
J_5 Z_105 N_0 L_2 J_6 
Stack 13
L_5 B_0 N_2 J_1 N_1 
Stack 14
O_2 I_8 O_1 K_3 G_3 
Stack 15
H_8 J_0 Z_106 O_0 I_6 
Stack 16
I_3 Z_107 I_5 H_1 Z_108 
Stack 17
F_4 Z_109 K_5 K_2 C_3 
