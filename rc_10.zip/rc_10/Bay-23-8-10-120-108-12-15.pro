Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
E_0 F_0 A_6 Z_100 A_3 Z_101 
Stack 1
B_4 J_4 B_6 B_1 F_8 Z_102 
Stack 2
D_8 G_8 H_2 B_7 Z_103 C_4 
Stack 3
H_6 G_1 F_4 G_4 E_6 G_5 
Stack 4
J_1 I_5 D_5 I_7 D_2 Z_104 
Stack 5
D_7 D_11 Z_105 D_6 A_5 
Stack 6
D_10 C_9 B_10 G_9 A_0 
Stack 7
C_6 H_4 A_7 D_3 Z_106 
Stack 8
E_9 I_3 J_5 E_10 D_9 
Stack 9
H_3 F_10 A_4 C_2 I_8 
Stack 10
F_6 H_1 F_1 Z_107 F_3 
Stack 11
F_9 J_7 B_0 I_4 G_7 
Stack 12
Z_108 E_3 I_1 Z_109 G_11 
Stack 13
J_2 D_1 A_1 C_7 G_6 
Stack 14
E_2 E_13 D_0 B_5 G_2 
Stack 15
I_9 E_4 F_7 J_3 G_0 
Stack 16
E_5 F_11 E_1 C_1 J_6 
Stack 17
B_8 F_5 H_0 J_0 E_7 
Stack 18
B_3 Z_110 J_8 I_6 A_2 
Stack 19
H_7 I_0 C_5 F_2 C_8 
Stack 20
I_2 B_2 Z_111 E_8 E_12 
Stack 21
H_8 G_3 G_10 D_4 C_0 
Stack 22
H_5 C_3 B_9 E_11 F_12 
