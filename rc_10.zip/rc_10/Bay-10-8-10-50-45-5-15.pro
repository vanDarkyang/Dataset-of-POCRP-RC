Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
E_3 I_3 G_0 H_2 J_0 
Stack 1
Z_100 E_4 Z_101 F_0 E_1 
Stack 2
G_2 F_1 D_3 B_1 Z_102 
Stack 3
G_3 G_1 C_1 G_5 H_0 
Stack 4
E_0 Z_103 A_0 C_2 A_1 
Stack 5
F_6 C_3 E_5 J_2 H_3 
Stack 6
I_1 A_2 B_0 F_2 E_2 
Stack 7
I_0 D_0 H_4 F_4 F_3 
Stack 8
F_5 G_4 H_1 D_1 C_0 
Stack 9
D_2 B_2 Z_104 I_2 J_1 
