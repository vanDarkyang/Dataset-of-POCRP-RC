Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_2 E_2 C_14 E_8 
Stack 1
B_5 E_3 Z_100 Z_101 
Stack 2
A_1 B_10 Z_102 C_6 
Stack 3
C_7 C_0 Z_103 B_0 
Stack 4
B_2 A_11 B_14 C_9 
Stack 5
A_6 D_9 Z_104 E_13 
Stack 6
D_13 C_8 B_6 A_9 
Stack 7
E_5 D_3 D_10 B_9 
Stack 8
Z_105 B_11 A_3 B_7 
Stack 9
D_8 C_3 A_4 C_4 
Stack 10
A_0 E_11 D_11 E_6 
Stack 11
E_7 Z_106 D_5 C_11 
Stack 12
D_2 C_5 D_12 B_1 
Stack 13
E_4 D_6 E_0 D_0 
Stack 14
B_13 A_2 E_1 B_4 
Stack 15
E_12 C_10 A_5 A_10 
Stack 16
A_7 C_12 D_1 E_9 
Stack 17
C_1 D_4 Z_107 A_8 
Stack 18
C_13 B_8 B_12 D_7 
Stack 19
B_3 D_14 E_10 
