Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_2 B_10 C_12 A_7 
Stack 1
C_3 Z_100 A_5 C_11 
Stack 2
B_1 B_6 B_11 C_5 
Stack 3
A_12 B_12 A_3 A_8 
Stack 4
C_6 B_9 B_7 C_10 
Stack 5
A_1 A_11 B_4 Z_101 
Stack 6
B_3 A_0 A_10 A_6 
Stack 7
A_9 Z_102 Z_103 B_8 
Stack 8
B_2 C_1 C_9 B_0 
Stack 9
C_0 C_4 C_8 Z_104 
Stack 10
C_13 C_2 A_13 
Stack 11
A_4 C_7 B_5 
