Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
D_1 H_8 H_1 G_1 
Stack 1
K_3 L_1 E_5 Z_100 
Stack 2
H_6 Z_101 K_4 D_0 
Stack 3
H_7 D_3 Z_102 J_3 
Stack 4
F_1 I_2 F_3 F_4 
Stack 5
Z_103 E_1 A_1 C_2 
Stack 6
E_2 O_2 A_0 M_3 
Stack 7
M_4 K_0 I_4 H_0 
Stack 8
Z_104 C_4 D_4 J_4 
Stack 9
L_0 K_2 B_2 Z_105 
Stack 10
F_5 G_4 F_6 N_1 
Stack 11
B_1 O_0 K_1 N_0 
Stack 12
G_5 A_2 K_6 Z_106 
Stack 13
O_1 J_0 Z_107 F_0 
Stack 14
G_3 M_0 H_3 D_2 
Stack 15
J_2 H_5 E_0 B_0 
Stack 16
B_3 C_3 E_4 N_2 
Stack 17
M_1 K_5 I_3 Z_108 
Stack 18
E_6 G_2 Z_109 H_2 
Stack 19
F_2 L_4 L_3 I_0 
Stack 20
J_1 I_6 I_7 E_3 
Stack 21
I_1 G_0 C_0 M_2 
Stack 22
H_4 C_1 L_2 
Stack 23
I_5 J_5 I_8 
