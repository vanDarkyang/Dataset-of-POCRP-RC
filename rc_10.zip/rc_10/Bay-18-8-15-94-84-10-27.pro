Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_0 I_4 L_0 I_1 Z_100 F_6 
Stack 1
E_1 G_0 F_3 G_3 O_2 G_6 
Stack 2
M_2 D_0 C_1 H_4 I_2 H_7 
Stack 3
M_3 H_9 Z_101 K_6 K_3 O_1 
Stack 4
Z_102 G_7 C_0 H_1 D_1 
Stack 5
B_0 H_8 H_6 K_0 K_1 
Stack 6
H_3 F_2 C_3 F_0 C_2 
Stack 7
Z_103 L_2 N_2 O_0 D_4 
Stack 8
Z_104 J_3 I_3 K_4 K_2 
Stack 9
M_1 N_3 A_2 D_3 E_3 
Stack 10
I_0 F_5 Z_105 Z_106 E_2 
Stack 11
K_5 J_6 F_4 G_2 D_2 
Stack 12
E_4 Z_107 F_1 D_5 H_5 
Stack 13
A_1 I_5 I_6 Z_108 J_4 
Stack 14
J_2 L_1 H_0 J_1 A_0 
Stack 15
E_5 G_4 G_1 B_2 N_0 
Stack 16
B_3 J_5 H_2 G_5 N_1 
Stack 17
J_0 B_1 Z_109 G_8 M_0 
