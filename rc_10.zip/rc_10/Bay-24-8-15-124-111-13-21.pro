Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
K_3 E_5 A_3 G_9 L_6 B_3 
Stack 1
G_3 C_3 A_1 Z_100 K_0 F_7 
Stack 2
M_1 C_1 K_1 F_3 N_1 M_3 
Stack 3
H_3 L_0 J_4 N_2 E_3 I_3 
Stack 4
H_0 F_2 E_7 O_2 H_2 
Stack 5
M_0 I_6 K_8 Z_101 D_1 
Stack 6
H_4 I_1 D_0 L_4 C_0 
Stack 7
L_3 J_2 I_2 E_1 O_1 
Stack 8
N_0 Z_102 D_2 M_2 Z_103 
Stack 9
K_6 Z_104 G_1 J_6 I_8 
Stack 10
J_1 E_0 O_3 E_6 A_0 
Stack 11
C_6 A_2 L_2 F_0 H_5 
Stack 12
B_1 E_4 B_0 F_4 G_6 
Stack 13
Z_105 B_2 Z_106 K_4 A_4 
Stack 14
J_9 Z_107 H_8 H_11 Z_108 
Stack 15
I_5 F_1 K_5 G_2 G_5 
Stack 16
O_0 L_7 G_8 H_1 C_5 
Stack 17
G_4 D_3 K_2 J_3 J_7 
Stack 18
G_7 Z_109 L_5 J_8 F_6 
Stack 19
I_7 N_3 D_5 B_4 D_4 
Stack 20
H_6 H_7 J_0 J_5 L_1 
Stack 21
Z_110 K_7 I_4 I_9 Z_111 
Stack 22
G_0 Z_112 E_2 C_2 N_4 
Stack 23
H_10 I_0 H_9 F_5 C_4 
