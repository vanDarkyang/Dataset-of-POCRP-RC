Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_0 A_7 B_7 B_8 
Stack 1
D_9 E_5 D_5 A_0 
Stack 2
A_1 D_2 A_4 E_7 
Stack 3
B_2 B_0 Z_100 E_9 
Stack 4
E_3 C_7 E_6 E_2 
Stack 5
B_4 E_1 D_8 B_6 
Stack 6
C_3 C_8 C_5 Z_101 
Stack 7
E_0 E_4 D_0 A_6 
Stack 8
B_5 Z_102 E_8 C_10 
Stack 9
Z_103 C_1 D_3 C_4 
Stack 10
A_5 B_1 A_2 D_6 
Stack 11
Z_104 A_3 C_9 D_7 
Stack 12
Z_105 B_3 D_1 
Stack 13
C_2 D_4 C_6 
