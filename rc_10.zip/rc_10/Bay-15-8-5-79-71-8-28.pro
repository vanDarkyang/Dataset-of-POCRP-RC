Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_7 B_2 Z_100 B_1 Z_101 C_13 
Stack 1
A_9 A_6 Z_102 Z_103 D_6 B_6 
Stack 2
D_11 B_10 A_1 D_4 C_10 Z_104 
Stack 3
E_7 D_10 D_8 C_2 C_1 B_8 
Stack 4
B_9 B_11 D_3 C_12 C_6 
Stack 5
A_5 C_4 B_5 E_5 E_3 
Stack 6
E_11 B_12 E_12 C_14 E_0 
Stack 7
Z_105 A_11 C_5 C_3 E_1 
Stack 8
A_0 A_10 B_13 D_9 D_1 
Stack 9
B_0 D_14 E_4 C_7 A_13 
Stack 10
E_8 D_13 D_2 E_10 Z_106 
Stack 11
B_3 C_0 D_0 A_4 A_3 
Stack 12
C_11 B_4 B_7 D_7 C_9 
Stack 13
E_2 C_8 A_8 A_2 E_6 
Stack 14
E_9 Z_107 D_5 D_12 A_12 
