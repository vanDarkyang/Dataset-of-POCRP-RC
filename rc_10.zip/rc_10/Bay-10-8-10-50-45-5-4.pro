Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
F_6 Z_100 Z_101 H_4 A_0 
Stack 1
F_4 H_3 E_5 E_0 E_6 
Stack 2
C_3 G_3 B_2 I_0 B_1 
Stack 3
G_0 E_1 Z_102 I_1 D_5 
Stack 4
Z_103 C_0 H_1 D_3 B_0 
Stack 5
G_2 F_2 D_4 D_0 J_1 
Stack 6
H_0 F_0 D_1 E_4 I_2 
Stack 7
J_0 I_3 E_2 Z_104 A_1 
Stack 8
C_2 F_5 E_3 J_2 C_1 
Stack 9
F_1 G_1 D_2 H_2 F_3 
