Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
Z_100 C_9 E_0 E_2 
Stack 1
C_8 C_15 D_5 E_5 
Stack 2
Z_101 Z_102 C_5 D_1 
Stack 3
C_1 B_12 A_10 B_10 
Stack 4
A_13 Z_103 D_13 E_3 
Stack 5
B_13 B_9 C_4 A_2 
Stack 6
A_1 E_7 C_10 B_5 
Stack 7
B_4 C_2 E_4 C_13 
Stack 8
B_7 Z_104 C_12 E_6 
Stack 9
Z_105 A_8 A_0 Z_106 
Stack 10
B_0 A_9 E_11 E_8 
Stack 11
D_12 E_9 A_5 A_4 
Stack 12
D_0 D_8 B_2 E_1 
Stack 13
D_2 C_11 B_1 A_3 
Stack 14
C_3 B_11 B_6 A_11 
Stack 15
A_12 E_10 C_7 A_7 
Stack 16
D_7 D_3 D_4 D_10 
Stack 17
B_8 D_11 C_0 C_6 
Stack 18
B_3 Z_107 D_9 C_14 
Stack 19
D_6 A_6 B_14 
