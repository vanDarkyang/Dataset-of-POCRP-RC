Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_4 C_0 Z_100 D_5 
Stack 1
A_7 A_8 C_7 C_9 
Stack 2
E_7 E_6 E_3 B_0 
Stack 3
E_2 E_8 C_10 D_2 
Stack 4
C_1 A_1 C_6 A_4 
Stack 5
B_7 Z_101 A_3 B_3 
Stack 6
E_0 D_0 B_2 B_5 
Stack 7
A_9 C_5 D_7 Z_102 
Stack 8
C_4 Z_103 C_3 D_6 
Stack 9
E_5 Z_104 C_2 A_6 
Stack 10
C_8 Z_105 D_3 B_8 
Stack 11
E_9 A_0 E_1 B_4 
Stack 12
B_1 D_4 A_5 
Stack 13
B_6 A_2 D_1 
