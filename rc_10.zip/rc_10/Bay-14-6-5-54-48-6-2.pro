Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
Z_100 D_5 A_7 E_5 
Stack 1
B_3 B_4 C_8 C_10 
Stack 2
E_1 A_2 E_3 E_7 
Stack 3
A_6 C_5 A_4 E_6 
Stack 4
D_6 B_1 D_3 B_7 
Stack 5
D_0 D_7 Z_101 E_4 
Stack 6
C_7 Z_102 B_9 B_2 
Stack 7
C_1 E_0 D_4 Z_103 
Stack 8
C_2 C_9 E_2 D_2 
Stack 9
A_8 A_9 Z_104 B_6 
Stack 10
C_4 C_6 A_1 B_5 
Stack 11
A_3 A_5 Z_105 E_8 
Stack 12
D_1 B_8 C_3 
Stack 13
B_0 A_0 C_0 
