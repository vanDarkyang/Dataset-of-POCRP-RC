Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
D_7 D_4 H_8 B_6 J_8 E_12 
Stack 1
B_8 Z_100 E_2 H_6 G_1 I_7 
Stack 2
F_11 C_5 D_1 E_8 Z_101 Z_102 
Stack 3
E_9 H_10 B_3 I_5 J_2 E_3 
Stack 4
I_1 J_6 F_8 F_12 H_2 B_4 
Stack 5
E_0 F_6 I_8 Z_103 G_7 
Stack 6
I_6 H_7 F_2 Z_104 D_9 
Stack 7
G_4 A_8 I_9 F_7 E_11 
Stack 8
B_0 A_1 D_8 C_2 H_1 
Stack 9
H_5 D_3 D_0 G_3 H_4 
Stack 10
I_4 F_1 A_0 H_3 C_0 
Stack 11
Z_105 Z_106 B_2 C_9 G_0 
Stack 12
A_5 H_11 A_3 E_10 J_5 
Stack 13
J_0 G_2 E_6 B_5 C_4 
Stack 14
E_7 J_7 Z_107 D_6 G_6 
Stack 15
F_9 F_0 G_8 C_3 C_6 
Stack 16
G_9 B_7 E_4 A_7 D_11 
Stack 17
J_4 Z_108 D_10 C_1 B_9 
Stack 18
Z_109 E_1 H_9 C_8 B_1 
Stack 19
I_2 F_4 A_4 J_3 E_5 
Stack 20
I_3 F_3 A_6 H_0 J_1 
Stack 21
C_7 G_5 Z_110 D_2 Z_111 
Stack 22
F_5 D_5 I_0 A_2 F_10 
