Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_6 C_9 C_5 A_4 B_4 
Stack 1
E_8 A_0 Z_100 A_3 E_6 
Stack 2
D_5 A_1 C_3 B_1 D_8 
Stack 3
Z_101 B_7 C_4 B_6 B_5 
Stack 4
D_9 D_0 Z_102 E_2 D_1 
Stack 5
Z_103 C_0 D_6 E_0 Z_104 
Stack 6
C_8 A_7 E_9 A_8 E_3 
Stack 7
D_7 A_6 B_2 E_7 D_3 
Stack 8
A_5 E_1 C_7 D_2 E_5 
Stack 9
A_2 E_4 D_4 B_0 Z_105 
Stack 10
C_2 B_8 C_1 B_3 
