Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_8 C_9 C_4 E_9 E_2 
Stack 1
E_5 E_6 A_2 A_1 B_6 
Stack 2
D_1 C_8 D_8 B_4 A_3 
Stack 3
D_3 D_7 E_4 C_0 E_3 
Stack 4
C_1 D_2 Z_100 D_9 Z_101 
Stack 5
A_6 Z_102 A_7 E_1 A_5 
Stack 6
D_0 E_7 Z_103 D_4 B_3 
Stack 7
C_6 D_6 Z_104 C_2 C_3 
Stack 8
B_8 B_5 A_0 B_1 D_10 
Stack 9
B_0 A_4 D_5 B_7 E_0 
Stack 10
C_7 Z_105 C_5 B_2 
