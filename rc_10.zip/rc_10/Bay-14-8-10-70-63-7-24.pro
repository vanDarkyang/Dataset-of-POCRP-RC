Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_3 G_1 F_5 D_6 Z_100 
Stack 1
A_4 D_0 E_7 C_5 I_4 
Stack 2
E_3 Z_101 D_4 I_2 H_4 
Stack 3
B_3 Z_102 J_2 D_2 J_3 
Stack 4
H_2 A_0 Z_103 D_5 H_0 
Stack 5
F_0 C_0 E_0 A_2 E_2 
Stack 6
J_0 G_4 H_3 E_1 B_0 
Stack 7
E_6 G_3 I_3 J_4 E_5 
Stack 8
F_2 A_3 B_4 H_5 Z_104 
Stack 9
C_4 J_1 C_1 F_3 E_4 
Stack 10
C_3 Z_105 B_5 C_2 F_1 
Stack 11
F_4 F_6 D_1 E_8 G_6 
Stack 12
A_1 H_1 Z_106 B_2 G_5 
Stack 13
I_0 G_2 B_1 I_1 G_0 
