Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_6 B_5 C_8 C_6 E_6 
Stack 1
C_1 C_0 Z_100 B_4 E_2 
Stack 2
Z_101 E_4 E_7 E_8 A_6 
Stack 3
D_9 E_0 B_7 A_2 A_3 
Stack 4
Z_102 D_3 A_4 E_1 A_1 
Stack 5
B_6 C_7 D_8 B_3 E_3 
Stack 6
D_1 B_0 Z_103 B_1 D_10 
Stack 7
D_0 C_4 Z_104 E_5 B_2 
Stack 8
D_7 B_8 C_2 D_5 D_4 
Stack 9
Z_105 D_2 A_5 B_9 C_5 
Stack 10
A_7 A_8 C_3 A_0 
