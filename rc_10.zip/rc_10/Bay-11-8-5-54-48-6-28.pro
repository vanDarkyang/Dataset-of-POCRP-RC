Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_9 B_2 B_3 E_2 A_9 
Stack 1
C_0 A_2 E_8 D_3 Z_100 
Stack 2
B_6 D_1 B_8 C_8 E_7 
Stack 3
C_6 A_0 D_0 Z_101 B_5 
Stack 4
C_3 B_7 D_8 C_1 A_8 
Stack 5
B_4 C_2 A_5 B_0 D_2 
Stack 6
A_6 D_4 Z_102 E_0 A_7 
Stack 7
C_7 D_6 E_5 C_5 B_1 
Stack 8
A_4 E_1 Z_103 D_7 Z_104 
Stack 9
C_9 A_1 D_5 E_3 A_3 
Stack 10
Z_105 C_4 E_6 E_4 
