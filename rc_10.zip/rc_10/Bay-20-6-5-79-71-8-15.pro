Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_11 C_6 A_5 C_5 
Stack 1
B_2 C_2 E_8 E_2 
Stack 2
D_8 D_6 D_11 E_6 
Stack 3
B_14 A_13 D_2 D_10 
Stack 4
D_0 A_2 D_5 D_3 
Stack 5
A_3 B_9 C_9 E_0 
Stack 6
C_14 B_6 B_0 D_4 
Stack 7
A_7 D_1 C_8 Z_100 
Stack 8
B_10 Z_101 Z_102 A_1 
Stack 9
B_3 C_12 B_7 B_5 
Stack 10
C_4 E_10 Z_103 Z_104 
Stack 11
E_9 E_12 E_1 E_4 
Stack 12
A_0 Z_105 E_7 E_5 
Stack 13
B_12 C_13 D_9 Z_106 
Stack 14
D_7 B_4 A_6 C_10 
Stack 15
C_7 A_12 C_11 B_13 
Stack 16
A_10 C_15 E_11 E_13 
Stack 17
E_3 Z_107 C_0 B_11 
Stack 18
C_3 A_4 B_8 B_1 
Stack 19
C_1 A_9 A_8 
