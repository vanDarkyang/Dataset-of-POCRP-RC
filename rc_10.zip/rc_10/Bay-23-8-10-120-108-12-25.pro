Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
H_3 E_6 F_6 C_8 I_0 I_1 
Stack 1
A_5 I_10 G_5 I_7 I_2 B_7 
Stack 2
F_5 I_3 J_4 B_9 J_0 E_12 
Stack 3
D_0 E_8 C_4 F_0 E_9 C_10 
Stack 4
C_6 B_3 B_5 G_4 E_11 E_5 
Stack 5
H_7 E_7 A_4 C_2 I_9 
Stack 6
D_5 Z_100 E_2 A_9 H_2 
Stack 7
A_1 Z_101 B_1 F_2 G_2 
Stack 8
H_6 Z_102 D_7 G_6 D_1 
Stack 9
F_4 C_5 F_7 Z_103 G_11 
Stack 10
J_2 J_1 B_4 Z_104 G_7 
Stack 11
A_3 E_3 F_3 A_7 Z_105 
Stack 12
J_9 F_10 G_3 D_8 F_8 
Stack 13
I_6 B_0 F_9 C_9 Z_106 
Stack 14
G_9 I_8 D_4 G_8 G_10 
Stack 15
H_4 B_6 F_1 B_2 Z_107 
Stack 16
Z_108 A_8 J_8 H_1 I_4 
Stack 17
C_7 E_1 J_6 E_4 A_6 
Stack 18
E_10 F_11 A_0 Z_109 B_8 
Stack 19
C_0 A_2 Z_110 D_3 C_3 
Stack 20
H_0 D_6 C_1 I_5 H_5 
Stack 21
G_0 G_1 D_9 J_5 J_7 
Stack 22
C_11 D_2 J_3 E_0 Z_111 
