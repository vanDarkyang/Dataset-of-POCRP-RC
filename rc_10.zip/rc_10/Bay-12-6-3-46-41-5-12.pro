Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_1 B_0 B_6 C_5 
Stack 1
Z_100 Z_101 B_9 C_11 
Stack 2
C_12 A_5 A_11 Z_102 
Stack 3
A_0 C_10 B_12 Z_103 
Stack 4
A_8 C_6 C_1 A_6 
Stack 5
C_3 A_1 C_7 A_4 
Stack 6
B_4 B_11 B_10 C_4 
Stack 7
C_9 Z_104 C_0 B_7 
Stack 8
B_2 A_2 A_13 A_12 
Stack 9
B_5 A_3 B_3 B_8 
Stack 10
A_7 A_9 C_8 
Stack 11
C_2 A_14 A_10 
