Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
M_2 F_7 E_5 C_0 A_0 G_5 
Stack 1
Z_100 F_2 O_0 E_4 E_8 H_0 
Stack 2
D_2 E_0 Z_101 E_7 C_5 I_2 
Stack 3
L_0 J_3 A_4 H_2 Z_102 F_4 
Stack 4
I_6 G_2 J_0 N_0 K_2 
Stack 5
Z_103 G_7 I_3 Z_104 D_0 
Stack 6
H_5 K_4 Z_105 Z_106 L_1 
Stack 7
L_4 H_10 M_4 F_8 I_0 
Stack 8
G_6 H_9 J_7 F_6 J_4 
Stack 9
C_2 M_3 L_3 L_6 H_3 
Stack 10
H_8 J_8 Z_107 O_4 E_3 
Stack 11
K_5 F_5 O_1 L_2 G_8 
Stack 12
H_4 B_4 A_1 J_6 Z_108 
Stack 13
I_8 H_6 H_1 Z_109 N_2 
Stack 14
D_3 K_0 D_4 J_1 F_1 
Stack 15
I_7 H_7 B_3 M_0 E_1 
Stack 16
B_1 C_3 K_3 K_1 L_5 
Stack 17
N_5 G_4 I_1 Z_110 M_1 
Stack 18
G_3 D_6 G_1 F_3 C_1 
Stack 19
D_5 N_4 I_4 F_0 C_4 
Stack 20
J_5 N_3 J_9 G_0 J_2 
Stack 21
Z_111 E_2 N_1 B_0 A_2 
Stack 22
L_7 B_2 I_5 K_6 E_6 
Stack 23
Z_112 O_3 A_3 D_1 O_2 
