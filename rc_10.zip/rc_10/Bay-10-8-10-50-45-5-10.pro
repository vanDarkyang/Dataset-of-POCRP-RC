Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_1 E_3 Z_100 F_1 I_3 
Stack 1
C_4 G_4 Z_101 A_0 G_1 
Stack 2
B_2 C_3 H_3 I_1 I_0 
Stack 3
Z_102 I_2 D_2 H_4 G_3 
Stack 4
C_1 E_0 G_5 D_0 H_0 
Stack 5
B_0 G_2 J_0 F_3 C_2 
Stack 6
J_1 Z_103 E_5 E_2 D_3 
Stack 7
A_2 J_2 H_2 H_1 F_2 
Stack 8
D_4 D_1 G_0 C_0 F_4 
Stack 9
F_0 E_1 Z_104 B_1 E_4 
