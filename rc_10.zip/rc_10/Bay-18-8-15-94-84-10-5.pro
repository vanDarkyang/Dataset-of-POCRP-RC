Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_6 J_2 C_1 F_2 B_1 Z_100 
Stack 1
K_2 O_2 H_0 C_3 J_6 G_0 
Stack 2
I_6 D_3 H_7 A_1 B_3 C_0 
Stack 3
O_1 J_3 I_2 B_0 F_0 E_2 
Stack 4
H_6 C_4 I_5 L_4 K_5 
Stack 5
A_2 O_0 M_0 N_0 K_3 
Stack 6
D_4 M_3 H_3 K_6 H_4 
Stack 7
N_1 G_5 G_3 M_1 Z_101 
Stack 8
G_6 E_3 N_2 H_1 J_4 
Stack 9
H_5 Z_102 Z_103 F_3 H_2 
Stack 10
F_5 D_5 K_4 L_3 L_1 
Stack 11
C_2 I_7 J_5 Z_104 D_1 
Stack 12
Z_105 G_4 I_0 K_1 L_0 
Stack 13
F_1 E_4 J_0 J_7 E_0 
Stack 14
Z_106 D_0 I_1 B_2 A_0 
Stack 15
I_3 Z_107 K_0 I_4 J_1 
Stack 16
E_1 G_2 F_4 Z_108 L_2 
Stack 17
Z_109 M_4 M_2 G_1 D_2 
