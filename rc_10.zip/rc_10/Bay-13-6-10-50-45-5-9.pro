Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_1 I_2 C_2 D_0 
Stack 1
G_0 Z_100 F_4 I_3 
Stack 2
E_0 H_1 C_4 E_2 
Stack 3
B_0 F_1 B_1 Z_101 
Stack 4
B_2 E_1 D_3 C_1 
Stack 5
Z_102 J_1 H_2 I_0 
Stack 6
C_0 H_0 Z_103 A_2 
Stack 7
E_3 G_3 F_5 F_3 
Stack 8
G_2 F_2 C_3 E_4 
Stack 9
A_0 J_0 D_4 G_1 
Stack 10
F_0 J_2 H_3 D_5 
Stack 11
D_1 D_2 G_4 
Stack 12
I_1 Z_104 G_5 
