Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
B_2 D_11 E_0 E_5 
Stack 1
C_5 B_13 B_3 D_7 
Stack 2
C_15 B_10 C_10 C_12 
Stack 3
E_2 C_14 D_13 E_7 
Stack 4
A_10 A_3 D_5 C_13 
Stack 5
Z_100 D_2 C_7 A_4 
Stack 6
C_4 Z_101 D_1 A_5 
Stack 7
Z_102 D_10 B_6 C_2 
Stack 8
D_4 A_9 E_13 Z_103 
Stack 9
D_8 C_11 E_1 B_4 
Stack 10
B_14 B_1 Z_104 B_0 
Stack 11
C_9 Z_105 B_8 B_9 
Stack 12
A_7 E_10 B_12 C_6 
Stack 13
D_6 Z_106 E_6 E_12 
Stack 14
C_1 D_9 Z_107 C_3 
Stack 15
E_9 B_7 A_1 A_2 
Stack 16
E_11 D_3 D_12 A_8 
Stack 17
B_5 B_11 C_8 A_6 
Stack 18
D_14 E_4 A_0 C_0 
Stack 19
D_0 E_8 E_3 
