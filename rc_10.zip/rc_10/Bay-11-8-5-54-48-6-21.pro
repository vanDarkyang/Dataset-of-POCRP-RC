Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_0 A_7 B_2 D_8 E_7 
Stack 1
D_9 D_10 C_1 C_5 E_9 
Stack 2
A_1 C_2 Z_100 D_0 E_2 
Stack 3
B_0 A_8 Z_101 E_8 B_4 
Stack 4
E_3 E_5 Z_102 D_3 C_7 
Stack 5
B_1 D_2 D_4 A_3 A_6 
Stack 6
C_3 Z_103 B_5 C_9 C_10 
Stack 7
E_0 C_8 D_5 D_1 C_4 
Stack 8
B_3 E_1 A_4 C_6 D_6 
Stack 9
Z_104 Z_105 A_2 B_6 D_7 
Stack 10
A_5 E_4 E_6 A_0 
