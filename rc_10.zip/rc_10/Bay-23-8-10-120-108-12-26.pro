Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
G_9 H_7 A_6 Z_100 J_7 A_8 
Stack 1
E_2 J_3 H_6 F_6 F_7 Z_101 
Stack 2
F_0 Z_102 G_3 D_0 I_8 C_4 
Stack 3
C_0 Z_103 B_2 I_6 D_3 J_4 
Stack 4
Z_104 D_2 F_1 Z_105 H_3 C_1 
Stack 5
C_3 Z_106 C_9 I_9 F_2 
Stack 6
A_4 D_6 I_4 B_1 G_4 
Stack 7
A_2 I_1 J_5 D_5 A_5 
Stack 8
E_0 C_6 G_8 F_3 A_3 
Stack 9
H_8 Z_107 H_2 I_7 B_3 
Stack 10
C_5 Z_108 C_10 B_4 F_11 
Stack 11
E_3 E_5 E_4 Z_109 E_1 
Stack 12
B_8 G_0 B_6 F_5 B_0 
Stack 13
J_2 E_8 A_0 F_10 F_12 
Stack 14
C_2 E_12 Z_110 F_9 C_7 
Stack 15
E_9 G_2 D_8 D_7 J_0 
Stack 16
G_7 Z_111 H_5 I_5 E_11 
Stack 17
D_4 I_10 J_1 I_3 D_9 
Stack 18
B_5 I_2 J_8 A_1 H_10 
Stack 19
J_9 E_7 G_6 F_4 H_9 
Stack 20
G_1 D_1 B_7 I_0 F_8 
Stack 21
H_0 J_6 E_10 E_6 C_8 
Stack 22
H_4 A_7 D_10 G_5 H_1 
