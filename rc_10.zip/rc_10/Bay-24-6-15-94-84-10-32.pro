Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
H_5 I_2 K_3 H_2 
Stack 1
A_2 J_5 N_1 G_7 
Stack 2
K_0 F_2 F_0 D_1 
Stack 3
F_3 N_0 Z_100 D_3 
Stack 4
H_3 D_2 B_2 I_6 
Stack 5
Z_101 J_4 I_4 I_5 
Stack 6
K_4 B_1 A_0 M_4 
Stack 7
K_1 G_5 B_0 Z_102 
Stack 8
E_5 N_2 H_0 G_6 
Stack 9
O_0 C_2 Z_103 E_2 
Stack 10
M_0 L_5 J_3 E_0 
Stack 11
C_0 G_0 G_4 F_5 
Stack 12
Z_104 M_2 Z_105 L_4 
Stack 13
Z_106 G_1 Z_107 F_4 
Stack 14
L_1 H_1 F_6 F_1 
Stack 15
H_6 K_2 H_4 Z_108 
Stack 16
E_4 J_2 J_0 I_0 
Stack 17
E_1 G_2 L_2 E_3 
Stack 18
J_1 A_1 I_3 N_3 
Stack 19
G_3 D_4 M_3 O_2 
Stack 20
H_8 E_6 C_1 D_0 
Stack 21
Z_109 I_1 I_7 J_6 
Stack 22
L_0 H_7 C_3 
Stack 23
O_1 M_1 L_3 
