Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
Z_100 E_1 F_7 C_1 
Stack 1
B_0 Z_101 D_5 C_3 
Stack 2
B_3 E_0 F_0 F_3 
Stack 3
B_2 G_6 A_3 E_2 
Stack 4
C_5 H_1 F_6 I_2 
Stack 5
D_3 E_7 Z_102 I_5 
Stack 6
E_6 C_2 I_3 B_4 
Stack 7
H_0 F_4 H_2 D_2 
Stack 8
F_2 E_8 J_1 A_2 
Stack 9
H_3 D_6 I_1 F_5 
Stack 10
A_1 D_0 Z_103 Z_104 
Stack 11
D_4 J_2 C_0 F_1 
Stack 12
D_1 G_0 A_0 G_2 
Stack 13
H_4 C_4 I_0 Z_105 
Stack 14
G_3 G_1 G_4 C_6 
Stack 15
Z_106 J_0 E_4 B_1 
Stack 16
G_5 B_5 I_4 
Stack 17
E_3 J_3 E_5 
