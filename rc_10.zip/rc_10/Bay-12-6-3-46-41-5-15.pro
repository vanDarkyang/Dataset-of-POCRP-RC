Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_9 B_14 C_9 C_10 
Stack 1
B_4 B_0 B_15 A_0 
Stack 2
A_7 C_0 Z_100 A_10 
Stack 3
B_3 Z_101 C_7 B_12 
Stack 4
C_3 B_2 C_13 A_1 
Stack 5
B_9 B_5 C_8 Z_102 
Stack 6
B_6 A_6 C_1 B_1 
Stack 7
Z_103 C_5 B_10 B_8 
Stack 8
A_8 A_2 C_12 B_7 
Stack 9
Z_104 C_6 B_11 B_13 
Stack 10
C_11 C_4 A_3 
Stack 11
A_5 A_4 C_2 
