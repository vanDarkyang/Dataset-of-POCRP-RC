Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_1 Z_100 G_5 H_0 
Stack 1
D_5 Z_101 A_1 F_4 
Stack 2
D_2 G_4 D_4 H_4 
Stack 3
F_1 G_3 F_5 E_5 
Stack 4
C_2 I_1 D_3 J_1 
Stack 5
F_3 E_2 D_0 F_6 
Stack 6
Z_102 H_2 E_0 A_2 
Stack 7
C_1 F_2 G_2 Z_103 
Stack 8
G_0 E_6 Z_104 A_0 
Stack 9
G_1 E_3 F_0 H_1 
Stack 10
C_0 B_3 B_0 D_1 
Stack 11
H_3 J_0 E_1 
Stack 12
E_4 B_2 I_0 
