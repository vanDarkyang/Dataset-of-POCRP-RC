Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
I_3 I_0 B_3 H_1 
Stack 1
D_2 G_3 G_2 F_5 
Stack 2
E_1 E_0 F_1 J_1 
Stack 3
D_4 Z_100 Z_101 H_4 
Stack 4
B_1 B_0 A_1 I_4 
Stack 5
C_1 F_6 A_2 I_1 
Stack 6
D_7 I_2 C_5 H_2 
Stack 7
D_0 E_4 I_5 D_5 
Stack 8
H_3 H_0 E_6 D_3 
Stack 9
H_6 G_0 C_4 E_2 
Stack 10
G_4 D_1 E_7 Z_102 
Stack 11
G_6 G_5 J_2 Z_103 
Stack 12
Z_104 D_6 J_3 Z_105 
Stack 13
F_2 C_2 G_1 F_4 
Stack 14
C_3 F_7 E_5 F_3 
Stack 15
H_5 B_2 J_4 J_0 
Stack 16
A_3 A_0 F_0 
Stack 17
Z_106 C_0 E_3 
