Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
Z_100 A_6 Z_101 A_5 Z_102 
Stack 1
A_0 D_7 E_9 B_7 C_3 
Stack 2
C_9 C_0 E_3 C_6 B_8 
Stack 3
C_7 E_0 E_6 B_0 B_1 
Stack 4
B_6 B_9 D_2 E_5 E_1 
Stack 5
Z_103 A_7 E_4 C_10 E_7 
Stack 6
B_5 D_8 E_2 A_2 C_4 
Stack 7
A_1 D_1 E_8 C_1 D_3 
Stack 8
D_6 B_2 C_2 B_3 C_5 
Stack 9
C_8 A_4 D_0 B_4 Z_104 
Stack 10
A_3 Z_105 D_4 D_5 
