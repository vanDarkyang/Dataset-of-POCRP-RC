Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
D_1 E_1 H_2 G_1 
Stack 1
D_0 G_4 G_0 D_5 
Stack 2
D_2 A_2 Z_100 C_0 
Stack 3
Z_101 E_5 J_0 Z_102 
Stack 4
F_4 C_3 I_1 J_1 
Stack 5
G_3 E_2 A_0 E_3 
Stack 6
C_2 C_1 I_0 I_2 
Stack 7
E_4 G_5 H_1 F_2 
Stack 8
D_3 B_0 Z_103 H_0 
Stack 9
C_4 F_0 Z_104 F_1 
Stack 10
B_1 A_1 F_3 G_2 
Stack 11
B_3 J_2 D_4 
Stack 12
E_0 H_3 B_2 
