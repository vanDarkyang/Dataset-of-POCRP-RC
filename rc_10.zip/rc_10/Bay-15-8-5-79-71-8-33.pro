Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_8 Z_100 C_12 D_0 A_6 B_9 
Stack 1
B_5 D_10 D_2 B_13 E_7 E_1 
Stack 2
B_4 E_3 Z_101 D_7 C_2 B_10 
Stack 3
D_3 A_5 D_12 C_7 B_14 B_11 
Stack 4
A_11 E_8 A_9 B_2 B_12 
Stack 5
A_4 B_8 C_5 A_2 E_10 
Stack 6
Z_102 Z_103 D_9 E_9 Z_104 
Stack 7
Z_105 B_1 B_15 C_14 B_6 
Stack 8
C_6 D_6 C_13 A_7 B_3 
Stack 9
C_1 A_3 A_0 C_9 D_1 
Stack 10
E_0 D_13 C_4 E_6 E_2 
Stack 11
Z_106 D_5 A_10 C_3 C_11 
Stack 12
D_4 C_0 C_15 D_8 C_10 
Stack 13
A_12 A_1 B_0 B_7 D_11 
Stack 14
E_5 C_16 A_8 E_4 Z_107 
