Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_6 B_7 C_2 A_8 
Stack 1
B_4 A_2 A_12 E_10 
Stack 2
B_3 B_1 C_13 C_1 
Stack 3
D_3 D_6 B_0 B_12 
Stack 4
A_13 A_4 A_10 B_10 
Stack 5
A_6 D_13 Z_100 Z_101 
Stack 6
A_5 D_4 B_11 E_12 
Stack 7
D_5 Z_102 D_7 B_5 
Stack 8
C_4 A_1 C_5 Z_103 
Stack 9
C_0 C_14 B_2 D_1 
Stack 10
E_0 C_10 A_3 E_2 
Stack 11
D_0 D_2 E_11 C_9 
Stack 12
Z_104 E_7 C_12 C_8 
Stack 13
A_14 D_12 A_9 D_11 
Stack 14
E_6 A_11 C_7 E_5 
Stack 15
E_9 C_3 E_8 B_8 
Stack 16
D_10 D_9 Z_105 E_1 
Stack 17
E_3 B_13 D_8 Z_106 
Stack 18
A_7 C_11 B_6 B_9 
Stack 19
Z_107 A_0 E_4 
