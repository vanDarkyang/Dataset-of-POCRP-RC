Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_0 C_2 H_4 G_1 
Stack 1
H_2 F_1 H_0 F_5 
Stack 2
D_2 D_3 Z_100 A_2 
Stack 3
D_4 E_5 E_3 F_3 
Stack 4
I_0 Z_101 J_2 B_1 
Stack 5
Z_102 Z_103 F_2 E_0 
Stack 6
F_6 G_3 F_4 D_1 
Stack 7
I_1 G_4 F_0 J_1 
Stack 8
H_3 G_0 C_3 Z_104 
Stack 9
E_4 B_2 G_2 J_0 
Stack 10
E_1 A_1 H_1 E_2 
Stack 11
D_0 B_0 D_5 
Stack 12
C_1 C_0 B_3 
