Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
A_1 A_3 H_0 G_6 
Stack 1
B_0 D_4 F_5 H_1 
Stack 2
Z_100 H_2 C_0 J_2 
Stack 3
D_5 I_1 G_5 I_5 
Stack 4
E_0 J_4 B_5 Z_101 
Stack 5
Z_102 B_1 D_2 A_2 
Stack 6
G_0 C_1 D_0 C_2 
Stack 7
H_6 G_2 F_3 I_4 
Stack 8
I_0 I_2 G_7 G_4 
Stack 9
E_1 C_4 I_3 D_3 
Stack 10
E_2 F_2 A_4 J_3 
Stack 11
D_1 Z_103 J_1 G_3 
Stack 12
H_4 A_0 G_1 D_6 
Stack 13
Z_104 J_0 B_2 B_4 
Stack 14
E_4 E_3 H_3 H_5 
Stack 15
B_3 F_4 Z_105 F_6 
Stack 16
C_3 Z_106 F_0 
Stack 17
F_1 C_5 E_5 
