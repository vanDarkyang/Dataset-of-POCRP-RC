Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
H_3 E_3 E_2 E_0 
Stack 1
F_6 F_1 H_1 D_2 
Stack 2
G_2 D_4 Z_100 E_4 
Stack 3
C_0 J_0 H_4 I_0 
Stack 4
A_0 B_0 D_3 E_5 
Stack 5
Z_101 I_2 G_1 G_3 
Stack 6
I_1 E_1 B_1 F_3 
Stack 7
C_2 A_2 G_4 D_1 
Stack 8
J_2 H_0 F_5 F_2 
Stack 9
Z_102 F_4 I_3 A_1 
Stack 10
F_0 D_0 Z_103 C_1 
Stack 11
Z_104 J_1 C_4 
Stack 12
H_2 G_0 C_3 
