Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_1 C_0 C_5 C_8 C_1 A_3 
Stack 1
A_5 D_2 D_1 E_10 A_0 B_8 
Stack 2
C_13 Z_100 Z_101 E_5 C_10 Z_102 
Stack 3
A_7 E_0 C_12 D_5 B_13 B_11 
Stack 4
B_10 B_2 D_11 D_13 D_4 
Stack 5
Z_103 C_6 A_8 E_3 A_6 
Stack 6
Z_104 D_14 D_3 E_6 E_8 
Stack 7
B_1 C_2 B_5 D_12 E_4 
Stack 8
B_0 C_4 D_15 E_7 A_12 
Stack 9
D_9 D_0 B_9 C_3 A_2 
Stack 10
B_4 E_11 B_12 D_8 E_12 
Stack 11
D_6 Z_105 E_1 Z_106 A_11 
Stack 12
Z_107 C_7 D_7 A_10 C_9 
Stack 13
E_13 D_10 B_3 A_9 C_11 
Stack 14
A_4 B_7 B_6 E_2 E_9 
