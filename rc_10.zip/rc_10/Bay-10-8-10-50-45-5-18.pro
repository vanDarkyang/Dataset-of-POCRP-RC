Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
J_0 C_3 D_0 I_1 F_2 
Stack 1
E_3 H_3 F_3 E_1 H_0 
Stack 2
D_1 H_1 F_0 D_4 D_3 
Stack 3
Z_100 A_0 G_0 G_2 C_4 
Stack 4
D_5 D_2 C_0 B_1 E_6 
Stack 5
G_4 F_4 G_1 H_2 H_4 
Stack 6
F_5 J_1 Z_101 E_4 C_1 
Stack 7
B_0 A_2 I_0 A_1 E_5 
Stack 8
Z_102 B_2 F_1 G_3 E_0 
Stack 9
Z_103 I_2 C_2 Z_104 E_2 
