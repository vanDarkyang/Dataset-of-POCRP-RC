Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_3 B_13 C_9 B_8 
Stack 1
B_5 B_4 A_2 A_6 
Stack 2
B_9 B_3 A_1 C_11 
Stack 3
B_15 B_2 Z_100 Z_101 
Stack 4
A_12 B_7 B_1 Z_102 
Stack 5
A_0 B_10 C_10 Z_103 
Stack 6
B_0 C_2 A_10 A_8 
Stack 7
C_7 A_11 Z_104 A_4 
Stack 8
B_11 C_1 B_12 C_6 
Stack 9
A_9 C_8 C_0 C_4 
Stack 10
B_14 A_7 A_5 
Stack 11
C_5 B_6 A_3 
