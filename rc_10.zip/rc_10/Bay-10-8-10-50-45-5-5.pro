Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
F_6 Z_100 D_4 F_0 A_1 
Stack 1
D_3 F_1 C_1 I_2 Z_101 
Stack 2
E_5 Z_102 G_2 H_0 Z_103 
Stack 3
J_1 D_2 I_0 J_0 I_1 
Stack 4
G_4 H_4 E_1 H_1 G_0 
Stack 5
C_2 G_3 E_3 F_5 F_4 
Stack 6
Z_104 F_3 F_2 E_0 H_2 
Stack 7
D_1 B_3 C_0 B_2 D_0 
Stack 8
H_3 E_2 A_0 A_2 G_1 
Stack 9
C_4 E_4 C_3 B_1 B_0 
