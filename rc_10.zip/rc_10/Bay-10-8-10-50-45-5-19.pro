Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_0 D_0 G_4 G_2 E_2 
Stack 1
H_1 C_0 I_2 J_2 F_2 
Stack 2
F_1 D_2 A_0 H_3 Z_100 
Stack 3
G_5 H_0 I_1 D_5 I_0 
Stack 4
Z_101 G_3 C_2 F_6 E_0 
Stack 5
F_4 D_1 E_3 H_2 Z_102 
Stack 6
A_2 D_4 Z_103 A_1 C_3 
Stack 7
D_3 B_1 J_1 F_5 C_1 
Stack 8
J_0 F_0 F_3 B_2 Z_104 
Stack 9
H_4 E_1 G_1 G_0 B_3 
