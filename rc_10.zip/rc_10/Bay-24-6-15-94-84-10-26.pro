Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
D_2 L_3 E_0 K_2 
Stack 1
E_1 D_0 Z_100 N_0 
Stack 2
J_3 I_3 D_3 I_1 
Stack 3
E_5 I_6 I_5 J_0 
Stack 4
G_2 E_3 C_2 G_1 
Stack 5
F_3 H_5 F_7 D_1 
Stack 6
H_4 H_8 C_1 H_0 
Stack 7
I_4 O_0 M_0 Z_101 
Stack 8
H_3 G_0 F_2 F_6 
Stack 9
F_0 B_0 M_2 F_1 
Stack 10
L_0 A_2 E_4 L_4 
Stack 11
L_5 Z_102 C_4 J_2 
Stack 12
N_1 E_2 Z_103 H_1 
Stack 13
J_1 M_3 K_3 G_4 
Stack 14
Z_104 J_4 C_3 Z_105 
Stack 15
Z_106 K_1 C_0 I_0 
Stack 16
J_6 G_5 Z_107 M_1 
Stack 17
Z_108 O_1 L_2 F_5 
Stack 18
D_4 I_7 N_2 A_0 
Stack 19
F_4 K_5 B_2 A_1 
Stack 20
K_0 G_3 G_6 H_2 
Stack 21
Z_109 H_7 K_4 G_7 
Stack 22
H_6 B_3 L_1 
Stack 23
I_2 J_5 B_1 
