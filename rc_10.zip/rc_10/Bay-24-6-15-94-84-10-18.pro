Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
M_0 M_2 F_0 L_4 
Stack 1
C_1 D_4 N_0 K_6 
Stack 2
H_3 J_4 H_7 J_5 
Stack 3
C_0 I_7 G_4 L_0 
Stack 4
G_2 Z_100 H_2 M_3 
Stack 5
H_4 K_0 G_1 F_4 
Stack 6
D_0 I_5 O_2 D_5 
Stack 7
Z_101 O_1 A_2 L_1 
Stack 8
I_6 H_1 E_4 E_0 
Stack 9
Z_102 E_2 G_0 Z_103 
Stack 10
C_3 G_5 B_0 I_8 
Stack 11
E_3 M_4 A_1 Z_104 
Stack 12
Z_105 J_1 B_2 H_0 
Stack 13
I_1 G_7 N_1 F_2 
Stack 14
D_3 L_5 F_3 A_0 
Stack 15
K_2 K_1 Z_106 H_6 
Stack 16
B_1 D_1 K_4 O_0 
Stack 17
F_1 J_3 G_3 M_1 
Stack 18
I_3 I_4 L_3 B_3 
Stack 19
H_5 Z_107 E_5 I_2 
Stack 20
D_2 K_5 G_6 N_2 
Stack 21
Z_108 H_8 L_2 E_1 
Stack 22
C_2 J_0 K_3 
Stack 23
Z_109 I_0 J_2 
