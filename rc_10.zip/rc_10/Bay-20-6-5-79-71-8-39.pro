Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_4 B_10 B_9 C_3 
Stack 1
A_10 Z_100 B_1 E_1 
Stack 2
D_4 D_10 D_6 B_0 
Stack 3
C_2 A_1 C_15 C_9 
Stack 4
D_5 B_2 C_1 B_7 
Stack 5
D_2 A_5 D_11 E_11 
Stack 6
D_3 A_3 A_4 B_13 
Stack 7
C_11 E_7 A_0 D_14 
Stack 8
B_5 A_9 C_14 E_10 
Stack 9
D_0 E_9 E_6 C_8 
Stack 10
A_6 A_11 A_2 B_8 
Stack 11
E_8 Z_101 A_7 E_5 
Stack 12
B_6 Z_102 D_9 B_14 
Stack 13
E_4 C_10 C_7 B_4 
Stack 14
Z_103 E_12 C_12 B_3 
Stack 15
D_13 C_0 D_1 A_8 
Stack 16
B_12 C_13 D_7 D_8 
Stack 17
D_12 E_2 B_11 Z_104 
Stack 18
Z_105 E_0 C_6 Z_106 
Stack 19
Z_107 E_3 C_5 
