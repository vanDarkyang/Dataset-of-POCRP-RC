Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
F_6 Z_100 F_2 Z_101 
Stack 1
D_2 H_4 C_0 A_1 
Stack 2
E_5 G_3 A_0 I_2 
Stack 3
J_2 F_3 Z_102 D_4 
Stack 4
G_4 B_1 F_0 I_1 
Stack 5
C_2 E_2 I_3 G_0 
Stack 6
E_3 E_4 H_0 F_4 
Stack 7
D_1 D_3 J_1 H_2 
Stack 8
H_3 C_1 H_1 D_0 
Stack 9
C_3 G_2 F_5 G_1 
Stack 10
J_0 I_0 E_0 B_0 
Stack 11
F_1 E_1 Z_103 
Stack 12
G_5 Z_104 A_2 
