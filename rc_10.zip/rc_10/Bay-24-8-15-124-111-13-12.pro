Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
A_1 Z_100 E_0 O_2 N_5 H_4 
Stack 1
N_3 J_4 N_4 M_3 I_0 Z_101 
Stack 2
F_2 O_0 I_1 I_8 G_3 G_6 
Stack 3
L_6 Z_102 L_2 M_5 G_2 I_4 
Stack 4
E_3 F_1 J_7 L_0 A_3 
Stack 5
H_7 F_0 L_1 F_4 F_7 
Stack 6
D_0 F_5 D_2 B_4 E_2 
Stack 7
M_0 E_7 K_8 O_3 L_5 
Stack 8
C_2 I_2 H_6 G_5 M_2 
Stack 9
B_2 Z_103 H_8 A_4 K_6 
Stack 10
J_5 Z_104 J_1 M_1 C_1 
Stack 11
E_8 Z_105 B_1 Z_106 M_4 
Stack 12
H_1 O_1 H_0 M_6 H_3 
Stack 13
H_9 F_6 E_6 J_3 N_0 
Stack 14
Z_107 F_3 K_2 K_4 G_8 
Stack 15
C_5 C_0 D_6 E_4 N_1 
Stack 16
B_0 L_4 C_3 L_3 D_1 
Stack 17
K_0 G_1 K_3 O_4 I_5 
Stack 18
G_0 D_4 I_6 D_7 K_7 
Stack 19
Z_108 K_5 D_5 B_3 J_2 
Stack 20
E_5 H_2 Z_109 D_3 E_1 
Stack 21
I_7 H_5 K_1 A_0 C_4 
Stack 22
Z_110 Z_111 A_2 G_7 G_4 
Stack 23
N_2 J_0 Z_112 J_6 I_3 
