Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
N_1 F_5 G_1 J_0 M_3 Z_100 
Stack 1
Z_101 E_1 H_5 D_1 A_1 O_2 
Stack 2
I_2 I_1 D_2 K_2 J_3 M_2 
Stack 3
E_5 G_0 F_6 D_3 C_3 F_4 
Stack 4
H_4 Z_102 H_0 H_7 J_4 
Stack 5
Z_103 F_2 D_4 A_0 H_8 
Stack 6
J_5 N_0 G_5 Z_104 K_0 
Stack 7
C_2 D_0 L_2 J_1 F_0 
Stack 8
I_0 G_3 I_3 Z_105 M_0 
Stack 9
Z_106 I_5 F_3 I_6 C_4 
Stack 10
A_2 G_2 L_3 L_1 Z_107 
Stack 11
B_1 C_0 B_0 H_3 G_4 
Stack 12
C_1 E_3 N_3 K_5 I_7 
Stack 13
M_1 I_8 K_1 J_6 K_3 
Stack 14
I_4 Z_108 E_2 E_4 K_4 
Stack 15
G_7 H_2 E_0 H_9 G_6 
Stack 16
F_1 Z_109 J_2 H_1 N_2 
Stack 17
H_6 L_4 O_1 L_0 O_0 
