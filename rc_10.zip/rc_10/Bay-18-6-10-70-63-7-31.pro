Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
J_1 I_2 D_4 C_1 
Stack 1
H_1 J_4 G_3 E_4 
Stack 2
D_3 Z_100 G_5 I_0 
Stack 3
B_0 Z_101 Z_102 H_4 
Stack 4
G_0 J_0 I_1 C_4 
Stack 5
F_1 G_6 B_2 F_5 
Stack 6
C_3 D_5 E_3 F_0 
Stack 7
C_5 E_6 D_2 F_6 
Stack 8
Z_103 J_2 H_2 A_2 
Stack 9
A_3 D_6 A_1 Z_104 
Stack 10
E_8 C_2 F_2 F_7 
Stack 11
C_6 Z_105 G_4 A_0 
Stack 12
I_3 F_3 E_5 E_7 
Stack 13
B_3 A_4 B_1 H_0 
Stack 14
H_3 F_4 I_4 Z_106 
Stack 15
G_1 E_0 G_2 B_4 
Stack 16
E_2 E_1 J_3 
Stack 17
D_0 D_1 C_0 
