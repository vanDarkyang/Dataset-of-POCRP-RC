Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
E_11 Z_100 F_6 C_3 B_1 Z_101 
Stack 1
F_3 E_4 Z_102 I_3 B_5 A_3 
Stack 2
J_1 H_7 E_3 J_4 E_6 F_4 
Stack 3
C_8 D_2 B_2 F_1 H_9 G_3 
Stack 4
I_9 A_5 H_3 B_9 B_6 I_10 
Stack 5
B_3 A_4 G_9 D_8 G_1 
Stack 6
A_0 B_10 D_11 B_4 D_0 
Stack 7
F_0 I_0 E_1 E_2 C_5 
Stack 8
H_8 D_9 F_9 C_0 J_6 
Stack 9
A_6 G_2 A_7 H_2 G_7 
Stack 10
D_4 E_7 G_5 C_4 C_2 
Stack 11
D_6 F_5 F_11 Z_103 G_10 
Stack 12
J_3 E_0 D_3 H_1 E_8 
Stack 13
Z_104 F_10 Z_105 F_8 Z_106 
Stack 14
I_2 C_7 H_6 Z_107 J_8 
Stack 15
D_1 G_4 I_8 H_0 G_11 
Stack 16
G_6 I_4 B_8 I_5 A_2 
Stack 17
C_1 F_7 G_8 C_10 D_10 
Stack 18
E_9 I_6 Z_108 Z_109 C_6 
Stack 19
J_0 C_9 I_1 A_1 B_0 
Stack 20
J_7 D_5 D_7 J_2 J_5 
Stack 21
E_5 B_7 E_10 I_7 Z_110 
Stack 22
G_0 F_2 H_4 Z_111 H_5 
