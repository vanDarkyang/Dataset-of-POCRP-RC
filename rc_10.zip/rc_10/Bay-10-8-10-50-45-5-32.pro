Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
H_1 I_0 I_3 I_1 A_0 
Stack 1
F_4 A_1 C_0 C_1 Z_100 
Stack 2
D_4 J_2 H_2 C_2 D_2 
Stack 3
Z_101 E_1 G_3 A_2 H_3 
Stack 4
J_0 C_3 F_3 D_1 B_3 
Stack 5
E_3 F_1 E_4 B_1 G_1 
Stack 6
I_2 E_5 Z_102 Z_103 J_1 
Stack 7
F_0 E_0 D_0 Z_104 G_0 
Stack 8
D_3 F_5 F_2 E_6 G_4 
Stack 9
G_2 H_0 B_0 B_2 E_2 
