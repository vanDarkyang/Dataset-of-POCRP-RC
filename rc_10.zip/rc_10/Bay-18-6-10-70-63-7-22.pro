Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
G_0 D_3 I_2 F_3 
Stack 1
D_4 Z_100 H_4 A_1 
Stack 2
F_6 F_2 F_4 B_2 
Stack 3
J_1 H_3 B_0 E_4 
Stack 4
F_0 D_6 Z_101 G_4 
Stack 5
F_5 J_2 G_2 C_0 
Stack 6
Z_102 H_2 I_3 C_3 
Stack 7
F_7 D_0 A_3 E_6 
Stack 8
B_5 E_5 B_1 E_1 
Stack 9
E_2 F_1 I_4 C_4 
Stack 10
Z_103 J_0 G_6 J_4 
Stack 11
G_3 G_5 D_2 I_5 
Stack 12
Z_104 C_2 A_2 A_0 
Stack 13
I_1 E_0 D_5 E_3 
Stack 14
C_5 H_0 G_7 I_0 
Stack 15
J_3 B_3 H_5 D_1 
Stack 16
C_1 B_4 Z_105 
Stack 17
H_1 Z_106 G_1 
