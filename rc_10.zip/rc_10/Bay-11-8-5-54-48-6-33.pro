Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_2 Z_100 D_6 Z_101 C_2 
Stack 1
D_1 C_4 B_5 E_9 Z_102 
Stack 2
B_0 E_1 B_2 C_11 A_5 
Stack 3
B_3 A_2 C_7 B_7 D_2 
Stack 4
D_8 C_9 D_4 D_7 Z_103 
Stack 5
A_6 E_3 C_10 B_4 D_0 
Stack 6
A_1 E_4 D_5 Z_104 D_3 
Stack 7
A_4 C_3 B_8 C_0 Z_105 
Stack 8
E_7 C_8 E_6 E_5 B_6 
Stack 9
A_7 E_0 C_6 B_1 E_8 
Stack 10
A_0 C_1 C_5 A_3 
