Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
Z_100 D_0 E_3 D_2 
Stack 1
C_2 E_1 E_2 F_0 
Stack 2
B_0 J_2 B_2 A_2 
Stack 3
B_3 I_1 H_1 F_3 
Stack 4
I_0 Z_101 G_0 D_3 
Stack 5
A_0 Z_102 A_1 E_0 
Stack 6
I_2 E_4 C_1 H_3 
Stack 7
D_4 F_1 Z_103 H_2 
Stack 8
C_0 G_4 F_5 H_0 
Stack 9
F_4 G_1 B_1 F_6 
Stack 10
J_1 F_2 I_3 J_0 
Stack 11
H_4 G_3 Z_104 
Stack 12
G_5 G_2 D_1 
