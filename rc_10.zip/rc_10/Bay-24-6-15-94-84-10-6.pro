Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_3 L_0 K_4 K_3 
Stack 1
A_0 H_3 I_4 L_1 
Stack 2
E_0 J_4 H_6 G_0 
Stack 3
I_6 H_0 I_1 H_5 
Stack 4
N_0 L_5 E_5 L_4 
Stack 5
F_1 E_4 G_6 Z_100 
Stack 6
C_1 H_2 F_4 Z_101 
Stack 7
D_4 B_1 K_1 F_5 
Stack 8
J_5 D_3 C_0 Z_102 
Stack 9
Z_103 Z_104 O_0 D_2 
Stack 10
J_6 O_1 E_2 F_2 
Stack 11
H_4 Z_105 H_7 Z_106 
Stack 12
J_3 I_0 B_3 Z_107 
Stack 13
G_4 F_0 B_2 K_0 
Stack 14
M_0 Z_108 J_1 M_1 
Stack 15
C_4 Z_109 A_1 K_2 
Stack 16
D_0 L_2 B_0 M_4 
Stack 17
I_3 I_2 G_3 N_3 
Stack 18
G_2 E_3 C_3 N_2 
Stack 19
L_3 J_2 D_5 N_1 
Stack 20
F_6 E_1 M_2 H_1 
Stack 21
K_5 D_1 J_0 E_6 
Stack 22
G_1 G_5 K_6 
Stack 23
C_2 I_5 M_3 
