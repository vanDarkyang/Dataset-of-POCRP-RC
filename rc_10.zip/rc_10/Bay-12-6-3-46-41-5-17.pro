Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
Z_100 B_6 B_12 A_0 
Stack 1
B_2 A_11 Z_101 Z_102 
Stack 2
C_4 B_9 A_8 C_1 
Stack 3
B_5 B_13 C_12 C_10 
Stack 4
C_6 Z_103 C_9 C_11 
Stack 5
B_11 A_9 C_13 A_7 
Stack 6
C_2 C_3 C_0 B_3 
Stack 7
A_6 C_7 A_1 B_0 
Stack 8
B_4 B_14 C_5 A_5 
Stack 9
A_4 Z_104 B_1 A_3 
Stack 10
B_7 B_10 A_2 
Stack 11
B_8 C_8 A_10 
