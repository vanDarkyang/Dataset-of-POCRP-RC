Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_3 B_6 E_4 B_9 
Stack 1
D_0 B_7 C_1 Z_100 
Stack 2
E_1 C_0 C_3 D_7 
Stack 3
D_5 A_3 E_8 D_8 
Stack 4
B_2 Z_101 D_3 B_5 
Stack 5
A_1 C_4 A_4 B_8 
Stack 6
B_0 E_7 A_0 A_5 
Stack 7
E_5 A_8 D_4 C_6 
Stack 8
D_2 C_8 A_6 E_2 
Stack 9
Z_102 A_2 C_5 D_9 
Stack 10
E_6 Z_103 D_6 C_9 
Stack 11
B_4 C_2 E_0 C_7 
Stack 12
A_7 D_1 Z_104 
Stack 13
E_3 B_1 Z_105 
