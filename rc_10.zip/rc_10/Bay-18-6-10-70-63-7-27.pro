Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_7 F_6 D_1 H_2 
Stack 1
E_4 C_3 E_2 D_5 
Stack 2
J_1 E_6 J_4 F_2 
Stack 3
J_0 B_5 D_2 J_3 
Stack 4
D_4 Z_100 E_0 E_7 
Stack 5
E_5 H_6 H_0 I_4 
Stack 6
D_6 F_7 H_3 B_1 
Stack 7
I_3 J_2 B_2 G_4 
Stack 8
H_5 F_0 B_0 C_2 
Stack 9
G_6 A_1 Z_101 Z_102 
Stack 10
G_3 Z_103 F_1 H_1 
Stack 11
H_4 A_0 Z_104 B_3 
Stack 12
G_1 A_2 G_5 D_0 
Stack 13
Z_105 F_4 I_2 D_3 
Stack 14
E_1 C_4 Z_106 F_5 
Stack 15
F_3 B_4 E_3 I_1 
Stack 16
G_2 G_0 C_0 
Stack 17
C_1 F_8 I_0 
