Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
I_7 J_3 E_0 D_4 Z_100 F_6 
Stack 1
J_6 E_8 I_4 E_6 B_9 F_8 
Stack 2
B_8 B_4 B_7 E_7 I_9 J_8 
Stack 3
Z_101 F_2 D_11 G_1 G_6 G_10 
Stack 4
A_0 G_5 C_3 G_2 E_10 D_10 
Stack 5
D_1 C_1 G_4 G_7 Z_102 
Stack 6
E_4 D_5 C_5 C_7 D_0 
Stack 7
E_1 D_7 H_6 J_0 D_2 
Stack 8
Z_103 A_1 Z_104 H_0 H_5 
Stack 9
B_1 A_3 E_11 C_9 C_2 
Stack 10
H_2 G_0 Z_105 C_8 H_1 
Stack 11
D_8 B_2 E_5 D_3 C_6 
Stack 12
E_12 G_9 I_5 Z_106 H_3 
Stack 13
H_8 C_0 Z_107 I_1 J_5 
Stack 14
J_9 Z_108 F_7 E_9 F_4 
Stack 15
Z_109 C_4 F_0 J_4 J_2 
Stack 16
J_7 Z_110 B_3 I_6 A_5 
Stack 17
F_11 E_2 I_0 G_3 F_10 
Stack 18
E_3 A_6 I_2 A_4 B_6 
Stack 19
C_10 A_2 G_8 B_5 I_8 
Stack 20
H_4 B_0 Z_111 J_1 H_7 
Stack 21
G_12 D_6 H_9 F_5 G_11 
Stack 22
D_9 F_1 F_3 F_9 I_3 
