Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
J_3 D_1 Z_100 Z_101 F_5 
Stack 1
E_4 F_1 D_0 I_4 A_3 
Stack 2
I_3 B_4 G_4 G_0 I_1 
Stack 3
Z_102 D_2 F_0 J_2 J_1 
Stack 4
A_1 D_4 D_3 D_6 G_6 
Stack 5
B_2 I_0 C_0 D_5 G_3 
Stack 6
H_3 Z_103 C_2 Z_104 Z_105 
Stack 7
B_0 E_2 H_1 H_2 F_7 
Stack 8
A_0 B_3 E_6 H_5 E_1 
Stack 9
F_4 E_0 B_5 A_4 C_5 
Stack 10
F_3 H_0 Z_106 C_1 B_1 
Stack 11
E_7 G_5 A_2 E_8 E_3 
Stack 12
C_3 F_6 G_2 F_2 E_5 
Stack 13
H_4 C_4 I_2 J_0 G_1 
