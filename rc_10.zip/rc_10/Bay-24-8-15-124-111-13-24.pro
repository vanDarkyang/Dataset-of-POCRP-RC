Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
F_0 E_6 H_7 O_4 A_2 G_6 
Stack 1
G_2 G_5 H_10 D_4 B_0 K_1 
Stack 2
C_2 H_6 B_2 K_4 J_5 F_1 
Stack 3
M_5 C_5 D_1 L_6 G_8 H_3 
Stack 4
H_4 J_4 L_1 L_4 I_1 
Stack 5
H_0 C_6 N_5 M_1 E_0 
Stack 6
H_5 F_4 Z_100 I_3 Z_101 
Stack 7
E_1 N_2 H_1 Z_102 G_0 
Stack 8
I_4 B_1 L_3 J_6 B_3 
Stack 9
F_5 E_5 K_0 K_6 H_2 
Stack 10
B_5 L_5 H_8 I_2 Z_103 
Stack 11
G_7 G_9 C_1 M_4 O_1 
Stack 12
N_3 N_0 Z_104 M_2 O_2 
Stack 13
D_0 A_3 Z_105 O_3 I_0 
Stack 14
G_3 J_1 F_2 K_3 J_7 
Stack 15
D_2 G_4 Z_106 M_3 B_4 
Stack 16
G_10 Z_107 M_0 I_8 N_1 
Stack 17
J_0 G_1 O_0 C_0 H_9 
Stack 18
L_2 I_7 E_4 Z_108 A_1 
Stack 19
C_3 I_5 Z_109 E_2 F_3 
Stack 20
I_9 Z_110 D_3 L_0 E_7 
Stack 21
J_3 N_4 F_6 D_5 I_6 
Stack 22
E_3 C_4 Z_111 F_7 Z_112 
Stack 23
K_2 A_0 D_6 J_2 K_5 
