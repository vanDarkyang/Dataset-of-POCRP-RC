Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
G_5 I_1 D_2 Z_100 J_0 
Stack 1
A_1 E_6 C_4 H_6 Z_101 
Stack 2
D_4 F_1 E_4 D_1 E_2 
Stack 3
Z_102 B_3 B_1 E_1 J_2 
Stack 4
H_4 Z_103 G_3 B_4 D_5 
Stack 5
F_3 Z_104 F_4 I_2 H_0 
Stack 6
C_0 A_2 C_2 F_5 Z_105 
Stack 7
G_2 C_1 E_7 H_2 I_0 
Stack 8
A_0 B_0 H_5 I_3 D_6 
Stack 9
B_5 H_3 Z_106 E_5 E_3 
Stack 10
B_2 G_0 F_6 F_0 J_3 
Stack 11
I_4 C_3 G_4 F_2 D_7 
Stack 12
E_0 F_7 J_4 D_3 G_1 
Stack 13
D_0 I_5 J_1 C_5 H_1 
