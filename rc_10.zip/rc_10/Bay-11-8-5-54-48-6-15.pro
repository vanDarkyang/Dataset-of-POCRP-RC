Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_2 B_3 C_3 A_0 Z_100 
Stack 1
E_0 Z_101 D_2 A_9 E_1 
Stack 2
C_0 C_9 D_4 D_7 B_8 
Stack 3
A_5 C_10 D_6 E_3 A_4 
Stack 4
E_5 A_8 D_8 Z_102 C_2 
Stack 5
E_4 D_5 B_5 E_6 B_7 
Stack 6
A_1 A_7 D_1 D_9 A_2 
Stack 7
B_6 Z_103 Z_104 D_3 Z_105 
Stack 8
C_1 C_5 C_4 E_2 A_3 
Stack 9
B_4 B_0 C_6 B_1 C_8 
Stack 10
C_11 C_7 D_0 A_6 
