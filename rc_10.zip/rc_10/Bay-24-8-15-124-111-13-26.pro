Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
Z_100 L_0 Z_101 F_2 B_5 K_1 
Stack 1
D_3 Z_102 G_4 O_0 E_0 E_4 
Stack 2
E_3 H_8 H_9 G_1 Z_103 N_3 
Stack 3
L_6 H_11 B_4 Z_104 C_2 J_6 
Stack 4
L_3 F_7 I_3 L_7 I_0 
Stack 5
Z_105 L_4 A_0 I_4 J_7 
Stack 6
B_0 J_3 F_5 N_0 H_1 
Stack 7
H_7 Z_106 B_1 M_5 J_2 
Stack 8
C_3 C_4 M_3 N_2 L_5 
Stack 9
K_2 K_6 I_2 G_3 F_9 
Stack 10
M_1 G_9 C_0 G_8 J_5 
Stack 11
K_7 A_1 M_0 J_0 F_0 
Stack 12
L_1 D_0 N_4 L_2 Z_107 
Stack 13
D_5 H_0 D_4 F_3 E_5 
Stack 14
F_1 G_6 G_7 H_5 G_5 
Stack 15
K_5 B_2 F_6 J_1 C_1 
Stack 16
M_2 H_6 Z_108 Z_109 F_8 
Stack 17
H_2 I_6 J_8 O_3 A_3 
Stack 18
I_1 E_1 Z_110 D_2 O_1 
Stack 19
A_4 G_0 O_2 E_6 I_7 
Stack 20
B_3 J_9 Z_111 E_2 H_4 
Stack 21
G_2 J_4 H_3 K_0 A_2 
Stack 22
F_4 I_5 N_1 Z_112 K_3 
Stack 23
D_1 H_10 I_8 K_4 M_4 
