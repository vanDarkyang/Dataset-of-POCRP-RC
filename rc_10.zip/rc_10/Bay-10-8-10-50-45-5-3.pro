Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
F_4 D_0 B_1 F_1 I_1 
Stack 1
F_3 H_1 F_2 J_1 C_0 
Stack 2
J_0 D_2 H_0 E_3 Z_100 
Stack 3
I_0 G_4 F_6 E_6 H_2 
Stack 4
C_3 E_1 D_4 F_5 Z_101 
Stack 5
F_0 G_1 B_2 G_5 I_2 
Stack 6
A_0 Z_102 D_3 Z_103 D_1 
Stack 7
C_1 G_2 I_3 E_0 C_4 
Stack 8
G_3 E_4 G_0 E_5 E_2 
Stack 9
H_3 B_0 C_2 Z_104 H_4 
