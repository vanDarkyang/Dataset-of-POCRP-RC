Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
Z_100 Z_101 C_4 A_0 
Stack 1
A_2 C_7 B_10 B_9 
Stack 2
A_9 C_5 Z_102 B_6 
Stack 3
B_4 C_1 C_0 B_7 
Stack 4
B_12 A_6 A_4 C_3 
Stack 5
A_10 C_8 A_7 C_2 
Stack 6
B_11 B_5 B_2 C_6 
Stack 7
C_13 A_8 A_5 A_11 
Stack 8
B_13 C_10 B_8 B_3 
Stack 9
C_12 C_9 Z_103 A_3 
Stack 10
B_0 Z_104 B_1 
Stack 11
A_12 C_11 A_1 
