Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_2 Z_100 A_9 E_5 
Stack 1
E_7 E_0 Z_101 D_9 
Stack 2
C_15 B_1 Z_102 B_4 
Stack 3
D_10 B_11 C_14 C_3 
Stack 4
E_8 Z_103 A_10 B_2 
Stack 5
D_0 A_5 A_6 E_9 
Stack 6
A_7 C_13 Z_104 A_0 
Stack 7
C_11 C_6 B_7 D_3 
Stack 8
B_5 C_0 Z_105 E_12 
Stack 9
D_11 D_4 B_12 C_1 
Stack 10
B_3 C_4 B_10 C_10 
Stack 11
B_13 A_3 E_6 E_3 
Stack 12
E_11 A_4 A_13 C_8 
Stack 13
A_12 E_2 A_1 D_2 
Stack 14
D_6 A_8 B_8 B_0 
Stack 15
D_12 E_10 C_9 Z_106 
Stack 16
C_12 C_7 C_5 E_4 
Stack 17
B_6 D_8 B_9 D_7 
Stack 18
D_1 E_1 Z_107 B_14 
Stack 19
A_2 D_5 A_11 
