Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
J_3 O_0 B_0 D_0 
Stack 1
H_5 F_3 C_4 I_4 
Stack 2
D_1 I_7 E_1 K_0 
Stack 3
Z_100 Z_101 J_7 F_1 
Stack 4
Z_102 Z_103 E_4 H_8 
Stack 5
I_3 E_3 D_5 M_2 
Stack 6
B_3 H_6 N_3 Z_104 
Stack 7
E_0 K_3 H_3 H_4 
Stack 8
H_7 D_3 K_2 C_0 
Stack 9
G_4 G_6 L_3 F_5 
Stack 10
G_1 E_2 Z_105 J_4 
Stack 11
J_6 A_1 I_5 F_0 
Stack 12
Z_106 L_1 I_1 G_2 
Stack 13
A_2 L_2 Z_107 J_0 
Stack 14
G_0 O_2 J_1 E_5 
Stack 15
J_5 J_2 B_2 D_2 
Stack 16
A_0 B_1 Z_108 M_1 
Stack 17
C_2 H_2 L_0 M_0 
Stack 18
G_5 I_2 H_1 G_7 
Stack 19
K_4 C_1 D_4 M_3 
Stack 20
G_3 O_1 F_4 F_2 
Stack 21
Z_109 N_0 C_3 N_1 
Stack 22
H_0 K_1 I_0 
Stack 23
K_5 I_6 N_2 
