Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
N_1 G_0 J_7 J_2 
Stack 1
C_3 J_3 J_0 K_5 
Stack 2
G_4 H_1 I_4 H_4 
Stack 3
Z_100 N_0 K_6 Z_101 
Stack 4
K_3 E_0 F_4 N_2 
Stack 5
Z_102 A_1 M_1 A_0 
Stack 6
G_3 Z_103 K_2 M_4 
Stack 7
D_0 H_9 H_6 B_0 
Stack 8
F_3 J_4 C_0 Z_104 
Stack 9
L_0 I_7 H_5 C_1 
Stack 10
L_2 G_1 G_2 Z_105 
Stack 11
I_0 I_8 K_0 J_6 
Stack 12
G_6 B_2 E_2 G_5 
Stack 13
Z_106 G_7 D_1 E_5 
Stack 14
I_2 Z_107 K_1 B_1 
Stack 15
I_5 N_3 K_4 O_0 
Stack 16
M_3 J_1 Z_108 D_2 
Stack 17
H_2 H_7 I_3 Z_109 
Stack 18
E_1 A_2 E_4 J_5 
Stack 19
M_0 F_1 L_3 F_2 
Stack 20
H_0 H_8 E_3 H_3 
Stack 21
O_1 I_6 G_8 I_1 
Stack 22
L_1 B_3 M_2 
Stack 23
C_2 C_4 F_0 
