Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
L_0 G_7 D_2 G_1 
Stack 1
N_2 L_3 B_1 K_5 
Stack 2
K_0 Z_100 C_3 F_3 
Stack 3
I_4 Z_101 E_2 A_1 
Stack 4
E_4 H_3 F_1 D_0 
Stack 5
G_4 C_2 Z_102 O_1 
Stack 6
D_5 Z_103 G_2 M_2 
Stack 7
F_5 Z_104 B_3 M_3 
Stack 8
O_2 I_3 K_2 H_2 
Stack 9
D_4 N_3 L_5 J_0 
Stack 10
F_0 L_4 M_0 I_2 
Stack 11
O_0 G_5 Z_105 H_7 
Stack 12
F_2 L_1 D_3 Z_106 
Stack 13
D_1 C_4 J_3 I_1 
Stack 14
J_6 H_0 Z_107 I_5 
Stack 15
G_0 E_1 G_3 A_0 
Stack 16
C_1 H_4 L_2 J_7 
Stack 17
K_1 J_2 A_2 H_6 
Stack 18
J_1 N_0 Z_108 K_4 
Stack 19
E_0 B_0 M_1 Z_109 
Stack 20
E_5 H_5 J_5 N_1 
Stack 21
J_4 F_4 G_6 E_3 
Stack 22
C_0 H_1 G_8 
Stack 23
B_2 K_3 I_0 
