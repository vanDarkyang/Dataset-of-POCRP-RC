Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
Z_100 G_6 F_2 A_0 C_0 
Stack 1
H_5 F_3 E_5 I_3 F_8 
Stack 2
G_5 E_4 E_0 D_2 G_0 
Stack 3
D_4 D_1 E_8 D_6 I_4 
Stack 4
C_4 E_3 J_0 C_1 C_2 
Stack 5
C_3 J_1 F_0 G_1 A_4 
Stack 6
A_3 H_3 Z_101 F_4 D_3 
Stack 7
B_3 F_1 I_2 F_6 A_1 
Stack 8
E_7 H_1 E_6 D_5 Z_102 
Stack 9
E_1 H_0 Z_103 Z_104 F_5 
Stack 10
G_4 J_2 Z_105 B_0 C_5 
Stack 11
F_7 I_1 G_7 B_2 H_4 
Stack 12
B_1 G_2 Z_106 E_2 D_0 
Stack 13
C_6 A_2 G_3 H_2 I_0 
