Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_7 E_3 E_8 D_5 
Stack 1
B_0 C_10 D_0 B_8 
Stack 2
B_5 B_9 E_1 Z_100 
Stack 3
Z_101 C_1 D_2 E_6 
Stack 4
E_5 A_0 E_2 A_1 
Stack 5
C_11 Z_102 C_0 C_6 
Stack 6
D_7 A_6 E_0 B_3 
Stack 7
C_7 C_4 E_9 Z_103 
Stack 8
C_2 A_2 B_1 C_3 
Stack 9
A_4 C_9 B_4 E_4 
Stack 10
D_1 Z_104 E_7 D_3 
Stack 11
D_8 A_5 B_6 B_2 
Stack 12
Z_105 D_6 C_5 
Stack 13
A_3 D_4 C_8 
