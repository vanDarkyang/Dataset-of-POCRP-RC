Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
D_12 B_11 A_9 D_5 
Stack 1
A_13 C_2 B_0 A_8 
Stack 2
D_13 A_7 B_3 B_6 
Stack 3
C_13 B_2 B_7 D_8 
Stack 4
D_6 D_0 B_9 C_8 
Stack 5
C_9 D_10 C_12 Z_100 
Stack 6
D_1 D_9 A_0 C_3 
Stack 7
E_1 Z_101 A_5 D_11 
Stack 8
D_2 C_4 E_6 A_3 
Stack 9
B_12 E_9 Z_102 D_14 
Stack 10
C_14 Z_103 B_10 C_6 
Stack 11
B_4 D_4 C_5 A_1 
Stack 12
D_3 A_12 E_5 E_12 
Stack 13
A_6 D_7 B_1 Z_104 
Stack 14
Z_105 E_3 C_0 Z_106 
Stack 15
E_11 E_8 B_8 C_10 
Stack 16
E_10 A_4 E_2 C_15 
Stack 17
A_11 C_7 B_5 Z_107 
Stack 18
A_10 C_11 E_0 E_7 
Stack 19
E_4 A_2 C_1 
