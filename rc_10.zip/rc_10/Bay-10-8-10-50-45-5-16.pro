Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
H_3 G_4 J_0 E_0 I_3 
Stack 1
Z_100 A_0 G_2 C_3 I_2 
Stack 2
D_1 E_4 F_0 E_3 C_2 
Stack 3
B_3 B_2 H_0 Z_101 E_1 
Stack 4
B_0 J_1 C_0 H_2 Z_102 
Stack 5
G_1 B_1 C_1 I_1 F_1 
Stack 6
F_2 D_3 Z_103 G_3 G_0 
Stack 7
F_4 A_2 H_1 E_5 D_2 
Stack 8
D_0 Z_104 A_1 F_3 J_2 
Stack 9
E_2 E_6 I_0 H_4 G_5 
