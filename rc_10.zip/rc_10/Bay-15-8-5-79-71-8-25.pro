Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_8 D_7 B_7 C_11 D_4 C_13 
Stack 1
E_9 A_6 Z_100 B_4 B_13 C_8 
Stack 2
B_0 D_5 B_5 A_0 E_11 Z_101 
Stack 3
E_3 Z_102 A_1 D_10 A_9 B_8 
Stack 4
C_3 B_6 A_14 B_3 E_12 
Stack 5
A_3 A_10 E_0 Z_103 B_2 
Stack 6
B_14 E_8 C_12 C_14 C_6 
Stack 7
A_4 E_10 E_4 D_1 B_10 
Stack 8
C_0 D_2 C_1 E_7 E_5 
Stack 9
C_4 D_9 A_5 D_11 C_5 
Stack 10
A_12 C_10 D_6 B_11 Z_104 
Stack 11
E_6 B_12 D_12 B_1 E_1 
Stack 12
D_3 A_11 Z_105 A_13 C_7 
Stack 13
C_9 A_2 A_7 C_2 E_2 
Stack 14
D_0 Z_106 D_8 Z_107 B_9 
