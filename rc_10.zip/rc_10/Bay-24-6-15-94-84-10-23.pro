Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
L_0 C_2 J_6 G_6 
Stack 1
K_6 J_3 H_3 G_8 
Stack 2
A_1 C_1 K_5 J_7 
Stack 3
C_3 Z_100 L_1 D_3 
Stack 4
L_3 F_1 F_7 N_2 
Stack 5
E_2 F_5 F_0 H_1 
Stack 6
H_0 I_7 E_3 G_7 
Stack 7
H_6 D_2 E_5 O_1 
Stack 8
F_4 K_0 J_1 E_4 
Stack 9
E_0 L_4 H_4 G_3 
Stack 10
D_1 G_4 Z_101 I_4 
Stack 11
J_2 C_0 Z_102 H_7 
Stack 12
N_3 K_4 B_1 D_0 
Stack 13
I_2 Z_103 I_5 N_0 
Stack 14
F_2 Z_104 E_1 A_0 
Stack 15
C_4 H_5 G_1 M_4 
Stack 16
O_0 I_1 H_2 Z_105 
Stack 17
J_5 M_0 Z_106 J_0 
Stack 18
M_3 Z_107 I_3 G_5 
Stack 19
I_0 N_1 M_2 Z_108 
Stack 20
B_0 J_4 L_2 M_1 
Stack 21
K_3 K_1 I_6 F_6 
Stack 22
F_3 G_2 K_2 
Stack 23
G_0 Z_109 O_2 
