Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
D_1 A_3 E_9 C_14 Z_100 E_11 
Stack 1
D_2 E_7 B_2 Z_101 D_5 B_0 
Stack 2
A_12 B_1 C_0 D_0 C_13 E_8 
Stack 3
A_2 Z_102 C_7 D_9 B_14 B_13 
Stack 4
Z_103 B_8 D_13 A_7 E_2 
Stack 5
C_9 E_6 A_8 A_11 B_11 
Stack 6
E_3 A_5 C_6 C_5 A_13 
Stack 7
A_9 D_6 B_9 A_4 Z_104 
Stack 8
D_11 D_10 A_10 A_1 C_8 
Stack 9
Z_105 E_1 B_6 B_7 B_12 
Stack 10
D_7 B_3 B_5 B_4 E_5 
Stack 11
C_4 D_12 C_10 A_6 D_4 
Stack 12
C_1 C_2 E_4 A_0 B_10 
Stack 13
C_11 E_0 E_10 Z_106 C_3 
Stack 14
D_3 D_8 B_15 Z_107 C_12 
