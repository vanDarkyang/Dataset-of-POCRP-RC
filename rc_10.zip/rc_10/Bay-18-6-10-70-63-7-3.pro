Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
G_0 Z_100 I_3 Z_101 
Stack 1
A_3 H_1 C_0 I_1 
Stack 2
A_2 F_1 F_4 E_3 
Stack 3
D_1 E_4 B_0 Z_102 
Stack 4
G_2 F_7 G_3 I_0 
Stack 5
C_4 D_2 C_1 I_5 
Stack 6
C_2 B_4 E_6 H_5 
Stack 7
D_6 C_3 F_6 G_5 
Stack 8
D_5 F_0 Z_103 H_0 
Stack 9
Z_104 F_5 F_2 B_2 
Stack 10
J_4 D_4 B_1 D_0 
Stack 11
E_5 E_1 G_4 Z_105 
Stack 12
I_4 E_0 B_5 H_2 
Stack 13
I_2 C_5 J_2 D_3 
Stack 14
A_0 G_6 F_3 A_1 
Stack 15
J_3 B_3 C_6 Z_106 
Stack 16
J_1 H_3 J_0 
Stack 17
H_4 G_1 E_2 
