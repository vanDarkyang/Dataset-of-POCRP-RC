Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_4 E_1 A_7 A_0 D_1 
Stack 1
E_2 D_10 E_8 Z_100 B_0 
Stack 2
B_5 Z_101 A_2 C_0 B_6 
Stack 3
C_2 A_4 B_7 D_3 A_3 
Stack 4
C_8 A_5 D_7 E_3 A_1 
Stack 5
D_2 B_1 A_8 Z_102 E_5 
Stack 6
B_3 D_9 B_4 C_6 C_7 
Stack 7
Z_103 E_6 D_4 D_6 C_5 
Stack 8
D_8 C_10 C_9 A_6 Z_104 
Stack 9
D_0 D_5 B_2 C_1 C_3 
Stack 10
C_4 E_0 Z_105 E_7 
