Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
111
Number Of Shutout Containers
13
Yard Bay
Stack 0
D_1 J_6 F_7 J_0 I_3 K_8 
Stack 1
G_2 E_4 O_2 D_3 M_3 I_1 
Stack 2
E_8 C_4 K_5 B_5 E_1 D_5 
Stack 3
M_2 H_6 Z_100 K_1 E_5 L_1 
Stack 4
M_1 J_4 Z_101 I_2 N_2 
Stack 5
B_4 O_4 F_0 F_1 F_9 
Stack 6
D_2 M_4 C_0 Z_102 G_4 
Stack 7
F_5 Z_103 H_4 J_3 E_2 
Stack 8
A_0 H_9 H_7 J_8 G_6 
Stack 9
K_0 D_6 O_1 I_0 G_1 
Stack 10
G_9 N_3 K_7 K_4 F_2 
Stack 11
C_1 E_6 I_9 B_3 O_3 
Stack 12
K_3 G_5 G_3 Z_104 I_4 
Stack 13
N_0 F_8 J_7 O_0 G_10 
Stack 14
I_7 Z_105 F_3 G_8 H_8 
Stack 15
I_8 I_5 Z_106 B_2 C_3 
Stack 16
L_4 L_3 B_0 L_2 C_2 
Stack 17
G_7 E_0 H_1 D_0 M_0 
Stack 18
L_0 E_7 K_2 A_2 J_1 
Stack 19
H_0 Z_107 K_6 H_5 A_3 
Stack 20
N_4 F_4 Z_108 N_1 G_0 
Stack 21
J_2 H_2 Z_109 A_1 E_3 
Stack 22
F_6 M_5 Z_110 D_4 J_5 
Stack 23
Z_111 I_6 Z_112 H_3 B_1 
