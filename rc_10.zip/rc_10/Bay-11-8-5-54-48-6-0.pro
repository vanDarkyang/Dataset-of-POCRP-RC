Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_7 D_9 A_2 Z_100 A_8 
Stack 1
B_0 D_0 C_7 Z_101 E_4 
Stack 2
B_5 A_3 A_6 E_7 A_1 
Stack 3
A_5 E_1 A_7 B_1 C_4 
Stack 4
E_3 C_8 D_7 B_4 B_3 
Stack 5
C_9 B_9 D_5 E_5 D_8 
Stack 6
Z_102 C_0 E_6 B_6 C_2 
Stack 7
C_5 A_0 D_1 C_3 E_2 
Stack 8
C_1 Z_103 E_0 C_6 D_4 
Stack 9
A_4 A_9 D_3 D_6 B_2 
Stack 10
D_2 Z_104 Z_105 B_8 
