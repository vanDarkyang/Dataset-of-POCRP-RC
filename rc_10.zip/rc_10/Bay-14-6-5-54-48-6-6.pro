Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
E_1 C_11 D_7 Z_100 
Stack 1
A_2 B_1 D_3 E_2 
Stack 2
A_7 B_3 A_3 Z_101 
Stack 3
A_6 D_4 D_5 C_0 
Stack 4
A_0 D_8 C_4 D_2 
Stack 5
C_1 Z_102 Z_103 B_6 
Stack 6
E_6 C_9 E_0 E_4 
Stack 7
A_4 B_7 C_6 E_5 
Stack 8
B_2 A_9 D_0 C_3 
Stack 9
A_5 A_8 B_0 E_3 
Stack 10
C_10 B_4 C_7 C_8 
Stack 11
Z_104 B_5 D_6 D_9 
Stack 12
C_2 C_5 E_7 
Stack 13
D_1 Z_105 A_1 
