Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_5 B_4 C_4 B_6 
Stack 1
Z_100 B_11 B_1 A_2 
Stack 2
A_0 Z_101 C_1 C_6 
Stack 3
B_3 B_2 A_8 A_5 
Stack 4
B_10 Z_102 A_11 B_5 
Stack 5
C_3 C_7 Z_103 A_7 
Stack 6
A_10 C_11 A_3 C_14 
Stack 7
Z_104 C_13 C_2 B_0 
Stack 8
C_0 A_12 B_12 A_4 
Stack 9
B_9 A_6 A_9 A_1 
Stack 10
C_9 B_7 C_8 
Stack 11
C_10 B_8 C_12 
