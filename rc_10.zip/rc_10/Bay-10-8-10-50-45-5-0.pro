Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
H_0 E_5 F_0 B_0 C_0 
Stack 1
E_4 Z_100 G_3 F_5 C_4 
Stack 2
B_2 B_1 G_0 I_1 D_2 
Stack 3
F_3 G_1 G_4 I_3 F_2 
Stack 4
F_4 E_0 E_2 J_2 E_6 
Stack 5
D_1 F_1 H_1 H_2 E_3 
Stack 6
C_1 I_2 A_0 B_3 A_1 
Stack 7
D_3 E_1 Z_101 J_1 F_6 
Stack 8
C_2 Z_102 Z_103 Z_104 D_4 
Stack 9
J_0 D_0 G_2 I_0 C_3 
