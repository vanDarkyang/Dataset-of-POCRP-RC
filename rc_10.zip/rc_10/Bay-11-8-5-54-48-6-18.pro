Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_5 B_3 Z_100 E_2 C_0 
Stack 1
Z_101 Z_102 E_0 C_8 A_5 
Stack 2
A_7 A_3 D_8 C_1 C_9 
Stack 3
E_4 A_2 C_10 D_0 Z_103 
Stack 4
C_2 D_1 B_8 B_7 E_6 
Stack 5
A_4 D_9 E_1 Z_104 E_5 
Stack 6
B_4 D_4 B_6 D_2 C_6 
Stack 7
A_8 A_6 D_6 E_3 Z_105 
Stack 8
B_2 A_0 C_7 B_1 B_5 
Stack 9
E_7 B_0 D_5 A_1 D_3 
Stack 10
C_3 C_11 C_4 D_7 
