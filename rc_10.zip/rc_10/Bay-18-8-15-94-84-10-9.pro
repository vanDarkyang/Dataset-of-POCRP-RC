Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 J_1 L_0 Z_101 G_1 K_5 
Stack 1
N_2 E_0 C_4 B_2 Z_102 E_2 
Stack 2
K_1 E_6 H_0 K_3 F_4 N_1 
Stack 3
I_5 J_4 E_1 L_4 A_1 E_4 
Stack 4
E_5 C_0 H_3 M_0 D_0 
Stack 5
G_3 Z_103 J_2 F_0 O_0 
Stack 6
D_5 G_6 N_0 D_3 M_2 
Stack 7
F_6 L_2 B_0 J_3 M_3 
Stack 8
O_1 H_6 H_4 I_4 H_1 
Stack 9
D_4 M_4 F_5 G_2 J_0 
Stack 10
F_1 H_2 Z_104 L_1 I_2 
Stack 11
Z_105 C_2 K_4 Z_106 H_5 
Stack 12
F_3 I_1 D_2 Z_107 K_0 
Stack 13
D_1 F_7 B_1 M_1 I_0 
Stack 14
J_6 I_3 C_3 J_5 I_6 
Stack 15
G_0 N_3 E_3 G_5 A_0 
Stack 16
C_1 L_3 F_2 G_7 J_7 
Stack 17
K_2 G_4 I_7 Z_108 Z_109 
