Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
F_6 I_3 D_5 E_1 H_4 Z_100 
Stack 1
J_5 J_3 Z_101 A_3 D_1 G_8 
Stack 2
B_3 F_3 E_4 E_11 J_2 A_1 
Stack 3
D_0 C_11 I_7 C_1 G_4 E_2 
Stack 4
I_4 F_2 G_0 F_9 C_7 E_10 
Stack 5
F_4 F_1 J_0 G_9 F_8 
Stack 6
G_11 C_2 Z_102 H_7 D_4 
Stack 7
D_9 H_10 Z_103 E_13 G_3 
Stack 8
D_10 C_5 C_4 B_7 E_6 
Stack 9
B_8 A_7 E_9 A_0 E_8 
Stack 10
I_0 D_2 E_0 G_6 A_6 
Stack 11
B_9 G_7 E_5 C_9 D_11 
Stack 12
C_8 H_3 F_0 H_9 Z_104 
Stack 13
C_0 D_7 I_2 I_1 D_6 
Stack 14
B_2 I_6 Z_105 B_6 F_10 
Stack 15
E_3 Z_106 B_4 F_7 Z_107 
Stack 16
J_1 G_2 B_0 C_6 B_5 
Stack 17
H_0 E_7 E_12 F_5 G_5 
Stack 18
H_8 Z_108 B_1 Z_109 H_1 
Stack 19
D_8 H_2 A_5 I_9 H_5 
Stack 20
I_5 C_3 J_6 G_10 C_10 
Stack 21
H_6 F_11 J_4 A_4 Z_110 
Stack 22
I_8 Z_111 G_1 A_2 D_3 
