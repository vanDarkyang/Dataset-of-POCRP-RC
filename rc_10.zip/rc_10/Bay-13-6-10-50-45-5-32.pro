Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
H_1 E_1 C_4 Z_100 
Stack 1
F_5 C_3 D_1 A_0 
Stack 2
Z_101 F_1 F_2 H_2 
Stack 3
D_0 E_4 B_0 D_3 
Stack 4
J_0 E_0 I_1 H_4 
Stack 5
E_2 F_6 C_1 B_2 
Stack 6
I_2 H_0 C_2 G_1 
Stack 7
F_0 I_3 A_2 J_1 
Stack 8
D_4 C_0 D_2 Z_102 
Stack 9
G_2 H_3 B_1 Z_103 
Stack 10
I_0 G_3 F_4 Z_104 
Stack 11
A_1 F_3 G_0 
Stack 12
J_2 E_3 E_5 
