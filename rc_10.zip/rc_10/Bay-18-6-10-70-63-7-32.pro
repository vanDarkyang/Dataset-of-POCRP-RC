Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_4 I_2 H_4 Z_100 
Stack 1
D_1 E_7 G_4 D_2 
Stack 2
C_2 Z_101 B_3 J_2 
Stack 3
E_2 Z_102 F_5 Z_103 
Stack 4
J_0 G_7 B_0 E_8 
Stack 5
I_0 G_5 E_6 E_5 
Stack 6
F_0 F_2 Z_104 G_2 
Stack 7
F_4 I_3 G_6 H_1 
Stack 8
F_7 D_5 A_0 B_4 
Stack 9
B_1 C_3 G_0 H_2 
Stack 10
F_3 B_2 H_0 E_0 
Stack 11
A_1 H_6 C_6 G_3 
Stack 12
I_4 C_0 D_0 C_1 
Stack 13
C_5 D_6 J_1 I_1 
Stack 14
F_6 G_1 H_3 E_3 
Stack 15
E_1 E_4 H_5 D_3 
Stack 16
D_4 I_5 F_1 
Stack 17
Z_105 Z_106 A_2 
