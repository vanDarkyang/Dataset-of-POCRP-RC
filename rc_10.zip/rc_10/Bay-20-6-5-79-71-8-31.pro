Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_0 B_9 C_3 B_12 
Stack 1
E_5 Z_100 D_3 B_5 
Stack 2
B_11 C_7 D_11 C_12 
Stack 3
Z_101 E_0 E_3 C_8 
Stack 4
C_13 C_9 C_4 C_1 
Stack 5
E_12 D_2 A_14 A_6 
Stack 6
D_5 E_11 A_9 E_7 
Stack 7
D_13 B_7 D_12 B_2 
Stack 8
A_2 B_4 A_13 E_13 
Stack 9
C_14 B_10 D_0 Z_102 
Stack 10
D_10 A_3 Z_103 A_11 
Stack 11
A_5 A_10 E_4 A_4 
Stack 12
A_0 B_8 B_6 Z_104 
Stack 13
C_5 E_2 D_8 E_1 
Stack 14
A_7 C_10 A_8 D_4 
Stack 15
D_7 E_9 B_0 D_9 
Stack 16
A_12 C_2 D_6 Z_105 
Stack 17
Z_106 A_1 D_1 E_6 
Stack 18
E_10 B_1 C_6 Z_107 
Stack 19
E_8 C_11 B_3 
