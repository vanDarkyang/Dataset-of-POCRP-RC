Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
H_2 D_1 A_0 J_4 
Stack 1
J_2 F_6 I_3 E_1 
Stack 2
B_1 E_8 G_5 A_1 
Stack 3
E_3 Z_100 J_3 H_1 
Stack 4
G_4 D_6 E_5 Z_101 
Stack 5
J_1 F_2 F_5 D_4 
Stack 6
Z_102 H_5 Z_103 D_5 
Stack 7
E_7 B_0 B_3 E_4 
Stack 8
C_4 Z_104 C_3 I_2 
Stack 9
H_4 G_0 F_1 E_0 
Stack 10
C_2 H_3 E_6 F_3 
Stack 11
C_5 E_2 H_0 B_4 
Stack 12
C_0 D_0 G_6 J_0 
Stack 13
I_0 Z_105 A_2 D_3 
Stack 14
A_4 I_1 D_2 F_0 
Stack 15
B_2 G_3 A_3 F_7 
Stack 16
C_1 G_1 Z_106 
Stack 17
G_2 I_4 F_4 
