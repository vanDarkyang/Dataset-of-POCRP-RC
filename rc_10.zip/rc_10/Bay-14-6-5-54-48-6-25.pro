Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_1 D_7 C_0 E_9 
Stack 1
C_3 C_5 E_8 A_5 
Stack 2
D_8 D_3 D_1 E_3 
Stack 3
A_6 C_6 D_5 E_6 
Stack 4
C_9 A_0 Z_100 A_3 
Stack 5
C_7 Z_101 D_0 B_0 
Stack 6
B_4 C_4 B_3 Z_102 
Stack 7
Z_103 C_2 D_2 E_1 
Stack 8
B_7 E_0 Z_104 E_7 
Stack 9
B_9 D_4 E_5 C_8 
Stack 10
C_1 A_8 A_4 D_6 
Stack 11
E_4 A_1 E_2 Z_105 
Stack 12
B_8 A_7 B_6 
Stack 13
A_2 B_2 B_5 
