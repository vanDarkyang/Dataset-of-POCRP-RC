Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_3 D_9 C_5 E_2 E_7 
Stack 1
D_1 B_8 A_0 B_6 E_1 
Stack 2
D_7 D_0 D_10 Z_100 C_10 
Stack 3
A_1 B_2 C_8 A_7 A_6 
Stack 4
B_0 C_4 D_4 D_3 C_0 
Stack 5
B_7 C_11 D_2 Z_101 D_8 
Stack 6
C_2 Z_102 B_3 B_5 E_5 
Stack 7
B_1 A_4 C_9 Z_103 D_6 
Stack 8
E_3 C_3 C_7 E_0 E_4 
Stack 9
C_1 B_4 C_6 E_6 A_2 
Stack 10
Z_104 Z_105 D_5 A_5 
