Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
J_1 H_4 C_2 E_3 I_0 
Stack 1
H_2 G_1 D_6 D_1 Z_100 
Stack 2
D_2 E_2 F_3 H_3 C_4 
Stack 3
B_0 Z_101 A_4 A_1 F_4 
Stack 4
G_0 I_2 Z_102 Z_103 F_1 
Stack 5
F_2 J_4 E_0 G_4 F_5 
Stack 6
C_3 F_0 E_1 E_5 A_2 
Stack 7
Z_104 B_1 D_0 B_2 H_0 
Stack 8
I_3 J_0 D_3 I_5 F_6 
Stack 9
A_3 G_6 G_3 G_2 A_0 
Stack 10
E_8 D_4 G_5 J_3 E_7 
Stack 11
Z_105 E_6 G_7 C_0 H_1 
Stack 12
I_4 J_2 I_1 C_1 H_5 
Stack 13
Z_106 D_5 B_3 E_4 B_4 
