Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
H_2 E_2 I_3 J_1 
Stack 1
E_3 G_2 D_1 Z_100 
Stack 2
C_0 I_0 E_4 F_5 
Stack 3
B_0 C_1 A_2 J_2 
Stack 4
D_3 C_3 E_0 Z_101 
Stack 5
F_4 Z_102 D_2 Z_103 
Stack 6
H_3 F_0 G_4 E_5 
Stack 7
H_0 I_1 A_1 C_2 
Stack 8
A_0 F_1 J_0 C_4 
Stack 9
F_3 G_3 G_1 H_1 
Stack 10
D_0 B_2 H_4 Z_104 
Stack 11
F_2 B_1 E_1 
Stack 12
I_2 G_0 D_4 
