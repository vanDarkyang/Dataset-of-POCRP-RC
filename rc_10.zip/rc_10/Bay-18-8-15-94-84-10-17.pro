Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 G_2 J_4 K_3 I_5 E_2 
Stack 1
B_2 G_1 Z_101 Z_102 O_0 H_0 
Stack 2
G_3 N_3 H_3 N_2 E_0 N_0 
Stack 3
D_2 H_6 J_2 M_0 C_3 F_2 
Stack 4
A_2 B_0 D_3 G_4 J_5 
Stack 5
K_2 M_3 J_0 L_3 E_3 
Stack 6
G_6 G_7 B_3 M_1 D_1 
Stack 7
Z_103 E_5 F_5 G_5 Z_104 
Stack 8
C_1 A_0 B_1 D_5 L_2 
Stack 9
Z_105 I_0 K_4 H_2 F_4 
Stack 10
L_5 I_2 H_5 L_4 H_8 
Stack 11
J_3 C_2 J_6 J_7 I_6 
Stack 12
Z_106 F_0 L_0 C_0 G_0 
Stack 13
Z_107 H_4 J_1 M_4 H_7 
Stack 14
K_1 I_1 I_3 E_1 A_1 
Stack 15
D_4 L_1 I_4 Z_108 K_0 
Stack 16
F_1 I_7 D_0 F_3 Z_109 
Stack 17
E_4 M_2 F_6 N_1 H_1 
