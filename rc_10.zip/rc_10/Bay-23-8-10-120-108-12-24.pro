Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
A_6 H_7 C_10 H_4 E_3 B_5 
Stack 1
Z_100 J_6 E_9 C_1 A_7 J_1 
Stack 2
C_2 I_4 C_3 I_8 Z_101 E_4 
Stack 3
E_1 H_1 J_5 F_9 F_7 A_8 
Stack 4
Z_102 E_0 B_2 Z_103 Z_104 F_4 
Stack 5
B_6 D_7 G_5 D_0 Z_105 
Stack 6
E_8 G_6 F_3 G_10 B_8 
Stack 7
H_3 H_6 H_8 B_4 A_9 
Stack 8
D_4 A_0 I_2 E_12 E_11 
Stack 9
J_2 F_5 B_1 E_6 F_6 
Stack 10
C_7 C_5 J_3 I_3 E_7 
Stack 11
Z_106 A_5 I_9 G_7 C_8 
Stack 12
F_1 F_8 D_5 Z_107 G_0 
Stack 13
C_4 D_1 H_9 I_6 J_0 
Stack 14
D_6 G_9 C_0 G_11 H_0 
Stack 15
F_10 C_11 G_4 B_0 Z_108 
Stack 16
Z_109 J_7 C_6 A_2 H_5 
Stack 17
B_7 D_2 I_5 E_2 J_8 
Stack 18
Z_110 D_10 I_0 C_9 G_3 
Stack 19
Z_111 F_2 A_1 G_2 F_0 
Stack 20
A_3 H_2 A_4 J_9 J_4 
Stack 21
D_3 B_3 I_1 E_5 I_7 
Stack 22
G_1 E_10 G_8 D_9 D_8 
