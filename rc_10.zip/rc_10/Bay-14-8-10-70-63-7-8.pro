Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_2 B_3 F_0 Z_100 B_5 
Stack 1
Z_101 C_2 E_0 A_1 D_0 
Stack 2
A_0 C_0 B_0 I_3 B_4 
Stack 3
B_1 Z_102 G_0 F_6 H_3 
Stack 4
F_5 G_6 Z_103 E_6 A_4 
Stack 5
I_1 Z_104 C_1 I_4 E_2 
Stack 6
E_8 C_5 I_5 A_2 G_5 
Stack 7
G_4 I_0 F_1 G_3 E_7 
Stack 8
F_3 A_3 E_3 J_0 J_2 
Stack 9
D_3 D_1 F_2 H_0 J_3 
Stack 10
I_2 C_3 Z_105 E_4 B_2 
Stack 11
C_6 H_1 C_4 H_5 E_5 
Stack 12
E_1 D_4 G_2 G_1 F_4 
Stack 13
J_1 H_2 H_4 Z_106 H_6 
