Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
Z_100 Z_101 D_4 H_4 Z_102 
Stack 1
Z_103 G_0 I_5 B_5 B_1 
Stack 2
Z_104 Z_105 H_2 G_3 F_5 
Stack 3
F_3 C_4 C_0 G_4 A_0 
Stack 4
E_0 I_0 J_1 B_2 B_0 
Stack 5
G_5 H_5 A_1 E_5 A_2 
Stack 6
J_2 F_0 F_4 H_1 J_3 
Stack 7
I_2 D_3 D_2 E_4 E_7 
Stack 8
E_2 H_0 E_1 F_7 G_2 
Stack 9
B_3 E_6 J_4 C_2 I_1 
Stack 10
E_8 Z_106 D_0 I_3 F_1 
Stack 11
B_4 F_2 E_3 J_0 D_1 
Stack 12
A_4 D_5 G_6 H_3 I_4 
Stack 13
C_3 F_6 A_3 C_1 G_1 
