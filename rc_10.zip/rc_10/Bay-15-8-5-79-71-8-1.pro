Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
C_16 B_8 C_8 A_5 B_11 B_10 
Stack 1
Z_100 E_4 C_10 B_7 Z_101 A_10 
Stack 2
C_4 E_12 C_13 A_0 E_3 E_2 
Stack 3
B_1 A_7 E_7 B_6 E_11 D_3 
Stack 4
E_5 D_11 D_7 E_0 E_10 
Stack 5
Z_102 A_1 Z_103 Z_104 A_9 
Stack 6
B_12 C_14 E_8 D_1 D_0 
Stack 7
B_3 C_0 B_0 C_7 D_9 
Stack 8
C_6 E_13 C_5 D_13 A_6 
Stack 9
C_12 C_9 Z_105 B_2 B_9 
Stack 10
A_8 D_14 C_1 Z_106 D_2 
Stack 11
E_9 Z_107 C_15 B_4 C_2 
Stack 12
D_6 B_5 D_5 D_8 A_3 
Stack 13
A_11 A_4 C_3 E_6 D_10 
Stack 14
E_1 C_11 D_4 A_2 D_12 
