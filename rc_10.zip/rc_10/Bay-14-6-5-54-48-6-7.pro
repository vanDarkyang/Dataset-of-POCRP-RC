Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_8 Z_100 E_9 B_0 
Stack 1
E_8 D_0 B_2 Z_101 
Stack 2
D_5 C_0 Z_102 B_3 
Stack 3
D_9 A_8 D_4 E_6 
Stack 4
D_10 A_7 C_1 D_8 
Stack 5
Z_103 E_1 A_4 B_4 
Stack 6
C_9 E_4 A_3 D_1 
Stack 7
D_7 B_6 B_1 C_7 
Stack 8
A_5 C_5 Z_104 E_3 
Stack 9
A_2 C_6 E_2 D_3 
Stack 10
C_2 C_3 E_0 E_5 
Stack 11
Z_105 C_4 A_9 A_6 
Stack 12
A_0 B_5 E_7 
Stack 13
A_1 D_6 D_2 
