Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
E_6 J_0 D_4 D_6 I_0 
Stack 1
Z_100 H_3 E_4 J_4 D_1 
Stack 2
F_1 B_1 F_3 G_0 G_5 
Stack 3
F_6 Z_101 B_0 E_2 H_2 
Stack 4
Z_102 Z_103 Z_104 B_3 Z_105 
Stack 5
F_2 D_2 C_0 J_1 D_0 
Stack 6
I_2 C_3 E_7 A_1 G_1 
Stack 7
G_2 E_1 A_3 F_5 C_2 
Stack 8
E_3 E_0 C_1 B_4 I_4 
Stack 9
H_4 I_1 J_3 D_5 F_4 
Stack 10
F_8 F_0 C_4 H_5 G_6 
Stack 11
C_5 A_0 D_3 B_2 G_7 
Stack 12
H_1 E_5 J_2 H_0 G_3 
Stack 13
G_4 A_2 F_7 Z_106 I_3 
