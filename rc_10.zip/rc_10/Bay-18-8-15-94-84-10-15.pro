Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
J_4 K_4 D_2 F_3 G_0 D_3 
Stack 1
Z_100 H_1 E_4 J_1 H_5 K_2 
Stack 2
C_2 E_2 K_5 Z_101 L_3 M_3 
Stack 3
B_2 E_1 J_0 H_0 H_4 H_7 
Stack 4
G_1 N_3 E_3 K_3 Z_102 
Stack 5
O_1 I_0 I_5 N_2 G_3 
Stack 6
N_1 F_6 Z_103 D_5 J_5 
Stack 7
A_1 Z_104 A_2 K_0 Z_105 
Stack 8
D_1 G_2 G_4 N_0 D_4 
Stack 9
D_0 M_0 L_2 I_4 H_2 
Stack 10
A_0 K_6 L_0 O_0 Z_106 
Stack 11
B_1 J_6 B_0 C_1 J_3 
Stack 12
I_1 E_0 J_2 M_2 L_5 
Stack 13
E_5 G_5 Z_107 I_7 F_2 
Stack 14
C_0 H_6 C_3 I_3 I_2 
Stack 15
G_6 Z_108 F_5 H_3 M_1 
Stack 16
F_0 I_6 L_1 L_4 F_1 
Stack 17
B_3 K_1 H_8 F_4 Z_109 
