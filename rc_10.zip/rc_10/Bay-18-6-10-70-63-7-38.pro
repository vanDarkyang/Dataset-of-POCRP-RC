Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
E_2 F_6 E_1 H_2 
Stack 1
Z_100 F_4 H_5 D_3 
Stack 2
D_5 Z_101 A_4 E_3 
Stack 3
C_5 A_1 D_0 B_0 
Stack 4
A_2 G_5 J_0 J_3 
Stack 5
I_2 Z_102 G_6 G_4 
Stack 6
B_4 G_0 I_4 G_3 
Stack 7
J_2 D_4 I_0 C_2 
Stack 8
C_1 F_1 B_3 E_5 
Stack 9
G_1 Z_103 E_8 D_2 
Stack 10
C_0 E_6 H_4 F_2 
Stack 11
C_4 E_4 Z_104 A_3 
Stack 12
G_2 D_6 C_6 A_0 
Stack 13
F_3 F_0 E_0 J_4 
Stack 14
H_1 E_7 F_5 C_3 
Stack 15
D_1 B_1 H_3 I_3 
Stack 16
Z_105 Z_106 J_1 
Stack 17
I_1 B_2 H_0 
