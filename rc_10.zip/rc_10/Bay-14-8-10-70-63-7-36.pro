Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
D_1 C_1 D_3 C_0 Z_100 
Stack 1
F_0 G_4 A_2 A_0 I_2 
Stack 2
D_7 H_0 B_3 C_4 Z_101 
Stack 3
J_4 E_6 B_2 G_7 H_4 
Stack 4
Z_102 D_6 Z_103 I_4 I_5 
Stack 5
E_2 F_5 B_1 C_2 C_5 
Stack 6
H_1 B_4 E_5 E_3 I_3 
Stack 7
F_6 G_1 F_7 E_1 Z_104 
Stack 8
F_1 B_0 D_4 E_0 I_1 
Stack 9
J_3 E_7 F_3 H_5 G_6 
Stack 10
J_2 G_5 D_0 I_0 D_5 
Stack 11
A_1 J_0 F_4 Z_105 Z_106 
Stack 12
E_4 C_3 F_2 G_0 H_3 
Stack 13
J_1 D_2 G_3 H_2 G_2 
