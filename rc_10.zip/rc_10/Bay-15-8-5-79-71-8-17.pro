Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_5 A_11 A_8 C_2 E_2 A_6 
Stack 1
C_6 D_9 E_12 Z_100 E_5 D_11 
Stack 2
B_5 B_9 Z_101 E_4 D_1 C_4 
Stack 3
C_0 B_3 C_8 C_9 B_11 C_11 
Stack 4
A_12 D_8 B_12 Z_102 E_3 
Stack 5
Z_103 C_7 E_13 E_14 A_1 
Stack 6
A_0 Z_104 D_3 A_4 B_6 
Stack 7
B_4 E_10 D_12 B_2 C_10 
Stack 8
B_8 B_13 D_7 B_1 E_7 
Stack 9
E_9 D_5 Z_105 B_7 E_6 
Stack 10
B_0 B_10 E_0 C_5 E_11 
Stack 11
D_13 E_8 D_6 D_4 A_3 
Stack 12
D_0 Z_106 C_3 Z_107 E_1 
Stack 13
D_2 C_12 A_9 D_10 A_2 
Stack 14
C_1 A_7 D_14 B_14 A_10 
