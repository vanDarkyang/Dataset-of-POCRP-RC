Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_4 J_0 H_3 L_1 
Stack 1
F_3 H_5 B_3 N_0 
Stack 2
B_0 F_5 H_7 D_4 
Stack 3
D_2 G_2 K_5 I_6 
Stack 4
M_2 F_1 E_2 H_0 
Stack 5
Z_100 A_0 I_3 I_5 
Stack 6
M_4 Z_101 Z_102 G_6 
Stack 7
I_7 J_4 H_2 E_0 
Stack 8
H_6 Z_103 H_4 D_3 
Stack 9
G_4 Z_104 L_2 D_1 
Stack 10
F_0 N_2 K_3 J_3 
Stack 11
I_0 Z_105 J_5 Z_106 
Stack 12
Z_107 B_1 G_3 J_2 
Stack 13
G_8 D_5 G_5 L_3 
Stack 14
E_1 C_1 F_2 O_1 
Stack 15
C_2 H_1 K_4 J_1 
Stack 16
N_1 C_0 O_2 K_2 
Stack 17
Z_108 M_0 E_3 K_6 
Stack 18
G_7 G_0 K_0 K_1 
Stack 19
C_3 I_4 B_2 D_0 
Stack 20
E_4 J_6 M_1 I_1 
Stack 21
L_4 M_3 Z_109 E_5 
Stack 22
N_3 O_0 I_2 
Stack 23
E_6 G_1 L_0 
