Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_3 I_2 E_0 Z_100 D_0 
Stack 1
I_0 D_3 G_4 F_0 E_2 
Stack 2
G_0 H_0 Z_101 H_4 C_0 
Stack 3
B_3 F_6 A_1 H_3 F_4 
Stack 4
C_2 C_4 Z_102 H_2 D_2 
Stack 5
Z_103 F_5 A_2 A_0 G_3 
Stack 6
I_1 E_3 E_4 F_2 E_1 
Stack 7
D_1 F_3 G_2 D_4 B_1 
Stack 8
I_3 J_0 B_2 F_1 B_0 
Stack 9
E_5 G_1 H_1 C_1 Z_104 
