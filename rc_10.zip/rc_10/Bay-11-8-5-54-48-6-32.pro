Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_3 Z_100 C_5 Z_101 A_2 
Stack 1
Z_102 D_10 A_3 C_0 D_5 
Stack 2
C_7 B_5 E_5 E_0 C_8 
Stack 3
C_1 D_1 E_1 C_3 D_8 
Stack 4
B_1 B_8 A_4 D_7 B_7 
Stack 5
B_9 B_0 E_2 A_0 B_3 
Stack 6
Z_103 A_1 E_6 D_6 E_7 
Stack 7
D_2 E_4 C_4 E_3 C_2 
Stack 8
B_6 A_8 Z_104 Z_105 A_6 
Stack 9
D_0 D_9 A_5 C_9 D_4 
Stack 10
C_6 B_2 B_4 A_7 
