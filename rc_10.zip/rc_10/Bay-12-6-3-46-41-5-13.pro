Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_5 B_3 B_1 Z_100 
Stack 1
B_11 A_1 B_13 C_2 
Stack 2
A_4 B_10 A_6 A_11 
Stack 3
B_5 B_8 C_8 A_8 
Stack 4
B_0 A_0 C_7 A_2 
Stack 5
B_2 A_10 A_12 B_14 
Stack 6
C_1 A_7 C_10 C_4 
Stack 7
Z_101 B_7 A_3 C_5 
Stack 8
A_9 C_11 Z_102 B_4 
Stack 9
B_9 B_6 Z_103 C_3 
Stack 10
C_9 B_12 C_6 
Stack 11
C_0 Z_104 C_12 
