Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_1 C_1 D_3 B_7 D_9 
Stack 1
E_1 A_5 Z_100 D_1 E_5 
Stack 2
Z_101 C_6 C_2 A_2 D_4 
Stack 3
C_4 E_0 B_5 B_0 A_3 
Stack 4
Z_102 A_4 B_10 C_3 D_7 
Stack 5
E_6 Z_103 A_8 E_3 A_0 
Stack 6
B_2 A_7 E_7 C_0 B_3 
Stack 7
B_1 E_2 D_2 D_8 E_4 
Stack 8
Z_104 A_6 C_8 B_6 C_5 
Stack 9
B_8 B_9 B_4 C_7 D_6 
Stack 10
E_8 D_5 Z_105 D_0 
