Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
E_5 I_4 J_1 J_3 
Stack 1
C_4 A_1 B_4 J_4 
Stack 2
E_3 I_5 I_3 G_4 
Stack 3
D_1 D_6 I_1 F_0 
Stack 4
H_0 H_6 E_4 H_2 
Stack 5
I_0 Z_100 H_5 B_2 
Stack 6
D_3 F_3 H_1 Z_101 
Stack 7
F_7 F_5 F_4 G_1 
Stack 8
F_2 D_2 J_0 G_6 
Stack 9
E_0 H_4 G_2 Z_102 
Stack 10
F_6 Z_103 Z_104 C_0 
Stack 11
A_0 E_2 F_1 D_0 
Stack 12
B_0 F_8 E_1 G_3 
Stack 13
C_1 B_1 G_0 I_2 
Stack 14
B_3 G_5 C_3 D_5 
Stack 15
Z_105 D_4 B_5 E_7 
Stack 16
Z_106 J_2 C_5 
Stack 17
C_2 E_6 H_3 
