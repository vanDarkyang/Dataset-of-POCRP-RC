Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_4 B_2 C_1 B_1 E_8 
Stack 1
A_6 B_3 C_8 A_1 D_7 
Stack 2
B_0 D_0 Z_100 D_3 C_5 
Stack 3
B_9 D_10 C_2 C_0 E_4 
Stack 4
Z_101 Z_102 Z_103 A_4 B_7 
Stack 5
C_7 A_0 C_9 A_2 B_5 
Stack 6
A_5 D_4 D_8 E_1 E_7 
Stack 7
C_6 D_5 Z_104 E_6 B_8 
Stack 8
A_3 C_3 E_0 E_3 D_6 
Stack 9
B_6 E_2 D_9 E_5 Z_105 
Stack 10
D_1 C_4 D_2 B_10 
