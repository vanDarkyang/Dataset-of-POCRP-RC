Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_5 G_4 D_1 B_0 
Stack 1
G_0 J_2 H_6 Z_100 
Stack 2
B_1 O_1 G_3 O_2 
Stack 3
H_4 G_7 I_4 L_1 
Stack 4
Z_101 O_0 H_5 F_2 
Stack 5
Z_102 E_2 G_2 I_6 
Stack 6
N_0 Z_103 E_3 J_3 
Stack 7
E_4 D_0 N_1 H_1 
Stack 8
J_4 M_0 I_3 I_2 
Stack 9
K_4 F_4 J_5 G_8 
Stack 10
B_3 F_1 J_7 H_3 
Stack 11
Z_104 F_5 E_1 H_2 
Stack 12
L_4 I_0 E_0 Z_105 
Stack 13
K_2 H_0 M_2 L_2 
Stack 14
I_5 K_0 A_2 Z_106 
Stack 15
A_1 H_7 G_5 A_0 
Stack 16
D_3 C_0 F_3 I_1 
Stack 17
J_0 D_5 D_4 F_6 
Stack 18
L_0 Z_107 C_1 H_8 
Stack 19
Z_108 K_1 M_1 N_2 
Stack 20
H_9 E_6 B_2 G_1 
Stack 21
J_1 L_3 G_6 D_2 
Stack 22
C_2 K_5 F_0 
Stack 23
K_3 Z_109 J_6 
