Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
D_6 E_0 C_8 B_7 
Stack 1
C_1 D_3 C_11 Z_100 
Stack 2
Z_101 C_9 C_3 E_6 
Stack 3
D_9 B_0 A_4 E_1 
Stack 4
Z_102 C_5 C_4 A_5 
Stack 5
B_5 B_6 C_7 A_2 
Stack 6
D_1 D_2 B_3 A_0 
Stack 7
D_0 A_7 E_8 E_2 
Stack 8
D_7 C_10 A_1 D_10 
Stack 9
C_2 E_5 Z_103 B_1 
Stack 10
A_6 E_7 B_2 D_4 
Stack 11
B_4 Z_104 Z_105 C_6 
Stack 12
C_0 A_3 E_4 
Stack 13
E_3 D_8 D_5 
