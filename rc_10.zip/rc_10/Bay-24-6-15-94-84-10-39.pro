Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
84
Number Of Shutout Containers
10
Yard Bay
Stack 0
L_3 F_4 L_4 H_9 
Stack 1
M_2 J_4 G_2 H_0 
Stack 2
A_0 D_3 I_0 M_0 
Stack 3
E_4 G_8 I_2 D_4 
Stack 4
F_5 Z_100 D_2 J_6 
Stack 5
Z_101 J_1 H_3 C_3 
Stack 6
F_6 E_3 G_1 Z_102 
Stack 7
B_2 J_5 Z_103 Z_104 
Stack 8
N_0 N_2 H_8 J_3 
Stack 9
F_3 D_5 L_0 E_0 
Stack 10
H_7 F_7 Z_105 G_4 
Stack 11
N_1 O_0 C_0 J_0 
Stack 12
I_5 Z_106 H_2 G_7 
Stack 13
C_2 M_1 F_0 H_5 
Stack 14
G_5 H_1 C_4 F_1 
Stack 15
K_1 O_1 L_2 B_1 
Stack 16
L_1 I_1 Z_107 I_6 
Stack 17
Z_108 K_5 E_1 D_1 
Stack 18
B_3 I_3 E_2 G_0 
Stack 19
A_1 F_2 O_2 M_3 
Stack 20
I_4 C_1 K_0 H_4 
Stack 21
K_4 K_3 K_2 H_6 
Stack 22
G_6 J_2 G_3 
Stack 23
Z_109 B_0 D_0 
