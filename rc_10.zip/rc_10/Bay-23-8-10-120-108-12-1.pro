Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
108
Number Of Shutout Containers
12
Yard Bay
Stack 0
G_1 I_6 D_0 J_3 B_1 J_6 
Stack 1
G_4 C_9 H_5 A_7 I_8 B_2 
Stack 2
H_9 J_0 E_5 J_7 E_0 D_10 
Stack 3
G_0 F_1 F_6 C_6 A_5 F_11 
Stack 4
I_4 B_3 B_7 E_3 I_9 A_0 
Stack 5
D_6 E_9 Z_100 C_3 B_8 
Stack 6
H_4 D_9 E_12 I_5 F_7 
Stack 7
F_10 G_9 B_4 G_6 F_3 
Stack 8
C_10 D_2 Z_101 B_0 H_6 
Stack 9
H_1 B_5 Z_102 F_9 C_7 
Stack 10
G_5 I_7 C_4 D_8 Z_103 
Stack 11
E_8 I_10 C_0 C_2 Z_104 
Stack 12
E_6 A_1 Z_105 J_5 G_3 
Stack 13
J_2 D_3 D_4 A_6 E_2 
Stack 14
E_7 H_10 Z_106 F_2 G_2 
Stack 15
J_8 G_8 H_2 E_11 H_0 
Stack 16
B_6 E_4 H_8 Z_107 D_7 
Stack 17
C_5 D_5 A_3 Z_108 D_11 
Stack 18
F_4 D_12 F_5 I_0 Z_109 
Stack 19
G_7 E_10 Z_110 J_9 I_2 
Stack 20
H_7 A_2 F_0 I_1 D_1 
Stack 21
I_3 E_1 C_1 J_1 Z_111 
Stack 22
C_8 H_3 J_4 A_4 F_8 
