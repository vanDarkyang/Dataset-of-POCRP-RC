Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
C_10 C_8 Z_100 B_1 
Stack 1
Z_101 C_2 A_10 C_6 
Stack 2
C_4 A_5 A_2 B_3 
Stack 3
Z_102 B_8 A_7 A_12 
Stack 4
C_9 B_9 A_0 C_1 
Stack 5
C_0 A_9 A_8 C_13 
Stack 6
B_11 C_12 C_5 Z_103 
Stack 7
B_2 C_3 B_10 C_11 
Stack 8
Z_104 B_7 B_13 B_6 
Stack 9
B_5 A_6 B_12 C_7 
Stack 10
B_4 A_4 A_11 
Stack 11
B_0 A_1 A_3 
