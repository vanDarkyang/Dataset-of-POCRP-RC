Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
A_2 H_4 H_0 Z_100 
Stack 1
Z_101 J_2 E_3 B_1 
Stack 2
A_4 B_0 Z_102 I_4 
Stack 3
C_5 G_4 I_2 F_3 
Stack 4
D_3 C_2 A_1 I_0 
Stack 5
B_4 D_6 C_4 G_3 
Stack 6
Z_103 D_2 F_2 E_7 
Stack 7
H_5 J_0 D_4 F_8 
Stack 8
F_4 Z_104 E_5 A_3 
Stack 9
B_2 F_5 E_2 F_0 
Stack 10
F_1 C_3 F_7 E_8 
Stack 11
F_6 B_3 I_3 H_1 
Stack 12
D_1 D_5 G_0 D_0 
Stack 13
H_6 G_5 I_1 H_3 
Stack 14
G_1 H_2 E_1 J_1 
Stack 15
E_0 G_2 E_4 E_6 
Stack 16
G_6 Z_105 A_0 
Stack 17
Z_106 C_0 C_1 
