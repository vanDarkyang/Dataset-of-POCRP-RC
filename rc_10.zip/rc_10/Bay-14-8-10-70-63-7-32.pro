Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
63
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_3 F_4 B_2 A_3 J_3 
Stack 1
D_1 E_1 H_5 G_6 A_4 
Stack 2
Z_100 D_5 C_0 A_0 E_7 
Stack 3
E_2 D_4 D_7 G_0 E_5 
Stack 4
J_0 I_2 G_1 H_0 G_2 
Stack 5
I_0 E_6 E_4 Z_101 H_1 
Stack 6
F_0 J_1 I_5 D_0 Z_102 
Stack 7
Z_103 B_4 J_4 J_2 Z_104 
Stack 8
F_6 G_7 H_3 H_2 E_0 
Stack 9
B_1 G_5 G_4 H_4 G_3 
Stack 10
F_2 F_1 B_3 Z_105 C_1 
Stack 11
A_1 I_3 F_3 A_2 I_1 
Stack 12
I_4 D_6 B_0 F_5 E_3 
Stack 13
C_4 C_2 Z_106 D_2 D_3 
