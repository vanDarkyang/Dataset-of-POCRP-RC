Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
45
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_1 H_2 G_1 D_0 G_3 
Stack 1
F_4 E_2 D_3 D_2 E_5 
Stack 2
J_1 E_4 Z_100 I_0 E_1 
Stack 3
C_1 D_1 Z_101 G_2 F_2 
Stack 4
E_3 G_0 H_0 J_0 Z_102 
Stack 5
C_2 F_3 Z_103 B_0 G_5 
Stack 6
A_0 E_0 A_1 G_4 B_2 
Stack 7
I_1 I_3 D_4 H_3 F_1 
Stack 8
C_0 Z_104 I_2 F_5 H_1 
Stack 9
J_2 C_3 B_3 F_0 A_2 
