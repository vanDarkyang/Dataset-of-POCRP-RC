Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
B_10 B_4 C_13 B_14 
Stack 1
A_4 B_6 C_6 A_7 
Stack 2
A_10 B_13 A_6 A_5 
Stack 3
B_5 Z_100 C_12 C_1 
Stack 4
C_2 Z_101 B_8 A_0 
Stack 5
C_3 B_11 A_1 B_9 
Stack 6
B_0 C_8 B_12 A_11 
Stack 7
A_3 Z_102 C_7 B_2 
Stack 8
C_5 C_4 Z_103 A_2 
Stack 9
B_3 C_9 B_7 C_10 
Stack 10
B_1 C_11 C_0 
Stack 11
A_8 Z_104 A_9 
