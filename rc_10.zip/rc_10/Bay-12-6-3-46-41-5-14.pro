Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
41
Number Of Shutout Containers
5
Yard Bay
Stack 0
A_6 B_14 B_8 B_4 
Stack 1
A_7 A_1 B_7 Z_100 
Stack 2
A_11 A_0 Z_101 A_4 
Stack 3
A_9 B_1 C_6 B_0 
Stack 4
B_13 A_8 B_6 A_5 
Stack 5
C_8 C_4 A_10 A_3 
Stack 6
B_9 B_11 C_11 Z_102 
Stack 7
Z_103 Z_104 C_2 A_12 
Stack 8
C_12 C_10 B_2 B_10 
Stack 9
B_12 A_2 C_9 C_0 
Stack 10
C_3 C_1 C_5 
Stack 11
B_3 C_7 B_5 
