Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
71
Number Of Shutout Containers
8
Yard Bay
Stack 0
A_8 C_2 D_2 B_4 
Stack 1
A_10 Z_100 D_0 D_7 
Stack 2
D_12 A_12 B_9 C_9 
Stack 3
E_6 A_11 A_9 C_1 
Stack 4
B_11 D_14 D_6 Z_101 
Stack 5
A_6 Z_102 B_2 Z_103 
Stack 6
E_10 C_0 D_3 E_0 
Stack 7
B_0 B_6 D_5 E_1 
Stack 8
A_1 C_7 Z_104 D_1 
Stack 9
B_1 A_0 C_11 A_14 
Stack 10
E_7 C_6 E_4 E_11 
Stack 11
B_5 C_4 C_13 A_4 
Stack 12
C_10 A_2 Z_105 C_8 
Stack 13
E_2 D_9 D_10 E_5 
Stack 14
E_8 D_4 C_5 A_13 
Stack 15
B_3 B_7 E_9 C_12 
Stack 16
A_7 E_12 A_5 B_8 
Stack 17
Z_106 C_3 D_8 Z_107 
Stack 18
D_11 B_13 A_3 B_10 
Stack 19
B_12 E_3 D_13 
