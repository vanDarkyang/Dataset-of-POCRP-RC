Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
48
Number Of Shutout Containers
6
Yard Bay
Stack 0
Z_100 B_7 A_7 E_5 B_6 
Stack 1
A_0 C_2 A_6 E_0 C_0 
Stack 2
A_5 D_1 B_5 C_6 D_2 
Stack 3
A_4 C_11 B_8 D_0 B_9 
Stack 4
Z_101 B_2 C_5 B_1 E_4 
Stack 5
C_1 B_4 E_1 C_7 E_6 
Stack 6
E_7 Z_102 D_6 D_5 C_3 
Stack 7
A_2 D_7 D_3 E_8 E_3 
Stack 8
B_3 B_0 A_1 Z_103 C_8 
Stack 9
A_3 C_9 D_4 Z_104 Z_105 
Stack 10
C_10 B_10 C_4 E_2 
