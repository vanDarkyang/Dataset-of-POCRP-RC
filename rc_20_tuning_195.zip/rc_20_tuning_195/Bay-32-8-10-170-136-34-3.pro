Number Of Containers
170
Number Of Yard Stacks
32
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
136
Number Of Shutout Containers
34
Yard Bay
Stack 0
G_6 E_0 I_1 Z_100 F_5 D_4 
Stack 1
C_7 H_1 Z_101 Z_102 C_0 C_1 
Stack 2
B_11 H_4 Z_103 C_2 Z_104 Z_105 
Stack 3
A_6 F_9 G_1 G_4 B_5 A_4 
Stack 4
D_7 I_10 D_11 C_12 J_1 B_4 
Stack 5
C_9 Z_106 G_12 Z_107 F_14 Z_108 
Stack 6
E_7 Z_109 E_14 G_0 D_13 B_10 
Stack 7
Z_110 H_5 E_1 B_7 E_9 G_11 
Stack 8
Z_111 G_9 H_6 B_2 E_5 I_8 
Stack 9
Z_112 I_9 A_5 J_7 Z_113 F_2 
Stack 10
D_9 I_6 F_1 A_0 Z_114 
Stack 11
F_6 E_6 C_8 Z_115 Z_116 
Stack 12
I_14 D_3 H_10 D_8 C_6 
Stack 13
A_10 J_0 B_6 D_0 H_7 
Stack 14
F_7 B_8 E_2 I_3 F_8 
Stack 15
Z_117 Z_118 J_6 B_3 Z_119 
Stack 16
F_15 Z_120 Z_121 C_5 H_0 
Stack 17
J_3 F_12 H_2 D_10 Z_122 
Stack 18
C_11 G_7 H_9 C_3 J_4 
Stack 19
Z_123 Z_124 A_8 I_7 A_7 
Stack 20
A_1 A_3 D_5 E_13 Z_125 
Stack 21
D_2 E_12 F_0 F_4 E_3 
Stack 22
J_5 G_13 Z_126 Z_127 F_3 
Stack 23
I_12 G_8 I_2 C_10 H_3 
Stack 24
H_8 F_11 I_4 G_3 D_1 
Stack 25
G_2 D_12 E_15 J_2 C_4 
Stack 26
Z_128 Z_129 Z_130 I_11 Z_131 
Stack 27
B_0 D_14 Z_132 Z_133 F_13 
Stack 28
I_5 F_10 A_2 B_12 B_1 
Stack 29
B_9 E_11 C_13 A_9 I_0 
Stack 30
J_9 I_13 H_11 E_10 G_10 
Stack 31
E_4 J_8 G_5 D_6 E_8 
