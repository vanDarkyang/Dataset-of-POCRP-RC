Number Of Containers
390
Number Of Yard Stacks
74
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
312
Number Of Shutout Containers
78
Yard Bay
Stack 0
G_1 B_6 Z_100 Q_0 G_10 I_11 
Stack 1
G_15 J_10 E_11 T_8 T_5 Q_8 
Stack 2
Q_2 G_0 O_9 L_10 N_9 B_7 
Stack 3
Q_4 J_13 F_3 J_2 Z_101 F_13 
Stack 4
B_3 G_16 Z_102 Z_103 H_4 B_12 
Stack 5
N_3 Z_104 M_16 F_5 Z_105 R_13 
Stack 6
A_8 Z_106 B_8 E_9 N_15 Z_107 
Stack 7
H_0 O_5 G_11 M_8 F_16 Q_5 
Stack 8
K_12 R_6 O_4 O_7 J_9 Z_108 
Stack 9
F_1 S_2 A_12 J_16 T_3 M_9 
Stack 10
B_11 Z_109 J_0 Q_3 N_4 Z_110 
Stack 11
Z_111 T_10 G_12 H_6 G_9 Z_112 
Stack 12
C_8 E_4 D_14 Z_113 T_1 L_9 
Stack 13
Z_114 O_1 L_13 H_7 Z_115 Z_116 
Stack 14
G_4 Z_117 L_0 M_13 Q_9 C_4 
Stack 15
Z_118 Z_119 N_10 E_6 Z_120 I_7 
Stack 16
O_8 M_15 H_2 C_10 Z_121 P_0 
Stack 17
S_1 O_13 L_11 D_4 Z_122 N_16 
Stack 18
Z_123 Z_124 N_1 Z_125 E_0 Z_126 
Stack 19
T_6 K_0 E_1 L_15 Z_127 A_5 
Stack 20
Z_128 Z_129 Z_130 Z_131 R_5 
Stack 21
N_8 M_18 M_2 T_9 Z_132 
Stack 22
N_14 M_12 Z_133 M_4 L_1 
Stack 23
Z_134 D_8 H_16 P_6 Z_135 
Stack 24
H_1 P_10 B_14 H_17 G_8 
Stack 25
B_13 Z_136 J_12 S_5 K_13 
Stack 26
J_11 R_0 L_4 J_3 E_14 
Stack 27
N_0 L_3 Z_137 P_12 S_3 
Stack 28
D_3 Z_138 T_4 M_0 A_1 
Stack 29
D_10 Q_11 F_9 F_7 D_7 
Stack 30
Z_139 O_11 J_17 H_10 K_11 
Stack 31
I_13 E_16 C_3 N_2 Z_140 
Stack 32
K_4 D_9 P_7 O_14 K_15 
Stack 33
Z_141 F_14 M_1 A_7 H_18 
Stack 34
Z_142 C_11 K_14 O_10 H_14 
Stack 35
H_13 O_2 Z_143 P_11 H_3 
Stack 36
I_2 Z_144 E_10 I_6 N_7 
Stack 37
R_12 H_5 I_0 Z_145 F_12 
Stack 38
B_5 R_9 Z_146 Z_147 Z_148 
Stack 39
N_12 D_11 A_3 C_0 G_2 
Stack 40
F_11 I_4 Z_149 D_0 I_3 
Stack 41
M_17 I_14 S_6 T_2 D_13 
Stack 42
B_10 C_9 Q_1 J_5 G_6 
Stack 43
Z_150 S_0 I_9 F_0 R_8 
Stack 44
E_13 J_8 C_5 H_15 Z_151 
Stack 45
M_14 J_20 I_5 Z_152 G_3 
Stack 46
L_2 A_10 L_5 C_7 Z_153 
Stack 47
D_12 H_8 O_6 Z_154 R_14 
Stack 48
C_1 P_13 Z_155 M_6 P_9 
Stack 49
K_5 J_15 M_5 D_5 H_9 
Stack 50
L_16 P_8 Z_156 R_3 F_8 
Stack 51
L_6 P_3 D_1 R_4 A_6 
Stack 52
C_2 H_11 J_4 F_15 J_1 
Stack 53
J_6 L_8 E_8 R_10 Z_157 
Stack 54
G_14 N_5 E_5 S_7 K_3 
Stack 55
M_3 Z_158 A_2 Q_6 I_1 
Stack 56
F_4 K_9 Z_159 P_2 K_10 
Stack 57
Z_160 E_2 Z_161 Z_162 R_2 
Stack 58
Z_163 T_7 Z_164 O_3 N_13 
Stack 59
F_6 Z_165 A_11 A_13 P_1 
Stack 60
Z_166 L_12 B_4 Z_167 I_10 
Stack 61
J_18 P_4 A_4 Z_168 T_11 
Stack 62
F_2 Z_169 M_11 K_7 Z_170 
Stack 63
G_5 Z_171 M_7 L_14 D_2 
Stack 64
A_0 N_11 R_11 B_1 A_9 
Stack 65
Z_172 Q_7 Z_173 B_2 H_12 
Stack 66
E_3 K_6 E_15 Q_12 M_10 
Stack 67
S_8 Z_174 E_12 D_6 K_1 
Stack 68
L_7 K_8 R_1 F_10 B_9 
Stack 69
I_8 O_12 S_4 C_6 T_12 
Stack 70
J_14 R_7 I_15 Q_10 T_0 
Stack 71
I_12 O_0 Z_175 B_0 K_2 
Stack 72
G_13 J_7 N_6 P_14 P_5 
Stack 73
G_7 E_7 Z_176 Z_177 J_19 
