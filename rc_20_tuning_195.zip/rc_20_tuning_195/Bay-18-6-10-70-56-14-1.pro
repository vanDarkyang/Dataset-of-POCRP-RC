Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 Z_101 J_1 Z_102 
Stack 1
C_5 A_4 B_2 J_2 
Stack 2
E_1 I_4 I_3 G_5 
Stack 3
Z_103 Z_104 I_1 Z_105 
Stack 4
H_0 H_6 E_2 H_2 
Stack 5
I_0 C_1 H_5 B_1 
Stack 6
D_3 F_1 H_1 E_4 
Stack 7
F_5 F_3 F_2 G_1 
Stack 8
Z_106 D_2 J_0 Z_107 
Stack 9
Z_108 H_4 G_2 G_3 
Stack 10
F_4 A_0 A_1 C_0 
Stack 11
A_3 E_0 F_0 D_1 
Stack 12
B_0 F_6 Z_109 G_4 
Stack 13
C_2 Z_110 G_0 I_2 
Stack 14
Z_111 G_6 C_4 D_4 
Stack 15
A_2 Z_112 B_3 E_5 
Stack 16
D_0 Z_113 C_6 
Stack 17
C_3 E_3 H_3 
