Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_5 B_2 Z_100 D_4 E_5 
Stack 1
Z_101 C_4 D_3 Z_102 Z_103 
Stack 2
A_7 Z_104 D_5 A_2 B_1 
Stack 3
C_8 B_8 A_1 E_1 C_9 
Stack 4
B_4 E_7 C_5 D_1 D_2 
Stack 5
A_3 A_5 B_7 C_3 C_2 
Stack 6
E_2 C_0 E_6 D_6 B_3 
Stack 7
B_6 D_0 E_3 Z_105 A_6 
Stack 8
A_0 C_1 Z_106 Z_107 C_6 
Stack 9
A_4 C_7 B_0 D_7 Z_108 
Stack 10
E_4 Z_109 Z_110 E_0 
