Number Of Containers
274
Number Of Yard Stacks
52
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
219
Number Of Shutout Containers
55
Yard Bay
Stack 0
I_0 Z_100 N_1 F_4 J_14 K_15 
Stack 1
Z_101 I_11 K_6 C_1 N_6 E_5 
Stack 2
I_4 N_7 M_4 J_0 J_8 Z_102 
Stack 3
N_3 B_3 K_4 Z_103 H_7 O_4 
Stack 4
J_1 G_9 Z_104 E_1 Z_105 Z_106 
Stack 5
B_1 C_0 B_7 N_9 I_6 Z_107 
Stack 6
Z_108 D_8 Z_109 O_6 F_5 J_10 
Stack 7
O_7 L_11 Z_110 Z_111 J_4 O_11 
Stack 8
Z_112 J_13 Z_113 M_5 K_17 K_2 
Stack 9
I_15 F_10 G_11 J_9 B_11 B_4 
Stack 10
O_3 Z_114 M_7 F_13 A_6 L_10 
Stack 11
M_9 I_13 C_6 K_8 L_5 J_5 
Stack 12
E_9 D_11 H_13 N_4 K_0 D_14 
Stack 13
H_16 G_8 A_0 K_12 O_1 D_9 
Stack 14
E_6 J_11 Z_115 M_3 Z_116 
Stack 15
H_2 B_14 F_3 E_10 E_3 
Stack 16
K_13 A_7 C_2 K_16 K_10 
Stack 17
H_1 I_12 E_4 Z_117 O_0 
Stack 18
F_8 D_0 B_5 Z_118 H_14 
Stack 19
Z_119 I_2 I_14 Z_120 C_8 
Stack 20
I_7 N_2 B_0 K_9 D_1 
Stack 21
C_4 K_14 O_5 F_9 I_5 
Stack 22
I_16 M_13 M_6 H_0 H_9 
Stack 23
Z_121 C_5 Z_122 Z_123 D_2 
Stack 24
A_10 B_6 O_10 O_2 N_5 
Stack 25
E_2 Z_124 Z_125 F_1 G_3 
Stack 26
H_10 B_9 Z_126 F_0 B_12 
Stack 27
Z_127 J_2 L_6 I_17 H_15 
Stack 28
Z_128 G_6 L_4 L_1 Z_129 
Stack 29
Z_130 G_1 H_8 Z_131 M_11 
Stack 30
K_11 N_8 O_12 G_7 Z_132 
Stack 31
N_12 D_6 M_1 Z_133 Z_134 
Stack 32
K_1 A_3 C_9 F_15 F_16 
Stack 33
F_7 H_6 D_7 Z_135 Z_136 
Stack 34
L_7 Z_137 I_3 H_12 L_0 
Stack 35
G_10 A_1 J_3 F_14 N_11 
Stack 36
F_2 H_3 Z_138 Z_139 K_3 
Stack 37
C_3 J_6 A_11 Z_140 I_8 
Stack 38
L_3 Z_141 F_12 L_8 I_10 
Stack 39
D_4 D_3 M_10 A_12 A_9 
Stack 40
N_0 J_12 B_10 B_13 A_2 
Stack 41
E_0 H_5 Z_142 Z_143 E_8 
Stack 42
H_4 K_5 M_2 O_8 M_0 
Stack 43
D_13 Z_144 A_4 B_2 D_5 
Stack 44
G_5 A_8 C_7 L_12 D_10 
Stack 45
Z_145 D_12 Z_146 Z_147 Z_148 
Stack 46
A_5 G_2 N_10 Z_149 F_11 
Stack 47
G_4 L_9 C_10 Z_150 J_7 
Stack 48
H_17 M_12 Z_151 H_11 L_13 
Stack 49
Z_152 L_2 H_18 I_1 E_7 
Stack 50
F_6 B_8 M_8 G_0 H_19 
Stack 51
O_9 Z_153 Z_154 I_9 K_7 
