Number Of Containers
31
Number Of Yard Stacks
6
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
24
Number Of Shutout Containers
7
Yard Bay
Stack 0
B_0 B_1 A_5 B_6 Z_100 C_0 
Stack 1
A_7 A_6 B_7 C_6 Z_101 
Stack 2
C_5 B_5 A_3 C_2 C_3 
Stack 3
Z_102 A_4 Z_103 C_4 C_1 
Stack 4
A_0 B_4 B_8 Z_104 Z_105 
Stack 5
B_2 Z_106 A_1 A_2 B_3 
