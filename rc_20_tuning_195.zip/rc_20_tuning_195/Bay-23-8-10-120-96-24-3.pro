Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 D_2 D_10 B_7 F_1 B_4 
Stack 1
B_2 A_6 H_6 G_3 E_2 Z_101 
Stack 2
E_11 Z_102 G_5 Z_103 G_2 Z_104 
Stack 3
H_7 C_0 A_3 G_1 Z_105 Z_106 
Stack 4
Z_107 Z_108 Z_109 E_4 I_6 G_9 
Stack 5
D_7 Z_110 E_6 B_1 H_8 
Stack 6
B_9 D_3 Z_111 D_5 Z_112 
Stack 7
D_0 B_0 H_0 E_10 C_6 
Stack 8
E_9 A_1 I_2 A_0 F_4 
Stack 9
B_5 J_4 J_7 Z_113 J_1 
Stack 10
J_0 D_8 D_1 A_2 F_5 
Stack 11
F_2 Z_114 C_1 B_8 Z_115 
Stack 12
E_7 D_9 C_7 J_3 F_6 
Stack 13
I_0 H_4 Z_116 G_6 D_4 
Stack 14
I_5 J_6 D_6 A_5 Z_117 
Stack 15
I_3 F_0 C_5 A_7 Z_118 
Stack 16
F_8 I_1 G_8 Z_119 B_3 
Stack 17
J_2 G_4 G_0 G_10 C_4 
Stack 18
E_1 I_8 B_6 E_8 H_2 
Stack 19
C_2 I_7 E_0 F_9 Z_120 
Stack 20
J_5 F_7 C_3 F_3 G_7 
Stack 21
H_5 E_5 Z_121 H_3 H_1 
Stack 22
I_4 E_3 Z_122 Z_123 A_4 
