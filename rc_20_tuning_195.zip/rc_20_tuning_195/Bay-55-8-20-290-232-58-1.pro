Number Of Containers
290
Number Of Yard Stacks
55
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
232
Number Of Shutout Containers
58
Yard Bay
Stack 0
A_1 T_1 J_0 C_0 T_4 Q_6 
Stack 1
D_6 I_9 O_2 M_10 I_4 Z_100 
Stack 2
G_2 Z_101 P_2 Z_102 Z_103 P_0 
Stack 3
E_6 M_9 P_8 N_1 C_2 L_0 
Stack 4
I_6 O_3 L_8 Z_104 N_3 B_3 
Stack 5
C_6 H_11 M_3 F_1 N_0 N_8 
Stack 6
N_2 L_2 Z_105 T_2 R_4 I_7 
Stack 7
Z_106 M_5 H_2 N_9 D_5 A_5 
Stack 8
P_10 I_10 S_5 Z_107 Z_108 F_6 
Stack 9
S_0 N_12 D_8 K_2 B_5 C_5 
Stack 10
R_8 Z_109 G_3 C_8 K_8 I_3 
Stack 11
C_3 E_3 K_12 Q_4 S_1 K_10 
Stack 12
A_7 Z_110 N_5 Z_111 C_9 R_5 
Stack 13
H_7 D_3 J_1 R_1 H_3 S_8 
Stack 14
K_3 A_9 Z_112 D_7 D_1 Z_113 
Stack 15
Z_114 L_7 J_10 M_2 S_2 
Stack 16
N_6 K_6 B_0 M_1 Z_115 
Stack 17
E_4 Z_116 Z_117 F_0 K_7 
Stack 18
F_3 P_7 Z_118 P_5 Z_119 
Stack 19
P_4 Q_3 H_13 T_5 Z_120 
Stack 20
G_4 H_8 E_5 H_4 J_9 
Stack 21
P_9 P_1 N_4 E_8 Z_121 
Stack 22
I_2 E_0 Z_122 N_11 Q_9 
Stack 23
D_10 P_6 M_8 M_6 J_4 
Stack 24
Z_123 H_15 B_2 L_10 B_6 
Stack 25
G_1 L_9 L_12 R_7 K_14 
Stack 26
Z_124 K_11 K_13 B_4 L_6 
Stack 27
H_1 F_10 K_16 O_8 T_3 
Stack 28
H_14 D_9 Q_10 A_2 Z_125 
Stack 29
Z_126 R_2 C_1 J_11 Q_1 
Stack 30
L_5 Z_127 Z_128 O_0 I_1 
Stack 31
J_8 K_5 Z_129 E_1 D_4 
Stack 32
F_4 G_10 G_8 R_9 H_12 
Stack 33
K_1 Z_130 Q_0 J_2 J_12 
Stack 34
E_9 I_5 T_0 Z_131 H_9 
Stack 35
Z_132 D_11 A_4 A_6 F_7 
Stack 36
Z_133 R_6 E_10 H_10 D_0 
Stack 37
G_9 H_0 C_7 K_15 L_11 
Stack 38
Z_134 Z_135 I_8 Z_136 L_14 
Stack 39
K_17 L_4 M_7 L_13 J_3 
Stack 40
S_3 J_7 Q_8 Z_137 F_2 
Stack 41
Z_138 M_0 P_3 O_1 B_1 
Stack 42
J_6 Z_139 G_0 J_5 Z_140 
Stack 43
K_4 O_7 H_5 G_7 F_11 
Stack 44
I_0 Z_141 N_10 S_9 Q_5 
Stack 45
Z_142 F_5 E_2 L_3 Q_2 
Stack 46
R_0 H_6 C_10 Z_143 S_6 
Stack 47
E_7 R_3 D_2 C_4 Z_144 
Stack 48
G_5 B_7 M_4 O_5 F_8 
Stack 49
F_12 Z_145 O_6 O_4 Z_146 
Stack 50
Z_147 L_1 A_3 Z_148 S_7 
Stack 51
A_0 B_8 Z_149 A_8 Z_150 
Stack 52
Z_151 Q_7 N_7 K_9 Z_152 
Stack 53
Z_153 Z_154 F_9 S_4 G_6 
Stack 54
K_0 Z_155 Z_156 Z_157 T_6 
