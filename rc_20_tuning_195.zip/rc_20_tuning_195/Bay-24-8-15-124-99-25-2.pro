Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
K_3 F_7 H_7 M_6 N_1 C_3 
Stack 1
A_0 Z_100 C_0 Z_101 I_5 Z_102 
Stack 2
J_3 M_1 D_4 Z_103 Z_104 N_2 
Stack 3
J_6 I_3 G_1 G_7 I_7 I_8 
Stack 4
F_1 G_5 Z_105 Z_106 D_1 
Stack 5
O_4 K_0 D_0 H_0 D_2 
Stack 6
Z_107 M_5 G_8 Z_108 B_1 
Stack 7
I_4 J_0 C_1 M_0 F_6 
Stack 8
Z_109 H_4 Z_110 O_0 K_4 
Stack 9
Z_111 G_6 E_3 N_3 F_4 
Stack 10
B_0 M_3 E_5 L_0 H_9 
Stack 11
N_0 I_0 H_2 E_1 K_7 
Stack 12
O_1 Z_112 D_5 Z_113 Z_114 
Stack 13
G_0 A_3 Z_115 A_1 Z_116 
Stack 14
H_1 L_4 H_6 L_2 O_2 
Stack 15
D_3 H_3 B_3 M_4 Z_117 
Stack 16
I_1 G_4 E_2 E_4 M_2 
Stack 17
G_2 E_0 K_1 F_2 H_5 
Stack 18
Z_118 Z_119 Z_120 O_3 F_0 
Stack 19
N_4 K_5 Z_121 Z_122 B_2 
Stack 20
G_3 J_1 H_8 I_2 Z_123 
Stack 21
J_4 L_3 Z_124 F_5 N_5 
Stack 22
C_2 I_6 J_7 K_2 K_6 
Stack 23
J_5 J_2 F_3 A_2 L_1 
