Number Of Containers
150
Number Of Yard Stacks
38
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
120
Number Of Shutout Containers
30
Yard Bay
Stack 0
L_1 Z_100 Z_101 F_1 
Stack 1
H_4 O_1 R_1 Z_102 
Stack 2
Z_103 K_3 P_4 N_2 
Stack 3
N_0 H_0 D_3 Z_104 
Stack 4
Z_105 L_7 Z_106 G_5 
Stack 5
Z_107 Q_2 I_3 G_2 
Stack 6
M_5 J_8 Z_108 G_7 
Stack 7
H_7 F_3 K_9 R_2 
Stack 8
I_4 R_3 I_5 O_3 
Stack 9
G_0 A_0 N_7 J_6 
Stack 10
L_3 I_2 E_3 C_0 
Stack 11
S_2 L_4 K_0 K_7 
Stack 12
J_7 K_8 K_1 J_3 
Stack 13
L_6 M_0 D_1 G_1 
Stack 14
Z_109 Z_110 H_1 Q_1 
Stack 15
Z_111 J_0 A_1 N_1 
Stack 16
Z_112 Z_113 O_5 Z_114 
Stack 17
S_3 Z_115 N_4 O_0 
Stack 18
F_0 O_2 T_2 P_1 
Stack 19
B_1 Z_116 L_5 N_6 
Stack 20
L_8 Z_117 C_2 I_6 
Stack 21
T_0 Q_0 K_2 H_3 
Stack 22
Z_118 I_1 O_4 K_10 
Stack 23
T_1 D_2 P_0 C_1 
Stack 24
D_0 N_3 Z_119 Z_120 
Stack 25
P_2 R_0 H_2 M_6 
Stack 26
G_4 Z_121 F_2 P_3 
Stack 27
G_8 L_0 H_6 S_1 
Stack 28
K_4 I_0 M_7 A_2 
Stack 29
S_0 Z_122 H_8 Z_123 
Stack 30
Z_124 M_2 M_4 Z_125 
Stack 31
H_5 Q_3 E_2 J_2 
Stack 32
E_0 J_5 Z_126 G_6 
Stack 33
M_3 K_6 C_3 B_0 
Stack 34
M_1 Z_127 B_2 G_3 
Stack 35
Z_128 L_2 N_5 K_5 
Stack 36
R_4 E_1 Z_129 
Stack 37
E_4 J_1 J_4 
