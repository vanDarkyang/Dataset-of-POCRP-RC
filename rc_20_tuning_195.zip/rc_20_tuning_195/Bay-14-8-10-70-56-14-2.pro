Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_3 B_3 A_1 E_0 B_1 
Stack 1
H_0 B_4 E_5 E_4 C_2 
Stack 2
A_2 E_2 Z_100 I_5 G_2 
Stack 3
C_5 D_2 B_2 Z_101 I_2 
Stack 4
H_1 J_0 B_0 Z_102 F_0 
Stack 5
E_6 I_4 A_0 F_4 Z_103 
Stack 6
F_8 Z_104 Z_105 I_1 F_5 
Stack 7
J_2 Z_106 Z_107 D_4 C_4 
Stack 8
C_3 E_1 D_5 F_3 D_6 
Stack 9
Z_108 F_7 I_0 G_4 Z_109 
Stack 10
D_0 G_1 C_1 F_2 G_0 
Stack 11
F_6 D_1 G_3 H_2 C_0 
Stack 12
D_3 Z_110 Z_111 Z_112 F_1 
Stack 13
J_1 E_3 Z_113 I_3 B_5 
