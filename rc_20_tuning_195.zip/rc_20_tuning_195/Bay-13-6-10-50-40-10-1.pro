Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_1 D_1 A_1 F_0 
Stack 1
F_2 Z_100 D_4 Z_101 
Stack 2
J_1 F_1 Z_102 E_5 
Stack 3
C_1 E_1 B_2 Z_103 
Stack 4
E_3 I_2 D_0 Z_104 
Stack 5
C_2 C_3 D_2 Z_105 
Stack 6
A_0 C_4 I_0 G_3 
Stack 7
I_1 G_0 G_1 Z_106 
Stack 8
C_0 D_3 J_0 Z_107 
Stack 9
Z_108 E_0 B_0 H_1 
Stack 10
H_3 Z_109 G_2 A_2 
Stack 11
E_2 H_0 H_4 
Stack 12
E_4 H_2 F_3 
