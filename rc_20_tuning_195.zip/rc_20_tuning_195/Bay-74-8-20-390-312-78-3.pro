Number Of Containers
390
Number Of Yard Stacks
74
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
312
Number Of Shutout Containers
78
Yard Bay
Stack 0
Z_100 J_1 E_4 H_14 J_3 B_6 
Stack 1
C_4 A_7 K_3 F_11 I_12 Z_101 
Stack 2
H_13 O_9 N_15 Z_102 F_5 M_8 
Stack 3
T_9 H_9 J_8 B_2 M_5 I_3 
Stack 4
N_11 Z_103 N_3 S_6 I_2 A_8 
Stack 5
M_9 P_9 Z_104 F_7 E_5 C_10 
Stack 6
O_0 O_14 S_5 K_5 Z_105 O_15 
Stack 7
O_11 T_8 I_11 G_8 N_5 I_1 
Stack 8
G_0 R_10 P_8 Z_106 I_16 K_6 
Stack 9
F_14 N_7 B_7 Z_107 J_14 T_3 
Stack 10
Z_108 A_0 Z_109 Z_110 A_10 E_7 
Stack 11
Z_111 E_12 N_8 S_4 S_1 Z_112 
Stack 12
H_17 C_12 Q_6 K_10 E_8 Z_113 
Stack 13
N_14 Z_114 Z_115 A_11 R_3 A_3 
Stack 14
S_11 K_12 L_14 F_1 C_13 M_6 
Stack 15
H_0 H_3 C_6 Z_116 Z_117 P_10 
Stack 16
Z_118 G_3 I_4 F_4 I_18 Z_119 
Stack 17
L_7 R_11 Z_120 O_3 C_0 Z_121 
Stack 18
C_14 P_11 O_5 G_15 T_1 Q_8 
Stack 19
Z_122 K_4 J_17 K_14 B_9 M_10 
Stack 20
D_6 Z_123 L_0 J_2 Q_7 
Stack 21
S_2 Q_12 I_13 K_9 R_1 
Stack 22
Z_124 Z_125 B_1 N_1 J_0 
Stack 23
C_3 F_13 P_14 Q_3 C_9 
Stack 24
D_9 B_3 G_13 L_1 Z_126 
Stack 25
E_2 M_1 A_2 E_9 Z_127 
Stack 26
Z_128 Z_129 T_2 Z_130 J_11 
Stack 27
E_3 F_8 J_15 H_11 Z_131 
Stack 28
H_8 O_8 P_13 S_8 A_9 
Stack 29
G_10 F_6 H_16 H_7 H_15 
Stack 30
I_0 O_7 P_4 B_4 J_4 
Stack 31
Z_132 F_10 Z_133 K_0 G_4 
Stack 32
Z_134 Q_1 Z_135 D_7 S_10 
Stack 33
P_2 G_11 J_5 B_8 B_12 
Stack 34
Z_136 R_4 T_12 Z_137 M_7 
Stack 35
C_11 E_1 Z_138 G_16 C_7 
Stack 36
R_6 Z_139 P_12 N_10 Z_140 
Stack 37
Z_141 N_13 P_6 L_8 A_1 
Stack 38
N_6 B_0 H_18 S_7 Z_142 
Stack 39
G_2 M_0 I_5 H_1 M_11 
Stack 40
K_19 H_12 S_9 H_2 B_5 
Stack 41
Z_143 G_1 O_13 Z_144 S_0 
Stack 42
D_10 L_15 J_12 T_6 F_15 
Stack 43
Z_145 Q_9 B_11 B_10 Q_0 
Stack 44
C_1 E_11 I_9 M_12 Q_2 
Stack 45
K_18 A_6 D_8 D_2 K_2 
Stack 46
L_9 M_14 Z_146 L_2 R_8 
Stack 47
Z_147 K_16 O_2 Z_148 Z_149 
Stack 48
E_0 Z_150 Q_10 Z_151 P_1 
Stack 49
T_7 L_11 M_13 L_12 C_8 
Stack 50
Z_152 K_17 P_3 P_0 I_6 
Stack 51
L_4 Z_153 Q_11 F_12 T_11 
Stack 52
G_7 Z_154 R_5 J_10 Z_155 
Stack 53
O_4 I_8 H_4 I_7 F_0 
Stack 54
Z_156 D_1 L_16 Z_157 G_9 
Stack 55
Z_158 Z_159 N_0 I_15 T_5 
Stack 56
Z_160 Z_161 Z_162 H_10 J_9 
Stack 57
T_0 K_1 L_6 S_3 Z_163 
Stack 58
G_17 Z_164 D_4 Z_165 M_4 
Stack 59
A_4 N_9 R_9 D_5 Q_13 
Stack 60
O_6 M_16 E_10 R_0 R_7 
Stack 61
K_11 C_2 I_10 O_1 Z_166 
Stack 62
K_13 K_7 L_3 Z_167 H_5 
Stack 63
T_10 D_0 Z_168 A_12 L_10 
Stack 64
G_6 F_16 N_16 H_19 Z_169 
Stack 65
N_12 Q_4 Z_170 T_4 M_3 
Stack 66
Z_171 Q_5 J_18 J_13 J_6 
Stack 67
F_2 A_5 O_12 K_15 G_12 
Stack 68
F_3 O_10 Z_172 F_9 C_5 
Stack 69
J_16 Z_173 Z_174 I_14 G_5 
Stack 70
Z_175 P_5 E_6 L_5 D_3 
Stack 71
E_13 R_2 Z_176 K_8 M_2 
Stack 72
J_7 Z_177 N_2 I_17 L_13 
Stack 73
M_15 H_6 N_4 P_7 G_14 
