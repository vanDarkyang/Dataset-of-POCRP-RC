Number Of Containers
19
Number Of Yard Stacks
5
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
15
Number Of Shutout Containers
4
Yard Bay
Stack 0
Z_100 E_0 Z_101 B_2 
Stack 1
D_2 A_1 E_1 Z_102 
Stack 2
B_1 D_1 C_3 C_0 
Stack 3
B_0 C_2 C_1 D_0 
Stack 4
Z_103 A_0 B_3 
