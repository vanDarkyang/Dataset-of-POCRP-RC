Number Of Containers
199
Number Of Yard Stacks
38
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
159
Number Of Shutout Containers
40
Yard Bay
Stack 0
Z_100 Z_101 Z_102 Z_103 C_2 J_9 
Stack 1
J_7 Z_104 Z_105 J_10 C_1 E_4 
Stack 2
Z_106 B_4 F_3 I_1 Z_107 Z_108 
Stack 3
L_1 E_10 Z_109 D_5 M_4 F_0 
Stack 4
K_6 H_4 N_9 K_10 N_6 B_6 
Stack 5
H_1 H_11 H_5 G_8 M_9 G_12 
Stack 6
Z_110 E_2 E_11 C_5 N_4 N_2 
Stack 7
E_12 J_5 L_5 Z_111 Z_112 Z_113 
Stack 8
O_1 F_1 G_7 G_5 G_9 I_3 
Stack 9
B_7 D_3 K_4 B_5 M_2 
Stack 10
Z_114 G_3 Z_115 Z_116 B_1 
Stack 11
Z_117 D_1 Z_118 K_8 E_8 
Stack 12
F_9 K_7 G_0 O_4 Z_119 
Stack 13
A_1 M_3 Z_120 I_12 E_6 
Stack 14
I_9 L_0 Z_121 L_2 I_6 
Stack 15
A_5 Z_122 N_0 H_8 J_0 
Stack 16
L_4 C_6 N_1 K_3 D_2 
Stack 17
J_4 I_10 B_8 B_0 D_8 
Stack 18
N_5 O_0 O_3 C_3 K_11 
Stack 19
C_7 A_0 A_4 I_0 I_11 
Stack 20
K_0 F_4 H_7 N_3 O_6 
Stack 21
J_2 I_4 E_9 O_2 F_7 
Stack 22
G_11 M_5 E_1 J_6 Z_123 
Stack 23
K_9 G_2 H_6 C_4 D_4 
Stack 24
F_6 F_5 I_14 Z_124 D_7 
Stack 25
Z_125 G_6 D_10 G_1 D_0 
Stack 26
K_2 J_8 B_2 J_11 E_0 
Stack 27
Z_126 M_7 M_8 I_5 Z_127 
Stack 28
H_12 A_6 F_2 Z_128 E_7 
Stack 29
H_0 J_1 Z_129 A_3 N_7 
Stack 30
M_6 D_6 Z_130 I_7 Z_131 
Stack 31
K_1 N_8 H_2 Z_132 D_9 
Stack 32
B_3 Z_133 G_10 Z_134 O_5 
Stack 33
K_5 Z_135 H_10 M_0 L_3 
Stack 34
H_9 H_3 M_1 I_8 I_13 
Stack 35
Z_136 Z_137 J_3 Z_138 C_9 
Stack 36
C_8 A_2 G_4 C_10 C_0 
Stack 37
I_2 Z_139 F_8 E_5 E_3 
