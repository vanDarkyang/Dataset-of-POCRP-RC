Number Of Containers
199
Number Of Yard Stacks
50
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
159
Number Of Shutout Containers
40
Yard Bay
Stack 0
O_1 K_2 Z_100 L_3 
Stack 1
Z_101 K_12 F_5 Z_102 
Stack 2
G_4 A_4 H_13 D_8 
Stack 3
H_9 K_11 Z_103 Z_104 
Stack 4
F_4 Z_105 I_6 G_5 
Stack 5
G_1 B_2 J_1 Z_106 
Stack 6
K_3 I_7 C_3 C_5 
Stack 7
M_7 F_2 N_6 M_5 
Stack 8
Z_107 D_9 I_10 D_3 
Stack 9
M_10 E_5 G_7 L_4 
Stack 10
Z_108 Z_109 H_4 C_8 
Stack 11
J_12 Z_110 B_4 Z_111 
Stack 12
I_14 L_2 O_6 G_6 
Stack 13
I_4 Z_112 F_7 O_5 
Stack 14
Z_113 J_11 Z_114 H_3 
Stack 15
M_2 A_5 F_3 L_5 
Stack 16
E_1 D_1 B_0 I_11 
Stack 17
N_3 M_6 Z_115 G_0 
Stack 18
H_10 H_8 G_3 F_8 
Stack 19
O_3 H_5 Z_116 M_8 
Stack 20
Z_117 F_1 E_8 A_6 
Stack 21
C_4 N_8 K_9 Z_118 
Stack 22
E_9 A_7 J_9 E_3 
Stack 23
K_1 K_10 L_8 K_5 
Stack 24
K_8 N_1 M_9 M_4 
Stack 25
D_0 E_11 K_13 Z_119 
Stack 26
I_12 D_2 F_6 D_4 
Stack 27
Z_120 C_6 Z_121 I_8 
Stack 28
N_0 Z_122 J_4 A_3 
Stack 29
Z_123 B_6 L_7 I_2 
Stack 30
Z_124 Z_125 E_0 H_0 
Stack 31
K_6 J_8 H_6 I_9 
Stack 32
J_3 A_0 Z_126 E_4 
Stack 33
E_7 D_5 G_2 E_6 
Stack 34
C_7 N_5 Z_127 A_1 
Stack 35
Z_128 I_3 J_10 L_0 
Stack 36
Z_129 O_4 Z_130 J_6 
Stack 37
Z_131 J_5 Z_132 E_10 
Stack 38
O_0 H_12 N_2 J_2 
Stack 39
C_2 G_8 I_13 H_7 
Stack 40
J_0 B_5 E_2 O_2 
Stack 41
K_0 I_1 K_4 Z_133 
Stack 42
N_4 A_2 M_3 L_6 
Stack 43
I_5 I_0 Z_134 J_7 
Stack 44
Z_135 F_0 F_9 A_8 
Stack 45
H_1 C_0 H_11 N_7 
Stack 46
K_7 M_1 D_7 L_1 
Stack 47
C_1 Z_136 D_6 M_0 
Stack 48
B_1 B_3 L_9 H_2 
Stack 49
Z_137 Z_138 Z_139 
