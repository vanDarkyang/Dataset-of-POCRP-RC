Number Of Containers
390
Number Of Yard Stacks
74
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
312
Number Of Shutout Containers
78
Yard Bay
Stack 0
G_15 N_0 J_5 R_9 D_1 F_5 
Stack 1
Q_1 K_11 D_4 Z_100 B_0 Z_101 
Stack 2
G_0 Z_102 L_1 L_11 L_3 Z_103 
Stack 3
Z_104 H_10 L_0 I_6 Z_105 K_12 
Stack 4
Q_12 T_6 L_10 Z_106 Z_107 M_10 
Stack 5
F_6 G_13 N_16 S_1 O_5 L_8 
Stack 6
M_0 Z_108 J_1 F_7 J_11 Z_109 
Stack 7
E_9 P_11 Z_110 E_14 Z_111 I_12 
Stack 8
B_11 M_3 Z_112 D_12 T_5 N_12 
Stack 9
D_11 T_2 B_7 G_4 K_1 M_16 
Stack 10
Z_113 Z_114 M_11 P_7 S_3 S_8 
Stack 11
Z_115 I_7 A_3 R_7 Z_116 Z_117 
Stack 12
G_7 G_5 J_0 G_9 A_11 Z_118 
Stack 13
Z_119 Q_4 G_10 Z_120 M_12 Z_121 
Stack 14
Z_122 L_4 E_2 M_4 O_8 I_14 
Stack 15
R_14 C_3 T_3 K_17 S_12 K_7 
Stack 16
F_8 N_15 S_2 K_13 N_2 H_8 
Stack 17
Z_123 C_2 C_1 P_10 K_20 I_4 
Stack 18
D_2 G_3 E_0 A_6 G_14 N_3 
Stack 19
I_13 Z_124 M_7 E_7 R_0 A_7 
Stack 20
P_2 S_9 Z_125 J_12 K_0 
Stack 21
Z_126 S_11 M_5 Q_0 O_7 
Stack 22
Z_127 Z_128 E_3 S_6 Z_129 
Stack 23
J_2 Z_130 P_13 R_1 Z_131 
Stack 24
Z_132 P_1 J_8 N_10 I_0 
Stack 25
Z_133 Q_8 Z_134 D_3 O_2 
Stack 26
T_9 N_7 C_11 P_4 L_14 
Stack 27
G_2 C_13 Z_135 T_1 Z_136 
Stack 28
B_2 E_11 B_15 N_13 L_5 
Stack 29
Q_6 O_14 Z_137 A_2 S_5 
Stack 30
H_6 H_7 A_1 P_8 D_10 
Stack 31
I_18 C_0 M_9 H_1 B_14 
Stack 32
Z_138 K_16 G_1 E_5 T_8 
Stack 33
R_13 A_4 C_6 I_8 Z_139 
Stack 34
C_15 Q_11 L_12 J_10 Q_14 
Stack 35
B_5 G_11 F_0 Z_140 Z_141 
Stack 36
K_19 A_9 G_12 N_11 E_12 
Stack 37
C_7 F_3 S_7 N_9 B_1 
Stack 38
Z_142 Z_143 K_3 I_15 R_4 
Stack 39
H_11 L_9 C_4 S_4 Z_144 
Stack 40
Z_145 Z_146 O_0 O_10 E_13 
Stack 41
O_4 R_12 Z_147 R_5 P_0 
Stack 42
N_17 E_6 Z_148 K_8 L_17 
Stack 43
J_16 H_5 M_15 B_13 C_10 
Stack 44
L_6 Z_149 Z_150 D_6 S_10 
Stack 45
Z_151 I_2 H_9 E_4 L_16 
Stack 46
T_7 O_11 H_3 O_3 Z_152 
Stack 47
I_10 R_2 Z_153 M_13 Q_2 
Stack 48
Z_154 R_10 H_13 R_6 E_1 
Stack 49
B_12 D_0 L_2 C_12 B_10 
Stack 50
R_8 A_10 J_13 Z_155 K_21 
Stack 51
Z_156 K_2 J_6 C_8 I_11 
Stack 52
D_8 K_14 Z_157 M_6 P_12 
Stack 53
F_10 B_3 D_9 K_4 Z_158 
Stack 54
J_4 J_15 D_7 S_0 O_1 
Stack 55
B_8 Z_159 L_15 N_1 C_5 
Stack 56
F_2 Z_160 T_4 J_3 B_9 
Stack 57
B_6 Q_5 O_12 J_7 H_12 
Stack 58
N_4 Z_161 Q_3 Z_162 P_3 
Stack 59
M_8 I_5 F_1 M_1 I_9 
Stack 60
K_15 Z_163 Q_15 Q_7 Z_164 
Stack 61
Z_165 P_9 L_18 K_10 K_6 
Stack 62
H_0 Z_166 Z_167 Q_13 N_6 
Stack 63
K_18 G_6 K_9 Z_168 I_3 
Stack 64
I_16 L_7 T_0 M_14 Z_169 
Stack 65
Z_170 R_11 A_0 N_8 A_8 
Stack 66
K_5 Q_10 F_4 B_4 F_11 
Stack 67
H_14 H_2 J_9 N_5 I_1 
Stack 68
E_8 I_17 L_13 M_2 O_6 
Stack 69
Z_171 P_6 C_14 Z_172 Z_173 
Stack 70
D_5 G_8 Z_174 O_13 Z_175 
Stack 71
F_9 P_5 H_4 A_5 J_14 
Stack 72
C_9 M_17 O_9 G_16 N_14 
Stack 73
E_10 Z_176 R_3 Z_177 Q_9 
