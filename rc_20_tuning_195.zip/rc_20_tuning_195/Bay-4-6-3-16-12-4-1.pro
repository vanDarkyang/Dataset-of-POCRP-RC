Number Of Containers
16
Number Of Yard Stacks
4
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
12
Number Of Shutout Containers
4
Yard Bay
Stack 0
Z_100 Z_101 B_1 C_1 
Stack 1
Z_102 B_2 C_0 C_3 
Stack 2
A_3 Z_103 B_3 B_0 
Stack 3
C_2 A_0 A_1 A_2 
