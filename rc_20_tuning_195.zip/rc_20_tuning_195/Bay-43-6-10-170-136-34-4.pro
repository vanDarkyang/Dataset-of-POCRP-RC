Number Of Containers
170
Number Of Yard Stacks
43
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
136
Number Of Shutout Containers
34
Yard Bay
Stack 0
H_4 D_7 E_0 H_2 
Stack 1
Z_100 H_9 Z_101 D_12 
Stack 2
C_0 G_8 G_5 Z_102 
Stack 3
D_1 J_5 Z_103 Z_104 
Stack 4
Z_105 I_0 Z_106 H_10 
Stack 5
F_9 E_6 Z_107 G_12 
Stack 6
J_2 A_4 A_3 I_3 
Stack 7
B_5 F_8 G_0 J_0 
Stack 8
E_10 G_4 F_7 Z_108 
Stack 9
E_12 Z_109 Z_110 I_12 
Stack 10
F_13 Z_111 Z_112 C_9 
Stack 11
C_11 Z_113 J_12 Z_114 
Stack 12
D_0 C_3 F_5 I_5 
Stack 13
Z_115 E_2 D_10 G_1 
Stack 14
J_6 I_1 J_3 B_0 
Stack 15
A_0 G_6 D_6 H_8 
Stack 16
F_10 J_7 B_12 E_3 
Stack 17
I_6 A_9 D_3 B_11 
Stack 18
C_7 D_13 J_4 Z_116 
Stack 19
C_6 D_14 G_9 Z_117 
Stack 20
J_11 H_1 J_1 D_2 
Stack 21
B_7 A_8 B_2 A_6 
Stack 22
C_4 Z_118 Z_119 G_7 
Stack 23
D_5 B_10 F_11 Z_120 
Stack 24
E_7 G_3 F_14 G_13 
Stack 25
Z_121 G_11 A_5 E_13 
Stack 26
Z_122 Z_123 H_3 B_4 
Stack 27
A_1 G_10 F_6 B_9 
Stack 28
J_8 D_4 I_8 Z_124 
Stack 29
J_13 Z_125 C_2 I_4 
Stack 30
D_9 Z_126 C_8 I_2 
Stack 31
E_5 F_4 I_9 Z_127 
Stack 32
E_11 F_2 I_7 J_10 
Stack 33
H_11 B_1 E_8 D_16 
Stack 34
H_7 F_0 H_6 J_9 
Stack 35
G_2 D_8 E_1 F_1 
Stack 36
I_11 B_6 B_3 E_4 
Stack 37
C_10 D_15 C_1 Z_128 
Stack 38
F_12 F_3 Z_129 H_0 
Stack 39
I_13 Z_130 A_10 Z_131 
Stack 40
B_8 A_7 C_5 Z_132 
Stack 41
I_10 Z_133 E_9 
Stack 42
D_11 H_5 A_2 
