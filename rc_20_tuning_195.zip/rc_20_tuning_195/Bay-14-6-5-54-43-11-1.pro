Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_6 B_5 A_2 A_4 
Stack 1
Z_100 D_6 E_5 A_5 
Stack 2
C_3 C_4 D_4 A_6 
Stack 3
A_7 E_0 Z_101 B_6 
Stack 4
B_0 Z_102 B_4 D_0 
Stack 5
A_3 E_2 Z_103 D_8 
Stack 6
C_5 C_8 A_0 D_7 
Stack 7
D_2 C_1 C_7 Z_104 
Stack 8
D_5 D_3 Z_105 B_2 
Stack 9
E_1 C_9 Z_106 Z_107 
Stack 10
E_4 A_1 B_3 C_10 
Stack 11
C_2 B_1 A_8 D_1 
Stack 12
Z_108 Z_109 E_3 
Stack 13
C_0 Z_110 B_7 
