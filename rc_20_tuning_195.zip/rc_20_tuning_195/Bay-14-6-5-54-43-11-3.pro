Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
D_5 E_0 C_6 B_8 
Stack 1
Z_100 D_3 C_9 A_0 
Stack 2
Z_101 C_7 C_2 E_4 
Stack 3
D_8 B_0 A_3 Z_102 
Stack 4
A_6 C_4 C_3 Z_103 
Stack 5
B_5 B_7 Z_104 A_1 
Stack 6
D_1 D_2 Z_105 Z_106 
Stack 7
D_0 A_5 E_6 Z_107 
Stack 8
D_6 C_8 Z_108 D_9 
Stack 9
C_1 E_3 E_1 B_2 
Stack 10
A_4 E_5 B_3 D_4 
Stack 11
B_4 B_6 B_1 C_5 
Stack 12
C_0 A_2 Z_109 
Stack 13
E_2 D_7 Z_110 
