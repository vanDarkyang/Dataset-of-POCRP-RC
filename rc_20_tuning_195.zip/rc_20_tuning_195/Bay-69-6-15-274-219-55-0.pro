Number Of Containers
274
Number Of Yard Stacks
69
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
219
Number Of Shutout Containers
55
Yard Bay
Stack 0
I_1 F_14 M_3 H_2 
Stack 1
B_5 B_8 N_4 Z_100 
Stack 2
B_2 Z_101 Z_102 I_9 
Stack 3
K_12 D_6 H_9 F_8 
Stack 4
F_9 E_7 M_7 L_4 
Stack 5
I_8 F_1 C_4 F_3 
Stack 6
I_7 A_0 C_9 D_4 
Stack 7
A_7 J_9 E_12 Z_103 
Stack 8
J_16 F_6 Z_104 G_8 
Stack 9
F_4 A_4 J_15 B_7 
Stack 10
Z_105 Z_106 B_9 I_4 
Stack 11
L_14 H_14 D_2 E_10 
Stack 12
D_8 G_15 L_11 N_10 
Stack 13
Z_107 E_11 E_1 J_12 
Stack 14
Z_108 O_6 E_8 C_8 
Stack 15
E_2 I_10 O_8 J_5 
Stack 16
Z_109 A_6 L_2 Z_110 
Stack 17
F_12 C_3 Z_111 K_6 
Stack 18
C_0 K_0 O_11 C_6 
Stack 19
B_12 M_4 J_10 Z_112 
Stack 20
H_10 K_4 H_4 F_2 
Stack 21
J_3 H_11 O_5 J_6 
Stack 22
F_0 K_14 K_9 N_7 
Stack 23
K_11 O_7 M_2 L_13 
Stack 24
A_3 Z_113 N_3 C_5 
Stack 25
Z_114 D_10 M_6 K_10 
Stack 26
K_7 F_10 G_13 Z_115 
Stack 27
Z_116 L_1 Z_117 G_1 
Stack 28
N_13 F_7 J_1 N_1 
Stack 29
H_7 C_1 Z_118 J_0 
Stack 30
L_7 J_8 O_1 G_5 
Stack 31
Z_119 Z_120 D_13 K_2 
Stack 32
Z_121 Z_122 J_11 K_13 
Stack 33
Z_123 I_0 I_11 C_10 
Stack 34
E_6 D_1 J_14 G_11 
Stack 35
D_7 G_0 I_6 G_2 
Stack 36
Z_124 J_2 F_13 B_11 
Stack 37
Z_125 Z_126 Z_127 N_12 
Stack 38
O_4 H_3 Z_128 H_13 
Stack 39
Z_129 G_12 J_7 I_5 
Stack 40
C_7 M_11 Z_130 Z_131 
Stack 41
K_1 E_0 L_15 L_6 
Stack 42
O_3 G_9 L_10 E_9 
Stack 43
Z_132 F_11 M_10 D_15 
Stack 44
O_12 L_12 K_3 I_12 
Stack 45
N_5 H_0 Z_133 Z_134 
Stack 46
G_10 Z_135 Z_136 M_5 
Stack 47
Z_137 Z_138 K_5 B_4 
Stack 48
Z_139 L_3 Z_140 N_14 
Stack 49
O_0 H_1 N_2 A_1 
Stack 50
J_13 Z_141 Z_142 D_12 
Stack 51
Z_143 D_0 A_8 E_13 
Stack 52
B_13 M_0 B_1 E_4 
Stack 53
O_2 M_8 G_7 F_15 
Stack 54
D_9 F_16 L_5 J_4 
Stack 55
H_6 G_6 A_5 D_3 
Stack 56
Z_144 M_1 H_5 K_8 
Stack 57
G_14 C_2 I_3 B_6 
Stack 58
Z_145 I_2 E_5 Z_146 
Stack 59
F_5 Z_147 E_14 N_0 
Stack 60
H_12 L_8 B_3 Z_148 
Stack 61
D_11 A_2 A_9 N_6 
Stack 62
C_11 N_9 C_12 B_0 
Stack 63
O_10 O_9 M_9 H_8 
Stack 64
Z_149 K_15 D_5 G_3 
Stack 65
Z_150 G_4 Z_151 B_10 
Stack 66
E_3 N_8 G_16 L_9 
Stack 67
N_11 L_0 Z_152 
Stack 68
Z_153 D_14 Z_154 
