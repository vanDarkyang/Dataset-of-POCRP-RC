Number Of Containers
31
Number Of Yard Stacks
6
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
24
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_1 B_6 A_1 A_0 C_7 C_2 
Stack 1
B_3 C_0 C_4 A_6 A_2 
Stack 2
B_4 Z_100 Z_101 B_2 Z_102 
Stack 3
Z_103 Z_104 B_5 C_6 C_8 
Stack 4
Z_105 B_0 C_5 C_3 A_4 
Stack 5
Z_106 B_1 B_7 A_3 A_5 
