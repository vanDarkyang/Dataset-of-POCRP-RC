Number Of Containers
199
Number Of Yard Stacks
38
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
159
Number Of Shutout Containers
40
Yard Bay
Stack 0
J_7 I_3 E_5 N_6 Z_100 Z_101 
Stack 1
H_6 H_2 E_2 I_6 C_6 G_4 
Stack 2
G_0 N_1 B_1 C_4 I_2 Z_102 
Stack 3
D_4 Z_103 L_6 Z_104 H_4 O_0 
Stack 4
D_3 Z_105 Z_106 I_10 Z_107 A_6 
Stack 5
K_8 Z_108 I_11 L_12 Z_109 C_10 
Stack 6
E_7 Z_110 O_4 B_3 I_9 K_7 
Stack 7
Z_111 L_1 L_3 L_11 Z_112 O_8 
Stack 8
K_2 K_6 L_4 K_9 H_8 F_6 
Stack 9
I_5 F_2 E_6 L_9 H_0 
Stack 10
Z_113 H_10 F_8 Z_114 Z_115 
Stack 11
F_0 C_3 F_7 N_0 B_4 
Stack 12
Z_116 K_0 E_4 K_12 Z_117 
Stack 13
Z_118 N_8 D_2 A_8 O_6 
Stack 14
Z_119 F_10 O_3 D_8 O_5 
Stack 15
A_1 O_2 K_1 Z_120 N_7 
Stack 16
G_7 N_5 Z_121 Z_122 O_7 
Stack 17
H_11 K_4 M_1 I_8 L_0 
Stack 18
I_0 H_1 Z_123 I_1 O_9 
Stack 19
J_8 M_3 H_12 I_7 Z_124 
Stack 20
E_8 D_1 J_0 Z_125 Z_126 
Stack 21
E_0 N_2 M_4 A_7 F_5 
Stack 22
J_4 N_9 Z_127 J_5 G_6 
Stack 23
G_8 H_7 Z_128 F_3 G_5 
Stack 24
L_2 E_1 M_8 L_8 G_2 
Stack 25
B_5 F_11 M_6 Z_129 D_7 
Stack 26
Z_130 D_0 G_10 O_1 J_2 
Stack 27
H_5 J_6 M_2 N_3 E_9 
Stack 28
M_5 H_9 J_1 F_1 Z_131 
Stack 29
K_11 B_2 L_7 Z_132 C_0 
Stack 30
C_9 B_0 M_0 D_6 G_3 
Stack 31
C_2 H_3 Z_133 A_4 A_3 
Stack 32
M_7 I_4 Z_134 Z_135 C_5 
Stack 33
J_3 K_3 L_5 A_5 Z_136 
Stack 34
A_0 I_12 F_4 K_5 G_9 
Stack 35
J_9 Z_137 Z_138 N_4 C_7 
Stack 36
G_1 F_9 K_10 A_2 C_1 
Stack 37
E_3 L_10 Z_139 D_5 C_8 
