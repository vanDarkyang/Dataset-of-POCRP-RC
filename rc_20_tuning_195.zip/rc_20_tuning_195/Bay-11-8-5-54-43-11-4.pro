Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_9 Z_100 Z_101 Z_102 E_3 
Stack 1
Z_103 Z_104 C_6 B_1 B_7 
Stack 2
E_6 B_4 C_4 B_3 D_1 
Stack 3
C_10 B_2 C_0 C_1 E_4 
Stack 4
D_2 E_5 Z_105 C_7 Z_106 
Stack 5
A_6 A_0 D_6 D_5 D_3 
Stack 6
D_0 C_2 A_4 A_2 Z_107 
Stack 7
E_0 E_2 Z_108 B_0 C_3 
Stack 8
A_7 C_8 A_1 B_6 A_3 
Stack 9
B_5 E_7 C_5 D_4 E_1 
Stack 10
Z_109 Z_110 E_8 A_5 
