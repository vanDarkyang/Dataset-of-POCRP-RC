Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_4 E_0 H_0 C_3 E_5 
Stack 1
E_2 J_1 E_1 J_2 G_1 
Stack 2
Z_100 D_1 I_1 I_3 C_1 
Stack 3
G_3 E_3 Z_101 J_0 I_0 
Stack 4
B_0 D_0 Z_102 G_2 B_2 
Stack 5
F_0 H_3 C_0 A_1 D_4 
Stack 6
D_3 G_4 Z_103 Z_104 Z_105 
Stack 7
Z_106 F_1 H_2 D_2 I_2 
Stack 8
Z_107 H_1 G_0 C_2 Z_108 
Stack 9
F_3 Z_109 A_0 F_2 B_1 
