Number Of Containers
390
Number Of Yard Stacks
74
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
312
Number Of Shutout Containers
78
Yard Bay
Stack 0
S_7 I_9 T_6 Z_100 A_6 L_0 
Stack 1
J_10 R_2 F_10 Z_101 D_13 J_6 
Stack 2
Z_102 Q_13 R_8 E_10 M_5 E_1 
Stack 3
L_18 Q_4 G_17 O_12 H_13 Z_103 
Stack 4
F_0 Z_104 C_8 D_1 I_18 Z_105 
Stack 5
Z_106 L_1 L_20 O_5 I_5 N_15 
Stack 6
L_12 A_2 L_5 I_16 P_11 J_2 
Stack 7
Z_107 Z_108 A_10 B_6 Z_109 Z_110 
Stack 8
Q_14 Z_111 L_13 I_10 Q_3 Z_112 
Stack 9
K_16 Z_113 E_5 E_3 Z_114 G_8 
Stack 10
K_5 Q_10 Z_115 N_4 S_10 T_2 
Stack 11
F_9 J_15 I_13 R_4 F_1 N_13 
Stack 12
G_15 A_0 M_1 G_14 B_0 N_3 
Stack 13
O_15 Z_116 M_4 Q_7 K_9 O_3 
Stack 14
Z_117 O_9 A_4 M_3 J_0 E_12 
Stack 15
Q_2 K_7 Z_118 K_15 T_5 F_12 
Stack 16
L_9 H_0 N_16 Z_119 Q_11 M_0 
Stack 17
J_17 Q_6 Z_120 J_11 S_4 I_1 
Stack 18
I_14 Z_121 T_8 R_13 Z_122 T_1 
Stack 19
Z_123 B_3 S_11 O_0 F_11 O_14 
Stack 20
C_5 B_1 K_14 Q_8 N_1 
Stack 21
J_12 G_12 Z_124 Z_125 Z_126 
Stack 22
H_8 G_16 N_14 S_12 P_1 
Stack 23
H_10 B_4 F_6 K_0 A_5 
Stack 24
Z_127 Q_9 S_6 Z_128 O_11 
Stack 25
Z_129 N_2 C_13 H_7 Z_130 
Stack 26
D_12 T_3 J_16 C_3 P_9 
Stack 27
K_12 G_7 J_8 F_5 H_9 
Stack 28
A_3 F_7 E_4 T_7 N_17 
Stack 29
G_2 S_13 O_8 R_7 M_2 
Stack 30
H_6 Z_131 D_9 Z_132 E_6 
Stack 31
O_2 I_3 G_3 K_17 N_10 
Stack 32
O_7 C_9 Z_133 C_4 N_8 
Stack 33
Z_134 O_13 Z_135 Z_136 K_11 
Stack 34
C_10 M_16 P_7 G_4 L_2 
Stack 35
Z_137 N_11 Z_138 P_6 K_3 
Stack 36
Z_139 B_7 H_5 E_9 F_8 
Stack 37
Z_140 E_8 P_10 R_1 D_8 
Stack 38
C_2 Z_141 J_7 D_6 Z_142 
Stack 39
Z_143 L_3 Z_144 S_9 D_4 
Stack 40
Z_145 H_12 C_15 P_3 I_6 
Stack 41
G_0 H_1 R_9 N_9 Z_146 
Stack 42
D_2 G_9 S_5 D_0 I_2 
Stack 43
L_10 D_10 R_3 J_18 G_1 
Stack 44
E_7 Z_147 R_0 S_0 L_15 
Stack 45
E_0 Z_148 M_6 C_14 T_0 
Stack 46
Z_149 K_1 Z_150 O_4 S_8 
Stack 47
L_7 I_8 Z_151 R_10 S_2 
Stack 48
L_17 Z_152 C_0 S_3 P_8 
Stack 49
Z_153 L_4 Z_154 B_5 J_9 
Stack 50
K_10 A_8 G_6 L_14 N_18 
Stack 51
M_14 M_9 K_8 O_16 S_1 
Stack 52
Z_155 Z_156 Q_5 Z_157 Q_1 
Stack 53
B_10 M_10 Q_0 I_4 I_15 
Stack 54
E_2 G_11 Z_158 Z_159 M_15 
Stack 55
P_2 A_1 C_11 L_19 H_15 
Stack 56
A_7 J_13 Z_160 C_6 N_12 
Stack 57
J_4 O_6 K_13 E_11 M_13 
Stack 58
I_11 G_13 I_12 F_3 H_11 
Stack 59
R_6 L_11 H_14 O_10 P_0 
Stack 60
Q_12 D_5 K_4 I_7 Z_161 
Stack 61
M_12 B_8 L_6 J_3 N_0 
Stack 62
I_17 P_4 E_13 D_11 Z_162 
Stack 63
N_5 Z_163 Z_164 J_1 N_6 
Stack 64
Z_165 R_11 B_2 Z_166 E_14 
Stack 65
Z_167 Z_168 K_2 J_5 Z_169 
Stack 66
H_17 D_7 H_16 C_7 Z_170 
Stack 67
R_5 O_1 M_7 Z_171 R_12 
Stack 68
M_11 G_18 M_8 H_4 K_6 
Stack 69
C_12 Z_172 A_9 P_5 H_2 
Stack 70
I_0 Z_173 F_4 C_1 Z_174 
Stack 71
A_11 D_3 G_10 N_7 F_2 
Stack 72
Z_175 G_5 L_16 Z_176 T_4 
Stack 73
B_9 Z_177 J_14 L_8 H_3 
