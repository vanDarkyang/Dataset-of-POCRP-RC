Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
H_0 G_2 A_0 I_0 
Stack 1
E_2 Z_100 Z_101 Z_102 
Stack 2
B_2 F_1 H_2 C_3 
Stack 3
F_3 I_2 G_3 D_2 
Stack 4
F_4 E_0 B_0 F_2 
Stack 5
D_1 A_1 Z_103 E_4 
Stack 6
C_0 D_0 I_1 Z_104 
Stack 7
D_3 F_0 I_3 A_2 
Stack 8
C_1 G_4 J_1 Z_105 
Stack 9
J_0 G_0 Z_106 Z_107 
Stack 10
E_3 G_5 B_3 C_2 
Stack 11
Z_108 E_1 Z_109 
Stack 12
B_1 H_1 G_1 
