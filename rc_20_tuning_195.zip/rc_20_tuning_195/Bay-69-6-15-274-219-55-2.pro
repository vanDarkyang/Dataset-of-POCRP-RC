Number Of Containers
274
Number Of Yard Stacks
69
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
219
Number Of Shutout Containers
55
Yard Bay
Stack 0
Z_100 Z_101 L_1 E_9 
Stack 1
A_4 K_13 Z_102 Z_103 
Stack 2
H_9 O_8 F_1 L_13 
Stack 3
G_3 K_12 Z_104 G_11 
Stack 4
G_14 A_1 D_1 C_11 
Stack 5
I_8 L_15 J_1 G_15 
Stack 6
F_12 F_9 A_5 L_4 
Stack 7
K_15 H_4 K_6 K_9 
Stack 8
F_11 K_5 G_8 N_10 
Stack 9
B_6 C_1 H_0 Z_105 
Stack 10
E_2 Z_106 L_10 B_9 
Stack 11
M_9 M_1 Z_107 M_13 
Stack 12
Z_108 M_8 I_9 M_6 
Stack 13
A_8 Z_109 Z_110 I_13 
Stack 14
G_6 F_6 Z_111 Z_112 
Stack 15
B_10 B_4 I_1 Z_113 
Stack 16
C_3 B_11 Z_114 H_17 
Stack 17
C_14 J_9 F_5 Z_115 
Stack 18
A_3 A_10 I_16 E_5 
Stack 19
J_10 B_3 N_0 J_2 
Stack 20
Z_116 H_6 Z_117 Z_118 
Stack 21
N_6 I_11 G_1 A_0 
Stack 22
Z_119 O_4 Z_120 E_4 
Stack 23
I_7 C_2 D_7 K_0 
Stack 24
B_13 H_15 G_13 F_0 
Stack 25
K_3 J_13 Z_121 B_7 
Stack 26
D_9 M_2 Z_122 O_7 
Stack 27
J_0 G_12 H_1 B_2 
Stack 28
L_12 L_7 O_9 K_2 
Stack 29
G_5 E_10 O_10 H_5 
Stack 30
I_3 O_6 H_10 H_2 
Stack 31
E_3 Z_123 L_0 Z_124 
Stack 32
I_6 E_7 J_4 F_8 
Stack 33
Z_125 L_6 B_8 H_3 
Stack 34
D_4 C_10 Z_126 Z_127 
Stack 35
Z_128 Z_129 A_2 C_12 
Stack 36
Z_130 L_14 Z_131 Z_132 
Stack 37
Z_133 N_8 C_5 O_5 
Stack 38
F_4 Z_134 Z_135 L_3 
Stack 39
I_14 Z_136 Z_137 D_10 
Stack 40
J_14 L_8 I_17 D_0 
Stack 41
Z_138 O_3 K_10 F_7 
Stack 42
Z_139 M_4 N_5 K_14 
Stack 43
N_3 O_12 M_0 E_11 
Stack 44
F_13 J_8 K_8 I_4 
Stack 45
M_7 E_13 C_7 H_8 
Stack 46
Z_140 C_4 K_11 E_15 
Stack 47
Z_141 Z_142 E_0 J_11 
Stack 48
H_14 O_1 I_12 E_8 
Stack 49
C_6 Z_143 G_10 D_5 
Stack 50
H_13 K_4 F_3 Z_144 
Stack 51
N_1 Z_145 E_1 E_12 
Stack 52
N_2 I_5 M_10 I_2 
Stack 53
H_7 C_8 O_11 E_14 
Stack 54
M_3 K_1 G_7 G_9 
Stack 55
J_12 H_16 N_7 I_10 
Stack 56
M_11 C_13 J_7 C_9 
Stack 57
Z_146 A_7 L_5 I_15 
Stack 58
B_0 J_5 F_2 Z_147 
Stack 59
F_10 M_5 L_9 E_6 
Stack 60
H_11 D_6 J_3 L_2 
Stack 61
L_11 B_5 M_12 D_8 
Stack 62
I_0 J_6 Z_148 A_6 
Stack 63
G_0 O_0 O_2 G_4 
Stack 64
N_4 D_3 Z_149 Z_150 
Stack 65
H_12 A_9 B_12 B_1 
Stack 66
A_11 C_0 K_7 G_2 
Stack 67
Z_151 Z_152 D_2 
Stack 68
Z_153 N_9 Z_154 
