Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_5 B_8 Z_100 D_7 
Stack 1
B_0 E_7 E_3 E_0 
Stack 2
A_6 Z_101 Z_102 E_6 
Stack 3
C_7 C_1 Z_103 D_6 
Stack 4
B_4 D_1 B_1 B_2 
Stack 5
A_2 C_2 Z_104 C_8 
Stack 6
E_2 C_6 E_8 D_2 
Stack 7
B_6 D_4 A_1 C_3 
Stack 8
Z_105 C_9 E_1 Z_106 
Stack 9
A_3 D_3 Z_107 A_4 
Stack 10
E_4 Z_108 C_4 Z_109 
Stack 11
B_3 A_0 D_5 E_5 
Stack 12
Z_110 C_5 D_0 
Stack 13
A_5 B_7 C_0 
