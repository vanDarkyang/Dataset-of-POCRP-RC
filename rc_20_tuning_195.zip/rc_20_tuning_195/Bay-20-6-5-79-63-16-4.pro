Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
D_12 B_12 A_7 D_5 
Stack 1
A_10 Z_100 B_0 Z_101 
Stack 2
Z_102 A_6 Z_103 B_5 
Stack 3
Z_104 B_2 B_6 Z_105 
Stack 4
D_6 D_0 B_10 C_5 
Stack 5
C_6 D_9 C_9 C_10 
Stack 6
D_1 D_8 Z_106 C_1 
Stack 7
E_1 B_8 Z_107 D_10 
Stack 8
D_2 C_2 E_5 A_2 
Stack 9
B_13 E_9 E_4 D_13 
Stack 10
Z_108 B_9 B_11 Z_109 
Stack 11
B_3 D_4 C_3 A_0 
Stack 12
D_3 Z_110 E_3 E_11 
Stack 13
A_5 D_7 B_1 A_3 
Stack 14
D_11 E_2 C_0 E_6 
Stack 15
Z_111 E_8 B_7 C_7 
Stack 16
E_10 A_4 Z_112 C_11 
Stack 17
A_9 C_4 B_4 Z_113 
Stack 18
A_8 C_8 E_0 E_7 
Stack 19
Z_114 A_1 Z_115 
