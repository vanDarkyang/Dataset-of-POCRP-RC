Number Of Containers
29
Number Of Yard Stacks
6
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
23
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_1 Z_100 A_0 D_3 Z_101 
Stack 1
B_0 C_5 D_1 C_1 B_3 
Stack 2
Z_102 B_4 D_2 A_2 E_0 
Stack 3
A_4 D_0 Z_103 C_0 A_3 
Stack 4
Z_104 E_2 B_2 E_1 B_1 
Stack 5
C_3 C_4 C_2 Z_105 
