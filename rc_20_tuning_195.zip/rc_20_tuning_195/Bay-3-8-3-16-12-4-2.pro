Number Of Containers
16
Number Of Yard Stacks
3
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
12
Number Of Shutout Containers
4
Yard Bay
Stack 0
Z_100 C_2 Z_101 B_4 B_1 B_3 
Stack 1
A_0 A_2 C_0 C_1 Z_102 
Stack 2
A_3 B_0 Z_103 A_1 B_2 
