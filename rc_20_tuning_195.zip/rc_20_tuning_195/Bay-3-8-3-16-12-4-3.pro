Number Of Containers
16
Number Of Yard Stacks
3
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
12
Number Of Shutout Containers
4
Yard Bay
Stack 0
B_3 A_0 B_2 Z_100 Z_101 A_2 
Stack 1
A_1 A_3 C_2 B_4 B_0 
Stack 2
Z_102 Z_103 C_0 B_1 C_1 
