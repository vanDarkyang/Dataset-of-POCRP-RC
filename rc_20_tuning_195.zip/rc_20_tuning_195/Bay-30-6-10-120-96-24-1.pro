Number Of Containers
120
Number Of Yard Stacks
30
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
G_1 Z_100 G_5 J_1 
Stack 1
G_6 Z_101 H_2 Z_102 
Stack 2
H_8 B_7 H_7 B_1 
Stack 3
G_0 I_5 A_3 Z_103 
Stack 4
I_3 I_7 F_6 E_0 
Stack 5
D_4 A_1 G_2 Z_104 
Stack 6
H_4 D_1 F_0 I_6 
Stack 7
Z_105 H_9 C_1 B_10 
Stack 8
C_10 Z_106 Z_107 F_7 
Stack 9
H_1 E_4 J_3 F_4 
Stack 10
Z_108 D_3 A_6 H_6 
Stack 11
E_7 Z_109 Z_110 C_7 
Stack 12
Z_111 E_9 C_6 F_10 
Stack 13
J_2 Z_112 E_3 B_3 
Stack 14
E_6 E_1 C_3 G_4 
Stack 15
J_5 H_3 I_4 E_2 
Stack 16
B_8 D_0 G_8 G_3 
Stack 17
C_5 H_5 B_0 H_0 
Stack 18
F_5 E_5 Z_113 D_5 
Stack 19
Z_114 Z_115 D_6 D_9 
Stack 20
Z_116 B_9 C_2 B_2 
Stack 21
Z_117 E_8 J_4 I_2 
Stack 22
C_8 E_11 A_5 Z_118 
Stack 23
Z_119 B_6 F_2 A_4 
Stack 24
C_9 Z_120 E_10 F_8 
Stack 25
J_0 Z_121 A_2 Z_122 
Stack 26
F_1 C_4 G_7 B_4 
Stack 27
B_5 C_0 I_0 D_8 
Stack 28
Z_123 F_3 J_6 F_9 
Stack 29
D_7 D_2 I_1 A_0 
