Number Of Containers
19
Number Of Yard Stacks
5
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
15
Number Of Shutout Containers
4
Yard Bay
Stack 0
B_1 C_1 B_3 Z_100 
Stack 1
A_0 Z_101 A_1 C_2 
Stack 2
D_0 Z_102 D_3 B_0 
Stack 3
B_2 D_1 E_0 E_1 
Stack 4
C_0 D_2 Z_103 
