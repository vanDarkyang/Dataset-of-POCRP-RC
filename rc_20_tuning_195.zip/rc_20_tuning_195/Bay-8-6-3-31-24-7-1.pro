Number Of Containers
31
Number Of Yard Stacks
8
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
24
Number Of Shutout Containers
7
Yard Bay
Stack 0
Z_100 B_3 B_7 B_6 
Stack 1
A_6 Z_101 A_1 C_7 
Stack 2
C_5 B_2 B_4 C_3 
Stack 3
A_5 A_4 C_6 Z_102 
Stack 4
A_0 A_3 C_1 B_8 
Stack 5
Z_103 B_5 C_4 B_1 
Stack 6
B_0 A_2 Z_104 C_0 
Stack 7
Z_105 C_2 Z_106 
