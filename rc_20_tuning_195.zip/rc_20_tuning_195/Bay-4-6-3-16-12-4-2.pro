Number Of Containers
16
Number Of Yard Stacks
4
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
12
Number Of Shutout Containers
4
Yard Bay
Stack 0
C_2 A_1 Z_100 B_2 
Stack 1
A_0 B_0 Z_101 A_3 
Stack 2
A_2 B_1 C_1 B_3 
Stack 3
Z_102 C_0 Z_103 B_4 
