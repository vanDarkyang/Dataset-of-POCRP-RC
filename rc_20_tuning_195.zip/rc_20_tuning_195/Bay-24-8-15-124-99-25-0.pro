Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
H_3 L_1 Z_100 H_9 J_2 Z_101 
Stack 1
Z_102 Z_103 Z_104 H_2 Z_105 G_2 
Stack 2
Z_106 K_1 M_0 L_4 F_2 O_1 
Stack 3
F_0 G_1 J_1 J_4 A_3 E_0 
Stack 4
O_2 G_7 L_2 Z_107 E_6 
Stack 5
B_0 I_5 A_4 Z_108 O_0 
Stack 6
H_1 F_3 Z_109 A_1 H_8 
Stack 7
Z_110 J_3 C_4 Z_111 I_7 
Stack 8
K_6 C_3 I_3 B_2 Z_112 
Stack 9
L_0 M_5 Z_113 E_2 M_3 
Stack 10
A_0 I_1 N_0 I_0 A_2 
Stack 11
K_0 O_3 J_8 G_3 Z_114 
Stack 12
C_5 O_4 J_0 D_1 K_5 
Stack 13
D_0 K_2 D_2 Z_115 C_1 
Stack 14
I_4 G_5 Z_116 I_6 N_3 
Stack 15
Z_117 F_6 M_4 N_1 E_4 
Stack 16
H_5 C_0 D_3 Z_118 G_0 
Stack 17
F_4 G_6 D_5 B_3 J_7 
Stack 18
E_5 N_4 E_1 G_4 D_4 
Stack 19
Z_119 K_3 N_2 H_6 Z_120 
Stack 20
C_2 Z_121 I_2 H_7 F_7 
Stack 21
M_1 B_1 F_1 L_3 Z_122 
Stack 22
E_3 M_2 J_5 Z_123 H_4 
Stack 23
Z_124 H_0 K_4 F_5 J_6 
