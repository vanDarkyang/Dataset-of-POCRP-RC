Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
D_9 E_2 D_8 C_5 
Stack 1
C_9 Z_100 Z_101 E_1 
Stack 2
B_0 C_8 E_6 C_4 
Stack 3
C_15 Z_102 D_0 E_8 
Stack 4
C_2 C_0 Z_103 E_3 
Stack 5
Z_104 C_12 Z_105 A_1 
Stack 6
Z_106 Z_107 A_8 Z_108 
Stack 7
A_10 D_10 D_4 E_7 
Stack 8
Z_109 C_7 Z_110 C_14 
Stack 9
D_5 B_6 D_6 D_2 
Stack 10
B_8 B_5 D_13 B_10 
Stack 11
Z_111 B_2 C_3 B_9 
Stack 12
A_0 A_7 D_3 E_4 
Stack 13
C_10 A_2 Z_112 A_3 
Stack 14
B_7 C_1 D_11 A_5 
Stack 15
E_9 E_10 C_11 B_4 
Stack 16
C_13 Z_113 D_7 B_3 
Stack 17
A_4 Z_114 D_12 Z_115 
Stack 18
C_6 E_5 A_6 B_1 
Stack 19
A_9 E_0 D_1 
