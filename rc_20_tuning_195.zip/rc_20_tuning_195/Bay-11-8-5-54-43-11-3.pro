Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
D_4 B_2 Z_100 C_7 E_6 
Stack 1
C_1 C_0 E_5 B_1 E_2 
Stack 2
B_6 E_3 E_7 E_8 A_6 
Stack 3
Z_101 E_0 B_4 A_2 A_3 
Stack 4
A_9 Z_102 A_4 E_1 A_1 
Stack 5
B_3 Z_103 D_6 Z_104 Z_105 
Stack 6
D_1 Z_106 Z_107 Z_108 D_7 
Stack 7
D_0 C_5 C_8 E_4 B_0 
Stack 8
D_5 B_5 C_3 Z_109 D_3 
Stack 9
C_2 D_2 A_5 Z_110 C_6 
Stack 10
A_7 A_8 C_4 A_0 
