Number Of Containers
16
Number Of Yard Stacks
4
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
12
Number Of Shutout Containers
4
Yard Bay
Stack 0
B_3 A_2 Z_100 C_0 
Stack 1
A_0 B_5 A_3 B_0 
Stack 2
Z_101 B_2 B_4 Z_102 
Stack 3
Z_103 C_1 B_1 A_1 
