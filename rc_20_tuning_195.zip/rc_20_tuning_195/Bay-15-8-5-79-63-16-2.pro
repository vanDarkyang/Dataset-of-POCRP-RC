Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 C_7 Z_101 A_3 Z_102 Z_103 
Stack 1
C_3 B_4 E_0 A_1 C_11 E_5 
Stack 2
A_6 D_4 B_2 D_8 D_10 A_4 
Stack 3
Z_104 Z_105 E_2 D_12 B_8 A_7 
Stack 4
D_3 E_3 C_12 B_11 B_0 
Stack 5
D_2 E_11 C_8 A_9 A_8 
Stack 6
B_3 Z_106 Z_107 D_5 Z_108 
Stack 7
B_9 C_9 C_1 Z_109 D_7 
Stack 8
C_0 D_0 E_10 C_13 E_7 
Stack 9
B_12 C_6 B_5 D_11 C_2 
Stack 10
B_7 C_4 D_6 C_5 A_5 
Stack 11
A_2 Z_110 C_10 B_6 B_1 
Stack 12
E_9 E_6 E_1 D_1 Z_111 
Stack 13
E_8 Z_112 Z_113 A_0 E_4 
Stack 14
Z_114 D_9 B_10 Z_115 E_12 
