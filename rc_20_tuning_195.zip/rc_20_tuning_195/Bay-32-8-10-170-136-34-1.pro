Number Of Containers
170
Number Of Yard Stacks
32
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
136
Number Of Shutout Containers
34
Yard Bay
Stack 0
Z_100 E_14 B_9 F_1 I_2 G_3 
Stack 1
D_11 D_9 J_2 B_0 I_7 E_5 
Stack 2
A_4 H_0 J_10 D_7 Z_101 H_4 
Stack 3
Z_102 Z_103 J_6 H_6 E_10 I_3 
Stack 4
J_1 E_7 E_13 B_6 I_6 A_0 
Stack 5
J_3 A_9 Z_104 Z_105 A_2 B_12 
Stack 6
G_10 Z_106 H_8 E_2 I_12 G_4 
Stack 7
D_12 E_3 F_2 C_0 E_6 I_0 
Stack 8
Z_107 Z_108 Z_109 H_3 Z_110 A_6 
Stack 9
G_8 G_6 G_2 Z_111 B_3 I_13 
Stack 10
C_9 E_1 J_4 D_6 H_5 
Stack 11
B_4 F_7 C_7 D_14 C_4 
Stack 12
B_2 Z_112 F_4 D_1 B_5 
Stack 13
H_2 I_4 C_8 Z_113 F_8 
Stack 14
A_10 Z_114 H_10 G_7 D_2 
Stack 15
D_8 Z_115 C_2 G_1 E_11 
Stack 16
B_8 B_1 Z_116 E_4 A_3 
Stack 17
J_5 F_0 F_10 I_1 Z_117 
Stack 18
C_5 H_7 I_5 G_14 F_6 
Stack 19
C_3 J_11 C_6 B_10 H_12 
Stack 20
Z_118 B_7 B_11 D_15 G_13 
Stack 21
Z_119 B_13 Z_120 H_11 Z_121 
Stack 22
I_9 D_4 Z_122 I_10 Z_123 
Stack 23
D_0 H_1 Z_124 D_10 J_8 
Stack 24
A_5 Z_125 G_0 C_1 J_9 
Stack 25
F_9 D_5 Z_126 D_3 Z_127 
Stack 26
A_7 E_8 E_0 Z_128 Z_129 
Stack 27
Z_130 I_11 F_3 J_0 C_12 
Stack 28
Z_131 H_9 G_5 F_5 E_12 
Stack 29
J_7 G_12 D_13 F_12 C_10 
Stack 30
G_11 E_9 I_8 A_8 C_11 
Stack 31
F_11 Z_132 G_9 A_1 Z_133 
