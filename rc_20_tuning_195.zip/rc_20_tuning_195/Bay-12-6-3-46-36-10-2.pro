Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_4 A_11 A_4 Z_100 
Stack 1
B_6 Z_101 B_1 B_0 
Stack 2
Z_102 Z_103 C_7 C_6 
Stack 3
A_0 B_2 C_12 B_9 
Stack 4
A_9 Z_104 B_7 C_5 
Stack 5
Z_105 Z_106 A_5 C_8 
Stack 6
C_11 C_4 C_10 A_3 
Stack 7
A_1 B_5 B_3 C_1 
Stack 8
Z_107 B_8 B_10 Z_108 
Stack 9
A_2 A_8 Z_109 C_2 
Stack 10
A_7 C_0 C_9 
Stack 11
A_10 C_3 A_6 
