Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_0 I_2 E_5 Z_100 
Stack 1
C_4 E_0 H_1 Z_101 
Stack 2
B_2 Z_102 G_0 G_1 
Stack 3
Z_103 F_0 F_2 I_0 
Stack 4
C_1 J_1 Z_104 G_2 
Stack 5
B_1 D_1 Z_105 Z_106 
Stack 6
Z_107 E_1 I_1 C_2 
Stack 7
A_1 B_0 H_3 D_3 
Stack 8
Z_108 E_6 D_0 F_3 
Stack 9
F_1 H_2 F_4 F_5 
Stack 10
E_3 D_2 E_2 E_4 
Stack 11
Z_109 G_3 H_0 
Stack 12
C_3 J_0 C_0 
