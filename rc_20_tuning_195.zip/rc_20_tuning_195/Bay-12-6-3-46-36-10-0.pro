Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_5 Z_100 A_5 C_1 
Stack 1
A_3 B_11 A_4 B_7 
Stack 2
A_9 B_8 C_6 C_2 
Stack 3
A_10 C_3 C_8 Z_101 
Stack 4
Z_102 A_11 A_8 Z_103 
Stack 5
A_2 B_2 B_6 B_3 
Stack 6
B_1 A_0 B_4 C_5 
Stack 7
Z_104 B_12 Z_105 Z_106 
Stack 8
A_7 C_9 B_10 Z_107 
Stack 9
C_4 B_13 B_0 C_7 
Stack 10
C_0 A_1 B_9 
Stack 11
Z_108 A_6 Z_109 
