Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_10 B_2 A_4 D_2 
Stack 1
B_1 E_5 Z_100 A_5 
Stack 2
E_6 Z_101 A_1 Z_102 
Stack 3
C_11 C_3 C_6 Z_103 
Stack 4
D_1 E_3 E_7 Z_104 
Stack 5
Z_105 C_9 E_0 E_4 
Stack 6
D_0 Z_106 Z_107 A_6 
Stack 7
E_1 Z_108 B_3 Z_109 
Stack 8
A_7 D_6 C_2 B_7 
Stack 9
B_5 C_7 C_8 C_4 
Stack 10
A_0 C_5 D_3 A_3 
Stack 11
Z_110 C_1 A_2 E_2 
Stack 12
D_4 C_0 B_0 
Stack 13
B_4 D_5 B_6 
