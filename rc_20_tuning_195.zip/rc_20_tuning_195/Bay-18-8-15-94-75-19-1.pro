Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
D_1 E_5 A_1 A_0 Z_100 H_2 
Stack 1
K_3 Z_101 J_0 I_4 L_0 I_0 
Stack 2
H_5 J_2 Z_102 D_3 D_0 E_2 
Stack 3
H_7 I_1 H_4 B_1 Z_103 M_1 
Stack 4
F_1 Z_104 C_3 F_3 F_2 
Stack 5
H_6 I_5 Z_105 K_1 C_2 
Stack 6
E_1 Z_106 G_1 K_5 M_2 
Stack 7
M_3 L_2 Z_107 G_2 H_0 
Stack 8
N_0 Z_108 I_6 H_3 J_4 
Stack 9
L_1 Z_109 G_0 E_0 Z_110 
Stack 10
Z_111 I_2 C_1 E_3 N_2 
Stack 11
B_0 Z_112 J_6 I_3 N_1 
Stack 12
G_5 O_2 H_1 J_5 Z_113 
Stack 13
O_1 K_0 E_4 L_4 F_0 
Stack 14
Z_114 C_4 K_4 I_7 D_2 
Stack 15
J_3 K_2 J_1 C_0 Z_115 
Stack 16
B_2 G_3 Z_116 L_3 Z_117 
Stack 17
M_0 O_0 Z_118 I_8 G_4 
