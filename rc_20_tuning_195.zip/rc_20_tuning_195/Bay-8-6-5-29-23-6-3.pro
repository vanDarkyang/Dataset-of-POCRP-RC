Number Of Containers
29
Number Of Yard Stacks
8
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
23
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_3 Z_100 D_2 B_1 
Stack 1
B_0 Z_101 E_1 Z_102 
Stack 2
B_3 Z_103 D_0 Z_104 
Stack 3
A_2 A_1 Z_105 B_4 
Stack 4
C_1 C_0 E_4 A_3 
Stack 5
D_3 E_3 A_0 
Stack 6
C_4 E_0 B_2 
Stack 7
C_2 E_2 D_1 
