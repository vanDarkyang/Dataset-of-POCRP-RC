Number Of Containers
199
Number Of Yard Stacks
50
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
159
Number Of Shutout Containers
40
Yard Bay
Stack 0
H_10 K_7 Z_100 C_10 
Stack 1
J_7 M_3 D_9 E_3 
Stack 2
F_7 L_0 B_1 C_2 
Stack 3
L_4 A_3 M_9 C_1 
Stack 4
K_6 C_7 F_4 Z_101 
Stack 5
Z_102 I_8 H_5 M_4 
Stack 6
L_3 O_0 C_3 N_6 
Stack 7
E_9 Z_103 H_0 M_10 
Stack 8
Z_104 Z_105 G_10 N_4 
Stack 9
B_6 Z_106 H_9 L_11 
Stack 10
L_8 M_5 M_1 Z_107 
Stack 11
Z_108 G_2 J_3 Z_109 
Stack 12
F_12 F_8 G_4 Z_110 
Stack 13
A_0 Z_111 F_11 E_5 
Stack 14
I_7 Z_112 Z_113 B_2 
Stack 15
A_5 M_8 J_10 E_4 
Stack 16
L_9 A_6 I_1 I_4 
Stack 17
J_4 J_1 Z_114 J_0 
Stack 18
N_5 D_5 K_9 Z_115 
Stack 19
C_8 Z_116 G_8 D_7 
Stack 20
K_0 H_2 C_6 K_10 
Stack 21
J_2 D_4 E_8 I_9 
Stack 22
G_11 Z_117 Z_118 Z_119 
Stack 23
K_8 L_6 B_4 F_10 
Stack 24
F_9 A_1 K_3 F_6 
Stack 25
L_2 K_4 Z_120 D_3 
Stack 26
K_2 J_6 Z_121 D_6 
Stack 27
I_12 N_3 I_10 D_0 
Stack 28
H_12 F_5 L_5 E_0 
Stack 29
Z_122 O_2 H_7 Z_123 
Stack 30
M_7 N_8 Z_124 Z_125 
Stack 31
K_1 H_3 B_0 N_7 
Stack 32
Z_126 Z_127 C_4 H_11 
Stack 33
K_5 L_12 I_0 D_8 
Stack 34
H_8 G_7 N_2 O_4 
Stack 35
G_5 Z_128 O_1 L_7 
Stack 36
C_9 O_3 Z_129 I_11 
Stack 37
Z_130 A_4 C_5 Z_131 
Stack 38
Z_132 G_0 G_6 C_0 
Stack 39
M_2 M_6 G_1 Z_133 
Stack 40
B_3 F_3 J_11 J_9 
Stack 41
E_7 Z_134 I_3 E_2 
Stack 42
H_1 N_0 L_1 L_10 
Stack 43
Z_135 B_7 Z_136 F_1 
Stack 44
E_1 Z_137 I_5 B_5 
Stack 45
J_5 A_2 G_9 G_12 
Stack 46
F_2 H_6 J_8 N_1 
Stack 47
D_2 E_6 M_0 Z_138 
Stack 48
G_3 Z_139 I_6 I_2 
Stack 49
D_1 H_4 F_0 
