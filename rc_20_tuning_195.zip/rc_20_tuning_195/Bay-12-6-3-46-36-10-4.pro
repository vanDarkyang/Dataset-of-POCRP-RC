Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 B_0 B_6 C_5 
Stack 1
B_7 C_3 B_9 C_10 
Stack 2
C_11 Z_101 A_7 B_5 
Stack 3
Z_102 C_9 B_12 Z_103 
Stack 4
A_4 C_6 C_0 A_3 
Stack 5
C_2 A_0 C_7 Z_104 
Stack 6
B_3 B_11 B_10 C_4 
Stack 7
Z_105 B_4 Z_106 Z_107 
Stack 8
B_1 A_1 A_9 A_8 
Stack 9
Z_108 A_2 B_2 B_8 
Stack 10
Z_109 A_5 C_8 
Stack 11
C_1 A_10 A_6 
