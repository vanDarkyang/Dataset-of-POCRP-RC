Number Of Containers
170
Number Of Yard Stacks
32
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
136
Number Of Shutout Containers
34
Yard Bay
Stack 0
Z_100 D_2 C_7 B_13 H_6 J_4 
Stack 1
H_8 Z_101 C_2 H_7 A_2 Z_102 
Stack 2
H_9 C_8 F_12 C_4 C_6 A_9 
Stack 3
F_7 J_3 D_10 Z_103 J_2 Z_104 
Stack 4
G_15 D_9 I_5 C_11 F_10 Z_105 
Stack 5
G_12 Z_106 B_6 G_10 Z_107 G_2 
Stack 6
Z_108 D_3 E_5 Z_109 Z_110 Z_111 
Stack 7
E_4 A_3 B_5 B_10 I_13 H_5 
Stack 8
E_11 Z_112 E_8 F_3 C_10 I_11 
Stack 9
G_6 F_2 Z_113 G_3 G_13 E_2 
Stack 10
Z_114 G_14 D_4 B_4 B_3 
Stack 11
H_3 D_7 Z_115 Z_116 J_11 
Stack 12
I_1 G_1 C_1 Z_117 Z_118 
Stack 13
F_14 H_0 C_0 H_2 G_7 
Stack 14
Z_119 I_10 Z_120 B_1 A_7 
Stack 15
E_0 Z_121 F_8 J_10 H_1 
Stack 16
F_0 A_0 A_10 E_13 Z_122 
Stack 17
I_9 G_0 B_7 B_2 B_8 
Stack 18
I_0 B_11 C_9 D_0 H_10 
Stack 19
D_1 C_5 G_8 Z_123 F_16 
Stack 20
E_7 E_9 A_1 J_7 I_2 
Stack 21
B_0 Z_124 Z_125 I_7 J_8 
Stack 22
J_5 D_6 B_9 A_6 F_5 
Stack 23
D_8 D_5 Z_126 D_11 I_8 
Stack 24
E_6 G_4 G_5 E_14 I_3 
Stack 25
E_3 J_0 I_12 Z_127 F_15 
Stack 26
G_11 Z_128 B_12 Z_129 Z_130 
Stack 27
J_6 D_12 A_4 F_6 H_4 
Stack 28
J_9 E_10 I_6 C_3 I_4 
Stack 29
G_16 F_9 Z_131 J_1 F_11 
Stack 30
G_9 Z_132 E_12 Z_133 A_8 
Stack 31
E_1 A_5 F_4 F_1 F_13 
