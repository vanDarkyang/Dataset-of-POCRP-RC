Number Of Containers
290
Number Of Yard Stacks
73
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
232
Number Of Shutout Containers
58
Yard Bay
Stack 0
M_10 I_11 Z_100 I_5 
Stack 1
C_2 Z_101 D_10 Z_102 
Stack 2
Z_103 H_1 J_7 D_3 
Stack 3
A_0 M_0 F_8 I_2 
Stack 4
I_10 F_9 Z_104 E_5 
Stack 5
Z_105 Z_106 Z_107 Q_3 
Stack 6
T_6 Q_2 Q_7 J_4 
Stack 7
J_3 K_12 M_5 O_3 
Stack 8
P_7 I_12 Z_108 I_6 
Stack 9
G_2 K_1 M_9 D_9 
Stack 10
P_6 A_4 E_3 O_6 
Stack 11
A_7 I_7 N_1 I_3 
Stack 12
P_9 I_1 A_5 F_7 
Stack 13
S_6 K_10 L_9 Z_109 
Stack 14
T_4 A_8 E_7 M_6 
Stack 15
M_4 I_4 Z_110 R_0 
Stack 16
E_11 Z_111 A_3 D_8 
Stack 17
Z_112 Z_113 N_5 C_5 
Stack 18
G_1 C_4 Z_114 Q_0 
Stack 19
N_11 R_3 Z_115 Z_116 
Stack 20
N_6 R_4 E_2 Z_117 
Stack 21
M_2 A_1 I_8 H_6 
Stack 22
I_14 K_5 Z_118 A_6 
Stack 23
Z_119 Z_120 H_3 C_6 
Stack 24
G_6 C_7 S_2 R_6 
Stack 25
D_6 Q_9 Z_121 P_8 
Stack 26
F_6 L_2 B_7 H_13 
Stack 27
Z_122 Z_123 Q_6 G_5 
Stack 28
N_13 B_8 H_8 I_13 
Stack 29
L_6 I_0 H_11 R_5 
Stack 30
D_7 Z_124 S_5 B_4 
Stack 31
B_1 J_1 B_2 F_0 
Stack 32
Z_125 E_8 O_7 N_10 
Stack 33
Z_126 I_15 R_9 A_2 
Stack 34
H_10 Z_127 Z_128 M_12 
Stack 35
E_1 D_4 Z_129 F_1 
Stack 36
G_9 B_6 E_12 O_5 
Stack 37
M_11 J_10 G_0 Z_130 
Stack 38
E_4 N_8 N_3 S_0 
Stack 39
L_4 B_0 Z_131 C_8 
Stack 40
H_12 Z_132 T_3 C_1 
Stack 41
K_3 D_5 Z_133 R_8 
Stack 42
J_8 P_4 T_7 Z_134 
Stack 43
S_7 F_2 L_14 D_0 
Stack 44
L_0 L_13 Z_135 F_3 
Stack 45
J_0 K_7 Z_136 M_7 
Stack 46
I_16 N_0 Z_137 P_1 
Stack 47
R_2 G_4 N_7 K_11 
Stack 48
E_6 G_10 R_1 F_10 
Stack 49
H_2 Z_138 D_1 M_8 
Stack 50
Z_139 L_7 S_3 Z_140 
Stack 51
Z_141 M_3 L_3 P_5 
Stack 52
Z_142 Z_143 N_9 N_2 
Stack 53
B_5 H_4 Z_144 G_7 
Stack 54
J_5 Q_8 Q_5 P_3 
Stack 55
G_3 H_5 R_10 P_0 
Stack 56
T_1 G_11 H_0 K_4 
Stack 57
M_1 H_9 Z_145 Z_146 
Stack 58
T_0 H_7 O_2 Z_147 
Stack 59
G_8 O_4 Q_4 Z_148 
Stack 60
F_5 C_3 Q_1 L_5 
Stack 61
L_1 L_11 D_2 P_2 
Stack 62
E_10 Z_149 N_12 T_2 
Stack 63
Z_150 K_2 L_8 J_2 
Stack 64
K_8 J_11 O_1 Z_151 
Stack 65
S_4 R_7 T_5 B_3 
Stack 66
E_0 N_4 K_9 L_12 
Stack 67
J_9 F_4 O_9 Z_152 
Stack 68
L_10 K_0 Z_153 D_11 
Stack 69
K_6 O_10 S_1 Z_154 
Stack 70
C_0 Z_155 I_9 Z_156 
Stack 71
J_6 N_14 O_0 
Stack 72
E_9 Z_157 O_8 
