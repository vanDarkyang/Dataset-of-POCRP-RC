Number Of Containers
290
Number Of Yard Stacks
73
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
232
Number Of Shutout Containers
58
Yard Bay
Stack 0
F_6 M_0 F_3 G_0 
Stack 1
L_4 L_13 J_1 N_6 
Stack 2
S_2 H_14 K_8 H_13 
Stack 3
N_9 G_6 B_0 F_2 
Stack 4
N_7 J_11 Z_100 B_6 
Stack 5
Z_101 F_1 M_10 E_7 
Stack 6
I_9 Q_6 Q_2 P_6 
Stack 7
Q_0 L_2 N_4 Q_7 
Stack 8
K_9 M_13 K_4 Z_102 
Stack 9
O_10 L_7 J_2 R_4 
Stack 10
K_13 Z_103 Z_104 D_2 
Stack 11
Z_105 E_1 F_9 J_0 
Stack 12
K_14 Z_106 P_1 Q_4 
Stack 13
Z_107 J_14 S_8 B_3 
Stack 14
A_0 K_7 K_6 Z_108 
Stack 15
G_4 A_6 O_5 P_10 
Stack 16
C_7 H_9 M_15 M_14 
Stack 17
Q_1 E_2 I_1 I_8 
Stack 18
E_3 K_3 E_5 G_10 
Stack 19
L_3 L_1 Z_109 J_5 
Stack 20
P_7 P_3 D_8 H_12 
Stack 21
M_8 I_7 I_2 Z_110 
Stack 22
Z_111 M_1 Z_112 L_9 
Stack 23
K_1 F_11 Z_113 T_3 
Stack 24
N_8 N_5 Q_9 K_0 
Stack 25
O_3 Z_114 S_5 C_1 
Stack 26
J_7 Z_115 G_3 F_8 
Stack 27
N_2 I_14 H_1 C_5 
Stack 28
E_0 P_8 O_4 M_7 
Stack 29
A_1 Z_116 Q_5 T_5 
Stack 30
G_2 Z_117 N_1 R_1 
Stack 31
G_5 S_3 L_5 K_2 
Stack 32
T_2 Z_118 D_1 T_0 
Stack 33
I_5 F_4 S_0 H_10 
Stack 34
Z_119 I_4 Z_120 G_11 
Stack 35
O_6 M_2 M_11 H_11 
Stack 36
Z_121 Z_122 Z_123 R_3 
Stack 37
D_3 Z_124 L_11 R_2 
Stack 38
E_4 C_9 J_6 F_12 
Stack 39
K_11 P_5 I_0 O_1 
Stack 40
O_12 J_3 H_0 J_13 
Stack 41
J_4 Z_125 Z_126 C_6 
Stack 42
Q_8 M_9 Z_127 B_1 
Stack 43
L_8 I_10 I_13 Z_128 
Stack 44
I_15 D_4 Z_129 P_12 
Stack 45
G_7 Z_130 F_10 T_6 
Stack 46
K_10 M_3 Z_131 Z_132 
Stack 47
H_8 R_0 N_10 H_7 
Stack 48
Z_133 B_2 Z_134 Z_135 
Stack 49
Z_136 Z_137 G_8 Z_138 
Stack 50
J_8 H_6 K_5 D_0 
Stack 51
A_4 R_6 Z_139 N_0 
Stack 52
B_4 P_11 C_3 P_4 
Stack 53
Z_140 M_4 Z_141 I_11 
Stack 54
O_9 G_1 N_3 A_2 
Stack 55
G_9 Z_142 C_4 C_2 
Stack 56
Z_143 M_6 R_5 H_3 
Stack 57
D_6 A_3 E_6 B_5 
Stack 58
J_9 Z_144 S_4 H_5 
Stack 59
T_1 C_8 D_5 O_8 
Stack 60
F_7 C_0 Z_145 S_7 
Stack 61
L_12 O_11 I_12 L_6 
Stack 62
F_5 Z_146 S_1 O_7 
Stack 63
M_12 A_7 O_2 Z_147 
Stack 64
M_5 B_7 Z_148 K_12 
Stack 65
H_2 L_10 D_7 A_5 
Stack 66
I_3 S_6 D_10 T_4 
Stack 67
Z_149 L_0 P_0 H_4 
Stack 68
N_11 D_9 J_10 Q_3 
Stack 69
Z_150 Z_151 Z_152 Z_153 
Stack 70
F_0 O_0 Z_154 Z_155 
Stack 71
Z_156 J_12 P_2 
Stack 72
Z_157 I_6 P_9 
