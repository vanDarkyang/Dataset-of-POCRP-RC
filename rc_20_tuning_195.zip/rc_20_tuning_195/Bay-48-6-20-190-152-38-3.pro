Number Of Containers
190
Number Of Yard Stacks
48
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
152
Number Of Shutout Containers
38
Yard Bay
Stack 0
G_2 I_4 D_3 Z_100 
Stack 1
J_8 Z_101 N_1 B_0 
Stack 2
K_5 M_6 Z_102 Z_103 
Stack 3
Z_104 K_3 P_3 Q_6 
Stack 4
L_2 I_2 L_1 G_0 
Stack 5
J_1 G_6 Z_105 A_0 
Stack 6
H_2 Z_106 I_8 O_1 
Stack 7
I_6 K_4 Z_107 L_0 
Stack 8
K_7 J_4 R_4 N_6 
Stack 9
N_4 K_2 Q_1 O_8 
Stack 10
Z_108 Z_109 O_6 E_0 
Stack 11
D_0 Z_110 F_5 I_0 
Stack 12
T_2 Q_4 F_6 T_1 
Stack 13
N_5 Z_111 M_2 P_4 
Stack 14
N_0 I_5 J_9 Z_112 
Stack 15
L_5 G_3 S_1 M_1 
Stack 16
Z_113 M_9 B_1 Z_114 
Stack 17
Z_115 F_1 R_0 Z_116 
Stack 18
G_4 H_7 Z_117 O_2 
Stack 19
D_5 D_6 Z_118 I_7 
Stack 20
K_0 F_2 K_9 Z_119 
Stack 21
M_0 Z_120 M_3 F_4 
Stack 22
J_10 Z_121 Z_122 Z_123 
Stack 23
M_5 Z_124 I_1 N_7 
Stack 24
F_0 P_1 N_2 E_6 
Stack 25
L_6 E_7 Q_0 Z_125 
Stack 26
G_1 B_3 Z_126 G_5 
Stack 27
A_4 Z_127 H_0 Z_128 
Stack 28
H_6 H_3 J_0 F_3 
Stack 29
E_4 H_4 E_2 R_3 
Stack 30
J_6 Z_129 P_0 K_8 
Stack 31
Z_130 E_3 T_0 Z_131 
Stack 32
F_8 Z_132 O_0 L_8 
Stack 33
H_8 B_2 I_3 G_8 
Stack 34
J_2 T_4 L_4 Z_133 
Stack 35
C_2 H_5 K_1 D_4 
Stack 36
O_4 F_7 E_5 S_0 
Stack 37
M_4 J_3 B_4 O_5 
Stack 38
N_3 G_9 R_5 Q_2 
Stack 39
A_3 Q_5 D_7 C_0 
Stack 40
M_8 R_1 L_3 O_3 
Stack 41
A_2 Z_134 A_1 P_2 
Stack 42
Q_3 D_1 H_9 Q_7 
Stack 43
G_7 M_7 R_2 Z_135 
Stack 44
C_1 L_7 J_5 O_7 
Stack 45
D_2 Z_136 H_1 E_1 
Stack 46
P_5 T_3 K_6 
Stack 47
Z_137 J_7 I_9 
