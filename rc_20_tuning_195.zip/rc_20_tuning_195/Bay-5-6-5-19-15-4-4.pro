Number Of Containers
19
Number Of Yard Stacks
5
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
15
Number Of Shutout Containers
4
Yard Bay
Stack 0
A_0 Z_100 B_0 A_1 
Stack 1
D_1 C_0 E_1 Z_101 
Stack 2
Z_102 E_0 B_2 D_0 
Stack 3
Z_103 C_3 C_1 D_2 
Stack 4
B_1 D_3 C_2 
