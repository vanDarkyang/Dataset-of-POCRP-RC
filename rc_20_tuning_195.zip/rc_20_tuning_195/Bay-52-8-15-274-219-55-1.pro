Number Of Containers
274
Number Of Yard Stacks
52
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
219
Number Of Shutout Containers
55
Yard Bay
Stack 0
J_4 I_5 Z_100 K_3 O_1 F_11 
Stack 1
Z_101 G_5 A_3 K_4 F_17 A_1 
Stack 2
Z_102 M_9 C_9 C_4 E_9 Z_103 
Stack 3
J_9 F_15 A_5 B_3 A_4 I_11 
Stack 4
Z_104 M_1 I_15 D_8 E_1 E_12 
Stack 5
E_8 I_6 K_11 Z_105 O_6 Z_106 
Stack 6
N_12 K_2 G_3 J_2 Z_107 Z_108 
Stack 7
Z_109 K_8 K_7 J_11 G_8 H_3 
Stack 8
F_16 G_4 H_6 N_7 L_11 O_2 
Stack 9
K_0 N_5 Z_110 L_12 L_9 L_4 
Stack 10
N_6 C_6 Z_111 K_6 H_17 C_0 
Stack 11
J_15 I_10 C_12 L_0 Z_112 M_6 
Stack 12
N_3 K_10 M_4 I_1 N_2 D_6 
Stack 13
A_7 D_9 N_9 M_0 N_14 F_12 
Stack 14
H_0 E_10 B_6 Z_113 Z_114 
Stack 15
G_6 Z_115 B_1 K_12 Z_116 
Stack 16
E_11 I_17 L_8 O_10 G_14 
Stack 17
Z_117 Z_118 J_1 A_0 E_4 
Stack 18
Z_119 O_7 G_13 N_0 A_6 
Stack 19
Z_120 G_11 L_2 Z_121 J_14 
Stack 20
Z_122 J_0 K_15 N_1 H_11 
Stack 21
C_10 M_5 H_8 B_2 N_8 
Stack 22
D_10 M_3 O_5 Z_123 I_3 
Stack 23
Z_124 O_11 G_12 H_2 L_7 
Stack 24
M_13 G_16 Z_125 Z_126 I_4 
Stack 25
I_7 J_7 M_12 L_3 Z_127 
Stack 26
J_16 F_1 I_13 G_2 H_19 
Stack 27
Z_128 H_15 C_11 D_3 E_5 
Stack 28
Z_129 H_4 F_10 F_2 Z_130 
Stack 29
M_11 F_14 I_12 Z_131 H_1 
Stack 30
Z_132 D_7 J_8 I_8 H_14 
Stack 31
B_7 F_13 F_3 Z_133 I_0 
Stack 32
C_7 O_3 G_9 D_1 N_13 
Stack 33
F_0 Z_134 M_7 D_0 J_6 
Stack 34
M_8 H_7 H_18 N_10 G_7 
Stack 35
K_14 L_6 O_9 B_11 Z_135 
Stack 36
D_5 B_0 B_4 O_4 L_5 
Stack 37
H_16 Z_136 E_7 G_1 M_10 
Stack 38
D_2 I_16 B_9 O_8 A_2 
Stack 39
J_5 Z_137 N_4 N_11 E_0 
Stack 40
Z_138 G_0 Z_139 D_4 J_3 
Stack 41
Z_140 H_5 I_14 Z_141 K_1 
Stack 42
Z_142 Z_143 L_1 G_15 C_8 
Stack 43
H_13 J_10 A_8 G_10 K_9 
Stack 44
I_2 C_5 Z_144 I_9 C_3 
Stack 45
Z_145 Z_146 C_2 C_1 H_9 
Stack 46
Z_147 H_10 F_8 B_5 F_7 
Stack 47
E_2 Z_148 Z_149 Z_150 J_12 
Stack 48
F_9 F_4 E_3 J_13 B_10 
Stack 49
F_6 O_0 M_2 E_6 H_12 
Stack 50
Z_151 K_5 Z_152 K_13 F_5 
Stack 51
A_9 Z_153 B_8 Z_154 L_10 
