Number Of Containers
290
Number Of Yard Stacks
73
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
232
Number Of Shutout Containers
58
Yard Bay
Stack 0
Z_100 T_5 P_2 Z_101 
Stack 1
T_6 K_10 Z_102 C_6 
Stack 2
O_13 Z_103 A_6 Z_104 
Stack 3
K_8 D_3 J_7 M_5 
Stack 4
B_2 O_12 C_2 R_1 
Stack 5
Z_105 R_2 M_8 S_1 
Stack 6
D_8 Z_106 G_1 Q_9 
Stack 7
G_13 R_8 L_7 P_9 
Stack 8
L_0 C_5 H_6 O_3 
Stack 9
G_0 O_0 Z_107 O_10 
Stack 10
Q_3 P_3 D_2 M_7 
Stack 11
Z_108 S_2 F_5 K_1 
Stack 12
Z_109 B_5 I_3 K_7 
Stack 13
G_4 G_3 Z_110 A_3 
Stack 14
Z_111 K_6 L_1 I_2 
Stack 15
G_9 N_4 J_10 C_1 
Stack 16
K_4 K_0 J_11 L_10 
Stack 17
E_3 M_12 O_1 S_6 
Stack 18
Q_2 C_8 G_5 Z_112 
Stack 19
B_0 H_10 G_7 T_2 
Stack 20
C_7 A_9 I_10 H_1 
Stack 21
Z_113 C_4 Q_6 H_16 
Stack 22
K_14 J_0 H_5 I_7 
Stack 23
O_6 E_1 L_9 P_11 
Stack 24
R_4 H_2 Q_10 Z_114 
Stack 25
Z_115 P_8 G_10 I_8 
Stack 26
B_6 S_4 M_6 G_12 
Stack 27
Z_116 E_9 H_9 M_0 
Stack 28
T_3 N_5 N_6 D_4 
Stack 29
Z_117 J_9 L_6 K_11 
Stack 30
K_2 Z_118 O_11 O_7 
Stack 31
Z_119 J_12 B_4 C_3 
Stack 32
P_6 S_7 Z_120 Z_121 
Stack 33
T_4 Z_122 H_13 K_9 
Stack 34
N_0 J_2 F_7 S_5 
Stack 35
H_3 Z_123 Z_124 R_0 
Stack 36
Z_125 N_9 Z_126 J_1 
Stack 37
I_4 N_2 G_8 Z_127 
Stack 38
Z_128 E_4 Z_129 S_0 
Stack 39
Q_4 Q_8 Z_130 P_4 
Stack 40
N_3 N_7 H_12 M_10 
Stack 41
T_1 Z_131 J_3 Z_132 
Stack 42
E_7 P_10 L_3 I_9 
Stack 43
N_10 Z_133 O_5 Z_134 
Stack 44
Z_135 M_9 Q_1 J_4 
Stack 45
A_2 Q_11 G_6 Z_136 
Stack 46
H_8 M_3 N_11 H_11 
Stack 47
Z_137 Z_138 D_0 F_2 
Stack 48
Z_139 M_2 Z_140 S_9 
Stack 49
Z_141 P_0 N_12 P_5 
Stack 50
Z_142 D_9 L_8 A_8 
Stack 51
O_9 Z_143 O_8 B_8 
Stack 52
F_6 H_14 Z_144 L_5 
Stack 53
B_3 K_5 G_11 A_4 
Stack 54
H_0 Q_7 S_8 J_6 
Stack 55
D_1 E_2 A_1 B_1 
Stack 56
K_15 K_3 F_3 R_7 
Stack 57
L_2 P_1 D_6 Z_145 
Stack 58
Z_146 K_12 Q_0 I_0 
Stack 59
B_7 H_4 I_1 Z_147 
Stack 60
I_5 Z_148 L_4 J_5 
Stack 61
L_11 O_2 D_7 N_1 
Stack 62
Z_149 R_6 G_2 Z_150 
Stack 63
Z_151 Z_152 D_5 N_8 
Stack 64
Z_153 A_5 Z_154 Z_155 
Stack 65
M_11 A_0 K_13 T_0 
Stack 66
C_0 R_5 H_15 E_8 
Stack 67
P_7 D_10 E_6 F_4 
Stack 68
H_7 J_8 S_3 E_0 
Stack 69
Z_156 F_1 Z_157 R_3 
Stack 70
M_1 O_4 I_6 M_4 
Stack 71
I_11 G_14 F_0 
Stack 72
E_5 A_7 Q_5 
