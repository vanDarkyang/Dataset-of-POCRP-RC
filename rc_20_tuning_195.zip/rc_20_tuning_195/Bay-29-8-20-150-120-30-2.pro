Number Of Containers
150
Number Of Yard Stacks
29
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
120
Number Of Shutout Containers
30
Yard Bay
Stack 0
Z_100 P_1 Z_101 Z_102 G_6 Z_103 
Stack 1
G_0 K_7 N_1 I_0 I_5 K_6 
Stack 2
F_5 Q_2 M_0 N_7 Z_104 C_4 
Stack 3
I_6 D_3 J_5 O_1 Z_105 C_3 
Stack 4
K_0 P_4 E_6 O_0 H_3 B_0 
Stack 5
B_1 N_6 M_2 Z_106 T_1 
Stack 6
N_5 Z_107 H_1 M_3 J_1 
Stack 7
P_0 D_5 C_0 Z_108 N_4 
Stack 8
R_1 H_4 J_7 D_2 A_1 
Stack 9
F_1 F_3 E_2 H_5 L_1 
Stack 10
I_2 I_1 R_0 L_3 Z_109 
Stack 11
J_4 J_6 J_10 Z_110 R_2 
Stack 12
Z_111 A_0 G_3 L_4 Z_112 
Stack 13
C_2 Z_113 Q_1 G_1 Z_114 
Stack 14
D_1 G_2 O_4 H_0 Z_115 
Stack 15
H_7 J_2 F_4 Z_116 L_6 
Stack 16
Z_117 K_4 H_8 P_2 F_0 
Stack 17
E_4 M_5 K_1 E_0 H_2 
Stack 18
N_3 C_1 J_0 K_2 I_9 
Stack 19
E_5 N_2 J_8 O_3 N_0 
Stack 20
G_8 L_0 I_7 K_3 I_4 
Stack 21
O_7 E_3 Z_118 Z_119 S_0 
Stack 22
I_8 P_3 J_3 Z_120 Z_121 
Stack 23
O_2 T_2 M_1 Z_122 I_3 
Stack 24
D_0 G_4 G_5 Z_123 T_0 
Stack 25
J_9 Z_124 S_1 O_5 Z_125 
Stack 26
O_6 L_5 Z_126 L_2 F_2 
Stack 27
G_7 Z_127 H_6 Q_0 M_4 
Stack 28
K_5 D_4 Z_128 E_1 Z_129 
