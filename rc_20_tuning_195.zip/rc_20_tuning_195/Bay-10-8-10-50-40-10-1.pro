Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_1 H_2 G_0 D_0 G_2 
Stack 1
F_4 E_2 D_4 D_3 Z_100 
Stack 2
J_1 Z_101 E_0 I_0 E_1 
Stack 3
C_1 D_2 D_1 G_1 F_2 
Stack 4
E_3 Z_102 H_0 J_0 F_3 
Stack 5
C_2 Z_103 H_1 B_0 G_4 
Stack 6
A_0 Z_104 A_1 G_3 B_2 
Stack 7
I_1 I_3 Z_105 H_3 F_1 
Stack 8
C_0 Z_106 I_2 Z_107 Z_108 
Stack 9
Z_109 C_3 B_3 F_0 A_2 
