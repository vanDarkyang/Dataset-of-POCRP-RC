Number Of Containers
124
Number Of Yard Stacks
31
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
J_5 Z_100 M_1 N_4 
Stack 1
F_4 H_3 H_5 Z_101 
Stack 2
H_2 L_3 Z_102 Z_103 
Stack 3
A_0 F_3 J_4 F_2 
Stack 4
Z_104 N_3 M_3 N_1 
Stack 5
F_6 L_5 N_0 I_6 
Stack 6
Z_105 L_0 Z_106 H_0 
Stack 7
E_0 G_0 K_6 J_3 
Stack 8
B_4 C_0 C_2 B_3 
Stack 9
D_2 Z_107 L_6 F_1 
Stack 10
H_7 F_5 E_6 N_2 
Stack 11
A_2 F_0 O_0 A_4 
Stack 12
K_5 O_2 G_9 I_4 
Stack 13
J_6 M_0 D_1 K_3 
Stack 14
D_5 L_4 G_8 G_2 
Stack 15
I_3 B_1 D_7 D_0 
Stack 16
D_3 A_3 F_7 K_2 
Stack 17
G_3 Z_108 A_1 K_1 
Stack 18
G_6 I_1 J_0 M_4 
Stack 19
E_2 I_5 G_4 B_0 
Stack 20
Z_109 E_3 Z_110 L_2 
Stack 21
L_1 C_1 Z_111 H_6 
Stack 22
J_2 Z_112 E_4 C_4 
Stack 23
Z_113 G_7 M_2 I_0 
Stack 24
I_2 Z_114 Z_115 E_7 
Stack 25
K_0 Z_116 K_4 O_3 
Stack 26
Z_117 E_5 E_1 Z_118 
Stack 27
D_4 H_4 Z_119 H_1 
Stack 28
O_1 G_5 B_2 Z_120 
Stack 29
J_1 Z_121 Z_122 D_6 
Stack 30
Z_123 Z_124 G_1 C_3 
