Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_14 Z_100 Z_101 C_16 
Stack 1
C_3 D_4 C_11 C_12 
Stack 2
A_9 C_10 E_1 D_6 
Stack 3
A_3 Z_102 Z_103 Z_104 
Stack 4
Z_105 C_6 B_11 B_0 
Stack 5
D_1 C_4 A_6 A_11 
Stack 6
B_4 Z_106 A_4 Z_107 
Stack 7
B_10 E_6 D_5 D_3 
Stack 8
C_0 A_2 D_7 E_7 
Stack 9
B_13 Z_108 B_12 C_2 
Stack 10
B_9 Z_109 Z_110 A_8 
Stack 11
A_5 E_0 D_2 B_1 
Stack 12
E_8 B_3 A_12 B_14 
Stack 13
Z_111 Z_112 C_15 E_3 
Stack 14
A_1 C_13 Z_113 E_9 
Stack 15
C_8 C_9 C_5 B_2 
Stack 16
B_5 E_4 B_8 E_5 
Stack 17
Z_114 C_1 D_0 A_7 
Stack 18
C_7 Z_115 A_0 A_10 
Stack 19
E_2 B_7 B_6 
