Number Of Containers
16
Number Of Yard Stacks
4
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
12
Number Of Shutout Containers
4
Yard Bay
Stack 0
Z_100 Z_101 A_1 C_0 
Stack 1
C_1 A_0 B_2 B_3 
Stack 2
B_1 C_2 B_0 Z_102 
Stack 3
C_4 Z_103 C_3 A_2 
