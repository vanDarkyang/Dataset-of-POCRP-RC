Number Of Containers
150
Number Of Yard Stacks
38
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
120
Number Of Shutout Containers
30
Yard Bay
Stack 0
Z_100 O_6 I_1 Q_0 
Stack 1
M_1 C_3 J_6 P_1 
Stack 2
F_1 Z_101 E_2 P_0 
Stack 3
A_0 E_5 Z_102 Z_103 
Stack 4
E_3 G_0 Q_1 L_3 
Stack 5
C_2 P_5 M_2 N_1 
Stack 6
L_2 M_6 Z_104 J_7 
Stack 7
K_2 Z_105 B_0 P_3 
Stack 8
Q_2 O_0 G_4 D_2 
Stack 9
Z_106 Z_107 M_4 K_4 
Stack 10
K_7 G_3 K_6 I_3 
Stack 11
K_8 L_4 R_1 Z_108 
Stack 12
T_0 N_4 T_2 Z_109 
Stack 13
J_1 Z_110 Z_111 N_6 
Stack 14
Z_112 I_7 P_6 P_2 
Stack 15
Z_113 J_8 L_1 M_5 
Stack 16
F_0 O_1 N_5 F_2 
Stack 17
J_3 R_0 I_8 J_4 
Stack 18
P_4 B_2 H_1 F_3 
Stack 19
Q_3 Z_114 E_1 F_6 
Stack 20
A_1 J_0 Z_115 O_3 
Stack 21
K_9 S_1 Z_116 N_3 
Stack 22
E_0 N_2 M_3 D_3 
Stack 23
D_1 Z_117 I_5 Z_118 
Stack 24
F_5 N_0 Z_119 Z_120 
Stack 25
G_5 I_0 K_5 G_6 
Stack 26
F_4 O_5 K_3 I_6 
Stack 27
I_4 J_9 H_3 K_1 
Stack 28
S_2 H_4 Z_121 B_1 
Stack 29
Z_122 Q_4 G_1 Z_123 
Stack 30
T_1 J_2 C_1 J_5 
Stack 31
Z_124 H_0 R_3 H_2 
Stack 32
S_0 L_0 R_2 C_4 
Stack 33
M_0 I_2 O_4 E_4 
Stack 34
C_0 K_0 H_5 Z_125 
Stack 35
Z_126 Q_5 Z_127 Z_128 
Stack 36
G_2 D_4 S_3 
Stack 37
D_0 O_2 Z_129 
