Number Of Containers
31
Number Of Yard Stacks
6
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
24
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_5 B_5 C_4 A_4 C_8 Z_100 
Stack 1
C_2 B_1 C_7 B_4 A_7 
Stack 2
B_6 A_1 C_3 B_0 Z_101 
Stack 3
Z_102 A_6 B_3 A_0 Z_103 
Stack 4
B_2 C_0 A_3 Z_104 C_1 
Stack 5
Z_105 A_2 C_6 Z_106 A_5 
