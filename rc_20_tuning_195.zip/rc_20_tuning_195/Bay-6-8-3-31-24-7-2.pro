Number Of Containers
31
Number Of Yard Stacks
6
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
24
Number Of Shutout Containers
7
Yard Bay
Stack 0
A_0 B_6 Z_100 A_1 C_4 A_6 
Stack 1
B_7 Z_101 Z_102 C_2 Z_103 
Stack 2
A_4 B_5 C_6 Z_104 A_2 
Stack 3
C_3 Z_105 B_3 B_1 C_1 
Stack 4
B_0 C_5 B_4 C_0 A_3 
Stack 5
B_2 B_8 A_5 Z_106 C_7 
