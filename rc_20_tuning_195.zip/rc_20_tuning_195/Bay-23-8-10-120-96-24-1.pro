Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 I_5 D_0 J_3 B_0 Z_101 
Stack 1
G_4 C_7 H_6 A_7 I_7 B_1 
Stack 2
H_10 J_0 E_3 J_5 Z_102 D_8 
Stack 3
G_0 F_1 F_7 C_6 A_5 F_11 
Stack 4
Z_103 B_2 B_5 Z_104 I_8 A_0 
Stack 5
D_5 E_5 E_6 C_3 Z_105 
Stack 6
H_5 Z_106 E_9 I_4 Z_107 
Stack 7
F_10 Z_108 Z_109 G_7 F_4 
Stack 8
C_8 D_1 H_2 Z_110 H_7 
Stack 9
H_1 B_3 Z_111 F_9 Z_112 
Stack 10
G_6 I_6 C_4 D_7 F_12 
Stack 11
E_4 Z_113 C_0 C_2 Z_114 
Stack 12
Z_115 Z_116 F_3 J_4 G_2 
Stack 13
J_2 D_2 D_3 A_6 E_1 
Stack 14
Z_117 H_11 G_3 F_2 Z_118 
Stack 15
J_6 G_9 H_3 E_8 H_0 
Stack 16
B_4 E_2 H_9 Z_119 D_6 
Stack 17
C_5 D_4 A_2 G_5 D_9 
Stack 18
F_5 D_10 F_6 I_0 Z_120 
Stack 19
G_8 E_7 G_1 J_7 I_2 
Stack 20
H_8 A_1 F_0 I_1 Z_121 
Stack 21
I_3 E_0 C_1 J_1 A_4 
Stack 22
Z_122 H_4 Z_123 A_3 F_8 
