Number Of Containers
46
Number Of Yard Stacks
9
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_3 A_8 B_7 A_3 Z_100 B_9 
Stack 1
Z_101 A_4 Z_102 C_2 A_6 
Stack 2
A_2 Z_103 C_0 A_1 Z_104 
Stack 3
A_0 C_8 C_1 C_9 B_8 
Stack 4
C_7 A_5 B_10 A_10 B_1 
Stack 5
Z_105 Z_106 B_11 B_0 A_11 
Stack 6
B_12 B_4 A_9 C_3 C_4 
Stack 7
Z_107 C_6 Z_108 C_5 Z_109 
Stack 8
B_2 A_7 B_5 C_10 B_6 
