Number Of Containers
290
Number Of Yard Stacks
55
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
232
Number Of Shutout Containers
58
Yard Bay
Stack 0
E_5 D_1 N_2 Z_100 C_6 R_10 
Stack 1
T_6 Z_101 E_4 Z_102 L_12 Z_103 
Stack 2
O_13 L_3 Q_6 Q_4 M_5 I_0 
Stack 3
K_7 B_5 N_8 H_3 R_2 T_1 
Stack 4
B_2 B_9 Z_104 Z_105 Z_106 J_9 
Stack 5
M_9 I_6 P_9 Q_8 Q_7 N_1 
Stack 6
Z_107 L_14 I_7 G_6 Z_108 J_12 
Stack 7
G_8 Z_109 M_8 M_6 O_3 N_10 
Stack 8
L_0 Z_110 Z_111 H_6 O_10 N_6 
Stack 9
G_0 J_14 M_3 N_7 Z_112 T_0 
Stack 10
Q_2 Z_113 N_11 L_8 K_1 E_10 
Stack 11
R_1 C_0 M_2 O_11 K_6 F_7 
Stack 12
K_13 P_7 Z_114 B_4 A_3 Z_115 
Stack 13
G_4 H_5 D_8 Z_116 Z_117 R_4 
Stack 14
F_3 N_9 Z_118 H_9 C_1 M_4 
Stack 15
Z_119 M_1 H_10 Z_120 L_13 
Stack 16
K_4 I_11 Z_121 Z_122 Z_123 
Stack 17
E_3 E_6 Q_5 Z_124 J_1 
Stack 18
Q_1 Z_125 E_2 Z_126 T_4 
Stack 19
B_0 K_10 K_3 Z_127 H_1 
Stack 20
C_7 Z_128 P_0 Z_129 Z_130 
Stack 21
I_4 D_4 K_12 H_8 I_9 
Stack 22
K_14 O_12 H_2 J_7 P_10 
Stack 23
O_6 R_3 T_3 L_5 F_6 
Stack 24
R_6 R_9 O_2 O_4 I_10 
Stack 25
E_0 R_11 R_8 Q_0 Z_131 
Stack 26
B_8 C_5 J_6 Z_132 M_0 
Stack 27
S_4 O_0 A_5 N_13 D_5 
Stack 28
T_5 P_2 A_0 D_0 K_11 
Stack 29
C_4 S_1 R_7 R_5 O_7 
Stack 30
K_2 B_6 D_9 N_14 C_3 
Stack 31
Z_133 G_3 J_11 L_11 E_9 
Stack 32
P_5 K_5 F_0 O_8 K_9 
Stack 33
Z_134 N_4 Z_135 O_5 S_5 
Stack 34
N_0 K_0 G_9 G_7 R_0 
Stack 35
Z_136 M_11 A_7 S_7 J_3 
Stack 36
T_2 C_9 P_1 A_1 K_8 
Stack 37
I_5 H_7 J_2 F_5 S_0 
Stack 38
D_10 A_8 A_6 D_7 P_3 
Stack 39
Q_3 Z_137 J_10 Z_138 Z_139 
Stack 40
N_3 J_0 C_2 I_1 B_7 
Stack 41
Z_140 E_1 M_7 L_6 Z_141 
Stack 42
E_8 Z_142 G_1 Z_143 F_4 
Stack 43
N_12 P_8 L_10 G_2 J_8 
Stack 44
L_1 S_3 H_4 D_6 J_4 
Stack 45
A_2 Z_144 K_15 D_2 Z_145 
Stack 46
Z_146 N_5 D_3 Z_147 F_1 
Stack 47
L_4 J_13 F_8 H_11 Z_148 
Stack 48
C_8 Z_149 Z_150 E_7 P_4 
Stack 49
L_9 J_15 P_6 S_2 Z_151 
Stack 50
I_2 S_6 L_2 I_3 B_10 
Stack 51
O_9 L_15 Z_152 I_8 L_7 
Stack 52
F_9 J_5 Z_153 Z_154 A_4 
Stack 53
B_3 M_10 O_1 Z_155 Z_156 
Stack 54
H_0 Z_157 G_5 F_2 B_1 
