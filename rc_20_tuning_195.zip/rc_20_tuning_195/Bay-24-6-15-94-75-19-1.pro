Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 H_6 H_1 G_0 
Stack 1
K_3 L_1 E_3 L_0 
Stack 2
Z_101 Z_102 K_4 D_0 
Stack 3
Z_103 D_2 J_1 J_4 
Stack 4
F_2 I_2 F_4 F_5 
Stack 5
H_5 E_0 A_1 C_0 
Stack 6
E_1 O_0 A_0 M_3 
Stack 7
M_4 K_0 I_4 H_0 
Stack 8
N_0 C_2 D_3 J_5 
Stack 9
Z_104 K_2 B_2 F_1 
Stack 10
F_6 G_5 F_7 N_2 
Stack 11
B_1 Z_105 K_1 N_1 
Stack 12
Z_106 Z_107 K_6 G_2 
Stack 13
Z_108 J_0 G_3 F_0 
Stack 14
G_4 M_0 H_3 D_1 
Stack 15
J_3 H_4 Z_109 B_0 
Stack 16
B_3 C_1 Z_110 N_3 
Stack 17
M_1 K_5 I_3 Z_111 
Stack 18
E_4 G_1 J_6 H_2 
Stack 19
F_3 L_3 L_2 I_0 
Stack 20
J_2 Z_112 I_6 E_2 
Stack 21
I_1 Z_113 Z_114 M_2 
Stack 22
Z_115 Z_116 Z_117 
Stack 23
I_5 J_7 Z_118 
