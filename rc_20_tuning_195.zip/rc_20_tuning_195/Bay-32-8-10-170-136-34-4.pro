Number Of Containers
170
Number Of Yard Stacks
32
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
136
Number Of Shutout Containers
34
Yard Bay
Stack 0
H_7 E_14 A_7 J_2 A_3 B_2 
Stack 1
F_6 H_15 Z_100 J_12 H_4 J_10 
Stack 2
C_0 H_10 B_7 F_7 D_9 D_12 
Stack 3
D_1 G_2 G_3 D_8 G_9 J_9 
Stack 4
F_3 I_12 G_11 J_3 C_4 F_0 
Stack 5
F_10 Z_101 Z_102 D_5 H_13 E_4 
Stack 6
Z_103 F_13 G_8 B_8 G_12 H_6 
Stack 7
Z_104 I_13 D_3 D_2 Z_105 H_0 
Stack 8
E_10 B_6 A_9 J_4 J_0 F_5 
Stack 9
E_15 I_11 Z_106 Z_107 I_7 E_12 
Stack 10
F_14 Z_108 F_4 J_1 Z_109 
Stack 11
C_12 D_6 F_1 B_3 C_11 
Stack 12
D_0 H_12 Z_110 Z_111 Z_112 
Stack 13
H_3 Z_113 Z_114 F_12 I_5 
Stack 14
J_6 J_5 D_7 Z_115 G_1 
Stack 15
A_0 I_0 Z_116 A_5 B_0 
Stack 16
F_11 E_6 D_11 H_5 H_11 
Stack 17
I_6 Z_117 F_2 F_8 E_3 
Stack 18
C_9 F_9 Z_118 I_9 Z_119 
Stack 19
C_7 G_4 A_6 C_2 E_11 
Stack 20
J_11 B_9 A_10 C_10 Z_120 
Stack 21
B_5 Z_121 H_8 I_10 Z_122 
Stack 22
C_5 E_1 E_0 I_8 Z_123 
Stack 23
D_4 C_3 H_14 E_8 G_7 
Stack 24
E_7 Z_124 G_5 H_9 Z_125 
Stack 25
E_13 I_1 G_10 E_2 Z_126 
Stack 26
Z_127 G_6 H_1 Z_128 E_16 
Stack 27
A_2 J_7 I_2 C_1 B_4 
Stack 28
J_8 A_8 A_4 B_1 Z_129 
Stack 29
Z_130 D_10 G_0 A_11 A_1 
Stack 30
Z_131 Z_132 Z_133 C_6 I_4 
Stack 31
E_5 H_2 C_8 E_9 I_3 
