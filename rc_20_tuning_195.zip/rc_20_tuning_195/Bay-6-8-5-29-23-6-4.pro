Number Of Containers
29
Number Of Yard Stacks
6
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
23
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_0 Z_100 D_1 Z_101 C_1 
Stack 1
A_0 A_2 Z_102 E_0 D_2 
Stack 2
B_4 B_2 C_5 C_3 A_3 
Stack 3
C_4 B_1 E_2 Z_103 E_1 
Stack 4
B_3 C_2 Z_104 D_0 C_6 
Stack 5
Z_105 C_0 A_1 E_3 
