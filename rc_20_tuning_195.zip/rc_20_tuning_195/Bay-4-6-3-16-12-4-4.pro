Number Of Containers
16
Number Of Yard Stacks
4
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
12
Number Of Shutout Containers
4
Yard Bay
Stack 0
A_3 A_1 B_3 Z_100 
Stack 1
B_0 C_1 C_0 Z_101 
Stack 2
B_2 Z_102 B_4 B_1 
Stack 3
Z_103 A_2 A_0 C_2 
