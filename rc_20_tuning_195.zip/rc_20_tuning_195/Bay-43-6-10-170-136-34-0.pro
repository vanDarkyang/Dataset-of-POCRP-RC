Number Of Containers
170
Number Of Yard Stacks
43
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
136
Number Of Shutout Containers
34
Yard Bay
Stack 0
I_8 Z_100 Z_101 A_1 
Stack 1
Z_102 G_0 E_3 C_7 
Stack 2
Z_103 H_0 G_4 J_3 
Stack 3
Z_104 I_11 Z_105 F_9 
Stack 4
G_13 A_11 B_11 F_2 
Stack 5
G_10 A_0 A_3 D_0 
Stack 6
Z_106 Z_107 Z_108 I_13 
Stack 7
Z_109 B_10 A_10 C_11 
Stack 8
E_9 C_5 E_11 G_11 
Stack 9
G_5 E_7 F_5 B_2 
Stack 10
B_7 Z_110 B_12 J_13 
Stack 11
Z_111 D_8 H_6 J_11 
Stack 12
I_2 Z_112 C_4 G_6 
Stack 13
F_12 G_3 C_6 Z_113 
Stack 14
Z_114 J_1 C_12 H_1 
Stack 15
E_0 A_6 G_8 H_10 
Stack 16
Z_115 D_13 E_14 B_8 
Stack 17
I_10 E_8 B_9 H_9 
Stack 18
I_0 F_8 F_4 F_14 
Stack 19
D_3 F_1 G_2 I_3 
Stack 20
E_5 A_4 B_3 J_9 
Stack 21
Z_116 C_8 G_14 F_6 
Stack 22
Z_117 Z_118 C_3 I_9 
Stack 23
D_10 Z_119 Z_120 I_4 
Stack 24
Z_121 D_12 B_0 F_13 
Stack 25
Z_122 I_6 J_12 H_8 
Stack 26
G_9 B_5 E_12 H_2 
Stack 27
J_6 E_4 B_1 I_5 
Stack 28
J_10 B_4 D_2 F_10 
Stack 29
Z_123 E_6 J_0 A_7 
Stack 30
Z_124 D_9 J_8 F_11 
Stack 31
E_1 Z_125 I_7 J_5 
Stack 32
D_4 E_10 A_5 Z_126 
Stack 33
I_1 C_1 Z_127 A_8 
Stack 34
C_9 C_0 E_13 Z_128 
Stack 35
J_4 Z_129 H_5 D_6 
Stack 36
D_11 Z_130 H_7 G_1 
Stack 37
H_3 A_9 F_7 J_7 
Stack 38
D_5 B_6 C_2 H_4 
Stack 39
A_2 C_10 J_2 I_12 
Stack 40
Z_131 G_7 D_7 E_2 
Stack 41
F_3 Z_132 F_0 
Stack 42
G_12 D_1 Z_133 
