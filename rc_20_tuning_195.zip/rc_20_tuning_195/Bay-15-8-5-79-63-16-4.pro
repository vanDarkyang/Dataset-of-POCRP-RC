Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
D_10 E_9 Z_100 C_11 D_5 C_9 
Stack 1
A_12 E_8 D_4 A_0 A_7 C_14 
Stack 2
D_11 A_10 A_11 A_4 Z_101 B_5 
Stack 3
C_13 A_9 D_6 E_3 D_7 E_5 
Stack 4
Z_102 Z_103 E_1 Z_104 C_7 
Stack 5
C_8 Z_105 E_6 B_10 C_12 
Stack 6
D_1 Z_106 Z_107 C_4 C_2 
Stack 7
Z_108 A_6 C_6 E_2 D_9 
Stack 8
D_2 B_2 C_10 B_1 A_2 
Stack 9
B_11 D_0 A_1 C_0 Z_109 
Stack 10
Z_110 Z_111 A_8 B_7 C_5 
Stack 11
Z_112 D_8 B_0 E_0 Z_113 
Stack 12
D_3 B_8 B_3 B_4 E_10 
Stack 13
A_5 C_3 B_6 Z_114 A_3 
Stack 14
Z_115 E_7 B_9 C_1 E_4 
