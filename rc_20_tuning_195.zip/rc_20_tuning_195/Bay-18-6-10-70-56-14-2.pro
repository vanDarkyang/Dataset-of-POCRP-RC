Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 J_0 D_6 J_4 
Stack 1
H_0 I_4 I_0 I_3 
Stack 2
Z_101 Z_102 C_1 B_1 
Stack 3
C_3 J_3 G_5 Z_103 
Stack 4
H_1 Z_104 H_5 G_4 
Stack 5
E_7 F_6 C_0 I_2 
Stack 6
Z_105 G_3 E_0 Z_106 
Stack 7
J_2 D_2 E_5 A_1 
Stack 8
C_2 E_4 Z_107 F_4 
Stack 9
H_3 E_3 E_2 Z_108 
Stack 10
D_0 A_2 Z_109 D_7 
Stack 11
F_5 E_6 F_3 G_0 
Stack 12
D_4 D_1 I_1 G_2 
Stack 13
J_1 Z_110 D_5 Z_111 
Stack 14
Z_112 B_0 F_2 F_0 
Stack 15
B_2 A_0 Z_113 B_3 
Stack 16
E_1 G_1 F_1 
Stack 17
D_3 H_4 H_2 
