Number Of Containers
199
Number Of Yard Stacks
38
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
159
Number Of Shutout Containers
40
Yard Bay
Stack 0
F_4 F_9 Z_100 C_7 F_12 Z_101 
Stack 1
M_7 F_3 E_5 Z_102 G_12 A_6 
Stack 2
E_0 Z_103 J_8 L_2 I_1 G_4 
Stack 3
O_3 D_0 Z_104 I_3 D_9 K_2 
Stack 4
G_10 Z_105 G_2 E_2 H_0 A_2 
Stack 5
C_3 Z_106 D_8 E_8 M_1 J_6 
Stack 6
F_7 C_5 H_8 H_1 D_7 F_1 
Stack 7
J_1 C_2 E_1 O_5 G_8 K_6 
Stack 8
B_4 Z_107 L_7 K_9 J_11 K_5 
Stack 9
F_2 J_9 Z_108 N_2 M_3 
Stack 10
E_4 Z_109 G_5 C_0 O_2 
Stack 11
G_3 B_7 O_0 Z_110 Z_111 
Stack 12
B_2 Z_112 M_0 N_3 A_4 
Stack 13
Z_113 N_5 L_9 H_5 M_4 
Stack 14
Z_114 G_0 Z_115 Z_116 Z_117 
Stack 15
F_11 B_1 F_0 Z_118 Z_119 
Stack 16
L_4 Z_120 D_10 Z_121 D_6 
Stack 17
J_10 C_6 Z_122 H_13 A_7 
Stack 18
N_0 H_15 O_4 Z_123 D_4 
Stack 19
E_6 B_0 H_2 N_1 I_0 
Stack 20
J_4 E_7 G_11 Z_124 Z_125 
Stack 21
D_2 Z_126 K_3 B_6 J_12 
Stack 22
M_2 Z_127 I_11 A_3 I_6 
Stack 23
L_0 I_10 L_5 H_7 A_8 
Stack 24
I_8 C_4 D_1 H_12 G_7 
Stack 25
G_1 Z_128 Z_129 N_4 H_16 
Stack 26
G_9 M_6 L_6 B_5 F_10 
Stack 27
B_3 Z_130 O_1 N_6 H_11 
Stack 28
J_3 J_0 I_2 H_6 F_5 
Stack 29
H_9 G_6 O_6 I_9 F_6 
Stack 30
A_1 K_7 Z_131 J_7 K_0 
Stack 31
Z_132 Z_133 J_2 K_8 K_4 
Stack 32
E_3 H_10 I_4 Z_134 C_8 
Stack 33
J_5 L_1 A_5 D_5 H_4 
Stack 34
Z_135 L_8 C_1 F_8 H_14 
Stack 35
M_8 G_13 I_5 Z_136 Z_137 
Stack 36
D_3 I_7 L_3 M_5 A_0 
Stack 37
Z_138 Z_139 I_12 K_1 H_3 
