Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_4 C_1 D_3 E_3 A_5 
Stack 1
B_7 D_7 C_6 A_0 B_5 
Stack 2
C_2 Z_100 A_1 Z_101 D_0 
Stack 3
A_7 Z_102 B_2 Z_103 D_9 
Stack 4
B_0 Z_104 A_6 D_5 D_8 
Stack 5
Z_105 C_3 E_1 B_4 B_1 
Stack 6
Z_106 Z_107 A_2 A_8 B_3 
Stack 7
D_2 E_5 E_6 Z_108 E_2 
Stack 8
D_6 Z_109 D_4 B_6 C_7 
Stack 9
E_0 C_5 C_8 A_3 D_1 
Stack 10
E_4 C_0 Z_110 A_4 
