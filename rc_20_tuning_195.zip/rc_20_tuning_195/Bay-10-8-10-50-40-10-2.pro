Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_0 E_3 B_0 F_2 I_3 
Stack 1
C_3 Z_100 E_6 Z_101 G_1 
Stack 2
Z_102 Z_103 H_2 I_1 I_0 
Stack 3
D_4 I_2 D_2 H_3 G_2 
Stack 4
C_1 E_0 G_3 D_0 H_0 
Stack 5
B_1 Z_104 J_0 Z_105 C_2 
Stack 6
Z_106 F_0 E_5 E_2 D_3 
Stack 7
A_1 J_1 Z_107 H_1 Z_108 
Stack 8
Z_109 D_1 G_0 C_0 F_4 
Stack 9
F_1 E_1 F_3 B_2 E_4 
