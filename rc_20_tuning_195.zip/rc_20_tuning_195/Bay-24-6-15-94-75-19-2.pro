Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
I_6 N_2 G_4 E_4 
Stack 1
C_1 H_0 Z_100 Z_101 
Stack 2
Z_102 Z_103 M_0 Z_104 
Stack 3
E_5 E_0 O_1 H_2 
Stack 4
Z_105 H_1 J_4 H_4 
Stack 5
Z_106 L_1 C_2 E_1 
Stack 6
H_6 Z_107 C_0 Z_108 
Stack 7
Z_109 D_2 F_4 I_3 
Stack 8
F_1 E_2 F_0 F_2 
Stack 9
D_3 O_0 L_2 J_6 
Stack 10
I_7 H_3 Z_110 A_0 
Stack 11
G_0 F_5 O_2 N_0 
Stack 12
Z_111 K_2 Z_112 J_2 
Stack 13
K_1 K_4 G_5 G_2 
Stack 14
Z_113 L_0 L_3 N_3 
Stack 15
N_1 D_4 D_1 F_3 
Stack 16
Z_114 H_5 M_2 I_0 
Stack 17
Z_115 K_6 G_1 A_1 
Stack 18
L_4 K_5 J_3 K_0 
Stack 19
G_3 J_0 B_0 B_1 
Stack 20
I_4 Z_116 J_1 D_0 
Stack 21
I_1 E_3 Z_117 E_6 
Stack 22
I_5 K_3 M_1 
Stack 23
J_5 Z_118 I_2 
