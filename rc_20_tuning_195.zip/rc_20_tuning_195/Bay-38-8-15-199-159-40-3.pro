Number Of Containers
199
Number Of Yard Stacks
38
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
159
Number Of Shutout Containers
40
Yard Bay
Stack 0
K_7 L_5 Z_100 C_7 L_2 A_6 
Stack 1
C_4 E_7 D_2 F_6 D_8 Z_101 
Stack 2
Z_102 K_5 J_2 G_2 J_0 K_3 
Stack 3
I_8 Z_103 I_4 H_8 M_1 Z_104 
Stack 4
G_7 E_8 I_5 D_5 N_0 G_1 
Stack 5
H_5 G_5 K_0 H_9 L_7 Z_105 
Stack 6
H_11 M_2 B_7 E_9 I_12 D_7 
Stack 7
Z_106 D_6 Z_107 I_14 N_2 Z_108 
Stack 8
E_4 L_4 Z_109 Z_110 Z_111 O_8 
Stack 9
Z_112 N_5 B_6 Z_113 Z_114 
Stack 10
F_7 D_4 I_9 H_2 G_4 
Stack 11
H_7 G_0 Z_115 F_5 C_2 
Stack 12
Z_116 Z_117 J_3 E_3 E_1 
Stack 13
I_7 I_10 C_6 Z_118 Z_119 
Stack 14
K_1 H_6 O_3 Z_120 B_4 
Stack 15
I_1 M_8 E_5 M_5 F_0 
Stack 16
Z_121 F_3 C_0 O_5 K_8 
Stack 17
Z_122 K_4 J_5 Z_123 Z_124 
Stack 18
G_8 K_2 F_1 L_0 C_5 
Stack 19
O_7 Z_125 H_10 B_5 A_8 
Stack 20
H_1 I_11 N_1 J_6 O_4 
Stack 21
I_13 F_9 M_0 Z_126 O_0 
Stack 22
E_0 I_2 Z_127 Z_128 M_4 
Stack 23
C_3 H_12 J_4 Z_129 L_8 
Stack 24
O_6 A_5 I_6 M_3 Z_130 
Stack 25
E_6 J_1 I_0 B_9 Z_131 
Stack 26
H_13 H_0 E_10 J_7 H_4 
Stack 27
A_2 B_8 Z_132 G_11 Z_133 
Stack 28
A_1 G_3 G_6 N_4 L_1 
Stack 29
Z_134 G_10 B_1 Z_135 J_9 
Stack 30
D_0 F_4 C_1 Z_136 L_6 
Stack 31
M_9 H_3 I_3 N_3 J_11 
Stack 32
D_3 A_3 L_3 D_9 K_6 
Stack 33
K_9 M_6 A_0 O_2 A_7 
Stack 34
B_0 Z_137 K_10 C_8 J_8 
Stack 35
G_9 J_10 M_7 F_8 F_2 
Stack 36
B_2 A_4 D_1 Z_138 B_3 
Stack 37
Z_139 O_1 E_2 G_12 E_11 
