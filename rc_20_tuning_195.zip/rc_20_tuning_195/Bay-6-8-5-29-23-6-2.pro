Number Of Containers
29
Number Of Yard Stacks
6
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
23
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_3 B_5 E_1 E_4 B_4 
Stack 1
A_4 A_0 C_0 C_2 A_2 
Stack 2
B_0 A_3 A_1 E_0 D_2 
Stack 3
Z_100 Z_101 E_2 Z_102 D_1 
Stack 4
C_3 Z_103 C_1 Z_104 B_2 
Stack 5
B_1 E_3 Z_105 D_0 
