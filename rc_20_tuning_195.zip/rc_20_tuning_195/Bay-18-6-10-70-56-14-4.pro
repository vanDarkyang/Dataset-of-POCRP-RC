Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
H_4 D_7 Z_100 H_1 
Stack 1
D_3 D_1 Z_101 G_6 
Stack 2
F_4 D_0 Z_102 Z_103 
Stack 3
B_1 A_2 J_3 Z_104 
Stack 4
B_3 I_1 E_0 Z_105 
Stack 5
G_0 E_2 I_0 Z_106 
Stack 6
C_2 G_5 I_3 F_0 
Stack 7
D_4 G_7 J_0 F_2 
Stack 8
A_3 E_1 H_2 Z_107 
Stack 9
E_6 D_5 I_2 C_1 
Stack 10
J_2 Z_108 B_2 Z_109 
Stack 11
G_4 E_5 C_0 J_1 
Stack 12
F_5 B_0 D_6 E_3 
Stack 13
E_7 A_4 G_1 Z_110 
Stack 14
Z_111 H_5 H_3 A_1 
Stack 15
E_4 H_0 G_3 F_1 
Stack 16
F_3 Z_112 A_0 
Stack 17
D_2 G_2 Z_113 
