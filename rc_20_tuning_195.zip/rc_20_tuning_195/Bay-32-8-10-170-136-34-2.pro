Number Of Containers
170
Number Of Yard Stacks
32
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
136
Number Of Shutout Containers
34
Yard Bay
Stack 0
G_14 B_0 B_4 G_1 I_11 Z_100 
Stack 1
Z_101 A_0 A_3 I_4 J_8 A_9 
Stack 2
B_9 D_5 Z_102 F_12 Z_103 B_11 
Stack 3
F_1 H_0 E_8 G_10 I_0 A_11 
Stack 4
D_7 Z_104 B_5 G_12 E_10 I_9 
Stack 5
H_10 J_3 B_6 Z_105 F_13 J_10 
Stack 6
Z_106 G_7 G_2 A_2 Z_107 A_10 
Stack 7
F_2 G_13 H_2 C_7 C_2 H_6 
Stack 8
C_4 Z_108 D_6 D_2 J_5 C_0 
Stack 9
B_7 I_2 C_10 D_3 Z_109 Z_110 
Stack 10
Z_111 Z_112 G_8 C_3 D_4 
Stack 11
F_4 C_9 Z_113 B_3 F_0 
Stack 12
Z_114 D_12 Z_115 F_3 Z_116 
Stack 13
C_12 E_5 G_6 J_11 H_3 
Stack 14
E_2 E_4 A_1 F_7 B_1 
Stack 15
D_1 Z_117 E_15 Z_118 E_12 
Stack 16
E_11 Z_119 J_7 I_7 F_6 
Stack 17
A_8 H_5 F_8 I_10 J_1 
Stack 18
Z_120 E_3 A_7 E_6 C_5 
Stack 19
E_9 F_11 C_14 I_8 A_5 
Stack 20
Z_121 Z_122 G_3 F_15 G_4 
Stack 21
B_8 E_1 Z_123 J_6 D_8 
Stack 22
A_4 C_13 Z_124 J_2 C_6 
Stack 23
Z_125 H_8 I_1 J_4 D_11 
Stack 24
H_7 D_9 C_8 G_5 G_11 
Stack 25
A_6 I_5 J_0 Z_126 Z_127 
Stack 26
G_9 F_5 E_0 B_10 Z_128 
Stack 27
D_0 B_2 Z_129 E_7 Z_130 
Stack 28
F_10 Z_131 D_13 Z_132 E_13 
Stack 29
C_1 F_14 F_9 H_4 H_9 
Stack 30
D_10 C_11 Z_133 I_6 I_3 
Stack 31
J_9 H_11 H_1 E_14 G_0 
