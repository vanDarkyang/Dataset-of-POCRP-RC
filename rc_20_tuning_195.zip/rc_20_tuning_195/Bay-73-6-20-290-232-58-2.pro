Number Of Containers
290
Number Of Yard Stacks
73
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
232
Number Of Shutout Containers
58
Yard Bay
Stack 0
F_3 F_12 N_3 E_6 
Stack 1
C_0 G_4 Z_100 B_4 
Stack 2
M_5 G_1 G_0 Q_1 
Stack 3
K_4 Z_101 K_10 J_6 
Stack 4
Z_102 K_7 O_6 I_1 
Stack 5
A_2 K_2 J_4 B_8 
Stack 6
Q_3 J_7 S_3 P_4 
Stack 7
I_13 Z_103 T_1 P_10 
Stack 8
Z_104 J_2 Z_105 J_10 
Stack 9
L_5 T_0 E_3 Z_106 
Stack 10
A_3 S_2 Z_107 Z_108 
Stack 11
Q_4 M_8 G_8 Z_109 
Stack 12
H_8 M_6 N_8 I_6 
Stack 13
D_3 S_4 L_10 H_6 
Stack 14
I_8 K_6 Z_110 G_13 
Stack 15
R_6 N_0 J_13 G_7 
Stack 16
O_10 N_5 E_2 K_9 
Stack 17
J_8 R_7 R_0 L_8 
Stack 18
J_14 H_7 Z_111 B_10 
Stack 19
I_11 S_9 B_3 D_9 
Stack 20
H_0 Z_112 N_4 Q_5 
Stack 21
N_1 L_3 A_4 I_10 
Stack 22
O_3 A_0 K_13 E_8 
Stack 23
T_6 N_12 Q_7 O_5 
Stack 24
Z_113 Z_114 H_9 H_10 
Stack 25
E_4 R_1 Z_115 Z_116 
Stack 26
B_9 M_1 E_7 L_9 
Stack 27
B_6 N_7 K_12 F_9 
Stack 28
J_11 J_3 Z_117 J_1 
Stack 29
Z_118 D_2 O_11 O_8 
Stack 30
R_2 O_1 P_1 P_0 
Stack 31
Z_119 G_10 O_9 P_9 
Stack 32
Z_120 C_7 M_9 R_4 
Stack 33
Z_121 Z_122 Z_123 Z_124 
Stack 34
G_3 F_10 G_6 T_4 
Stack 35
K_3 Z_125 P_3 K_11 
Stack 36
G_5 M_11 O_0 Z_126 
Stack 37
Q_2 S_7 H_11 D_7 
Stack 38
Z_127 M_12 Z_128 Z_129 
Stack 39
E_11 Z_130 D_4 Z_131 
Stack 40
N_9 H_5 Z_132 I_12 
Stack 41
B_7 J_5 R_5 F_2 
Stack 42
G_11 O_4 Z_133 T_2 
Stack 43
L_4 Z_134 S_6 Z_135 
Stack 44
Z_136 I_5 A_1 S_0 
Stack 45
R_8 I_7 I_4 C_6 
Stack 46
Z_137 B_2 J_9 C_5 
Stack 47
N_2 M_4 F_7 T_5 
Stack 48
C_4 P_8 H_1 F_13 
Stack 49
L_2 S_8 F_6 K_1 
Stack 50
K_14 Z_138 K_15 F_5 
Stack 51
Z_139 Z_140 L_1 L_7 
Stack 52
M_2 D_5 Z_141 Z_142 
Stack 53
E_5 C_2 H_3 Z_143 
Stack 54
G_2 Z_144 H_2 M_10 
Stack 55
H_4 B_0 N_10 F_4 
Stack 56
P_5 A_5 I_9 D_6 
Stack 57
P_6 Z_145 Z_146 F_14 
Stack 58
Z_147 Z_148 C_1 E_9 
Stack 59
I_0 C_3 M_13 B_5 
Stack 60
E_10 K_0 D_8 O_2 
Stack 61
T_3 J_0 S_1 R_3 
Stack 62
S_5 Z_149 Z_150 Z_151 
Stack 63
F_1 J_12 N_6 Q_6 
Stack 64
L_6 Z_152 G_12 Z_153 
Stack 65
P_2 B_1 Z_154 Q_9 
Stack 66
F_11 Q_0 M_7 L_0 
Stack 67
Q_8 K_8 H_12 P_7 
Stack 68
Z_155 I_3 O_7 E_0 
Stack 69
C_8 F_0 F_8 M_3 
Stack 70
Z_156 M_0 N_11 I_2 
Stack 71
Z_157 D_1 D_0 
Stack 72
G_9 E_1 K_5 
