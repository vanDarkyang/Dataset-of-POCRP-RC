Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_6 E_3 E_7 D_5 
Stack 1
B_0 C_8 D_0 B_7 
Stack 2
B_3 B_8 E_1 A_4 
Stack 3
A_2 C_1 D_2 E_5 
Stack 4
E_4 A_0 E_2 Z_100 
Stack 5
C_9 B_4 C_0 C_5 
Stack 6
D_7 A_5 E_0 B_2 
Stack 7
C_6 C_3 E_8 D_6 
Stack 8
Z_101 Z_102 Z_103 C_2 
Stack 9
A_1 C_7 Z_104 Z_105 
Stack 10
D_1 Z_106 E_6 D_3 
Stack 11
D_8 A_3 B_5 B_1 
Stack 12
Z_107 Z_108 C_4 
Stack 13
Z_109 D_4 Z_110 
