Number Of Containers
29
Number Of Yard Stacks
6
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
23
Number Of Shutout Containers
6
Yard Bay
Stack 0
C_3 C_5 C_0 Z_100 B_2 
Stack 1
B_1 Z_101 E_1 Z_102 B_0 
Stack 2
B_4 D_0 Z_103 E_2 C_4 
Stack 3
A_3 C_2 Z_104 A_1 B_5 
Stack 4
C_1 A_0 D_1 B_3 A_4 
Stack 5
D_2 A_2 E_0 Z_105 
