Number Of Containers
199
Number Of Yard Stacks
50
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
159
Number Of Shutout Containers
40
Yard Bay
Stack 0
F_3 I_9 D_1 Z_100 
Stack 1
M_6 N_6 Z_101 K_1 
Stack 2
E_0 G_0 L_7 F_12 
Stack 3
O_3 Z_102 O_1 G_14 
Stack 4
G_12 B_2 I_2 Z_103 
Stack 5
C_4 C_6 O_8 D_8 
Stack 6
Z_104 H_12 K_2 H_0 
Stack 7
J_1 Z_105 Z_106 M_1 
Stack 8
Z_107 E_6 I_4 D_6 
Stack 9
Z_108 I_1 A_5 G_9 
Stack 10
E_3 C_2 C_3 J_10 
Stack 11
G_3 Z_109 I_5 M_4 
Stack 12
Z_110 C_5 L_3 O_2 
Stack 13
C_7 D_9 I_12 L_10 
Stack 14
J_6 M_5 C_8 A_4 
Stack 15
F_11 M_0 Z_111 Z_112 
Stack 16
L_4 J_0 Z_113 C_0 
Stack 17
J_9 G_7 I_3 E_4 
Stack 18
N_0 K_8 Z_114 D_5 
Stack 19
E_5 Z_115 E_7 A_7 
Stack 20
J_2 H_8 H_1 D_4 
Stack 21
D_2 L_1 O_7 I_0 
Stack 22
M_2 L_8 K_10 Z_116 
Stack 23
L_0 G_15 N_3 Z_117 
Stack 24
I_8 I_7 C_1 I_6 
Stack 25
G_1 J_7 Z_118 A_8 
Stack 26
G_10 B_5 N_4 G_8 
Stack 27
B_0 Z_119 H_4 H_13 
Stack 28
Z_120 J_5 F_7 F_10 
Stack 29
Z_121 M_3 F_5 H_9 
Stack 30
A_1 G_2 L_2 F_4 
Stack 31
I_11 D_7 Z_122 F_6 
Stack 32
Z_123 H_7 E_2 K_0 
Stack 33
J_3 Z_124 N_1 K_5 
Stack 34
G_11 Z_125 O_6 C_9 
Stack 35
M_8 K_11 B_3 H_3 
Stack 36
Z_126 G_6 Z_127 H_11 
Stack 37
Z_128 O_0 H_6 M_7 
Stack 38
F_9 Z_129 H_10 A_0 
Stack 39
F_2 L_9 N_5 H_2 
Stack 40
E_1 O_4 B_1 L_6 
Stack 41
D_0 F_0 N_7 A_6 
Stack 42
A_3 Z_130 H_5 G_4 
Stack 43
Z_131 N_2 Z_132 K_3 
Stack 44
Z_133 O_5 J_4 A_2 
Stack 45
Z_134 Z_135 K_9 Z_136 
Stack 46
Z_137 G_13 G_5 F_1 
Stack 47
J_8 K_4 Z_138 K_7 
Stack 48
D_3 I_10 F_8 K_6 
Stack 49
B_4 L_5 Z_139 
