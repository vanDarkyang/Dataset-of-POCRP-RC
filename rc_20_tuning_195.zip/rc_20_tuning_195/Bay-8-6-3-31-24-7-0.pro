Number Of Containers
31
Number Of Yard Stacks
8
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
24
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_0 A_2 C_2 Z_100 
Stack 1
C_1 B_5 B_2 Z_101 
Stack 2
B_3 Z_102 A_4 B_8 
Stack 3
A_0 A_5 Z_103 Z_104 
Stack 4
A_6 B_4 C_4 B_0 
Stack 5
B_7 A_7 A_1 B_1 
Stack 6
Z_105 A_3 Z_106 C_5 
Stack 7
B_6 C_3 C_6 
