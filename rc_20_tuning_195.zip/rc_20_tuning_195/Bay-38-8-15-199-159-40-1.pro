Number Of Containers
199
Number Of Yard Stacks
38
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
159
Number Of Shutout Containers
40
Yard Bay
Stack 0
O_3 O_0 Z_100 E_4 D_4 O_4 
Stack 1
L_6 C_1 C_3 F_2 C_7 H_6 
Stack 2
Z_101 J_0 O_1 B_0 G_8 L_8 
Stack 3
Z_102 K_0 B_7 O_2 F_6 Z_103 
Stack 4
Z_104 N_5 B_2 G_6 Z_105 A_7 
Stack 5
G_3 I_4 J_7 J_11 M_6 N_8 
Stack 6
Z_106 C_5 A_0 E_7 D_0 L_1 
Stack 7
M_8 H_1 Z_107 K_7 L_4 M_0 
Stack 8
Z_108 K_5 N_7 J_8 C_6 H_2 
Stack 9
M_11 Z_109 Z_110 L_10 Z_111 
Stack 10
N_3 Z_112 O_6 M_10 G_9 
Stack 11
J_12 A_6 J_5 K_10 O_7 
Stack 12
I_11 K_1 H_12 F_5 H_4 
Stack 13
I_3 K_9 G_11 Z_113 L_5 
Stack 14
G_12 A_3 B_6 J_4 I_8 
Stack 15
M_2 K_8 I_1 L_9 G_1 
Stack 16
E_1 Z_114 Z_115 E_0 F_7 
Stack 17
N_4 B_3 I_0 H_7 M_9 
Stack 18
Z_116 Z_117 F_0 Z_118 A_4 
Stack 19
O_5 Z_119 C_0 G_4 L_7 
Stack 20
Z_120 D_5 M_1 G_2 Z_121 
Stack 21
Z_122 Z_123 F_1 J_9 K_3 
Stack 22
E_8 Z_124 B_4 N_6 M_5 
Stack 23
Z_125 B_1 I_12 G_7 G_5 
Stack 24
K_6 L_2 F_8 N_2 D_1 
Stack 25
Z_126 H_9 Z_127 I_10 Z_128 
Stack 26
I_9 J_10 H_13 E_2 A_2 
Stack 27
D_2 Z_129 F_3 K_2 I_2 
Stack 28
N_0 Z_130 I_5 M_4 H_0 
Stack 29
F_4 M_7 J_1 Z_131 I_6 
Stack 30
Z_132 H_10 C_2 F_9 E_3 
Stack 31
K_4 H_5 Z_133 H_11 E_5 
Stack 32
J_3 Z_134 I_7 D_3 A_1 
Stack 33
E_6 N_9 G_10 Z_135 L_0 
Stack 34
C_4 A_5 Z_136 L_12 J_6 
Stack 35
Z_137 Z_138 B_5 M_3 E_9 
Stack 36
H_3 N_1 O_8 L_3 J_2 
Stack 37
L_11 E_10 Z_139 G_0 H_8 
