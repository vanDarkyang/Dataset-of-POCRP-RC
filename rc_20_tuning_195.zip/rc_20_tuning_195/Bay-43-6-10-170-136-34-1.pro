Number Of Containers
170
Number Of Yard Stacks
43
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
136
Number Of Shutout Containers
34
Yard Bay
Stack 0
C_8 F_9 H_7 I_6 
Stack 1
Z_100 G_10 Z_101 A_10 
Stack 2
A_5 I_4 Z_102 Z_103 
Stack 3
H_12 I_3 G_7 Z_104 
Stack 4
J_0 Z_105 E_0 A_3 
Stack 5
J_3 B_2 F_4 I_10 
Stack 6
G_8 F_2 Z_106 E_3 
Stack 7
D_10 H_6 D_12 H_9 
Stack 8
C_6 Z_107 Z_108 B_4 
Stack 9
G_5 B_8 G_6 H_4 
Stack 10
Z_109 B_14 Z_110 C_4 
Stack 11
B_5 D_4 B_1 B_6 
Stack 12
B_3 H_1 D_6 Z_111 
Stack 13
Z_112 Z_113 H_5 D_2 
Stack 14
Z_114 Z_115 B_7 E_7 
Stack 15
D_7 E_5 J_1 A_4 
Stack 16
B_9 I_9 E_1 Z_116 
Stack 17
J_5 H_8 C_0 F_8 
Stack 18
C_5 G_12 H_2 H_13 
Stack 19
C_3 E_6 C_9 G_13 
Stack 20
E_9 F_0 D_5 B_0 
Stack 21
E_10 B_10 D_13 Z_117 
Stack 22
I_7 J_2 D_1 J_8 
Stack 23
D_0 J_10 H_10 J_9 
Stack 24
A_6 Z_118 G_4 F_6 
Stack 25
F_11 E_12 G_0 E_8 
Stack 26
A_8 D_3 E_2 C_13 
Stack 27
A_0 Z_119 I_1 E_11 
Stack 28
D_11 F_3 G_14 C_11 
Stack 29
J_6 I_5 B_11 C_12 
Stack 30
G_9 G_1 D_14 F_10 
Stack 31
F_13 J_4 H_11 G_2 
Stack 32
E_13 Z_120 I_8 Z_121 
Stack 33
D_8 F_5 D_9 H_3 
Stack 34
H_0 C_10 C_1 I_2 
Stack 35
Z_122 Z_123 Z_124 A_1 
Stack 36
E_4 C_2 F_1 B_13 
Stack 37
Z_125 F_7 Z_126 G_3 
Stack 38
J_7 F_12 Z_127 I_0 
Stack 39
Z_128 Z_129 F_14 A_7 
Stack 40
Z_130 C_7 A_9 I_11 
Stack 41
Z_131 B_12 A_2 
Stack 42
Z_132 G_11 Z_133 
