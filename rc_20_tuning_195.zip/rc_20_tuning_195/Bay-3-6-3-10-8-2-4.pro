Number Of Containers
10
Number Of Yard Stacks
3
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
8
Number Of Shutout Containers
2
Yard Bay
Stack 0
B_1 Z_100 B_2 B_3 
Stack 1
A_0 A_1 B_0 
Stack 2
C_0 C_1 Z_101 
