Number Of Containers
120
Number Of Yard Stacks
30
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_1 Z_100 B_5 F_1 
Stack 1
D_9 D_2 D_0 J_0 
Stack 2
Z_101 Z_102 J_1 D_7 
Stack 3
A_9 E_2 G_0 C_0 
Stack 4
H_5 E_5 Z_103 Z_104 
Stack 5
C_6 A_5 D_8 I_0 
Stack 6
G_3 E_4 B_0 D_10 
Stack 7
J_2 E_7 B_1 C_9 
Stack 8
C_5 A_3 D_5 E_3 
Stack 9
J_5 D_3 I_6 J_6 
Stack 10
F_3 H_2 F_6 D_4 
Stack 11
Z_105 H_3 Z_106 C_4 
Stack 12
B_7 C_8 G_8 H_6 
Stack 13
D_1 J_4 Z_107 F_9 
Stack 14
Z_108 G_9 C_7 I_7 
Stack 15
H_0 Z_109 B_2 Z_110 
Stack 16
G_2 Z_111 Z_112 A_2 
Stack 17
I_5 G_1 I_4 B_8 
Stack 18
I_2 E_6 Z_113 C_2 
Stack 19
E_8 I_3 E_1 A_0 
Stack 20
F_4 H_8 F_0 Z_114 
Stack 21
A_8 C_3 Z_115 G_7 
Stack 22
F_8 Z_116 A_4 H_4 
Stack 23
H_1 F_2 C_10 F_5 
Stack 24
A_1 G_6 B_3 Z_117 
Stack 25
H_9 Z_118 J_3 H_7 
Stack 26
Z_119 I_1 B_6 F_7 
Stack 27
Z_120 A_7 Z_121 A_6 
Stack 28
E_0 G_4 Z_122 Z_123 
Stack 29
G_5 B_4 I_8 D_6 
