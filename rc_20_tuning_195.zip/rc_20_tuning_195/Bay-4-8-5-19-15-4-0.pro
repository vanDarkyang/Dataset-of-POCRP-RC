Number Of Containers
19
Number Of Yard Stacks
4
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
15
Number Of Shutout Containers
4
Yard Bay
Stack 0
B_1 A_0 A_1 Z_100 B_3 
Stack 1
D_1 B_2 E_1 C_1 Z_101 
Stack 2
E_0 C_2 B_0 C_0 C_3 
Stack 3
D_0 Z_102 D_2 Z_103 
