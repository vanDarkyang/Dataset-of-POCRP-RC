Number Of Containers
31
Number Of Yard Stacks
6
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
24
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_0 Z_100 B_2 Z_101 B_1 C_7 
Stack 1
C_1 B_5 A_6 C_4 C_6 
Stack 2
Z_102 A_2 A_3 C_5 B_7 
Stack 3
A_0 B_4 C_3 A_1 Z_103 
Stack 4
A_5 Z_104 C_2 B_3 Z_105 
Stack 5
B_6 A_4 B_0 C_8 Z_106 
