Number Of Containers
29
Number Of Yard Stacks
8
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
23
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_1 B_2 E_2 Z_100 
Stack 1
A_0 Z_101 Z_102 D_5 
Stack 2
B_4 C_1 D_4 A_1 
Stack 3
Z_103 C_0 E_0 E_1 
Stack 4
B_3 D_1 Z_104 C_3 
Stack 5
D_2 A_2 B_0 
Stack 6
D_3 C_2 D_0 
Stack 7
Z_105 E_3 E_4 
