Number Of Containers
16
Number Of Yard Stacks
3
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
12
Number Of Shutout Containers
4
Yard Bay
Stack 0
A_3 Z_100 C_0 Z_101 Z_102 C_1 
Stack 1
B_0 A_1 A_2 B_5 B_3 
Stack 2
B_2 Z_103 B_4 A_0 B_1 
