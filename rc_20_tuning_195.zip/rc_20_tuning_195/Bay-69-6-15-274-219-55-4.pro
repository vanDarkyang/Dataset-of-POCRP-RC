Number Of Containers
274
Number Of Yard Stacks
69
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
219
Number Of Shutout Containers
55
Yard Bay
Stack 0
L_2 Z_100 I_8 Z_101 
Stack 1
C_1 Z_102 M_11 E_11 
Stack 2
D_11 Z_103 E_14 Z_104 
Stack 3
Z_105 Z_106 B_4 Z_107 
Stack 4
D_8 O_8 A_3 M_1 
Stack 5
K_11 F_6 E_12 F_4 
Stack 6
Z_108 L_3 C_7 J_1 
Stack 7
O_9 H_11 C_12 Z_109 
Stack 8
Z_110 Z_111 N_7 C_10 
Stack 9
I_18 I_9 Z_112 Z_113 
Stack 10
B_7 I_5 A_1 L_9 
Stack 11
Z_114 A_10 I_11 J_10 
Stack 12
F_11 N_4 H_9 C_0 
Stack 13
N_3 Z_115 J_13 A_7 
Stack 14
O_7 F_3 I_15 G_6 
Stack 15
C_5 N_5 D_10 I_4 
Stack 16
Z_116 J_8 I_2 H_7 
Stack 17
Z_117 Z_118 G_2 G_12 
Stack 18
Z_119 K_2 G_10 J_3 
Stack 19
K_1 E_5 Z_120 M_10 
Stack 20
C_4 F_2 Z_121 J_0 
Stack 21
Z_122 D_6 Z_123 F_8 
Stack 22
J_2 Z_124 A_4 O_1 
Stack 23
M_4 K_14 D_9 G_1 
Stack 24
H_13 L_14 H_4 G_5 
Stack 25
K_7 B_10 K_13 B_0 
Stack 26
O_4 Z_125 I_10 A_9 
Stack 27
D_1 B_3 K_10 C_8 
Stack 28
G_8 D_13 Z_126 J_4 
Stack 29
H_3 J_9 B_8 O_0 
Stack 30
N_6 G_7 Z_127 J_7 
Stack 31
B_9 M_3 F_9 B_12 
Stack 32
M_13 M_0 H_8 B_5 
Stack 33
G_3 I_19 J_6 F_13 
Stack 34
E_6 E_13 L_8 I_6 
Stack 35
H_10 I_1 L_13 H_0 
Stack 36
Z_128 E_1 J_16 F_5 
Stack 37
E_10 Z_129 Z_130 K_0 
Stack 38
Z_131 L_10 B_1 O_2 
Stack 39
D_2 Z_132 A_0 Z_133 
Stack 40
H_12 Z_134 M_8 Z_135 
Stack 41
C_9 L_5 F_14 D_0 
Stack 42
E_9 E_0 I_14 M_6 
Stack 43
B_2 O_12 G_0 Z_136 
Stack 44
E_3 Z_137 Z_138 K_6 
Stack 45
L_7 H_2 G_13 E_4 
Stack 46
Z_139 K_3 L_6 Z_140 
Stack 47
D_4 Z_141 M_12 K_4 
Stack 48
J_15 I_7 L_1 Z_142 
Stack 49
G_14 K_8 L_12 A_5 
Stack 50
G_15 J_12 F_7 O_10 
Stack 51
E_7 N_8 H_1 Z_143 
Stack 52
G_9 F_0 Z_144 G_11 
Stack 53
I_17 B_11 O_3 O_11 
Stack 54
Z_145 G_4 M_5 D_5 
Stack 55
Z_146 E_8 K_12 O_5 
Stack 56
M_7 C_2 I_3 D_12 
Stack 57
L_4 H_14 K_5 K_9 
Stack 58
Z_147 N_1 C_11 F_1 
Stack 59
I_0 D_3 Z_148 Z_149 
Stack 60
B_6 H_6 L_15 Z_150 
Stack 61
E_2 N_2 Z_151 O_6 
Stack 62
I_13 J_11 Z_152 L_0 
Stack 63
F_10 H_5 J_14 M_2 
Stack 64
M_9 A_6 C_3 L_11 
Stack 65
D_7 J_5 N_0 Z_153 
Stack 66
Z_154 L_16 I_12 C_6 
Stack 67
B_13 F_12 A_8 
Stack 68
A_2 I_16 B_14 
