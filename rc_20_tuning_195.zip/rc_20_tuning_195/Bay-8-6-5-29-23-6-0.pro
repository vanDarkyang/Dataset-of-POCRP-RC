Number Of Containers
29
Number Of Yard Stacks
8
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
23
Number Of Shutout Containers
6
Yard Bay
Stack 0
A_1 B_4 B_2 D_3 
Stack 1
B_0 Z_100 Z_101 B_3 
Stack 2
B_5 Z_102 D_4 E_0 
Stack 3
A_4 Z_103 Z_104 A_3 
Stack 4
Z_105 A_0 A_2 B_1 
Stack 5
C_1 D_1 C_0 
Stack 6
C_3 D_2 E_2 
Stack 7
C_2 E_1 D_0 
