Number Of Containers
19
Number Of Yard Stacks
5
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
15
Number Of Shutout Containers
4
Yard Bay
Stack 0
Z_100 B_0 Z_101 E_2 
Stack 1
D_2 C_2 D_3 Z_102 
Stack 2
E_0 C_4 D_0 Z_103 
Stack 3
D_1 A_1 C_1 C_3 
Stack 4
A_0 E_1 C_0 
