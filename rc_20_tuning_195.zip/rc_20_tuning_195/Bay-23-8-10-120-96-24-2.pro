Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
I_2 H_2 Z_100 A_6 E_3 E_5 
Stack 1
D_2 A_2 A_7 F_2 J_1 H_10 
Stack 2
E_0 C_7 G_1 H_9 I_3 H_5 
Stack 3
H_0 C_4 A_3 H_1 H_7 J_3 
Stack 4
J_5 D_6 Z_101 F_4 E_10 I_8 
Stack 5
C_1 Z_102 I_0 I_9 A_8 
Stack 6
E_6 C_8 D_4 I_7 J_0 
Stack 7
E_1 J_4 C_5 F_7 Z_103 
Stack 8
F_3 Z_104 A_5 G_7 B_4 
Stack 9
D_5 D_1 I_4 A_4 D_0 
Stack 10
Z_105 D_8 B_0 G_10 A_1 
Stack 11
A_0 Z_106 F_1 Z_107 E_7 
Stack 12
Z_108 Z_109 F_0 G_2 Z_110 
Stack 13
Z_111 H_6 G_5 G_9 I_6 
Stack 14
F_5 Z_112 Z_113 C_10 B_3 
Stack 15
G_6 B_5 F_6 C_3 G_4 
Stack 16
E_9 E_4 G_8 Z_114 Z_115 
Stack 17
H_4 G_3 Z_116 Z_117 E_2 
Stack 18
E_8 B_7 C_9 C_6 C_2 
Stack 19
Z_118 J_2 Z_119 Z_120 C_0 
Stack 20
D_7 F_8 Z_121 B_2 B_6 
Stack 21
H_8 G_0 B_1 I_5 H_3 
Stack 22
Z_122 Z_123 G_11 I_1 D_3 
