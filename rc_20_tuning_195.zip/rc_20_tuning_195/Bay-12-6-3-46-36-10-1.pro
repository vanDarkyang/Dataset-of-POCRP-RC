Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 Z_101 A_9 A_6 
Stack 1
A_12 Z_102 C_9 A_5 
Stack 2
A_2 C_1 B_3 A_4 
Stack 3
A_0 Z_103 Z_104 B_8 
Stack 4
C_6 C_5 C_3 B_1 
Stack 5
B_7 A_7 A_1 A_11 
Stack 6
B_11 B_6 C_7 Z_105 
Stack 7
Z_106 Z_107 A_10 B_5 
Stack 8
B_2 C_0 B_0 B_4 
Stack 9
A_8 C_2 C_4 Z_108 
Stack 10
A_3 B_9 Z_109 
Stack 11
C_10 B_10 C_8 
