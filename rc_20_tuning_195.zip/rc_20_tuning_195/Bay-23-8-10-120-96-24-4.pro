Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_1 H_1 Z_100 Z_101 D_7 H_7 
Stack 1
D_8 A_1 G_0 F_6 C_0 F_8 
Stack 2
B_0 H_10 E_7 J_5 E_8 A_6 
Stack 3
A_8 D_5 I_3 G_8 I_0 Z_102 
Stack 4
H_5 I_7 H_9 D_0 D_9 Z_103 
Stack 5
C_5 E_0 C_3 C_6 C_8 
Stack 6
G_2 G_4 Z_104 B_1 E_2 
Stack 7
J_2 B_4 Z_105 F_7 J_6 
Stack 8
C_4 D_2 G_6 Z_106 D_4 
Stack 9
Z_107 F_3 I_5 E_10 Z_108 
Stack 10
Z_109 Z_110 I_1 E_1 H_6 
Stack 11
Z_111 E_6 A_7 F_1 F_10 
Stack 12
B_7 A_5 G_3 E_3 I_6 
Stack 13
D_1 E_5 B_3 A_4 J_4 
Stack 14
H_8 E_9 B_5 C_9 A_2 
Stack 15
H_0 A_3 Z_112 B_2 Z_113 
Stack 16
G_1 D_3 J_1 Z_114 C_2 
Stack 17
I_4 H_2 Z_115 B_6 A_0 
Stack 18
I_2 H_3 F_0 G_5 E_4 
Stack 19
E_11 C_7 Z_116 F_4 G_7 
Stack 20
Z_117 J_3 Z_118 Z_119 H_4 
Stack 21
Z_120 G_9 Z_121 F_2 F_5 
Stack 22
F_9 Z_122 D_6 J_0 Z_123 
