Number Of Containers
150
Number Of Yard Stacks
29
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
120
Number Of Shutout Containers
30
Yard Bay
Stack 0
D_1 J_5 J_0 R_1 P_0 Z_100 
Stack 1
M_2 Z_101 S_1 T_1 E_3 C_3 
Stack 2
F_1 H_3 N_1 G_3 L_5 E_5 
Stack 3
Z_102 S_0 A_1 P_6 Z_103 B_2 
Stack 4
E_4 M_1 N_0 L_2 Z_104 N_4 
Stack 5
C_2 C_0 I_0 Z_105 P_3 
Stack 6
L_3 Z_106 O_6 I_7 D_3 
Stack 7
Z_107 G_2 J_8 H_1 K_3 
Stack 8
Z_108 D_0 Z_109 E_1 Z_110 
Stack 9
Z_111 O_7 Q_3 H_5 K_7 
Stack 10
K_6 Z_112 J_2 F_0 L_6 
Stack 11
K_8 Z_113 H_0 M_4 N_5 
Stack 12
T_0 E_6 L_1 I_4 P_2 
Stack 13
J_1 G_0 I_2 H_7 M_6 
Stack 14
Z_114 P_5 K_0 K_4 F_2 
Stack 15
O_1 M_7 Q_4 K_2 J_3 
Stack 16
Z_115 Z_116 D_5 H_4 F_3 
Stack 17
Z_117 O_0 O_3 Z_118 Z_119 
Stack 18
P_4 M_0 I_1 Z_120 O_4 
Stack 19
Q_2 G_4 J_7 C_1 N_2 
Stack 20
A_0 Z_121 E_2 R_3 D_4 
Stack 21
K_9 N_3 L_4 R_2 Z_122 
Stack 22
E_0 K_10 Q_1 O_5 G_1 
Stack 23
D_2 I_6 M_3 H_6 Z_123 
Stack 24
Z_124 Z_125 L_0 H_2 I_5 
Stack 25
G_5 O_2 B_0 Z_126 K_1 
Stack 26
Z_127 R_0 Z_128 Z_129 B_1 
Stack 27
I_3 B_3 M_5 Q_0 J_4 
Stack 28
S_2 I_8 K_5 P_1 J_6 
