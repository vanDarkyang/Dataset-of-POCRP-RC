Number Of Containers
150
Number Of Yard Stacks
29
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
120
Number Of Shutout Containers
30
Yard Bay
Stack 0
R_2 G_1 B_1 Z_100 Z_101 E_4 
Stack 1
E_1 N_4 Q_3 P_1 M_3 J_4 
Stack 2
Q_1 O_0 Z_102 H_2 Z_103 O_5 
Stack 3
Z_104 M_2 J_2 Z_105 N_3 L_6 
Stack 4
F_3 L_9 F_1 Z_106 N_0 E_2 
Stack 5
N_1 J_1 A_0 Z_107 Z_108 
Stack 6
L_0 G_5 Z_109 Z_110 J_8 
Stack 7
N_5 I_3 A_1 L_2 D_0 
Stack 8
O_4 Z_111 I_1 Z_112 T_1 
Stack 9
L_10 G_0 N_2 K_0 Z_113 
Stack 10
Z_114 K_6 N_6 J_7 Z_115 
Stack 11
I_4 M_6 H_0 J_6 I_2 
Stack 12
T_0 O_2 Z_116 G_3 F_6 
Stack 13
K_2 M_4 D_1 R_3 I_5 
Stack 14
H_1 R_1 D_3 G_2 M_7 
Stack 15
E_3 Z_117 K_1 H_6 F_0 
Stack 16
P_4 J_3 M_5 E_0 F_2 
Stack 17
P_3 O_3 S_1 J_5 C_0 
Stack 18
Z_118 S_2 P_2 Z_119 H_5 
Stack 19
K_5 K_4 S_0 L_4 H_7 
Stack 20
Q_2 J_0 B_0 Q_0 Z_120 
Stack 21
C_1 Q_4 H_3 K_9 O_1 
Stack 22
F_7 L_5 Z_121 M_0 Z_122 
Stack 23
H_4 Z_123 L_7 T_2 K_7 
Stack 24
Z_124 F_5 L_1 Z_125 Z_126 
Stack 25
G_4 R_0 P_0 C_2 I_0 
Stack 26
K_8 D_2 S_3 B_2 F_4 
Stack 27
I_6 L_3 J_9 M_1 Z_127 
Stack 28
L_8 K_10 Z_128 Z_129 K_3 
