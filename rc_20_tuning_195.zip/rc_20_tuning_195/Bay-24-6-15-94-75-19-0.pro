Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 Z_101 L_3 G_0 
Stack 1
C_1 D_3 K_1 K_3 
Stack 2
J_1 E_1 J_2 G_1 
Stack 3
C_4 K_5 Z_102 C_3 
Stack 4
O_1 Z_103 H_2 Z_104 
Stack 5
E_0 Z_105 Z_106 E_4 
Stack 6
G_5 J_3 Z_107 H_5 
Stack 7
M_0 I_3 J_4 A_0 
Stack 8
D_1 C_0 N_3 H_4 
Stack 9
F_2 L_0 B_0 Z_108 
Stack 10
K_2 H_1 D_2 N_2 
Stack 11
H_3 Z_109 L_5 B_1 
Stack 12
D_4 G_2 I_4 E_2 
Stack 13
M_1 B_2 Z_110 G_3 
Stack 14
G_7 Z_111 M_3 F_3 
Stack 15
I_0 E_3 Z_112 N_1 
Stack 16
F_4 Z_113 L_4 I_6 
Stack 17
I_2 A_1 O_0 J_0 
Stack 18
L_2 G_4 M_2 I_5 
Stack 19
H_0 C_2 I_7 K_0 
Stack 20
Z_114 I_1 Z_115 H_6 
Stack 21
K_4 Z_116 Z_117 L_1 
Stack 22
F_1 D_0 Z_118 
Stack 23
F_0 G_6 N_0 
