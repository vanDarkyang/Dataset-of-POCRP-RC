Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 J_2 G_1 G_6 D_4 M_0 
Stack 1
E_4 H_1 D_0 M_1 L_2 C_2 
Stack 2
Z_101 Z_102 J_1 Z_103 Z_104 L_1 
Stack 3
N_0 F_3 F_5 E_5 J_3 D_3 
Stack 4
A_0 E_1 I_3 Z_105 L_3 
Stack 5
Z_106 F_2 C_1 M_2 D_1 
Stack 6
F_1 F_0 I_4 K_2 G_3 
Stack 7
H_2 F_4 Z_107 N_2 H_7 
Stack 8
C_4 H_0 Z_108 H_5 C_0 
Stack 9
A_1 H_8 Z_109 E_0 I_0 
Stack 10
O_1 G_4 Z_110 J_4 J_5 
Stack 11
Z_111 G_5 Z_112 M_4 B_0 
Stack 12
Z_113 L_4 Z_114 G_0 I_6 
Stack 13
Z_115 B_1 E_2 M_3 B_2 
Stack 14
Z_116 F_6 I_5 D_2 H_3 
Stack 15
H_4 H_6 Z_117 O_0 I_2 
Stack 16
K_1 N_1 I_1 L_0 E_3 
Stack 17
C_3 Z_118 G_2 J_0 K_0 
