Number Of Containers
46
Number Of Yard Stacks
9
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_1 B_3 B_11 B_12 C_4 B_8 
Stack 1
Z_100 A_6 B_4 Z_101 Z_102 
Stack 2
C_9 C_1 A_2 C_6 B_5 
Stack 3
A_0 B_0 A_3 B_10 Z_103 
Stack 4
A_7 C_3 Z_104 C_0 A_5 
Stack 5
C_2 A_4 A_12 A_11 Z_105 
Stack 6
B_2 Z_106 B_6 Z_107 Z_108 
Stack 7
C_8 C_5 B_9 C_7 B_7 
Stack 8
Z_109 A_1 A_9 A_8 A_10 
