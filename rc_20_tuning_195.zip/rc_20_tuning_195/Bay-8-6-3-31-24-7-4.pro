Number Of Containers
31
Number Of Yard Stacks
8
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
24
Number Of Shutout Containers
7
Yard Bay
Stack 0
Z_100 A_0 Z_101 Z_102 
Stack 1
Z_103 A_6 C_5 A_7 
Stack 2
B_8 C_0 A_4 Z_104 
Stack 3
B_0 A_1 B_6 A_3 
Stack 4
Z_105 C_4 B_1 C_1 
Stack 5
B_4 C_6 Z_106 A_5 
Stack 6
B_7 C_3 C_2 A_2 
Stack 7
B_3 B_5 B_2 
