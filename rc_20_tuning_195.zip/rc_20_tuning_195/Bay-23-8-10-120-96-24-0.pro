Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_0 G_6 A_3 Z_100 Z_101 D_3 
Stack 1
Z_102 B_7 B_9 G_8 H_6 F_8 
Stack 2
Z_103 F_10 Z_104 C_6 H_2 I_1 
Stack 3
B_5 J_6 F_4 D_6 E_3 C_1 
Stack 4
Z_105 A_4 B_2 G_4 Z_106 H_3 
Stack 5
J_7 B_1 Z_107 Z_108 J_5 
Stack 6
Z_109 B_3 Z_110 D_1 G_9 
Stack 7
E_0 B_4 E_1 F_0 H_5 
Stack 8
Z_111 A_2 I_4 J_2 Z_112 
Stack 9
Z_113 G_7 G_5 F_7 H_1 
Stack 10
Z_114 C_0 Z_115 H_7 I_6 
Stack 11
D_5 F_6 G_10 A_0 H_8 
Stack 12
Z_116 B_8 J_4 B_6 C_2 
Stack 13
G_3 H_0 J_0 I_0 I_2 
Stack 14
G_0 Z_117 Z_118 C_4 F_12 
Stack 15
Z_119 J_1 G_2 F_2 I_3 
Stack 16
F_11 A_1 C_3 E_6 E_12 
Stack 17
C_7 I_5 Z_120 F_9 E_7 
Stack 18
F_3 J_8 D_2 D_7 Z_121 
Stack 19
E_4 E_11 C_5 Z_122 F_1 
Stack 20
F_13 Z_123 J_3 F_5 D_4 
Stack 21
H_4 E_2 E_8 E_10 G_1 
Stack 22
E_5 A_6 E_9 B_0 A_5 
