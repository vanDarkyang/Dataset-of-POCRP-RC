Number Of Containers
31
Number Of Yard Stacks
8
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
24
Number Of Shutout Containers
7
Yard Bay
Stack 0
C_1 A_9 Z_100 Z_101 
Stack 1
B_2 A_8 B_6 A_2 
Stack 2
Z_102 Z_103 A_0 C_5 
Stack 3
B_4 B_0 A_6 C_4 
Stack 4
B_7 A_1 B_1 A_4 
Stack 5
A_7 C_3 Z_104 A_5 
Stack 6
B_5 B_3 Z_105 C_2 
Stack 7
C_0 Z_106 A_3 
