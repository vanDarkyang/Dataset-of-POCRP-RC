Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
H_0 Z_100 F_0 B_0 Z_101 
Stack 1
E_1 H_1 G_4 F_4 C_3 
Stack 2
B_2 B_1 G_0 I_0 D_2 
Stack 3
F_2 G_2 G_5 I_1 F_1 
Stack 4
F_3 Z_102 Z_103 J_2 E_2 
Stack 5
Z_104 Z_105 H_2 H_3 Z_106 
Stack 6
C_0 Z_107 A_0 B_3 A_2 
Stack 7
D_3 E_0 D_1 J_1 Z_108 
Stack 8
C_1 A_1 H_4 G_1 D_4 
Stack 9
J_0 D_0 G_3 Z_109 C_2 
