Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 D_2 J_4 H_3 M_1 Z_101 
Stack 1
I_1 N_1 J_5 Z_102 K_2 I_3 
Stack 2
C_0 J_7 Z_103 I_2 H_5 Z_104 
Stack 3
K_0 G_7 C_1 M_3 Z_105 J_3 
Stack 4
D_5 F_1 J_0 Z_106 E_0 
Stack 5
H_4 D_3 Z_107 Z_108 I_5 
Stack 6
C_4 G_4 G_0 O_0 K_1 
Stack 7
N_3 D_4 Z_109 H_7 C_2 
Stack 8
K_3 N_0 O_1 L_2 H_0 
Stack 9
Z_110 L_1 B_0 A_1 Z_111 
Stack 10
B_2 G_2 I_0 D_0 H_2 
Stack 11
Z_112 J_1 B_3 N_2 A_2 
Stack 12
G_6 J_6 A_0 O_2 F_4 
Stack 13
H_6 F_3 Z_113 H_8 G_1 
Stack 14
D_1 G_5 F_2 G_3 I_4 
Stack 15
Z_114 Z_115 H_1 M_0 F_0 
Stack 16
H_9 Z_116 M_2 B_1 L_0 
Stack 17
Z_117 L_3 Z_118 J_2 C_3 
