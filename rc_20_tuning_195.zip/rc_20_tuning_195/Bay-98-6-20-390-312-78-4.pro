Number Of Containers
390
Number Of Yard Stacks
98
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
312
Number Of Shutout Containers
78
Yard Bay
Stack 0
I_12 D_7 I_6 M_15 
Stack 1
L_7 D_10 K_7 G_1 
Stack 2
Q_6 P_2 N_7 D_6 
Stack 3
A_4 Z_100 Q_10 Z_101 
Stack 4
R_6 D_3 N_13 Z_102 
Stack 5
A_0 M_3 P_9 T_7 
Stack 6
T_11 T_2 P_0 T_10 
Stack 7
I_9 R_9 Q_7 C_6 
Stack 8
T_9 Z_103 I_1 I_11 
Stack 9
R_10 J_3 T_6 L_4 
Stack 10
Z_104 Z_105 P_8 R_7 
Stack 11
J_1 Z_106 G_11 P_7 
Stack 12
H_16 H_11 K_15 P_3 
Stack 13
F_1 N_8 S_7 Z_107 
Stack 14
O_3 E_17 F_12 Q_5 
Stack 15
E_14 N_2 E_8 A_3 
Stack 16
M_19 Z_108 Z_109 G_3 
Stack 17
Z_110 N_12 G_6 L_1 
Stack 18
D_5 B_8 N_4 S_10 
Stack 19
C_1 M_7 J_20 A_7 
Stack 20
L_11 J_15 Z_111 N_9 
Stack 21
D_9 E_1 Z_112 T_8 
Stack 22
Z_113 M_13 I_5 Q_0 
Stack 23
Z_114 B_2 H_14 E_9 
Stack 24
Z_115 Z_116 K_14 Q_12 
Stack 25
L_0 J_17 M_12 G_0 
Stack 26
Z_117 G_13 M_9 G_7 
Stack 27
J_0 L_5 Z_118 S_6 
Stack 28
Z_119 O_1 O_8 H_3 
Stack 29
I_17 L_15 M_17 K_8 
Stack 30
H_1 J_12 Z_120 O_4 
Stack 31
R_5 K_0 B_12 J_2 
Stack 32
E_5 K_1 P_6 Z_121 
Stack 33
E_3 Z_122 K_18 O_5 
Stack 34
B_10 J_7 Z_123 M_4 
Stack 35
E_10 Z_124 D_0 E_2 
Stack 36
Z_125 K_9 Z_126 P_1 
Stack 37
S_0 I_0 O_11 T_5 
Stack 38
B_11 I_16 Z_127 Q_14 
Stack 39
E_13 D_11 P_4 Z_128 
Stack 40
B_6 H_12 Z_129 N_1 
Stack 41
L_18 L_6 E_15 N_15 
Stack 42
M_1 Q_13 Q_2 B_4 
Stack 43
E_16 B_3 I_8 B_5 
Stack 44
Z_130 M_16 S_5 S_8 
Stack 45
Q_8 F_7 K_16 N_16 
Stack 46
G_9 Z_131 Z_132 A_6 
Stack 47
F_4 M_8 A_1 E_0 
Stack 48
F_0 C_8 Z_133 K_4 
Stack 49
Q_1 H_7 F_11 L_2 
Stack 50
F_9 N_6 J_5 S_9 
Stack 51
Q_4 H_13 R_2 E_11 
Stack 52
Z_134 Q_9 E_6 F_3 
Stack 53
Z_135 C_2 O_6 L_8 
Stack 54
P_10 C_11 Z_136 C_9 
Stack 55
I_13 Z_137 I_18 B_1 
Stack 56
E_4 O_12 J_14 Z_138 
Stack 57
Z_139 I_4 T_4 Z_140 
Stack 58
A_8 N_14 K_10 Z_141 
Stack 59
N_17 Z_142 J_18 F_2 
Stack 60
D_4 S_4 G_5 G_2 
Stack 61
A_9 Z_143 B_9 N_3 
Stack 62
O_7 H_9 O_14 Z_144 
Stack 63
L_19 T_1 D_2 Z_145 
Stack 64
Z_146 M_6 J_16 C_4 
Stack 65
H_17 Z_147 R_4 Z_148 
Stack 66
Z_149 R_11 P_11 L_16 
Stack 67
M_11 I_15 L_10 D_8 
Stack 68
Z_150 M_0 I_3 K_12 
Stack 69
E_12 A_11 Z_151 M_14 
Stack 70
H_2 L_3 C_0 Z_152 
Stack 71
Z_153 F_10 N_10 M_5 
Stack 72
B_0 T_0 Z_154 S_11 
Stack 73
J_10 E_7 G_4 Z_155 
Stack 74
F_8 O_13 N_0 O_2 
Stack 75
L_13 F_5 Z_156 Z_157 
Stack 76
C_12 Q_11 T_3 R_8 
Stack 77
A_2 Z_158 H_5 Z_159 
Stack 78
I_10 C_5 N_11 K_11 
Stack 79
Z_160 I_2 Z_161 L_9 
Stack 80
F_13 L_12 C_10 F_6 
Stack 81
S_2 N_5 H_0 O_10 
Stack 82
D_1 K_13 H_10 Z_162 
Stack 83
J_6 J_11 Z_163 J_9 
Stack 84
M_18 P_5 I_14 L_14 
Stack 85
P_13 Z_164 I_7 J_8 
Stack 86
B_7 Q_3 G_10 Z_165 
Stack 87
H_8 K_5 Z_166 A_10 
Stack 88
Z_167 Z_168 Z_169 S_3 
Stack 89
Z_170 Z_171 R_0 R_1 
Stack 90
H_6 K_6 R_3 G_8 
Stack 91
S_1 M_10 Z_172 Z_173 
Stack 92
Z_174 K_17 A_5 C_3 
Stack 93
Z_175 H_15 H_4 C_7 
Stack 94
O_0 M_2 K_3 Z_176 
Stack 95
L_17 J_19 K_2 J_13 
Stack 96
O_9 Z_177 G_12 
Stack 97
J_4 P_12 N_18 
