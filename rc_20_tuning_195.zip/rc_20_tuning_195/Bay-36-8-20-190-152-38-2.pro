Number Of Containers
190
Number Of Yard Stacks
36
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
152
Number Of Shutout Containers
38
Yard Bay
Stack 0
S_0 Z_100 T_0 M_1 N_7 T_2 
Stack 1
H_11 H_0 Z_101 J_1 Z_102 F_2 
Stack 2
Z_103 Z_104 H_1 P_6 M_4 E_2 
Stack 3
Z_105 Z_106 H_2 C_5 Z_107 K_3 
Stack 4
G_4 Z_108 N_8 M_0 L_3 I_10 
Stack 5
G_0 C_0 H_8 O_7 Z_109 L_0 
Stack 6
S_2 Z_110 P_5 Z_111 D_3 E_1 
Stack 7
R_3 K_7 M_7 A_0 E_0 I_9 
Stack 8
D_1 G_5 D_2 N_1 R_0 Z_112 
Stack 9
C_1 F_3 H_6 H_3 B_0 H_9 
Stack 10
N_0 B_4 S_3 O_3 L_1 
Stack 11
C_6 K_5 Z_113 O_4 H_10 
Stack 12
E_7 Z_114 Z_115 Z_116 B_3 
Stack 13
D_0 N_2 F_1 L_7 R_1 
Stack 14
Z_117 F_6 M_3 Z_118 Z_119 
Stack 15
E_3 Q_3 N_5 A_3 A_1 
Stack 16
Z_120 J_6 E_4 O_2 I_6 
Stack 17
F_5 F_0 C_3 H_7 N_4 
Stack 18
N_3 C_4 E_5 Z_121 J_5 
Stack 19
J_4 Z_122 Z_123 J_3 D_4 
Stack 20
Z_124 Z_125 L_9 M_2 L_4 
Stack 21
I_2 M_5 P_7 J_0 I_0 
Stack 22
Z_126 L_8 Z_127 Z_128 I_5 
Stack 23
M_6 Z_129 Q_2 Z_130 P_0 
Stack 24
I_1 R_4 K_1 G_8 G_2 
Stack 25
Z_131 N_6 Z_132 O_1 G_6 
Stack 26
G_1 Z_133 L_2 G_3 I_7 
Stack 27
B_1 P_4 K_4 L_6 D_5 
Stack 28
T_3 J_10 J_7 Z_134 J_9 
Stack 29
C_2 I_3 M_8 A_2 F_4 
Stack 30
J_8 G_7 Q_0 J_12 B_2 
Stack 31
R_2 I_8 O_6 Z_135 I_4 
Stack 32
J_2 K_6 K_0 P_3 Q_1 
Stack 33
H_4 T_1 O_0 O_5 J_11 
Stack 34
I_11 H_5 Z_136 P_2 Z_137 
Stack 35
K_2 P_1 E_6 S_1 L_5 
