Number Of Containers
150
Number Of Yard Stacks
38
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
120
Number Of Shutout Containers
30
Yard Bay
Stack 0
M_3 F_3 Z_100 Q_1 
Stack 1
G_0 I_1 Z_101 Z_102 
Stack 2
F_4 J_4 Z_103 G_6 
Stack 3
I_7 A_0 Z_104 I_5 
Stack 4
K_1 B_0 J_1 F_6 
Stack 5
Z_105 G_2 M_1 N_0 
Stack 6
Z_106 Z_107 G_5 H_4 
Stack 7
P_0 K_4 S_2 T_1 
Stack 8
R_1 Z_108 H_2 J_0 
Stack 9
F_1 C_1 H_7 N_5 
Stack 10
I_2 N_3 L_3 A_2 
Stack 11
J_2 L_1 A_1 L_2 
Stack 12
S_0 E_2 I_0 K_0 
Stack 13
Z_109 Z_110 Z_111 Z_112 
Stack 14
D_0 Z_113 O_1 M_7 
Stack 15
H_8 G_4 O_0 K_6 
Stack 16
F_5 Q_0 R_2 M_4 
Stack 17
E_3 L_9 M_5 L_10 
Stack 18
N_4 I_6 S_3 F_0 
Stack 19
E_4 D_2 D_1 H_3 
Stack 20
Z_114 R_3 H_6 I_9 
Stack 21
O_5 N_2 L_6 N_1 
Stack 22
I_8 M_0 Z_115 I_4 
Stack 23
O_2 J_3 L_8 S_1 
Stack 24
Z_116 E_5 G_1 L_7 
Stack 25
J_6 M_2 H_0 I_3 
Stack 26
Z_117 H_1 L_0 T_0 
Stack 27
G_7 C_0 Z_118 L_5 
Stack 28
K_5 J_5 E_0 F_2 
Stack 29
P_2 E_1 Z_119 M_6 
Stack 30
K_8 R_0 O_3 Z_120 
Stack 31
Q_3 J_7 Z_121 Q_4 
Stack 32
Z_122 G_3 K_9 K_7 
Stack 33
P_3 Q_2 K_3 C_2 
Stack 34
Z_123 O_4 P_1 Z_124 
Stack 35
Z_125 Z_126 Z_127 Z_128 
Stack 36
D_3 H_9 Z_129 
Stack 37
H_5 K_2 L_4 
