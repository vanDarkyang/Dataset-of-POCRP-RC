Number Of Containers
29
Number Of Yard Stacks
8
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
23
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_3 A_3 C_1 B_4 
Stack 1
A_4 D_3 Z_100 A_2 
Stack 2
B_0 Z_101 E_4 D_2 
Stack 3
Z_102 E_3 Z_103 D_1 
Stack 4
Z_104 E_1 E_0 B_2 
Stack 5
B_1 C_0 Z_105 
Stack 6
B_5 A_1 C_2 
Stack 7
A_0 E_2 D_0 
