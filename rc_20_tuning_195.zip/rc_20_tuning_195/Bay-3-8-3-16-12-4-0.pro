Number Of Containers
16
Number Of Yard Stacks
3
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
12
Number Of Shutout Containers
4
Yard Bay
Stack 0
Z_100 C_3 C_2 B_2 C_0 A_3 
Stack 1
C_1 A_1 B_3 B_0 Z_101 
Stack 2
B_1 A_0 A_2 Z_102 Z_103 
