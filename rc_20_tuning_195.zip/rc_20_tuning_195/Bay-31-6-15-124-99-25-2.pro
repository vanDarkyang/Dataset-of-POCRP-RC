Number Of Containers
124
Number Of Yard Stacks
31
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
Z_100 Z_101 H_7 F_4 
Stack 1
A_0 Z_102 B_3 K_1 
Stack 2
Z_103 G_6 E_3 Z_104 
Stack 3
J_5 M_2 Z_105 Z_106 
Stack 4
F_1 I_0 F_0 I_6 
Stack 5
O_4 J_4 H_4 F_5 
Stack 6
E_5 Z_107 H_9 I_8 
Stack 7
I_5 L_5 G_9 D_1 
Stack 8
C_2 H_5 J_6 D_2 
Stack 9
E_4 G_4 F_3 B_0 
Stack 10
Z_108 E_1 M_5 F_6 
Stack 11
Z_109 Z_110 H_3 K_2 
Stack 12
O_1 K_3 C_1 Z_111 
Stack 13
G_0 J_0 G_7 H_10 
Stack 14
H_1 L_3 L_6 Z_112 
Stack 15
Z_113 I_7 H_0 E_0 
Stack 16
I_2 J_1 Z_114 B_2 
Stack 17
G_2 H_8 M_0 O_2 
Stack 18
I_1 C_0 O_0 Z_115 
Stack 19
N_0 D_5 Z_116 M_1 
Stack 20
G_3 G_1 L_0 H_6 
Stack 21
Z_117 J_2 E_2 Z_118 
Stack 22
Z_119 D_0 D_4 Z_120 
Stack 23
J_3 G_8 A_1 B_1 
Stack 24
F_7 Z_121 L_2 N_1 
Stack 25
Z_122 D_3 M_3 K_4 
Stack 26
Z_123 E_6 E_7 L_1 
Stack 27
I_4 E_8 F_2 C_4 
Stack 28
G_5 H_2 O_3 L_4 
Stack 29
K_0 D_6 A_2 Z_124 
Stack 30
M_4 C_3 I_3 I_9 
