Number Of Containers
390
Number Of Yard Stacks
98
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
312
Number Of Shutout Containers
78
Yard Bay
Stack 0
Z_100 P_11 Z_101 Z_102 
Stack 1
Z_103 G_5 Z_104 Z_105 
Stack 2
Q_3 Z_106 J_2 Z_107 
Stack 3
Q_5 Z_108 D_2 Z_109 
Stack 4
B_1 H_0 J_4 Z_110 
Stack 5
N_3 Z_111 E_9 O_10 
Stack 6
A_7 O_15 E_6 H_4 
Stack 7
Z_112 E_18 A_2 Z_113 
Stack 8
K_17 Z_114 K_0 N_15 
Stack 9
F_1 Z_115 F_9 Z_116 
Stack 10
B_7 C_14 Z_117 J_6 
Stack 11
E_5 O_4 A_9 T_1 
Stack 12
C_11 M_3 B_2 Z_118 
Stack 13
H_14 H_6 A_4 G_8 
Stack 14
G_3 R_8 M_8 Z_119 
Stack 15
K_5 D_11 M_6 L_13 
Stack 16
O_13 I_8 Z_120 Z_121 
Stack 17
S_1 I_19 J_17 O_7 
Stack 18
Z_122 C_12 E_17 S_7 
Stack 19
T_3 Z_123 E_13 Z_124 
Stack 20
I_13 J_5 R_0 E_0 
Stack 21
N_9 J_18 S_4 K_10 
Stack 22
N_14 A_8 I_21 R_4 
Stack 23
C_4 Z_125 Q_10 O_3 
Stack 24
H_1 P_14 N_7 L_2 
Stack 25
B_9 J_11 O_1 A_11 
Stack 26
J_7 P_10 Q_0 Z_126 
Stack 27
N_0 P_5 T_4 K_18 
Stack 28
Z_127 H_11 L_10 E_16 
Stack 29
D_9 L_8 J_1 Z_128 
Stack 30
C_1 N_4 S_10 A_1 
Stack 31
Z_129 P_0 Z_130 D_7 
Stack 32
K_6 Z_131 E_10 K_16 
Stack 33
I_4 E_2 Z_132 I_5 
Stack 34
Q_1 Z_133 O_12 K_19 
Stack 35
Z_134 S_3 J_12 H_17 
Stack 36
I_3 L_14 Q_4 Z_135 
Stack 37
Z_136 P_6 H_7 H_3 
Stack 38
Z_137 G_13 P_12 N_8 
Stack 39
N_12 E_15 H_8 F_11 
Stack 40
Z_138 N_11 Z_139 D_10 
Stack 41
M_14 Q_8 E_7 G_1 
Stack 42
B_6 K_8 C_13 I_6 
Stack 43
K_14 Z_140 D_4 D_13 
Stack 44
E_14 K_11 K_13 G_6 
Stack 45
M_11 O_16 L_18 R_7 
Stack 46
L_3 R_6 O_8 P_1 
Stack 47
D_12 O_0 T_5 G_2 
Stack 48
C_2 Z_141 M_4 F_8 
Stack 49
K_7 E_8 P_8 R_12 
Stack 50
L_19 Z_142 H_16 Z_143 
Stack 51
L_6 E_12 S_5 H_9 
Stack 52
C_5 Z_144 J_3 F_6 
Stack 53
Z_145 F_2 P_13 A_6 
Stack 54
G_11 J_15 M_0 J_0 
Stack 55
M_2 M_13 F_5 I_1 
Stack 56
F_3 Z_146 H_10 K_4 
Stack 57
L_17 Z_147 N_2 I_2 
Stack 58
Q_7 O_6 O_18 K_15 
Stack 59
F_4 A_10 Z_148 R_1 
Stack 60
L_11 Z_149 O_14 N_13 
Stack 61
J_14 G_9 Z_150 P_3 
Stack 62
Z_151 D_14 I_10 I_15 
Stack 63
Z_152 L_15 C_10 T_6 
Stack 64
A_0 L_1 D_0 R_9 
Stack 65
I_7 N_10 C_0 D_3 
Stack 66
E_3 H_2 D_1 Z_153 
Stack 67
S_9 L_12 T_0 H_12 
Stack 68
L_7 N_1 Z_154 M_7 
Stack 69
I_12 E_1 F_0 K_1 
Stack 70
J_10 Z_155 H_13 B_5 
Stack 71
I_17 M_1 Z_156 T_7 
Stack 72
G_10 L_0 C_9 Z_157 
Stack 73
G_7 H_15 L_16 K_3 
Stack 74
B_3 B_10 M_5 P_7 
Stack 75
Z_158 J_8 D_5 J_16 
Stack 76
G_0 L_4 R_2 I_16 
Stack 77
J_9 K_2 R_3 Z_159 
Stack 78
G_12 T_2 F_13 Z_160 
Stack 79
Z_161 F_7 Z_162 F_12 
Stack 80
H_5 J_13 S_8 B_8 
Stack 81
O_9 C_6 Z_163 R_10 
Stack 82
R_5 P_9 P_4 Z_164 
Stack 83
S_2 Z_165 C_3 Q_6 
Stack 84
N_6 Z_166 O_5 I_18 
Stack 85
Z_167 B_4 A_12 Z_168 
Stack 86
E_4 E_11 Z_169 R_11 
Stack 87
O_2 I_0 K_12 Q_9 
Stack 88
I_20 N_5 K_9 L_9 
Stack 89
N_17 A_3 Z_170 S_0 
Stack 90
M_12 M_10 Z_171 C_7 
Stack 91
O_17 Z_172 Z_173 I_11 
Stack 92
G_4 Q_2 Q_11 P_2 
Stack 93
Z_174 I_14 D_6 N_16 
Stack 94
Z_175 C_8 F_10 S_6 
Stack 95
M_15 I_9 Z_176 A_5 
Stack 96
M_9 L_5 Z_177 
Stack 97
D_8 O_11 B_0 
