Number Of Containers
29
Number Of Yard Stacks
8
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
23
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_3 B_4 Z_100 C_6 
Stack 1
B_0 B_1 A_0 D_0 
Stack 2
C_2 D_1 C_0 Z_101 
Stack 3
C_3 A_1 C_5 E_0 
Stack 4
Z_102 B_2 A_2 D_2 
Stack 5
Z_103 C_1 C_4 
Stack 6
B_5 Z_104 D_3 
Stack 7
E_2 E_1 Z_105 
