Number Of Containers
124
Number Of Yard Stacks
31
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
A_1 Z_100 K_2 A_0 
Stack 1
N_3 I_3 D_5 G_6 
Stack 2
Z_101 B_0 C_3 J_7 
Stack 3
Z_102 F_3 Z_103 N_5 
Stack 4
Z_104 Z_105 I_7 I_1 
Stack 5
H_7 O_1 D_4 G_2 
Stack 6
D_0 F_5 G_3 Z_106 
Stack 7
Z_107 F_1 K_1 A_3 
Stack 8
C_2 C_0 A_2 F_6 
Stack 9
B_2 Z_108 J_3 E_1 
Stack 10
J_6 G_1 O_2 L_4 
Stack 11
E_3 D_3 M_1 Z_109 
Stack 12
H_1 K_4 I_10 Z_110 
Stack 13
H_9 H_2 M_2 C_1 
Stack 14
F_0 H_5 L_0 Z_111 
Stack 15
C_6 L_2 F_2 Z_112 
Stack 16
Z_113 J_0 B_4 N_0 
Stack 17
K_0 E_0 O_3 G_7 
Stack 18
G_0 N_4 G_5 N_1 
Stack 19
C_4 I_2 A_4 D_1 
Stack 20
E_2 Z_114 M_0 I_6 
Stack 21
I_9 J_8 I_0 K_5 
Stack 22
J_1 L_1 M_3 J_2 
Stack 23
N_2 D_2 J_4 Z_115 
Stack 24
H_4 K_6 K_3 C_5 
Stack 25
J_5 H_6 Z_116 G_4 
Stack 26
O_0 H_8 L_3 I_4 
Stack 27
I_8 Z_117 O_4 Z_118 
Stack 28
Z_119 B_1 Z_120 H_3 
Stack 29
Z_121 H_0 B_3 Z_122 
Stack 30
F_4 Z_123 Z_124 I_5 
