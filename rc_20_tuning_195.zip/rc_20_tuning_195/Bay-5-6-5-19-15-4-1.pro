Number Of Containers
19
Number Of Yard Stacks
5
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
15
Number Of Shutout Containers
4
Yard Bay
Stack 0
A_0 C_2 D_2 B_1 
Stack 1
C_4 D_1 Z_100 Z_101 
Stack 2
Z_102 C_3 C_0 B_0 
Stack 3
C_1 E_1 A_1 D_0 
Stack 4
E_0 Z_103 E_2 
