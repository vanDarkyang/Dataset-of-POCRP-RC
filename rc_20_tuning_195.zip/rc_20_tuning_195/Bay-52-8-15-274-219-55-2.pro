Number Of Containers
274
Number Of Yard Stacks
52
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
219
Number Of Shutout Containers
55
Yard Bay
Stack 0
H_3 N_5 Z_100 I_17 K_0 Z_101 
Stack 1
A_5 H_6 L_11 N_0 L_10 G_10 
Stack 2
H_8 Z_102 N_11 A_4 G_11 I_10 
Stack 3
G_4 J_13 H_11 G_1 Z_103 C_7 
Stack 4
G_16 M_8 Z_104 Z_105 Z_106 I_16 
Stack 5
I_8 B_8 L_7 Z_107 Z_108 G_17 
Stack 6
Z_109 B_0 O_2 G_15 K_7 E_6 
Stack 7
K_12 F_13 M_2 F_3 N_13 L_2 
Stack 8
F_14 H_10 O_10 O_9 N_3 D_6 
Stack 9
B_4 Z_110 J_8 Z_111 B_7 A_7 
Stack 10
E_2 Z_112 Z_113 Z_114 M_10 G_5 
Stack 11
M_6 G_0 Z_115 Z_116 M_3 M_11 
Stack 12
D_9 N_7 A_0 H_9 I_14 B_1 
Stack 13
A_9 H_12 Z_117 L_0 E_0 G_3 
Stack 14
G_7 A_13 L_5 J_4 A_10 
Stack 15
Z_118 M_1 Z_119 B_6 H_17 
Stack 16
Z_120 O_7 H_14 G_2 N_1 
Stack 17
C_11 Z_121 I_5 A_2 E_5 
Stack 18
A_3 K_10 C_6 K_3 Z_122 
Stack 19
J_11 O_8 K_1 Z_123 E_4 
Stack 20
F_11 K_9 H_16 E_12 A_1 
Stack 21
N_9 Z_124 C_10 J_10 Z_125 
Stack 22
D_7 L_12 A_8 I_18 Z_126 
Stack 23
I_7 F_12 J_6 Z_127 F_0 
Stack 24
B_12 H_4 Z_128 N_8 B_5 
Stack 25
K_4 K_5 D_5 Z_129 O_6 
Stack 26
D_11 C_1 Z_130 K_6 B_2 
Stack 27
J_0 D_8 Z_131 C_5 K_2 
Stack 28
L_9 Z_132 O_0 K_8 H_5 
Stack 29
G_6 M_5 Z_133 Z_134 H_0 
Stack 30
I_2 N_15 A_11 I_12 C_4 
Stack 31
E_3 F_8 C_0 Z_135 F_10 
Stack 32
I_6 B_3 J_14 F_4 H_1 
Stack 33
H_2 B_10 N_12 E_1 Z_136 
Stack 34
D_4 J_9 L_1 M_7 C_9 
Stack 35
I_13 A_12 D_2 Z_137 N_4 
Stack 36
Z_138 Z_139 F_1 G_8 O_4 
Stack 37
B_9 Z_140 I_4 N_10 L_3 
Stack 38
F_5 I_11 D_1 J_7 D_12 
Stack 39
I_15 O_3 J_1 L_4 Z_141 
Stack 40
Z_142 C_2 A_6 F_2 F_9 
Stack 41
G_13 H_15 Z_143 Z_144 K_11 
Stack 42
D_10 J_15 G_9 J_2 E_10 
Stack 43
N_6 M_0 Z_145 M_9 I_3 
Stack 44
F_16 G_14 L_8 F_15 H_7 
Stack 45
M_4 L_6 G_12 O_1 Z_146 
Stack 46
Z_147 Z_148 I_9 Z_149 J_12 
Stack 47
K_13 O_5 N_14 B_11 E_8 
Stack 48
H_13 D_0 J_3 Z_150 Z_151 
Stack 49
C_3 E_7 I_0 D_3 Z_152 
Stack 50
Z_153 Z_154 F_7 J_5 E_11 
Stack 51
N_2 C_8 F_6 E_9 I_1 
