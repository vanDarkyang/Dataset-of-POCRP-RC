Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 L_2 G_2 Z_101 G_0 I_4 
Stack 1
C_1 H_1 B_1 J_5 Z_102 K_0 
Stack 2
J_1 H_0 A_1 N_3 G_1 H_7 
Stack 3
Z_103 K_3 E_4 Z_104 C_3 L_1 
Stack 4
O_0 F_1 M_3 D_2 Z_105 
Stack 5
E_0 F_0 A_2 L_4 Z_106 
Stack 6
G_5 F_2 G_4 I_3 H_6 
Stack 7
M_0 D_3 C_2 J_6 A_0 
Stack 8
Z_107 E_1 I_0 M_4 Z_108 
Stack 9
Z_109 Z_110 Z_111 Z_112 Z_113 
Stack 10
K_2 Z_114 D_0 L_3 N_2 
Stack 11
H_5 H_8 G_6 Z_115 B_0 
Stack 12
D_4 J_4 Z_116 M_2 E_3 
Stack 13
M_1 I_2 K_1 Z_117 G_3 
Stack 14
G_7 C_0 J_2 D_1 F_3 
Stack 15
Z_118 L_0 J_3 K_4 N_1 
Stack 16
F_4 H_2 H_3 E_2 I_5 
Stack 17
I_1 H_4 F_5 N_0 J_0 
