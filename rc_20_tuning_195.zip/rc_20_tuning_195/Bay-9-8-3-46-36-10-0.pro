Number Of Containers
46
Number Of Yard Stacks
9
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_3 C_6 A_0 C_12 C_1 C_9 
Stack 1
A_4 C_0 B_9 Z_100 B_6 
Stack 2
Z_101 B_4 C_13 B_5 C_2 
Stack 3
Z_102 A_2 B_10 B_2 Z_103 
Stack 4
C_4 B_8 A_1 C_11 C_10 
Stack 5
A_3 Z_104 A_7 Z_105 B_1 
Stack 6
Z_106 C_3 A_6 Z_107 C_7 
Stack 7
C_5 A_10 A_5 B_7 Z_108 
Stack 8
A_9 B_0 C_8 A_8 Z_109 
