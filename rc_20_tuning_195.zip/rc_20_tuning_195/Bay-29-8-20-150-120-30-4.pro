Number Of Containers
150
Number Of Yard Stacks
29
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
120
Number Of Shutout Containers
30
Yard Bay
Stack 0
Z_100 S_0 O_3 K_0 N_1 J_2 
Stack 1
H_3 I_9 Z_101 K_1 Q_4 G_5 
Stack 2
J_1 Z_102 I_1 Z_103 G_4 B_0 
Stack 3
N_0 E_0 D_2 H_1 Z_104 G_2 
Stack 4
N_7 Z_105 N_2 A_1 G_6 K_5 
Stack 5
Q_0 M_1 R_0 O_5 R_2 
Stack 6
M_4 B_2 D_1 N_3 O_2 
Stack 7
H_5 R_3 L_0 T_0 J_4 
Stack 8
I_5 E_4 I_0 L_5 C_0 
Stack 9
G_0 L_1 Z_106 Z_107 K_7 
Stack 10
Z_108 Z_109 M_2 K_2 Z_110 
Stack 11
Z_111 K_3 Q_3 O_4 G_1 
Stack 12
J_5 H_0 J_3 P_0 Q_1 
Stack 13
L_6 L_7 K_6 E_2 Z_112 
Stack 14
L_3 Q_2 I_6 Z_113 P_5 
Stack 15
F_4 J_7 L_2 Z_114 O_0 
Stack 16
Z_115 F_3 Z_116 H_4 P_1 
Stack 17
S_2 Z_117 Z_118 M_6 N_5 
Stack 18
F_1 A_0 C_1 Z_119 I_8 
Stack 19
B_1 I_2 R_1 M_3 H_2 
Stack 20
L_8 L_4 P_4 E_1 K_10 
Stack 21
Z_120 K_8 D_3 F_0 Z_121 
Stack 22
I_10 M_0 D_4 C_2 Z_122 
Stack 23
Z_123 J_6 I_3 B_3 Z_124 
Stack 24
D_0 J_0 H_6 N_4 P_3 
Stack 25
P_2 E_3 K_9 F_5 S_1 
Stack 26
G_3 M_5 I_7 Z_125 A_2 
Stack 27
G_7 O_1 N_6 F_2 K_4 
Stack 28
Z_126 I_4 Z_127 Z_128 Z_129 
