Number Of Containers
190
Number Of Yard Stacks
48
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
152
Number Of Shutout Containers
38
Yard Bay
Stack 0
K_2 Z_100 S_4 F_7 
Stack 1
G_1 I_4 K_10 L_9 
Stack 2
H_10 H_5 L_3 D_5 
Stack 3
T_1 G_8 C_1 F_3 
Stack 4
F_6 Z_101 M_1 P_0 
Stack 5
Z_102 J_4 O_3 R_0 
Stack 6
E_0 H_7 A_2 D_1 
Stack 7
M_6 K_8 L_4 E_5 
Stack 8
Z_103 Z_104 T_2 J_1 
Stack 9
Z_105 Z_106 Z_107 D_4 
Stack 10
I_2 Z_108 N_2 O_5 
Stack 11
H_2 E_4 N_5 J_7 
Stack 12
F_1 F_5 Z_109 Z_110 
Stack 13
L_5 H_9 N_6 F_4 
Stack 14
J_0 L_2 J_10 Z_111 
Stack 15
S_2 K_3 K_7 M_2 
Stack 16
L_6 L_0 I_6 F_0 
Stack 17
G_4 P_7 E_7 Z_112 
Stack 18
P_1 L_8 N_1 H_0 
Stack 19
M_4 K_4 Z_113 K_1 
Stack 20
P_3 Z_114 Z_115 R_3 
Stack 21
M_0 Z_116 I_0 S_0 
Stack 22
H_8 I_7 K_6 Z_117 
Stack 23
E_1 H_1 Z_118 D_3 
Stack 24
J_9 I_9 C_0 M_7 
Stack 25
Z_119 I_5 Z_120 K_5 
Stack 26
H_4 Z_121 S_1 Z_122 
Stack 27
H_3 O_1 L_7 O_2 
Stack 28
P_6 P_4 E_6 R_1 
Stack 29
T_0 O_0 A_3 G_6 
Stack 30
A_1 D_0 Z_123 Z_124 
Stack 31
O_4 K_0 J_5 G_7 
Stack 32
N_7 J_3 Z_125 Z_126 
Stack 33
B_3 F_2 Q_3 B_0 
Stack 34
C_3 A_0 D_2 M_3 
Stack 35
Q_0 N_4 I_1 G_0 
Stack 36
N_0 Z_127 E_3 I_8 
Stack 37
K_9 J_2 Q_2 R_2 
Stack 38
J_6 P_5 C_2 G_2 
Stack 39
Z_128 Q_4 L_1 Z_129 
Stack 40
Z_130 Z_131 P_2 Z_132 
Stack 41
M_5 F_8 H_6 N_8 
Stack 42
Z_133 S_3 K_11 H_11 
Stack 43
T_4 B_2 N_3 Z_134 
Stack 44
Q_1 B_1 G_3 J_8 
Stack 45
G_5 E_2 Z_135 Z_136 
Stack 46
L_10 T_3 Z_137 
Stack 47
I_3 M_8 I_10 
