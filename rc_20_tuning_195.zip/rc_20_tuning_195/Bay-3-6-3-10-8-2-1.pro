Number Of Containers
10
Number Of Yard Stacks
3
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
8
Number Of Shutout Containers
2
Yard Bay
Stack 0
A_1 A_2 Z_100 B_1 
Stack 1
C_1 A_0 B_0 
Stack 2
B_2 Z_101 C_0 
