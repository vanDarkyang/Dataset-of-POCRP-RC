Number Of Containers
190
Number Of Yard Stacks
36
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
152
Number Of Shutout Containers
38
Yard Bay
Stack 0
G_2 Z_100 Z_101 Z_102 Z_103 S_1 
Stack 1
J_8 M_3 Z_104 M_1 B_0 O_4 
Stack 2
Z_105 N_6 B_3 J_10 N_3 Q_1 
Stack 3
B_5 A_3 H_3 S_2 Q_5 C_0 
Stack 4
L_3 Z_106 H_2 B_1 G_0 O_3 
Stack 5
J_1 A_2 H_4 Z_107 A_0 P_2 
Stack 6
H_1 Q_2 I_7 L_9 O_1 Q_6 
Stack 7
I_5 Z_108 Z_109 K_5 L_0 Z_110 
Stack 8
K_7 C_2 L_2 K_9 N_9 O_6 
Stack 9
N_7 D_1 B_2 M_2 O_7 Z_111 
Stack 10
Z_112 P_5 T_3 M_8 E_0 
Stack 11
D_0 L_4 H_5 I_1 I_0 
Stack 12
Z_113 Z_114 Z_115 N_4 T_1 
Stack 13
N_8 K_3 Z_116 Q_0 P_3 
Stack 14
N_0 M_5 G_6 J_2 I_3 
Stack 15
L_6 Z_117 Q_4 H_0 M_0 
Stack 16
C_6 I_2 R_0 J_0 N_5 
Stack 17
P_1 G_4 L_7 E_1 Z_118 
Stack 18
G_3 C_1 Z_119 Z_120 O_2 
Stack 19
D_4 K_6 M_6 T_0 I_6 
Stack 20
K_0 J_4 L_10 O_0 M_7 
Stack 21
Z_121 K_4 Z_122 Z_123 F_3 
Stack 22
J_11 S_3 T_2 L_5 I_8 
Stack 23
M_4 C_3 J_7 K_2 N_10 
Stack 24
Z_124 Q_3 D_2 Z_125 E_3 
Stack 25
L_8 C_5 N_1 B_4 N_2 
Stack 26
G_1 I_4 H_6 R_4 Z_126 
Stack 27
Z_127 Z_128 Z_129 D_6 P_0 
Stack 28
H_7 M_9 L_1 Z_130 F_2 
Stack 29
E_2 F_0 J_12 A_1 R_2 
Stack 30
J_6 H_8 I_9 H_9 K_8 
Stack 31
K_1 D_5 J_9 R_1 S_0 
Stack 32
F_4 F_1 R_3 J_5 L_11 
Stack 33
Z_131 P_4 Z_132 Z_133 G_5 
Stack 34
J_3 Z_134 O_5 Z_135 Z_136 
Stack 35
C_4 R_5 Z_137 I_10 D_3 
