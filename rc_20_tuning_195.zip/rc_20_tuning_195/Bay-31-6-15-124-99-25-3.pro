Number Of Containers
124
Number Of Yard Stacks
31
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
G_7 F_7 Z_100 Z_101 
Stack 1
A_2 Z_102 Z_103 E_1 
Stack 2
G_9 M_0 J_6 E_8 
Stack 3
B_3 C_0 O_0 N_5 
Stack 4
G_5 J_3 C_1 M_2 
Stack 5
Z_104 K_1 E_0 M_3 
Stack 6
G_3 L_1 Z_105 Z_106 
Stack 7
H_2 G_4 F_2 Z_107 
Stack 8
B_5 A_1 Z_108 C_2 
Stack 9
N_2 H_5 K_3 E_6 
Stack 10
I_4 D_1 Z_109 H_0 
Stack 11
B_4 Z_110 C_4 Z_111 
Stack 12
F_3 C_3 F_1 B_0 
Stack 13
E_5 H_3 B_1 J_2 
Stack 14
M_1 Z_112 I_1 M_4 
Stack 15
Z_113 J_4 Z_114 D_6 
Stack 16
I_7 I_9 D_5 O_2 
Stack 17
N_0 Z_115 B_2 F_6 
Stack 18
A_3 E_2 J_5 D_0 
Stack 19
G_0 I_8 G_2 G_6 
Stack 20
N_4 H_1 Z_116 Z_117 
Stack 21
K_0 F_0 I_6 I_0 
Stack 22
I_3 J_0 Z_118 N_3 
Stack 23
D_3 K_4 O_1 K_2 
Stack 24
E_3 Z_119 D_2 Z_120 
Stack 25
F_8 L_4 J_7 L_3 
Stack 26
E_4 L_2 F_4 Z_121 
Stack 27
Z_122 G_8 H_4 L_0 
Stack 28
G_1 I_2 E_7 F_5 
Stack 29
Z_123 N_1 I_5 M_5 
Stack 30
D_4 J_1 Z_124 A_0 
