Number Of Containers
290
Number Of Yard Stacks
55
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
232
Number Of Shutout Containers
58
Yard Bay
Stack 0
Z_100 Z_101 Z_102 B_3 B_4 D_5 
Stack 1
C_1 P_6 M_11 Z_103 Q_3 Z_104 
Stack 2
Z_105 Z_106 K_1 A_6 J_6 E_7 
Stack 3
K_6 Z_107 H_3 Z_108 I_2 B_5 
Stack 4
L_10 I_0 J_5 Q_6 B_8 O_1 
Stack 5
A_4 E_8 O_3 H_8 P_5 R_4 
Stack 6
Z_109 Z_110 J_11 R_9 P_8 L_7 
Stack 7
I_13 S_6 Z_111 E_5 Z_112 Q_5 
Stack 8
K_0 Z_113 I_9 K_12 H_6 M_13 
Stack 9
L_8 L_9 B_2 Z_114 Z_115 Q_8 
Stack 10
Z_116 P_2 M_4 O_10 L_4 Z_117 
Stack 11
Q_4 F_9 Z_118 P_1 I_8 P_7 
Stack 12
H_5 Q_7 S_8 Z_119 Z_120 Z_121 
Stack 13
Z_122 Z_123 I_7 M_9 G_14 M_3 
Stack 14
Z_124 C_10 L_5 Q_2 G_8 I_4 
Stack 15
R_7 C_0 D_4 G_7 K_10 
Stack 16
O_9 Z_125 Z_126 P_3 L_12 
Stack 17
Z_127 Z_128 Z_129 Z_130 B_10 
Stack 18
J_12 F_10 B_0 Z_131 D_11 
Stack 19
I_11 G_5 A_8 C_8 Z_132 
Stack 20
H_0 G_2 Z_133 D_3 Z_134 
Stack 21
N_1 I_1 K_9 S_1 E_6 
Stack 22
O_2 Z_135 C_3 R_6 O_6 
Stack 23
T_6 K_4 K_2 Q_0 H_9 
Stack 24
G_1 Z_136 Z_137 S_7 G_13 
Stack 25
Z_138 N_8 Z_139 A_3 L_13 
Stack 26
B_9 J_2 Z_140 I_6 F_7 
Stack 27
B_6 T_0 J_10 J_8 J_1 
Stack 28
J_9 S_3 B_1 F_5 O_8 
Stack 29
A_7 M_8 Z_141 Z_142 P_0 
Stack 30
R_3 M_5 K_8 F_4 Z_143 
Stack 31
L_0 S_5 I_5 K_14 R_5 
Stack 32
Z_144 Z_145 F_0 L_1 E_9 
Stack 33
A_1 N_0 M_0 R_2 T_4 
Stack 34
G_4 N_4 D_1 H_2 K_11 
Stack 35
K_5 R_8 E_0 H_1 M_7 
Stack 36
G_6 H_4 N_3 N_10 D_6 
Stack 37
Z_146 Z_147 Z_148 I_10 J_7 
Stack 38
I_3 Q_1 G_0 O_5 Z_149 
Stack 39
E_10 L_3 Z_150 C_2 I_12 
Stack 40
N_7 A_0 Z_151 M_12 F_1 
Stack 41
B_7 N_12 J_4 D_7 T_3 
Stack 42
G_11 D_8 S_4 S_2 A_2 
Stack 43
L_6 R_1 T_1 C_7 S_0 
Stack 44
H_7 M_1 J_0 Z_152 C_6 
Stack 45
Z_153 N_5 E_2 G_12 C_5 
Stack 46
D_9 J_3 T_2 P_4 T_5 
Stack 47
N_2 D_2 G_9 M_6 F_11 
Stack 48
C_4 O_0 N_6 H_10 K_3 
Stack 49
L_2 G_10 L_15 Z_154 F_3 
Stack 50
K_13 C_9 L_14 F_6 L_11 
Stack 51
O_4 N_9 Z_155 N_11 D_10 
Stack 52
M_2 F_8 E_1 D_0 Z_156 
Stack 53
E_3 O_7 R_0 K_7 M_10 
Stack 54
G_3 Z_157 A_5 E_4 F_2 
