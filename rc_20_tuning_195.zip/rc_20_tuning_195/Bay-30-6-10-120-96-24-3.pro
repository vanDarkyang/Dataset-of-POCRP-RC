Number Of Containers
120
Number Of Yard Stacks
30
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 Z_101 D_7 Z_102 
Stack 1
B_1 A_0 C_6 F_11 
Stack 2
Z_103 J_4 Z_104 F_1 
Stack 3
Z_105 D_9 Z_106 E_2 
Stack 4
I_7 F_8 B_5 G_1 
Stack 5
D_8 D_10 E_0 Z_107 
Stack 6
B_8 H_4 C_4 Z_108 
Stack 7
D_0 J_6 H_7 Z_109 
Stack 8
E_8 F_0 B_9 Z_110 
Stack 9
B_4 I_1 B_6 Z_111 
Stack 10
J_0 G_3 G_2 F_5 
Stack 11
F_2 I_9 Z_112 J_1 
Stack 12
E_6 I_6 G_0 F_6 
Stack 13
I_0 F_9 E_4 H_6 
Stack 14
I_5 Z_113 B_0 F_7 
Stack 15
I_3 E_3 Z_114 D_6 
Stack 16
Z_115 D_11 E_9 A_6 
Stack 17
J_2 H_8 Z_116 G_5 
Stack 18
Z_117 G_4 H_0 B_2 
Stack 19
Z_118 A_2 A_1 C_5 
Stack 20
J_5 E_1 B_7 H_3 
Stack 21
H_5 E_5 J_3 C_3 
Stack 22
I_4 C_7 G_6 G_7 
Stack 23
D_3 H_1 A_3 H_2 
Stack 24
Z_119 I_2 A_4 Z_120 
Stack 25
A_5 Z_121 E_7 B_3 
Stack 26
C_0 D_2 G_9 Z_122 
Stack 27
F_3 C_2 Z_123 C_1 
Stack 28
D_1 C_8 F_10 D_4 
Stack 29
D_5 I_8 F_4 G_8 
