Number Of Containers
124
Number Of Yard Stacks
31
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
Z_100 J_2 H_2 L_4 
Stack 1
E_5 Z_101 M_4 Z_102 
Stack 2
Z_103 M_6 Z_104 F_4 
Stack 3
Z_105 I_1 D_5 Z_106 
Stack 4
O_2 O_3 E_1 E_6 
Stack 5
B_0 O_4 N_3 Z_107 
Stack 6
H_1 K_3 I_2 A_3 
Stack 7
N_2 G_6 F_1 Z_108 
Stack 8
K_7 F_5 J_4 O_0 
Stack 9
L_1 C_0 K_5 H_6 
Stack 10
A_0 Z_109 Z_110 I_8 
Stack 11
K_0 N_5 H_3 M_5 
Stack 12
Z_111 Z_112 L_5 M_3 
Stack 13
D_0 I_5 J_3 A_2 
Stack 14
I_6 B_2 Z_113 I_9 
Stack 15
B_3 M_2 D_6 K_6 
Stack 16
Z_114 H_0 A_1 C_1 
Stack 17
F_2 F_0 K_2 N_4 
Stack 18
Z_115 K_4 B_4 E_4 
Stack 19
Z_116 M_0 E_2 G_0 
Stack 20
C_2 J_1 I_0 J_6 
Stack 21
M_1 L_3 Z_117 D_3 
Stack 22
E_3 Z_118 D_1 I_4 
Stack 23
G_1 Z_119 B_1 F_6 
Stack 24
L_2 C_3 I_7 D_4 
Stack 25
L_0 I_3 N_1 H_4 
Stack 26
K_1 Z_120 G_4 J_5 
Stack 27
G_2 N_0 B_5 F_3 
Stack 28
G_7 Z_121 G_5 G_3 
Stack 29
Z_122 J_0 Z_123 O_1 
Stack 30
Z_124 D_2 H_5 E_0 
