Number Of Containers
10
Number Of Yard Stacks
3
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
8
Number Of Shutout Containers
2
Yard Bay
Stack 0
A_0 B_0 B_1 C_2 
Stack 1
A_1 Z_100 C_1 
Stack 2
Z_101 B_2 C_0 
