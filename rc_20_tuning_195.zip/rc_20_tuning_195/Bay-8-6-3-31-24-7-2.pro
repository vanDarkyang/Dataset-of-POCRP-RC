Number Of Containers
31
Number Of Yard Stacks
8
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
24
Number Of Shutout Containers
7
Yard Bay
Stack 0
A_0 B_5 B_3 C_3 
Stack 1
B_7 A_2 Z_100 A_1 
Stack 2
A_6 C_4 Z_101 A_3 
Stack 3
Z_102 B_8 C_2 C_1 
Stack 4
B_0 B_4 Z_103 A_5 
Stack 5
B_2 C_0 B_1 Z_104 
Stack 6
B_6 C_6 Z_105 A_7 
Stack 7
C_5 Z_106 A_4 
