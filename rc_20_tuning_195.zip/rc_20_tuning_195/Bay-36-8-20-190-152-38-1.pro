Number Of Containers
190
Number Of Yard Stacks
36
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
152
Number Of Shutout Containers
38
Yard Bay
Stack 0
M_9 L_5 Z_100 E_7 Z_101 P_2 
Stack 1
P_5 K_2 P_1 G_2 N_5 Z_102 
Stack 2
O_2 O_8 Z_103 G_5 S_3 Z_104 
Stack 3
I_6 D_6 G_1 R_5 H_1 P_0 
Stack 4
Z_105 O_1 G_7 Q_1 H_3 O_0 
Stack 5
B_3 Z_106 E_3 L_8 Z_107 O_3 
Stack 6
D_0 Z_108 M_2 T_4 M_6 P_7 
Stack 7
Z_109 D_4 I_8 P_6 C_4 N_4 
Stack 8
C_3 T_2 K_3 M_8 M_3 R_0 
Stack 9
A_2 D_2 Z_110 Z_111 Z_112 M_7 
Stack 10
H_0 M_5 O_5 Z_113 Z_114 
Stack 11
Z_115 I_1 C_0 D_1 H_4 
Stack 12
B_1 Z_116 A_1 S_0 M_0 
Stack 13
F_6 K_6 G_6 I_2 R_1 
Stack 14
L_2 J_6 J_5 T_1 K_9 
Stack 15
E_1 Z_117 Z_118 F_2 N_1 
Stack 16
R_2 E_0 I_0 A_0 K_10 
Stack 17
Z_119 Z_120 Z_121 N_0 Z_122 
Stack 18
Z_123 K_5 K_4 H_7 B_2 
Stack 19
Q_0 J_1 L_9 I_5 S_1 
Stack 20
K_0 Q_2 F_4 D_5 I_7 
Stack 21
Z_124 P_4 O_6 Z_125 H_5 
Stack 22
H_2 Q_3 Z_126 G_3 B_4 
Stack 23
J_8 J_3 F_5 S_2 P_3 
Stack 24
E_4 K_8 Q_6 T_3 B_0 
Stack 25
L_0 L_7 L_6 N_3 Z_127 
Stack 26
L_4 M_10 G_0 C_1 G_4 
Stack 27
F_1 Z_128 Q_4 Z_129 I_3 
Stack 28
Z_130 N_6 L_3 T_0 N_2 
Stack 29
N_8 Z_131 A_3 J_7 C_2 
Stack 30
J_0 F_3 K_7 J_2 H_6 
Stack 31
E_5 R_3 J_4 P_8 K_1 
Stack 32
Z_132 Z_133 C_5 Q_5 O_4 
Stack 33
M_4 Z_134 Z_135 E_6 Z_136 
Stack 34
O_7 F_0 M_1 Z_137 E_2 
Stack 35
L_1 N_7 R_4 I_4 D_3 
