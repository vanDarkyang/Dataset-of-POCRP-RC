Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_7 A_2 Z_100 A_4 
Stack 1
B_0 B_11 Z_101 Z_102 
Stack 2
A_5 C_1 C_6 Z_103 
Stack 3
C_0 A_7 A_9 Z_104 
Stack 4
A_8 B_3 C_2 Z_105 
Stack 5
A_0 C_3 Z_106 A_6 
Stack 6
B_12 C_10 B_4 B_1 
Stack 7
B_5 C_4 B_9 Z_107 
Stack 8
B_2 B_6 C_9 B_13 
Stack 9
B_8 Z_108 C_8 A_1 
Stack 10
A_3 B_10 C_7 
Stack 11
Z_109 C_5 B_14 
