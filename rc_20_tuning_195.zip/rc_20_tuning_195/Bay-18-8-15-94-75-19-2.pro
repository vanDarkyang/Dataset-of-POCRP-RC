Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 L_5 K_1 Z_101 E_3 K_0 
Stack 1
C_2 G_4 K_3 F_4 L_3 B_2 
Stack 2
Z_102 Z_103 L_0 F_1 C_1 D_0 
Stack 3
E_4 I_1 D_4 L_2 H_1 Z_104 
Stack 4
C_0 Z_105 H_4 Z_106 H_3 
Stack 5
B_3 J_6 K_5 O_2 E_1 
Stack 6
H_5 N_2 K_4 G_3 F_0 
Stack 7
H_7 H_0 J_1 G_6 I_2 
Stack 8
Z_107 I_3 Z_108 L_4 F_2 
Stack 9
Z_109 E_0 E_2 D_1 J_7 
Stack 10
Z_110 Z_111 K_2 M_3 A_0 
Stack 11
Z_112 L_1 M_2 G_1 N_0 
Stack 12
Z_113 H_6 G_5 J_4 J_3 
Stack 13
Z_114 D_3 Z_115 B_0 G_2 
Stack 14
J_0 Z_116 M_0 J_2 N_3 
Stack 15
N_1 O_0 O_1 G_0 F_3 
Stack 16
D_2 H_2 J_5 M_1 I_0 
Stack 17
B_1 F_5 C_3 Z_117 Z_118 
