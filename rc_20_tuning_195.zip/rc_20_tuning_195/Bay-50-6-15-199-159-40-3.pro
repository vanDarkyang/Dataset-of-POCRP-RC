Number Of Containers
199
Number Of Yard Stacks
50
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
159
Number Of Shutout Containers
40
Yard Bay
Stack 0
Z_100 C_5 Z_101 M_5 
Stack 1
C_6 I_6 Z_102 Z_103 
Stack 2
J_9 H_3 E_9 L_1 
Stack 3
Z_104 M_7 Z_105 D_8 
Stack 4
G_8 F_4 G_7 J_0 
Stack 5
H_2 K_3 B_1 M_1 
Stack 6
H_8 K_1 C_1 N_2 
Stack 7
N_0 N_3 I_1 L_7 
Stack 8
E_2 I_7 L_2 I_8 
Stack 9
D_6 F_10 A_0 N_5 
Stack 10
F_9 I_0 K_9 D_5 
Stack 11
Z_106 H_9 M_6 L_10 
Stack 12
G_5 A_6 D_1 G_6 
Stack 13
I_3 J_1 Z_107 C_2 
Stack 14
Z_108 H_0 C_8 E_0 
Stack 15
Z_109 B_7 Z_110 J_10 
Stack 16
N_6 G_4 G_2 B_3 
Stack 17
H_5 G_11 H_6 Z_111 
Stack 18
G_9 F_6 D_4 K_6 
Stack 19
O_7 Z_112 Z_113 G_13 
Stack 20
H_1 A_3 E_7 Z_114 
Stack 21
I_9 Z_115 Z_116 A_9 
Stack 22
Z_117 K_0 C_4 O_3 
Stack 23
C_3 J_8 K_7 O_0 
Stack 24
O_5 A_4 Z_118 M_4 
Stack 25
E_4 O_1 F_7 L_9 
Stack 26
H_10 M_8 E_1 F_5 
Stack 27
A_2 Z_119 F_3 Z_120 
Stack 28
A_1 Z_121 K_2 Z_122 
Stack 29
Z_123 I_2 Z_124 H_11 
Stack 30
D_0 Z_125 O_4 L_0 
Stack 31
Z_126 Z_127 E_11 J_7 
Stack 32
D_2 B_6 Z_128 L_5 
Stack 33
K_8 E_8 B_4 Z_129 
Stack 34
B_0 D_9 J_4 K_5 
Stack 35
G_10 B_5 A_5 A_8 
Stack 36
B_2 I_4 F_8 J_6 
Stack 37
L_8 O_6 B_8 F_1 
Stack 38
L_4 Z_130 M_3 Z_131 
Stack 39
E_5 C_7 B_9 E_10 
Stack 40
K_4 Z_132 J_5 A_7 
Stack 41
Z_133 E_3 G_12 I_5 
Stack 42
E_6 C_0 N_7 Z_134 
Stack 43
Z_135 J_3 F_2 N_1 
Stack 44
M_2 F_0 N_8 G_1 
Stack 45
Z_136 H_7 Z_137 H_4 
Stack 46
L_3 N_4 D_10 D_7 
Stack 47
N_9 M_0 O_2 G_3 
Stack 48
D_3 L_6 Z_138 O_8 
Stack 49
G_0 J_2 Z_139 
