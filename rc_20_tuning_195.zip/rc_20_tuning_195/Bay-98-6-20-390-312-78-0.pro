Number Of Containers
390
Number Of Yard Stacks
98
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
312
Number Of Shutout Containers
78
Yard Bay
Stack 0
S_5 Q_8 C_0 Z_100 
Stack 1
J_12 N_0 F_13 Z_101 
Stack 2
Z_102 T_5 G_5 A_5 
Stack 3
L_16 Z_103 K_10 D_11 
Stack 4
F_1 F_9 Q_4 Z_104 
Stack 5
C_12 Z_105 Q_0 Z_106 
Stack 6
L_10 Z_107 T_7 I_17 
Stack 7
F_5 I_1 C_8 Z_108 
Stack 8
Q_12 C_7 D_12 P_12 
Stack 9
K_19 O_11 Z_109 B_7 
Stack 10
K_7 M_16 I_11 Z_110 
Stack 11
F_11 N_6 H_13 R_1 
Stack 12
G_11 B_12 K_6 S_7 
Stack 13
O_14 E_7 L_5 F_2 
Stack 14
K_17 J_1 E_12 B_0 
Stack 15
Q_2 L_3 Z_111 K_11 
Stack 16
L_7 H_12 B_2 J_0 
Stack 17
J_21 Z_112 Z_113 Z_114 
Stack 18
I_13 Z_115 H_15 Q_10 
Stack 19
K_3 Z_116 Z_117 S_3 
Stack 20
Z_118 M_15 M_7 Z_119 
Stack 21
J_14 K_4 A_8 Z_120 
Stack 22
Z_121 K_1 Z_122 Z_123 
Stack 23
Z_124 I_7 G_7 Z_125 
Stack 24
Z_126 I_2 L_14 P_0 
Stack 25
H_3 Z_127 J_16 A_4 
Stack 26
D_10 A_6 T_3 O_8 
Stack 27
K_15 M_8 Z_128 Z_129 
Stack 28
A_3 B_3 E_9 Z_130 
Stack 29
G_2 Z_131 O_9 H_10 
Stack 30
H_8 Z_132 D_1 Z_133 
Stack 31
O_1 A_2 O_3 M_2 
Stack 32
Z_134 J_15 I_15 E_6 
Stack 33
D_9 O_4 B_10 Z_135 
Stack 34
Z_136 Z_137 I_10 N_5 
Stack 35
J_17 L_9 E_3 K_13 
Stack 36
K_14 D_4 N_2 L_2 
Stack 37
D_7 B_13 R_5 K_5 
Stack 38
Z_138 P_4 G_10 F_10 
Stack 39
Z_139 N_12 Q_6 D_6 
Stack 40
M_3 R_11 M_4 L_15 
Stack 41
G_0 P_5 K_18 D_3 
Stack 42
Z_140 D_5 G_9 I_5 
Stack 43
L_8 Z_141 J_13 M_10 
Stack 44
Z_142 Z_143 R_15 Z_144 
Stack 45
E_0 H_5 O_0 G_1 
Stack 46
J_10 T_1 Q_7 L_13 
Stack 47
L_6 D_2 P_6 T_2 
Stack 48
Z_145 G_4 S_10 S_6 
Stack 49
A_1 H_7 K_0 Z_146 
Stack 50
K_12 T_8 E_13 Z_147 
Stack 51
M_13 F_12 H_9 J_11 
Stack 52
Z_148 R_8 C_2 N_14 
Stack 53
B_14 G_13 F_6 S_1 
Stack 54
E_2 C_6 T_9 Q_1 
Stack 55
P_1 L_18 R_7 I_14 
Stack 56
Z_149 L_4 F_3 M_14 
Stack 57
J_4 A_10 K_20 H_14 
Stack 58
Z_150 L_11 C_3 N_7 
Stack 59
Z_151 E_5 B_5 Z_152 
Stack 60
Z_153 K_2 Z_154 H_11 
Stack 61
M_12 I_12 P_8 Z_155 
Stack 62
I_16 M_1 E_8 R_14 
Stack 63
N_3 M_5 R_2 Z_156 
Stack 64
B_9 Z_157 Z_158 A_9 
Stack 65
I_3 P_10 Z_159 N_4 
Stack 66
H_16 N_13 P_2 E_14 
Stack 67
R_6 T_0 Z_160 M_11 
Stack 68
M_9 T_10 D_0 Q_9 
Stack 69
C_9 S_9 J_22 R_12 
Stack 70
Z_161 K_16 S_0 K_8 
Stack 71
A_11 A_7 C_11 H_1 
Stack 72
S_8 N_10 O_2 O_12 
Stack 73
Z_162 F_7 R_10 Z_163 
Stack 74
I_8 Z_164 S_2 T_6 
Stack 75
R_3 C_10 B_8 H_2 
Stack 76
Q_11 J_19 L_12 L_0 
Stack 77
Z_165 J_9 O_15 J_7 
Stack 78
F_14 E_4 G_6 E_1 
Stack 79
L_1 O_5 I_4 N_9 
Stack 80
Z_166 D_8 Q_3 F_0 
Stack 81
Z_167 G_3 L_17 N_11 
Stack 82
P_3 B_11 C_4 J_3 
Stack 83
I_18 F_4 E_10 T_11 
Stack 84
Z_168 P_9 Z_169 J_20 
Stack 85
J_18 S_11 O_7 Z_170 
Stack 86
A_0 H_6 I_6 T_4 
Stack 87
F_8 P_11 Z_171 N_8 
Stack 88
O_6 J_8 Z_172 N_1 
Stack 89
K_9 Z_173 J_2 Z_174 
Stack 90
H_0 C_13 J_6 E_11 
Stack 91
Q_5 R_9 J_5 F_15 
Stack 92
R_13 S_4 C_5 M_0 
Stack 93
B_4 R_4 Z_175 I_0 
Stack 94
B_1 R_0 H_4 Z_176 
Stack 95
G_8 M_6 P_7 O_13 
Stack 96
G_12 I_9 C_1 
Stack 97
B_6 O_10 Z_177 
