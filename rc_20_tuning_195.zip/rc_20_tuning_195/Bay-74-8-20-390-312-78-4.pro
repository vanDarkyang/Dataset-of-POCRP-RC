Number Of Containers
390
Number Of Yard Stacks
74
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
312
Number Of Shutout Containers
78
Yard Bay
Stack 0
I_11 F_10 N_5 M_8 D_7 R_10 
Stack 1
L_4 Z_100 H_12 S_0 F_0 Z_101 
Stack 2
Q_3 C_14 Q_5 Z_102 C_5 K_11 
Stack 3
A_5 A_3 C_2 M_15 T_9 L_5 
Stack 4
R_8 I_10 C_12 J_10 Z_103 F_8 
Stack 5
A_1 O_11 T_7 Z_104 C_6 Z_105 
Stack 6
T_12 F_17 Z_106 P_7 Z_107 F_2 
Stack 7
I_9 S_3 I_5 K_18 L_2 J_11 
Stack 8
T_11 Z_108 Z_109 H_13 Z_110 Z_111 
Stack 9
R_13 J_7 C_8 D_0 P_8 J_9 
Stack 10
G_16 Z_112 S_5 Q_8 Z_113 Z_114 
Stack 11
Z_115 Z_116 T_8 Z_117 Z_118 A_10 
Stack 12
H_14 B_8 Z_119 O_7 Q_2 S_4 
Stack 13
F_1 H_7 T_1 P_5 A_4 R_1 
Stack 14
O_3 I_2 M_5 R_12 G_6 G_13 
Stack 15
E_9 I_8 P_12 E_10 L_1 Z_120 
Stack 16
M_16 H_5 R_14 Z_121 S_11 Z_122 
Stack 17
K_5 S_2 I_16 Z_123 A_7 C_7 
Stack 18
D_4 I_15 M_0 S_6 N_7 Z_124 
Stack 19
C_1 O_12 A_11 Z_125 T_10 Z_126 
Stack 20
Z_127 O_0 Z_128 P_2 Q_0 
Stack 21
D_10 L_11 Z_129 A_2 Z_130 
Stack 22
J_1 O_9 T_0 G_7 Q_10 
Stack 23
S_12 J_4 Z_131 F_15 G_0 
Stack 24
H_11 D_8 O_13 J_5 G_12 
Stack 25
L_0 D_11 F_7 R_2 Z_132 
Stack 26
S_8 P_4 Q_9 Z_133 H_2 
Stack 27
J_0 Z_134 J_6 O_6 K_8 
Stack 28
C_13 Z_135 C_4 Z_136 O_4 
Stack 29
I_18 M_2 I_3 I_19 J_2 
Stack 30
Z_137 T_2 L_7 J_15 K_9 
Stack 31
R_6 R_11 N_4 T_5 O_5 
Stack 32
Z_138 D_6 K_14 K_10 M_3 
Stack 33
E_3 J_3 J_13 J_18 E_2 
Stack 34
B_10 Z_139 P_6 G_10 P_3 
Stack 35
E_6 K_12 F_13 Z_140 T_6 
Stack 36
P_15 H_8 Z_141 O_14 Q_12 
Stack 37
S_1 Z_142 Z_143 D_1 N_13 
Stack 38
B_11 E_12 G_5 J_16 N_0 
Stack 39
E_8 N_1 S_9 R_5 Z_144 
Stack 40
B_5 P_0 K_6 P_13 Z_145 
Stack 41
L_12 N_9 M_9 L_6 B_4 
Stack 42
Z_146 B_9 K_17 I_4 S_7 
Stack 43
E_11 M_6 Z_147 R_9 Z_148 
Stack 44
O_10 Z_149 Z_150 C_0 A_6 
Stack 45
Z_151 E_1 J_19 Z_152 E_0 
Stack 46
G_14 M_12 Z_153 D_12 K_4 
Stack 47
F_5 B_2 P_14 G_9 Z_154 
Stack 48
Z_155 R_4 I_7 Z_156 S_10 
Stack 49
Z_157 J_17 K_7 D_5 E_7 
Stack 50
F_11 G_18 N_6 T_4 F_4 
Stack 51
Q_1 L_3 Q_7 H_4 Z_158 
Stack 52
F_12 O_1 N_10 N_8 Z_159 
Stack 53
D_13 L_8 P_10 G_8 B_1 
Stack 54
P_11 J_14 P_1 C_11 K_2 
Stack 55
I_12 K_0 Q_4 H_0 L_10 
Stack 56
E_4 K_1 I_1 Z_160 D_14 
Stack 57
B_6 Q_6 Z_161 Z_162 F_3 
Stack 58
A_9 J_8 P_9 I_13 G_3 
Stack 59
N_12 H_9 Z_163 Z_164 N_2 
Stack 60
D_2 Z_165 K_16 G_15 I_14 
Stack 61
Z_166 I_0 Z_167 T_3 M_1 
Stack 62
O_8 I_17 F_16 A_8 C_3 
Stack 63
L_13 D_15 E_5 R_0 D_3 
Stack 64
F_6 H_10 B_7 R_3 L_9 
Stack 65
H_15 Z_168 G_11 C_10 D_9 
Stack 66
F_14 Q_11 N_3 Z_169 K_13 
Stack 67
M_10 B_3 J_20 H_3 M_13 
Stack 68
G_4 Z_170 Z_171 K_3 Z_172 
Stack 69
Z_173 F_9 N_11 Z_174 M_4 
Stack 70
H_1 G_1 I_6 G_17 Z_175 
Stack 71
R_7 M_7 Z_176 N_14 A_0 
Stack 72
B_0 C_9 K_15 M_14 O_2 
Stack 73
J_12 H_6 M_11 G_2 Z_177 
