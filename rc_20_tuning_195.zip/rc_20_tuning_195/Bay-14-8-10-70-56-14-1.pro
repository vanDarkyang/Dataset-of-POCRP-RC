Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 B_3 Z_101 H_1 Z_102 
Stack 1
C_5 A_1 E_2 F_4 F_0 
Stack 2
E_3 Z_103 F_6 J_0 Z_104 
Stack 3
Z_105 C_3 B_1 G_2 B_2 
Stack 4
H_0 I_4 Z_106 A_0 E_6 
Stack 5
I_0 Z_107 D_3 F_1 G_1 
Stack 6
D_2 Z_108 J_2 E_1 G_5 
Stack 7
F_5 D_5 E_5 G_0 G_3 
Stack 8
F_2 H_3 J_1 C_4 C_0 
Stack 9
E_0 C_1 B_4 B_5 D_0 
Stack 10
Z_109 F_3 I_3 C_6 G_4 
Stack 11
Z_110 Z_111 I_1 Z_112 I_2 
Stack 12
B_0 D_1 E_4 J_3 D_4 
Stack 13
C_2 H_2 Z_113 J_4 E_7 
