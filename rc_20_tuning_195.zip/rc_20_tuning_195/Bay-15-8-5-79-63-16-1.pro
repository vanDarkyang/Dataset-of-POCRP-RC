Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_13 B_9 C_7 A_5 B_12 B_11 
Stack 1
A_7 E_3 C_9 B_8 Z_100 Z_101 
Stack 2
Z_102 Z_103 Z_104 A_0 E_2 E_1 
Stack 3
B_1 A_6 E_5 B_7 E_8 D_1 
Stack 4
Z_105 D_8 Z_106 E_0 E_7 
Stack 5
B_6 A_1 D_12 A_3 A_9 
Stack 6
B_13 Z_107 E_6 D_0 Z_108 
Stack 7
B_4 C_0 B_0 C_6 D_6 
Stack 8
C_5 E_10 C_4 D_10 Z_109 
Stack 9
C_11 C_8 B_2 B_3 B_10 
Stack 10
A_8 D_11 C_1 A_4 Z_110 
Stack 11
Z_111 E_9 C_12 Z_112 C_2 
Stack 12
D_4 B_5 D_3 D_5 Z_113 
Stack 13
A_10 Z_114 C_3 E_4 D_7 
Stack 14
Z_115 C_10 D_2 A_2 D_9 
