Number Of Containers
190
Number Of Yard Stacks
48
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
152
Number Of Shutout Containers
38
Yard Bay
Stack 0
L_5 M_8 J_6 N_0 
Stack 1
Z_100 F_4 T_2 K_6 
Stack 2
J_3 F_5 Z_101 R_3 
Stack 3
E_3 J_0 Z_102 Z_103 
Stack 4
D_1 T_3 B_2 P_6 
Stack 5
P_1 O_5 I_0 K_12 
Stack 6
I_6 H_4 O_3 P_4 
Stack 7
B_1 J_1 Z_104 N_2 
Stack 8
L_0 Z_105 Z_106 L_6 
Stack 9
Z_107 Z_108 G_7 Z_109 
Stack 10
E_6 K_0 I_4 L_3 
Stack 11
Z_110 A_2 D_2 D_4 
Stack 12
J_5 R_4 T_1 K_2 
Stack 13
I_3 T_0 G_1 K_11 
Stack 14
H_7 S_5 N_4 Q_2 
Stack 15
F_2 M_4 J_9 F_7 
Stack 16
D_6 G_0 E_2 E_1 
Stack 17
M_5 Z_111 Z_112 L_4 
Stack 18
D_3 F_0 N_5 J_11 
Stack 19
M_3 I_8 Z_113 O_2 
Stack 20
A_1 J_10 K_9 Z_114 
Stack 21
Z_115 K_10 A_0 Z_116 
Stack 22
O_1 I_1 K_3 S_0 
Stack 23
Z_117 E_0 Z_118 K_5 
Stack 24
D_5 Z_119 P_7 Z_120 
Stack 25
B_4 G_5 H_5 O_0 
Stack 26
H_2 H_1 Q_3 P_0 
Stack 27
E_4 Z_121 N_6 C_0 
Stack 28
Z_122 Z_123 O_8 Z_124 
Stack 29
Q_4 M_0 F_6 N_7 
Stack 30
G_6 H_8 C_1 H_9 
Stack 31
M_7 I_7 P_2 Z_125 
Stack 32
Z_126 Z_127 K_7 O_4 
Stack 33
L_2 K_4 S_2 Q_1 
Stack 34
D_0 Z_128 N_1 B_3 
Stack 35
Z_129 E_7 P_5 N_8 
Stack 36
Z_130 K_1 I_5 Z_131 
Stack 37
E_5 B_0 Z_132 G_2 
Stack 38
H_3 M_2 J_2 Z_133 
Stack 39
L_1 I_2 A_3 A_4 
Stack 40
R_2 F_3 S_4 O_6 
Stack 41
R_0 G_3 F_1 H_0 
Stack 42
H_6 R_1 G_4 J_8 
Stack 43
P_3 O_7 T_4 Z_134 
Stack 44
Q_0 Z_135 C_2 J_7 
Stack 45
Z_136 M_6 J_4 N_3 
Stack 46
S_3 M_1 S_1 
Stack 47
G_8 Z_137 K_8 
