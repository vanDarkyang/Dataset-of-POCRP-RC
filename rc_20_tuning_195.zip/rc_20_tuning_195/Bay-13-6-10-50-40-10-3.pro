Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 E_4 F_4 Z_101 
Stack 1
E_3 Z_102 H_2 E_5 
Stack 2
C_1 H_4 G_1 Z_103 
Stack 3
G_3 G_4 Z_104 Z_105 
Stack 4
B_1 F_2 C_3 Z_106 
Stack 5
F_1 H_1 J_2 B_3 
Stack 6
Z_107 B_0 I_1 D_3 
Stack 7
F_3 H_0 J_0 H_3 
Stack 8
D_2 E_1 G_2 I_0 
Stack 9
Z_108 Z_109 A_1 A_0 
Stack 10
E_0 G_0 E_2 B_2 
Stack 11
J_1 F_0 D_1 
Stack 12
D_0 C_0 C_2 
