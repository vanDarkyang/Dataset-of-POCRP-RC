Number Of Containers
10
Number Of Yard Stacks
3
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
8
Number Of Shutout Containers
2
Yard Bay
Stack 0
A_0 Z_100 C_2 A_1 
Stack 1
B_1 B_2 Z_101 
Stack 2
C_0 C_1 B_0 
