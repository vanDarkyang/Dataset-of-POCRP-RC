Number Of Containers
16
Number Of Yard Stacks
3
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
12
Number Of Shutout Containers
4
Yard Bay
Stack 0
A_2 Z_100 C_0 C_1 C_2 A_0 
Stack 1
B_1 B_4 Z_101 Z_102 C_3 
Stack 2
A_1 B_3 B_2 Z_103 B_0 
