Number Of Containers
199
Number Of Yard Stacks
50
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
159
Number Of Shutout Containers
40
Yard Bay
Stack 0
J_9 K_0 M_8 A_2 
Stack 1
Z_100 N_8 Z_101 D_5 
Stack 2
G_0 F_10 G_11 E_9 
Stack 3
D_4 O_2 M_2 C_5 
Stack 4
D_3 N_5 J_3 I_2 
Stack 5
K_8 K_4 Z_102 H_5 
Stack 6
E_7 H_1 M_0 J_0 
Stack 7
J_2 M_3 I_8 B_2 
Stack 8
K_2 Z_103 B_0 I_11 
Stack 9
I_5 N_2 L_4 F_7 
Stack 10
Z_104 N_9 Z_105 H_9 
Stack 11
Z_106 H_8 H_4 H_0 
Stack 12
Z_107 E_2 K_9 D_8 
Stack 13
F_0 F_11 Z_108 Z_109 
Stack 14
E_0 Z_110 N_6 B_7 
Stack 15
A_1 J_8 I_6 O_6 
Stack 16
G_8 H_10 C_3 O_5 
Stack 17
H_12 B_5 Z_111 N_7 
Stack 18
I_0 B_1 Z_112 O_7 
Stack 19
J_10 H_3 L_9 L_0 
Stack 20
E_8 I_4 B_6 O_8 
Stack 21
E_1 K_3 L_8 K_1 
Stack 22
J_6 Z_113 Z_114 N_1 
Stack 23
G_9 B_3 L_7 F_4 
Stack 24
L_2 F_9 Z_115 Z_116 
Stack 25
Z_117 Z_118 N_0 G_6 
Stack 26
Z_119 E_5 K_11 G_1 
Stack 27
H_6 E_3 A_6 D_7 
Stack 28
M_6 B_4 Z_120 Z_121 
Stack 29
K_10 L_5 G_5 E_11 
Stack 30
C_8 J_5 E_10 M_4 
Stack 31
C_1 I_12 I_10 Z_122 
Stack 32
Z_123 O_4 I_1 G_2 
Stack 33
J_4 Z_124 I_9 Z_125 
Stack 34
A_0 L_3 Z_126 C_4 
Stack 35
J_11 E_6 Z_127 G_7 
Stack 36
Z_128 F_8 J_7 G_10 
Stack 37
Z_129 F_6 F_3 Z_130 
Stack 38
I_3 Z_131 L_6 C_0 
Stack 39
H_2 D_1 Z_132 C_6 
Stack 40
Z_133 O_3 O_1 D_0 
Stack 41
Z_134 Z_135 N_3 G_4 
Stack 42
H_13 M_7 F_1 I_7 
Stack 43
G_3 M_1 J_1 O_0 
Stack 44
C_7 Z_136 D_6 A_5 
Stack 45
L_1 H_14 A_3 Z_137 
Stack 46
K_6 Z_138 E_4 K_7 
Stack 47
F_2 M_5 A_4 Z_139 
Stack 48
H_11 H_7 K_5 F_5 
Stack 49
C_2 D_2 N_4 
