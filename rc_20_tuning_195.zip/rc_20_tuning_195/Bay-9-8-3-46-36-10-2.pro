Number Of Containers
46
Number Of Yard Stacks
9
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_4 A_2 Z_100 C_12 B_7 C_2 
Stack 1
B_6 A_7 B_5 B_8 Z_101 
Stack 2
A_4 A_10 B_9 A_6 Z_102 
Stack 3
A_0 Z_103 A_8 C_9 B_10 
Stack 4
A_9 Z_104 C_0 Z_105 C_5 
Stack 5
B_3 Z_106 C_4 B_11 C_7 
Stack 6
C_11 B_2 A_5 Z_107 A_3 
Stack 7
A_1 C_3 B_0 C_8 C_1 
Stack 8
C_10 Z_108 C_6 Z_109 B_1 
