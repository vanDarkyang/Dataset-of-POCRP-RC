Number Of Containers
46
Number Of Yard Stacks
9
MaxTier of Yard Stacks
8
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_5 B_6 Z_100 A_11 A_5 A_3 
Stack 1
B_0 Z_101 C_5 C_3 Z_102 
Stack 2
A_7 A_1 B_4 Z_103 A_6 
Stack 3
C_0 A_4 Z_104 Z_105 C_7 
Stack 4
A_9 B_9 B_8 B_7 B_11 
Stack 5
A_0 C_1 C_6 C_9 A_8 
Stack 6
B_10 Z_106 A_10 C_8 Z_107 
Stack 7
B_3 B_2 C_2 Z_108 A_2 
Stack 8
B_1 C_4 Z_109 B_13 B_12 
