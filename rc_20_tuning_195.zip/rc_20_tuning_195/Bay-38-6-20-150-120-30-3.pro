Number Of Containers
150
Number Of Yard Stacks
38
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
120
Number Of Shutout Containers
30
Yard Bay
Stack 0
E_2 Z_100 K_4 T_1 
Stack 1
Z_101 F_0 A_1 I_5 
Stack 2
I_4 H_6 J_4 K_7 
Stack 3
Z_102 O_4 K_11 L_9 
Stack 4
Q_1 J_0 Z_103 G_2 
Stack 5
K_1 L_6 H_1 P_3 
Stack 6
J_1 N_6 M_3 M_0 
Stack 7
F_2 J_9 O_5 Z_104 
Stack 8
J_8 G_4 O_6 K_8 
Stack 9
P_5 I_0 I_1 P_2 
Stack 10
Z_105 Z_106 Z_107 K_6 
Stack 11
T_0 C_1 R_4 N_5 
Stack 12
D_1 M_7 D_4 Q_3 
Stack 13
J_6 Z_108 B_1 Z_109 
Stack 14
D_2 N_7 Z_110 Z_111 
Stack 15
M_4 M_6 F_3 K_5 
Stack 16
Z_112 I_7 L_5 Z_113 
Stack 17
K_2 D_3 Z_114 L_2 
Stack 18
Z_115 M_5 O_1 J_2 
Stack 19
Z_116 Z_117 D_0 Z_118 
Stack 20
O_2 N_8 K_3 Z_119 
Stack 21
E_0 Q_4 Z_120 G_1 
Stack 22
H_2 H_3 P_1 Z_121 
Stack 23
F_5 N_2 I_2 Z_122 
Stack 24
R_0 A_0 Z_123 D_5 
Stack 25
K_10 L_0 N_1 S_0 
Stack 26
L_4 E_1 Z_124 R_2 
Stack 27
G_3 J_5 I_3 R_1 
Stack 28
J_7 H_4 J_3 Q_0 
Stack 29
M_2 L_8 N_0 H_5 
Stack 30
H_0 L_7 G_0 M_1 
Stack 31
L_3 Z_125 N_4 C_2 
Stack 32
S_1 B_0 C_0 O_3 
Stack 33
I_6 K_9 Z_126 Z_127 
Stack 34
R_3 N_3 K_0 Z_128 
Stack 35
Q_2 L_1 P_4 F_4 
Stack 36
P_0 Z_129 F_1 
Stack 37
M_8 O_0 Q_5 
