Number Of Containers
170
Number Of Yard Stacks
43
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
136
Number Of Shutout Containers
34
Yard Bay
Stack 0
Z_100 E_5 G_1 C_0 
Stack 1
C_6 Z_101 I_3 Z_102 
Stack 2
Z_103 Z_104 I_4 B_4 
Stack 3
A_5 B_8 E_11 J_1 
Stack 4
D_7 E_7 G_6 F_14 
Stack 5
C_9 J_5 H_3 Z_105 
Stack 6
Z_106 F_12 Z_107 E_6 
Stack 7
Z_108 G_9 C_13 Z_109 
Stack 8
Z_110 Z_111 H_13 B_6 
Stack 9
H_1 A_2 G_7 D_12 
Stack 10
Z_112 Z_113 C_10 A_7 
Stack 11
F_5 G_14 A_8 Z_114 
Stack 12
I_14 G_10 C_1 H_8 
Stack 13
A_11 F_11 G_5 F_7 
Stack 14
F_6 D_11 C_12 B_5 
Stack 15
Z_115 A_1 J_6 H_0 
Stack 16
F_15 D_13 G_0 F_9 
Stack 17
J_3 F_10 B_7 J_4 
Stack 18
Z_116 E_9 Z_117 A_6 
Stack 19
J_0 I_13 J_8 D_0 
Stack 20
A_0 J_10 Z_118 E_3 
Stack 21
D_2 I_2 J_12 F_2 
Stack 22
Z_119 C_5 D_8 Z_120 
Stack 23
I_12 C_8 Z_121 D_1 
Stack 24
H_9 G_2 Z_122 C_3 
Stack 25
G_3 D_10 B_2 I_0 
Stack 26
Z_123 Z_124 C_4 F_13 
Stack 27
B_0 Z_125 D_9 B_1 
Stack 28
I_5 E_1 C_2 I_1 
Stack 29
B_9 H_7 I_7 G_12 
Stack 30
J_11 A_4 E_10 Z_126 
Stack 31
E_4 F_1 F_3 D_3 
Stack 32
E_0 C_7 G_8 Z_127 
Stack 33
Z_128 H_12 C_11 D_5 
Stack 34
H_5 Z_129 G_4 A_3 
Stack 35
F_8 E_2 J_2 B_3 
Stack 36
I_10 J_7 I_11 H_4 
Stack 37
J_9 H_11 Z_130 Z_131 
Stack 38
Z_132 H_2 B_10 G_13 
Stack 39
H_6 H_10 A_10 I_8 
Stack 40
G_11 A_9 E_8 Z_133 
Stack 41
I_9 D_4 D_6 
Stack 42
I_6 F_0 F_4 
