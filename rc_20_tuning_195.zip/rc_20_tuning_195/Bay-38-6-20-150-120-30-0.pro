Number Of Containers
150
Number Of Yard Stacks
38
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
120
Number Of Shutout Containers
30
Yard Bay
Stack 0
Z_100 G_0 Z_101 M_0 
Stack 1
E_1 K_7 S_0 I_3 
Stack 2
Z_102 M_5 B_0 C_3 
Stack 3
Z_103 O_2 H_5 M_2 
Stack 4
F_3 Z_104 Z_105 R_2 
Stack 5
N_1 R_1 L_6 N_4 
Stack 6
L_0 I_5 L_1 N_0 
Stack 7
N_6 J_1 P_0 Z_106 
Stack 8
Z_107 O_4 Z_108 J_5 
Stack 9
L_9 S_2 J_6 Z_109 
Stack 10
E_5 K_5 M_4 Z_110 
Stack 11
I_6 Z_111 O_3 K_1 
Stack 12
T_0 Z_112 P_1 I_9 
Stack 13
K_3 L_4 H_4 I_2 
Stack 14
H_2 E_4 C_1 F_6 
Stack 15
E_3 F_5 B_2 I_8 
Stack 16
Z_113 R_0 D_0 M_6 
Stack 17
P_3 D_3 N_3 F_0 
Stack 18
Z_114 Z_115 L_2 F_2 
Stack 19
K_6 K_10 H_0 C_0 
Stack 20
Q_1 Z_116 K_0 H_7 
Stack 21
Z_117 Z_118 J_4 Z_119 
Stack 22
F_7 I_7 Z_120 G_2 
Stack 23
H_6 Z_121 G_5 O_1 
Stack 24
Z_122 F_1 Z_123 H_3 
Stack 25
G_6 A_0 G_3 K_8 
Stack 26
K_9 Z_124 H_8 G_4 
Stack 27
I_10 A_1 E_0 I_0 
Stack 28
L_7 I_1 J_3 F_4 
Stack 29
G_1 N_2 J_2 M_1 
Stack 30
N_5 Z_125 L_3 K_4 
Stack 31
O_0 H_1 Q_0 E_6 
Stack 32
Z_126 D_2 Z_127 Z_128 
Stack 33
L_8 D_1 Z_129 O_5 
Stack 34
J_0 D_4 T_1 L_5 
Stack 35
G_7 K_2 P_2 E_2 
Stack 36
I_4 M_3 C_2 
Stack 37
O_6 S_1 B_1 
