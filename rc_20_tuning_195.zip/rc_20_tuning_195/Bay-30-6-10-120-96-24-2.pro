Number Of Containers
120
Number Of Yard Stacks
30
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
I_0 J_6 H_11 I_4 
Stack 1
Z_100 F_6 F_8 Z_101 
Stack 2
E_1 D_1 G_6 E_2 
Stack 3
H_0 D_11 B_5 J_4 
Stack 4
Z_102 A_6 C_9 I_1 
Stack 5
C_1 Z_103 D_9 H_7 
Stack 6
E_4 H_6 Z_104 E_8 
Stack 7
Z_105 J_0 Z_106 A_8 
Stack 8
Z_107 B_3 Z_108 J_1 
Stack 9
D_5 Z_109 A_5 D_8 
Stack 10
Z_110 G_3 F_3 B_2 
Stack 11
A_0 B_7 H_9 D_0 
Stack 12
D_10 Z_111 H_1 A_1 
Stack 13
D_2 F_10 F_5 E_5 
Stack 14
F_7 G_0 Z_112 J_3 
Stack 15
G_5 B_6 I_6 I_5 
Stack 16
E_7 F_1 F_9 Z_113 
Stack 17
H_4 A_7 Z_114 Z_115 
Stack 18
E_6 G_1 A_3 J_2 
Stack 19
F_4 A_2 G_8 Z_116 
Stack 20
D_7 Z_117 I_3 C_2 
Stack 21
H_8 Z_118 G_2 C_0 
Stack 22
C_7 D_4 G_7 Z_119 
Stack 23
H_2 C_5 C_10 H_3 
Stack 24
Z_120 A_4 C_3 D_3 
Stack 25
Z_121 I_2 B_4 E_3 
Stack 26
C_4 B_0 E_0 H_10 
Stack 27
D_6 F_2 C_6 H_5 
Stack 28
Z_122 F_0 Z_123 J_5 
Stack 29
C_8 G_4 B_1 I_7 
