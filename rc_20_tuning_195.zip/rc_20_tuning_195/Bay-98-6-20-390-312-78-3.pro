Number Of Containers
390
Number Of Yard Stacks
98
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
312
Number Of Shutout Containers
78
Yard Bay
Stack 0
E_11 B_3 Q_8 I_11 
Stack 1
C_4 M_0 Z_100 P_5 
Stack 2
H_12 Z_101 P_2 J_2 
Stack 3
T_8 Z_102 Q_9 Z_103 
Stack 4
N_12 Z_104 R_8 F_4 
Stack 5
M_9 F_5 Z_105 M_4 
Stack 6
O_0 O_8 L_18 I_1 
Stack 7
O_11 F_9 N_0 Z_106 
Stack 8
G_1 Z_107 S_8 Z_108 
Stack 9
F_14 Z_109 L_5 N_4 
Stack 10
G_0 R_6 D_6 Z_110 
Stack 11
D_8 Z_111 R_12 J_13 
Stack 12
H_14 E_4 Z_112 A_11 
Stack 13
N_15 N_14 I_8 S_1 
Stack 14
S_12 B_0 L_3 E_6 
Stack 15
H_0 Z_113 B_10 R_5 
Stack 16
L_16 H_11 N_17 C_13 
Stack 17
L_6 Z_114 B_4 K_0 
Stack 18
C_14 L_17 J_15 I_12 
Stack 19
E_8 Q_6 O_12 C_0 
Stack 20
Z_115 E_9 D_9 T_1 
Stack 21
Z_116 Z_117 R_7 B_11 
Stack 22
F_16 Z_118 E_3 Q_4 
Stack 23
C_3 K_16 S_10 R_1 
Stack 24
D_13 M_5 N_2 Z_119 
Stack 25
Z_120 L_12 N_3 C_9 
Stack 26
O_4 Z_121 Z_122 F_7 
Stack 27
E_1 Z_123 F_10 Z_124 
Stack 28
H_7 A_4 Z_125 J_10 
Stack 29
G_9 Z_126 B_2 P_12 
Stack 30
I_0 D_1 S_5 A_10 
Stack 31
J_6 J_4 F_6 H_13 
Stack 32
P_8 L_13 Z_127 J_3 
Stack 33
P_1 K_2 Z_128 Z_129 
Stack 34
T_4 I_4 O_3 Z_130 
Stack 35
Z_131 N_9 R_15 B_15 
Stack 36
R_9 M_15 Z_132 M_7 
Stack 37
Z_133 C_2 S_3 C_7 
Stack 38
N_5 K_8 K_11 L_11 
Stack 39
G_2 D_0 Z_134 A_1 
Stack 40
K_19 Z_135 F_1 Z_136 
Stack 41
L_0 Z_137 D_5 Z_138 
Stack 42
D_14 Q_2 F_3 B_6 
Stack 43
F_12 A_6 O_5 S_0 
Stack 44
C_1 O_10 G_13 F_15 
Stack 45
K_18 Z_139 K_14 Q_0 
Stack 46
L_9 P_4 J_1 Z_140 
Stack 47
D_10 R_4 K_10 K_3 
Stack 48
E_0 L_19 N_1 R_11 
Stack 49
T_6 H_5 Q_1 I_7 
Stack 50
A_8 E_2 L_2 P_0 
Stack 51
L_4 Z_141 E_7 C_8 
Stack 52
G_7 N_16 Z_142 I_5 
Stack 53
Z_143 Z_144 H_10 T_10 
Stack 54
S_11 Z_145 S_6 M_11 
Stack 55
L_8 O_15 H_6 F_0 
Stack 56
P_11 S_4 B_5 G_8 
Stack 57
T_0 Z_146 K_1 Z_147 
Stack 58
G_15 P_6 D_11 Z_148 
Stack 59
A_5 B_8 B_9 K_4 
Stack 60
O_7 Q_7 D_4 M_3 
Stack 61
K_12 N_8 G_14 Q_11 
Stack 62
K_13 Q_3 N_11 R_10 
Stack 63
T_9 C_11 L_7 M_14 
Stack 64
G_6 L_15 Z_149 Z_150 
Stack 65
N_13 C_6 H_1 L_10 
Stack 66
M_6 Z_151 H_2 Z_152 
Stack 67
F_2 Z_153 N_10 M_2 
Stack 68
Z_154 O_6 T_5 J_7 
Stack 69
Z_155 Z_156 B_12 G_10 
Stack 70
Z_157 L_1 M_12 C_5 
Stack 71
E_12 I_9 Z_158 G_5 
Stack 72
J_8 B_1 Z_159 D_3 
Stack 73
M_13 Z_160 K_6 M_1 
Stack 74
Z_161 G_11 S_7 L_14 
Stack 75
A_7 A_2 Z_162 G_12 
Stack 76
O_9 T_2 Z_163 B_7 
Stack 77
H_8 J_14 F_11 P_10 
Stack 78
N_18 P_14 J_9 M_8 
Stack 79
P_7 Z_164 I_6 I_2 
Stack 80
O_16 P_3 Q_12 A_9 
Stack 81
Z_165 E_5 I_10 C_10 
Stack 82
R_13 R_3 H_9 O_17 
Stack 83
N_6 J_5 S_2 Z_166 
Stack 84
A_0 Z_167 T_7 K_7 
Stack 85
E_10 K_17 D_7 Z_168 
Stack 86
C_12 P_13 R_0 Z_169 
Stack 87
H_4 Z_170 O_1 J_0 
Stack 88
Z_171 H_15 N_7 R_2 
Stack 89
H_3 I_3 A_12 A_3 
Stack 90
G_3 S_9 H_16 Z_172 
Stack 91
R_14 O_14 T_3 P_9 
Stack 92
Z_173 J_11 J_12 O_13 
Stack 93
K_5 B_13 K_15 B_14 
Stack 94
Z_174 Z_175 F_8 Q_5 
Stack 95
Q_10 D_12 Z_176 M_10 
Stack 96
D_2 G_4 Z_177 
Stack 97
F_13 O_2 K_9 
