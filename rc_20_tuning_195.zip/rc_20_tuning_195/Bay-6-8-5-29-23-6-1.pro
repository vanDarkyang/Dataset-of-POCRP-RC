Number Of Containers
29
Number Of Yard Stacks
6
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
23
Number Of Shutout Containers
6
Yard Bay
Stack 0
B_3 B_5 B_2 Z_100 C_3 
Stack 1
B_0 Z_101 C_0 Z_102 D_0 
Stack 2
C_1 B_4 A_0 A_3 D_1 
Stack 3
Z_103 B_1 Z_104 C_2 E_0 
Stack 4
E_2 D_3 D_2 D_5 D_4 
Stack 5
A_1 A_2 Z_105 E_1 
