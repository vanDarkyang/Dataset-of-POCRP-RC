Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
J_0 C_4 G_2 C_5 F_6 
Stack 1
E_0 G_5 E_4 F_4 A_4 
Stack 2
C_2 J_2 Z_100 C_3 G_4 
Stack 3
F_1 A_3 H_1 D_5 E_1 
Stack 4
C_1 G_0 A_1 I_0 Z_101 
Stack 5
H_4 E_2 H_5 H_2 Z_102 
Stack 6
D_1 A_2 B_0 D_3 Z_103 
Stack 7
Z_104 D_6 Z_105 B_1 Z_106 
Stack 8
J_1 Z_107 G_1 F_5 I_4 
Stack 9
G_3 F_0 Z_108 D_0 D_2 
Stack 10
B_2 Z_109 F_3 Z_110 H_3 
Stack 11
B_3 Z_111 I_1 C_0 A_0 
Stack 12
Z_112 E_3 F_2 Z_113 I_2 
Stack 13
D_4 I_3 G_6 J_3 H_0 
