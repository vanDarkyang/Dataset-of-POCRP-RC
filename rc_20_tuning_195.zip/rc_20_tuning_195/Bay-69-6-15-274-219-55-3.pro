Number Of Containers
274
Number Of Yard Stacks
69
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
219
Number Of Shutout Containers
55
Yard Bay
Stack 0
I_0 I_12 I_4 I_10 
Stack 1
A_1 Z_100 J_5 J_17 
Stack 2
I_5 I_3 E_5 N_4 
Stack 3
Z_101 N_0 A_11 J_10 
Stack 4
J_2 K_8 F_13 H_5 
Stack 5
B_1 M_12 M_9 A_12 
Stack 6
Z_102 C_8 B_11 I_7 
Stack 7
O_9 B_6 K_12 F_4 
Stack 8
Z_103 Z_104 M_1 J_6 
Stack 9
Z_105 B_9 A_4 K_11 
Stack 10
O_3 Z_106 C_10 B_12 
Stack 11
M_8 G_8 L_4 A_6 
Stack 12
E_12 G_2 N_9 L_6 
Stack 13
Z_107 N_6 C_13 Z_108 
Stack 14
E_8 D_4 O_5 O_1 
Stack 15
H_1 A_3 H_14 G_9 
Stack 16
K_7 H_4 M_7 E_4 
Stack 17
H_0 G_11 I_1 K_4 
Stack 18
F_8 A_2 F_3 O_0 
Stack 19
E_13 H_2 C_3 H_11 
Stack 20
I_8 Z_109 J_1 C_11 
Stack 21
Z_110 H_6 E_16 D_0 
Stack 22
I_15 D_2 E_2 I_6 
Stack 23
E_0 J_15 N_8 Z_111 
Stack 24
A_10 H_3 O_8 D_1 
Stack 25
E_3 Z_112 I_2 N_2 
Stack 26
H_7 G_6 M_4 G_3 
Stack 27
E_6 A_8 J_12 B_13 
Stack 28
F_10 D_10 F_14 H_12 
Stack 29
Z_113 Z_114 K_3 C_2 
Stack 30
K_5 L_9 N_1 M_10 
Stack 31
N_10 M_11 K_6 I_13 
Stack 32
K_0 L_2 M_2 N_7 
Stack 33
F_7 B_8 E_15 Z_115 
Stack 34
L_8 L_14 K_10 J_0 
Stack 35
Z_116 Z_117 Z_118 L_0 
Stack 36
F_1 K_2 Z_119 Z_120 
Stack 37
C_6 M_3 F_6 Z_121 
Stack 38
L_5 K_1 Z_122 I_9 
Stack 39
Z_123 Z_124 F_9 I_11 
Stack 40
Z_125 B_7 Z_126 A_9 
Stack 41
E_1 Z_127 J_9 Z_128 
Stack 42
Z_129 C_7 O_2 E_11 
Stack 43
D_11 C_0 F_0 Z_130 
Stack 44
G_5 G_15 Z_131 D_3 
Stack 45
Z_132 M_6 I_16 D_7 
Stack 46
A_5 Z_133 L_1 E_14 
Stack 47
G_4 H_10 C_4 F_12 
Stack 48
H_13 A_0 G_10 J_8 
Stack 49
G_7 J_4 O_7 L_13 
Stack 50
F_5 F_2 Z_134 E_9 
Stack 51
O_10 C_5 G_0 Z_135 
Stack 52
J_11 Z_136 H_9 Z_137 
Stack 53
Z_138 B_5 F_15 K_9 
Stack 54
N_5 I_14 L_11 E_7 
Stack 55
B_3 B_0 Z_139 C_9 
Stack 56
G_13 O_6 Z_140 O_4 
Stack 57
C_1 M_5 Z_141 Z_142 
Stack 58
Z_143 N_3 B_14 G_14 
Stack 59
L_10 O_11 L_3 J_13 
Stack 60
J_16 Z_144 Z_145 Z_146 
Stack 61
F_11 E_10 B_2 Z_147 
Stack 62
J_3 L_7 L_12 B_4 
Stack 63
Z_148 Z_149 B_10 Z_150 
Stack 64
D_9 Z_151 D_8 J_7 
Stack 65
G_12 O_12 Z_152 D_12 
Stack 66
J_14 M_0 H_8 D_6 
Stack 67
Z_153 C_12 Z_154 
Stack 68
A_7 D_5 G_1 
