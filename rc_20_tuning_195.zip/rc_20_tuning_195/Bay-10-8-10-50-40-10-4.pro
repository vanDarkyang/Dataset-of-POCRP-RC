Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_0 C_0 F_1 Z_100 F_3 
Stack 1
D_4 H_1 E_5 D_0 H_2 
Stack 2
D_2 E_3 Z_101 E_0 E_4 
Stack 3
Z_102 Z_103 B_2 G_2 J_1 
Stack 4
C_3 C_4 J_0 Z_104 F_4 
Stack 5
F_2 G_4 B_1 F_0 A_2 
Stack 6
Z_105 G_3 G_5 Z_106 C_2 
Stack 7
C_1 I_1 A_1 E_1 A_0 
Stack 8
G_0 E_2 D_3 I_0 Z_107 
Stack 9
G_1 Z_108 Z_109 H_0 D_1 
