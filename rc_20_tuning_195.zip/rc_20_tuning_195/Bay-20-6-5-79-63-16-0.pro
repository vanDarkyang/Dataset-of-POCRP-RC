Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_9 B_9 B_6 A_2 
Stack 1
Z_100 C_6 Z_101 A_7 
Stack 2
C_5 D_1 B_13 C_2 
Stack 3
B_7 E_3 Z_102 Z_103 
Stack 4
Z_104 Z_105 E_8 D_10 
Stack 5
Z_106 C_4 C_3 A_1 
Stack 6
C_8 A_8 B_3 A_6 
Stack 7
B_5 B_10 E_11 B_1 
Stack 8
D_3 C_9 Z_107 E_5 
Stack 9
C_11 A_10 Z_108 Z_109 
Stack 10
B_8 C_1 Z_110 D_8 
Stack 11
A_4 D_9 E_9 B_4 
Stack 12
B_0 D_4 D_7 A_11 
Stack 13
D_2 E_13 Z_111 E_10 
Stack 14
Z_112 E_12 B_2 C_0 
Stack 15
B_11 C_10 E_6 E_0 
Stack 16
D_6 B_12 E_2 Z_113 
Stack 17
D_0 E_1 D_5 A_3 
Stack 18
E_4 C_7 A_0 A_5 
Stack 19
Z_114 Z_115 E_7 
