Number Of Containers
150
Number Of Yard Stacks
29
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
120
Number Of Shutout Containers
30
Yard Bay
Stack 0
E_5 Z_100 N_7 R_4 K_5 C_3 
Stack 1
E_3 H_0 Q_3 Z_101 L_7 O_3 
Stack 2
I_5 L_3 H_3 B_2 Z_102 P_4 
Stack 3
O_2 S_2 N_1 G_0 P_3 J_8 
Stack 4
Q_1 I_6 Z_103 F_2 Z_104 Z_105 
Stack 5
K_1 R_3 L_0 Z_106 E_6 
Stack 6
Z_107 Q_2 E_4 S_1 K_6 
Stack 7
F_1 P_0 J_5 O_0 P_2 
Stack 8
J_9 M_4 H_4 D_0 K_4 
Stack 9
P_6 Z_108 Z_109 K_2 N_4 
Stack 10
H_5 Z_110 L_5 A_0 Z_111 
Stack 11
T_1 H_8 Z_112 P_1 C_1 
Stack 12
Z_113 O_4 B_0 Z_114 Z_115 
Stack 13
J_6 J_0 K_7 T_0 Z_116 
Stack 14
D_1 L_4 N_2 Z_117 M_5 
Stack 15
Z_118 N_5 L_1 J_2 L_2 
Stack 16
I_3 J_10 L_6 I_4 J_1 
Stack 17
Z_119 G_6 Z_120 J_3 Z_121 
Stack 18
Z_122 I_0 K_3 N_0 F_0 
Stack 19
E_0 Z_123 A_1 G_1 G_2 
Stack 20
O_1 C_2 J_4 N_3 H_7 
Stack 21
E_1 M_3 K_9 Z_124 I_1 
Stack 22
H_2 G_3 G_4 E_2 D_3 
Stack 23
F_3 N_6 H_1 K_0 S_0 
Stack 24
R_0 M_2 M_1 P_5 R_2 
Stack 25
K_8 I_7 Z_125 Z_126 R_1 
Stack 26
Z_127 D_2 O_5 Q_4 Q_0 
Stack 27
G_5 Z_128 I_2 T_2 H_6 
Stack 28
J_7 C_0 B_1 Z_129 M_0 
