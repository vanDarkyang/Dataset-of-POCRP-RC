Number Of Containers
274
Number Of Yard Stacks
52
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
219
Number Of Shutout Containers
55
Yard Bay
Stack 0
I_1 Z_100 G_0 O_10 L_6 F_14 
Stack 1
B_6 O_2 J_4 J_11 I_13 J_6 
Stack 2
B_2 D_10 E_6 H_5 F_6 D_3 
Stack 3
K_10 H_8 H_4 Z_101 L_3 K_6 
Stack 4
F_7 Z_102 G_11 K_8 F_2 B_7 
Stack 5
I_12 G_13 M_13 Z_103 D_4 Z_104 
Stack 6
I_9 I_10 E_0 N_2 B_1 N_0 
Stack 7
Z_105 Z_106 G_8 M_8 Z_107 I_7 
Stack 8
J_16 Z_108 F_9 G_12 B_8 N_5 
Stack 9
Z_109 Z_110 L_10 F_13 I_3 B_0 
Stack 10
C_4 C_11 H_0 J_2 E_11 H_10 
Stack 11
Z_111 O_9 F_3 Z_112 N_9 Z_113 
Stack 12
D_9 I_6 M_3 O_1 J_13 B_11 
Stack 13
Z_114 F_16 L_1 D_12 C_7 L_7 
Stack 14
Z_115 E_2 H_2 J_12 J_7 
Stack 15
Z_116 N_10 C_10 I_15 J_17 
Stack 16
G_10 Z_117 D_0 J_14 K_5 
Stack 17
F_10 F_12 M_1 I_8 C_5 
Stack 18
Z_118 B_9 M_9 F_11 M_11 
Stack 19
Z_119 H_11 F_15 I_5 F_1 
Stack 20
H_13 D_6 G_5 M_5 J_8 
Stack 21
J_5 E_8 M_2 Z_120 N_6 
Stack 22
F_0 Z_121 Z_122 A_0 L_11 
Stack 23
Z_123 A_1 I_2 L_12 C_3 
Stack 24
A_3 J_10 Z_124 L_8 K_9 
Stack 25
H_1 F_4 Z_125 M_12 L_2 
Stack 26
Z_126 A_4 Z_127 K_3 G_1 
Stack 27
K_13 H_15 N_8 Z_128 Z_129 
Stack 28
Z_130 Z_131 O_8 E_7 J_1 
Stack 29
H_9 Z_132 K_14 K_4 G_4 
Stack 30
Z_133 E_12 G_2 Z_134 K_2 
Stack 31
C_1 O_5 N_7 N_1 K_11 
Stack 32
H_6 I_14 Z_135 D_8 C_9 
Stack 33
J_3 A_6 D_13 A_9 G_9 
Stack 34
E_5 C_2 M_4 Z_136 Z_137 
Stack 35
D_7 K_0 N_3 G_7 B_12 
Stack 36
Z_138 M_6 Z_139 L_4 Z_140 
Stack 37
Z_141 Z_142 H_12 A_5 H_17 
Stack 38
O_4 H_16 Z_143 H_7 I_4 
Stack 39
I_17 K_12 Z_144 Z_145 A_8 
Stack 40
C_6 O_6 C_8 E_4 L_5 
Stack 41
K_1 K_15 E_13 E_15 E_10 
Stack 42
O_3 Z_146 A_7 B_3 D_14 
Stack 43
G_3 F_8 J_15 Z_147 I_16 
Stack 44
Z_148 L_0 B_10 C_12 H_14 
Stack 45
N_4 F_5 D_2 M_10 M_7 
Stack 46
Z_149 C_0 L_9 D_5 B_5 
Stack 47
E_14 J_9 E_1 K_7 N_11 
Stack 48
B_4 I_11 E_9 G_14 A_2 
Stack 49
O_0 G_6 O_7 Z_150 D_11 
Stack 50
Z_151 I_0 Z_152 M_0 Z_153 
Stack 51
Z_154 D_1 J_0 H_3 E_3 
