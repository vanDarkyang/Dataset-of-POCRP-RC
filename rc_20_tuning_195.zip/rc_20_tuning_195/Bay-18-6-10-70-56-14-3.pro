Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
J_0 G_0 G_1 Z_100 
Stack 1
E_3 E_5 E_0 J_3 
Stack 2
C_1 A_2 Z_101 F_5 
Stack 3
F_1 D_4 I_1 A_4 
Stack 4
Z_102 Z_103 F_2 G_4 
Stack 5
H_4 Z_104 G_6 E_4 
Stack 6
Z_105 F_0 C_3 Z_106 
Stack 7
C_4 E_2 F_3 H_6 
Stack 8
Z_107 Z_108 Z_109 F_4 
Stack 9
G_3 I_2 D_3 E_1 
Stack 10
B_3 G_2 I_0 I_3 
Stack 11
B_4 E_7 H_2 D_1 
Stack 12
Z_110 J_2 D_2 H_3 
Stack 13
Z_111 H_1 B_2 A_0 
Stack 14
C_2 A_1 Z_112 Z_113 
Stack 15
G_5 H_5 D_0 H_0 
Stack 16
J_1 B_0 E_6 
Stack 17
A_3 B_1 C_0 
