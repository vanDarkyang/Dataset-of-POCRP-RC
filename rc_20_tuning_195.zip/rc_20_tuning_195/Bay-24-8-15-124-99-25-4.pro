Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
Z_100 H_4 E_0 O_2 N_5 H_5 
Stack 1
N_3 J_5 N_4 M_2 I_1 H_2 
Stack 2
F_3 O_0 I_2 Z_101 G_2 G_5 
Stack 3
Z_102 I_6 Z_103 Z_104 Z_105 Z_106 
Stack 4
Z_107 F_2 J_8 Z_108 Z_109 
Stack 5
H_8 F_1 L_0 F_5 F_8 
Stack 6
D_0 F_7 D_2 B_4 E_2 
Stack 7
Z_110 E_6 K_7 Z_111 L_3 
Stack 8
C_2 Z_112 H_7 Z_113 M_1 
Stack 9
B_3 B_1 H_9 A_2 K_6 
Stack 10
J_6 F_6 J_2 M_0 C_1 
Stack 11
Z_114 Z_115 B_2 I_0 M_3 
Stack 12
H_0 O_1 Z_116 Z_117 H_3 
Stack 13
Z_118 Z_119 E_5 J_4 N_0 
Stack 14
F_0 F_4 K_2 K_4 G_7 
Stack 15
C_6 C_0 D_5 E_3 N_1 
Stack 16
B_0 L_2 C_3 Z_120 D_1 
Stack 17
K_0 G_1 K_3 O_3 I_4 
Stack 18
G_0 D_4 I_5 D_6 Z_121 
Stack 19
C_4 K_5 Z_122 Z_123 Z_124 
Stack 20
E_4 H_1 G_3 D_3 E_1 
Stack 21
I_7 H_6 K_1 A_0 C_5 
Stack 22
J_1 L_1 A_1 G_6 G_4 
Stack 23
N_2 J_0 J_3 J_7 I_3 
