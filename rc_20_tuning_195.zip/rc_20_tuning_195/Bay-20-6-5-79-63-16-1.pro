Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 A_0 C_0 B_12 
Stack 1
A_7 C_12 Z_101 Z_102 
Stack 2
C_3 Z_103 Z_104 E_3 
Stack 3
B_1 E_14 C_2 E_11 
Stack 4
E_5 C_8 Z_105 E_10 
Stack 5
B_7 D_8 A_5 A_9 
Stack 6
B_13 E_12 Z_106 Z_107 
Stack 7
B_4 B_6 Z_108 D_4 
Stack 8
C_5 A_3 B_8 Z_109 
Stack 9
C_10 C_9 E_0 B_10 
Stack 10
A_8 C_7 A_2 D_0 
Stack 11
E_9 Z_110 Z_111 C_1 
Stack 12
D_2 C_11 C_6 Z_112 
Stack 13
A_11 E_7 D_7 D_5 
Stack 14
E_1 Z_113 B_3 D_6 
Stack 15
B_9 Z_114 A_4 B_11 
Stack 16
E_4 E_8 B_5 A_10 
Stack 17
E_13 B_0 D_3 E_2 
Stack 18
A_6 C_4 E_6 D_1 
Stack 19
Z_115 B_2 A_1 
