Number Of Containers
190
Number Of Yard Stacks
36
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
152
Number Of Shutout Containers
38
Yard Bay
Stack 0
K_2 N_0 I_8 R_1 F_7 I_7 
Stack 1
G_1 K_9 I_4 N_7 L_10 R_3 
Stack 2
H_6 J_6 R_0 J_9 D_4 G_2 
Stack 3
T_0 L_8 O_2 K_7 F_3 N_9 
Stack 4
F_6 D_1 P_4 I_5 P_1 Z_100 
Stack 5
J_10 M_6 O_0 E_8 R_2 Z_101 
Stack 6
E_0 G_7 D_0 N_1 Z_102 H_7 
Stack 7
M_7 T_3 K_0 J_5 E_6 O_4 
Stack 8
Z_103 Q_1 J_1 J_3 Z_104 Z_105 
Stack 9
O_9 G_5 F_2 I_1 D_3 Z_106 
Stack 10
I_3 L_11 A_0 K_6 O_8 
Stack 11
Z_107 Z_108 N_4 P_0 J_7 
Stack 12
F_1 B_2 L_3 C_1 Z_109 
Stack 13
L_5 Z_110 J_0 Z_111 F_4 
Stack 14
Z_112 H_3 Z_113 S_1 Z_114 
Stack 15
Z_115 Z_116 Q_6 L_7 M_3 
Stack 16
L_6 Q_3 Z_117 E_7 F_0 
Stack 17
G_4 J_2 F_8 Z_118 B_1 
Stack 18
P_2 Z_119 S_2 Z_120 H_0 
Stack 19
M_5 K_8 Z_121 J_4 K_1 
Stack 20
Z_122 Z_123 B_0 Q_2 R_5 
Stack 21
M_0 N_5 E_3 Q_5 S_0 
Stack 22
H_5 Z_124 T_2 D_2 Z_125 
Stack 23
E_2 E_5 M_9 I_2 Z_126 
Stack 24
J_8 F_5 Z_127 E_4 M_8 
Stack 25
I_0 Z_128 K_10 Q_4 K_5 
Stack 26
H_2 L_2 Z_129 C_3 E_1 
Stack 27
H_1 K_3 C_2 L_1 O_3 
Stack 28
Z_130 L_0 M_1 P_3 Z_131 
Stack 29
Z_132 P_5 O_5 H_4 Z_133 
Stack 30
A_2 L_9 A_3 K_11 M_2 
Stack 31
O_6 K_4 L_4 N_3 G_6 
Stack 32
N_8 C_0 T_1 G_3 R_4 
Stack 33
Z_134 A_1 Z_135 O_7 Z_136 
Stack 34
C_4 I_6 N_2 O_1 M_4 
Stack 35
Q_0 Z_137 N_6 I_9 G_0 
