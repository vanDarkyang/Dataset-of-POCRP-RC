Number Of Containers
290
Number Of Yard Stacks
73
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
232
Number Of Shutout Containers
58
Yard Bay
Stack 0
Z_100 P_8 E_11 G_13 
Stack 1
D_5 Q_3 C_6 Z_101 
Stack 2
G_3 H_7 I_9 I_2 
Stack 3
Z_102 P_1 M_10 T_1 
Stack 4
I_7 E_0 Q_9 C_0 
Stack 5
C_5 P_7 Z_103 Z_104 
Stack 6
N_2 H_14 G_0 N_0 
Stack 7
M_9 Z_105 H_4 Z_106 
Stack 8
Z_107 K_10 N_8 D_4 
Stack 9
S_0 Z_108 E_2 N_10 
Stack 10
R_8 D_8 C_9 Z_109 
Stack 11
C_1 R_2 D_1 K_8 
Stack 12
A_5 Z_110 Z_111 S_1 
Stack 13
H_6 K_5 O_7 C_8 
Stack 14
Z_112 G_12 Z_113 H_2 
Stack 15
I_3 Z_114 R_0 Z_115 
Stack 16
Z_116 I_4 N_4 S_2 
Stack 17
E_4 Z_117 Z_118 I_5 
Stack 18
F_3 R_5 I_6 K_7 
Stack 19
P_3 Z_119 Z_120 I_14 
Stack 20
G_6 M_8 M_13 K_3 
Stack 21
P_10 Z_121 Z_122 J_10 
Stack 22
Z_123 Z_124 N_1 O_0 
Stack 23
D_9 Z_125 J_4 Q_10 
Stack 24
E_5 I_8 F_1 Z_126 
Stack 25
G_1 O_8 T_2 B_6 
Stack 26
F_9 B_2 N_7 K_13 
Stack 27
H_0 F_5 Q_5 L_5 
Stack 28
H_13 H_5 K_2 T_3 
Stack 29
O_3 R_3 C_7 R_6 
Stack 30
L_4 B_7 Q_4 Q_1 
Stack 31
J_9 Z_127 D_10 I_0 
Stack 32
F_4 L_1 R_1 D_3 
Stack 33
K_1 B_8 D_6 H_11 
Stack 34
E_10 Q_8 M_2 Z_128 
Stack 35
J_2 Z_129 M_1 H_8 
Stack 36
T_4 Z_130 F_0 Z_131 
Stack 37
G_11 Z_132 P_6 D_0 
Stack 38
I_13 O_2 Z_133 Z_134 
Stack 39
K_16 P_2 H_3 L_13 
Stack 40
S_3 P_9 E_8 J_3 
Stack 41
G_5 Z_135 Z_136 F_2 
Stack 42
J_8 M_3 M_6 B_1 
Stack 43
K_4 M_0 L_9 J_7 
Stack 44
Z_137 H_1 R_7 F_8 
Stack 45
Z_138 S_5 B_5 Q_6 
Stack 46
Z_139 D_7 O_9 Q_2 
Stack 47
E_6 G_4 A_1 S_6 
Stack 48
G_7 K_11 J_11 N_9 
Stack 49
F_10 N_3 Z_140 Z_141 
Stack 50
M_7 J_0 E_1 M_5 
Stack 51
A_0 L_10 R_9 Z_142 
Stack 52
Z_143 Z_144 J_1 L_7 
Stack 53
E_7 B_0 F_6 M_14 
Stack 54
K_0 J_5 A_4 Z_145 
Stack 55
Z_146 I_11 H_9 T_5 
Stack 56
I_10 H_12 K_14 Q_7 
Stack 57
P_4 Z_147 G_2 Z_148 
Stack 58
M_12 Z_149 L_12 P_0 
Stack 59
O_4 P_5 C_4 L_0 
Stack 60
H_10 M_11 O_1 B_4 
Stack 61
L_2 B_3 J_6 N_6 
Stack 62
M_4 L_11 G_9 Z_150 
Stack 63
I_12 K_12 S_8 A_3 
Stack 64
Z_151 K_15 L_3 F_7 
Stack 65
Q_0 Q_11 L_8 C_3 
Stack 66
E_3 Z_152 C_2 I_1 
Stack 67
Z_153 P_11 O_5 K_9 
Stack 68
D_2 G_8 Z_154 R_4 
Stack 69
A_6 G_10 O_6 S_7 
Stack 70
L_6 Z_155 Z_156 N_5 
Stack 71
K_6 T_0 Z_157 
Stack 72
E_9 A_2 S_4 
