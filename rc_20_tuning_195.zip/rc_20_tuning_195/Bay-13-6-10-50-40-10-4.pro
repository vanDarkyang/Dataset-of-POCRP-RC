Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_1 I_0 Z_100 H_0 
Stack 1
D_4 C_4 A_1 Z_101 
Stack 2
D_1 G_4 D_3 H_2 
Stack 3
F_1 G_3 F_4 E_4 
Stack 4
C_3 I_1 D_2 J_1 
Stack 5
F_3 Z_102 D_0 Z_103 
Stack 6
Z_104 Z_105 E_0 A_2 
Stack 7
C_1 F_2 G_2 C_2 
Stack 8
G_0 E_5 Z_106 A_0 
Stack 9
G_1 E_2 F_0 H_1 
Stack 10
C_0 B_3 B_0 Z_107 
Stack 11
Z_108 J_0 E_1 
Stack 12
E_3 B_2 Z_109 
