Number Of Containers
19
Number Of Yard Stacks
4
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
15
Number Of Shutout Containers
4
Yard Bay
Stack 0
A_0 B_1 C_3 B_3 C_0 
Stack 1
D_1 B_2 D_2 C_2 D_0 
Stack 2
Z_100 C_1 B_0 Z_101 Z_102 
Stack 3
A_1 E_0 Z_103 A_2 
