Number Of Containers
19
Number Of Yard Stacks
4
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
15
Number Of Shutout Containers
4
Yard Bay
Stack 0
A_1 E_0 E_1 Z_100 A_0 
Stack 1
C_2 C_1 B_2 A_2 B_1 
Stack 2
D_0 Z_101 Z_102 E_2 D_1 
Stack 3
C_0 Z_103 B_0 B_3 
