Number Of Containers
274
Number Of Yard Stacks
52
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
219
Number Of Shutout Containers
55
Yard Bay
Stack 0
L_2 G_11 I_1 G_12 E_14 Z_100 
Stack 1
C_2 I_16 E_2 A_11 K_4 D_4 
Stack 2
D_11 Z_101 Z_102 N_0 H_3 O_6 
Stack 3
F_8 D_13 Z_103 N_7 Z_104 D_12 
Stack 4
D_6 M_6 G_3 A_5 F_5 Z_105 
Stack 5
K_10 L_4 O_4 D_7 J_0 F_2 
Stack 6
H_0 Z_106 L_5 H_5 Z_107 J_13 
Stack 7
O_10 I_0 E_0 Z_108 Z_109 Z_110 
Stack 8
Z_111 B_6 O_12 I_10 Z_112 O_7 
Stack 9
I_17 E_3 N_6 K_9 L_9 L_0 
Stack 10
B_7 I_12 Z_113 J_5 J_9 M_2 
Stack 11
E_12 Z_114 K_2 B_8 C_1 Z_115 
Stack 12
Z_116 Z_117 D_9 Z_118 A_8 Z_119 
Stack 13
Z_120 Z_121 I_7 Z_122 G_6 C_6 
Stack 14
O_8 H_7 K_8 Z_123 I_4 
Stack 15
C_5 B_12 Z_124 J_6 H_8 
Stack 16
A_10 A_3 N_13 L_8 G_14 
Stack 17
D_15 B_4 F_0 L_12 J_2 
Stack 18
Z_125 I_3 B_10 J_12 M_9 
Stack 19
Z_126 M_0 G_4 N_2 Z_127 
Stack 20
Z_128 F_1 E_10 B_0 Z_129 
Stack 21
Z_130 O_9 C_3 A_0 O_1 
Stack 22
J_1 F_7 H_16 M_8 G_1 
Stack 23
Z_131 L_3 N_3 F_12 G_5 
Stack 24
H_15 H_13 D_2 I_13 Z_132 
Stack 25
K_7 H_10 Z_133 G_0 A_9 
Stack 26
O_5 I_9 N_4 N_12 C_8 
Stack 27
D_1 I_5 J_10 G_15 J_3 
Stack 28
G_10 Z_134 H_6 L_6 O_0 
Stack 29
H_4 N_8 A_7 M_11 J_7 
Stack 30
N_10 D_10 J_4 L_1 B_11 
Stack 31
Z_135 F_4 L_13 L_10 B_5 
Stack 32
M_12 N_9 F_10 F_9 Z_136 
Stack 33
Z_137 J_8 I_15 H_2 I_6 
Stack 34
E_8 C_12 I_8 Z_138 H_1 
Stack 35
H_11 K_1 M_10 O_3 Z_139 
Stack 36
L_11 Z_140 E_15 M_4 K_0 
Stack 37
E_13 F_3 B_3 K_11 O_2 
Stack 38
G_8 D_5 A_4 I_2 G_7 
Stack 39
Z_141 F_11 Z_142 K_5 E_4 
Stack 40
H_14 K_12 C_7 C_10 D_0 
Stack 41
C_9 Z_143 C_11 M_7 M_5 
Stack 42
E_11 B_9 N_11 Z_144 A_1 
Stack 43
B_1 H_12 C_0 Z_145 K_6 
Stack 44
E_5 B_2 A_2 Z_146 E_6 
Stack 45
L_7 D_14 Z_147 Z_148 Z_149 
Stack 46
E_7 Z_150 H_9 C_4 K_3 
Stack 47
D_3 G_9 J_11 N_1 E_1 
Stack 48
Z_151 M_3 I_14 I_11 A_6 
Stack 49
G_16 M_1 D_8 Z_152 O_11 
Stack 50
G_17 I_18 Z_153 B_13 N_5 
Stack 51
E_9 Z_154 G_2 F_6 G_13 
