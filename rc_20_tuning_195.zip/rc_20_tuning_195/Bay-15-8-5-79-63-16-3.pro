Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
D_9 E_9 B_6 B_2 C_2 B_5 
Stack 1
C_5 C_10 B_4 A_10 E_1 Z_100 
Stack 2
B_0 A_6 A_9 D_4 Z_101 Z_102 
Stack 3
C_11 C_3 A_2 Z_103 E_7 B_1 
Stack 4
Z_104 Z_105 C_1 D_6 Z_106 
Stack 5
A_11 E_3 E_10 D_13 A_1 
Stack 6
E_8 A_5 D_0 Z_107 A_7 
Stack 7
Z_108 Z_109 C_8 D_3 E_6 
Stack 8
E_2 B_3 E_4 B_13 Z_110 
Stack 9
Z_111 C_0 E_0 D_11 D_2 
Stack 10
Z_112 C_9 D_8 C_7 B_12 
Stack 11
B_8 B_10 D_5 D_7 B_11 
Stack 12
A_0 D_10 E_5 D_12 Z_113 
Stack 13
C_6 C_4 Z_114 A_8 A_3 
Stack 14
B_9 B_7 A_4 D_1 Z_115 
