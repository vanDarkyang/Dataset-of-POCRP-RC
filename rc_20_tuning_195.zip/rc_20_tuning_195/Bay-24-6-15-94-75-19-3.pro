Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
K_0 G_3 A_0 Z_100 
Stack 1
I_2 Z_101 F_3 K_3 
Stack 2
C_0 N_0 F_2 H_4 
Stack 3
Z_102 Z_103 H_1 K_4 
Stack 4
D_3 Z_104 M_1 E_2 
Stack 5
H_3 Z_105 E_4 I_6 
Stack 6
C_4 J_5 H_2 K_1 
Stack 7
N_3 F_4 G_0 C_2 
Stack 8
Z_106 G_4 I_3 H_0 
Stack 9
Z_107 L_1 Z_108 L_2 
Stack 10
Z_109 E_1 I_7 Z_110 
Stack 11
F_5 Z_111 M_2 A_1 
Stack 12
G_5 J_3 O_0 F_6 
Stack 13
H_5 J_4 H_6 G_1 
Stack 14
Z_112 Z_113 Z_114 I_5 
Stack 15
E_3 C_1 Z_115 F_0 
Stack 16
H_8 J_0 D_0 L_0 
Stack 17
F_1 K_2 N_2 C_3 
Stack 18
D_1 Z_116 O_2 E_0 
Stack 19
N_1 I_1 H_7 I_4 
Stack 20
J_6 O_1 G_2 Z_117 
Stack 21
G_6 B_0 M_0 J_2 
Stack 22
Z_118 I_0 B_1 
Stack 23
D_2 B_2 J_1 
