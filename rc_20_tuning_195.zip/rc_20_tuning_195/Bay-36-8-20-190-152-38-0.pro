Number Of Containers
190
Number Of Yard Stacks
36
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
152
Number Of Shutout Containers
38
Yard Bay
Stack 0
L_5 L_4 Z_100 Z_101 Z_102 E_0 
Stack 1
J_5 E_4 G_4 G_0 K_4 G_1 
Stack 2
J_3 H_4 H_2 N_5 Z_103 H_0 
Stack 3
E_2 Z_104 Z_105 J_10 N_1 A_3 
Stack 4
D_1 Z_106 Z_107 E_1 P_6 O_6 
Stack 5
P_1 R_0 Z_108 Q_6 K_11 H_1 
Stack 6
Z_109 H_7 H_9 N_6 P_4 J_9 
Stack 7
B_1 P_3 I_8 C_0 N_3 Z_110 
Stack 8
L_0 Q_0 N_0 K_8 Z_111 J_8 
Stack 9
C_6 C_4 K_3 A_0 Z_112 N_4 
Stack 10
E_5 Z_113 F_5 K_2 Z_114 
Stack 11
C_1 G_7 E_6 O_5 Z_115 
Stack 12
J_7 M_10 K_0 P_7 K_1 
Stack 13
I_3 F_4 B_0 H_6 K_10 
Stack 14
H_8 Z_116 M_3 Q_4 Q_3 
Stack 15
F_2 J_0 I_2 N_7 F_6 
Stack 16
D_4 T_1 F_3 O_7 Z_117 
Stack 17
M_7 O_4 G_2 Z_118 L_3 
Stack 18
Z_119 H_5 Z_120 C_3 Z_121 
Stack 19
M_4 J_1 Z_122 P_2 O_1 
Stack 20
A_1 Z_123 L_8 K_5 Z_124 
Stack 21
Q_2 L_6 M_8 S_1 G_6 
Stack 22
O_0 Z_125 M_0 N_2 S_0 
Stack 23
G_5 A_2 K_7 P_5 Z_126 
Stack 24
D_3 R_2 Z_127 I_5 R_1 
Stack 25
B_5 Z_128 T_0 I_7 Z_129 
Stack 26
H_3 S_3 Q_5 J_2 P_0 
Stack 27
E_3 M_5 L_1 Z_130 C_2 
Stack 28
M_2 Z_131 B_2 S_2 B_4 
Stack 29
Q_7 I_9 I_0 F_1 N_8 
Stack 30
Z_132 F_0 O_2 G_3 H_10 
Stack 31
M_9 I_10 I_6 Z_133 J_6 
Stack 32
L_7 Z_134 M_1 C_5 O_3 
Stack 33
L_2 K_9 Z_135 J_4 Q_1 
Stack 34
D_0 I_1 I_4 Z_136 B_3 
Stack 35
M_6 Z_137 D_2 K_6 N_9 
