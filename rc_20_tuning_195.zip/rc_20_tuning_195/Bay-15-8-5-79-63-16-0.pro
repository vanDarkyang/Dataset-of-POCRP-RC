Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_8 B_13 Z_100 Z_101 A_2 E_0 
Stack 1
E_8 Z_102 D_9 B_5 Z_103 D_0 
Stack 2
C_2 Z_104 D_4 E_10 C_0 A_3 
Stack 3
B_9 E_4 E_12 D_5 C_8 A_5 
Stack 4
C_4 A_1 E_11 B_2 D_10 
Stack 5
D_6 B_11 C_9 Z_105 A_0 
Stack 6
C_7 C_3 Z_106 E_7 A_6 
Stack 7
B_7 D_1 E_1 D_8 B_1 
Stack 8
Z_107 E_3 C_5 Z_108 E_5 
Stack 9
C_11 C_6 A_9 B_3 C_10 
Stack 10
B_10 C_1 B_8 Z_109 Z_110 
Stack 11
A_4 A_7 B_4 E_2 B_6 
Stack 12
B_0 B_12 B_14 D_7 A_10 
Stack 13
D_3 Z_111 A_11 Z_112 E_9 
Stack 14
D_2 Z_113 E_6 Z_114 Z_115 
