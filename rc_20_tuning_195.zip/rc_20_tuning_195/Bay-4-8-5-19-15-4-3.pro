Number Of Containers
19
Number Of Yard Stacks
4
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
15
Number Of Shutout Containers
4
Yard Bay
Stack 0
A_1 D_3 C_1 C_2 E_1 
Stack 1
D_2 E_0 A_0 C_0 Z_100 
Stack 2
B_1 Z_101 Z_102 Z_103 D_0 
Stack 3
B_0 D_1 E_2 B_2 
