Number Of Containers
290
Number Of Yard Stacks
55
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
232
Number Of Shutout Containers
58
Yard Bay
Stack 0
F_6 G_10 Z_100 Z_101 N_9 H_4 
Stack 1
L_4 C_11 C_10 D_7 H_13 B_6 
Stack 2
S_0 Z_102 Z_103 I_2 F_2 H_6 
Stack 3
N_12 J_8 J_1 L_3 B_7 O_8 
Stack 4
N_10 T_2 Z_104 J_13 E_8 S_5 
Stack 5
I_5 Z_105 M_6 Z_106 P_5 L_6 
Stack 6
I_9 Z_107 I_10 S_3 Z_108 O_7 
Stack 7
Q_0 F_5 D_3 Z_109 T_0 Z_110 
Stack 8
K_10 M_9 Z_111 H_2 R_5 K_13 
Stack 9
O_10 M_3 M_1 O_4 D_2 A_6 
Stack 10
K_14 H_3 Z_112 Z_113 Z_114 T_5 
Stack 11
Z_115 I_3 B_3 N_1 Q_6 H_5 
Stack 12
K_15 H_1 T_4 L_5 B_4 Q_5 
Stack 13
Z_116 N_14 H_7 D_0 F_3 G_7 
Stack 14
A_0 Z_117 R_7 Z_118 P_8 L_0 
Stack 15
G_5 F_0 P_9 C_8 M_10 
Stack 16
C_7 O_11 M_2 M_8 I_8 
Stack 17
Q_2 D_1 G_1 A_5 G_11 
Stack 18
E_4 Z_119 J_7 L_11 Z_120 
Stack 19
Z_121 L_12 Z_122 J_4 H_12 
Stack 20
P_6 Z_123 A_3 I_0 R_1 
Stack 21
M_5 G_9 L_9 H_0 L_8 
Stack 22
B_0 Z_124 C_9 G_4 Z_125 
Stack 23
K_3 F_1 C_0 Q_9 K_2 
Stack 24
N_11 Q_7 O_12 I_13 C_1 
Stack 25
O_3 Z_126 G_8 Z_127 F_7 
Stack 26
J_5 Z_128 A_8 F_8 C_5 
Stack 27
N_2 Z_129 B_9 Z_130 M_4 
Stack 28
Z_131 R_6 Z_132 N_13 T_7 
Stack 29
A_1 E_1 S_4 E_0 R_0 
Stack 30
G_3 L_10 L_1 Z_133 K_4 
Stack 31
G_6 J_14 D_8 Z_134 T_1 
Stack 32
T_3 K_8 Z_135 N_5 H_10 
Stack 33
I_4 A_7 O_0 C_3 G_12 
Stack 34
R_4 Z_136 J_11 M_11 H_11 
Stack 35
O_6 E_2 I_6 N_3 R_3 
Stack 36
K_11 Z_137 Z_138 C_4 R_2 
Stack 37
Z_139 L_2 J_0 Z_140 F_10 
Stack 38
Z_141 P_3 K_9 E_6 O_1 
Stack 39
K_12 I_7 B_1 S_2 J_12 
Stack 40
O_13 M_0 Q_1 D_5 C_6 
Stack 41
J_2 F_9 M_7 N_7 B_2 
Stack 42
Q_8 Z_142 Q_4 I_12 N_8 
Stack 43
L_7 N_6 N_4 Z_143 P_10 
Stack 44
Z_144 G_2 K_6 O_2 T_8 
Stack 45
Z_145 Z_146 Z_147 E_7 J_9 
Stack 46
Z_148 P_7 Z_149 D_6 H_8 
Stack 47
H_9 B_8 Z_150 D_9 K_5 
Stack 48
J_3 K_1 P_1 P_0 Q_3 
Stack 49
D_4 S_1 S_6 J_10 Z_151 
Stack 50
J_6 K_0 K_7 T_6 N_0 
Stack 51
A_4 F_4 O_5 Z_152 P_4 
Stack 52
B_5 Z_153 Z_154 P_2 I_11 
Stack 53
E_3 Z_155 I_1 Z_156 A_2 
Stack 54
O_9 Z_157 E_5 G_0 C_2 
