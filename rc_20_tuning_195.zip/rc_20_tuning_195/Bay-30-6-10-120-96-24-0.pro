Number Of Containers
120
Number Of Yard Stacks
30
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_0 Z_100 C_6 E_8 
Stack 1
G_6 A_5 G_2 B_0 
Stack 2
E_0 G_7 C_4 I_1 
Stack 3
B_5 C_0 H_4 H_6 
Stack 4
I_7 Z_101 D_2 Z_102 
Stack 5
J_7 B_8 C_5 E_3 
Stack 6
H_0 Z_103 J_3 A_0 
Stack 7
Z_104 D_8 Z_105 J_5 
Stack 8
D_4 J_1 E_7 G_9 
Stack 9
C_8 A_3 Z_106 H_5 
Stack 10
G_10 I_5 G_8 A_4 
Stack 11
Z_107 J_9 Z_108 Z_109 
Stack 12
B_3 E_9 Z_110 I_6 
Stack 13
G_3 A_1 G_4 Z_111 
Stack 14
G_0 E_2 D_6 C_2 
Stack 15
I_3 Z_112 D_1 Z_113 
Stack 16
Z_114 A_6 F_0 F_8 
Stack 17
C_7 Z_115 J_2 I_2 
Stack 18
F_3 H_1 Z_116 E_10 
Stack 19
Z_117 Z_118 H_7 E_6 
Stack 20
F_9 B_2 A_2 D_3 
Stack 21
H_3 C_1 B_6 F_1 
Stack 22
E_4 J_8 I_0 D_7 
Stack 23
G_5 E_1 Z_119 G_1 
Stack 24
B_7 I_4 F_2 A_8 
Stack 25
F_7 Z_120 E_5 Z_121 
Stack 26
J_6 C_3 F_6 F_5 
Stack 27
A_7 G_11 D_9 Z_122 
Stack 28
B_1 J_4 D_5 Z_123 
Stack 29
B_4 J_0 F_4 H_2 
