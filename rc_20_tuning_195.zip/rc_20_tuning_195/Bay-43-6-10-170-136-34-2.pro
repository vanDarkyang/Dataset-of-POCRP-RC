Number Of Containers
170
Number Of Yard Stacks
43
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
136
Number Of Shutout Containers
34
Yard Bay
Stack 0
G_12 C_9 E_11 Z_100 
Stack 1
G_6 D_9 I_0 F_6 
Stack 2
B_11 E_4 C_8 Z_101 
Stack 3
F_1 Z_102 Z_103 E_8 
Stack 4
D_6 I_4 E_0 Z_104 
Stack 5
H_15 H_13 A_1 E_2 
Stack 6
D_0 H_8 D_10 C_2 
Stack 7
F_2 Z_105 F_10 J_4 
Stack 8
C_4 F_12 Z_106 B_8 
Stack 9
B_7 J_9 H_1 Z_107 
Stack 10
H_2 E_1 G_1 F_0 
Stack 11
F_3 C_14 I_3 E_14 
Stack 12
C_12 H_12 F_13 H_4 
Stack 13
C_13 D_7 Z_108 B_1 
Stack 14
E_3 Z_109 G_9 E_10 
Stack 15
D_2 F_4 B_12 F_7 
Stack 16
E_9 Z_110 Z_111 J_1 
Stack 17
A_9 G_10 C_7 C_5 
Stack 18
I_7 F_14 D_3 A_6 
Stack 19
E_7 C_11 Z_112 G_3 
Stack 20
Z_113 H_16 C_3 Z_114 
Stack 21
B_9 B_3 B_2 C_6 
Stack 22
A_5 A_3 Z_115 Z_116 
Stack 23
B_10 Z_117 J_8 G_8 
Stack 24
H_10 Z_118 F_8 A_2 
Stack 25
A_7 B_4 F_5 J_0 
Stack 26
G_7 B_5 I_6 H_7 
Stack 27
D_1 Z_119 I_10 E_12 
Stack 28
F_11 H_3 E_5 H_14 
Stack 29
C_1 D_5 I_8 I_2 
Stack 30
Z_120 C_10 Z_121 G_0 
Stack 31
Z_122 G_5 J_6 J_5 
Stack 32
B_0 D_8 J_2 Z_123 
Stack 33
A_0 A_4 J_3 B_14 
Stack 34
D_4 Z_124 Z_125 A_11 
Stack 35
H_0 Z_126 I_9 Z_127 
Stack 36
Z_128 Z_129 B_13 Z_130 
Stack 37
Z_131 J_7 E_6 A_10 
Stack 38
G_4 F_9 H_6 H_9 
Stack 39
G_11 A_8 H_5 C_0 
Stack 40
Z_132 C_15 I_5 Z_133 
Stack 41
I_1 G_2 E_13 
Stack 42
H_11 B_6 I_11 
