Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
Z_100 E_3 H_7 Z_101 N_3 Z_102 
Stack 1
A_1 Z_103 E_2 Z_104 M_3 F_6 
Stack 2
G_8 E_4 Z_105 F_2 M_4 M_6 
Stack 3
B_2 Z_106 H_3 B_1 F_0 A_0 
Stack 4
G_5 G_1 F_1 Z_107 O_2 
Stack 5
Z_108 O_1 J_0 Z_109 C_2 
Stack 6
G_3 D_5 K_6 D_6 E_6 
Stack 7
H_4 Z_110 H_0 Z_111 H_2 
Stack 8
B_3 L_4 L_5 J_5 J_6 
Stack 9
Z_112 M_1 L_2 G_2 B_0 
Stack 10
I_2 C_0 G_7 K_2 J_1 
Stack 11
Z_113 J_2 I_0 I_5 M_5 
Stack 12
F_4 Z_114 N_0 H_1 D_7 
Stack 13
E_5 L_1 Z_115 Z_116 O_3 
Stack 14
M_2 G_4 K_1 D_3 F_7 
Stack 15
M_0 Z_117 C_4 J_7 D_0 
Stack 16
I_6 H_10 Z_118 F_5 G_6 
Stack 17
Z_119 D_2 O_0 H_8 D_1 
Stack 18
Z_120 I_4 C_1 E_7 Z_121 
Stack 19
G_0 C_3 E_0 I_3 N_1 
Stack 20
N_2 H_5 Z_122 Z_123 K_3 
Stack 21
K_0 L_0 F_3 K_5 H_6 
Stack 22
I_1 J_3 J_4 E_1 L_3 
Stack 23
D_4 Z_124 K_4 E_8 H_9 
