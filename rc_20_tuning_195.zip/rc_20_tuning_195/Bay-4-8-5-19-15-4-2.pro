Number Of Containers
19
Number Of Yard Stacks
4
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
15
Number Of Shutout Containers
4
Yard Bay
Stack 0
B_1 Z_100 D_1 D_3 C_1 
Stack 1
Z_101 C_0 D_2 E_0 B_0 
Stack 2
D_0 Z_102 Z_103 E_1 E_2 
Stack 3
B_2 A_0 A_1 C_2 
