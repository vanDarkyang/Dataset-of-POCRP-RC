Number Of Containers
190
Number Of Yard Stacks
48
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
152
Number Of Shutout Containers
38
Yard Bay
Stack 0
S_0 Q_7 Z_100 N_8 
Stack 1
H_7 N_3 L_4 Q_2 
Stack 2
F_8 F_7 Z_101 M_6 
Stack 3
Z_102 Q_4 K_5 E_6 
Stack 4
G_4 J_5 J_7 L_2 
Stack 5
G_2 F_1 M_10 Z_103 
Stack 6
S_1 C_3 Q_0 Z_104 
Stack 7
R_5 N_2 Z_105 E_0 
Stack 8
D_2 M_4 K_0 R_0 
Stack 9
C_1 M_7 O_0 B_1 
Stack 10
N_0 Z_106 I_0 L_1 
Stack 11
C_5 Q_6 E_5 H_6 
Stack 12
E_7 R_6 M_2 Z_107 
Stack 13
D_1 N_7 J_1 R_3 
Stack 14
B_0 K_7 P_6 D_0 
Stack 15
E_2 P_4 C_4 A_1 
Stack 16
Z_108 J_10 M_0 Z_109 
Stack 17
F_6 I_1 O_6 Z_110 
Stack 18
N_4 G_6 M_9 Z_111 
Stack 19
J_4 I_5 Z_112 D_3 
Stack 20
T_0 Z_113 N_1 L_6 
Stack 21
Z_114 T_1 H_2 Z_115 
Stack 22
F_9 H_4 O_3 I_3 
Stack 23
Z_116 Z_117 Z_118 P_0 
Stack 24
Z_119 Z_120 R_2 Z_121 
Stack 25
M_1 L_5 Z_122 G_5 
Stack 26
Z_123 Z_124 Z_125 I_4 
Stack 27
B_2 H_1 A_3 D_4 
Stack 28
T_3 N_9 O_2 J_9 
Stack 29
C_2 Z_126 Z_127 F_5 
Stack 30
J_8 P_5 Z_128 B_3 
Stack 31
R_4 M_8 J_3 I_2 
Stack 32
J_2 Z_129 M_3 Q_1 
Stack 33
H_3 H_5 J_0 J_11 
Stack 34
I_7 S_2 O_4 Z_130 
Stack 35
K_1 F_0 R_1 L_7 
Stack 36
G_0 K_2 G_7 T_2 
Stack 37
H_0 F_2 O_1 F_3 
Stack 38
G_1 M_5 G_3 E_1 
Stack 39
Q_5 N_5 L_8 Z_131 
Stack 40
J_6 E_3 N_6 I_6 
Stack 41
C_0 Z_132 A_2 L_0 
Stack 42
L_3 E_4 J_12 Z_133 
Stack 43
K_8 K_3 P_1 Z_134 
Stack 44
Z_135 L_9 P_3 K_4 
Stack 45
F_4 P_7 O_5 Z_136 
Stack 46
B_4 A_0 P_2 
Stack 47
K_6 Q_3 Z_137 
