Number Of Containers
290
Number Of Yard Stacks
55
MaxTier of Yard Stacks
8
Number of Vessel Stacks
20
Number Of Export Containers
232
Number Of Shutout Containers
58
Yard Bay
Stack 0
M_12 G_4 J_12 P_5 Z_100 K_7 
Stack 1
C_2 T_1 N_6 E_1 D_4 J_11 
Stack 2
J_10 M_2 B_0 I_6 I_2 P_11 
Stack 3
A_0 T_0 M_4 J_14 Z_101 Z_102 
Stack 4
I_8 G_11 D_6 H_3 Q_3 L_5 
Stack 5
Q_7 F_6 P_7 Z_103 J_5 P_4 
Stack 6
T_8 L_2 Z_104 A_5 O_5 T_3 
Stack 7
Z_105 E_9 Z_106 Z_107 Z_108 J_4 
Stack 8
Z_109 O_3 Z_110 Q_5 D_9 J_3 
Stack 9
G_2 K_11 Z_111 H_8 O_8 B_2 
Stack 10
P_9 S_3 G_5 H_11 Z_112 Z_113 
Stack 11
A_6 Z_114 G_12 S_4 F_8 Z_115 
Stack 12
P_12 Z_116 K_1 B_1 S_1 D_11 
Stack 13
S_5 Z_117 L_7 O_9 M_8 Z_118 
Stack 14
T_5 K_10 M_5 R_7 R_0 Z_119 
Stack 15
M_6 C_0 H_5 N_3 Z_120 
Stack 16
E_10 J_7 H_4 Z_121 C_5 
Stack 17
J_2 E_8 Q_8 E_11 Q_0 
Stack 18
G_1 I_9 Z_122 G_0 R_9 
Stack 19
N_8 G_7 G_13 Z_123 G_3 
Stack 20
N_5 H_2 H_9 Z_124 H_6 
Stack 21
M_3 M_0 H_7 T_4 A_4 
Stack 22
I_10 F_11 O_6 P_2 C_6 
Stack 23
Z_125 L_11 C_3 T_9 R_5 
Stack 24
G_9 Q_2 L_12 L_13 P_10 
Stack 25
D_7 Z_126 F_10 P_3 H_13 
Stack 26
F_7 Z_127 Z_128 Z_129 G_6 
Stack 27
T_2 K_4 J_13 O_0 Z_130 
Stack 28
Z_131 A_3 R_6 Z_132 R_4 
Stack 29
L_6 I_5 N_2 R_1 B_3 
Stack 30
D_8 I_1 F_5 D_2 F_0 
Stack 31
Z_133 Z_134 K_3 S_2 Z_135 
Stack 32
L_1 A_7 O_13 L_3 A_2 
Stack 33
K_9 I_3 S_0 N_7 M_14 
Stack 34
H_10 F_3 Z_136 L_10 F_1 
Stack 35
E_0 G_8 Q_9 Q_4 O_7 
Stack 36
Z_137 C_4 M_9 R_8 Z_138 
Stack 37
M_13 Z_139 D_10 H_0 Z_140 
Stack 38
E_3 R_3 J_8 Z_141 Z_142 
Stack 39
L_4 A_1 F_9 O_4 C_1 
Stack 40
H_12 K_8 H_1 Z_143 Z_144 
Stack 41
K_6 K_5 M_1 Q_1 K_0 
Stack 42
J_9 C_7 Q_6 D_3 D_0 
Stack 43
Z_145 Z_146 M_7 N_9 F_4 
Stack 44
L_0 Z_147 Z_148 L_8 M_10 
Stack 45
J_0 D_1 Z_149 O_2 P_1 
Stack 46
I_12 B_6 E_2 T_6 K_13 
Stack 47
R_2 I_0 N_0 K_12 F_12 
Stack 48
E_4 I_4 Z_150 O_12 M_11 
Stack 49
Z_151 Z_152 L_9 E_7 Z_153 
Stack 50
F_2 E_6 E_5 Z_154 P_8 
Stack 51
J_1 I_11 T_7 I_7 N_1 
Stack 52
K_2 O_10 Z_155 O_1 G_10 
Stack 53
B_4 D_5 N_4 O_11 P_6 
Stack 54
J_6 B_5 Z_156 Z_157 P_0 
