Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 J_0 D_2 D_4 I_0 
Stack 1
B_3 H_4 E_4 J_3 Z_101 
Stack 2
Z_102 B_1 F_2 G_0 Z_103 
Stack 3
F_5 E_0 B_0 E_3 H_3 
Stack 4
Z_104 H_2 Z_105 B_4 A_3 
Stack 5
F_1 D_1 C_0 Z_106 D_0 
Stack 6
I_2 Z_107 E_6 A_1 G_1 
Stack 7
G_2 E_2 A_4 F_4 C_2 
Stack 8
Z_108 E_1 Z_109 B_5 I_3 
Stack 9
H_5 I_1 J_2 D_3 F_3 
Stack 10
F_7 F_0 C_3 H_6 G_4 
Stack 11
C_4 A_0 Z_110 B_2 Z_111 
Stack 12
H_1 E_5 J_1 H_0 G_3 
Stack 13
Z_112 A_2 F_6 C_1 Z_113 
