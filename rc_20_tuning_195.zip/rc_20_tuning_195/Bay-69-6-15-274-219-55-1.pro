Number Of Containers
274
Number Of Yard Stacks
69
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
219
Number Of Shutout Containers
55
Yard Bay
Stack 0
J_3 K_14 H_20 D_1 
Stack 1
D_0 O_7 O_9 O_2 
Stack 2
N_10 G_11 B_3 F_14 
Stack 3
J_9 J_0 E_10 E_13 
Stack 4
J_5 M_5 Z_100 A_6 
Stack 5
E_11 Z_101 Z_102 E_1 
Stack 6
N_7 O_10 K_4 Z_103 
Stack 7
A_8 G_17 Z_104 A_1 
Stack 8
F_13 Z_105 L_1 Z_106 
Stack 9
K_0 F_1 A_11 L_13 
Stack 10
Z_107 H_16 Z_108 L_11 
Stack 11
Z_109 H_4 Z_110 H_18 
Stack 12
Z_111 Z_112 F_7 H_19 
Stack 13
Z_113 D_10 Z_114 N_2 
Stack 14
H_0 F_11 E_3 N_9 
Stack 15
G_6 O_4 Z_115 Z_116 
Stack 16
Z_117 Z_118 M_3 F_6 
Stack 17
E_8 H_7 B_9 G_14 
Stack 18
C_5 L_8 K_3 E_4 
Stack 19
E_12 Z_119 Z_120 A_10 
Stack 20
I_3 D_6 Z_121 J_14 
Stack 21
C_10 I_13 B_2 H_11 
Stack 22
D_13 J_7 D_11 N_5 
Stack 23
A_7 G_0 M_9 I_4 
Stack 24
Z_122 H_5 J_1 L_9 
Stack 25
Z_123 O_5 J_11 I_5 
Stack 26
J_15 J_10 N_4 C_6 
Stack 27
E_5 C_4 L_14 H_21 
Stack 28
L_2 B_0 Z_124 E_7 
Stack 29
M_12 H_10 L_0 M_2 
Stack 30
D_12 B_1 I_1 H_1 
Stack 31
B_8 F_3 M_0 H_15 
Stack 32
C_7 O_0 K_6 I_0 
Stack 33
F_0 K_5 K_10 N_8 
Stack 34
M_8 Z_125 Z_126 J_6 
Stack 35
K_12 G_16 A_0 G_7 
Stack 36
D_9 A_5 N_0 L_7 
Stack 37
H_17 C_9 B_4 Z_127 
Stack 38
D_5 A_9 N_1 M_11 
Stack 39
J_4 Z_128 Z_129 A_4 
Stack 40
Z_130 K_9 E_6 E_0 
Stack 41
A_12 G_3 H_2 J_2 
Stack 42
D_2 Z_131 G_8 K_1 
Stack 43
H_14 H_6 L_6 C_8 
Stack 44
I_2 C_3 G_2 K_7 
Stack 45
Z_132 A_2 D_7 C_2 
Stack 46
L_4 C_11 Z_133 H_9 
Stack 47
E_2 M_4 Z_134 Z_135 
Stack 48
F_8 Z_136 I_8 J_12 
Stack 49
F_5 B_7 L_3 B_10 
Stack 50
Z_137 Z_138 D_4 H_12 
Stack 51
A_13 L_10 D_3 F_4 
Stack 52
I_6 Z_139 Z_140 L_12 
Stack 53
G_5 G_13 B_11 F_9 
Stack 54
M_10 L_5 Z_141 A_3 
Stack 55
F_12 K_13 G_1 H_13 
Stack 56
M_1 H_8 O_8 I_10 
Stack 57
I_7 O_6 N_6 E_15 
Stack 58
K_2 G_12 D_8 Z_142 
Stack 59
Z_143 E_14 Z_144 B_6 
Stack 60
G_4 M_13 G_15 H_3 
Stack 61
N_3 I_12 G_10 O_3 
Stack 62
Z_145 Z_146 I_9 Z_147 
Stack 63
Z_148 Z_149 C_1 C_0 
Stack 64
K_8 I_11 B_5 M_6 
Stack 65
Z_150 J_8 Z_151 Z_152 
Stack 66
Z_153 F_2 J_13 F_10 
Stack 67
O_1 G_9 E_9 
Stack 68
Z_154 M_7 K_11 
