Number Of Containers
190
Number Of Yard Stacks
48
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
152
Number Of Shutout Containers
38
Yard Bay
Stack 0
M_10 H_0 Q_5 J_2 
Stack 1
P_5 K_6 Z_100 Z_101 
Stack 2
O_1 J_6 G_0 S_5 
Stack 3
Z_102 F_6 Q_4 H_3 
Stack 4
I_0 E_0 L_4 H_7 
Stack 5
Z_103 E_1 A_4 N_1 
Stack 6
D_0 K_5 K_7 M_7 
Stack 7
H_4 Z_104 J_4 C_5 
Stack 8
C_4 Q_2 C_6 M_4 
Stack 9
A_2 P_4 Z_105 R_0 
Stack 10
H_2 Q_3 M_1 Z_106 
Stack 11
A_3 J_3 R_4 Z_107 
Stack 12
B_2 K_8 E_8 M_0 
Stack 13
F_9 Z_108 Z_109 R_2 
Stack 14
L_3 M_11 G_3 Z_110 
Stack 15
E_2 Z_111 Z_112 N_2 
Stack 16
Z_113 N_7 Q_1 K_9 
Stack 17
O_2 M_2 Z_114 C_2 
Stack 18
Z_115 F_3 T_4 B_3 
Stack 19
Q_0 R_3 Z_116 S_3 
Stack 20
K_0 F_7 M_9 I_7 
Stack 21
K_4 K_2 S_2 Z_117 
Stack 22
H_5 F_0 N_6 B_4 
Stack 23
J_7 N_8 D_2 P_3 
Stack 24
E_5 H_1 S_1 B_0 
Stack 25
L_0 P_1 I_4 I_2 
Stack 26
L_5 I_3 T_1 G_2 
Stack 27
F_1 Z_118 F_2 Z_119 
Stack 28
G_6 Z_120 A_0 N_3 
Stack 29
N_9 E_4 N_0 C_3 
Stack 30
Z_121 M_3 Z_122 H_8 
Stack 31
E_6 Z_123 I_6 K_1 
Stack 32
F_4 Z_124 D_5 O_3 
Stack 33
M_5 Q_6 G_5 B_1 
Stack 34
O_6 O_4 G_1 E_3 
Stack 35
L_1 C_0 S_4 D_3 
Stack 36
Z_125 A_1 T_3 P_2 
Stack 37
K_3 G_4 N_4 Z_126 
Stack 38
O_7 J_5 C_1 Z_127 
Stack 39
Z_128 H_6 L_6 P_0 
Stack 40
Z_129 Z_130 T_0 O_0 
Stack 41
J_1 L_2 Z_131 Z_132 
Stack 42
Z_133 Z_134 J_0 P_6 
Stack 43
D_4 Z_135 P_7 N_5 
Stack 44
T_2 F_5 Z_136 R_1 
Stack 45
Z_137 O_5 E_7 M_8 
Stack 46
M_6 D_1 S_0 
Stack 47
I_1 F_8 I_5 
