Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
H_5 F_4 Z_100 I_4 B_2 
Stack 1
D_3 E_3 E_4 J_0 H_0 
Stack 2
F_6 F_5 B_0 H_3 C_0 
Stack 3
Z_101 D_2 A_3 Z_102 C_2 
Stack 4
B_4 D_5 H_6 B_3 F_0 
Stack 5
G_0 D_1 H_1 C_1 F_2 
Stack 6
Z_103 D_0 Z_104 Z_105 I_2 
Stack 7
D_4 A_2 G_2 G_1 C_3 
Stack 8
Z_106 I_3 B_1 H_4 C_4 
Stack 9
Z_107 Z_108 Z_109 G_3 J_1 
Stack 10
J_2 G_5 F_3 A_0 E_2 
Stack 11
G_4 G_7 J_3 I_0 E_1 
Stack 12
Z_110 E_0 Z_111 H_2 A_1 
Stack 13
Z_112 Z_113 I_1 G_6 F_1 
