Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
J_6 I_3 I_0 E_3 F_1 H_0 
Stack 1
F_3 K_0 I_2 O_0 N_2 E_2 
Stack 2
Z_100 N_0 I_6 G_9 I_8 Z_101 
Stack 3
Z_102 D_2 Z_103 D_0 Z_104 Z_105 
Stack 4
B_3 O_1 C_1 G_8 Z_106 
Stack 5
F_6 J_2 H_3 D_4 B_4 
Stack 6
F_2 K_5 G_7 F_7 F_0 
Stack 7
E_0 Z_107 H_5 A_0 N_3 
Stack 8
B_5 H_2 I_7 J_0 A_3 
Stack 9
D_1 L_2 Z_108 Z_109 I_5 
Stack 10
Z_110 Z_111 H_4 F_4 K_3 
Stack 11
A_1 Z_112 G_5 C_3 G_3 
Stack 12
Z_113 Z_114 I_9 Z_115 Z_116 
Stack 13
J_7 L_0 Z_117 M_4 K_2 
Stack 14
D_3 G_1 M_2 O_2 K_1 
Stack 15
I_4 C_0 Z_118 Z_119 M_6 
Stack 16
Z_120 H_1 J_4 Z_121 B_0 
Stack 17
G_4 F_5 J_5 I_10 Z_122 
Stack 18
G_6 Z_123 M_5 B_2 H_6 
Stack 19
E_1 O_3 N_1 H_7 C_4 
Stack 20
M_3 M_1 M_0 G_2 I_1 
Stack 21
L_1 L_3 K_4 N_4 E_4 
Stack 22
J_3 B_1 C_2 Z_124 O_4 
Stack 23
L_4 A_2 L_5 J_1 G_0 
