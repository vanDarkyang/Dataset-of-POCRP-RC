Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_6 D_9 A_2 C_0 Z_100 
Stack 1
Z_101 D_0 C_9 E_0 Z_102 
Stack 2
B_3 A_3 A_5 E_5 A_1 
Stack 3
Z_103 Z_104 Z_105 B_0 C_6 
Stack 4
Z_106 C_10 D_7 Z_107 B_2 
Stack 5
C_11 B_7 D_5 E_3 D_8 
Stack 6
Z_108 C_1 E_4 B_5 C_3 
Stack 7
C_7 A_0 D_1 C_5 E_2 
Stack 8
C_2 B_4 E_1 C_8 D_4 
Stack 9
A_4 A_6 D_3 D_6 B_1 
Stack 10
D_2 C_4 Z_109 Z_110 
