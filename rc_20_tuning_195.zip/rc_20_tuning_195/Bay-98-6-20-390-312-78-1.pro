Number Of Containers
390
Number Of Yard Stacks
98
MaxTier of Yard Stacks
6
Number of Vessel Stacks
20
Number Of Export Containers
312
Number Of Shutout Containers
78
Yard Bay
Stack 0
Z_100 P_1 H_14 Z_101 
Stack 1
Q_2 Q_9 L_2 I_8 
Stack 2
Z_102 N_7 J_11 Z_103 
Stack 3
J_16 C_10 J_4 B_0 
Stack 4
Q_13 E_12 L_1 L_3 
Stack 5
F_7 O_18 D_9 H_17 
Stack 6
M_0 Z_104 Z_105 O_16 
Stack 7
Z_106 C_0 L_15 Z_107 
Stack 8
Z_108 K_13 T_7 J_7 
Stack 9
D_11 A_2 O_15 P_8 
Stack 10
Z_109 Q_11 Q_4 T_9 
Stack 11
Q_0 Z_110 F_1 Z_111 
Stack 12
G_4 A_7 Q_16 S_4 
Stack 13
E_10 F_3 L_19 Z_112 
Stack 14
I_6 J_8 H_12 A_9 
Stack 15
R_15 L_8 K_7 M_15 
Stack 16
Z_113 P_4 T_0 O_10 
Stack 17
T_4 R_13 Z_114 S_13 
Stack 18
D_2 E_5 F_4 N_2 
Stack 19
Z_115 H_6 Z_116 Z_117 
Stack 20
Z_118 F_15 L_12 G_9 
Stack 21
H_15 I_3 C_11 R_0 
Stack 22
F_5 O_14 Z_119 K_0 
Stack 23
Z_120 R_3 H_5 O_9 
Stack 24
O_12 R_11 O_11 P_9 
Stack 25
I_2 D_0 R_4 Q_12 
Stack 26
Z_121 A_8 R_10 I_0 
Stack 27
G_1 K_2 S_1 O_3 
Stack 28
B_2 K_11 L_10 L_14 
Stack 29
Q_7 B_3 Z_122 T_1 
Stack 30
H_7 J_13 L_13 Z_123 
Stack 31
I_17 P_0 Z_124 Z_125 
Stack 32
S_10 A_4 F_8 D_10 
Stack 33
R_14 Q_6 Z_126 B_12 
Stack 34
C_12 Z_127 D_13 T_13 
Stack 35
B_5 I_5 Z_128 T_6 
Stack 36
K_15 O_7 P_6 Q_15 
Stack 37
C_5 Z_129 R_8 L_5 
Stack 38
Z_130 M_20 Z_131 Z_132 
Stack 39
H_11 G_3 J_5 B_1 
Stack 40
Z_133 L_7 M_4 R_5 
Stack 41
O_5 R_12 Z_134 Z_135 
Stack 42
N_16 Q_10 K_10 E_13 
Stack 43
J_15 H_3 P_10 Z_136 
Stack 44
L_6 I_16 A_5 L_18 
Stack 45
J_9 P_5 E_6 Z_137 
Stack 46
T_12 G_5 J_10 S_11 
Stack 47
I_11 P_3 Q_1 L_16 
Stack 48
Z_138 M_19 S_6 T_8 
Stack 49
B_10 J_14 R_2 Q_3 
Stack 50
R_9 J_3 N_10 E_1 
Stack 51
Z_139 D_4 D_3 B_9 
Stack 52
Z_140 Z_141 Z_142 Z_143 
Stack 53
F_11 L_0 T_2 I_12 
Stack 54
J_2 L_9 N_11 P_12 
Stack 55
B_8 N_15 A_1 N_12 
Stack 56
F_2 Z_144 Z_145 O_2 
Stack 57
B_6 M_11 H_1 C_3 
Stack 58
Z_146 S_3 E_4 Z_147 
Stack 59
M_10 B_7 I_9 H_13 
Stack 60
K_12 M_14 Z_148 P_2 
Stack 61
Z_149 Z_150 D_12 I_10 
Stack 62
H_0 J_0 Z_151 T_10 
Stack 63
K_14 G_7 N_9 K_4 
Stack 64
I_15 E_2 I_14 N_6 
Stack 65
E_8 T_5 S_5 I_4 
Stack 66
K_3 S_2 O_13 Z_152 
Stack 67
H_16 Z_153 R_6 Z_154 
Stack 68
E_7 E_0 K_6 F_14 
Stack 69
D_7 M_9 B_11 I_1 
Stack 70
D_5 J_6 D_6 O_8 
Stack 71
F_10 M_6 Z_155 D_1 
Stack 72
C_7 E_3 O_4 F_13 
Stack 73
E_9 Z_156 M_16 J_12 
Stack 74
N_0 Z_157 R_7 N_13 
Stack 75
K_8 G_6 C_9 Z_158 
Stack 76
N_17 Z_159 Z_160 F_6 
Stack 77
H_10 M_5 C_6 F_9 
Stack 78
T_11 B_13 M_8 R_1 
Stack 79
G_8 O_0 Z_161 K_9 
Stack 80
D_8 A_0 S_0 M_13 
Stack 81
P_11 M_12 N_1 Z_162 
Stack 82
M_3 G_0 J_1 H_2 
Stack 83
T_3 C_4 Z_163 Z_164 
Stack 84
E_11 L_11 Z_165 Z_166 
Stack 85
I_7 F_0 M_1 Z_167 
Stack 86
G_2 Z_168 Q_8 S_8 
Stack 87
Q_5 S_7 Z_169 A_3 
Stack 88
L_4 Z_170 Q_14 Z_171 
Stack 89
Z_172 C_2 C_8 N_4 
Stack 90
N_14 O_1 M_17 I_13 
Stack 91
C_1 P_7 N_8 K_5 
Stack 92
Z_173 K_1 B_4 H_8 
Stack 93
Z_174 M_18 N_5 Z_175 
Stack 94
S_9 F_12 M_2 N_3 
Stack 95
S_12 H_9 O_6 A_6 
Stack 96
M_7 H_4 O_17 
Stack 97
L_17 Z_176 Z_177 
