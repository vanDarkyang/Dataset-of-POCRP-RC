Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
E_4 H_2 C_1 H_0 
Stack 1
B_3 D_2 J_3 C_0 
Stack 2
F_0 Z_100 C_3 I_0 
Stack 3
F_4 E_2 D_3 D_1 
Stack 4
Z_101 E_1 J_2 G_4 
Stack 5
F_1 Z_102 F_5 H_3 
Stack 6
Z_103 Z_104 D_6 Z_105 
Stack 7
G_2 A_0 J_4 D_0 
Stack 8
Z_106 Z_107 G_0 G_1 
Stack 9
H_5 A_2 Z_108 C_2 
Stack 10
F_6 D_4 Z_109 I_3 
Stack 11
Z_110 E_3 J_1 F_3 
Stack 12
H_1 F_2 A_1 G_5 
Stack 13
Z_111 B_0 Z_112 G_6 
Stack 14
J_0 I_1 B_4 G_3 
Stack 15
H_4 Z_113 D_5 I_2 
Stack 16
B_1 E_5 H_6 
Stack 17
E_0 A_3 B_2 
