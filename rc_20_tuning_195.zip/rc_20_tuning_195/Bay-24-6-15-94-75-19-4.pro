Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
G_5 Z_100 L_1 D_4 
Stack 1
E_4 F_4 E_1 L_0 
Stack 2
Z_101 H_0 I_4 H_4 
Stack 3
N_0 H_6 I_1 J_4 
Stack 4
A_1 G_6 I_0 L_2 
Stack 5
D_1 G_7 G_3 Z_102 
Stack 6
F_0 L_3 G_8 G_4 
Stack 7
H_2 B_2 M_1 H_5 
Stack 8
C_2 Z_103 K_3 C_0 
Stack 9
A_2 Z_104 E_5 Z_105 
Stack 10
O_2 N_2 K_4 J_5 
Stack 11
A_0 G_0 M_2 B_1 
Stack 12
E_3 G_2 K_2 I_5 
Stack 13
J_3 D_0 Z_106 B_3 
Stack 14
Z_107 J_1 Z_108 H_3 
Stack 15
Z_109 F_5 Z_110 I_2 
Stack 16
K_1 Z_111 Z_112 E_2 
Stack 17
Z_113 Z_114 M_4 K_0 
Stack 18
J_2 I_3 G_1 M_0 
Stack 19
H_1 J_0 M_3 C_1 
Stack 20
F_1 B_0 D_2 Z_115 
Stack 21
F_3 O_0 O_1 D_3 
Stack 22
E_0 Z_116 Z_117 
Stack 23
F_2 N_1 Z_118 
