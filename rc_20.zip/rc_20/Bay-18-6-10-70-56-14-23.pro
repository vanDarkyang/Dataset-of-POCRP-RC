Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
G_0 E_3 Z_100 A_2 
Stack 1
A_4 H_0 C_0 I_1 
Stack 2
A_3 Z_101 F_3 E_2 
Stack 3
D_1 E_5 B_0 Z_102 
Stack 4
G_2 F_6 G_3 I_0 
Stack 5
C_4 D_2 C_1 Z_103 
Stack 6
C_2 B_3 E_6 Z_104 
Stack 7
D_7 C_3 F_5 G_5 
Stack 8
D_5 F_0 F_2 Z_105 
Stack 9
E_4 F_4 F_1 Z_106 
Stack 10
Z_107 D_4 B_1 D_0 
Stack 11
Z_108 E_0 G_4 G_6 
Stack 12
I_3 Z_109 B_4 H_1 
Stack 13
I_2 C_5 Z_110 D_3 
Stack 14
A_0 G_7 Z_111 A_1 
Stack 15
J_1 B_2 C_6 D_6 
Stack 16
J_0 Z_112 Z_113 
Stack 17
H_2 G_1 E_1 
