Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_4 F_2 A_3 H_6 
Stack 1
B_3 J_2 I_2 D_2 
Stack 2
G_1 B_4 B_5 C_0 
Stack 3
C_2 Z_100 J_1 E_6 
Stack 4
J_3 G_3 F_3 E_5 
Stack 5
A_0 G_4 I_1 Z_101 
Stack 6
D_0 Z_102 J_4 H_3 
Stack 7
E_1 A_4 B_0 H_5 
Stack 8
Z_103 H_4 F_1 Z_104 
Stack 9
Z_105 G_0 Z_106 B_1 
Stack 10
H_0 C_1 D_1 E_3 
Stack 11
F_4 Z_107 A_1 H_1 
Stack 12
J_0 I_0 D_3 Z_108 
Stack 13
B_2 E_2 Z_109 Z_110 
Stack 14
C_3 A_2 E_0 C_4 
Stack 15
I_3 E_4 F_0 G_2 
Stack 16
Z_111 Z_112 H_2 
Stack 17
D_5 F_5 Z_113 
