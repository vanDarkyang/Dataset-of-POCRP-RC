Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_6 B_5 A_7 Z_100 
Stack 1
B_2 B_6 B_8 B_11 
Stack 2
C_1 B_3 C_5 A_1 
Stack 3
A_9 B_1 A_8 C_0 
Stack 4
C_2 B_0 C_6 C_3 
Stack 5
Z_101 C_4 Z_102 C_7 
Stack 6
B_10 A_11 B_4 C_8 
Stack 7
A_2 Z_103 A_4 Z_104 
Stack 8
Z_105 B_7 C_9 B_9 
Stack 9
A_10 A_3 Z_106 Z_107 
Stack 10
Z_108 Z_109 B_12 
Stack 11
A_12 A_0 A_5 
