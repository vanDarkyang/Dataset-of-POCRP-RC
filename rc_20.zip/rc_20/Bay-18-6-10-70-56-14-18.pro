Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_0 H_1 D_1 Z_100 
Stack 1
H_0 G_0 C_3 C_5 
Stack 2
Z_101 Z_102 Z_103 G_2 
Stack 3
E_0 D_6 I_1 Z_104 
Stack 4
F_2 J_1 I_0 Z_105 
Stack 5
H_5 A_3 G_6 I_2 
Stack 6
A_0 B_0 Z_106 A_2 
Stack 7
G_7 E_3 Z_107 C_4 
Stack 8
F_1 D_7 E_2 H_4 
Stack 9
G_1 H_2 Z_108 Z_109 
Stack 10
E_6 A_1 D_2 G_3 
Stack 11
D_5 H_3 F_5 G_4 
Stack 12
B_2 E_5 E_1 F_3 
Stack 13
J_0 C_0 C_1 Z_110 
Stack 14
C_2 F_0 E_4 B_1 
Stack 15
D_3 F_6 G_5 Z_111 
Stack 16
F_4 D_4 Z_112 
Stack 17
J_2 F_7 Z_113 
