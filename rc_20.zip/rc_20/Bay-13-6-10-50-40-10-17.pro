Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_0 B_1 Z_100 D_1 
Stack 1
C_0 G_3 H_1 B_2 
Stack 2
E_1 J_1 Z_101 H_2 
Stack 3
E_0 E_4 I_0 F_0 
Stack 4
G_4 J_0 C_1 D_3 
Stack 5
G_1 B_3 A_0 H_3 
Stack 6
Z_102 C_4 D_0 Z_103 
Stack 7
F_3 C_2 D_2 I_1 
Stack 8
E_2 F_2 G_2 I_2 
Stack 9
F_1 Z_104 Z_105 F_5 
Stack 10
H_0 F_4 Z_106 Z_107 
Stack 11
Z_108 F_6 Z_109 
Stack 12
G_0 E_3 C_3 
