Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
E_1 D_10 C_15 Z_100 
Stack 1
B_12 A_6 B_9 B_5 
Stack 2
D_3 B_6 D_6 C_1 
Stack 3
D_5 Z_101 A_7 C_6 
Stack 4
E_5 C_9 C_5 E_0 
Stack 5
A_10 C_12 D_0 D_8 
Stack 6
A_0 D_7 A_2 A_3 
Stack 7
C_13 C_11 D_2 Z_102 
Stack 8
B_2 D_4 A_9 E_8 
Stack 9
Z_103 Z_104 Z_105 A_8 
Stack 10
E_3 A_4 Z_106 Z_107 
Stack 11
C_8 D_1 A_1 E_4 
Stack 12
Z_108 C_10 B_7 Z_109 
Stack 13
B_1 C_2 E_7 C_7 
Stack 14
A_11 B_10 D_9 B_4 
Stack 15
E_9 C_16 C_0 E_2 
Stack 16
Z_110 E_6 B_3 Z_111 
Stack 17
C_14 B_8 Z_112 Z_113 
Stack 18
Z_114 B_11 A_5 C_3 
Stack 19
Z_115 B_0 C_4 
