Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_1 B_1 Z_100 A_10 
Stack 1
Z_101 Z_102 C_0 C_4 
Stack 2
A_7 B_10 B_3 C_10 
Stack 3
B_7 B_5 C_3 Z_103 
Stack 4
A_3 C_9 C_1 A_11 
Stack 5
B_2 A_8 C_8 B_9 
Stack 6
Z_104 Z_105 C_2 B_6 
Stack 7
B_4 A_2 B_11 C_6 
Stack 8
A_4 A_0 Z_106 A_9 
Stack 9
C_7 A_12 Z_107 A_6 
Stack 10
Z_108 B_8 Z_109 
Stack 11
B_0 C_5 A_5 
