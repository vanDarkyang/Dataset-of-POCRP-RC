Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
C_2 D_0 J_2 Z_100 M_0 Z_101 
Stack 1
N_3 F_2 K_5 O_1 J_1 H_1 
Stack 2
F_3 E_3 H_2 Z_102 D_5 K_0 
Stack 3
B_3 Z_103 Z_104 M_3 L_2 K_1 
Stack 4
C_3 M_2 K_3 H_0 N_0 
Stack 5
D_4 D_2 Z_105 I_5 N_2 
Stack 6
E_2 Z_106 Z_107 K_2 Z_108 
Stack 7
G_3 K_4 I_2 A_0 B_1 
Stack 8
G_0 H_6 O_2 I_0 N_1 
Stack 9
Z_109 C_4 Z_110 Z_111 B_0 
Stack 10
I_3 C_0 E_1 C_1 I_1 
Stack 11
H_7 Z_112 Z_113 J_3 D_3 
Stack 12
Z_114 L_1 L_3 F_1 Z_115 
Stack 13
L_4 L_0 E_0 H_5 Z_116 
Stack 14
I_4 Z_117 H_4 J_0 J_5 
Stack 15
G_1 Z_118 H_3 G_4 B_2 
Stack 16
F_0 J_6 G_2 J_4 H_8 
Stack 17
M_1 D_1 A_1 O_0 G_5 
