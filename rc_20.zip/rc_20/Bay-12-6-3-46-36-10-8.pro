Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_8 A_2 B_10 A_10 
Stack 1
C_9 C_5 C_1 C_12 
Stack 2
B_0 Z_100 C_3 A_1 
Stack 3
A_3 C_10 C_11 Z_101 
Stack 4
C_2 A_8 A_6 B_4 
Stack 5
A_7 Z_102 A_4 Z_103 
Stack 6
Z_104 B_7 B_6 Z_105 
Stack 7
Z_106 Z_107 B_1 B_11 
Stack 8
B_5 C_4 B_2 A_9 
Stack 9
B_9 A_0 C_0 B_3 
Stack 10
A_5 C_7 C_8 
Stack 11
Z_108 Z_109 C_6 
