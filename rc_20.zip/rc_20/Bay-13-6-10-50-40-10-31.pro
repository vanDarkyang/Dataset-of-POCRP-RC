Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 C_3 H_3 Z_101 
Stack 1
H_1 F_0 H_0 F_3 
Stack 2
D_1 D_2 G_4 A_1 
Stack 3
D_3 Z_102 E_3 F_2 
Stack 4
I_1 C_1 J_2 B_1 
Stack 5
E_4 I_0 F_1 E_0 
Stack 6
Z_103 G_2 Z_104 Z_105 
Stack 7
Z_106 G_3 Z_107 J_1 
Stack 8
H_2 G_0 C_4 Z_108 
Stack 9
E_5 B_2 G_1 J_0 
Stack 10
E_1 A_0 Z_109 E_2 
Stack 11
D_0 B_0 D_4 
Stack 12
C_2 C_0 B_3 
