Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
N_0 B_0 L_0 Z_100 
Stack 1
F_1 Z_101 J_1 M_3 
Stack 2
D_1 F_0 A_1 Z_102 
Stack 3
E_5 L_1 H_7 M_1 
Stack 4
C_3 Z_103 J_2 F_2 
Stack 5
Z_104 E_0 C_2 Z_105 
Stack 6
G_3 G_2 H_6 E_3 
Stack 7
Z_106 G_6 G_5 H_5 
Stack 8
O_0 J_3 L_2 B_1 
Stack 9
F_5 M_2 K_0 I_3 
Stack 10
Z_107 H_2 O_1 Z_108 
Stack 11
K_6 K_4 D_4 Z_109 
Stack 12
E_4 D_3 J_0 E_1 
Stack 13
A_0 Z_110 L_5 H_1 
Stack 14
N_2 M_0 Z_111 H_4 
Stack 15
G_4 Z_112 K_5 D_2 
Stack 16
D_0 K_2 I_6 Z_113 
Stack 17
N_3 N_1 L_4 G_0 
Stack 18
C_0 I_5 I_0 G_1 
Stack 19
Z_114 K_1 Z_115 C_1 
Stack 20
L_3 E_2 F_3 H_0 
Stack 21
B_2 I_1 Z_116 Z_117 
Stack 22
F_4 I_2 Z_118 
Stack 23
H_3 I_4 K_3 
