Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
B_0 C_4 F_3 N_2 C_2 K_2 
Stack 1
F_6 C_1 O_3 Z_100 M_5 D_5 
Stack 2
D_6 N_0 F_4 Z_101 L_2 M_2 
Stack 3
A_0 H_2 G_1 Z_102 I_5 Z_103 
Stack 4
Z_104 F_1 O_2 Z_105 Z_106 
Stack 5
Z_107 D_1 N_3 K_6 Z_108 
Stack 6
E_3 K_4 L_1 Z_109 D_7 
Stack 7
C_0 F_2 Z_110 A_1 G_6 
Stack 8
J_3 Z_111 J_2 B_5 J_1 
Stack 9
H_9 J_5 M_1 O_1 E_1 
Stack 10
N_5 E_0 E_6 M_0 N_4 
Stack 11
Z_112 K_0 Z_113 K_1 L_0 
Stack 12
H_7 D_4 D_3 H_5 C_3 
Stack 13
E_7 Z_114 K_5 Z_115 F_7 
Stack 14
G_7 F_0 Z_116 Z_117 Z_118 
Stack 15
B_3 G_3 E_2 B_4 Z_119 
Stack 16
Z_120 Z_121 D_0 J_6 I_2 
Stack 17
D_2 H_3 O_0 L_4 J_4 
Stack 18
G_0 H_8 E_4 A_2 Z_122 
Stack 19
B_1 H_6 H_10 Z_123 I_1 
Stack 20
I_0 H_4 I_4 F_5 K_3 
Stack 21
I_3 M_4 L_3 G_2 Z_124 
Stack 22
B_2 H_1 M_3 G_4 E_5 
Stack 23
G_8 H_0 N_1 G_5 J_0 
