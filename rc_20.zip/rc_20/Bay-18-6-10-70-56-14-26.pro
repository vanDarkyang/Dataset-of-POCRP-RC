Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_4 I_2 H_3 F_7 
Stack 1
D_1 E_6 G_3 Z_100 
Stack 2
C_2 J_0 B_2 J_2 
Stack 3
E_2 B_3 F_5 A_3 
Stack 4
Z_101 G_6 B_0 Z_102 
Stack 5
I_0 G_4 E_5 E_4 
Stack 6
F_0 F_2 A_2 G_2 
Stack 7
F_4 Z_103 G_5 Z_104 
Stack 8
Z_105 Z_106 A_0 B_4 
Stack 9
Z_107 C_3 G_0 H_1 
Stack 10
F_3 B_1 H_0 E_0 
Stack 11
A_1 Z_108 C_6 Z_109 
Stack 12
I_3 C_0 D_0 C_1 
Stack 13
C_5 D_4 J_1 I_1 
Stack 14
F_6 G_1 H_2 Z_110 
Stack 15
E_1 E_3 H_4 D_2 
Stack 16
D_3 I_4 F_1 
Stack 17
Z_111 Z_112 Z_113 
