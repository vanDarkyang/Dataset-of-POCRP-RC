Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_0 G_6 G_5 Z_100 Z_101 
Stack 1
Z_102 D_0 G_2 H_4 F_1 
Stack 2
C_3 J_4 A_2 E_0 C_4 
Stack 3
C_5 I_1 E_3 E_5 H_2 
Stack 4
J_2 F_4 I_3 C_0 B_2 
Stack 5
H_3 Z_103 D_6 G_4 G_0 
Stack 6
B_1 J_3 I_2 A_1 Z_104 
Stack 7
E_1 Z_105 F_2 C_2 D_2 
Stack 8
Z_106 F_5 Z_107 F_6 J_0 
Stack 9
E_4 F_7 F_0 H_0 Z_108 
Stack 10
D_1 I_0 D_5 Z_109 J_1 
Stack 11
Z_110 Z_111 C_1 B_0 Z_112 
Stack 12
D_4 H_1 G_1 E_6 D_3 
Stack 13
G_3 Z_113 F_3 I_4 E_2 
