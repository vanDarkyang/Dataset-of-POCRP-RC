Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
D_0 F_0 E_1 Z_100 H_4 
Stack 1
Z_101 Z_102 F_1 G_5 E_3 
Stack 2
H_0 D_3 Z_103 H_2 D_4 
Stack 3
F_3 E_4 D_1 I_0 Z_104 
Stack 4
C_0 A_1 F_2 E_2 G_3 
Stack 5
C_2 E_0 H_3 Z_105 J_2 
Stack 6
D_2 I_1 A_0 B_1 Z_106 
Stack 7
Z_107 G_0 G_2 H_1 Z_108 
Stack 8
G_4 C_1 F_4 Z_109 G_1 
Stack 9
B_0 J_1 J_0 A_2 F_5 
