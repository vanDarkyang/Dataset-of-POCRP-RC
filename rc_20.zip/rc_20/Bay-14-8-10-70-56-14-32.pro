Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 Z_101 E_4 I_2 Z_102 
Stack 1
Z_103 D_1 E_2 I_0 Z_104 
Stack 2
D_5 Z_105 D_6 B_2 Z_106 
Stack 3
C_5 Z_107 F_0 E_5 G_5 
Stack 4
A_2 F_7 Z_108 H_4 G_4 
Stack 5
I_1 F_5 B_0 B_1 C_2 
Stack 6
B_3 G_2 Z_109 C_6 E_3 
Stack 7
J_2 A_1 Z_110 E_0 D_2 
Stack 8
C_1 G_6 E_1 F_6 F_3 
Stack 9
G_1 H_1 H_5 H_3 A_3 
Stack 10
C_0 G_0 Z_111 J_1 A_0 
Stack 11
C_4 D_4 D_0 H_0 Z_112 
Stack 12
G_3 F_2 J_0 H_2 C_3 
Stack 13
F_4 F_1 G_7 D_3 Z_113 
