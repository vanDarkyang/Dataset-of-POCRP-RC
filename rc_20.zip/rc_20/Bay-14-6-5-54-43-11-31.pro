Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 A_3 B_5 C_1 
Stack 1
E_2 A_4 Z_101 E_7 
Stack 2
B_7 B_1 Z_102 D_1 
Stack 3
C_2 Z_103 B_2 B_0 
Stack 4
C_9 E_6 Z_104 Z_105 
Stack 5
D_2 C_10 A_0 A_2 
Stack 6
B_3 D_4 Z_106 Z_107 
Stack 7
E_4 E_0 C_0 E_5 
Stack 8
Z_108 A_6 D_3 C_8 
Stack 9
D_0 E_8 E_3 C_6 
Stack 10
C_4 A_1 C_5 B_4 
Stack 11
E_1 Z_109 C_7 C_3 
Stack 12
D_6 D_5 Z_110 
Stack 13
B_6 A_7 A_5 
