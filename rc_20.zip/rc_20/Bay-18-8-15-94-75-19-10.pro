Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
M_0 I_1 J_2 O_2 L_4 B_3 
Stack 1
C_0 H_5 Z_100 A_2 Z_101 Z_102 
Stack 2
H_3 D_1 L_5 Z_103 Z_104 N_3 
Stack 3
Z_105 N_0 K_0 G_0 L_0 E_1 
Stack 4
G_2 C_1 D_0 B_0 M_3 
Stack 5
Z_106 H_4 J_5 A_1 F_5 
Stack 6
Z_107 M_2 I_2 B_2 Z_108 
Stack 7
F_6 D_3 J_0 N_2 L_1 
Stack 8
I_4 J_6 Z_109 F_4 E_0 
Stack 9
Z_110 Z_111 H_7 E_3 G_6 
Stack 10
C_2 J_3 J_1 K_3 I_5 
Stack 11
Z_112 Z_113 I_0 G_3 Z_114 
Stack 12
F_2 I_3 F_0 L_3 H_0 
Stack 13
Z_115 O_1 N_1 E_4 F_3 
Stack 14
D_2 H_1 Z_116 G_5 A_0 
Stack 15
K_1 E_2 G_4 L_2 H_6 
Stack 16
B_1 Z_117 H_2 K_2 O_0 
Stack 17
F_1 Z_118 G_1 J_4 M_1 
