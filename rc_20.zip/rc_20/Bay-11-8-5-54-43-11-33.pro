Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_7 Z_100 Z_101 E_8 E_2 
Stack 1
E_5 Z_102 A_3 A_1 B_7 
Stack 2
Z_103 C_7 D_7 B_4 A_5 
Stack 3
D_2 D_6 E_4 C_0 E_3 
Stack 4
C_2 D_1 A_2 D_8 B_3 
Stack 5
A_7 C_1 A_8 E_1 A_6 
Stack 6
D_0 E_6 Z_104 D_3 B_2 
Stack 7
C_5 D_5 B_5 C_3 Z_105 
Stack 8
Z_106 B_6 A_0 B_0 Z_107 
Stack 9
Z_108 Z_109 D_4 Z_110 E_0 
Stack 10
C_6 A_4 C_4 B_1 
