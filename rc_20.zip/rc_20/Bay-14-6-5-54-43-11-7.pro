Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 C_8 D_1 B_1 
Stack 1
E_0 A_6 E_3 A_5 
Stack 2
C_0 D_5 C_3 E_1 
Stack 3
Z_101 Z_102 C_5 E_2 
Stack 4
E_6 B_7 D_0 B_8 
Stack 5
Z_103 C_4 A_0 A_4 
Stack 6
A_1 B_0 A_7 Z_104 
Stack 7
B_4 C_6 Z_105 B_5 
Stack 8
C_1 C_2 E_5 A_2 
Stack 9
Z_106 D_2 E_4 D_8 
Stack 10
Z_107 D_4 E_7 A_3 
Stack 11
B_2 D_6 Z_108 C_7 
Stack 12
B_6 D_7 D_3 
Stack 13
Z_109 B_3 Z_110 
