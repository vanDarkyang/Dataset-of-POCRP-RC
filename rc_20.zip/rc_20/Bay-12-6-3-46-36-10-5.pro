Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_5 B_3 B_0 C_9 
Stack 1
B_10 A_0 B_12 C_2 
Stack 2
A_3 B_9 Z_100 A_8 
Stack 3
B_5 Z_101 C_8 Z_102 
Stack 4
Z_103 Z_104 C_7 A_1 
Stack 5
B_2 A_7 A_9 B_13 
Stack 6
C_1 A_6 Z_105 C_4 
Stack 7
A_4 B_7 A_2 C_5 
Stack 8
Z_106 C_11 Z_107 B_4 
Stack 9
B_8 B_6 Z_108 C_3 
Stack 10
C_10 B_11 C_6 
Stack 11
C_0 B_1 Z_109 
