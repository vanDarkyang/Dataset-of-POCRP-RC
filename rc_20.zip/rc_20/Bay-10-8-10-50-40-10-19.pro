Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_2 D_4 I_2 H_0 J_1 
Stack 1
F_1 H_1 F_2 D_0 B_1 
Stack 2
E_5 D_2 J_2 E_1 G_3 
Stack 3
E_3 F_0 E_4 D_5 G_2 
Stack 4
F_4 I_0 H_2 Z_100 C_1 
Stack 5
G_0 D_3 F_3 Z_101 C_0 
Stack 6
F_5 D_1 A_1 Z_102 B_0 
Stack 7
Z_103 J_0 I_3 Z_104 Z_105 
Stack 8
Z_106 A_0 Z_107 G_1 E_2 
Stack 9
E_0 Z_108 Z_109 I_1 C_2 
