Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 E_7 C_10 D_0 A_7 B_6 
Stack 1
Z_101 D_9 D_3 B_10 E_8 E_0 
Stack 2
B_3 Z_102 E_5 D_6 C_2 B_7 
Stack 3
D_4 A_6 Z_103 C_6 B_11 B_8 
Stack 4
A_10 E_9 A_9 Z_104 B_9 
Stack 5
A_5 Z_105 Z_106 A_2 Z_107 
Stack 6
A_4 Z_108 D_8 E_10 E_11 
Stack 7
Z_109 B_1 B_12 Z_110 B_4 
Stack 8
C_5 Z_111 C_11 A_8 B_2 
Stack 9
C_1 A_3 A_0 C_7 D_2 
Stack 10
Z_112 D_11 C_4 E_6 E_1 
Stack 11
D_1 D_5 Z_113 C_3 C_9 
Stack 12
Z_114 C_0 C_12 D_7 C_8 
Stack 13
A_11 A_1 B_0 B_5 D_10 
Stack 14
E_4 C_13 Z_115 E_2 E_3 
