Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 Z_101 A_4 E_3 C_0 
Stack 1
E_8 B_2 E_0 C_6 Z_102 
Stack 2
A_6 A_3 D_7 C_1 C_7 
Stack 3
Z_103 A_2 C_8 D_0 D_5 
Stack 4
Z_104 D_1 B_6 Z_105 E_6 
Stack 5
Z_106 D_8 E_1 Z_107 E_5 
Stack 6
B_4 Z_108 Z_109 D_2 C_4 
Stack 7
A_7 A_5 Z_110 E_4 E_2 
Stack 8
B_3 A_0 C_5 B_1 B_5 
Stack 9
E_7 B_0 D_4 A_1 D_3 
Stack 10
C_2 C_9 C_3 D_6 
