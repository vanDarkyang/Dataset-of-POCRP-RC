Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
I_1 B_2 E_2 Z_100 
Stack 1
Z_101 C_0 J_1 Z_102 
Stack 2
B_0 H_5 F_0 Z_103 
Stack 3
B_1 Z_104 Z_105 H_1 
Stack 4
E_6 Z_106 E_5 B_3 
Stack 5
E_1 G_1 B_5 G_3 
Stack 6
Z_107 E_4 E_7 Z_108 
Stack 7
I_0 F_2 A_2 G_0 
Stack 8
G_2 A_3 A_4 D_3 
Stack 9
J_2 H_2 E_0 F_1 
Stack 10
C_3 I_4 G_4 C_2 
Stack 11
F_4 C_1 I_3 F_5 
Stack 12
Z_109 B_4 Z_110 E_8 
Stack 13
Z_111 J_0 H_3 G_5 
Stack 14
A_1 D_1 I_2 E_3 
Stack 15
D_0 D_4 A_0 Z_112 
Stack 16
H_4 D_2 F_3 
Stack 17
H_0 Z_113 C_4 
