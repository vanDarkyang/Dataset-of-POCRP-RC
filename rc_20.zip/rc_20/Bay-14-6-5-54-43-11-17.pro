Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_2 A_7 B_4 B_1 
Stack 1
B_3 B_5 C_8 C_4 
Stack 2
A_3 C_1 A_6 D_5 
Stack 3
E_6 D_1 E_4 Z_100 
Stack 4
Z_101 C_6 Z_102 E_1 
Stack 5
D_7 A_4 D_6 D_4 
Stack 6
D_0 C_5 E_7 E_8 
Stack 7
A_0 E_2 Z_103 Z_104 
Stack 8
Z_105 C_9 D_2 A_1 
Stack 9
B_0 Z_106 C_0 A_5 
Stack 10
Z_107 Z_108 D_8 B_2 
Stack 11
C_2 C_3 Z_109 D_3 
Stack 12
B_6 C_7 E_0 
Stack 13
E_5 E_3 Z_110 
