Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_1 C_10 C_5 C_8 
Stack 1
Z_100 A_3 A_8 B_4 
Stack 2
A_1 B_10 A_9 C_6 
Stack 3
Z_101 A_2 C_9 A_6 
Stack 4
Z_102 C_11 B_9 Z_103 
Stack 5
Z_104 B_11 Z_105 B_7 
Stack 6
A_0 B_3 A_11 B_0 
Stack 7
C_7 A_4 Z_106 B_8 
Stack 8
A_10 C_3 Z_107 B_2 
Stack 9
Z_108 C_2 C_0 B_1 
Stack 10
C_4 B_6 B_5 
Stack 11
Z_109 A_7 A_5 
