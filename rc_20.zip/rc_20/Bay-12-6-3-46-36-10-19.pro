Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_1 B_6 A_4 A_1 
Stack 1
B_7 C_2 Z_100 C_3 
Stack 2
A_6 Z_101 Z_102 C_4 
Stack 3
A_3 A_2 B_0 C_6 
Stack 4
B_13 C_5 C_10 B_9 
Stack 5
A_5 B_4 B_3 C_8 
Stack 6
B_5 B_12 B_8 B_2 
Stack 7
Z_103 Z_104 A_7 Z_105 
Stack 8
A_9 C_0 Z_106 Z_107 
Stack 9
A_0 B_10 C_11 B_11 
Stack 10
Z_108 C_7 Z_109 
Stack 11
C_1 C_9 A_8 
