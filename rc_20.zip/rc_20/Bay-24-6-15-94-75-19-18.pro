Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
M_1 G_2 G_0 F_2 
Stack 1
Z_100 L_4 H_1 A_1 
Stack 2
N_0 G_5 F_3 F_7 
Stack 3
Z_101 C_0 I_4 J_1 
Stack 4
Z_102 H_3 D_4 Z_103 
Stack 5
B_3 Z_104 C_2 Z_105 
Stack 6
M_0 G_4 J_4 Z_106 
Stack 7
C_1 I_5 J_0 L_0 
Stack 8
C_3 E_3 Z_107 L_1 
Stack 9
O_1 J_3 O_0 G_7 
Stack 10
A_0 F_1 Z_108 E_1 
Stack 11
I_6 E_5 L_2 Z_109 
Stack 12
H_2 Z_110 D_3 N_1 
Stack 13
L_3 K_1 Z_111 E_2 
Stack 14
Z_112 H_4 Z_113 Z_114 
Stack 15
B_1 I_2 E_0 G_6 
Stack 16
Z_115 B_2 J_5 H_7 
Stack 17
H_0 F_0 K_0 D_1 
Stack 18
D_2 I_1 I_0 J_6 
Stack 19
J_2 I_3 Z_116 K_4 
Stack 20
H_6 Z_117 K_3 F_5 
Stack 21
H_5 D_0 E_4 G_3 
Stack 22
Z_118 B_0 K_2 
Stack 23
F_4 F_6 G_1 
