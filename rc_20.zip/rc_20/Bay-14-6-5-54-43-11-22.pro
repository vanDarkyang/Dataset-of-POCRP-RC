Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_3 C_0 D_0 D_4 
Stack 1
A_6 A_7 C_7 C_9 
Stack 2
E_5 E_4 E_2 B_0 
Stack 3
Z_100 E_6 C_10 D_1 
Stack 4
Z_101 A_1 C_5 A_4 
Stack 5
B_6 C_6 A_3 Z_102 
Stack 6
E_0 Z_103 B_3 B_5 
Stack 7
A_8 C_4 Z_104 D_2 
Stack 8
C_3 D_5 C_2 D_6 
Stack 9
Z_105 B_4 C_1 A_5 
Stack 10
C_8 B_1 Z_106 B_7 
Stack 11
E_7 A_0 E_1 Z_107 
Stack 12
B_2 D_3 Z_108 
Stack 13
Z_109 A_2 Z_110 
