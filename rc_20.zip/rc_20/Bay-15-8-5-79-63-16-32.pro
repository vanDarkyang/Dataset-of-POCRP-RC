Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
E_6 A_0 D_10 D_2 B_13 E_4 
Stack 1
B_7 E_1 E_8 Z_100 B_12 C_2 
Stack 2
Z_101 B_0 B_10 E_7 Z_102 E_11 
Stack 3
B_11 A_4 A_7 Z_103 B_9 Z_104 
Stack 4
A_3 Z_105 Z_106 D_11 Z_107 
Stack 5
A_6 D_7 A_10 B_4 B_8 
Stack 6
A_5 C_4 C_0 B_3 Z_108 
Stack 7
E_0 E_10 D_8 D_0 C_1 
Stack 8
A_11 B_2 E_9 D_5 E_2 
Stack 9
A_9 D_1 Z_109 Z_110 D_3 
Stack 10
E_5 Z_111 B_5 B_14 C_11 
Stack 11
D_9 C_7 Z_112 C_9 A_2 
Stack 12
Z_113 C_10 C_8 D_6 B_1 
Stack 13
C_5 Z_114 C_6 A_8 Z_115 
Stack 14
C_3 D_4 A_1 E_3 B_6 
