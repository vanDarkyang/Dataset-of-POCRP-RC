Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
I_1 I_7 H_1 Z_100 Z_101 N_1 
Stack 1
Z_102 E_1 Z_103 J_5 I_0 E_2 
Stack 2
K_6 F_0 N_2 O_2 M_2 H_8 
Stack 3
G_5 F_3 K_7 Z_104 M_5 D_1 
Stack 4
L_1 I_5 Z_105 H_4 Z_106 
Stack 5
H_10 I_4 G_3 Z_107 Z_108 
Stack 6
J_4 J_3 K_2 N_0 I_2 
Stack 7
E_3 Z_109 J_0 O_0 L_0 
Stack 8
G_4 E_0 Z_110 G_6 N_3 
Stack 9
I_8 O_1 F_7 Z_111 Z_112 
Stack 10
G_7 Z_113 M_0 J_1 G_8 
Stack 11
M_3 L_2 E_5 I_3 C_4 
Stack 12
B_3 M_1 F_6 L_4 G_2 
Stack 13
G_1 H_2 J_2 Z_114 D_0 
Stack 14
B_1 C_0 N_4 E_4 Z_115 
Stack 15
L_5 J_7 Z_116 C_2 D_2 
Stack 16
K_3 G_0 H_7 K_1 E_7 
Stack 17
F_4 L_6 C_1 Z_117 J_6 
Stack 18
L_7 H_3 E_6 Z_118 O_3 
Stack 19
M_4 F_2 Z_119 K_5 D_3 
Stack 20
F_5 B_0 H_9 Z_120 Z_121 
Stack 21
K_0 H_0 L_3 C_3 I_6 
Stack 22
Z_122 B_2 A_0 K_4 F_1 
Stack 23
D_4 Z_123 H_6 Z_124 H_5 
