Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
D_8 B_2 B_3 E_1 A_8 
Stack 1
C_0 A_1 E_7 D_4 C_5 
Stack 2
B_6 D_1 B_8 Z_100 E_6 
Stack 3
C_6 A_0 D_0 Z_101 B_5 
Stack 4
Z_102 B_7 Z_103 Z_104 A_7 
Stack 5
B_4 C_2 A_4 B_0 D_3 
Stack 6
A_5 Z_105 D_2 E_0 A_6 
Stack 7
C_7 D_6 E_4 C_4 B_1 
Stack 8
A_3 Z_106 Z_107 D_7 E_3 
Stack 9
Z_108 Z_109 D_5 E_2 A_2 
Stack 10
C_1 C_3 E_5 Z_110 
