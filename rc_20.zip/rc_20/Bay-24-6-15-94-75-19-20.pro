Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
E_1 F_2 Z_100 L_4 
Stack 1
E_2 L_3 I_7 O_2 
Stack 2
Z_101 J_2 H_0 I_2 
Stack 3
M_2 N_2 G_1 K_2 
Stack 4
J_4 F_5 Z_102 D_0 
Stack 5
Z_103 J_5 I_4 Z_104 
Stack 6
H_2 F_1 I_1 Z_105 
Stack 7
L_2 Z_106 G_3 D_3 
Stack 8
C_0 L_1 H_3 K_1 
Stack 9
M_1 Z_107 Z_108 Z_109 
Stack 10
I_0 Z_110 H_1 E_3 
Stack 11
K_4 B_0 K_0 D_1 
Stack 12
E_4 L_0 F_0 H_4 
Stack 13
A_1 F_3 O_0 J_3 
Stack 14
Z_111 C_1 K_3 A_0 
Stack 15
E_5 I_6 D_2 N_0 
Stack 16
B_2 Z_112 L_5 Z_113 
Stack 17
J_0 Z_114 G_2 M_0 
Stack 18
I_5 C_2 D_4 F_6 
Stack 19
G_0 N_1 E_0 G_4 
Stack 20
Z_115 I_3 J_1 H_5 
Stack 21
H_6 A_2 B_1 O_1 
Stack 22
G_5 Z_116 Z_117 
Stack 23
Z_118 F_4 G_6 
