Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 E_0 C_1 C_13 
Stack 1
C_6 Z_101 B_2 D_9 
Stack 2
A_1 Z_102 A_4 A_7 
Stack 3
D_5 B_7 B_10 D_3 
Stack 4
C_7 C_8 D_1 D_8 
Stack 5
E_3 C_5 Z_103 Z_104 
Stack 6
B_11 A_0 C_11 D_11 
Stack 7
E_2 Z_105 C_0 C_10 
Stack 8
A_5 B_12 A_2 E_5 
Stack 9
D_4 B_1 A_6 Z_106 
Stack 10
Z_107 Z_108 Z_109 E_10 
Stack 11
B_4 Z_110 C_4 E_8 
Stack 12
A_3 B_8 D_13 B_3 
Stack 13
C_12 D_6 E_1 D_7 
Stack 14
Z_111 B_6 B_0 Z_112 
Stack 15
Z_113 C_3 A_8 E_11 
Stack 16
C_2 Z_114 D_12 E_6 
Stack 17
B_9 Z_115 E_9 C_9 
Stack 18
E_7 E_4 A_9 D_10 
Stack 19
D_2 B_5 D_0 
