Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
H_4 J_5 H_8 E_0 
Stack 1
G_3 Z_100 F_1 J_2 
Stack 2
Z_101 K_3 L_4 Z_102 
Stack 3
C_0 M_0 H_2 F_0 
Stack 4
N_1 N_0 I_4 C_2 
Stack 5
E_3 Z_103 G_1 L_0 
Stack 6
I_1 I_2 F_5 E_4 
Stack 7
D_3 O_0 A_1 O_2 
Stack 8
J_1 Z_104 Z_105 G_5 
Stack 9
F_2 F_3 Z_106 Z_107 
Stack 10
K_1 C_3 Z_108 E_1 
Stack 11
D_2 B_0 Z_109 K_0 
Stack 12
O_1 Z_110 I_3 N_2 
Stack 13
M_4 H_6 G_0 E_2 
Stack 14
F_4 A_0 J_3 Z_111 
Stack 15
D_4 Z_112 M_1 Z_113 
Stack 16
B_1 D_5 I_0 H_7 
Stack 17
H_0 J_4 C_1 Z_114 
Stack 18
Z_115 I_5 K_4 G_4 
Stack 19
L_1 G_2 Z_116 L_3 
Stack 20
B_3 B_2 K_2 M_2 
Stack 21
D_0 H_5 J_0 L_2 
Stack 22
Z_117 M_3 H_1 
Stack 23
Z_118 D_1 H_3 
