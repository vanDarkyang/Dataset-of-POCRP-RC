Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
E_10 D_12 A_9 B_2 D_1 C_1 
Stack 1
B_5 Z_100 A_1 Z_101 E_0 A_0 
Stack 2
C_9 Z_102 E_4 Z_103 E_8 C_2 
Stack 3
Z_104 A_10 A_4 D_11 C_3 E_2 
Stack 4
Z_105 D_10 A_7 D_4 A_12 
Stack 5
C_5 Z_106 E_1 E_11 D_9 
Stack 6
B_0 A_6 D_7 E_7 B_4 
Stack 7
Z_107 B_11 A_11 B_8 D_0 
Stack 8
E_12 A_5 B_1 Z_108 C_8 
Stack 9
Z_109 B_9 B_10 Z_110 Z_111 
Stack 10
E_5 Z_112 E_9 E_3 A_2 
Stack 11
C_4 E_6 Z_113 C_0 A_8 
Stack 12
Z_114 B_6 D_6 D_2 A_3 
Stack 13
B_3 D_3 C_7 C_6 D_8 
Stack 14
Z_115 B_7 D_5 D_14 D_13 
