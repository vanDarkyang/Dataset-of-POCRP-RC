Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
F_12 E_0 B_3 F_13 C_2 B_10 
Stack 1
D_9 E_3 H_6 H_4 H_7 D_8 
Stack 2
D_3 D_6 D_4 G_3 Z_100 F_10 
Stack 3
A_3 F_1 J_4 A_6 A_0 J_1 
Stack 4
B_1 D_0 J_3 C_0 E_6 B_8 
Stack 5
Z_101 I_6 D_5 E_1 F_3 
Stack 6
Z_102 Z_103 C_1 A_8 I_8 
Stack 7
Z_104 Z_105 Z_106 H_1 G_0 
Stack 8
Z_107 D_7 H_5 Z_108 A_2 
Stack 9
I_0 E_8 B_5 Z_109 F_6 
Stack 10
Z_110 A_1 J_8 F_0 I_4 
Stack 11
A_4 G_7 H_3 B_2 F_9 
Stack 12
Z_111 H_0 B_0 J_6 D_10 
Stack 13
B_6 Z_112 F_11 Z_113 Z_114 
Stack 14
G_5 E_9 Z_115 E_4 G_6 
Stack 15
E_7 G_2 J_7 A_5 B_9 
Stack 16
I_2 F_8 B_4 J_0 F_5 
Stack 17
A_7 E_5 I_1 Z_116 J_2 
Stack 18
F_7 B_7 Z_117 Z_118 F_4 
Stack 19
C_3 G_1 D_2 Z_119 J_5 
Stack 20
E_2 Z_120 F_2 E_10 G_4 
Stack 21
I_7 D_1 Z_121 C_5 I_3 
Stack 22
C_4 I_5 H_2 Z_122 Z_123 
