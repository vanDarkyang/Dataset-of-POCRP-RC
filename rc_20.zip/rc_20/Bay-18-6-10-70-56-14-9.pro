Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_2 E_3 Z_100 J_1 
Stack 1
D_0 F_5 C_0 Z_101 
Stack 2
A_1 F_2 D_1 F_0 
Stack 3
D_4 G_0 Z_102 I_1 
Stack 4
Z_103 F_1 E_2 D_5 
Stack 5
F_6 B_3 C_3 I_4 
Stack 6
G_2 B_2 J_2 H_0 
Stack 7
F_8 D_2 C_6 Z_104 
Stack 8
B_0 G_3 E_5 A_4 
Stack 9
F_4 F_7 J_0 I_0 
Stack 10
C_4 Z_105 Z_106 F_3 
Stack 11
G_4 E_0 H_1 I_2 
Stack 12
C_1 G_1 Z_107 D_3 
Stack 13
Z_108 G_5 Z_109 H_3 
Stack 14
C_5 A_2 E_4 A_0 
Stack 15
Z_110 A_3 Z_111 Z_112 
Stack 16
B_1 Z_113 H_4 
Stack 17
E_1 I_3 H_2 
