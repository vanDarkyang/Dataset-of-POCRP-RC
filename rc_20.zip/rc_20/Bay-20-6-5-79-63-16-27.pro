Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 B_8 C_4 A_6 
Stack 1
B_5 A_2 A_10 E_8 
Stack 2
B_4 B_1 Z_101 C_2 
Stack 3
D_1 D_4 B_0 B_14 
Stack 4
A_11 Z_102 A_8 B_12 
Stack 5
A_4 D_10 Z_103 Z_104 
Stack 6
Z_105 D_2 B_13 E_11 
Stack 7
D_3 C_0 Z_106 B_6 
Stack 8
C_6 A_1 C_7 B_3 
Stack 9
C_1 Z_107 B_2 Z_108 
Stack 10
E_0 C_9 A_3 Z_109 
Stack 11
D_0 Z_110 E_10 Z_111 
Stack 12
Z_112 E_5 C_11 Z_113 
Stack 13
A_12 D_9 A_7 D_8 
Stack 14
E_4 A_9 C_8 E_3 
Stack 15
E_7 C_5 E_6 B_9 
Stack 16
D_7 D_6 C_3 E_1 
Stack 17
E_2 Z_114 D_5 B_10 
Stack 18
A_5 C_10 B_7 B_11 
Stack 19
E_9 A_0 Z_115 
