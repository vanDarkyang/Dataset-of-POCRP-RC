Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_6 B_10 Z_100 Z_101 
Stack 1
C_7 B_0 Z_102 B_1 
Stack 2
A_2 Z_103 A_3 B_8 
Stack 3
A_6 C_2 A_9 B_5 
Stack 4
Z_104 C_5 Z_105 B_3 
Stack 5
A_5 C_3 C_4 A_1 
Stack 6
B_7 B_4 A_4 Z_106 
Stack 7
C_0 B_11 C_1 Z_107 
Stack 8
Z_108 A_7 A_0 Z_109 
Stack 9
B_2 C_8 C_13 C_12 
Stack 10
B_9 C_9 C_10 
Stack 11
C_11 B_6 A_8 
