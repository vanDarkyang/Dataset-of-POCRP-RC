Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
H_0 E_0 C_3 B_1 
Stack 1
F_5 C_2 Z_100 A_0 
Stack 2
Z_101 F_1 F_2 H_1 
Stack 3
D_0 E_3 Z_102 Z_103 
Stack 4
J_0 Z_104 I_1 H_3 
Stack 5
Z_105 F_6 Z_106 B_2 
Stack 6
I_2 Z_107 C_1 G_2 
Stack 7
F_0 I_3 Z_108 J_1 
Stack 8
D_2 C_0 D_1 G_0 
Stack 9
G_3 H_2 B_0 Z_109 
Stack 10
I_0 G_4 F_4 E_1 
Stack 11
A_1 F_3 G_1 
Stack 12
J_2 E_2 E_4 
