Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
N_0 G_4 L_4 Z_100 B_0 J_0 
Stack 1
Z_101 F_4 J_6 H_0 K_3 Z_102 
Stack 2
C_0 A_1 G_2 K_1 C_4 M_2 
Stack 3
H_1 H_7 M_0 Z_103 J_5 E_4 
Stack 4
O_0 H_4 N_3 K_0 Z_104 
Stack 5
D_2 I_1 B_1 Z_105 K_2 
Stack 6
F_2 I_2 J_4 I_0 Z_106 
Stack 7
H_3 H_2 N_1 Z_107 D_1 
Stack 8
E_1 L_0 I_4 L_3 N_2 
Stack 9
I_5 F_0 M_1 A_0 Z_108 
Stack 10
Z_109 H_5 Z_110 Z_111 Z_112 
Stack 11
Z_113 Z_114 L_2 K_4 E_3 
Stack 12
D_4 C_3 E_0 D_3 O_1 
Stack 13
F_3 G_3 G_0 Z_115 G_1 
Stack 14
J_1 L_1 Z_116 I_6 F_5 
Stack 15
B_2 J_3 I_3 O_2 Z_117 
Stack 16
C_1 M_3 F_1 E_2 C_2 
Stack 17
H_6 J_2 F_6 Z_118 D_0 
