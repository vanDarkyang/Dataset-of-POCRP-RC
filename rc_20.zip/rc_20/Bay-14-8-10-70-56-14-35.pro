Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 F_8 H_2 A_1 H_5 
Stack 1
C_2 F_0 G_4 D_3 Z_101 
Stack 2
H_4 A_0 Z_102 E_3 G_5 
Stack 3
G_6 H_0 C_1 Z_103 B_1 
Stack 4
Z_104 F_6 G_3 H_1 E_4 
Stack 5
Z_105 B_0 J_2 G_2 F_4 
Stack 6
A_2 D_4 E_1 A_4 E_2 
Stack 7
E_6 G_1 Z_106 Z_107 D_0 
Stack 8
C_0 F_2 Z_108 D_2 J_1 
Stack 9
I_4 F_3 E_5 Z_109 F_5 
Stack 10
C_3 F_1 I_5 Z_110 E_0 
Stack 11
Z_111 G_0 I_1 F_7 B_3 
Stack 12
J_0 B_2 A_3 I_3 I_0 
Stack 13
Z_112 I_2 Z_113 H_3 D_1 
