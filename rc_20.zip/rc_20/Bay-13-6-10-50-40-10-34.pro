Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 E_0 D_1 H_1 
Stack 1
F_4 C_0 E_1 Z_101 
Stack 2
C_4 F_2 E_2 Z_102 
Stack 3
Z_103 F_0 Z_104 B_1 
Stack 4
A_0 I_3 H_3 Z_105 
Stack 5
G_1 F_5 Z_106 B_0 
Stack 6
Z_107 G_0 I_0 J_1 
Stack 7
J_0 C_1 I_1 I_2 
Stack 8
C_3 E_3 D_2 A_1 
Stack 9
F_1 B_2 D_0 C_2 
Stack 10
Z_108 G_2 Z_109 F_3 
Stack 11
H_2 H_0 G_4 
Stack 12
G_3 D_3 J_2 
