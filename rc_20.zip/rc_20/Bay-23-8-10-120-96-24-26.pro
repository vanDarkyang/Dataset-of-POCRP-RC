Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
E_7 I_0 F_1 J_2 G_6 Z_100 
Stack 1
H_1 D_6 C_0 B_7 H_4 Z_101 
Stack 2
H_8 A_9 C_1 C_2 I_1 F_8 
Stack 3
J_5 A_1 F_5 Z_102 I_5 C_9 
Stack 4
C_6 B_0 E_8 Z_103 E_10 A_4 
Stack 5
B_9 E_0 Z_104 Z_105 F_9 
Stack 6
A_0 I_8 F_3 C_7 A_6 
Stack 7
C_10 I_3 C_3 E_9 I_6 
Stack 8
Z_106 G_2 Z_107 Z_108 H_2 
Stack 9
H_9 B_1 A_8 C_8 Z_109 
Stack 10
I_7 D_1 Z_110 B_6 Z_111 
Stack 11
B_8 D_5 G_4 H_5 Z_112 
Stack 12
I_9 Z_113 Z_114 A_5 C_4 
Stack 13
I_4 J_4 G_3 G_5 Z_115 
Stack 14
Z_116 D_3 D_2 J_6 G_0 
Stack 15
Z_117 J_0 Z_118 E_4 E_6 
Stack 16
F_10 H_3 A_2 H_0 C_5 
Stack 17
Z_119 B_2 E_3 D_0 G_1 
Stack 18
A_3 H_6 Z_120 F_0 Z_121 
Stack 19
F_2 J_3 G_8 Z_122 E_2 
Stack 20
I_2 B_3 J_1 B_5 B_4 
Stack 21
F_6 Z_123 G_7 D_4 F_4 
Stack 22
E_5 E_1 A_7 H_7 F_7 
