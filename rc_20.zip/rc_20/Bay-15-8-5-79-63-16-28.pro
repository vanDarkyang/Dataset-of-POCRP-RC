Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 Z_101 C_2 A_6 E_4 D_3 
Stack 1
E_6 C_9 Z_102 D_11 D_9 Z_103 
Stack 2
C_12 Z_104 A_4 B_5 B_3 D_6 
Stack 3
D_10 D_0 E_2 Z_105 C_1 B_11 
Stack 4
E_7 A_2 Z_106 B_9 B_1 
Stack 5
Z_107 D_8 E_9 Z_108 E_8 
Stack 6
A_7 E_1 C_5 E_5 A_0 
Stack 7
Z_109 B_0 D_7 A_12 D_1 
Stack 8
B_4 B_8 Z_110 A_1 E_12 
Stack 9
Z_111 C_6 D_4 B_6 Z_112 
Stack 10
B_2 A_5 A_8 C_7 C_8 
Stack 11
B_10 C_10 E_0 C_3 E_3 
Stack 12
E_10 C_4 A_3 B_7 Z_113 
Stack 13
A_11 C_0 C_11 E_11 Z_114 
Stack 14
D_5 D_2 A_9 A_10 Z_115 
