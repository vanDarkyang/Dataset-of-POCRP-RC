Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 I_2 C_2 D_0 
Stack 1
G_0 H_3 F_3 I_3 
Stack 2
E_0 H_1 C_4 Z_101 
Stack 3
B_0 F_1 Z_102 B_1 
Stack 4
Z_103 E_1 D_3 C_1 
Stack 5
E_3 Z_104 H_2 I_0 
Stack 6
C_0 H_0 E_2 A_0 
Stack 7
E_4 G_2 F_4 F_2 
Stack 8
Z_105 Z_106 C_3 E_5 
Stack 9
Z_107 J_0 D_4 G_1 
Stack 10
F_0 J_1 Z_108 Z_109 
Stack 11
D_1 D_2 G_3 
Stack 12
I_1 F_5 G_4 
