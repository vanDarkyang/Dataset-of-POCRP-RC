Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
L_0 Z_100 J_5 G_6 
Stack 1
Z_101 J_3 H_4 Z_102 
Stack 2
A_1 C_0 K_2 J_6 
Stack 3
C_1 L_3 L_1 D_4 
Stack 4
L_2 F_0 F_5 N_2 
Stack 5
Z_103 F_3 Z_104 H_1 
Stack 6
H_0 Z_105 E_3 Z_106 
Stack 7
Z_107 D_3 E_5 O_1 
Stack 8
Z_108 Z_109 J_1 E_4 
Stack 9
E_1 L_4 H_5 G_3 
Stack 10
D_2 G_4 E_0 I_3 
Stack 11
J_2 Z_110 H_2 H_7 
Stack 12
N_3 K_1 B_3 D_1 
Stack 13
Z_111 H_3 Z_112 N_0 
Stack 14
F_1 I_2 E_2 A_0 
Stack 15
C_2 H_6 G_1 M_4 
Stack 16
O_0 I_0 Z_113 D_0 
Stack 17
J_4 M_0 D_5 J_0 
Stack 18
M_3 A_2 I_1 G_5 
Stack 19
Z_114 N_1 M_2 B_2 
Stack 20
B_1 Z_115 Z_116 M_1 
Stack 21
Z_117 Z_118 I_4 F_4 
Stack 22
F_2 G_2 K_0 
Stack 23
G_0 B_0 O_2 
