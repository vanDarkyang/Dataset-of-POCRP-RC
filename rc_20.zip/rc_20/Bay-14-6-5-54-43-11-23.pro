Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_8 D_5 E_1 E_0 
Stack 1
A_6 C_3 A_1 E_6 
Stack 2
D_2 C_1 E_4 B_9 
Stack 3
Z_100 A_2 E_3 Z_101 
Stack 4
A_0 Z_102 Z_103 Z_104 
Stack 5
C_0 C_2 B_5 D_6 
Stack 6
C_7 A_7 E_2 B_0 
Stack 7
E_7 Z_105 E_5 E_8 
Stack 8
Z_106 D_3 B_2 A_5 
Stack 9
Z_107 D_0 C_5 D_4 
Stack 10
B_7 Z_108 C_6 D_1 
Stack 11
B_4 B_3 C_8 C_4 
Stack 12
A_4 B_6 Z_109 
Stack 13
Z_110 B_1 A_3 
