Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_6 B_3 Z_100 Z_101 B_7 
Stack 1
Z_102 A_5 Z_103 E_1 C_4 
Stack 2
D_2 C_7 D_3 E_4 B_4 
Stack 3
D_4 D_5 B_2 B_1 D_7 
Stack 4
A_0 Z_104 B_5 C_3 Z_105 
Stack 5
C_0 C_1 B_0 C_5 E_7 
Stack 6
C_8 A_2 Z_106 C_9 A_7 
Stack 7
E_6 C_6 A_1 E_2 Z_107 
Stack 8
A_6 C_2 Z_108 A_3 D_0 
Stack 9
D_6 A_8 E_3 E_0 Z_109 
Stack 10
Z_110 D_1 A_4 E_5 
