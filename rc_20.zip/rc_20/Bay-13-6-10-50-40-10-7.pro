Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 G_1 B_0 I_2 
Stack 1
E_0 B_2 Z_101 J_0 
Stack 2
G_2 C_3 H_1 Z_102 
Stack 3
Z_103 Z_104 Z_105 D_1 
Stack 4
Z_106 D_0 H_2 H_0 
Stack 5
F_4 G_3 F_0 A_1 
Stack 6
I_1 B_3 B_1 H_3 
Stack 7
I_0 G_0 G_4 E_1 
Stack 8
F_3 Z_107 C_2 Z_108 
Stack 9
D_3 D_4 J_2 C_0 
Stack 10
I_3 C_1 F_2 J_1 
Stack 11
E_2 A_0 Z_109 
Stack 12
F_1 E_3 D_2 
