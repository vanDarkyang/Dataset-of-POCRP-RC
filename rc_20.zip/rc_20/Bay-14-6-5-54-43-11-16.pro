Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_2 B_5 E_3 B_9 
Stack 1
D_0 B_6 C_0 Z_100 
Stack 2
Z_101 Z_102 C_1 D_6 
Stack 3
D_5 A_2 E_6 D_7 
Stack 4
B_1 C_2 D_3 B_4 
Stack 5
A_0 C_3 A_3 B_8 
Stack 6
Z_103 Z_104 Z_105 A_4 
Stack 7
E_4 A_7 D_4 C_5 
Stack 8
D_2 C_7 A_5 E_1 
Stack 9
B_7 A_1 C_4 D_8 
Stack 10
E_5 Z_106 Z_107 C_8 
Stack 11
B_3 Z_108 E_0 C_6 
Stack 12
A_6 D_1 E_2 
Stack 13
Z_109 B_0 Z_110 
