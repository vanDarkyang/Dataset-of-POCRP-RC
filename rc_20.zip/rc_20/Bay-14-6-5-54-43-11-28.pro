Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_1 E_1 D_4 A_7 
Stack 1
C_4 Z_100 E_2 B_6 
Stack 2
B_8 D_1 B_1 Z_101 
Stack 3
D_6 Z_102 B_7 C_6 
Stack 4
B_5 E_6 E_0 C_2 
Stack 5
A_8 Z_103 C_7 A_2 
Stack 6
B_3 A_6 Z_104 A_0 
Stack 7
A_5 A_9 A_4 Z_105 
Stack 8
C_3 E_3 A_1 D_0 
Stack 9
E_8 B_2 E_5 C_5 
Stack 10
B_0 Z_106 Z_107 D_3 
Stack 11
B_4 Z_108 E_4 A_3 
Stack 12
Z_109 C_0 D_5 
Stack 13
Z_110 D_2 E_7 
