Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_7 C_0 D_2 C_5 
Stack 1
D_9 B_0 D_0 Z_100 
Stack 2
C_3 B_1 B_3 E_2 
Stack 3
A_8 Z_101 D_8 B_6 
Stack 4
C_4 Z_102 D_7 B_2 
Stack 5
C_6 E_5 A_6 E_3 
Stack 6
E_1 Z_103 Z_104 E_4 
Stack 7
D_1 C_1 Z_105 B_5 
Stack 8
D_5 E_6 A_2 D_6 
Stack 9
A_5 Z_106 E_7 C_8 
Stack 10
Z_107 A_1 Z_108 C_2 
Stack 11
Z_109 A_4 D_4 Z_110 
Stack 12
D_3 A_3 A_0 
Stack 13
C_7 B_4 E_0 
