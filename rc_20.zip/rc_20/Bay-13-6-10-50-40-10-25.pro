Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 B_3 F_1 D_4 
Stack 1
Z_101 Z_102 Z_103 Z_104 
Stack 2
D_1 J_0 C_1 E_1 
Stack 3
I_1 H_3 Z_105 G_0 
Stack 4
B_1 G_3 J_1 A_0 
Stack 5
A_1 E_0 E_2 H_2 
Stack 6
D_2 D_0 F_0 D_3 
Stack 7
I_2 G_2 Z_106 Z_107 
Stack 8
H_4 H_1 Z_108 C_0 
Stack 9
Z_109 E_3 C_2 B_0 
Stack 10
B_2 F_5 G_1 F_4 
Stack 11
E_4 A_2 H_0 
Stack 12
I_0 F_2 F_3 
