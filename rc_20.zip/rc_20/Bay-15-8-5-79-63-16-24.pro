Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
D_3 E_4 B_12 E_8 B_10 A_1 
Stack 1
D_11 A_9 C_7 C_9 Z_100 D_5 
Stack 2
B_11 C_8 Z_101 E_7 B_6 E_11 
Stack 3
C_2 E_2 A_8 C_4 D_7 E_9 
Stack 4
B_9 Z_102 Z_103 Z_104 C_0 
Stack 5
A_3 D_8 E_1 D_6 A_5 
Stack 6
Z_105 B_8 E_5 Z_106 Z_107 
Stack 7
E_12 Z_108 Z_109 D_0 D_2 
Stack 8
C_3 A_0 C_1 A_7 A_4 
Stack 9
B_7 A_12 D_10 Z_110 B_3 
Stack 10
B_5 C_11 E_3 Z_111 A_11 
Stack 11
D_1 B_2 C_10 Z_112 A_2 
Stack 12
A_6 B_4 B_1 B_0 E_0 
Stack 13
C_5 A_10 Z_113 E_6 D_9 
Stack 14
C_6 Z_114 Z_115 E_10 D_4 
