Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
I_0 Z_100 J_4 A_1 C_1 Z_101 
Stack 1
G_0 M_3 H_1 Z_102 Z_103 A_2 
Stack 2
J_5 J_2 K_0 C_0 F_4 Z_104 
Stack 3
N_0 I_6 I_4 D_3 D_2 F_3 
Stack 4
F_1 J_3 I_2 N_1 M_2 
Stack 5
H_0 O_0 H_6 E_4 Z_105 
Stack 6
K_5 G_1 F_0 F_5 Z_106 
Stack 7
H_2 B_1 O_1 G_4 E_5 
Stack 8
B_0 L_1 H_4 Z_107 M_1 
Stack 9
G_3 K_4 D_0 J_0 K_1 
Stack 10
Z_108 B_2 Z_109 L_4 Z_110 
Stack 11
Z_111 I_3 H_5 A_0 I_1 
Stack 12
Z_112 H_3 Z_113 N_2 L_5 
Stack 13
K_3 D_1 K_2 J_1 Z_114 
Stack 14
E_1 J_6 L_2 L_0 E_0 
Stack 15
B_3 G_5 F_2 Z_115 M_0 
Stack 16
E_3 Z_116 G_2 J_7 I_5 
Stack 17
E_2 G_6 Z_117 Z_118 L_3 
