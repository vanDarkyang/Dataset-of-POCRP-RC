Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
B_2 D_10 Z_100 E_3 
Stack 1
Z_101 B_12 B_3 D_6 
Stack 2
C_12 B_9 Z_102 C_9 
Stack 3
Z_103 C_11 D_13 E_4 
Stack 4
Z_104 Z_105 D_4 C_10 
Stack 5
A_5 Z_106 C_5 A_4 
Stack 6
C_3 A_1 D_1 A_6 
Stack 7
A_2 D_9 B_6 Z_107 
Stack 8
D_3 A_8 E_11 A_3 
Stack 9
D_7 C_8 E_0 B_4 
Stack 10
B_13 B_1 E_9 B_0 
Stack 11
C_7 Z_108 Z_109 B_7 
Stack 12
A_7 E_7 B_11 C_4 
Stack 13
D_5 D_11 Z_110 E_10 
Stack 14
C_1 D_8 B_8 C_2 
Stack 15
E_6 Z_111 Z_112 Z_113 
Stack 16
E_8 D_2 D_12 Z_114 
Stack 17
B_5 B_10 C_6 Z_115 
Stack 18
D_14 E_2 A_0 C_0 
Stack 19
D_0 E_5 E_1 
