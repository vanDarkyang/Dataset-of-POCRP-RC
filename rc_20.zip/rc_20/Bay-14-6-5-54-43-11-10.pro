Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_3 A_2 B_7 A_1 
Stack 1
E_8 D_0 Z_100 Z_101 
Stack 2
A_7 Z_102 C_5 C_0 
Stack 3
E_4 D_2 D_3 A_6 
Stack 4
Z_103 Z_104 C_2 Z_105 
Stack 5
A_4 A_0 E_2 D_4 
Stack 6
B_5 Z_106 C_6 E_6 
Stack 7
A_8 C_8 C_1 E_5 
Stack 8
B_2 A_5 Z_107 C_4 
Stack 9
E_7 E_0 B_8 E_1 
Stack 10
Z_108 D_5 B_4 B_6 
Stack 11
B_3 C_7 Z_109 D_1 
Stack 12
B_1 B_9 E_3 
Stack 13
A_3 Z_110 B_0 
