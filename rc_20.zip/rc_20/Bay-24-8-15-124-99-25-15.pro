Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
J_4 J_0 I_6 D_2 O_0 H_8 
Stack 1
Z_100 E_4 Z_101 Z_102 H_3 D_3 
Stack 2
B_2 N_5 L_2 O_2 A_0 B_0 
Stack 3
E_5 H_11 M_2 Z_103 A_4 J_1 
Stack 4
Z_104 A_2 F_5 Z_105 H_2 
Stack 5
G_1 H_0 H_1 Z_106 M_1 
Stack 6
F_3 N_4 H_4 L_0 N_1 
Stack 7
K_1 H_6 H_5 G_2 J_3 
Stack 8
Z_107 I_1 J_6 C_3 E_7 
Stack 9
M_0 Z_108 I_4 F_6 G_3 
Stack 10
H_7 N_0 L_5 F_8 C_4 
Stack 11
D_6 F_4 I_7 M_3 L_6 
Stack 12
Z_109 G_8 E_6 F_0 J_5 
Stack 13
C_2 G_6 Z_110 I_2 L_4 
Stack 14
Z_111 D_4 Z_112 D_5 Z_113 
Stack 15
I_3 J_2 B_3 F_7 A_3 
Stack 16
E_1 A_1 L_3 G_0 Z_114 
Stack 17
O_1 J_7 I_0 N_2 G_5 
Stack 18
C_0 E_0 Z_115 Z_116 F_1 
Stack 19
G_7 E_3 C_1 F_2 I_5 
Stack 20
Z_117 K_0 Z_118 Z_119 Z_120 
Stack 21
E_2 B_4 D_1 N_3 H_10 
Stack 22
H_9 Z_121 Z_122 B_1 Z_123 
Stack 23
Z_124 D_0 G_4 K_2 L_1 
