Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_4 C_11 B_7 Z_100 E_9 E_1 
Stack 1
B_12 A_11 B_2 A_5 E_0 D_9 
Stack 2
A_0 B_4 D_10 Z_101 C_3 B_9 
Stack 3
Z_102 C_7 E_10 Z_103 D_11 A_6 
Stack 4
Z_104 B_8 Z_105 D_2 B_13 
Stack 5
D_4 C_5 B_3 A_3 E_8 
Stack 6
Z_106 D_0 A_1 D_7 A_7 
Stack 7
C_2 E_3 E_5 Z_107 E_4 
Stack 8
E_7 C_1 D_1 Z_108 D_5 
Stack 9
A_8 D_3 E_6 Z_109 B_10 
Stack 10
C_9 Z_110 B_14 Z_111 B_0 
Stack 11
C_0 A_2 C_12 C_10 B_11 
Stack 12
C_6 C_8 A_9 A_10 Z_112 
Stack 13
Z_113 B_6 D_8 B_1 D_6 
Stack 14
B_5 Z_114 Z_115 C_4 E_2 
