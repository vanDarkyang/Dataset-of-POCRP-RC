Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
F_6 G_4 B_0 I_6 L_1 K_0 
Stack 1
F_5 C_3 Z_100 H_2 Z_101 D_0 
Stack 2
Z_102 Z_103 C_1 H_4 D_4 I_0 
Stack 3
D_2 L_4 H_1 L_2 I_5 E_3 
Stack 4
M_2 N_2 C_0 Z_104 H_0 
Stack 5
Z_105 E_4 M_0 J_5 I_4 
Stack 6
Z_106 J_0 G_0 G_2 Z_107 
Stack 7
I_7 H_5 I_3 Z_108 E_0 
Stack 8
Z_109 F_7 J_6 F_4 D_3 
Stack 9
G_3 Z_110 Z_111 K_2 D_1 
Stack 10
F_0 F_1 O_0 O_2 Z_112 
Stack 11
Z_113 A_2 G_1 E_2 Z_114 
Stack 12
F_2 C_4 H_3 Z_115 J_3 
Stack 13
G_5 J_4 B_1 Z_116 L_3 
Stack 14
Z_117 Z_118 H_6 M_1 O_1 
Stack 15
C_2 F_3 K_3 A_0 J_1 
Stack 16
N_0 N_1 E_1 I_1 K_1 
Stack 17
A_1 J_2 I_2 L_0 K_4 
