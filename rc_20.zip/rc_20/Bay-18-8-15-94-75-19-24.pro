Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
C_1 H_7 Z_100 M_0 K_5 F_5 
Stack 1
M_1 L_4 K_1 E_0 C_0 B_3 
Stack 2
I_4 G_1 I_2 D_1 J_5 N_0 
Stack 3
A_2 Z_101 H_2 K_3 H_6 O_1 
Stack 4
K_2 G_2 A_1 G_3 C_3 
Stack 5
B_1 L_2 G_4 C_2 F_1 
Stack 6
Z_102 F_0 N_2 E_3 Z_103 
Stack 7
Z_104 E_2 H_3 Z_105 J_2 
Stack 8
J_3 O_2 B_2 F_2 L_5 
Stack 9
Z_106 O_0 H_1 H_4 Z_107 
Stack 10
Z_108 H_5 Z_109 L_1 N_3 
Stack 11
I_0 G_0 J_0 Z_110 N_1 
Stack 12
M_2 D_2 Z_111 F_4 D_3 
Stack 13
J_4 Z_112 Z_113 K_0 I_6 
Stack 14
I_3 Z_114 I_1 Z_115 E_1 
Stack 15
F_3 F_6 Z_116 L_3 J_6 
Stack 16
D_0 L_0 I_5 A_0 J_1 
Stack 17
Z_117 Z_118 B_0 H_0 K_4 
