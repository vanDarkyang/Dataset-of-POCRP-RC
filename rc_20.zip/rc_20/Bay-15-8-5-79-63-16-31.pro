Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
B_9 D_1 Z_100 E_10 D_8 C_6 
Stack 1
Z_101 E_2 E_9 Z_102 E_8 A_7 
Stack 2
D_2 Z_103 B_3 A_2 D_11 Z_104 
Stack 3
A_4 D_6 D_3 E_7 D_9 Z_105 
Stack 4
C_4 D_7 Z_106 Z_107 E_5 
Stack 5
B_4 A_9 A_3 Z_108 A_10 
Stack 6
Z_109 B_1 C_8 Z_110 E_3 
Stack 7
Z_111 B_12 B_11 D_12 C_1 
Stack 8
Z_112 C_2 D_5 B_5 D_4 
Stack 9
C_11 B_2 A_8 E_6 C_10 
Stack 10
B_0 Z_113 Z_114 Z_115 B_7 
Stack 11
C_9 C_3 E_11 D_10 A_1 
Stack 12
B_6 E_1 A_0 A_5 E_0 
Stack 13
A_6 C_12 B_10 E_4 B_8 
Stack 14
C_5 C_0 D_0 C_7 C_13 
