Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_3 B_0 D_5 A_2 
Stack 1
G_4 Z_100 F_4 H_1 
Stack 2
E_6 F_1 I_4 H_0 
Stack 3
Z_101 C_2 E_3 H_2 
Stack 4
E_0 J_2 I_3 B_2 
Stack 5
C_5 J_1 D_1 Z_102 
Stack 6
C_0 G_1 D_3 Z_103 
Stack 7
B_1 E_7 Z_104 C_4 
Stack 8
Z_105 D_2 G_2 G_0 
Stack 9
D_6 I_1 E_2 Z_106 
Stack 10
E_5 A_3 I_2 E_4 
Stack 11
Z_107 G_5 Z_108 J_0 
Stack 12
C_1 C_6 Z_109 G_3 
Stack 13
Z_110 G_7 F_2 E_1 
Stack 14
F_3 Z_111 G_6 A_4 
Stack 15
A_0 A_1 I_0 F_0 
Stack 16
J_3 D_4 F_5 
Stack 17
Z_112 D_0 Z_113 
