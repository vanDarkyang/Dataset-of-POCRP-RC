Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_1 A_0 D_1 H_2 
Stack 1
Z_100 E_2 J_2 I_0 
Stack 2
Z_101 Z_102 C_1 Z_103 
Stack 3
B_1 Z_104 H_1 C_3 
Stack 4
D_2 Z_105 I_3 F_2 
Stack 5
G_1 B_0 A_1 G_2 
Stack 6
G_3 C_2 E_3 I_1 
Stack 7
D_0 Z_106 E_0 H_0 
Stack 8
G_0 D_4 E_1 J_0 
Stack 9
H_3 B_2 F_3 Z_107 
Stack 10
D_5 I_2 E_4 D_3 
Stack 11
Z_108 F_0 Z_109 
Stack 12
C_0 J_1 A_2 
