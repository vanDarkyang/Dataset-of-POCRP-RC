Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
L_1 Z_100 H_9 L_0 D_4 Z_101 
Stack 1
I_0 H_4 Z_102 N_4 B_3 C_4 
Stack 2
D_0 Z_103 I_5 H_5 G_3 E_3 
Stack 3
Z_104 E_2 Z_105 A_0 A_1 G_5 
Stack 4
N_3 K_0 Z_106 I_6 F_3 
Stack 5
J_2 F_0 Z_107 K_6 Z_108 
Stack 6
D_5 K_1 D_2 Z_109 H_10 
Stack 7
J_8 Z_110 Z_111 J_5 G_4 
Stack 8
E_0 Z_112 M_2 O_1 M_5 
Stack 9
C_3 M_4 G_6 C_5 H_7 
Stack 10
Z_113 K_3 I_9 K_5 I_8 
Stack 11
O_3 I_7 H_6 G_0 I_1 
Stack 12
L_2 M_0 I_3 A_3 H_3 
Stack 13
I_4 F_4 B_2 C_6 E_1 
Stack 14
D_1 Z_114 N_2 H_2 F_5 
Stack 15
K_2 J_0 M_3 F_6 N_1 
Stack 16
D_3 B_1 J_3 L_4 O_2 
Stack 17
G_1 B_0 J_7 F_2 Z_115 
Stack 18
Z_116 Z_117 C_2 L_3 Z_118 
Stack 19
A_2 Z_119 N_0 Z_120 F_1 
Stack 20
G_2 Z_121 M_1 H_8 B_4 
Stack 21
Z_122 Z_123 J_1 H_1 C_1 
Stack 22
J_6 H_0 Z_124 K_4 J_4 
Stack 23
G_7 I_2 N_5 C_0 O_0 
