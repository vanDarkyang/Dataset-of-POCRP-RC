Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_1 D_9 Z_100 E_6 
Stack 1
C_3 C_5 E_5 A_3 
Stack 2
D_10 D_4 D_2 Z_101 
Stack 3
A_4 C_6 D_6 E_3 
Stack 4
Z_102 A_0 D_7 Z_103 
Stack 5
C_7 D_1 D_0 B_0 
Stack 6
B_5 C_4 B_4 C_2 
Stack 7
B_3 C_1 D_3 E_1 
Stack 8
Z_104 E_0 A_7 E_4 
Stack 9
B_7 D_5 Z_105 C_8 
Stack 10
C_0 A_6 A_2 D_8 
Stack 11
Z_106 Z_107 E_2 Z_108 
Stack 12
Z_109 A_5 B_6 
Stack 13
A_1 B_2 Z_110 
