Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_1 G_6 E_2 G_1 
Stack 1
Z_100 Z_101 Z_102 D_2 
Stack 2
A_0 C_2 J_0 B_4 
Stack 3
B_1 Z_103 C_1 Z_104 
Stack 4
F_6 A_3 G_2 B_3 
Stack 5
I_0 D_0 H_3 H_2 
Stack 6
E_7 Z_105 G_7 Z_106 
Stack 7
G_4 Z_107 A_1 E_1 
Stack 8
F_4 D_4 I_2 G_5 
Stack 9
D_3 H_1 F_7 E_6 
Stack 10
I_1 F_0 E_5 J_3 
Stack 11
Z_108 E_0 I_3 J_4 
Stack 12
Z_109 B_0 A_2 Z_110 
Stack 13
J_2 G_0 G_3 E_4 
Stack 14
B_2 F_2 J_1 F_5 
Stack 15
C_0 Z_111 H_0 H_4 
Stack 16
Z_112 I_4 E_3 
Stack 17
F_1 F_3 Z_113 
