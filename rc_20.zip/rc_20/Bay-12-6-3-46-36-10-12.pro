Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_6 C_5 B_7 B_1 
Stack 1
C_7 C_0 A_9 Z_100 
Stack 2
C_2 Z_101 A_2 B_3 
Stack 3
A_8 B_8 A_6 A_11 
Stack 4
Z_102 B_9 A_0 Z_103 
Stack 5
Z_104 Z_105 A_7 C_10 
Stack 6
B_11 C_9 C_3 Z_106 
Stack 7
B_2 C_1 B_10 C_8 
Stack 8
Z_107 Z_108 Z_109 B_6 
Stack 9
B_5 A_5 B_12 C_4 
Stack 10
B_4 A_4 A_10 
Stack 11
B_0 A_1 A_3 
