Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_0 B_5 C_9 Z_100 
Stack 1
B_2 B_4 C_3 B_9 
Stack 2
A_3 A_4 C_0 B_8 
Stack 3
A_6 Z_101 Z_102 C_8 
Stack 4
B_3 A_5 C_7 Z_103 
Stack 5
Z_104 A_12 Z_105 A_7 
Stack 6
A_1 B_11 A_0 C_4 
Stack 7
A_13 Z_106 C_1 A_8 
Stack 8
Z_107 C_5 C_6 A_9 
Stack 9
C_2 A_2 B_6 Z_108 
Stack 10
B_10 A_10 A_11 
Stack 11
Z_109 B_7 B_1 
