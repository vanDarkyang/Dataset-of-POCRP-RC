Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_1 A_0 Z_100 A_3 
Stack 1
C_6 C_7 Z_101 A_2 
Stack 2
B_3 C_10 C_2 A_11 
Stack 3
Z_102 A_9 Z_103 C_8 
Stack 4
C_11 C_5 A_1 Z_104 
Stack 5
A_6 C_0 C_12 Z_105 
Stack 6
B_6 Z_106 B_5 B_8 
Stack 7
Z_107 A_7 B_0 C_4 
Stack 8
Z_108 A_10 A_8 B_4 
Stack 9
C_9 B_7 Z_109 C_1 
Stack 10
B_10 C_3 A_5 
Stack 11
A_4 B_2 B_9 
