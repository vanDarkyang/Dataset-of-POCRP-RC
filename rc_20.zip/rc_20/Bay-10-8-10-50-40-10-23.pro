Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 D_0 B_2 F_1 I_1 
Stack 1
F_3 H_1 F_2 J_2 C_0 
Stack 2
J_1 D_2 H_0 E_2 Z_101 
Stack 3
I_0 G_2 F_5 E_5 H_2 
Stack 4
C_2 E_1 D_3 F_4 J_0 
Stack 5
F_0 G_1 B_3 G_3 I_2 
Stack 6
Z_102 A_0 Z_103 Z_104 D_1 
Stack 7
C_1 Z_105 Z_106 E_0 C_3 
Stack 8
Z_107 E_3 G_0 E_4 Z_108 
Stack 9
H_3 B_0 Z_109 B_1 H_4 
