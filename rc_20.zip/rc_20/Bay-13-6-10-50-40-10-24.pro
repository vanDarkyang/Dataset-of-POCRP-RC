Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_3 Z_100 G_1 Z_101 
Stack 1
B_1 E_0 E_2 Z_102 
Stack 2
J_1 Z_103 F_3 I_0 
Stack 3
H_1 G_2 H_3 Z_104 
Stack 4
D_1 D_4 D_0 Z_105 
Stack 5
I_2 F_2 F_5 A_1 
Stack 6
F_4 C_1 F_1 F_0 
Stack 7
G_3 C_0 D_2 B_2 
Stack 8
C_3 C_2 G_4 H_0 
Stack 9
H_2 J_0 Z_106 A_2 
Stack 10
E_1 E_4 Z_107 B_0 
Stack 11
D_3 Z_108 G_0 
Stack 12
I_1 A_0 Z_109 
