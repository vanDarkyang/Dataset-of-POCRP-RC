Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_8 C_5 A_3 C_4 
Stack 1
Z_100 C_1 E_8 E_2 
Stack 2
D_8 D_6 D_12 E_6 
Stack 3
B_8 Z_101 D_2 D_11 
Stack 4
D_0 Z_102 D_4 D_3 
Stack 5
Z_103 B_3 C_8 E_0 
Stack 6
C_13 Z_104 Z_105 Z_106 
Stack 7
Z_107 Z_108 C_7 E_10 
Stack 8
B_4 D_9 A_10 A_1 
Stack 9
B_0 C_11 B_2 B_1 
Stack 10
C_3 E_11 D_5 D_1 
Stack 11
E_9 E_13 E_1 E_4 
Stack 12
A_0 Z_109 E_7 E_5 
Stack 13
B_6 C_12 D_10 Z_110 
Stack 14
D_7 Z_111 A_4 C_9 
Stack 15
C_6 A_9 C_10 B_7 
Stack 16
A_7 C_14 E_12 E_14 
Stack 17
E_3 Z_112 Z_113 B_5 
Stack 18
C_2 A_2 Z_114 Z_115 
Stack 19
C_0 A_6 A_5 
