Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
G_0 A_0 Z_100 E_7 E_3 
Stack 1
A_4 J_3 E_1 Z_101 H_1 
Stack 2
A_3 J_1 E_0 F_4 I_0 
Stack 3
D_1 H_4 Z_102 F_2 I_3 
Stack 4
G_1 E_4 G_5 B_1 H_5 
Stack 5
C_4 Z_103 Z_104 G_3 Z_105 
Stack 6
C_2 F_1 H_3 B_4 H_0 
Stack 7
D_4 E_6 Z_106 J_2 B_2 
Stack 8
D_3 F_5 I_1 F_3 D_0 
Stack 9
E_5 D_2 C_0 C_5 G_4 
Stack 10
J_4 B_3 Z_107 J_0 H_2 
Stack 11
Z_108 C_3 B_0 E_2 Z_109 
Stack 12
I_2 F_0 G_2 A_2 A_1 
Stack 13
Z_110 Z_111 C_1 Z_112 Z_113 
