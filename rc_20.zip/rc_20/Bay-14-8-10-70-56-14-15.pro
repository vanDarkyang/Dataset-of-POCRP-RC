Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
G_0 C_4 J_0 Z_100 Z_101 
Stack 1
D_5 J_2 G_4 A_3 Z_102 
Stack 2
F_5 C_1 C_2 B_1 G_3 
Stack 3
Z_103 H_1 E_0 I_3 C_0 
Stack 4
F_0 D_3 H_0 G_5 C_3 
Stack 5
F_4 E_1 Z_104 D_2 Z_105 
Stack 6
D_4 F_2 B_2 Z_106 E_2 
Stack 7
F_6 H_3 Z_107 D_6 Z_108 
Stack 8
B_3 D_7 I_2 G_6 J_3 
Stack 9
Z_109 J_1 H_4 H_5 I_4 
Stack 10
E_3 H_2 Z_110 F_1 A_0 
Stack 11
G_2 D_0 B_0 Z_111 E_4 
Stack 12
A_2 E_5 Z_112 F_3 I_0 
Stack 13
I_1 Z_113 G_1 A_1 D_1 
