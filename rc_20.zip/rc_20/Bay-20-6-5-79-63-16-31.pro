Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
B_9 Z_100 B_10 Z_101 
Stack 1
C_0 B_0 E_12 Z_102 
Stack 2
Z_103 Z_104 A_0 D_8 
Stack 3
Z_105 Z_106 B_11 D_6 
Stack 4
C_5 B_1 D_0 E_5 
Stack 5
B_4 B_5 E_11 A_9 
Stack 6
A_10 C_4 B_3 Z_107 
Stack 7
Z_108 E_1 A_2 C_2 
Stack 8
E_2 C_12 E_8 D_2 
Stack 9
C_11 C_1 D_5 C_10 
Stack 10
Z_109 D_9 D_10 B_7 
Stack 11
C_9 E_10 A_8 A_1 
Stack 12
Z_110 B_2 D_11 E_0 
Stack 13
Z_111 Z_112 B_6 B_8 
Stack 14
C_6 A_4 E_6 C_13 
Stack 15
D_1 A_3 E_7 C_7 
Stack 16
E_3 Z_113 D_7 Z_114 
Stack 17
C_3 B_12 A_5 E_9 
Stack 18
Z_115 D_3 E_4 A_6 
Stack 19
D_4 A_7 C_8 
