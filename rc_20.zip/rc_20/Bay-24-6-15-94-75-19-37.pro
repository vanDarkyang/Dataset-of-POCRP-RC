Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 G_4 D_1 B_0 
Stack 1
G_0 J_2 H_3 F_6 
Stack 2
Z_101 O_0 G_3 O_1 
Stack 3
Z_102 G_6 I_6 L_1 
Stack 4
I_4 Z_103 Z_104 F_2 
Stack 5
C_1 Z_105 G_2 I_8 
Stack 6
N_0 Z_106 E_2 J_3 
Stack 7
E_3 D_0 Z_107 Z_108 
Stack 8
J_4 Z_109 I_5 I_3 
Stack 9
K_3 F_4 J_5 Z_110 
Stack 10
B_2 F_1 J_7 H_2 
Stack 11
Z_111 F_5 E_1 H_1 
Stack 12
L_4 I_0 E_0 N_1 
Stack 13
Z_112 H_0 M_2 L_2 
Stack 14
I_7 K_0 A_1 Z_113 
Stack 15
Z_114 H_4 Z_115 A_0 
Stack 16
D_3 C_0 F_3 I_2 
Stack 17
J_0 D_5 D_4 F_7 
Stack 18
L_0 C_2 Z_116 H_5 
Stack 19
I_1 K_1 M_1 N_2 
Stack 20
H_6 Z_117 B_1 G_1 
Stack 21
J_1 L_3 G_5 D_2 
Stack 22
Z_118 K_4 F_0 
Stack 23
K_2 M_0 J_6 
