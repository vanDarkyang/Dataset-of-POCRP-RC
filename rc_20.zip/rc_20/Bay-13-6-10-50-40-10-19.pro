Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 Z_101 A_2 I_1 
Stack 1
F_0 I_0 Z_102 J_1 
Stack 2
Z_103 D_2 Z_104 Z_105 
Stack 3
E_3 D_0 B_1 G_4 
Stack 4
Z_106 J_0 H_2 G_3 
Stack 5
G_0 A_1 Z_107 C_1 
Stack 6
Z_108 H_1 E_1 C_0 
Stack 7
G_1 I_2 D_4 B_0 
Stack 8
G_5 F_1 C_2 C_3 
Stack 9
E_0 J_2 E_4 E_2 
Stack 10
D_3 E_5 H_0 C_4 
Stack 11
Z_109 H_3 A_0 
Stack 12
D_1 F_2 G_2 
