Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
H_2 C_3 F_0 F_7 E_0 G_7 
Stack 1
G_4 L_1 Z_100 A_1 J_3 L_3 
Stack 2
J_1 Z_101 A_0 A_2 H_5 M_2 
Stack 3
Z_102 D_0 L_4 G_3 F_1 L_2 
Stack 4
N_1 Z_103 Z_104 Z_105 C_1 
Stack 5
E_3 I_1 J_5 J_0 L_0 
Stack 6
I_0 J_6 I_3 Z_106 E_4 
Stack 7
D_3 N_3 G_2 G_0 O_1 
Stack 8
J_2 K_3 B_1 J_4 Z_107 
Stack 9
F_3 M_0 H_3 M_1 Z_108 
Stack 10
K_1 N_0 M_3 Z_109 E_1 
Stack 11
D_2 Z_110 D_1 C_0 K_0 
Stack 12
Z_111 Z_112 H_6 Z_113 N_2 
Stack 13
M_4 O_0 F_2 E_2 Z_114 
Stack 14
F_5 K_4 L_5 K_2 G_5 
Stack 15
D_4 F_4 Z_115 Z_116 F_6 
Stack 16
Z_117 C_2 I_2 H_0 H_4 
Stack 17
Z_118 B_0 G_1 H_1 G_6 
