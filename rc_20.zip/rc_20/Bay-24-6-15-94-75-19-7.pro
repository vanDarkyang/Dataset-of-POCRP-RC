Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
J_4 F_5 J_1 G_0 
Stack 1
Z_100 H_6 F_1 H_5 
Stack 2
C_3 G_2 Z_101 L_2 
Stack 3
Z_102 M_0 F_4 H_4 
Stack 4
G_1 K_5 Z_103 C_2 
Stack 5
O_1 Z_104 H_9 G_3 
Stack 6
N_1 E_0 F_2 Z_105 
Stack 7
Z_106 G_5 Z_107 O_2 
Stack 8
Z_108 H_7 G_7 Z_109 
Stack 9
D_0 I_6 H_0 H_2 
Stack 10
A_0 I_5 K_2 J_2 
Stack 11
B_1 K_0 Z_110 J_3 
Stack 12
I_0 D_1 Z_111 L_4 
Stack 13
E_5 E_4 Z_112 F_0 
Stack 14
C_0 K_4 N_0 I_1 
Stack 15
G_6 J_0 I_3 M_1 
Stack 16
Z_113 Z_114 O_0 Z_115 
Stack 17
B_2 I_4 C_1 E_2 
Stack 18
K_3 M_2 Z_116 D_2 
Stack 19
H_1 A_1 I_7 K_1 
Stack 20
E_3 G_4 I_2 Z_117 
Stack 21
E_1 L_1 H_3 H_8 
Stack 22
N_2 L_0 L_3 
Stack 23
Z_118 B_0 F_3 
