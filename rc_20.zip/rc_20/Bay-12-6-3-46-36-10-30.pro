Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_7 B_1 C_8 C_2 
Stack 1
C_3 B_12 Z_100 Z_101 
Stack 2
A_6 A_2 C_4 C_1 
Stack 3
A_9 B_10 B_0 Z_102 
Stack 4
Z_103 C_5 Z_104 Z_105 
Stack 5
A_7 C_6 A_1 B_9 
Stack 6
A_11 B_3 B_11 C_9 
Stack 7
B_2 C_0 A_0 C_10 
Stack 8
Z_106 Z_107 Z_108 B_4 
Stack 9
Z_109 A_3 B_5 B_6 
Stack 10
B_8 A_10 C_7 
Stack 11
A_4 A_8 A_5 
