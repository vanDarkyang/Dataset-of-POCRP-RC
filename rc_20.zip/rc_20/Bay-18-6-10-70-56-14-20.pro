Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_7 F_6 D_1 H_2 
Stack 1
E_3 C_4 E_1 D_5 
Stack 2
J_1 E_5 Z_100 F_2 
Stack 3
J_0 B_4 D_2 Z_101 
Stack 4
D_4 Z_102 Z_103 E_6 
Stack 5
E_4 H_4 H_0 I_3 
Stack 6
D_6 F_7 Z_104 B_1 
Stack 7
I_2 J_2 B_2 Z_105 
Stack 8
Z_106 F_0 B_0 C_3 
Stack 9
G_4 A_2 C_1 A_0 
Stack 10
G_3 A_1 F_1 H_1 
Stack 11
H_3 Z_107 G_1 Z_108 
Stack 12
Z_109 A_3 Z_110 D_0 
Stack 13
Z_111 F_4 I_1 D_3 
Stack 14
Z_112 C_5 E_0 F_5 
Stack 15
F_3 B_3 E_2 I_0 
Stack 16
G_2 G_0 C_0 
Stack 17
C_2 F_8 Z_113 
