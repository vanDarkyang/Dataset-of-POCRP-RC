Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
K_1 B_3 E_6 L_1 E_0 J_0 
Stack 1
H_5 A_2 G_3 L_2 E_3 G_5 
Stack 2
M_5 J_5 F_3 Z_100 Z_101 N_4 
Stack 3
Z_102 E_5 I_6 D_6 Z_103 Z_104 
Stack 4
O_2 J_2 D_0 I_5 E_1 
Stack 5
M_2 F_1 D_7 N_1 J_4 
Stack 6
A_0 M_4 Z_105 F_0 Z_106 
Stack 7
J_1 K_3 Z_107 M_0 F_4 
Stack 8
A_1 H_3 C_2 O_1 C_4 
Stack 9
D_1 G_4 I_0 I_3 Z_108 
Stack 10
H_0 E_2 H_2 Z_109 M_3 
Stack 11
Z_110 H_6 O_3 Z_111 C_1 
Stack 12
L_3 G_0 N_2 L_0 H_4 
Stack 13
G_8 J_7 F_2 Z_112 Z_113 
Stack 14
C_0 K_4 H_7 L_5 K_0 
Stack 15
D_4 Z_114 Z_115 F_6 B_2 
Stack 16
Z_116 Z_117 G_6 Z_118 B_0 
Stack 17
K_2 Z_119 Z_120 H_8 Z_121 
Stack 18
N_0 N_3 M_1 L_4 J_6 
Stack 19
I_7 D_3 B_4 F_5 J_3 
Stack 20
D_2 B_1 I_1 Z_122 I_4 
Stack 21
H_1 E_4 Z_123 L_6 D_5 
Stack 22
I_2 G_1 J_8 G_7 H_9 
Stack 23
G_2 O_0 Z_124 K_5 C_3 
