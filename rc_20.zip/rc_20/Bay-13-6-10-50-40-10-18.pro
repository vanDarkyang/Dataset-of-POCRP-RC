Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_2 F_6 E_4 Z_100 
Stack 1
I_0 C_3 Z_101 D_0 
Stack 2
Z_102 F_5 B_2 E_2 
Stack 3
B_3 E_3 H_0 C_0 
Stack 4
C_1 F_3 G_1 F_4 
Stack 5
J_1 J_2 F_0 D_1 
Stack 6
I_1 G_0 H_1 G_2 
Stack 7
Z_103 Z_104 Z_105 E_0 
Stack 8
I_3 Z_106 Z_107 B_1 
Stack 9
E_5 D_2 A_0 B_0 
Stack 10
I_2 A_1 F_2 J_0 
Stack 11
D_3 E_1 D_4 
Stack 12
Z_108 Z_109 F_1 
