Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 B_2 C_0 A_0 E_1 
Stack 1
E_0 B_7 D_2 A_8 E_2 
Stack 2
Z_101 C_5 D_3 D_5 Z_102 
Stack 3
A_4 C_6 Z_103 E_4 Z_104 
Stack 4
E_6 A_7 D_6 Z_105 Z_106 
Stack 5
E_5 D_4 B_4 E_7 B_6 
Stack 6
A_1 A_6 D_1 D_8 A_2 
Stack 7
B_5 B_8 Z_107 Z_108 D_7 
Stack 8
Z_109 Z_110 C_1 E_3 A_3 
Stack 9
B_3 B_0 C_2 B_1 C_4 
Stack 10
C_7 C_3 D_0 A_5 
