Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
K_3 G_2 J_3 Z_100 I_6 E_2 
Stack 1
B_1 G_1 O_0 Z_101 O_1 Z_102 
Stack 2
G_3 N_2 H_1 N_1 E_0 Z_103 
Stack 3
Z_104 H_4 J_1 M_0 C_2 F_2 
Stack 4
A_1 B_0 D_2 G_4 J_4 
Stack 5
K_2 M_3 Z_105 L_2 E_3 
Stack 6
G_7 G_8 B_2 M_1 D_1 
Stack 7
G_6 E_5 F_4 G_5 H_3 
Stack 8
Z_106 Z_107 Z_108 D_4 Z_109 
Stack 9
I_3 I_0 Z_110 Z_111 F_3 
Stack 10
L_4 I_2 Z_112 L_3 H_5 
Stack 11
J_2 C_1 Z_113 J_5 Z_114 
Stack 12
Z_115 F_0 L_0 C_0 G_0 
Stack 13
K_4 H_2 J_0 M_4 Z_116 
Stack 14
K_1 I_1 I_4 E_1 A_0 
Stack 15
D_3 L_1 I_5 F_6 K_0 
Stack 16
F_1 I_7 D_0 Z_117 Z_118 
Stack 17
E_4 M_2 F_5 N_0 H_0 
