Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_0 C_1 Z_100 H_0 G_2 
Stack 1
H_1 D_3 H_4 I_0 B_1 
Stack 2
B_4 Z_101 E_5 E_3 I_3 
Stack 3
E_1 J_2 C_0 E_4 Z_102 
Stack 4
F_2 H_2 F_0 D_2 A_1 
Stack 5
H_6 G_0 F_4 Z_103 C_2 
Stack 6
A_0 J_1 D_4 E_2 H_5 
Stack 7
G_7 D_5 F_5 Z_104 B_3 
Stack 8
F_1 J_0 D_1 Z_105 G_3 
Stack 9
G_1 A_3 Z_106 G_5 G_4 
Stack 10
E_6 B_0 E_0 I_2 F_3 
Stack 11
Z_107 Z_108 I_1 Z_109 J_3 
Stack 12
Z_110 D_6 Z_111 A_2 B_2 
Stack 13
Z_112 H_3 G_6 C_3 Z_113 
