Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 B_7 E_6 Z_101 
Stack 1
Z_102 D_0 B_0 B_1 
Stack 2
Z_103 Z_104 C_6 B_2 
Stack 3
D_8 Z_105 D_4 Z_106 
Stack 4
D_9 A_6 C_0 D_7 
Stack 5
B_4 E_1 A_3 B_3 
Stack 6
C_7 E_4 Z_107 D_1 
Stack 7
D_6 B_8 Z_108 C_5 
Stack 8
A_4 C_4 B_6 E_3 
Stack 9
A_2 Z_109 E_2 D_3 
Stack 10
C_1 C_2 E_0 E_5 
Stack 11
C_8 C_3 A_7 A_5 
Stack 12
A_0 B_5 Z_110 
Stack 13
A_1 D_5 D_2 
