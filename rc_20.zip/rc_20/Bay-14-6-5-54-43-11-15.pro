Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 Z_101 Z_102 A_2 
Stack 1
C_6 D_0 C_0 D_1 
Stack 2
D_2 Z_103 C_5 C_3 
Stack 3
B_1 Z_104 B_5 D_7 
Stack 4
A_7 B_2 A_1 Z_105 
Stack 5
C_8 Z_106 B_9 Z_107 
Stack 6
C_4 A_6 C_7 D_4 
Stack 7
E_6 A_0 E_3 A_3 
Stack 8
D_3 C_9 D_5 B_3 
Stack 9
Z_108 E_0 B_4 A_5 
Stack 10
E_5 D_6 Z_109 B_0 
Stack 11
E_4 B_8 C_2 B_6 
Stack 12
E_1 E_2 Z_110 
Stack 13
C_1 B_7 A_4 
