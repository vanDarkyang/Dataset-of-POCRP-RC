Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_3 F_2 I_0 Z_100 Z_101 
Stack 1
J_1 G_5 A_0 Z_102 Z_103 
Stack 2
F_4 Z_104 B_1 J_0 C_0 
Stack 3
D_1 F_6 B_2 G_3 F_0 
Stack 4
E_0 I_3 G_2 F_3 D_2 
Stack 5
C_4 G_4 I_2 Z_105 C_2 
Stack 6
F_1 D_4 H_0 H_1 G_0 
Stack 7
C_1 D_0 Z_106 E_1 G_1 
Stack 8
C_3 B_0 F_5 I_1 Z_107 
Stack 9
J_2 Z_108 D_3 E_2 Z_109 
