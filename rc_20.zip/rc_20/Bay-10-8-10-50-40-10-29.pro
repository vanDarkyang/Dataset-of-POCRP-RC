Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 Z_101 D_1 A_1 E_1 
Stack 1
B_0 J_1 I_3 B_1 F_2 
Stack 2
B_2 F_3 C_0 G_2 F_1 
Stack 3
J_0 F_0 Z_102 I_0 F_4 
Stack 4
E_0 D_2 E_2 Z_103 E_3 
Stack 5
G_3 Z_104 Z_105 Z_106 G_4 
Stack 6
D_4 H_2 H_1 G_1 I_1 
Stack 7
D_0 A_0 D_3 C_4 H_4 
Stack 8
H_0 C_1 C_3 C_2 Z_107 
Stack 9
H_3 Z_108 I_2 Z_109 G_0 
