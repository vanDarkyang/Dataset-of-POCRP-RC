Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_3 F_6 H_1 E_2 
Stack 1
J_1 I_3 H_0 E_1 
Stack 2
F_4 Z_100 F_5 Z_101 
Stack 3
D_0 D_4 D_3 C_0 
Stack 4
Z_102 Z_103 H_4 F_0 
Stack 5
C_4 Z_104 Z_105 D_1 
Stack 6
F_1 Z_106 J_0 C_2 
Stack 7
C_1 I_0 Z_107 G_0 
Stack 8
C_3 A_0 F_3 Z_108 
Stack 9
J_2 Z_109 H_3 B_0 
Stack 10
F_2 B_1 H_2 D_2 
Stack 11
G_2 G_1 E_0 
Stack 12
A_1 I_2 I_1 
