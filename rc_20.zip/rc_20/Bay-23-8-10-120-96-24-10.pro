Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
G_6 H_3 Z_100 F_11 J_3 D_1 
Stack 1
B_7 G_2 Z_101 D_7 Z_102 B_6 
Stack 2
E_11 D_6 A_2 Z_103 E_10 D_5 
Stack 3
G_5 Z_104 C_2 E_12 H_1 B_3 
Stack 4
C_4 A_0 F_7 G_4 H_0 Z_105 
Stack 5
Z_106 Z_107 C_3 E_9 J_4 
Stack 6
B_0 A_3 E_8 G_7 H_4 
Stack 7
Z_108 H_6 C_0 D_10 B_1 
Stack 8
G_10 I_4 B_4 G_0 Z_109 
Stack 9
F_1 F_9 E_13 Z_110 D_2 
Stack 10
Z_111 E_1 G_1 Z_112 F_12 
Stack 11
F_2 Z_113 J_2 D_8 A_4 
Stack 12
E_2 F_13 I_1 B_5 B_8 
Stack 13
C_7 F_6 J_7 H_8 J_1 
Stack 14
H_5 A_5 F_8 A_1 F_3 
Stack 15
G_3 E_5 F_10 Z_114 E_7 
Stack 16
C_6 I_0 D_3 Z_115 D_9 
Stack 17
F_4 I_3 J_6 C_1 I_2 
Stack 18
Z_116 Z_117 Z_118 H_7 F_5 
Stack 19
J_5 H_2 G_8 C_5 E_0 
Stack 20
D_0 D_11 B_2 D_4 G_9 
Stack 21
E_3 Z_119 F_0 J_0 E_6 
Stack 22
Z_120 Z_121 E_4 Z_122 Z_123 
