Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_2 Z_100 E_6 F_6 Z_101 
Stack 1
A_1 D_1 I_3 Z_102 I_1 
Stack 2
G_2 Z_103 H_3 D_5 G_5 
Stack 3
F_3 G_4 E_0 Z_104 E_1 
Stack 4
F_1 G_0 B_0 Z_105 Z_106 
Stack 5
F_0 Z_107 B_3 F_5 J_2 
Stack 6
C_2 Z_108 J_1 C_0 E_7 
Stack 7
A_2 H_0 Z_109 D_6 C_3 
Stack 8
J_3 C_5 Z_110 H_2 Z_111 
Stack 9
G_1 G_3 J_0 F_4 H_1 
Stack 10
Z_112 Z_113 F_2 B_1 D_3 
Stack 11
D_0 E_4 G_7 C_1 D_2 
Stack 12
G_6 C_4 E_3 B_4 I_0 
Stack 13
A_0 I_2 E_5 D_4 E_2 
