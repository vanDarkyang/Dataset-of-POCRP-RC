Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
J_0 Z_100 Z_101 E_0 
Stack 1
K_2 H_6 K_1 N_2 
Stack 2
H_2 Z_102 G_4 B_1 
Stack 3
D_0 H_3 E_1 F_2 
Stack 4
G_2 L_2 F_3 Z_103 
Stack 5
D_5 E_5 Z_104 Z_105 
Stack 6
E_2 M_2 N_3 G_0 
Stack 7
D_1 C_0 L_1 G_3 
Stack 8
J_2 F_0 H_1 G_1 
Stack 9
H_5 A_0 Z_106 Z_107 
Stack 10
H_7 N_1 I_2 N_0 
Stack 11
B_2 K_0 I_5 M_0 
Stack 12
H_0 I_3 J_1 C_1 
Stack 13
F_4 H_4 J_4 Z_108 
Stack 14
E_4 D_2 Z_109 Z_110 
Stack 15
E_6 A_1 Z_111 G_5 
Stack 16
L_0 J_5 C_2 J_6 
Stack 17
E_3 L_4 I_4 Z_112 
Stack 18
D_3 K_3 Z_113 O_0 
Stack 19
I_1 Z_114 D_4 I_0 
Stack 20
C_3 O_2 M_1 K_4 
Stack 21
Z_115 J_3 Z_116 L_3 
Stack 22
F_5 B_0 O_1 
Stack 23
Z_117 Z_118 F_1 
