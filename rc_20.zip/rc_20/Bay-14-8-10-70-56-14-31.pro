Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 B_4 G_3 A_1 C_1 
Stack 1
H_0 Z_101 D_5 E_2 D_2 
Stack 2
Z_102 G_0 H_1 D_4 I_3 
Stack 3
C_4 C_2 F_3 Z_103 I_2 
Stack 4
G_6 F_5 Z_104 A_2 G_1 
Stack 5
G_2 Z_105 Z_106 H_4 F_0 
Stack 6
Z_107 E_5 C_0 J_0 B_0 
Stack 7
E_0 E_1 G_5 Z_108 E_4 
Stack 8
F_6 I_4 B_2 D_0 J_2 
Stack 9
C_3 D_3 C_5 H_3 Z_109 
Stack 10
B_1 I_1 D_1 H_2 A_3 
Stack 11
J_1 J_3 Z_110 Z_111 F_2 
Stack 12
A_0 F_1 E_3 F_4 Z_112 
Stack 13
I_0 G_4 B_3 D_6 Z_113 
