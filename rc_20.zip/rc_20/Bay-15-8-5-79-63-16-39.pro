Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_3 Z_100 B_2 D_3 D_6 E_5 
Stack 1
C_1 A_10 B_6 Z_101 D_2 C_2 
Stack 2
C_10 B_11 A_5 Z_102 A_1 Z_103 
Stack 3
B_9 Z_104 C_0 D_5 A_8 Z_105 
Stack 4
A_4 D_7 Z_106 Z_107 Z_108 
Stack 5
Z_109 A_2 A_11 Z_110 B_8 
Stack 6
B_0 Z_111 D_11 C_5 E_8 
Stack 7
A_6 D_1 D_12 Z_112 A_0 
Stack 8
B_3 D_8 E_3 Z_113 B_1 
Stack 9
E_6 E_2 C_4 Z_114 E_4 
Stack 10
B_7 C_11 C_3 B_4 D_10 
Stack 11
D_0 Z_115 B_12 E_0 A_12 
Stack 12
B_5 D_9 B_10 D_14 A_9 
Stack 13
C_7 E_1 C_9 C_8 E_7 
Stack 14
A_13 C_6 D_13 D_4 A_7 
