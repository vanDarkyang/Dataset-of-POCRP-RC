Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
D_0 F_1 N_2 Z_100 A_0 N_3 
Stack 1
M_6 C_6 D_2 Z_101 I_4 J_0 
Stack 2
E_1 G_3 A_3 M_5 N_1 M_1 
Stack 3
F_3 Z_102 Z_103 G_5 B_1 H_9 
Stack 4
Z_104 G_6 O_3 H_11 Z_105 
Stack 5
C_0 I_1 K_1 D_1 N_4 
Stack 6
Z_106 G_2 J_7 I_8 O_1 
Stack 7
Z_107 B_3 J_2 G_7 A_1 
Stack 8
H_6 J_4 L_0 G_9 N_0 
Stack 9
Z_108 H_1 B_0 O_0 M_2 
Stack 10
M_4 A_4 I_3 D_4 Z_109 
Stack 11
Z_110 L_1 C_4 D_3 C_1 
Stack 12
H_8 Z_111 I_2 Z_112 Z_113 
Stack 13
J_3 H_2 L_4 G_4 Z_114 
Stack 14
Z_115 L_2 Z_116 K_0 H_4 
Stack 15
I_6 C_3 E_2 E_3 G_8 
Stack 16
Z_117 H_0 H_10 C_5 Z_118 
Stack 17
C_2 Z_119 J_5 A_2 H_3 
Stack 18
K_2 G_1 B_2 F_2 G_0 
Stack 19
L_3 Z_120 I_0 O_2 J_6 
Stack 20
K_5 Z_121 E_0 Z_122 I_7 
Stack 21
Z_123 D_5 H_7 F_5 F_4 
Stack 22
M_3 H_5 M_0 K_4 Z_124 
Stack 23
I_5 J_1 K_3 O_4 F_0 
