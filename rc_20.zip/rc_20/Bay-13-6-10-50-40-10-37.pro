Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 E_3 E_2 Z_101 
Stack 1
F_4 F_0 H_1 D_2 
Stack 2
G_2 D_4 B_0 Z_102 
Stack 3
C_0 Z_103 H_3 I_0 
Stack 4
A_0 B_2 D_3 E_4 
Stack 5
B_1 I_2 G_1 G_3 
Stack 6
I_1 E_1 B_3 F_2 
Stack 7
C_2 A_1 G_4 D_1 
Stack 8
J_0 H_0 Z_104 F_1 
Stack 9
Z_105 F_3 Z_106 Z_107 
Stack 10
Z_108 D_0 G_5 C_1 
Stack 11
E_0 Z_109 C_4 
Stack 12
H_2 G_0 C_3 
