Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
Z_100 E_6 H_5 O_4 A_2 G_5 
Stack 1
G_1 G_4 Z_101 D_3 B_0 Z_102 
Stack 2
C_2 H_4 B_2 K_4 J_2 F_0 
Stack 3
M_4 C_5 D_1 L_7 G_7 H_2 
Stack 4
H_3 Z_103 L_2 L_5 I_1 
Stack 5
H_0 C_6 N_4 M_1 E_0 
Stack 6
Z_104 F_4 D_5 I_3 Z_105 
Stack 7
E_1 N_2 H_1 F_5 Z_106 
Stack 8
I_4 B_1 L_4 Z_107 B_3 
Stack 9
Z_108 E_4 K_0 K_5 Z_109 
Stack 10
Z_110 L_6 H_7 I_2 Z_111 
Stack 11
G_6 G_8 C_1 M_3 O_1 
Stack 12
Z_112 N_0 H_6 Z_113 O_2 
Stack 13
D_0 Z_114 F_2 O_3 I_0 
Stack 14
G_2 J_0 F_1 K_3 J_3 
Stack 15
Z_115 G_3 L_0 M_2 B_4 
Stack 16
G_9 Z_116 M_0 I_8 N_1 
Stack 17
Z_117 G_0 O_0 C_0 H_8 
Stack 18
L_3 Z_118 Z_119 M_5 A_1 
Stack 19
C_3 I_5 Z_120 E_2 F_3 
Stack 20
I_9 E_5 D_2 L_1 Z_121 
Stack 21
Z_122 N_3 Z_123 D_4 I_7 
Stack 22
E_3 C_4 K_1 F_6 I_6 
Stack 23
K_2 A_0 D_6 J_1 Z_124 
