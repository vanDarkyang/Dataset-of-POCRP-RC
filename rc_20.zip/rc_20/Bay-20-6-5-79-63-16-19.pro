Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_1 C_3 B_11 Z_100 
Stack 1
A_6 D_12 Z_101 A_0 
Stack 2
C_10 C_0 D_6 C_7 
Stack 3
A_8 Z_102 B_2 B_12 
Stack 4
Z_103 D_0 B_5 D_3 
Stack 5
Z_104 E_9 C_4 A_7 
Stack 6
Z_105 Z_106 E_8 E_5 
Stack 7
B_0 Z_107 E_3 E_2 
Stack 8
Z_108 D_9 D_4 A_12 
Stack 9
D_8 B_6 Z_109 A_3 
Stack 10
B_3 C_2 Z_110 E_10 
Stack 11
D_5 D_1 Z_111 A_11 
Stack 12
C_6 C_1 D_11 C_5 
Stack 13
E_11 C_9 E_4 C_8 
Stack 14
A_5 D_10 Z_112 E_6 
Stack 15
Z_113 A_9 D_7 A_4 
Stack 16
D_2 Z_114 E_7 B_7 
Stack 17
B_9 B_4 Z_115 A_2 
Stack 18
E_0 D_13 A_10 B_10 
Stack 19
B_1 B_8 E_1 
