Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 J_5 C_1 Z_101 
Stack 1
G_4 E_1 Z_102 Z_103 
Stack 2
Z_104 D_4 J_3 F_2 
Stack 3
Z_105 Z_106 D_0 O_0 
Stack 4
H_5 J_4 K_0 Z_107 
Stack 5
Z_108 D_3 Z_109 H_3 
Stack 6
Z_110 E_5 I_1 E_0 
Stack 7
Z_111 Z_112 J_0 N_1 
Stack 8
L_1 M_4 D_2 B_2 
Stack 9
I_5 Z_113 K_3 E_2 
Stack 10
Z_114 M_3 H_1 D_1 
Stack 11
G_2 I_7 I_3 J_6 
Stack 12
L_2 J_2 I_4 H_4 
Stack 13
G_3 F_6 K_1 M_2 
Stack 14
B_0 H_0 B_1 N_0 
Stack 15
F_1 F_3 F_4 E_4 
Stack 16
J_1 I_0 N_2 M_0 
Stack 17
I_6 Z_115 A_0 M_1 
Stack 18
G_5 O_1 F_5 C_0 
Stack 19
L_3 L_4 A_2 E_3 
Stack 20
K_2 H_2 I_2 O_2 
Stack 21
G_0 Z_116 F_0 L_0 
Stack 22
A_1 Z_117 G_1 
Stack 23
F_7 Z_118 C_2 
