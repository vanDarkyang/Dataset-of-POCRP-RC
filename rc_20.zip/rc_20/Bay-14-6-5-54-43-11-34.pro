Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_5 Z_100 A_3 Z_101 
Stack 1
E_8 C_8 Z_102 E_0 
Stack 2
Z_103 Z_104 A_4 E_6 
Stack 3
E_7 C_6 B_2 C_1 
Stack 4
A_0 E_2 D_3 Z_105 
Stack 5
A_7 C_2 Z_106 Z_107 
Stack 6
B_7 A_2 D_4 C_0 
Stack 7
Z_108 D_0 E_4 E_1 
Stack 8
C_3 D_7 D_5 Z_109 
Stack 9
B_3 E_3 C_5 C_7 
Stack 10
C_4 B_0 D_1 A_5 
Stack 11
D_6 A_1 B_6 Z_110 
Stack 12
D_2 A_6 B_1 
Stack 13
B_5 B_4 D_8 
