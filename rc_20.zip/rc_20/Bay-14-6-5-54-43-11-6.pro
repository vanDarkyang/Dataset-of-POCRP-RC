Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_8 E_1 D_7 D_6 
Stack 1
D_0 E_3 D_1 B_3 
Stack 2
C_3 C_5 Z_100 E_6 
Stack 3
C_9 D_4 E_7 Z_101 
Stack 4
A_5 B_6 A_3 D_2 
Stack 5
Z_102 Z_103 B_2 B_4 
Stack 6
C_2 E_2 E_8 Z_104 
Stack 7
D_5 B_1 C_7 Z_105 
Stack 8
B_8 A_1 C_0 C_6 
Stack 9
B_0 A_6 Z_106 B_5 
Stack 10
E_4 A_0 E_5 Z_107 
Stack 11
Z_108 A_4 C_4 Z_109 
Stack 12
B_7 E_0 D_3 
Stack 13
A_2 C_1 Z_110 
