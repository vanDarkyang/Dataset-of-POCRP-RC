Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 G_3 F_1 A_0 C_0 
Stack 1
H_4 F_2 E_4 I_4 F_6 
Stack 2
G_2 E_3 Z_101 D_3 Z_102 
Stack 3
Z_103 D_1 Z_104 D_6 I_5 
Stack 4
C_4 E_2 J_0 C_1 C_2 
Stack 5
C_3 J_1 F_0 Z_105 A_4 
Stack 6
A_3 H_3 D_2 F_3 D_4 
Stack 7
Z_106 Z_107 I_2 F_4 A_1 
Stack 8
E_6 H_1 E_5 D_5 I_3 
Stack 9
E_0 H_0 J_2 B_2 Z_108 
Stack 10
Z_109 Z_110 B_4 B_0 Z_111 
Stack 11
F_5 I_1 G_4 B_3 Z_112 
Stack 12
B_1 G_0 Z_113 E_1 D_0 
Stack 13
C_5 A_2 G_1 H_2 I_0 
