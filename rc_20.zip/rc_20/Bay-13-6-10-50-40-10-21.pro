Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
D_1 E_2 A_0 A_2 
Stack 1
D_0 A_1 G_1 Z_100 
Stack 2
H_0 E_0 F_4 Z_101 
Stack 3
F_3 I_2 J_0 D_5 
Stack 4
C_0 Z_102 Z_103 Z_104 
Stack 5
C_3 C_2 Z_105 G_2 
Stack 6
D_3 Z_106 H_2 J_1 
Stack 7
E_3 E_1 I_0 C_1 
Stack 8
Z_107 F_1 Z_108 I_1 
Stack 9
B_0 B_2 B_3 G_0 
Stack 10
F_0 D_2 B_1 F_5 
Stack 11
Z_109 F_2 H_1 
Stack 12
D_4 H_3 F_6 
