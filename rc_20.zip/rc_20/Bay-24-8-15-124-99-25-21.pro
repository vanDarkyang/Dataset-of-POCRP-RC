Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
A_1 K_1 L_0 Z_100 H_7 Z_101 
Stack 1
D_0 F_1 D_2 Z_102 J_4 N_0 
Stack 2
J_1 H_0 L_6 K_4 M_2 Z_103 
Stack 3
Z_104 G_5 A_3 H_8 N_4 C_2 
Stack 4
E_2 E_4 C_3 E_0 Z_105 
Stack 5
E_5 Z_106 D_7 B_5 M_3 
Stack 6
K_0 H_2 I_6 L_4 J_2 
Stack 7
M_1 G_0 I_5 J_3 H_6 
Stack 8
F_2 Z_107 L_1 G_2 Z_108 
Stack 9
N_1 E_1 K_2 I_2 Z_109 
Stack 10
Z_110 N_2 D_5 Z_111 K_3 
Stack 11
Z_112 Z_113 G_7 K_6 K_5 
Stack 12
C_4 G_1 Z_114 J_0 Z_115 
Stack 13
D_3 F_4 Z_116 I_1 D_1 
Stack 14
Z_117 F_3 Z_118 I_3 N_3 
Stack 15
E_6 H_5 Z_119 N_5 L_5 
Stack 16
F_5 B_0 C_0 F_6 B_2 
Stack 17
G_8 A_0 D_4 G_4 I_4 
Stack 18
K_7 I_7 H_1 Z_120 H_3 
Stack 19
L_2 O_1 D_6 H_4 Z_121 
Stack 20
G_6 B_1 B_3 G_3 J_6 
Stack 21
Z_122 H_9 L_3 I_0 E_3 
Stack 22
O_2 J_5 M_0 F_0 C_1 
Stack 23
Z_123 B_4 O_0 A_2 Z_124 
