Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
H_3 Z_100 A_0 Z_101 
Stack 1
Z_102 F_5 Z_103 E_1 
Stack 2
B_2 E_7 G_3 A_1 
Stack 3
E_2 I_2 Z_104 H_2 
Stack 4
Z_105 D_5 E_4 C_4 
Stack 5
Z_106 Z_107 F_4 D_4 
Stack 6
F_2 Z_108 H_0 Z_109 
Stack 7
E_6 B_0 B_4 E_3 
Stack 8
C_5 B_1 C_3 I_3 
Stack 9
H_5 G_0 F_1 E_0 
Stack 10
C_2 H_4 E_5 Z_110 
Stack 11
C_6 Z_111 H_1 B_5 
Stack 12
C_0 D_0 G_4 J_0 
Stack 13
I_0 G_5 A_2 D_3 
Stack 14
Z_112 I_1 D_2 F_0 
Stack 15
B_3 G_2 A_3 F_6 
Stack 16
C_1 G_1 D_1 
Stack 17
Z_113 I_4 F_3 
