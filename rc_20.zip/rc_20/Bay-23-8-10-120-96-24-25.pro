Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
F_5 E_7 C_2 F_7 J_4 I_6 
Stack 1
J_2 E_4 G_6 D_2 Z_100 E_0 
Stack 2
C_0 E_8 G_4 Z_101 J_1 Z_102 
Stack 3
J_3 H_0 Z_103 Z_104 F_0 B_4 
Stack 4
A_2 H_2 I_1 E_6 A_4 F_9 
Stack 5
F_10 I_8 J_7 C_1 F_3 
Stack 6
A_0 G_3 I_9 A_6 B_2 
Stack 7
Z_105 I_0 Z_106 D_4 A_3 
Stack 8
F_1 Z_107 F_11 G_5 Z_108 
Stack 9
E_3 J_6 E_10 F_6 I_2 
Stack 10
Z_109 B_3 G_7 B_0 H_4 
Stack 11
E_9 H_6 G_8 E_5 H_8 
Stack 12
H_5 Z_110 A_1 Z_111 E_2 
Stack 13
I_3 Z_112 D_8 Z_113 E_1 
Stack 14
H_1 A_5 C_5 Z_114 Z_115 
Stack 15
B_7 G_2 D_5 I_4 C_4 
Stack 16
H_9 J_0 Z_116 C_3 G_1 
Stack 17
H_7 D_1 I_7 B_6 J_5 
Stack 18
D_6 Z_117 G_9 I_5 D_3 
Stack 19
C_6 Z_118 B_5 Z_119 G_0 
Stack 20
C_8 B_1 F_2 Z_120 D_0 
Stack 21
H_3 Z_121 E_12 C_7 F_8 
Stack 22
E_11 D_7 Z_122 Z_123 F_4 
