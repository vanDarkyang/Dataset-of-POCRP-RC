Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 B_1 C_9 E_6 
Stack 1
A_3 C_2 Z_101 Z_102 
Stack 2
C_8 A_0 C_7 E_3 
Stack 3
D_4 E_0 A_8 Z_103 
Stack 4
B_6 B_7 Z_104 Z_105 
Stack 5
A_1 Z_106 D_1 A_2 
Stack 6
E_2 E_1 D_0 D_6 
Stack 7
C_5 A_6 E_5 A_9 
Stack 8
D_2 C_1 B_4 C_4 
Stack 9
Z_107 Z_108 C_3 E_4 
Stack 10
B_3 B_5 A_7 Z_109 
Stack 11
A_4 C_0 D_5 E_7 
Stack 12
B_2 C_6 Z_110 
Stack 13
A_5 B_0 D_3 
