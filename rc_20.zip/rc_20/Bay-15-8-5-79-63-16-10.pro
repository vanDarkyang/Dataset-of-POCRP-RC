Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
D_9 Z_100 C_8 Z_101 E_9 E_10 
Stack 1
D_5 D_0 Z_102 D_3 A_10 C_6 
Stack 2
Z_103 D_6 D_4 B_10 E_5 Z_104 
Stack 3
Z_105 B_4 Z_106 C_0 C_4 D_7 
Stack 4
C_12 B_9 B_5 C_7 B_8 
Stack 5
A_5 Z_107 D_12 B_6 E_4 
Stack 6
Z_108 Z_109 A_12 E_7 E_8 
Stack 7
C_10 B_2 B_7 A_11 B_0 
Stack 8
C_9 A_0 Z_110 A_8 C_13 
Stack 9
B_1 E_6 D_8 E_2 E_1 
Stack 10
A_3 D_10 C_1 E_0 A_1 
Stack 11
A_6 D_1 Z_111 C_2 E_3 
Stack 12
Z_112 A_9 B_11 C_3 B_3 
Stack 13
Z_113 C_11 C_5 D_11 A_2 
Stack 14
Z_114 A_7 A_4 Z_115 D_2 
