Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 E_4 B_5 A_8 
Stack 1
D_1 A_4 Z_101 Z_102 
Stack 2
Z_103 D_5 E_2 C_10 
Stack 3
A_1 D_9 E_9 B_14 
Stack 4
E_3 E_1 B_15 Z_104 
Stack 5
Z_105 B_3 C_11 B_11 
Stack 6
Z_106 D_11 C_2 A_10 
Stack 7
Z_107 Z_108 D_0 D_2 
Stack 8
D_10 E_0 D_8 C_7 
Stack 9
D_4 D_7 A_6 B_12 
Stack 10
D_6 E_8 A_9 Z_109 
Stack 11
C_4 B_2 C_5 D_3 
Stack 12
C_0 Z_110 A_3 B_10 
Stack 13
C_8 C_6 Z_111 C_3 
Stack 14
Z_112 D_12 B_7 C_9 
Stack 15
A_2 A_7 B_4 E_10 
Stack 16
E_5 Z_113 A_5 B_0 
Stack 17
B_1 B_9 A_0 E_6 
Stack 18
Z_114 Z_115 C_1 B_13 
Stack 19
B_8 B_6 E_7 
