Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_2 Z_100 E_4 I_2 Z_101 
Stack 1
G_2 B_0 D_4 A_1 F_3 
Stack 2
Z_102 C_0 B_3 E_5 Z_103 
Stack 3
B_2 A_0 I_1 E_0 F_4 
Stack 4
D_2 E_3 F_1 E_2 G_1 
Stack 5
G_0 H_0 J_1 F_5 I_0 
Stack 6
G_3 C_3 D_1 E_6 Z_104 
Stack 7
D_0 F_0 Z_105 Z_106 J_0 
Stack 8
Z_107 B_1 C_1 Z_108 E_1 
Stack 9
H_2 C_2 H_1 Z_109 D_3 
