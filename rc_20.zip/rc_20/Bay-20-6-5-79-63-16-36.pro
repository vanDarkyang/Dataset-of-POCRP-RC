Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_3 Z_100 Z_101 E_8 
Stack 1
B_12 D_0 C_13 E_0 
Stack 2
A_0 E_2 Z_102 C_3 
Stack 3
Z_103 C_1 D_10 Z_104 
Stack 4
C_7 D_3 B_11 B_13 
Stack 5
D_5 A_5 E_11 E_7 
Stack 6
C_5 A_2 A_4 Z_105 
Stack 7
C_2 C_8 A_9 Z_106 
Stack 8
E_6 B_5 E_5 D_7 
Stack 9
A_7 C_12 D_2 B_9 
Stack 10
C_9 B_6 Z_107 B_0 
Stack 11
C_0 B_1 D_9 B_10 
Stack 12
C_6 Z_108 D_6 Z_109 
Stack 13
D_4 E_10 Z_110 D_8 
Stack 14
B_4 E_9 A_8 E_1 
Stack 15
C_11 B_2 D_12 Z_111 
Stack 16
Z_112 A_1 C_10 D_11 
Stack 17
B_3 E_3 Z_113 B_8 
Stack 18
Z_114 D_1 Z_115 A_6 
Stack 19
B_7 E_4 C_4 
