Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
D_1 Z_100 A_2 B_5 
Stack 1
E_6 E_5 C_2 E_4 
Stack 2
Z_101 Z_102 E_1 Z_103 
Stack 3
Z_104 A_1 A_3 D_0 
Stack 4
A_7 Z_105 D_4 D_3 
Stack 5
B_8 B_9 D_5 Z_106 
Stack 6
D_6 C_1 B_1 A_5 
Stack 7
D_2 E_7 B_2 C_5 
Stack 8
E_2 C_3 Z_107 B_4 
Stack 9
B_0 C_0 A_6 B_6 
Stack 10
C_6 D_7 Z_108 C_4 
Stack 11
Z_109 C_7 A_0 D_8 
Stack 12
E_0 B_7 Z_110 
Stack 13
B_3 A_4 E_3 
