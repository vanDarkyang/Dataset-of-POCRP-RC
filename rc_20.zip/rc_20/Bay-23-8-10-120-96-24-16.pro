Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
E_10 H_5 F_7 Z_100 B_1 Z_101 
Stack 1
F_3 Z_102 E_7 I_3 B_4 A_3 
Stack 2
J_1 H_8 E_3 Z_103 E_6 F_5 
Stack 3
C_7 Z_104 Z_105 F_1 H_10 Z_106 
Stack 4
I_7 A_5 H_4 B_7 Z_107 I_8 
Stack 5
B_2 Z_108 Z_109 D_6 G_1 
Stack 6
A_0 B_8 D_9 B_3 D_0 
Stack 7
F_0 I_0 E_1 E_2 C_4 
Stack 8
H_9 D_7 F_10 C_0 J_6 
Stack 9
A_6 G_2 A_7 H_3 G_6 
Stack 10
Z_110 Z_111 G_4 C_3 C_2 
Stack 11
D_4 F_6 F_11 H_2 Z_112 
Stack 12
J_3 E_0 D_2 H_1 Z_113 
Stack 13
F_4 Z_114 G_7 F_9 Z_115 
Stack 14
I_2 C_6 H_7 J_4 J_7 
Stack 15
D_1 G_3 I_6 H_0 Z_116 
Stack 16
G_5 I_4 B_6 Z_117 A_2 
Stack 17
C_1 F_8 Z_118 C_9 D_8 
Stack 18
E_8 Z_119 E_4 F_2 C_5 
Stack 19
J_0 C_8 I_1 A_1 B_0 
Stack 20
Z_120 D_3 D_5 J_2 J_5 
Stack 21
E_5 B_5 E_9 I_5 Z_121 
Stack 22
G_0 Z_122 Z_123 A_4 H_6 
