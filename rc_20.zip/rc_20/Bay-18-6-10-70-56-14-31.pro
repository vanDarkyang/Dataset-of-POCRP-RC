Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
E_2 F_4 B_1 F_3 
Stack 1
H_0 Z_100 C_6 Z_101 
Stack 2
Z_102 E_7 D_0 C_1 
Stack 3
C_5 E_3 E_1 Z_103 
Stack 4
G_7 Z_104 E_5 Z_105 
Stack 5
G_2 Z_106 B_2 I_2 
Stack 6
Z_107 I_1 A_0 G_1 
Stack 7
E_0 J_3 E_4 Z_108 
Stack 8
F_5 F_0 D_1 Z_109 
Stack 9
C_4 G_4 Z_110 E_6 
Stack 10
B_0 G_3 A_1 J_2 
Stack 11
J_1 D_3 H_5 Z_111 
Stack 12
Z_112 H_1 J_0 A_2 
Stack 13
I_0 F_2 C_3 F_1 
Stack 14
B_4 H_6 Z_113 B_3 
Stack 15
G_6 D_2 H_4 H_2 
Stack 16
G_0 C_0 H_3 
Stack 17
C_2 G_5 I_3 
