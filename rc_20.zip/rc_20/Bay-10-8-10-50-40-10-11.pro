Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_0 D_0 Z_100 Z_101 E_3 
Stack 1
H_0 C_0 I_3 Z_102 F_2 
Stack 2
F_1 D_2 A_0 Z_103 E_0 
Stack 3
G_3 Z_104 I_2 D_4 I_0 
Stack 4
I_1 G_2 C_3 F_6 E_1 
Stack 5
F_4 D_1 Z_105 Z_106 E_4 
Stack 6
A_2 Z_107 C_1 A_1 C_4 
Stack 7
D_3 B_1 J_1 F_5 C_2 
Stack 8
J_0 F_0 F_3 Z_108 Z_109 
Stack 9
H_1 E_2 G_1 G_0 B_2 
