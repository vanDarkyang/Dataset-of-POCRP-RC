Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_9 A_11 B_10 E_5 Z_100 D_4 
Stack 1
D_6 B_12 D_11 B_2 Z_101 D_10 
Stack 2
D_3 A_4 B_0 B_7 C_3 C_1 
Stack 3
Z_102 A_2 A_1 Z_103 E_9 Z_104 
Stack 4
Z_105 A_10 D_5 Z_106 Z_107 
Stack 5
B_8 B_11 Z_108 E_3 D_2 
Stack 6
C_4 A_5 C_6 C_2 A_8 
Stack 7
Z_109 A_12 D_12 B_6 D_9 
Stack 8
E_2 A_3 B_4 Z_110 E_10 
Stack 9
Z_111 C_9 E_7 D_8 Z_112 
Stack 10
B_9 B_1 D_0 C_5 A_7 
Stack 11
A_0 C_11 E_6 D_7 E_8 
Stack 12
E_0 A_6 C_0 B_3 C_8 
Stack 13
E_1 Z_113 E_11 B_5 D_1 
Stack 14
Z_114 E_4 Z_115 C_10 C_7 
