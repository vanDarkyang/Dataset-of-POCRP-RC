Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
D_2 E_3 Z_100 C_6 A_1 
Stack 1
Z_101 Z_102 A_2 C_0 D_4 
Stack 2
Z_103 Z_104 E_5 E_0 Z_105 
Stack 3
Z_106 D_0 E_1 C_3 D_7 
Stack 4
B_1 B_7 A_3 D_6 B_6 
Stack 5
B_8 B_0 E_2 A_0 B_3 
Stack 6
E_6 Z_107 E_7 D_5 Z_108 
Stack 7
D_1 E_4 C_4 Z_109 C_1 
Stack 8
B_5 A_8 C_2 A_5 A_6 
Stack 9
Z_110 D_8 A_4 C_7 D_3 
Stack 10
C_5 B_2 B_4 A_7 
