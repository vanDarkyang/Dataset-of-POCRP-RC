Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
G_2 Z_100 I_0 E_6 E_12 B_5 
Stack 1
Z_101 G_5 H_7 Z_102 F_5 D_10 
Stack 2
Z_103 B_2 G_3 D_7 G_7 G_1 
Stack 3
G_9 Z_104 Z_105 H_2 A_4 D_3 
Stack 4
A_2 A_1 Z_106 B_0 G_0 Z_107 
Stack 5
C_1 Z_108 F_6 B_3 I_4 
Stack 6
J_7 G_10 B_6 J_1 B_4 
Stack 7
I_3 F_9 G_8 Z_109 H_6 
Stack 8
E_8 C_4 Z_110 H_3 H_9 
Stack 9
Z_111 H_1 D_8 Z_112 A_6 
Stack 10
F_3 E_13 F_0 E_11 J_2 
Stack 11
Z_113 I_1 C_2 H_5 D_5 
Stack 12
E_0 E_1 Z_114 H_8 A_3 
Stack 13
E_9 Z_115 Z_116 F_2 C_3 
Stack 14
Z_117 E_3 I_2 Z_118 G_6 
Stack 15
D_1 E_4 Z_119 D_6 I_6 
Stack 16
J_4 I_5 D_2 Z_120 D_4 
Stack 17
A_0 J_5 C_5 E_2 G_11 
Stack 18
F_11 D_0 F_4 F_7 B_1 
Stack 19
H_0 Z_121 C_6 G_4 E_10 
Stack 20
E_7 A_5 Z_122 D_9 E_5 
Stack 21
J_3 J_6 F_10 F_8 Z_123 
Stack 22
J_0 H_4 C_0 F_1 F_12 
