Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
F_1 G_4 B_1 Z_100 
Stack 1
E_6 Z_101 A_3 Z_102 
Stack 2
H_0 C_1 A_1 A_2 
Stack 3
Z_103 F_4 F_5 C_5 
Stack 4
E_2 Z_104 A_4 B_0 
Stack 5
Z_105 D_4 I_0 Z_106 
Stack 6
I_3 Z_107 H_3 C_0 
Stack 7
E_0 F_2 H_1 E_8 
Stack 8
J_2 C_2 B_2 Z_108 
Stack 9
D_0 D_5 A_0 E_5 
Stack 10
B_3 J_1 G_3 D_3 
Stack 11
H_4 Z_109 Z_110 E_3 
Stack 12
G_5 Z_111 D_1 E_1 
Stack 13
F_0 G_1 E_4 J_3 
Stack 14
D_2 Z_112 J_0 C_3 
Stack 15
Z_113 C_4 G_0 E_7 
Stack 16
G_2 I_2 H_2 
Stack 17
H_5 I_1 F_3 
