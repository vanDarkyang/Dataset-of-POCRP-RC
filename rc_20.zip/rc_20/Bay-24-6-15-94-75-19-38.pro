Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
N_0 I_3 Z_100 B_0 
Stack 1
Z_101 H_2 Z_102 K_3 
Stack 2
C_0 L_0 Z_103 C_3 
Stack 3
H_1 Z_104 I_4 J_5 
Stack 4
Z_105 H_5 F_1 Z_106 
Stack 5
D_3 J_0 Z_107 Z_108 
Stack 6
F_2 C_2 Z_109 E_1 
Stack 7
H_3 G_2 H_0 D_2 
Stack 8
E_0 L_1 K_0 N_2 
Stack 9
I_6 J_3 L_3 I_8 
Stack 10
A_0 M_2 Z_110 E_3 
Stack 11
F_0 J_2 I_2 E_4 
Stack 12
Z_111 L_5 I_0 O_0 
Stack 13
F_3 J_6 Z_112 G_0 
Stack 14
Z_113 G_1 L_4 F_5 
Stack 15
B_3 M_0 Z_114 B_1 
Stack 16
C_1 N_3 G_5 Z_115 
Stack 17
Z_116 B_2 K_4 D_1 
Stack 18
G_3 J_4 D_4 J_1 
Stack 19
F_4 N_1 D_0 K_2 
Stack 20
Z_117 I_5 I_7 Z_118 
Stack 21
H_6 M_1 O_1 E_5 
Stack 22
H_4 G_4 E_2 
Stack 23
I_1 L_2 K_1 
