Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_0 H_0 C_1 G_0 
Stack 1
H_1 Z_100 Z_101 Z_102 
Stack 2
F_0 D_1 F_2 F_1 
Stack 3
Z_103 D_3 Z_104 Z_105 
Stack 4
I_1 B_1 G_1 I_0 
Stack 5
F_3 Z_106 J_1 E_1 
Stack 6
A_2 E_2 H_2 E_3 
Stack 7
Z_107 G_2 D_4 C_4 
Stack 8
J_0 I_3 F_4 C_2 
Stack 9
H_3 A_0 Z_108 E_0 
Stack 10
D_0 I_2 A_1 B_3 
Stack 11
C_0 C_3 Z_109 
Stack 12
D_2 E_4 B_2 
