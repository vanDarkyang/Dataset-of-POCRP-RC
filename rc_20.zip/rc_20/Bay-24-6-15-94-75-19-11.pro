Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
N_1 G_0 Z_100 J_2 
Stack 1
C_3 J_3 J_0 K_3 
Stack 2
G_3 H_0 I_4 H_1 
Stack 3
F_0 N_0 K_4 L_2 
Stack 4
Z_101 E_0 Z_102 N_2 
Stack 5
D_3 A_1 M_1 A_0 
Stack 6
G_2 E_4 Z_103 Z_104 
Stack 7
D_0 H_4 Z_105 B_0 
Stack 8
Z_106 J_4 C_0 F_5 
Stack 9
L_0 I_7 H_2 C_1 
Stack 10
Z_107 Z_108 G_1 F_2 
Stack 11
I_0 I_8 K_0 Z_109 
Stack 12
G_5 B_2 E_2 G_4 
Stack 13
L_3 Z_110 D_1 E_6 
Stack 14
I_2 D_2 K_1 B_1 
Stack 15
I_5 N_3 K_2 Z_111 
Stack 16
M_3 J_1 D_5 D_4 
Stack 17
Z_112 H_3 I_3 Z_113 
Stack 18
E_1 A_2 E_5 Z_114 
Stack 19
M_0 F_3 L_4 F_4 
Stack 20
Z_115 Z_116 E_3 Z_117 
Stack 21
O_0 I_6 G_6 I_1 
Stack 22
L_1 Z_118 M_2 
Stack 23
C_2 C_4 F_1 
