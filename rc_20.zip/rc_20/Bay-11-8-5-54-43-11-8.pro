Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_1 C_4 B_0 A_7 E_3 
Stack 1
D_3 D_1 D_8 D_2 Z_100 
Stack 2
E_4 B_6 A_5 Z_101 Z_102 
Stack 3
C_8 D_5 D_4 A_3 B_3 
Stack 4
C_6 Z_103 Z_104 C_7 C_1 
Stack 5
Z_105 A_2 Z_106 Z_107 B_8 
Stack 6
C_5 E_6 D_6 E_5 B_4 
Stack 7
A_6 B_2 C_3 Z_108 A_4 
Stack 8
E_7 D_0 Z_109 C_2 A_0 
Stack 9
D_7 C_0 B_1 E_1 B_5 
Stack 10
E_2 Z_110 E_0 B_7 
