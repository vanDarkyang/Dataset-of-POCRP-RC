Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_8 D_1 B_7 Z_100 D_10 C_13 
Stack 1
C_14 A_8 E_1 C_4 B_5 B_10 
Stack 2
B_0 A_1 B_11 B_4 C_2 Z_101 
Stack 3
A_0 C_6 A_5 A_6 D_11 Z_102 
Stack 4
Z_103 Z_104 B_1 C_3 E_3 
Stack 5
B_8 C_1 D_5 Z_105 Z_106 
Stack 6
Z_107 Z_108 D_12 D_3 A_3 
Stack 7
B_12 A_4 E_4 C_11 E_6 
Stack 8
D_7 B_3 Z_109 D_6 Z_110 
Stack 9
B_9 C_12 E_8 C_7 E_9 
Stack 10
Z_111 C_5 D_9 Z_112 A_7 
Stack 11
A_9 D_14 Z_113 D_13 A_2 
Stack 12
Z_114 D_2 C_0 D_4 E_0 
Stack 13
Z_115 E_2 E_5 C_9 E_7 
Stack 14
B_2 D_0 D_8 B_6 C_10 
