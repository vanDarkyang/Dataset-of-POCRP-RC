Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
N_1 N_0 N_3 Z_100 
Stack 1
F_2 D_0 K_1 A_1 
Stack 2
Z_101 G_3 E_1 J_1 
Stack 3
E_4 I_2 Z_102 Z_103 
Stack 4
H_4 G_2 Z_104 Z_105 
Stack 5
B_1 C_0 O_1 H_7 
Stack 6
Z_106 E_2 J_0 K_0 
Stack 7
C_2 I_4 D_1 F_0 
Stack 8
I_0 M_2 K_2 M_0 
Stack 9
D_5 H_2 D_3 Z_107 
Stack 10
A_2 G_7 Z_108 B_2 
Stack 11
B_0 L_4 A_0 G_4 
Stack 12
C_1 G_1 J_2 Z_109 
Stack 13
M_1 H_5 Z_110 K_3 
Stack 14
I_1 D_2 E_5 K_4 
Stack 15
G_6 F_6 I_3 G_5 
Stack 16
F_1 H_0 Z_111 N_2 
Stack 17
H_6 D_4 H_3 O_0 
Stack 18
F_5 Z_112 K_5 K_6 
Stack 19
E_0 L_2 Z_113 O_2 
Stack 20
Z_114 Z_115 E_3 M_3 
Stack 21
G_0 F_3 Z_116 F_4 
Stack 22
L_1 L_3 H_1 
Stack 23
Z_117 Z_118 L_0 
