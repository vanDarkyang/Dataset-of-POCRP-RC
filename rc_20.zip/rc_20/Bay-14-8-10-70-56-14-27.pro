Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
J_2 D_2 C_5 D_1 Z_100 
Stack 1
E_4 F_1 D_0 I_4 Z_101 
Stack 2
Z_102 B_3 Z_103 Z_104 I_1 
Stack 3
G_5 D_3 F_0 J_1 Z_105 
Stack 4
Z_106 Z_107 D_4 D_6 G_4 
Stack 5
B_1 I_0 C_0 D_5 G_2 
Stack 6
H_3 Z_108 C_2 I_3 F_4 
Stack 7
Z_109 E_2 H_1 H_2 F_6 
Stack 8
A_0 B_2 E_6 H_5 E_1 
Stack 9
F_3 E_0 B_4 Z_110 Z_111 
Stack 10
F_2 H_0 J_3 C_1 B_0 
Stack 11
Z_112 G_3 A_1 E_7 E_3 
Stack 12
C_3 F_5 G_1 Z_113 E_5 
Stack 13
H_4 C_4 I_2 J_0 G_0 
