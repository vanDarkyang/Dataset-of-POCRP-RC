Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_10 E_5 C_2 F_7 G_2 Z_100 
Stack 1
F_5 C_9 H_7 Z_101 F_1 A_4 
Stack 2
Z_102 E_3 A_1 Z_103 I_6 E_6 
Stack 3
E_2 A_5 J_6 Z_104 Z_105 J_8 
Stack 4
H_5 F_8 C_6 J_7 D_2 E_9 
Stack 5
Z_106 G_8 I_5 Z_107 H_4 
Stack 6
E_1 A_2 C_3 I_8 G_4 
Stack 7
Z_108 D_8 I_9 I_3 E_4 
Stack 8
B_5 D_7 D_1 I_7 D_6 
Stack 9
F_2 I_4 E_10 Z_109 G_7 
Stack 10
C_1 H_3 A_6 J_4 Z_110 
Stack 11
Z_111 J_0 C_8 E_8 G_5 
Stack 12
H_0 F_9 I_1 J_3 E_0 
Stack 13
J_5 Z_112 G_1 C_0 J_2 
Stack 14
A_3 B_3 B_4 D_11 Z_113 
Stack 15
F_6 Z_114 I_2 F_4 G_10 
Stack 16
Z_115 G_6 D_4 F_3 Z_116 
Stack 17
B_0 H_1 J_1 H_8 Z_117 
Stack 18
Z_118 D_10 G_9 D_5 I_0 
Stack 19
D_0 E_7 D_3 A_0 H_2 
Stack 20
B_2 Z_119 Z_120 H_6 C_7 
Stack 21
C_4 Z_121 G_0 C_5 D_9 
Stack 22
F_0 B_1 Z_122 Z_123 G_3 
