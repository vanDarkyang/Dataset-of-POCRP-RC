Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
E_1 I_4 L_0 I_0 L_4 F_6 
Stack 1
E_2 G_0 F_4 G_2 O_2 G_5 
Stack 2
M_2 D_0 C_2 Z_100 I_1 Z_101 
Stack 3
M_3 Z_102 Z_103 K_5 Z_104 O_1 
Stack 4
J_4 Z_105 C_1 Z_106 D_1 
Stack 5
B_0 Z_107 H_4 K_0 K_1 
Stack 6
H_2 F_3 C_4 F_0 C_3 
Stack 7
L_2 L_3 Z_108 O_0 D_4 
Stack 8
C_0 J_2 I_2 K_3 K_2 
Stack 9
Z_109 N_1 Z_110 D_3 Z_111 
Stack 10
Z_112 Z_113 M_1 Z_114 E_3 
Stack 11
K_4 J_6 F_5 G_1 D_2 
Stack 12
E_4 F_2 F_1 D_5 H_3 
Stack 13
A_1 Z_115 I_5 E_0 J_3 
Stack 14
J_1 L_1 H_0 J_0 A_0 
Stack 15
E_5 G_3 Z_116 B_2 Z_117 
Stack 16
B_3 J_5 H_1 G_4 N_0 
Stack 17
Z_118 B_1 I_3 G_6 M_0 
