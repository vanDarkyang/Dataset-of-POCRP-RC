Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_1 Z_100 F_2 Z_101 Z_102 
Stack 1
B_0 B_3 E_6 F_3 I_5 
Stack 2
Z_103 C_2 A_0 Z_104 Z_105 
Stack 3
D_3 Z_106 J_0 I_3 A_2 
Stack 4
E_0 A_3 E_4 A_4 C_1 
Stack 5
F_1 D_2 F_4 J_1 I_4 
Stack 6
G_0 H_2 E_5 G_1 Z_107 
Stack 7
H_6 I_1 C_4 B_2 Z_108 
Stack 8
I_0 J_3 H_0 H_3 J_2 
Stack 9
E_1 B_1 Z_109 F_0 G_3 
Stack 10
E_3 C_0 Z_110 Z_111 D_4 
Stack 11
D_0 G_2 G_4 Z_112 B_4 
Stack 12
H_4 I_2 Z_113 G_5 H_5 
Stack 13
E_2 C_3 D_1 H_1 F_5 
