Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_4 B_1 C_3 Z_100 
Stack 1
Z_101 A_9 A_2 C_5 
Stack 2
C_0 A_4 B_11 B_2 
Stack 3
Z_102 Z_103 A_0 Z_104 
Stack 4
A_3 C_8 Z_105 B_5 
Stack 5
A_1 C_7 A_12 A_5 
Stack 6
C_1 C_4 C_9 A_7 
Stack 7
B_7 Z_106 B_6 A_13 
Stack 8
A_10 B_8 B_9 Z_107 
Stack 9
B_10 C_6 A_6 A_11 
Stack 10
Z_108 C_2 A_8 
Stack 11
B_3 Z_109 B_0 
