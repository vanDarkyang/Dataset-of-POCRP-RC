Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
A_1 J_3 C_1 F_7 M_1 G_2 
Stack 1
L_2 G_7 I_1 E_1 H_2 H_3 
Stack 2
Z_100 A_0 Z_101 Z_102 L_0 A_2 
Stack 3
G_5 F_1 C_2 Z_103 H_0 Z_104 
Stack 4
B_1 G_4 Z_105 F_5 E_4 
Stack 5
G_1 E_5 Z_106 Z_107 Z_108 
Stack 6
M_0 D_4 D_1 J_4 E_2 
Stack 7
D_3 Z_109 M_3 F_0 Z_110 
Stack 8
I_0 G_6 F_2 M_2 E_3 
Stack 9
D_0 D_2 F_3 H_4 J_1 
Stack 10
J_5 G_0 Z_111 F_6 I_5 
Stack 11
C_0 Z_112 Z_113 K_3 Z_114 
Stack 12
J_6 H_5 N_0 L_1 J_7 
Stack 13
L_3 B_0 N_3 J_2 N_1 
Stack 14
Z_115 I_6 Z_116 K_2 G_3 
Stack 15
H_6 J_0 K_0 O_0 I_4 
Stack 16
I_2 Z_117 I_3 H_1 E_0 
Stack 17
F_4 N_2 Z_118 K_1 C_3 
