Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
G_1 E_1 F_7 C_1 
Stack 1
B_0 Z_100 D_4 C_3 
Stack 2
B_3 E_0 F_0 F_3 
Stack 3
B_2 Z_101 Z_102 E_2 
Stack 4
Z_103 H_1 F_6 I_2 
Stack 5
D_2 E_7 D_1 I_5 
Stack 6
E_6 C_2 I_3 B_4 
Stack 7
H_0 F_4 H_3 Z_104 
Stack 8
F_2 E_8 Z_105 Z_106 
Stack 9
H_4 D_5 I_1 F_5 
Stack 10
A_1 D_0 J_0 A_2 
Stack 11
D_3 J_1 C_0 F_1 
Stack 12
Z_107 Z_108 A_0 Z_109 
Stack 13
H_5 C_4 I_0 H_2 
Stack 14
G_0 Z_110 Z_111 C_5 
Stack 15
F_8 Z_112 E_4 B_1 
Stack 16
Z_113 B_5 I_4 
Stack 17
E_3 J_2 E_5 
