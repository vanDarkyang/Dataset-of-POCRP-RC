Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 Z_101 I_3 N_3 E_0 O_0 
Stack 1
K_1 I_0 H_5 L_2 N_2 Z_102 
Stack 2
H_2 C_2 D_2 H_1 B_1 K_4 
Stack 3
D_0 I_5 Z_103 Z_104 Z_105 Z_106 
Stack 4
G_3 F_4 J_3 I_1 I_2 
Stack 5
Z_107 H_8 L_4 I_6 L_1 
Stack 6
E_1 M_0 K_3 Z_108 G_0 
Stack 7
D_1 H_7 B_2 J_2 G_5 
Stack 8
J_0 K_0 O_2 Z_109 G_2 
Stack 9
H_6 H_4 J_1 F_5 F_6 
Stack 10
H_9 L_3 B_0 C_1 N_0 
Stack 11
B_3 Z_110 A_0 I_4 Z_111 
Stack 12
H_0 M_2 K_2 Z_112 C_0 
Stack 13
F_3 Z_113 Z_114 D_3 G_7 
Stack 14
E_2 F_0 G_6 M_1 I_7 
Stack 15
Z_115 A_1 Z_116 H_3 G_8 
Stack 16
L_0 N_1 F_2 O_1 J_4 
Stack 17
Z_117 Z_118 G_1 F_1 G_4 
