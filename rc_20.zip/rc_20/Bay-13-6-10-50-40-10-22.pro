Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_0 F_2 D_5 E_5 
Stack 1
C_0 D_1 C_2 C_4 
Stack 2
E_2 E_0 E_3 B_1 
Stack 3
B_2 Z_100 Z_101 A_0 
Stack 4
D_3 Z_102 F_3 E_1 
Stack 5
C_1 I_1 H_0 H_3 
Stack 6
I_2 D_4 J_0 J_1 
Stack 7
E_4 F_4 Z_103 Z_104 
Stack 8
C_3 Z_105 H_1 Z_106 
Stack 9
G_1 Z_107 G_0 H_2 
Stack 10
F_0 J_2 Z_108 Z_109 
Stack 11
F_5 D_2 I_0 
Stack 12
F_1 G_2 D_0 
