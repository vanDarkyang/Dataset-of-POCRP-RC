Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_1 C_4 H_0 Z_100 F_0 
Stack 1
D_0 D_1 E_0 C_5 I_2 
Stack 2
A_1 Z_101 G_1 Z_102 D_7 
Stack 3
D_6 E_1 G_6 Z_103 I_4 
Stack 4
G_7 E_3 Z_104 E_5 H_1 
Stack 5
F_5 Z_105 A_2 Z_106 Z_107 
Stack 6
G_3 F_2 Z_108 Z_109 A_3 
Stack 7
F_7 G_0 I_3 D_3 I_1 
Stack 8
B_0 F_1 B_1 E_4 F_3 
Stack 9
F_4 B_3 C_0 Z_110 Z_111 
Stack 10
C_3 B_2 D_2 H_4 D_5 
Stack 11
G_5 D_4 I_0 H_3 Z_112 
Stack 12
Z_113 G_4 E_2 J_0 A_0 
Stack 13
H_2 F_6 C_2 J_1 G_2 
