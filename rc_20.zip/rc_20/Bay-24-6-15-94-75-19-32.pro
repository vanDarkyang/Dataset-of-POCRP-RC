Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
K_4 Z_100 G_3 N_1 
Stack 1
J_0 H_1 G_4 I_0 
Stack 2
J_6 F_4 F_0 M_1 
Stack 3
Z_101 J_1 J_2 E_2 
Stack 4
C_1 A_1 Z_102 N_0 
Stack 5
H_5 M_2 H_2 Z_103 
Stack 6
E_0 Z_104 G_6 Z_105 
Stack 7
I_5 O_0 L_1 H_7 
Stack 8
F_3 L_0 F_1 I_2 
Stack 9
F_6 K_3 A_0 C_0 
Stack 10
G_7 Z_106 C_3 Z_107 
Stack 11
C_2 O_1 K_0 A_2 
Stack 12
H_3 H_6 B_1 Z_108 
Stack 13
D_4 H_0 B_2 I_3 
Stack 14
G_1 I_6 E_4 F_5 
Stack 15
D_3 D_0 Z_109 G_5 
Stack 16
E_1 M_0 J_3 E_3 
Stack 17
Z_110 G_2 Z_111 I_1 
Stack 18
F_2 O_2 K_2 Z_112 
Stack 19
H_4 D_2 J_4 Z_113 
Stack 20
F_7 Z_114 D_1 Z_115 
Stack 21
K_1 N_2 G_0 B_0 
Stack 22
Z_116 Z_117 E_5 
Stack 23
I_4 J_5 Z_118 
