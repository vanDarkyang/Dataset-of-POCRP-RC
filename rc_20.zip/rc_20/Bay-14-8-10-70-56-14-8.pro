Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
H_3 A_2 H_4 H_0 A_1 
Stack 1
J_1 B_2 E_1 B_3 H_2 
Stack 2
B_1 C_0 D_0 C_2 C_3 
Stack 3
E_2 G_2 G_6 F_0 D_4 
Stack 4
G_4 Z_100 I_1 E_5 D_5 
Stack 5
Z_101 F_5 G_3 H_1 E_3 
Stack 6
F_2 Z_102 G_1 Z_103 I_2 
Stack 7
E_6 Z_104 I_4 Z_105 Z_106 
Stack 8
C_4 D_6 A_0 D_2 F_3 
Stack 9
H_5 F_1 I_3 Z_107 B_4 
Stack 10
C_1 H_6 G_5 D_1 J_0 
Stack 11
Z_108 B_0 J_2 Z_109 D_3 
Stack 12
Z_110 Z_111 E_4 J_3 Z_112 
Stack 13
I_0 G_0 F_4 E_0 Z_113 
