Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_0 D_5 A_3 Z_100 B_12 D_6 
Stack 1
Z_101 A_10 A_8 A_7 Z_102 C_12 
Stack 2
B_11 C_14 B_8 Z_103 C_11 E_5 
Stack 3
B_7 E_9 E_1 Z_104 C_8 D_8 
Stack 4
C_13 E_7 C_10 D_0 C_1 
Stack 5
E_11 B_9 E_8 E_2 Z_105 
Stack 6
D_4 B_13 C_2 E_4 E_6 
Stack 7
D_9 C_7 A_1 B_5 B_2 
Stack 8
A_2 E_0 B_1 Z_106 Z_107 
Stack 9
C_15 C_9 Z_108 A_6 D_3 
Stack 10
Z_109 D_2 C_3 B_0 A_9 
Stack 11
Z_110 E_10 Z_111 Z_112 A_4 
Stack 12
A_0 B_6 D_7 D_1 B_3 
Stack 13
C_5 B_4 E_3 C_6 Z_113 
Stack 14
A_5 B_10 C_4 Z_114 Z_115 
