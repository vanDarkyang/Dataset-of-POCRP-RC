Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
J_3 O_0 B_0 D_0 
Stack 1
H_3 Z_100 C_3 I_4 
Stack 2
Z_101 I_6 E_1 K_0 
Stack 3
Z_102 K_4 J_5 F_1 
Stack 4
Z_103 L_1 E_2 Z_104 
Stack 5
I_3 Z_105 D_3 M_3 
Stack 6
B_3 H_4 N_3 G_6 
Stack 7
E_0 K_3 Z_106 H_2 
Stack 8
Z_107 Z_108 K_2 C_0 
Stack 9
Z_109 G_4 L_4 F_4 
Stack 10
G_1 Z_110 Z_111 Z_112 
Stack 11
Z_113 A_1 I_5 F_0 
Stack 12
F_5 L_2 I_1 Z_114 
Stack 13
A_2 L_3 L_0 J_0 
Stack 14
G_0 O_2 J_1 E_3 
Stack 15
J_4 J_2 B_2 D_1 
Stack 16
A_0 B_1 M_2 M_1 
Stack 17
C_2 H_1 Z_115 M_0 
Stack 18
G_3 I_2 Z_116 G_5 
Stack 19
K_5 C_1 D_2 M_4 
Stack 20
G_2 O_1 F_3 F_2 
Stack 21
F_6 N_0 Z_117 N_1 
Stack 22
H_0 K_1 I_0 
Stack 23
K_6 Z_118 N_2 
