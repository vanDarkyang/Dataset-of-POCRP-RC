Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 H_4 Z_101 E_3 I_0 
Stack 1
H_2 G_0 D_6 D_2 Z_102 
Stack 2
D_3 E_2 Z_103 H_3 C_1 
Stack 3
Z_104 D_0 A_4 A_1 F_3 
Stack 4
Z_105 I_2 F_2 Z_106 F_0 
Stack 5
F_1 J_3 E_0 G_3 F_4 
Stack 6
Z_107 Z_108 E_1 E_5 A_2 
Stack 7
C_2 B_0 D_1 Z_109 H_0 
Stack 8
I_3 J_0 D_4 Z_110 F_5 
Stack 9
A_3 G_5 G_2 G_1 A_0 
Stack 10
E_8 Z_111 G_4 J_2 E_7 
Stack 11
C_3 E_6 G_6 C_0 H_1 
Stack 12
Z_112 J_1 I_1 Z_113 H_5 
Stack 13
B_2 D_5 B_1 E_4 B_3 
