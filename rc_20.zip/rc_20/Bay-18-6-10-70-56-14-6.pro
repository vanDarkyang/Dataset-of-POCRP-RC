Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
G_6 G_1 H_3 D_1 
Stack 1
A_2 A_1 Z_100 C_4 
Stack 2
D_2 A_3 Z_101 J_0 
Stack 3
Z_102 Z_103 G_5 Z_104 
Stack 4
H_2 Z_105 J_3 E_2 
Stack 5
F_3 Z_106 J_1 J_2 
Stack 6
C_0 G_0 A_4 D_3 
Stack 7
G_3 C_2 H_4 Z_107 
Stack 8
A_0 F_5 Z_108 E_8 
Stack 9
B_4 I_3 E_1 I_0 
Stack 10
B_1 D_0 B_3 D_4 
Stack 11
Z_109 C_3 I_2 E_3 
Stack 12
E_0 E_4 Z_110 Z_111 
Stack 13
Z_112 B_0 H_1 D_5 
Stack 14
I_1 G_4 Z_113 G_2 
Stack 15
E_6 F_4 E_5 H_0 
Stack 16
F_1 C_1 F_0 
Stack 17
B_2 E_7 F_2 
