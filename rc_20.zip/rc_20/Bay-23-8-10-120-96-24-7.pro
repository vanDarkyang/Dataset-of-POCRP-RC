Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
E_0 F_0 A_7 F_11 A_4 G_0 
Stack 1
Z_100 J_5 B_3 B_0 F_7 A_6 
Stack 2
Z_101 Z_102 H_3 B_4 C_0 Z_103 
Stack 3
Z_104 Z_105 F_3 G_3 Z_106 G_4 
Stack 4
J_2 Z_107 D_6 I_5 D_2 A_2 
Stack 5
D_8 D_11 C_6 D_7 A_5 
Stack 6
D_10 Z_108 B_7 Z_109 A_0 
Stack 7
C_5 Z_110 A_8 D_3 H_6 
Stack 8
E_7 Z_111 Z_112 E_8 D_9 
Stack 9
H_4 F_9 Z_113 C_3 I_6 
Stack 10
F_5 H_2 F_1 H_0 Z_114 
Stack 11
F_8 J_7 Z_115 I_3 G_5 
Stack 12
I_7 Z_116 I_1 D_4 G_7 
Stack 13
J_3 D_1 A_1 C_7 Z_117 
Stack 14
E_2 E_11 D_0 B_2 G_1 
Stack 15
Z_118 E_3 F_6 J_4 Z_119 
Stack 16
E_4 F_10 E_1 C_2 J_6 
Stack 17
B_5 F_4 Z_120 J_0 E_5 
Stack 18
Z_121 H_1 J_8 I_4 A_3 
Stack 19
H_7 I_0 Z_122 F_2 C_8 
Stack 20
I_2 B_1 J_1 E_6 E_10 
Stack 21
H_8 G_2 G_6 D_5 C_1 
Stack 22
H_5 C_4 B_6 E_9 Z_123 
