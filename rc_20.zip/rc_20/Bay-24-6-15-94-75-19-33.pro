Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
L_3 F_4 L_4 H_5 
Stack 1
Z_100 J_5 Z_101 H_0 
Stack 2
A_0 D_3 I_0 M_0 
Stack 3
E_5 G_4 I_3 D_4 
Stack 4
F_5 I_2 D_2 J_7 
Stack 5
A_1 J_2 Z_102 Z_103 
Stack 6
F_6 E_4 G_1 J_1 
Stack 7
Z_104 J_6 E_1 N_1 
Stack 8
N_0 N_3 Z_105 J_4 
Stack 9
F_3 Z_106 Z_107 E_0 
Stack 10
Z_108 F_7 M_2 G_2 
Stack 11
N_2 O_0 C_0 J_0 
Stack 12
I_6 L_2 Z_109 G_3 
Stack 13
C_2 M_1 F_0 H_3 
Stack 14
Z_110 H_1 C_3 F_1 
Stack 15
K_1 O_1 L_1 B_1 
Stack 16
L_0 I_1 Z_111 Z_112 
Stack 17
E_2 K_5 E_3 D_1 
Stack 18
Z_113 Z_114 Z_115 G_0 
Stack 19
A_2 F_2 Z_116 M_3 
Stack 20
I_5 C_1 K_0 H_2 
Stack 21
K_4 K_3 K_2 H_4 
Stack 22
Z_117 J_3 Z_118 
Stack 23
I_4 B_0 D_0 
