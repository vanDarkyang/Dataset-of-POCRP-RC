Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
H_1 G_7 B_3 M_4 G_6 K_1 
Stack 1
G_3 Z_100 F_0 B_4 D_2 I_9 
Stack 2
H_4 H_6 Z_101 E_2 H_7 I_8 
Stack 3
F_1 H_0 Z_102 I_6 J_2 D_4 
Stack 4
N_0 K_0 M_0 F_5 F_2 
Stack 5
G_2 K_8 D_5 M_3 J_1 
Stack 6
Z_103 B_2 A_2 O_1 N_1 
Stack 7
Z_104 M_1 I_1 I_4 Z_105 
Stack 8
I_0 Z_106 C_6 K_3 L_3 
Stack 9
G_1 Z_107 E_4 H_5 I_7 
Stack 10
C_3 Z_108 J_5 E_5 D_0 
Stack 11
F_6 E_0 A_3 B_0 K_6 
Stack 12
O_0 F_3 H_3 F_4 K_5 
Stack 13
K_2 J_0 N_2 L_2 N_3 
Stack 14
O_3 Z_109 Z_110 O_2 J_4 
Stack 15
E_3 Z_111 Z_112 B_1 D_3 
Stack 16
Z_113 M_2 Z_114 Z_115 J_3 
Stack 17
J_6 A_0 C_0 Z_116 C_1 
Stack 18
Z_117 C_4 L_4 I_3 D_1 
Stack 19
Z_118 E_1 G_0 K_4 Z_119 
Stack 20
G_8 Z_120 Z_121 I_2 G_5 
Stack 21
K_7 I_5 A_1 M_5 Z_122 
Stack 22
Z_123 H_2 G_4 C_5 L_5 
Stack 23
L_1 B_5 Z_124 C_2 L_0 
