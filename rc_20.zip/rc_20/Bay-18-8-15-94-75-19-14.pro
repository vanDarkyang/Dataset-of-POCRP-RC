Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 G_3 M_2 Z_101 Z_102 F_7 
Stack 1
Z_103 M_1 I_2 K_4 I_5 Z_104 
Stack 2
J_2 G_2 N_3 Z_105 L_1 M_3 
Stack 3
Z_106 L_0 J_1 F_4 H_4 A_0 
Stack 4
K_5 G_0 C_2 Z_107 D_5 
Stack 5
Z_108 E_1 C_0 H_7 K_3 
Stack 6
G_6 F_0 K_2 J_5 D_0 
Stack 7
J_4 Z_109 I_0 C_1 E_0 
Stack 8
D_1 L_2 Z_110 I_3 Z_111 
Stack 9
J_0 H_1 J_3 D_3 F_2 
Stack 10
K_6 I_1 K_1 O_1 N_2 
Stack 11
O_0 K_0 F_6 Z_112 F_3 
Stack 12
H_8 M_0 F_5 H_6 H_5 
Stack 13
H_0 E_3 D_2 Z_113 H_3 
Stack 14
B_0 I_4 Z_114 L_3 E_2 
Stack 15
Z_115 Z_116 F_1 G_5 Z_117 
Stack 16
H_2 Z_118 N_1 N_0 B_1 
Stack 17
G_4 D_4 L_4 G_1 A_1 
