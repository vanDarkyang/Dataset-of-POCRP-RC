Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
G_0 E_3 B_0 A_4 G_6 B_2 
Stack 1
H_9 F_3 A_5 G_9 Z_100 I_8 
Stack 2
J_3 I_1 I_7 J_4 B_5 C_2 
Stack 3
Z_101 E_9 Z_102 B_6 Z_103 Z_104 
Stack 4
C_0 Z_105 Z_106 I_0 C_4 H_8 
Stack 5
Z_107 H_0 G_8 H_4 Z_108 
Stack 6
C_6 F_2 D_10 E_7 D_2 
Stack 7
H_3 Z_109 D_6 J_2 C_3 
Stack 8
Z_110 A_0 I_10 F_4 E_5 
Stack 9
G_3 C_8 A_6 I_3 G_4 
Stack 10
Z_111 Z_112 B_1 D_7 E_0 
Stack 11
A_1 H_7 D_8 J_6 I_4 
Stack 12
H_1 E_6 Z_113 I_2 G_2 
Stack 13
A_2 Z_114 Z_115 D_9 D_0 
Stack 14
Z_116 D_4 Z_117 E_2 H_6 
Stack 15
C_7 E_1 D_5 Z_118 J_0 
Stack 16
C_1 Z_119 F_6 I_6 F_1 
Stack 17
F_0 I_5 G_5 G_10 A_8 
Stack 18
Z_120 G_1 B_4 D_1 F_7 
Stack 19
E_8 E_4 G_7 J_1 H_5 
Stack 20
G_11 A_7 F_5 Z_121 D_3 
Stack 21
I_9 B_3 Z_122 J_5 Z_123 
Stack 22
A_3 H_2 C_5 C_9 E_10 
