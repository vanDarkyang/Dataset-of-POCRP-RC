Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
E_2 Z_100 H_5 F_3 Z_101 I_5 
Stack 1
B_4 H_10 C_0 C_5 H_2 I_2 
Stack 2
Z_102 Z_103 Z_104 Z_105 D_9 A_4 
Stack 3
G_3 I_6 Z_106 H_7 C_7 D_8 
Stack 4
I_7 H_3 G_7 Z_107 Z_108 E_4 
Stack 5
G_1 F_0 C_1 I_1 C_6 
Stack 6
G_4 D_5 H_9 Z_109 I_4 
Stack 7
Z_110 B_0 A_2 Z_111 D_3 
Stack 8
D_4 E_6 F_10 G_0 Z_112 
Stack 9
D_6 J_1 H_1 G_8 Z_113 
Stack 10
H_6 D_1 E_3 J_6 G_2 
Stack 11
B_1 B_2 C_9 G_6 Z_114 
Stack 12
Z_115 F_1 I_0 D_0 B_5 
Stack 13
Z_116 E_7 B_6 E_8 D_2 
Stack 14
B_3 J_4 D_10 I_8 D_7 
Stack 15
Z_117 Z_118 I_3 A_6 J_5 
Stack 16
E_5 F_11 Z_119 G_5 G_9 
Stack 17
C_3 E_0 F_8 A_0 Z_120 
Stack 18
F_7 A_3 G_11 F_9 J_2 
Stack 19
A_1 E_1 H_4 C_4 F_4 
Stack 20
Z_121 Z_122 G_10 F_2 J_7 
Stack 21
A_5 H_0 F_6 F_5 J_3 
Stack 22
J_0 C_8 C_2 H_8 Z_123 
