Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 D_0 H_2 Z_101 
Stack 1
Z_102 Z_103 B_1 F_2 
Stack 2
E_2 D_3 E_5 D_1 
Stack 3
G_3 C_1 Z_104 G_0 
Stack 4
B_2 I_3 I_1 Z_105 
Stack 5
F_3 E_6 A_2 F_0 
Stack 6
J_1 A_1 C_0 E_4 
Stack 7
G_1 Z_106 F_1 E_0 
Stack 8
I_2 D_2 J_0 G_2 
Stack 9
C_4 Z_107 H_1 Z_108 
Stack 10
I_0 H_0 E_1 B_0 
Stack 11
A_0 C_2 E_3 
Stack 12
F_4 C_3 Z_109 
