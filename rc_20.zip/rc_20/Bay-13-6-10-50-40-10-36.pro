Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_1 Z_100 E_4 D_2 
Stack 1
C_3 E_2 E_3 F_0 
Stack 2
B_0 Z_101 B_2 A_2 
Stack 3
B_3 I_1 H_1 F_3 
Stack 4
I_0 D_0 G_0 Z_102 
Stack 5
A_0 Z_103 A_1 E_0 
Stack 6
I_2 Z_104 C_2 Z_105 
Stack 7
Z_106 F_1 C_4 H_2 
Stack 8
C_1 G_3 F_4 H_0 
Stack 9
Z_107 G_1 B_1 F_5 
Stack 10
Z_108 F_2 I_3 J_0 
Stack 11
H_3 G_2 C_0 
Stack 12
G_4 Z_109 D_1 
