Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_3 C_3 C_7 D_8 D_7 
Stack 1
B_2 B_6 C_1 E_5 Z_100 
Stack 2
A_4 E_3 Z_101 B_4 Z_102 
Stack 3
E_4 A_9 C_4 D_3 D_5 
Stack 4
D_0 Z_103 Z_104 C_0 E_6 
Stack 5
Z_105 C_2 Z_106 D_9 D_6 
Stack 6
D_1 D_2 B_3 B_0 A_2 
Stack 7
A_0 Z_107 C_6 E_0 A_6 
Stack 8
C_8 A_5 A_8 A_1 Z_108 
Stack 9
Z_109 Z_110 E_2 B_1 D_4 
Stack 10
B_5 E_1 A_7 C_5 
