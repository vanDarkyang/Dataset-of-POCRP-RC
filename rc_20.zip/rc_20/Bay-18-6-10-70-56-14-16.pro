Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
J_3 E_2 E_4 E_1 
Stack 1
H_5 J_1 J_2 H_2 
Stack 2
G_3 Z_100 B_4 C_0 
Stack 3
Z_101 Z_102 G_5 F_6 
Stack 4
C_3 H_1 H_3 Z_103 
Stack 5
C_2 H_0 Z_104 I_3 
Stack 6
A_3 Z_105 A_0 Z_106 
Stack 7
B_5 Z_107 I_2 Z_108 
Stack 8
E_5 G_1 D_2 D_3 
Stack 9
Z_109 A_2 D_5 A_1 
Stack 10
G_2 Z_110 C_1 I_1 
Stack 11
F_5 E_3 G_0 F_3 
Stack 12
B_1 E_0 F_2 C_4 
Stack 13
C_5 E_6 F_4 H_4 
Stack 14
G_4 J_0 D_4 D_0 
Stack 15
F_1 F_0 B_2 Z_111 
Stack 16
Z_112 Z_113 B_0 
Stack 17
D_1 I_0 B_3 
