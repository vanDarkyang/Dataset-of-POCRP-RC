Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_2 F_5 Z_100 A_3 J_3 
Stack 1
D_1 E_0 H_5 G_5 Z_101 
Stack 2
Z_102 D_5 C_0 A_0 Z_103 
Stack 3
Z_104 D_4 Z_105 G_0 E_3 
Stack 4
J_0 Z_106 G_1 H_0 G_2 
Stack 5
I_0 E_5 E_2 C_4 Z_107 
Stack 6
F_0 J_1 I_4 D_0 B_3 
Stack 7
F_4 B_2 J_4 J_2 H_1 
Stack 8
F_7 Z_108 H_3 H_2 Z_109 
Stack 9
B_1 G_4 Z_110 H_4 G_3 
Stack 10
F_3 F_2 Z_111 F_1 C_1 
Stack 11
A_1 I_2 Z_112 A_2 I_1 
Stack 12
I_3 D_6 B_0 F_6 E_1 
Stack 13
C_3 Z_113 E_4 D_2 D_3 
