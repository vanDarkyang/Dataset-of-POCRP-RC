Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 B_0 A_5 Z_101 
Stack 1
A_8 C_6 A_11 C_3 
Stack 2
C_4 A_2 A_1 A_9 
Stack 3
Z_102 B_2 B_6 C_9 
Stack 4
Z_103 C_0 C_8 B_7 
Stack 5
C_1 A_0 A_12 C_5 
Stack 6
Z_104 Z_105 A_7 Z_106 
Stack 7
Z_107 B_3 C_2 B_8 
Stack 8
B_4 B_9 C_10 B_5 
Stack 9
C_11 Z_108 A_3 C_7 
Stack 10
A_10 B_1 A_6 
Stack 11
A_4 Z_109 C_12 
