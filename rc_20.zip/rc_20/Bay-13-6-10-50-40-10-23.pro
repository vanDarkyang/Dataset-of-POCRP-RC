Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_4 G_3 D_2 B_0 
Stack 1
F_3 E_1 I_3 I_1 
Stack 2
J_1 G_1 G_0 C_0 
Stack 3
I_0 Z_100 Z_101 D_4 
Stack 4
C_1 G_2 F_1 H_2 
Stack 5
F_0 E_3 J_2 J_0 
Stack 6
A_0 Z_102 E_2 I_2 
Stack 7
Z_103 Z_104 E_5 D_0 
Stack 8
Z_105 F_2 F_5 C_2 
Stack 9
Z_106 H_0 G_4 Z_107 
Stack 10
Z_108 F_6 Z_109 H_3 
Stack 11
H_1 D_3 E_0 
Stack 12
D_1 B_1 E_4 
