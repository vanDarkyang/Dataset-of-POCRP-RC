Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_4 A_9 Z_100 C_4 E_2 A_6 
Stack 1
C_7 D_7 Z_101 Z_102 E_5 D_9 
Stack 2
B_4 Z_103 D_8 E_4 D_1 C_5 
Stack 3
C_1 B_2 C_9 C_10 B_8 Z_104 
Stack 4
A_10 D_6 B_9 A_0 E_3 
Stack 5
B_11 C_8 E_12 Z_105 Z_106 
Stack 6
A_1 C_13 Z_107 A_3 B_5 
Stack 7
B_3 E_10 D_10 Z_108 C_11 
Stack 8
B_7 B_10 D_5 B_1 E_7 
Stack 9
E_9 D_3 A_5 B_6 E_6 
Stack 10
B_0 Z_109 E_0 C_6 E_11 
Stack 11
Z_110 E_8 D_4 Z_111 Z_112 
Stack 12
D_0 C_2 Z_113 C_0 E_1 
Stack 13
D_2 C_12 Z_114 Z_115 A_2 
Stack 14
C_3 A_7 D_11 B_12 A_8 
