Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 D_12 E_9 D_1 
Stack 1
B_5 A_5 Z_101 E_0 
Stack 2
C_10 B_12 D_6 E_8 
Stack 3
B_8 A_4 C_9 C_3 
Stack 4
C_4 B_10 D_5 A_12 
Stack 5
C_5 C_7 B_2 D_9 
Stack 6
Z_102 E_6 Z_103 B_4 
Stack 7
C_8 B_6 Z_104 D_0 
Stack 8
E_10 D_3 Z_105 Z_106 
Stack 9
B_0 B_7 D_4 Z_107 
Stack 10
E_5 A_8 Z_108 Z_109 
Stack 11
Z_110 A_1 E_7 A_7 
Stack 12
A_11 E_4 B_9 A_2 
Stack 13
B_3 A_3 C_6 D_8 
Stack 14
Z_111 A_6 E_1 D_11 
Stack 15
Z_112 E_2 Z_113 C_1 
Stack 16
B_13 D_7 C_0 A_0 
Stack 17
C_2 A_10 D_2 Z_114 
Stack 18
A_9 B_1 Z_115 E_3 
Stack 19
D_10 B_11 D_13 
