Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
M_1 Z_100 E_5 C_0 A_0 G_4 
Stack 1
K_2 Z_101 O_0 E_4 E_8 H_0 
Stack 2
D_1 E_0 G_3 E_7 C_5 I_0 
Stack 3
L_0 J_2 A_4 H_2 Z_102 F_3 
Stack 4
I_3 G_2 Z_103 N_0 Z_104 
Stack 5
Z_105 G_6 I_1 D_5 D_0 
Stack 6
H_6 K_5 M_2 I_7 L_1 
Stack 7
L_4 H_10 Z_106 F_6 Z_107 
Stack 8
G_5 H_9 J_6 Z_108 J_3 
Stack 9
C_2 M_3 L_3 L_6 H_3 
Stack 10
H_8 Z_109 H_5 O_3 E_3 
Stack 11
Z_110 F_4 Z_111 L_2 G_7 
Stack 12
H_4 Z_112 A_1 J_5 B_0 
Stack 13
I_5 Z_113 H_1 I_6 N_2 
Stack 14
Z_114 K_0 D_2 J_0 F_1 
Stack 15
I_4 H_7 B_1 Z_115 E_1 
Stack 16
Z_116 C_3 K_4 K_3 L_5 
Stack 17
N_5 Z_117 Z_118 K_1 M_0 
Stack 18
Z_119 D_4 G_1 F_2 C_1 
Stack 19
D_3 N_4 Z_120 F_0 C_4 
Stack 20
J_4 N_3 J_7 G_0 J_1 
Stack 21
Z_121 E_2 N_1 Z_122 A_2 
Stack 22
L_7 Z_123 I_2 K_6 E_6 
Stack 23
F_5 O_2 A_3 Z_124 O_1 
