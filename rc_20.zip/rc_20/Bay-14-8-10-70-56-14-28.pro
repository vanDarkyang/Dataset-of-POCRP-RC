Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
J_1 F_2 F_4 G_6 Z_100 
Stack 1
Z_101 G_2 B_1 C_2 B_3 
Stack 2
D_4 E_4 A_1 E_1 G_3 
Stack 3
Z_102 Z_103 G_0 G_1 Z_104 
Stack 4
A_0 F_6 F_1 H_4 C_1 
Stack 5
F_3 F_7 D_3 Z_105 D_6 
Stack 6
C_0 E_5 G_5 H_3 E_0 
Stack 7
Z_106 C_3 B_0 Z_107 J_3 
Stack 8
D_0 Z_108 D_2 D_5 H_0 
Stack 9
G_4 J_0 B_2 Z_109 F_0 
Stack 10
F_5 E_7 Z_110 H_1 Z_111 
Stack 11
E_3 C_4 E_6 D_1 I_2 
Stack 12
Z_112 I_1 H_6 J_4 Z_113 
Stack 13
J_2 E_2 I_0 H_2 H_5 
