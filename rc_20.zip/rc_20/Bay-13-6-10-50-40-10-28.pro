Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
I_3 G_4 B_0 D_3 
Stack 1
Z_100 I_0 J_1 E_0 
Stack 2
E_4 C_0 C_2 G_3 
Stack 3
B_1 A_1 C_1 Z_101 
Stack 4
F_0 H_2 H_3 D_2 
Stack 5
E_1 D_0 F_2 J_0 
Stack 6
F_3 B_3 H_1 D_4 
Stack 7
F_1 Z_102 G_0 G_1 
Stack 8
Z_103 H_4 H_0 Z_104 
Stack 9
A_0 Z_105 Z_106 D_1 
Stack 10
E_3 G_2 B_2 Z_107 
Stack 11
I_1 Z_108 I_2 
Stack 12
E_2 A_2 Z_109 
