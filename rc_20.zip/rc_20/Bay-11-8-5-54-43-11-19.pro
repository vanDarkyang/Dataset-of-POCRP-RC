Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 A_8 Z_101 A_6 A_5 
Stack 1
A_0 Z_102 E_7 B_6 C_2 
Stack 2
C_7 C_0 E_1 Z_103 Z_104 
Stack 3
C_5 E_0 E_4 B_0 B_1 
Stack 4
Z_105 B_7 D_1 E_3 Z_106 
Stack 5
A_7 Z_107 E_2 C_8 E_5 
Stack 6
B_5 D_8 Z_108 A_2 C_3 
Stack 7
A_1 Z_109 E_6 C_1 D_2 
Stack 8
D_7 B_2 Z_110 B_3 C_4 
Stack 9
C_6 A_4 D_0 B_4 D_4 
Stack 10
A_3 D_5 D_3 D_6 
