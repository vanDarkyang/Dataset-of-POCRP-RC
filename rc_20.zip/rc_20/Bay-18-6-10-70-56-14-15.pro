Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 D_3 I_1 F_4 
Stack 1
D_4 E_1 Z_101 A_0 
Stack 2
F_7 F_3 F_5 Z_102 
Stack 3
J_1 H_3 B_0 E_6 
Stack 4
F_0 D_6 Z_103 G_2 
Stack 5
F_6 J_2 G_0 C_0 
Stack 6
Z_104 H_2 I_2 C_2 
Stack 7
F_8 D_0 Z_105 E_7 
Stack 8
B_3 Z_106 B_1 E_2 
Stack 9
E_4 F_1 I_3 C_3 
Stack 10
E_3 J_0 G_4 J_3 
Stack 11
G_1 G_3 D_2 I_4 
Stack 12
A_2 Z_107 A_1 Z_108 
Stack 13
I_0 E_0 D_5 E_5 
Stack 14
Z_109 H_0 G_5 Z_110 
Stack 15
Z_111 B_2 H_5 D_1 
Stack 16
C_1 Z_112 F_2 
Stack 17
H_1 H_4 Z_113 
