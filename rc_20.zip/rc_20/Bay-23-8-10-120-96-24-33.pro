Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_3 C_6 J_2 H_7 E_8 D_7 
Stack 1
G_6 E_4 Z_100 H_5 D_8 E_3 
Stack 2
E_5 B_4 Z_101 C_0 I_0 J_6 
Stack 3
A_8 D_6 J_7 Z_102 H_6 Z_103 
Stack 4
I_6 I_5 Z_104 A_0 H_0 H_2 
Stack 5
J_0 G_0 A_7 Z_105 F_2 
Stack 6
J_1 E_2 E_9 E_6 D_3 
Stack 7
I_8 Z_106 D_9 C_7 E_1 
Stack 8
Z_107 D_1 G_1 G_7 Z_108 
Stack 9
Z_109 B_3 D_2 A_3 B_2 
Stack 10
J_3 Z_110 H_1 I_1 Z_111 
Stack 11
D_10 D_11 F_7 D_12 A_2 
Stack 12
A_6 C_1 I_3 E_7 I_4 
Stack 13
B_5 Z_112 G_4 D_4 E_10 
Stack 14
F_1 B_6 E_0 C_8 G_5 
Stack 15
Z_113 F_6 C_5 Z_114 I_2 
Stack 16
F_3 G_8 Z_115 F_0 D_5 
Stack 17
I_7 B_1 J_4 G_10 C_2 
Stack 18
C_4 Z_116 Z_117 Z_118 H_3 
Stack 19
D_0 Z_119 H_4 A_4 A_5 
Stack 20
Z_120 G_9 J_5 E_11 F_5 
Stack 21
Z_121 Z_122 F_8 A_1 G_3 
Stack 22
G_2 F_4 B_7 B_0 Z_123 
