Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
D_1 E_1 H_1 Z_100 
Stack 1
D_0 G_1 Z_101 D_3 
Stack 2
Z_102 A_1 F_2 C_0 
Stack 3
I_1 E_5 J_0 F_1 
Stack 4
F_6 C_2 I_2 Z_103 
Stack 5
Z_104 E_2 Z_105 E_3 
Stack 6
C_1 Z_106 I_0 I_3 
Stack 7
E_4 Z_107 H_0 F_4 
Stack 8
Z_108 B_0 E_6 Z_109 
Stack 9
C_3 F_0 H_2 F_3 
Stack 10
B_1 A_0 F_5 G_0 
Stack 11
B_3 J_1 D_2 
Stack 12
E_0 H_3 B_2 
