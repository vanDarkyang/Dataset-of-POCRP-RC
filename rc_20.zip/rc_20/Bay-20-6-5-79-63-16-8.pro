Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_10 Z_100 Z_101 B_7 
Stack 1
Z_102 D_6 B_9 C_5 
Stack 2
A_3 Z_103 Z_104 Z_105 
Stack 3
D_7 D_2 Z_106 A_6 
Stack 4
A_8 D_11 B_5 D_10 
Stack 5
Z_107 D_8 Z_108 D_5 
Stack 6
Z_109 E_6 E_9 C_2 
Stack 7
B_8 D_4 E_7 E_2 
Stack 8
D_0 B_2 Z_110 C_7 
Stack 9
B_4 Z_111 A_9 D_1 
Stack 10
B_10 E_0 D_3 Z_112 
Stack 11
E_1 E_4 A_4 A_1 
Stack 12
A_7 C_6 Z_113 B_3 
Stack 13
D_13 C_4 A_5 E_10 
Stack 14
B_11 B_6 D_9 A_2 
Stack 15
C_1 A_0 E_5 B_0 
Stack 16
C_8 B_1 C_12 D_12 
Stack 17
B_12 C_9 Z_114 E_8 
Stack 18
C_3 C_0 E_11 C_13 
Stack 19
Z_115 C_11 E_3 
