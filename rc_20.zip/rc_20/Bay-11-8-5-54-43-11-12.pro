Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
D_5 A_3 C_9 E_5 E_4 
Stack 1
B_3 D_1 A_8 B_9 E_3 
Stack 2
Z_100 B_0 C_6 Z_101 B_7 
Stack 3
A_6 Z_102 A_5 Z_103 E_1 
Stack 4
D_6 B_4 B_8 Z_104 B_2 
Stack 5
D_0 A_2 A_0 A_1 D_3 
Stack 6
C_7 C_5 A_7 Z_105 D_2 
Stack 7
C_2 B_1 C_8 C_4 B_6 
Stack 8
C_3 Z_106 E_0 C_0 B_5 
Stack 9
Z_107 C_1 A_4 E_2 Z_108 
Stack 10
Z_109 Z_110 D_4 C_10 
