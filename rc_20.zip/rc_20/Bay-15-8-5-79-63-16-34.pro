Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 A_1 C_1 E_2 E_6 B_7 
Stack 1
E_8 Z_101 C_3 B_9 D_10 E_3 
Stack 2
A_7 Z_102 Z_103 A_9 C_10 B_2 
Stack 3
A_5 A_8 D_6 C_0 B_3 E_5 
Stack 4
D_4 B_1 D_13 B_6 B_12 
Stack 5
A_4 C_8 B_0 E_7 Z_104 
Stack 6
C_4 C_2 D_12 B_4 B_11 
Stack 7
Z_105 D_11 E_4 E_12 Z_106 
Stack 8
Z_107 E_10 B_8 B_10 Z_108 
Stack 9
A_10 Z_109 E_11 D_9 C_6 
Stack 10
D_2 A_2 E_9 C_9 A_6 
Stack 11
D_7 D_5 Z_110 C_5 C_11 
Stack 12
Z_111 Z_112 Z_113 D_0 Z_114 
Stack 13
Z_115 C_7 A_3 D_1 A_0 
Stack 14
B_5 E_1 D_8 E_0 D_3 
