Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
I_7 J_2 Z_100 D_5 Z_101 Z_102 
Stack 1
J_4 E_5 I_4 Z_103 B_9 F_6 
Stack 2
B_8 B_5 Z_104 E_4 I_9 J_6 
Stack 3
B_2 F_2 D_9 G_1 G_5 Z_105 
Stack 4
A_0 G_4 C_3 Z_106 E_7 Z_107 
Stack 5
D_1 C_1 G_3 G_6 E_6 
Stack 6
E_3 D_6 Z_108 C_6 D_0 
Stack 7
E_0 D_7 Z_109 J_0 D_2 
Stack 8
A_7 A_1 H_0 H_1 Z_110 
Stack 9
B_1 A_4 Z_111 C_8 C_2 
Stack 10
Z_112 G_0 F_9 C_7 H_2 
Stack 11
D_8 B_3 Z_113 D_3 C_5 
Stack 12
E_8 G_8 I_5 C_9 H_3 
Stack 13
H_5 C_0 A_2 I_1 J_3 
Stack 14
J_7 Z_114 Z_115 Z_116 F_4 
Stack 15
D_4 C_4 F_0 Z_117 Z_118 
Stack 16
J_5 Z_119 B_4 I_6 A_6 
Stack 17
F_8 E_1 I_0 G_2 Z_120 
Stack 18
E_2 A_8 I_2 A_5 B_7 
Stack 19
C_10 A_3 G_7 B_6 I_8 
Stack 20
H_4 B_0 I_10 J_1 Z_121 
Stack 21
G_10 Z_122 H_6 F_5 G_9 
Stack 22
Z_123 F_1 F_3 F_7 I_3 
