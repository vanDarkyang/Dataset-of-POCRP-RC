Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_4 Z_100 D_5 A_6 J_0 D_3 
Stack 1
Z_101 C_1 H_7 J_5 I_7 G_2 
Stack 2
C_6 Z_102 E_10 A_1 C_2 H_9 
Stack 3
G_8 Z_103 G_1 D_9 F_9 D_2 
Stack 4
J_2 C_7 Z_104 Z_105 E_3 E_4 
Stack 5
B_4 I_2 C_8 G_11 J_1 
Stack 6
D_10 E_5 Z_106 F_3 B_2 
Stack 7
G_3 C_5 C_0 H_6 B_6 
Stack 8
F_4 F_8 D_1 Z_107 F_0 
Stack 9
F_2 G_6 E_0 Z_108 D_6 
Stack 10
Z_109 Z_110 F_5 A_3 Z_111 
Stack 11
C_3 Z_112 F_7 Z_113 Z_114 
Stack 12
C_4 D_8 Z_115 H_4 B_5 
Stack 13
E_7 G_0 H_2 E_1 H_1 
Stack 14
H_3 D_7 I_1 I_0 Z_116 
Stack 15
I_3 J_3 B_3 J_4 G_9 
Stack 16
Z_117 G_5 B_8 H_0 A_2 
Stack 17
G_4 Z_118 Z_119 H_5 E_9 
Stack 18
E_6 E_8 H_10 E_11 Z_120 
Stack 19
Z_121 A_5 G_10 B_0 A_4 
Stack 20
H_8 B_7 I_6 Z_122 G_7 
Stack 21
J_6 I_5 F_6 A_0 Z_123 
Stack 22
F_1 D_0 B_1 I_4 E_2 
