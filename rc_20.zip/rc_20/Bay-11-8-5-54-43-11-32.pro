Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_5 D_1 C_2 B_2 B_3 
Stack 1
D_6 E_5 C_9 D_2 C_7 
Stack 2
Z_100 A_2 E_0 D_3 E_6 
Stack 3
Z_101 B_5 E_2 E_1 A_3 
Stack 4
Z_102 Z_103 A_6 C_3 A_4 
Stack 5
Z_104 Z_105 D_5 B_0 E_7 
Stack 6
Z_106 C_8 C_1 A_1 C_0 
Stack 7
C_5 A_0 B_7 C_6 D_0 
Stack 8
D_4 A_7 Z_107 B_4 D_7 
Stack 9
Z_108 E_4 E_3 Z_109 C_10 
Stack 10
B_6 C_4 Z_110 B_1 
