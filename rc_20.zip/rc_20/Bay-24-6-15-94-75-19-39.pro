Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 Z_101 D_1 G_1 
Stack 1
N_1 L_2 Z_102 K_6 
Stack 2
K_1 H_5 C_3 F_3 
Stack 3
I_4 Z_103 E_2 A_1 
Stack 4
E_4 H_3 F_1 D_0 
Stack 5
G_4 C_2 I_6 O_1 
Stack 6
D_4 I_1 G_2 M_2 
Stack 7
F_5 Z_104 B_2 Z_105 
Stack 8
Z_106 Z_107 K_3 H_2 
Stack 9
D_3 N_2 L_4 J_0 
Stack 10
Z_108 L_3 M_0 I_2 
Stack 11
O_0 G_5 F_0 Z_109 
Stack 12
F_2 L_0 D_2 K_0 
Stack 13
Z_110 C_4 J_2 I_0 
Stack 14
J_5 H_0 I_3 I_5 
Stack 15
G_0 E_1 G_3 A_0 
Stack 16
C_1 Z_111 L_1 J_6 
Stack 17
K_2 J_1 A_2 Z_112 
Stack 18
Z_113 Z_114 Z_115 K_5 
Stack 19
E_0 B_0 M_1 Z_116 
Stack 20
E_5 H_4 J_4 N_0 
Stack 21
J_3 F_4 Z_117 E_3 
Stack 22
C_0 H_1 G_6 
Stack 23
B_1 K_4 Z_118 
