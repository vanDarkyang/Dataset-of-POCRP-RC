Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
E_3 Z_100 I_0 E_1 Z_101 H_7 
Stack 1
G_0 I_1 H_0 N_2 F_5 N_3 
Stack 2
B_0 H_8 K_0 I_4 O_1 G_1 
Stack 3
H_3 J_1 H_6 Z_102 L_0 D_2 
Stack 4
I_3 Z_103 C_0 J_6 Z_104 
Stack 5
C_2 Z_105 D_4 Z_106 I_7 
Stack 6
N_0 G_2 Z_107 E_0 J_3 
Stack 7
E_2 J_2 K_2 M_2 H_1 
Stack 8
J_4 O_0 E_4 A_2 Z_108 
Stack 9
K_4 G_4 L_2 G_3 Z_109 
Stack 10
B_2 Z_110 K_5 F_2 Z_111 
Stack 11
M_3 Z_112 M_0 D_3 H_2 
Stack 12
L_3 Z_113 D_1 C_1 N_1 
Stack 13
K_3 D_0 H_5 Z_114 L_1 
Stack 14
I_6 M_1 Z_115 B_1 K_1 
Stack 15
A_1 F_3 I_5 Z_116 A_0 
Stack 16
Z_117 F_1 H_4 F_0 I_2 
Stack 17
J_0 F_4 Z_118 J_5 F_6 
