Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_1 B_7 Z_100 Z_101 
Stack 1
C_1 A_8 A_2 Z_102 
Stack 2
A_5 A_6 B_2 C_6 
Stack 3
B_0 C_8 C_12 C_4 
Stack 4
A_3 B_3 A_0 B_5 
Stack 5
C_5 C_11 Z_103 A_1 
Stack 6
B_8 A_9 C_10 Z_104 
Stack 7
B_6 Z_105 C_3 C_2 
Stack 8
Z_106 A_10 B_9 Z_107 
Stack 9
Z_108 B_4 C_7 C_13 
Stack 10
C_0 A_4 A_11 
Stack 11
A_7 Z_109 C_9 
