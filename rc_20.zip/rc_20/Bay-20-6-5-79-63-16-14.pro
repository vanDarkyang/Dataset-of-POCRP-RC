Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_7 C_0 D_2 E_7 
Stack 1
C_2 Z_100 C_11 A_5 
Stack 2
E_8 C_3 B_8 E_3 
Stack 3
B_3 E_13 Z_101 E_11 
Stack 4
D_11 Z_102 Z_103 Z_104 
Stack 5
C_4 C_6 B_5 A_2 
Stack 6
A_3 A_10 Z_105 D_6 
Stack 7
C_1 C_8 Z_106 D_0 
Stack 8
D_1 E_12 C_9 C_12 
Stack 9
E_4 D_10 A_4 Z_107 
Stack 10
D_9 E_6 E_0 D_8 
Stack 11
B_7 Z_108 Z_109 Z_110 
Stack 12
Z_111 Z_112 A_0 E_10 
Stack 13
B_4 C_5 A_1 B_2 
Stack 14
D_5 B_1 C_7 D_7 
Stack 15
C_10 D_4 E_2 Z_113 
Stack 16
B_10 A_6 B_6 B_11 
Stack 17
B_9 E_1 B_0 E_9 
Stack 18
Z_114 E_5 A_9 A_8 
Stack 19
D_12 Z_115 D_3 
