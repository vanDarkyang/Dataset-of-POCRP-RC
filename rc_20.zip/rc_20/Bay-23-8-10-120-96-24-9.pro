Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 E_9 H_9 G_10 C_8 E_1 
Stack 1
B_7 F_8 C_0 J_3 B_6 I_8 
Stack 2
G_7 I_0 B_4 D_4 Z_101 F_10 
Stack 3
Z_102 H_4 Z_103 E_6 H_3 A_3 
Stack 4
J_0 E_4 D_2 F_1 H_7 Z_104 
Stack 5
F_11 H_5 D_1 F_6 I_7 
Stack 6
B_8 H_0 G_2 Z_105 H_6 
Stack 7
B_0 D_3 J_2 A_6 D_7 
Stack 8
B_5 Z_106 D_5 Z_107 F_0 
Stack 9
C_3 A_5 E_3 Z_108 D_0 
Stack 10
F_5 C_5 E_8 A_2 Z_109 
Stack 11
B_3 G_5 Z_110 B_2 C_9 
Stack 12
E_5 E_7 Z_111 I_5 G_3 
Stack 13
G_11 Z_112 H_2 G_8 Z_113 
Stack 14
E_0 C_7 I_3 J_4 Z_114 
Stack 15
Z_115 C_1 Z_116 I_9 C_4 
Stack 16
Z_117 Z_118 H_1 F_4 F_7 
Stack 17
F_2 G_0 Z_119 I_6 C_6 
Stack 18
I_1 I_2 E_2 G_9 Z_120 
Stack 19
H_8 H_10 G_4 Z_121 J_1 
Stack 20
F_9 F_3 D_6 G_1 A_1 
Stack 21
C_2 B_1 I_4 B_9 G_12 
Stack 22
Z_122 G_6 A_4 Z_123 A_0 
