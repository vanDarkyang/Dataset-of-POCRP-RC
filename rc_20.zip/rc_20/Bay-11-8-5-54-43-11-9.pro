Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
D_3 C_2 C_3 A_5 C_4 
Stack 1
A_7 C_1 E_5 D_6 D_9 
Stack 2
C_9 B_4 D_7 B_1 A_0 
Stack 3
Z_100 A_2 B_7 B_0 C_5 
Stack 4
E_1 D_0 C_8 A_1 E_2 
Stack 5
D_2 D_1 C_7 Z_101 Z_102 
Stack 6
E_4 C_6 D_4 D_5 Z_103 
Stack 7
Z_104 E_3 Z_105 Z_106 A_3 
Stack 8
A_4 Z_107 B_5 A_6 C_0 
Stack 9
Z_108 B_3 B_6 E_0 Z_109 
Stack 10
C_10 Z_110 B_2 D_8 
