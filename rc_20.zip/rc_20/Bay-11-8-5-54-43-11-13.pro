Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_6 D_4 B_3 D_8 D_1 
Stack 1
Z_100 Z_101 B_2 C_4 C_3 
Stack 2
A_2 B_1 E_2 A_1 C_2 
Stack 3
E_5 E_3 E_8 A_4 D_7 
Stack 4
B_4 Z_102 A_6 A_3 D_2 
Stack 5
C_8 B_7 Z_103 A_5 D_3 
Stack 6
B_5 D_6 Z_104 Z_105 C_5 
Stack 7
Z_106 C_7 E_0 E_1 A_0 
Stack 8
Z_107 B_6 D_5 C_0 B_0 
Stack 9
C_6 Z_108 D_0 Z_109 E_4 
Stack 10
Z_110 A_7 E_7 C_1 
