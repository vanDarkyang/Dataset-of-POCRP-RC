Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
D_4 C_3 D_1 A_3 
Stack 1
D_5 B_3 E_4 E_5 
Stack 2
Z_100 B_5 D_2 C_5 
Stack 3
A_8 C_9 A_1 C_2 
Stack 4
C_1 A_4 Z_101 Z_102 
Stack 5
Z_103 Z_104 B_2 B_4 
Stack 6
Z_105 Z_106 A_9 C_4 
Stack 7
E_3 D_6 E_1 B_6 
Stack 8
C_10 Z_107 Z_108 C_6 
Stack 9
E_2 D_7 C_0 E_0 
Stack 10
A_7 A_0 D_0 D_3 
Stack 11
A_6 Z_109 B_0 C_7 
Stack 12
A_5 A_2 Z_110 
Stack 13
B_1 E_6 C_8 
