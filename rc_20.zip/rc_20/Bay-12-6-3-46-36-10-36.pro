Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_0 A_3 Z_100 B_7 
Stack 1
Z_101 Z_102 A_2 B_11 
Stack 2
B_0 B_12 Z_103 C_9 
Stack 3
C_7 C_6 A_8 B_3 
Stack 4
A_1 B_5 B_9 C_2 
Stack 5
Z_104 A_6 C_4 C_10 
Stack 6
B_13 C_8 B_14 B_1 
Stack 7
C_11 Z_105 C_5 C_3 
Stack 8
B_2 Z_106 A_4 C_1 
Stack 9
B_8 A_0 B_4 A_5 
Stack 10
Z_107 B_10 B_6 
Stack 11
Z_108 A_7 Z_109 
