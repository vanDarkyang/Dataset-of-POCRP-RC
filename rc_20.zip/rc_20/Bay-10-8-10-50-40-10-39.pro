Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_0 F_0 G_3 D_2 I_3 
Stack 1
G_0 D_1 F_2 H_1 E_1 
Stack 2
E_0 I_1 J_0 E_2 B_1 
Stack 3
B_0 I_2 J_1 F_5 C_1 
Stack 4
B_3 Z_100 Z_101 Z_102 I_0 
Stack 5
E_3 H_0 F_6 D_3 Z_103 
Stack 6
C_0 F_1 C_2 Z_104 F_3 
Stack 7
E_4 Z_105 F_4 G_4 E_5 
Stack 8
G_2 Z_106 Z_107 G_5 G_1 
Stack 9
Z_108 Z_109 B_2 D_0 D_4 
