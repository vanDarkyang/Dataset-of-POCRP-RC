Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_0 Z_100 Z_101 C_7 C_0 A_4 
Stack 1
A_6 D_2 D_1 E_8 Z_102 B_8 
Stack 2
C_13 Z_103 C_4 E_3 C_10 A_2 
Stack 3
A_8 E_0 C_12 D_3 B_13 B_11 
Stack 4
B_10 B_2 D_7 Z_104 Z_105 
Stack 5
B_0 C_5 A_9 Z_106 A_7 
Stack 6
A_1 D_9 Z_107 Z_108 E_5 
Stack 7
B_1 C_1 B_5 D_8 E_2 
Stack 8
Z_109 C_3 D_10 E_4 Z_110 
Stack 9
Z_111 D_0 B_9 C_2 A_3 
Stack 10
B_4 E_9 B_12 D_6 E_10 
Stack 11
D_4 Z_112 Z_113 E_7 A_12 
Stack 12
C_9 C_6 D_5 A_11 C_8 
Stack 13
Z_114 Z_115 B_3 A_10 C_11 
Stack 14
A_5 B_7 B_6 E_1 E_6 
