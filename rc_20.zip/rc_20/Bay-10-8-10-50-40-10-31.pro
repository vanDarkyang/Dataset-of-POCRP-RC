Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_0 E_1 G_4 J_2 F_4 
Stack 1
H_1 D_0 G_0 Z_100 A_2 
Stack 2
D_2 C_0 B_2 F_3 F_2 
Stack 3
D_4 Z_101 A_1 F_0 B_1 
Stack 4
I_0 F_1 B_0 C_1 E_0 
Stack 5
E_3 D_3 Z_102 G_2 D_1 
Stack 6
Z_103 Z_104 H_3 H_0 J_1 
Stack 7
I_2 Z_105 Z_106 D_5 I_1 
Stack 8
H_2 Z_107 Z_108 B_3 J_0 
Stack 9
E_4 G_3 Z_109 G_1 E_2 
