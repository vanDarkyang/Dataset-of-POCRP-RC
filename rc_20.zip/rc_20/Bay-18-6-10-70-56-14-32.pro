Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
E_2 F_5 E_1 H_3 
Stack 1
Z_100 F_3 H_6 D_3 
Stack 2
D_5 G_2 A_3 E_3 
Stack 3
Z_101 A_1 D_0 B_0 
Stack 4
Z_102 G_5 J_0 J_3 
Stack 5
Z_103 H_1 G_6 G_4 
Stack 6
B_3 G_0 I_3 G_3 
Stack 7
J_2 D_4 I_0 C_2 
Stack 8
C_1 Z_104 B_2 Z_105 
Stack 9
G_1 F_1 Z_106 D_2 
Stack 10
C_0 E_5 H_5 Z_107 
Stack 11
C_4 E_4 B_1 A_2 
Stack 12
Z_108 Z_109 C_5 A_0 
Stack 13
F_2 F_0 E_0 Z_110 
Stack 14
H_2 E_6 F_4 C_3 
Stack 15
D_1 Z_111 H_4 I_2 
Stack 16
Z_112 I_4 J_1 
Stack 17
I_1 Z_113 H_0 
