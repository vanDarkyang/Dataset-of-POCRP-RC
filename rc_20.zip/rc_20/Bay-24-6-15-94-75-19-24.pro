Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 F_0 M_0 K_4 
Stack 1
M_2 Z_101 G_4 C_0 
Stack 2
I_4 O_2 I_0 J_5 
Stack 3
A_2 O_0 I_1 H_7 
Stack 4
Z_102 H_5 I_5 Z_103 
Stack 5
B_1 G_0 B_0 Z_104 
Stack 6
H_6 Z_105 M_1 Z_106 
Stack 7
G_5 E_3 E_0 J_2 
Stack 8
J_3 M_3 Z_107 Z_108 
Stack 9
F_2 F_6 K_3 Z_109 
Stack 10
D_2 Z_110 G_3 N_3 
Stack 11
Z_111 Z_112 C_2 N_1 
Stack 12
M_4 C_1 E_4 D_3 
Stack 13
J_4 K_2 E_2 I_7 
Stack 14
I_3 I_2 F_1 E_1 
Stack 15
F_3 H_2 H_4 J_6 
Stack 16
D_1 A_1 Z_113 J_1 
Stack 17
I_6 Z_114 D_0 Z_115 
Stack 18
H_8 N_2 F_4 F_5 
Stack 19
L_2 H_3 K_0 Z_116 
Stack 20
G_1 B_2 K_1 N_0 
Stack 21
H_0 Z_117 L_1 O_1 
Stack 22
G_2 Z_118 A_0 
Stack 23
L_0 J_0 H_1 
