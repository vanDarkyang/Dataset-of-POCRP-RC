Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_1 I_2 E_0 G_1 D_0 
Stack 1
I_0 D_4 Z_100 F_0 E_2 
Stack 2
G_0 H_0 D_3 H_3 Z_101 
Stack 3
B_2 F_5 A_1 Z_102 F_4 
Stack 4
Z_103 C_2 E_1 H_2 D_2 
Stack 5
J_1 Z_104 A_2 A_0 G_3 
Stack 6
I_1 E_3 E_4 F_2 Z_105 
Stack 7
D_1 F_3 G_2 D_5 B_0 
Stack 8
Z_106 J_2 B_1 F_1 Z_107 
Stack 9
Z_108 Z_109 H_1 C_0 J_0 
