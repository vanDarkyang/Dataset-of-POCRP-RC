Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_6 D_4 H_6 B_7 Z_100 E_9 
Stack 1
B_9 E_5 E_0 H_4 Z_101 Z_102 
Stack 2
F_10 C_6 D_1 Z_103 D_7 A_3 
Stack 3
E_6 H_8 B_4 I_3 J_2 E_1 
Stack 4
I_1 J_6 F_6 Z_104 H_2 B_5 
Stack 5
Z_105 F_5 I_6 J_7 G_7 
Stack 6
I_5 H_5 Z_106 F_9 D_9 
Stack 7
G_2 A_5 I_7 Z_107 E_8 
Stack 8
B_0 Z_108 D_8 C_3 H_1 
Stack 9
H_3 D_3 D_0 G_1 Z_109 
Stack 10
Z_110 F_1 A_0 Z_111 C_2 
Stack 11
G_6 C_1 B_2 C_10 Z_112 
Stack 12
Z_113 H_9 A_2 E_7 J_5 
Stack 13
J_0 G_0 E_4 B_6 C_5 
Stack 14
Z_114 Z_115 B_3 D_5 G_4 
Stack 15
F_7 F_0 G_8 C_4 C_7 
Stack 16
G_10 B_8 E_2 A_4 Z_116 
Stack 17
J_4 G_9 Z_117 Z_118 B_10 
Stack 18
C_0 Z_119 H_7 C_9 B_1 
Stack 19
Z_120 F_3 Z_121 J_3 E_3 
Stack 20
I_2 F_2 Z_122 H_0 J_1 
Stack 21
C_8 G_3 G_5 D_2 I_4 
Stack 22
F_4 Z_123 I_0 A_1 F_8 
