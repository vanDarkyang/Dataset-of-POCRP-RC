Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 Z_101 J_2 I_1 L_4 Z_102 
Stack 1
G_4 L_3 F_4 J_0 H_2 E_3 
Stack 2
D_0 K_5 H_0 D_2 F_1 O_1 
Stack 3
Z_103 G_0 F_2 Z_104 Z_105 L_0 
Stack 4
H_8 A_1 I_0 H_1 B_2 
Stack 5
H_4 F_5 J_5 I_4 H_5 
Stack 6
E_1 Z_106 O_0 I_5 E_0 
Stack 7
K_2 E_2 L_5 K_4 N_2 
Stack 8
L_1 Z_107 H_3 B_0 B_1 
Stack 9
I_6 I_2 N_0 Z_108 Z_109 
Stack 10
H_9 Z_110 K_0 Z_111 D_1 
Stack 11
G_2 D_3 C_0 A_0 J_4 
Stack 12
L_2 Z_112 C_1 F_3 H_6 
Stack 13
G_3 K_1 C_2 Z_113 M_2 
Stack 14
Z_114 M_4 J_3 I_3 N_1 
Stack 15
F_0 Z_115 Z_116 Z_117 E_4 
Stack 16
J_1 M_3 K_3 G_1 M_0 
Stack 17
Z_118 I_7 H_7 C_3 M_1 
