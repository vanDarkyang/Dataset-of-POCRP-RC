Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
L_0 M_2 Z_100 E_3 G_6 G_5 
Stack 1
K_3 I_0 H_3 Z_101 G_8 B_2 
Stack 2
Z_102 B_1 I_4 J_1 J_7 M_0 
Stack 3
C_3 K_1 Z_103 H_5 Z_104 F_3 
Stack 4
L_2 Z_105 I_1 Z_106 N_1 
Stack 5
E_2 G_0 Z_107 H_2 H_0 
Stack 6
Z_108 C_2 Z_109 B_3 G_7 
Stack 7
H_6 J_3 Z_110 I_6 O_1 
Stack 8
F_2 C_1 J_4 E_1 E_4 
Stack 9
E_0 L_3 Z_111 G_1 G_3 
Stack 10
D_2 F_1 G_2 H_1 I_5 
Stack 11
J_2 Z_112 B_0 D_3 H_7 
Stack 12
Z_113 Z_114 J_6 I_3 D_1 
Stack 13
I_2 Z_115 H_4 M_1 N_0 
Stack 14
Z_116 Z_117 K_2 L_1 A_0 
Stack 15
C_4 L_4 Z_118 I_7 M_3 
Stack 16
O_0 G_4 F_4 K_0 D_0 
Stack 17
J_5 C_0 F_0 O_2 J_0 
