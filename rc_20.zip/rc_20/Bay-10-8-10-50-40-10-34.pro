Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 B_1 Z_101 H_4 A_0 
Stack 1
F_3 H_3 E_4 E_0 E_5 
Stack 2
C_3 Z_102 B_2 I_0 B_0 
Stack 3
G_0 E_1 G_2 I_1 D_2 
Stack 4
A_1 C_0 H_1 Z_103 Z_104 
Stack 5
Z_105 F_1 D_1 D_0 J_1 
Stack 6
H_0 Z_106 Z_107 E_3 I_2 
Stack 7
J_0 I_3 E_2 G_3 A_2 
Stack 8
C_2 F_4 Z_108 J_2 C_1 
Stack 9
F_0 G_1 Z_109 H_2 F_2 
