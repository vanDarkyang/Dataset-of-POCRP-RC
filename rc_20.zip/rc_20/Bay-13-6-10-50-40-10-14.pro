Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_0 E_0 F_2 I_0 
Stack 1
B_1 G_2 G_0 Z_100 
Stack 2
A_2 B_0 I_3 C_2 
Stack 3
A_0 B_2 J_2 E_6 
Stack 4
Z_101 G_3 D_2 Z_102 
Stack 5
Z_103 E_1 D_1 J_0 
Stack 6
D_3 Z_104 Z_105 Z_106 
Stack 7
F_3 E_3 G_4 E_5 
Stack 8
G_1 E_2 J_1 D_4 
Stack 9
Z_107 C_1 Z_108 C_0 
Stack 10
E_4 H_2 Z_109 H_0 
Stack 11
D_0 F_1 I_1 
Stack 12
H_1 I_2 A_1 
