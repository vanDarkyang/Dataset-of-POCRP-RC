Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 F_3 Z_101 D_2 H_1 
Stack 1
G_4 A_0 G_5 H_4 H_5 
Stack 2
E_6 J_4 C_4 G_2 Z_102 
Stack 3
Z_103 F_2 G_6 E_2 B_3 
Stack 4
E_0 Z_104 E_7 I_3 J_2 
Stack 5
C_3 H_2 Z_105 B_0 Z_106 
Stack 6
C_0 F_1 Z_107 I_2 G_0 
Stack 7
B_1 C_2 D_0 Z_108 F_7 
Stack 8
H_0 J_3 D_3 Z_109 E_4 
Stack 9
D_4 J_1 F_4 I_0 J_0 
Stack 10
E_5 G_1 Z_110 F_5 G_3 
Stack 11
F_6 Z_111 E_3 B_2 E_1 
Stack 12
C_1 D_1 I_4 Z_112 A_1 
Stack 13
D_5 I_1 Z_113 H_3 F_0 
