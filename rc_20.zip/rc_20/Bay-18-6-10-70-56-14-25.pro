Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
J_0 Z_100 D_3 Z_101 
Stack 1
H_1 J_2 G_3 E_4 
Stack 2
Z_102 F_0 G_5 I_0 
Stack 3
B_0 B_1 G_7 H_3 
Stack 4
G_0 Z_103 I_1 C_3 
Stack 5
F_2 G_6 B_3 Z_104 
Stack 6
C_2 D_4 E_3 F_1 
Stack 7
Z_105 E_6 D_2 F_6 
Stack 8
I_2 Z_106 Z_107 A_2 
Stack 9
A_3 Z_108 A_1 H_0 
Stack 10
Z_109 C_1 F_3 F_7 
Stack 11
C_4 D_5 G_4 A_0 
Stack 12
Z_110 F_4 E_5 E_7 
Stack 13
B_4 Z_111 B_2 Z_112 
Stack 14
H_2 F_5 I_3 Z_113 
Stack 15
G_1 E_0 G_2 B_5 
Stack 16
E_2 E_1 J_1 
Stack 17
D_0 D_1 C_0 
