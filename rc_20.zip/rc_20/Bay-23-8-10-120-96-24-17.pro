Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_5 H_8 C_9 H_5 E_3 B_5 
Stack 1
H_0 J_6 E_7 C_1 A_6 J_1 
Stack 2
C_2 I_3 Z_100 I_6 B_3 E_4 
Stack 3
E_1 Z_101 J_5 F_8 Z_102 A_7 
Stack 4
I_4 E_0 B_1 Z_103 E_2 F_3 
Stack 5
B_6 D_7 G_3 D_0 G_0 
Stack 6
Z_104 G_4 F_2 G_8 B_7 
Stack 7
H_4 H_7 H_9 B_4 A_8 
Stack 8
D_3 A_0 I_2 E_10 E_9 
Stack 9
J_2 F_5 Z_105 Z_106 F_6 
Stack 10
C_6 C_4 J_3 Z_107 E_6 
Stack 11
F_9 A_4 I_7 G_5 C_7 
Stack 12
Z_108 F_7 D_4 H_2 Z_109 
Stack 13
C_3 D_1 H_10 Z_110 J_0 
Stack 14
D_5 G_7 C_0 G_9 H_1 
Stack 15
Z_111 Z_112 G_2 B_0 D_6 
Stack 16
B_2 J_7 C_5 A_1 H_6 
Stack 17
Z_113 Z_114 Z_115 Z_116 Z_117 
Stack 18
F_4 Z_118 I_0 C_8 G_1 
Stack 19
Z_119 F_1 Z_120 Z_121 F_0 
Stack 20
A_2 H_3 A_3 J_8 J_4 
Stack 21
D_2 Z_122 I_1 E_5 I_5 
Stack 22
Z_123 E_8 G_6 D_9 D_8 
