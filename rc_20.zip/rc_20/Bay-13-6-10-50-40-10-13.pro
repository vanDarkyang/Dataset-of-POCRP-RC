Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
H_1 E_3 I_1 J_1 
Stack 1
E_4 G_2 D_1 Z_100 
Stack 2
C_0 I_0 E_5 F_5 
Stack 3
Z_101 Z_102 A_1 J_2 
Stack 4
D_4 C_1 E_0 E_1 
Stack 5
F_4 G_5 D_3 D_2 
Stack 6
H_2 Z_103 G_4 E_6 
Stack 7
Z_104 Z_105 A_0 Z_106 
Stack 8
Z_107 F_1 J_0 Z_108 
Stack 9
F_3 G_3 G_1 H_0 
Stack 10
D_0 B_1 H_3 F_0 
Stack 11
F_2 B_0 E_2 
Stack 12
Z_109 G_0 D_5 
