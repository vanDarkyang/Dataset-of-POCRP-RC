Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
I_0 G_2 K_0 Z_100 
Stack 1
G_1 B_1 K_3 Z_101 
Stack 2
J_5 L_1 L_2 F_4 
Stack 3
Z_102 K_5 F_2 D_3 
Stack 4
F_1 B_2 G_3 M_2 
Stack 5
H_0 I_2 Z_103 Z_104 
Stack 6
K_6 H_4 A_1 Z_105 
Stack 7
H_3 D_2 C_2 E_4 
Stack 8
B_0 Z_106 C_1 M_1 
Stack 9
G_4 G_7 D_5 K_2 
Stack 10
D_0 I_4 N_1 F_3 
Stack 11
H_1 Z_107 E_3 I_1 
Stack 12
Z_108 J_4 F_5 Z_109 
Stack 13
K_4 H_2 G_5 C_3 
Stack 14
Z_110 K_1 D_4 E_0 
Stack 15
B_3 I_3 J_0 M_0 
Stack 16
E_2 Z_111 Z_112 I_5 
Stack 17
E_1 H_7 A_0 L_3 
Stack 18
Z_113 F_0 N_2 G_6 
Stack 19
M_3 Z_114 J_1 Z_115 
Stack 20
J_2 H_5 L_0 C_0 
Stack 21
Z_116 D_1 N_0 Z_117 
Stack 22
J_3 G_0 J_6 
Stack 23
O_0 H_6 Z_118 
