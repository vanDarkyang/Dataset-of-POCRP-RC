Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
B_8 Z_100 D_3 B_10 B_2 Z_101 
Stack 1
E_1 D_7 A_8 C_8 D_10 B_0 
Stack 2
Z_102 B_3 Z_103 Z_104 Z_105 Z_106 
Stack 3
C_12 B_5 A_1 C_0 E_7 Z_107 
Stack 4
A_10 E_10 D_9 A_7 C_11 
Stack 5
E_6 C_14 A_5 C_5 A_4 
Stack 6
B_7 Z_108 C_6 C_3 D_11 
Stack 7
D_6 E_2 D_5 D_8 E_3 
Stack 8
B_1 C_2 A_2 D_12 A_3 
Stack 9
E_9 E_4 C_13 C_4 D_1 
Stack 10
Z_109 Z_110 A_0 B_4 B_9 
Stack 11
C_9 C_1 A_6 D_4 B_6 
Stack 12
Z_111 D_0 E_12 E_0 Z_112 
Stack 13
E_5 Z_113 E_11 E_8 C_7 
Stack 14
Z_114 C_10 Z_115 A_9 D_2 
