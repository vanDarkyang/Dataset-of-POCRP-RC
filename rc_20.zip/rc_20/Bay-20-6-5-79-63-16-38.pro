Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
B_2 Z_100 D_2 B_4 
Stack 1
D_13 Z_101 Z_102 B_5 
Stack 2
A_1 C_2 C_11 E_7 
Stack 3
D_10 D_12 B_9 D_7 
Stack 4
B_0 D_5 A_5 D_1 
Stack 5
C_1 A_0 E_0 E_5 
Stack 6
Z_103 C_3 A_6 D_11 
Stack 7
B_10 E_3 C_0 C_4 
Stack 8
E_4 D_14 Z_104 D_3 
Stack 9
Z_105 C_10 E_1 Z_106 
Stack 10
B_1 D_9 D_6 A_3 
Stack 11
B_6 Z_107 C_9 C_5 
Stack 12
E_2 A_7 A_12 B_7 
Stack 13
E_6 C_7 Z_108 Z_109 
Stack 14
D_0 A_2 A_9 Z_110 
Stack 15
A_8 C_6 C_13 Z_111 
Stack 16
Z_112 C_12 Z_113 Z_114 
Stack 17
A_13 D_8 B_3 A_11 
Stack 18
B_11 D_4 A_10 A_4 
Stack 19
Z_115 B_8 C_8 
