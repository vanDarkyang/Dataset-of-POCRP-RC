Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_9 Z_100 A_7 Z_101 E_0 C_8 
Stack 1
E_7 A_2 D_2 E_8 E_2 B_7 
Stack 2
C_13 D_4 Z_102 C_9 E_3 D_13 
Stack 3
E_9 C_12 D_11 Z_103 D_0 E_4 
Stack 4
A_11 B_5 Z_104 A_3 E_10 
Stack 5
C_5 E_1 D_12 D_10 C_4 
Stack 6
A_5 C_10 A_0 Z_105 B_2 
Stack 7
D_6 Z_106 B_9 B_1 A_1 
Stack 8
Z_107 C_7 C_11 A_8 Z_108 
Stack 9
B_3 C_1 C_2 B_10 Z_109 
Stack 10
A_10 C_3 A_4 Z_110 Z_111 
Stack 11
D_3 B_8 C_0 E_5 Z_112 
Stack 12
E_6 D_7 A_6 Z_113 D_8 
Stack 13
Z_114 C_14 B_6 D_5 C_6 
Stack 14
B_0 Z_115 B_4 D_9 D_1 
