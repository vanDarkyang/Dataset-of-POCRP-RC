Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_2 B_0 D_0 Z_100 B_1 
Stack 1
A_3 J_2 D_1 A_0 H_6 
Stack 2
Z_101 F_3 B_3 H_0 I_1 
Stack 3
Z_102 Z_103 F_2 Z_104 Z_105 
Stack 4
J_1 I_3 C_0 I_0 J_0 
Stack 5
I_4 G_4 Z_106 G_1 A_1 
Stack 6
C_1 F_1 G_3 F_5 F_0 
Stack 7
H_1 H_3 H_4 B_2 H_2 
Stack 8
E_2 D_6 J_3 D_5 B_4 
Stack 9
C_2 H_5 G_2 G_0 Z_107 
Stack 10
D_4 E_0 D_3 Z_108 Z_109 
Stack 11
F_6 Z_110 E_5 Z_111 D_7 
Stack 12
Z_112 E_3 C_3 Z_113 I_2 
Stack 13
E_1 E_4 F_4 I_5 A_2 
