Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 E_1 B_2 K_1 J_2 J_4 
Stack 1
Z_101 M_0 G_6 Z_102 K_3 F_4 
Stack 2
G_3 Z_103 Z_104 C_0 H_3 H_2 
Stack 3
F_0 Z_105 N_2 H_4 L_2 I_1 
Stack 4
Z_106 L_1 J_1 G_1 N_1 
Stack 5
D_1 Z_107 H_5 Z_108 A_0 
Stack 6
G_2 Z_109 A_1 E_2 M_4 
Stack 7
D_0 J_3 F_3 Z_110 B_0 
Stack 8
F_5 H_0 H_6 K_0 Z_111 
Stack 9
L_0 N_0 I_4 K_2 C_1 
Stack 10
L_3 E_0 B_3 D_3 F_2 
Stack 11
I_0 Z_112 Z_113 I_2 J_5 
Stack 12
G_5 E_4 J_6 Z_114 G_4 
Stack 13
L_4 H_7 J_0 L_5 E_5 
Stack 14
Z_115 Z_116 Z_117 E_3 B_1 
Stack 15
I_3 I_5 K_4 G_7 O_0 
Stack 16
M_3 G_0 F_6 M_2 D_2 
Stack 17
H_1 Z_118 M_1 F_1 O_1 
