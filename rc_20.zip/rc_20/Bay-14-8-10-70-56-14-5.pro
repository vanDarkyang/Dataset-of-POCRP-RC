Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_2 Z_100 D_3 H_4 G_2 
Stack 1
C_1 G_0 I_4 B_4 B_1 
Stack 2
D_0 Z_101 H_2 Z_102 F_4 
Stack 3
F_2 C_5 C_0 Z_103 A_0 
Stack 4
E_0 I_0 J_1 B_2 B_0 
Stack 5
G_3 H_5 A_1 E_5 Z_104 
Stack 6
J_2 F_0 F_3 H_1 J_3 
Stack 7
I_2 D_2 D_1 E_4 Z_105 
Stack 8
E_2 H_0 E_1 F_6 G_1 
Stack 9
B_3 E_6 J_4 C_3 I_1 
Stack 10
E_7 H_6 Z_106 I_3 F_1 
Stack 11
Z_107 Z_108 E_3 J_0 Z_109 
Stack 12
Z_110 D_4 G_4 H_3 Z_111 
Stack 13
C_4 F_5 A_2 Z_112 Z_113 
