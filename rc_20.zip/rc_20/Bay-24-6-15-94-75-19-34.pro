Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 G_4 K_2 M_4 
Stack 1
B_0 H_5 C_1 E_2 
Stack 2
L_1 Z_101 B_2 J_0 
Stack 3
H_4 Z_102 I_7 D_1 
Stack 4
N_2 L_0 N_0 E_0 
Stack 5
Z_103 I_5 C_0 C_3 
Stack 6
L_2 Z_104 K_0 L_3 
Stack 7
J_1 I_2 E_3 Z_105 
Stack 8
Z_106 E_1 H_1 G_5 
Stack 9
Z_107 M_3 I_6 M_1 
Stack 10
K_3 Z_108 M_0 L_4 
Stack 11
Z_109 F_5 G_6 F_3 
Stack 12
I_0 Z_110 C_2 D_2 
Stack 13
I_1 J_4 J_6 J_3 
Stack 14
D_3 F_1 J_5 G_3 
Stack 15
G_2 O_1 H_7 O_0 
Stack 16
Z_111 Z_112 Z_113 Z_114 
Stack 17
H_2 Z_115 I_4 Z_116 
Stack 18
H_6 Z_117 H_0 Z_118 
Stack 19
F_6 A_1 H_3 G_0 
Stack 20
J_2 F_2 K_4 G_1 
Stack 21
K_1 D_0 M_2 A_0 
Stack 22
B_1 F_4 N_1 
Stack 23
F_0 G_7 I_3 
