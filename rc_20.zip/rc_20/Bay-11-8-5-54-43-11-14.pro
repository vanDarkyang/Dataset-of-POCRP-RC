Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_0 A_6 B_5 D_5 Z_100 
Stack 1
D_6 D_7 C_1 Z_101 E_6 
Stack 2
A_1 C_2 B_1 D_0 E_2 
Stack 3
B_2 A_7 A_3 E_5 B_7 
Stack 4
E_3 Z_102 B_3 D_2 C_5 
Stack 5
B_4 Z_103 Z_104 Z_105 A_5 
Stack 6
C_3 Z_106 B_8 C_8 C_9 
Stack 7
E_0 C_6 D_3 D_1 C_4 
Stack 8
B_6 E_1 A_4 Z_107 D_4 
Stack 9
B_0 C_7 A_2 B_9 Z_108 
Stack 10
Z_109 Z_110 E_4 A_0 
