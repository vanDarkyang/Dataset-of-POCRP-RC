Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
F_7 D_3 H_3 Z_100 C_3 
Stack 1
A_1 G_5 B_3 Z_101 E_0 
Stack 2
B_1 G_3 A_2 J_2 Z_102 
Stack 3
Z_103 Z_104 H_2 G_4 J_4 
Stack 4
E_2 D_1 F_5 F_1 B_2 
Stack 5
D_0 Z_105 C_2 F_6 C_4 
Stack 6
C_0 D_2 E_4 G_0 I_0 
Stack 7
G_6 H_0 Z_106 Z_107 C_5 
Stack 8
I_1 G_1 F_2 E_5 E_7 
Stack 9
C_1 F_0 E_1 I_2 Z_108 
Stack 10
F_4 E_3 C_6 Z_109 B_0 
Stack 11
H_1 J_1 A_0 F_3 J_3 
Stack 12
A_3 Z_110 J_0 E_6 Z_111 
Stack 13
Z_112 G_2 H_4 D_4 Z_113 
