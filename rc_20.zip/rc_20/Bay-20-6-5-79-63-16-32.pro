Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
E_7 D_8 B_3 B_10 
Stack 1
B_5 C_4 D_7 B_9 
Stack 2
Z_100 Z_101 Z_102 E_2 
Stack 3
B_8 Z_103 C_7 B_7 
Stack 4
A_3 Z_104 A_1 C_6 
Stack 5
A_6 A_4 D_1 B_6 
Stack 6
A_5 C_8 A_11 Z_105 
Stack 7
E_0 C_11 E_8 C_1 
Stack 8
A_13 D_12 D_3 E_3 
Stack 9
A_10 D_4 Z_106 D_2 
Stack 10
E_6 D_11 B_2 Z_107 
Stack 11
D_10 E_9 Z_108 A_2 
Stack 12
C_9 Z_109 D_0 B_1 
Stack 13
C_5 A_8 D_5 Z_110 
Stack 14
C_3 Z_111 Z_112 B_4 
Stack 15
A_0 A_12 B_11 E_5 
Stack 16
E_1 C_0 Z_113 C_2 
Stack 17
B_0 D_9 D_6 E_11 
Stack 18
Z_114 E_10 A_9 C_10 
Stack 19
A_7 Z_115 E_4 
