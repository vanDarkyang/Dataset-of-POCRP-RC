Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
J_1 Z_100 D_0 Z_101 F_2 
Stack 1
E_3 H_3 Z_102 E_1 H_0 
Stack 2
D_1 H_1 F_0 D_3 D_2 
Stack 3
J_0 A_0 G_0 G_1 Z_103 
Stack 4
D_4 Z_104 C_0 B_0 E_6 
Stack 5
G_3 F_4 Z_105 H_2 H_4 
Stack 6
F_5 J_2 I_1 E_4 Z_106 
Stack 7
Z_107 A_2 I_0 A_1 E_5 
Stack 8
Z_108 B_1 F_1 G_2 E_0 
Stack 9
Z_109 I_2 C_1 F_3 E_2 
