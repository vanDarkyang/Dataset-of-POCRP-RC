Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
D_2 I_0 B_2 I_1 F_1 
Stack 1
Z_100 A_0 D_3 A_2 D_1 
Stack 2
E_2 Z_101 J_1 Z_102 G_0 
Stack 3
G_4 D_0 H_1 Z_103 F_0 
Stack 4
B_3 H_2 C_0 J_0 Z_104 
Stack 5
Z_105 Z_106 C_1 H_3 E_4 
Stack 6
J_2 Z_107 H_4 E_1 E_0 
Stack 7
G_1 I_2 B_1 E_3 G_3 
Stack 8
Z_108 E_5 Z_109 F_2 D_4 
Stack 9
C_2 A_1 G_2 H_0 B_0 
