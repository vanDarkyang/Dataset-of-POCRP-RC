Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
I_4 G_0 Z_100 E_3 
Stack 1
Z_101 F_0 J_5 J_0 
Stack 2
E_0 I_1 G_5 Z_102 
Stack 3
Z_103 K_3 L_3 L_1 
Stack 4
D_0 L_4 I_5 G_1 
Stack 5
I_2 H_1 K_5 Z_104 
Stack 6
E_4 G_6 D_2 K_2 
Stack 7
G_4 Z_105 D_5 J_4 
Stack 8
K_0 H_3 C_2 D_3 
Stack 9
Z_106 Z_107 Z_108 J_2 
Stack 10
L_2 C_1 J_6 N_0 
Stack 11
N_2 K_6 F_1 C_4 
Stack 12
Z_109 I_0 D_4 H_4 
Stack 13
Z_110 I_3 O_0 A_0 
Stack 14
Z_111 Z_112 A_1 H_5 
Stack 15
B_1 J_3 G_7 O_1 
Stack 16
M_2 E_2 H_0 Z_113 
Stack 17
Z_114 M_3 F_2 B_0 
Stack 18
H_2 Z_115 E_5 G_2 
Stack 19
L_0 B_3 G_3 D_1 
Stack 20
Z_116 Z_117 K_1 C_0 
Stack 21
M_1 E_1 K_4 M_0 
Stack 22
F_3 N_1 J_1 
Stack 23
Z_118 C_3 B_2 
