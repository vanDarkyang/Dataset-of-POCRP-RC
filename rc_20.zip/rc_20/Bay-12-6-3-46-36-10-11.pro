Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_1 C_4 C_9 A_0 
Stack 1
B_5 C_0 A_4 C_5 
Stack 2
Z_100 B_3 B_1 A_9 
Stack 3
B_11 B_0 B_12 A_3 
Stack 4
Z_101 C_2 C_6 A_7 
Stack 5
C_1 Z_102 B_2 B_4 
Stack 6
Z_103 C_11 A_2 B_8 
Stack 7
Z_104 B_9 B_6 B_7 
Stack 8
A_8 Z_105 Z_106 B_13 
Stack 9
Z_107 C_8 Z_108 C_7 
Stack 10
C_10 C_3 A_5 
Stack 11
Z_109 B_10 A_6 
