Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
D_2 Z_100 Z_101 B_8 
Stack 1
D_12 B_7 C_15 Z_102 
Stack 2
B_9 D_3 B_0 B_5 
Stack 3
C_3 A_0 D_6 D_9 
Stack 4
Z_103 Z_104 D_8 C_1 
Stack 5
A_3 Z_105 E_7 A_5 
Stack 6
C_12 Z_106 C_14 C_10 
Stack 7
E_9 B_3 E_6 D_1 
Stack 8
C_4 A_10 C_5 A_4 
Stack 9
B_6 E_10 C_9 B_1 
Stack 10
B_4 Z_107 Z_108 A_11 
Stack 11
Z_109 C_11 D_7 A_2 
Stack 12
Z_110 A_12 D_0 E_0 
Stack 13
C_6 A_8 A_7 D_10 
Stack 14
C_8 E_4 Z_111 D_4 
Stack 15
E_3 E_1 B_2 A_1 
Stack 16
A_9 Z_112 C_7 D_5 
Stack 17
C_13 C_0 Z_113 Z_114 
Stack 18
E_2 C_2 E_5 Z_115 
Stack 19
A_6 D_11 E_8 
