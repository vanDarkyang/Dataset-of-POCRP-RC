Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_10 Z_100 A_6 E_0 
Stack 1
E_7 Z_101 C_0 E_2 
Stack 2
C_11 B_7 A_7 Z_102 
Stack 3
E_10 C_5 Z_103 D_0 
Stack 4
Z_104 C_1 B_3 E_11 
Stack 5
Z_105 Z_106 Z_107 C_3 
Stack 6
Z_108 B_9 E_8 B_1 
Stack 7
D_7 D_8 C_7 A_1 
Stack 8
E_6 C_12 E_9 Z_109 
Stack 9
B_2 E_1 A_5 A_3 
Stack 10
A_11 A_8 D_9 B_11 
Stack 11
D_4 D_3 Z_110 B_6 
Stack 12
E_5 D_2 B_0 Z_111 
Stack 13
A_2 D_10 A_9 C_4 
Stack 14
Z_112 Z_113 B_12 D_1 
Stack 15
Z_114 D_11 B_8 C_6 
Stack 16
A_4 A_0 E_4 B_5 
Stack 17
D_5 B_10 C_9 D_12 
Stack 18
C_10 C_8 D_6 E_3 
Stack 19
B_4 C_2 Z_115 
