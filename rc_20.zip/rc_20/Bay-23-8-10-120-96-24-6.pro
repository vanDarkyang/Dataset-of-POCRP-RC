Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_2 Z_100 C_6 Z_101 I_0 G_8 
Stack 1
B_2 E_2 E_10 C_4 H_10 E_7 
Stack 2
Z_102 F_2 B_4 D_4 D_5 I_3 
Stack 3
H_8 F_9 F_8 A_0 I_2 Z_103 
Stack 4
I_4 F_3 H_2 A_4 I_5 C_1 
Stack 5
J_4 G_9 Z_104 H_9 Z_105 
Stack 6
E_6 Z_106 H_6 B_6 F_5 
Stack 7
Z_107 H_3 G_6 G_10 F_7 
Stack 8
E_0 E_4 C_2 C_8 J_2 
Stack 9
I_1 A_7 D_0 B_5 Z_108 
Stack 10
F_4 F_11 G_4 B_0 F_1 
Stack 11
E_9 J_1 G_1 H_7 H_5 
Stack 12
E_11 E_1 A_2 H_4 I_6 
Stack 13
G_0 D_6 F_10 Z_109 I_8 
Stack 14
F_0 Z_110 G_2 E_8 B_3 
Stack 15
H_1 D_7 Z_111 F_6 B_7 
Stack 16
H_0 Z_112 Z_113 A_3 A_5 
Stack 17
Z_114 E_5 C_7 Z_115 G_7 
Stack 18
G_11 C_5 G_3 E_3 G_5 
Stack 19
A_6 I_7 Z_116 Z_117 E_12 
Stack 20
J_0 Z_118 D_1 B_8 C_3 
Stack 21
Z_119 A_1 J_3 D_3 Z_120 
Stack 22
Z_121 C_0 Z_122 Z_123 B_1 
