Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 A_2 D_4 Z_101 
Stack 1
A_8 D_0 Z_102 D_7 
Stack 2
Z_103 D_1 B_7 C_5 
Stack 3
C_1 C_6 Z_104 D_8 
Stack 4
E_0 E_2 B_3 A_0 
Stack 5
D_2 E_3 A_5 Z_105 
Stack 6
Z_106 B_5 D_6 E_1 
Stack 7
D_3 B_1 B_2 A_6 
Stack 8
A_4 C_4 B_0 E_6 
Stack 9
E_4 Z_107 A_1 A_3 
Stack 10
Z_108 Z_109 E_5 C_0 
Stack 11
C_3 B_8 D_5 B_4 
Stack 12
C_2 C_8 Z_110 
Stack 13
B_6 C_7 A_7 
