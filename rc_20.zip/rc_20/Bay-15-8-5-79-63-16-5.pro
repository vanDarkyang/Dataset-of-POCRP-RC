Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_9 Z_100 A_9 C_1 C_13 B_10 
Stack 1
C_3 Z_101 A_5 D_13 Z_102 E_6 
Stack 2
E_7 A_4 E_8 D_3 A_1 A_7 
Stack 3
D_2 B_9 C_4 Z_103 Z_104 D_5 
Stack 4
B_3 C_10 Z_105 Z_106 C_2 
Stack 5
A_3 Z_107 B_1 A_6 A_11 
Stack 6
D_11 E_5 A_0 C_6 D_1 
Stack 7
B_6 E_0 D_7 Z_108 Z_109 
Stack 8
D_10 A_8 A_2 B_0 Z_110 
Stack 9
Z_111 C_7 B_11 B_5 C_12 
Stack 10
D_9 D_8 C_14 C_5 B_4 
Stack 11
Z_112 Z_113 B_8 B_7 E_1 
Stack 12
A_10 D_12 C_11 C_0 E_4 
Stack 13
Z_114 Z_115 C_8 D_4 B_2 
Stack 14
D_6 E_9 E_2 E_3 D_0 
