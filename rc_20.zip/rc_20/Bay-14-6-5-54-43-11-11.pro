Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_1 D_5 B_0 D_4 
Stack 1
C_5 A_0 E_4 E_2 
Stack 2
C_6 A_5 B_7 D_3 
Stack 3
D_2 Z_100 E_0 B_9 
Stack 4
A_2 A_1 D_8 Z_101 
Stack 5
A_7 D_6 C_7 C_8 
Stack 6
D_1 E_3 B_6 Z_102 
Stack 7
Z_103 D_0 A_3 E_5 
Stack 8
B_4 A_8 C_1 A_6 
Stack 9
C_0 B_1 C_4 Z_104 
Stack 10
A_4 C_2 B_5 Z_105 
Stack 11
B_2 C_3 Z_106 Z_107 
Stack 12
B_3 Z_108 Z_109 
Stack 13
Z_110 B_8 D_7 
