Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 F_3 D_0 E_3 M_2 A_2 
Stack 1
L_3 B_1 H_3 I_3 G_6 Z_101 
Stack 2
N_0 M_1 G_2 J_1 H_5 O_0 
Stack 3
G_5 H_0 A_0 L_4 K_0 Z_102 
Stack 4
C_1 I_6 I_4 E_2 F_4 
Stack 5
Z_103 C_3 I_2 Z_104 Z_105 
Stack 6
G_7 H_4 L_0 A_1 H_6 
Stack 7
J_3 D_4 J_2 Z_106 M_0 
Stack 8
I_5 H_7 J_5 O_2 I_0 
Stack 9
F_1 K_2 D_1 J_4 Z_107 
Stack 10
G_0 Z_108 L_2 D_2 C_4 
Stack 11
Z_109 Z_110 H_8 Z_111 Z_112 
Stack 12
E_6 E_0 J_6 B_0 C_2 
Stack 13
E_4 K_1 D_3 L_1 C_0 
Stack 14
Z_113 Z_114 J_0 H_2 O_1 
Stack 15
Z_115 Z_116 Z_117 G_3 Z_118 
Stack 16
F_5 F_0 N_1 E_1 F_2 
Stack 17
I_1 G_1 G_4 E_5 H_1 
