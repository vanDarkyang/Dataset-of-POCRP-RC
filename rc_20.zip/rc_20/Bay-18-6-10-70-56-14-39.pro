Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
H_0 C_3 Z_100 Z_101 
Stack 1
D_2 Z_102 A_1 F_1 
Stack 2
B_1 A_2 I_0 F_2 
Stack 3
C_5 E_3 B_2 E_6 
Stack 4
D_0 E_2 A_0 I_1 
Stack 5
C_1 H_3 Z_103 E_1 
Stack 6
G_4 Z_104 Z_105 B_0 
Stack 7
C_2 C_0 I_3 J_1 
Stack 8
E_7 E_4 H_2 A_3 
Stack 9
F_4 H_1 J_2 D_4 
Stack 10
Z_106 Z_107 G_0 I_2 
Stack 11
F_5 H_4 Z_108 G_5 
Stack 12
G_1 Z_109 I_4 F_3 
Stack 13
I_5 A_4 Z_110 F_0 
Stack 14
E_5 D_1 J_0 G_2 
Stack 15
Z_111 E_0 C_4 H_5 
Stack 16
Z_112 G_3 D_5 
Stack 17
D_3 Z_113 G_6 
