Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_0 E_4 Z_100 B_8 C_3 
Stack 1
C_6 E_1 E_0 C_8 D_7 
Stack 2
D_1 C_2 D_5 Z_101 D_6 
Stack 3
B_2 E_2 Z_102 D_4 D_8 
Stack 4
A_7 Z_103 Z_104 B_4 D_3 
Stack 5
C_9 A_1 B_7 E_5 A_3 
Stack 6
C_4 C_1 C_7 Z_105 Z_106 
Stack 7
E_6 B_3 C_0 Z_107 A_5 
Stack 8
D_2 E_3 C_5 A_4 B_1 
Stack 9
Z_108 A_6 B_5 Z_109 B_6 
Stack 10
Z_110 A_0 A_2 D_0 
