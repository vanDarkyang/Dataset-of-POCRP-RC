Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
I_2 C_3 D_1 C_5 Z_100 
Stack 1
Z_101 H_4 G_5 I_3 H_3 
Stack 2
Z_102 Z_103 D_5 E_5 Z_104 
Stack 3
D_3 F_1 C_2 C_4 I_0 
Stack 4
B_2 Z_105 F_6 E_6 H_2 
Stack 5
Z_106 G_3 B_3 J_0 D_4 
Stack 6
D_6 E_0 A_0 J_1 D_2 
Stack 7
D_0 B_0 C_1 G_1 E_1 
Stack 8
Z_107 B_1 B_4 E_4 B_5 
Stack 9
H_5 F_5 G_2 J_2 Z_108 
Stack 10
G_4 I_1 F_2 F_0 C_0 
Stack 11
G_6 Z_109 E_2 E_3 F_4 
Stack 12
Z_110 H_0 A_1 H_1 Z_111 
Stack 13
F_3 G_0 A_2 Z_112 Z_113 
