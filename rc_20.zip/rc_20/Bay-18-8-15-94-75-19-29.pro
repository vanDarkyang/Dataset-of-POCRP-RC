Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
G_6 I_7 E_0 D_4 D_1 H_2 
Stack 1
G_3 H_0 I_1 F_1 B_3 Z_100 
Stack 2
C_0 H_3 L_1 Z_101 O_0 J_0 
Stack 3
E_3 N_3 B_2 N_1 D_3 N_2 
Stack 4
G_1 Z_102 M_2 A_0 Z_103 
Stack 5
L_0 G_2 B_0 Z_104 J_2 
Stack 6
I_3 E_1 F_2 Z_105 O_2 
Stack 7
H_5 J_6 H_1 Z_106 G_0 
Stack 8
G_5 Z_107 I_5 E_2 M_0 
Stack 9
D_0 I_2 Z_108 I_6 J_1 
Stack 10
A_2 J_4 Z_109 K_0 O_1 
Stack 11
Z_110 M_1 B_1 Z_111 Z_112 
Stack 12
L_2 I_4 C_3 J_5 Z_113 
Stack 13
G_4 Z_114 E_4 D_5 F_4 
Stack 14
H_4 Z_115 Z_116 I_0 F_6 
Stack 15
F_3 Z_117 D_2 Z_118 C_1 
Stack 16
K_3 K_1 M_3 J_3 F_0 
Stack 17
C_2 F_5 A_1 K_2 N_0 
