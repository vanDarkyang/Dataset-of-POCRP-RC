Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_5 J_0 D_3 Z_100 A_0 
Stack 1
D_2 F_0 C_0 I_3 I_2 
Stack 2
E_5 G_3 G_1 H_0 D_4 
Stack 3
J_2 D_1 I_0 J_1 I_1 
Stack 4
G_2 H_2 Z_101 H_1 Z_102 
Stack 5
C_1 Z_103 E_2 F_4 F_3 
Stack 6
E_3 F_2 F_1 E_0 Z_104 
Stack 7
Z_105 Z_106 Z_107 B_2 D_0 
Stack 8
Z_108 E_1 Z_109 A_1 G_0 
Stack 9
C_3 E_4 C_2 B_1 B_0 
