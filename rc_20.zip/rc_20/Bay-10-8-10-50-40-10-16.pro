Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
D_2 F_2 C_0 G_2 E_1 
Stack 1
H_1 Z_100 D_0 Z_101 F_3 
Stack 2
Z_102 E_2 Z_103 Z_104 J_2 
Stack 3
E_0 F_1 B_1 I_2 E_3 
Stack 4
B_2 J_0 A_1 H_4 Z_105 
Stack 5
G_0 Z_106 H_2 I_3 I_1 
Stack 6
D_1 F_0 J_1 E_4 F_4 
Stack 7
A_0 I_0 C_1 H_3 H_0 
Stack 8
Z_107 B_0 G_3 C_2 G_1 
Stack 9
D_3 Z_108 Z_109 F_5 C_3 
