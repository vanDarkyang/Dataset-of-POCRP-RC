Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
D_1 Z_100 G_5 I_1 D_4 
Stack 1
D_0 B_2 B_0 A_0 C_0 
Stack 2
D_2 E_0 F_0 Z_101 F_1 
Stack 3
I_0 Z_102 A_1 H_1 Z_103 
Stack 4
F_5 G_4 Z_104 E_4 E_1 
Stack 5
G_3 A_2 H_3 H_2 I_2 
Stack 6
Z_105 E_3 Z_106 F_4 F_3 
Stack 7
E_2 C_2 G_0 Z_107 H_0 
Stack 8
D_3 Z_108 Z_109 B_1 F_2 
Stack 9
C_3 C_1 J_0 G_1 G_2 
