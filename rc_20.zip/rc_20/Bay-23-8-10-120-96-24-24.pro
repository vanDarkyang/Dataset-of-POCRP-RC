Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_8 Z_100 D_3 C_0 D_4 G_6 
Stack 1
C_10 Z_101 G_8 I_4 G_0 C_3 
Stack 2
J_4 Z_102 I_8 A_7 G_9 H_3 
Stack 3
Z_103 J_3 C_9 F_8 I_3 G_2 
Stack 4
I_0 Z_104 E_3 E_1 E_6 F_1 
Stack 5
G_11 C_1 J_1 C_11 D_7 
Stack 6
Z_105 D_6 G_10 Z_106 E_10 
Stack 7
Z_107 Z_108 Z_109 G_4 B_3 
Stack 8
H_2 F_0 C_4 D_1 I_1 
Stack 9
E_8 E_9 H_4 E_0 F_3 
Stack 10
Z_110 D_5 Z_111 B_8 Z_112 
Stack 11
B_1 B_2 Z_113 E_2 I_6 
Stack 12
E_7 G_1 F_5 A_2 G_3 
Stack 13
Z_114 G_7 I_7 H_5 J_0 
Stack 14
H_8 B_6 A_1 I_2 F_6 
Stack 15
A_8 Z_115 Z_116 A_3 H_0 
Stack 16
F_2 H_7 B_4 D_2 C_8 
Stack 17
Z_117 A_4 A_5 F_7 Z_118 
Stack 18
F_4 G_5 Z_119 H_1 J_2 
Stack 19
C_7 E_4 I_5 Z_120 D_0 
Stack 20
C_6 J_5 G_12 Z_121 B_5 
Stack 21
A_6 Z_122 H_6 Z_123 E_5 
Stack 22
A_0 B_0 B_7 C_2 C_5 
