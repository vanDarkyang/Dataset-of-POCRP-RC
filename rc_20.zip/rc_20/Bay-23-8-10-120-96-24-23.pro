Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_9 H_7 J_1 J_9 D_8 I_7 
Stack 1
A_6 Z_100 H_8 J_0 D_1 A_8 
Stack 2
Z_101 C_0 Z_102 F_1 Z_103 B_6 
Stack 3
A_5 Z_104 A_3 Z_105 E_0 J_7 
Stack 4
E_3 E_1 E_4 Z_106 H_3 B_8 
Stack 5
F_6 F_7 A_2 Z_107 G_5 
Stack 6
G_6 H_2 F_4 E_9 D_7 
Stack 7
E_10 B_5 Z_108 Z_109 D_2 
Stack 8
J_5 H_1 C_7 C_5 I_5 
Stack 9
H_6 F_2 F_5 J_3 B_1 
Stack 10
D_6 Z_110 I_4 A_0 B_2 
Stack 11
B_4 C_3 A_1 F_3 E_7 
Stack 12
B_10 F_0 G_8 B_9 J_2 
Stack 13
D_3 Z_111 Z_112 Z_113 D_0 
Stack 14
Z_114 G_2 A_7 C_6 C_1 
Stack 15
D_5 B_0 C_2 C_8 J_8 
Stack 16
G_1 G_7 I_6 H_4 J_6 
Stack 17
E_11 G_0 G_4 D_4 E_5 
Stack 18
I_8 I_0 H_5 E_6 Z_115 
Stack 19
Z_116 E_2 Z_117 I_3 Z_118 
Stack 20
Z_119 B_3 B_7 I_2 I_1 
Stack 21
J_4 H_0 Z_120 A_4 Z_121 
Stack 22
Z_122 Z_123 E_8 G_3 C_4 
