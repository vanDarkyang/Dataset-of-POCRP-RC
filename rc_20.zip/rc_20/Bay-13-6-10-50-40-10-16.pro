Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 F_1 Z_101 F_4 
Stack 1
H_1 J_0 C_1 E_1 
Stack 2
Z_102 G_0 G_5 Z_103 
Stack 3
E_0 F_0 E_2 Z_104 
Stack 4
B_3 I_0 G_4 Z_105 
Stack 5
G_1 B_1 D_2 D_3 
Stack 6
D_1 B_0 G_2 Z_106 
Stack 7
Z_107 C_0 I_1 F_3 
Stack 8
C_4 D_0 Z_108 H_0 
Stack 9
D_4 Z_109 I_2 G_3 
Stack 10
F_2 B_2 E_4 C_3 
Stack 11
A_0 A_1 H_3 
Stack 12
E_3 H_2 C_2 
