Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
F_5 J_2 C_1 F_3 B_1 N_0 
Stack 1
K_1 O_2 H_0 Z_100 J_4 G_0 
Stack 2
Z_101 D_3 H_8 Z_102 B_3 C_0 
Stack 3
O_1 Z_103 Z_104 B_0 F_0 E_4 
Stack 4
H_7 C_3 I_4 L_4 Z_105 
Stack 5
A_1 O_0 M_0 N_1 Z_106 
Stack 6
Z_107 M_3 H_4 K_2 H_5 
Stack 7
N_2 G_3 G_1 M_1 Z_108 
Stack 8
G_5 E_5 N_3 Z_109 J_3 
Stack 9
H_6 H_3 L_3 F_4 H_1 
Stack 10
Z_110 D_4 Z_111 L_2 Z_112 
Stack 11
C_2 I_6 Z_113 F_2 D_1 
Stack 12
I_5 G_2 I_0 K_0 L_0 
Stack 13
F_1 Z_114 J_0 J_5 E_0 
Stack 14
E_1 D_0 I_1 B_2 A_0 
Stack 15
I_2 G_4 Z_115 I_3 J_1 
Stack 16
E_2 Z_116 Z_117 H_2 L_1 
Stack 17
E_3 M_4 M_2 Z_118 D_2 
