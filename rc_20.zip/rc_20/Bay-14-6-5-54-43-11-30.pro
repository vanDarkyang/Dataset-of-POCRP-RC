Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_4 C_7 C_8 B_2 
Stack 1
E_9 C_6 E_2 A_1 
Stack 2
Z_100 D_5 B_7 E_4 
Stack 3
A_6 B_5 B_3 C_5 
Stack 4
Z_101 A_0 E_6 D_7 
Stack 5
Z_102 D_3 Z_103 Z_104 
Stack 6
D_6 C_4 Z_105 Z_106 
Stack 7
E_1 C_0 Z_107 Z_108 
Stack 8
Z_109 D_0 E_3 A_3 
Stack 9
D_2 D_4 D_1 E_7 
Stack 10
C_1 C_3 C_9 A_5 
Stack 11
B_1 B_0 E_0 C_2 
Stack 12
A_2 E_5 B_6 
Stack 13
E_8 Z_110 A_4 
