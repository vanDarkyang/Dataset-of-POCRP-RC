Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_1 D_3 F_4 I_1 C_1 
Stack 1
Z_100 E_5 Z_101 Z_102 H_1 
Stack 2
B_1 I_2 F_2 H_3 G_2 
Stack 3
E_2 D_4 Z_103 C_0 B_2 
Stack 4
Z_104 E_0 G_0 G_1 F_3 
Stack 5
I_0 H_0 Z_105 I_3 F_5 
Stack 6
E_1 G_4 J_0 E_4 G_3 
Stack 7
D_1 D_2 F_0 A_2 E_3 
Stack 8
Z_106 B_0 Z_107 F_1 H_2 
Stack 9
D_0 Z_108 A_0 Z_109 G_5 
