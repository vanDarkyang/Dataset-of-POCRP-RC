Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_0 F_0 F_5 F_3 C_4 
Stack 1
C_0 Z_100 H_1 H_0 B_1 
Stack 2
Z_101 F_1 Z_102 J_0 Z_103 
Stack 3
B_3 F_2 J_2 A_0 E_0 
Stack 4
D_3 D_1 D_2 Z_104 H_3 
Stack 5
C_1 Z_105 G_2 Z_106 J_1 
Stack 6
I_1 F_4 D_5 E_2 B_2 
Stack 7
E_3 Z_107 C_2 Z_108 G_3 
Stack 8
C_3 I_0 E_1 D_0 H_2 
Stack 9
G_1 D_4 Z_109 E_4 G_0 
