Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_0 F_1 H_1 B_2 
Stack 1
B_0 D_2 D_3 E_2 
Stack 2
B_3 G_4 C_3 F_2 
Stack 3
J_0 H_2 I_2 Z_100 
Stack 4
E_1 A_0 A_1 F_4 
Stack 5
G_2 C_1 B_1 Z_101 
Stack 6
D_4 Z_102 G_1 G_3 
Stack 7
D_0 Z_103 I_0 I_1 
Stack 8
H_0 I_3 F_0 H_4 
Stack 9
H_3 C_0 D_1 J_1 
Stack 10
Z_104 Z_105 Z_106 G_0 
Stack 11
Z_107 E_3 Z_108 
Stack 12
F_3 Z_109 C_2 
