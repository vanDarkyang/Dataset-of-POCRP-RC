Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_9 B_9 Z_100 C_9 
Stack 1
Z_101 B_0 B_10 Z_102 
Stack 2
A_6 C_0 A_8 A_10 
Stack 3
Z_103 C_2 C_7 B_7 
Stack 4
C_4 Z_104 C_12 Z_105 
Stack 5
B_5 B_2 C_8 Z_106 
Stack 6
B_3 A_5 C_1 B_1 
Stack 7
A_11 C_5 B_6 B_4 
Stack 8
A_7 A_0 C_11 Z_107 
Stack 9
A_4 C_6 Z_108 B_8 
Stack 10
C_10 Z_109 A_1 
Stack 11
A_3 A_2 C_3 
