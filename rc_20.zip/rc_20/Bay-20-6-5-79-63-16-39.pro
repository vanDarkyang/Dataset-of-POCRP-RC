Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_2 Z_100 C_3 D_7 
Stack 1
C_2 Z_101 Z_102 D_3 
Stack 2
C_10 D_1 B_10 A_1 
Stack 3
B_8 D_8 C_9 A_7 
Stack 4
A_3 E_1 D_12 E_11 
Stack 5
E_9 C_11 D_4 B_7 
Stack 6
B_1 E_8 B_9 E_7 
Stack 7
A_5 D_9 C_1 A_0 
Stack 8
B_3 E_0 D_6 B_2 
Stack 9
E_5 C_6 B_0 E_3 
Stack 10
Z_103 Z_104 D_2 D_10 
Stack 11
D_0 B_6 C_5 Z_105 
Stack 12
B_5 A_4 Z_106 A_8 
Stack 13
C_7 C_0 Z_107 E_6 
Stack 14
A_10 C_14 C_12 Z_108 
Stack 15
E_10 A_9 B_4 E_4 
Stack 16
Z_109 Z_110 Z_111 Z_112 
Stack 17
Z_113 D_11 D_13 Z_114 
Stack 18
A_6 E_2 C_8 C_13 
Stack 19
Z_115 C_4 D_5 
