Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_4 D_9 D_7 E_2 
Stack 1
A_8 E_5 Z_100 B_8 
Stack 2
B_0 A_0 Z_101 Z_102 
Stack 3
B_7 Z_103 D_8 D_6 
Stack 4
A_4 D_4 D_2 Z_104 
Stack 5
C_6 C_3 B_1 Z_105 
Stack 6
A_7 E_0 A_3 B_6 
Stack 7
C_5 C_4 D_3 B_5 
Stack 8
Z_106 C_1 C_0 E_4 
Stack 9
Z_107 C_7 A_6 Z_108 
Stack 10
D_1 Z_109 A_5 D_5 
Stack 11
B_2 C_2 Z_110 A_2 
Stack 12
B_3 A_1 E_3 
Stack 13
D_0 C_8 E_1 
