Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_4 E_1 C_0 D_0 C_3 
Stack 1
B_1 D_3 C_2 Z_100 I_0 
Stack 2
Z_101 I_1 J_1 F_2 Z_102 
Stack 3
H_1 E_2 Z_103 Z_104 G_3 
Stack 4
D_1 E_0 F_1 Z_105 A_1 
Stack 5
I_3 B_2 A_0 J_0 F_0 
Stack 6
F_5 G_1 Z_106 D_2 Z_107 
Stack 7
G_2 Z_108 E_3 G_0 H_0 
Stack 8
C_4 F_3 F_4 I_2 Z_109 
Stack 9
H_2 C_1 H_3 H_4 B_0 
