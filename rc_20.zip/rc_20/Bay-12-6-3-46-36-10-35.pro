Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 C_6 A_0 A_11 
Stack 1
A_3 C_2 A_5 B_6 
Stack 2
A_1 B_5 Z_101 C_8 
Stack 3
A_10 B_8 A_8 B_9 
Stack 4
C_1 B_7 C_5 B_1 
Stack 5
C_3 A_7 B_3 Z_102 
Stack 6
Z_103 B_4 A_9 C_7 
Stack 7
Z_104 Z_105 C_4 B_10 
Stack 8
B_11 A_6 A_4 Z_106 
Stack 9
A_2 C_11 Z_107 C_9 
Stack 10
B_0 B_2 Z_108 
Stack 11
C_0 Z_109 C_10 
