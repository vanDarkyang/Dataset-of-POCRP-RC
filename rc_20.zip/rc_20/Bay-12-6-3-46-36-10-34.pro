Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_4 B_4 C_3 B_6 
Stack 1
Z_100 Z_101 B_1 Z_102 
Stack 2
A_0 B_2 C_1 C_5 
Stack 3
Z_103 B_3 Z_104 A_4 
Stack 4
B_10 Z_105 A_10 B_5 
Stack 5
Z_106 Z_107 A_7 A_6 
Stack 6
A_9 C_9 A_2 C_11 
Stack 7
B_9 C_10 C_2 B_0 
Stack 8
C_0 A_11 B_11 A_3 
Stack 9
B_8 A_5 A_8 A_1 
Stack 10
C_7 B_7 C_6 
Stack 11
C_8 Z_108 Z_109 
