Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_7 B_3 C_8 B_2 B_4 C_12 
Stack 1
A_9 A_6 C_6 D_2 Z_100 B_7 
Stack 2
D_9 B_11 A_2 D_3 C_10 E_3 
Stack 3
Z_101 D_8 D_6 C_1 Z_102 B_9 
Stack 4
B_10 B_12 Z_103 C_11 C_5 
Stack 5
Z_104 C_3 Z_105 E_5 Z_106 
Stack 6
E_9 Z_107 Z_108 C_13 E_0 
Stack 7
B_0 Z_109 C_4 C_2 E_1 
Stack 8
A_1 Z_110 B_13 D_7 Z_111 
Stack 9
B_1 Z_112 E_4 C_7 A_11 
Stack 10
E_7 D_11 D_1 Z_113 E_10 
Stack 11
B_5 C_0 D_0 A_5 A_4 
Stack 12
Z_114 B_6 B_8 D_5 Z_115 
Stack 13
E_2 C_9 A_8 A_3 E_6 
Stack 14
E_8 A_0 D_4 D_10 A_10 
