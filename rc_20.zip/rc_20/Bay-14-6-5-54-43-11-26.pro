Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
D_1 Z_100 E_6 C_9 
Stack 1
B_3 B_7 C_4 A_6 
Stack 2
Z_101 B_0 C_3 A_2 
Stack 3
C_1 A_1 A_5 D_3 
Stack 4
B_1 E_3 Z_102 C_7 
Stack 5
B_8 A_7 C_8 D_6 
Stack 6
E_5 Z_103 C_0 B_6 
Stack 7
Z_104 B_2 Z_105 B_4 
Stack 8
B_5 C_5 Z_106 E_7 
Stack 9
D_0 A_3 D_5 C_2 
Stack 10
C_6 E_4 A_0 Z_107 
Stack 11
E_2 E_0 D_4 D_2 
Stack 12
D_7 A_4 E_1 
Stack 13
Z_108 Z_109 Z_110 
