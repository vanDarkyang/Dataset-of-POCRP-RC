Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 Z_101 Z_102 A_6 
Stack 1
C_2 C_3 A_3 C_11 
Stack 2
B_0 B_5 B_9 C_5 
Stack 3
Z_103 B_10 Z_104 A_7 
Stack 4
C_6 B_8 B_6 C_10 
Stack 5
A_1 A_9 B_4 B_11 
Stack 6
B_3 A_0 Z_105 A_5 
Stack 7
A_8 A_4 B_2 B_7 
Stack 8
B_1 Z_106 C_9 Z_107 
Stack 9
C_0 C_4 C_8 Z_108 
Stack 10
C_12 C_1 A_10 
Stack 11
A_2 C_7 Z_109 
