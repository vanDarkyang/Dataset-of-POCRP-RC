Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
D_3 Z_100 B_6 Z_101 C_5 
Stack 1
Z_102 A_4 Z_103 A_6 C_1 
Stack 2
E_7 B_1 A_0 E_1 D_6 
Stack 3
Z_104 C_2 B_2 D_4 B_4 
Stack 4
C_0 B_3 A_1 Z_105 C_4 
Stack 5
Z_106 B_7 E_8 Z_107 B_9 
Stack 6
D_5 Z_108 D_0 B_0 Z_109 
Stack 7
E_4 A_3 E_5 B_8 E_0 
Stack 8
C_8 C_3 D_1 C_7 D_2 
Stack 9
E_3 B_5 Z_110 A_2 C_6 
Stack 10
A_5 D_7 E_2 E_6 
