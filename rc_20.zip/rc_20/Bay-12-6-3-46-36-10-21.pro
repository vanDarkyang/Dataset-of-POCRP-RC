Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 A_0 A_5 C_0 
Stack 1
B_10 A_1 B_6 B_0 
Stack 2
A_9 Z_101 B_3 A_3 
Stack 3
B_4 C_10 Z_102 Z_103 
Stack 4
Z_104 A_11 A_6 B_8 
Stack 5
A_7 A_8 B_9 C_4 
Stack 6
C_5 Z_105 Z_106 C_11 
Stack 7
Z_107 A_2 A_4 C_1 
Stack 8
C_8 A_10 B_7 C_7 
Stack 9
C_6 C_3 Z_108 B_2 
Stack 10
B_1 Z_109 C_9 
Stack 11
C_2 B_5 B_11 
