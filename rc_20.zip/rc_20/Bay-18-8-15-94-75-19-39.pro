Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
L_0 J_1 Z_100 G_0 Z_101 K_4 
Stack 1
N_2 E_0 C_2 B_2 K_5 Z_102 
Stack 2
K_1 Z_103 H_0 Z_104 F_4 N_1 
Stack 3
I_6 J_3 E_1 L_4 A_1 E_3 
Stack 4
E_4 C_0 H_4 M_0 D_0 
Stack 5
G_1 Z_105 Z_106 F_0 O_0 
Stack 6
D_5 G_4 N_0 D_3 M_2 
Stack 7
Z_107 L_2 B_0 J_2 Z_108 
Stack 8
O_1 H_7 H_5 I_5 H_2 
Stack 9
D_4 M_3 Z_109 Z_110 J_0 
Stack 10
F_1 H_3 H_1 L_1 I_3 
Stack 11
Z_111 Z_112 K_3 A_2 Z_113 
Stack 12
F_3 I_2 D_2 H_6 K_0 
Stack 13
D_1 F_5 B_1 M_1 I_1 
Stack 14
Z_114 I_4 C_1 J_4 I_7 
Stack 15
Z_115 N_3 E_2 G_3 A_0 
Stack 16
Z_116 L_3 F_2 G_5 J_5 
Stack 17
K_2 G_2 Z_117 I_0 Z_118 
