Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 B_12 C_7 B_7 
Stack 1
B_5 B_4 A_3 A_7 
Stack 2
B_8 B_3 A_2 Z_101 
Stack 3
B_13 B_2 Z_102 A_4 
Stack 4
A_13 Z_103 B_1 C_6 
Stack 5
A_1 B_9 Z_104 C_4 
Stack 6
B_0 C_1 A_11 A_9 
Stack 7
C_5 A_12 A_0 A_5 
Stack 8
B_10 C_0 B_11 Z_105 
Stack 9
A_10 Z_106 Z_107 C_2 
Stack 10
Z_108 A_8 A_6 
Stack 11
C_3 B_6 Z_109 
