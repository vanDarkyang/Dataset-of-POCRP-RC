Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_8 Z_100 C_10 Z_101 D_6 D_2 
Stack 1
A_7 C_3 B_6 A_9 E_8 D_0 
Stack 2
E_2 C_6 D_1 Z_102 D_4 E_7 
Stack 3
B_5 C_4 C_2 Z_103 Z_104 D_9 
Stack 4
D_8 B_0 B_7 Z_105 Z_106 
Stack 5
E_12 B_11 B_2 Z_107 Z_108 
Stack 6
C_9 D_12 B_4 A_3 C_5 
Stack 7
D_3 B_1 B_12 A_5 E_1 
Stack 8
B_3 C_7 Z_109 E_6 B_8 
Stack 9
E_0 E_5 A_4 B_9 A_1 
Stack 10
C_11 Z_110 Z_111 D_11 C_0 
Stack 11
Z_112 C_1 D_10 D_5 A_8 
Stack 12
Z_113 E_11 E_9 D_7 D_13 
Stack 13
A_0 E_3 A_6 E_4 Z_114 
Stack 14
A_2 E_10 Z_115 E_13 B_10 
