Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_0 A_7 B_8 B_9 
Stack 1
D_7 E_5 D_3 A_0 
Stack 2
A_1 D_1 A_4 Z_100 
Stack 3
B_2 B_0 A_2 E_8 
Stack 4
E_3 Z_101 E_6 E_2 
Stack 5
B_4 E_1 D_6 B_7 
Stack 6
Z_102 C_5 Z_103 C_4 
Stack 7
E_0 E_4 Z_104 Z_105 
Stack 8
B_6 B_5 E_7 Z_106 
Stack 9
B_1 C_1 Z_107 C_2 
Stack 10
A_5 Z_108 Z_109 D_4 
Stack 11
A_6 A_3 C_6 D_5 
Stack 12
D_8 B_3 D_0 
Stack 13
Z_110 D_2 C_3 
