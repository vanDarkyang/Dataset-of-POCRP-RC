Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 E_0 E_2 B_3 
Stack 1
A_0 B_8 E_6 D_6 
Stack 2
Z_101 A_7 Z_102 A_3 
Stack 3
C_6 D_9 Z_103 C_2 
Stack 4
B_5 D_0 D_3 B_7 
Stack 5
A_5 B_1 A_4 Z_104 
Stack 6
B_4 Z_105 B_6 E_1 
Stack 7
Z_106 D_5 C_5 Z_107 
Stack 8
D_7 Z_108 B_0 C_3 
Stack 9
C_7 Z_109 E_5 D_2 
Stack 10
A_2 E_3 C_8 C_4 
Stack 11
A_6 Z_110 A_1 D_4 
Stack 12
D_8 D_1 C_1 
Stack 13
C_0 E_4 B_2 
