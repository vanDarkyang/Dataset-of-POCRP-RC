Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_1 F_3 B_4 E_6 
Stack 1
Z_100 E_4 Z_101 I_4 
Stack 2
C_3 J_2 Z_102 A_3 
Stack 3
C_5 A_0 C_1 F_1 
Stack 4
J_1 F_4 G_1 C_4 
Stack 5
H_4 F_6 F_2 H_3 
Stack 6
B_2 I_0 Z_103 B_3 
Stack 7
E_1 B_0 Z_104 G_0 
Stack 8
C_0 H_2 E_0 D_1 
Stack 9
E_5 H_0 Z_105 D_2 
Stack 10
Z_106 Z_107 Z_108 Z_109 
Stack 11
F_0 G_2 G_4 Z_110 
Stack 12
D_4 A_4 A_2 J_0 
Stack 13
Z_111 E_3 C_2 G_3 
Stack 14
G_5 I_3 F_5 D_3 
Stack 15
D_0 D_5 Z_112 E_2 
Stack 16
J_3 I_2 H_1 
Stack 17
I_1 Z_113 B_1 
