Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_3 A_0 Z_100 B_2 
Stack 1
Z_101 C_0 C_1 I_1 
Stack 2
Z_102 G_3 B_4 C_3 
Stack 3
B_3 G_2 D_1 I_5 
Stack 4
H_2 A_3 I_4 H_4 
Stack 5
F_1 J_0 B_1 J_2 
Stack 6
Z_103 F_4 Z_104 H_0 
Stack 7
Z_105 F_7 C_4 E_1 
Stack 8
F_3 H_1 I_2 B_0 
Stack 9
Z_106 G_1 D_2 E_2 
Stack 10
Z_107 F_6 D_6 F_0 
Stack 11
F_5 E_3 A_2 Z_108 
Stack 12
A_1 D_5 Z_109 F_2 
Stack 13
I_0 J_1 J_3 G_5 
Stack 14
G_0 H_5 H_6 G_4 
Stack 15
D_0 E_0 Z_110 Z_111 
Stack 16
D_4 H_3 C_2 
Stack 17
Z_112 I_3 Z_113 
