Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_7 Z_100 A_1 B_4 E_5 
Stack 1
Z_101 B_8 Z_102 E_6 A_7 
Stack 2
C_2 A_2 A_0 C_6 D_1 
Stack 3
C_9 E_1 A_4 C_0 B_6 
Stack 4
A_5 E_3 E_0 Z_103 A_6 
Stack 5
C_8 C_4 Z_104 Z_105 B_0 
Stack 6
C_1 D_4 D_7 C_3 C_5 
Stack 7
D_5 Z_106 D_0 Z_107 B_7 
Stack 8
B_9 Z_108 Z_109 D_2 D_3 
Stack 9
B_2 E_2 Z_110 D_6 B_1 
Stack 10
E_4 B_3 A_3 B_5 
