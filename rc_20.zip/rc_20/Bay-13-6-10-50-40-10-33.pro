Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_1 F_2 F_0 I_2 
Stack 1
B_0 G_3 Z_100 Z_101 
Stack 2
B_1 Z_102 C_3 F_3 
Stack 3
Z_103 Z_104 F_1 J_0 
Stack 4
D_2 H_1 C_2 A_0 
Stack 5
G_0 E_3 G_1 E_5 
Stack 6
Z_105 I_0 I_3 I_1 
Stack 7
Z_106 F_5 D_4 E_2 
Stack 8
E_4 H_0 D_1 E_0 
Stack 9
C_4 G_2 Z_107 Z_108 
Stack 10
B_2 D_0 C_0 D_3 
Stack 11
C_1 Z_109 G_4 
Stack 12
F_4 H_2 D_5 
