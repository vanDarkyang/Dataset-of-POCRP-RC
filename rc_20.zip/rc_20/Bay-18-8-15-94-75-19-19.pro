Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
D_1 D_3 E_3 C_1 K_1 A_0 
Stack 1
E_2 F_3 M_4 M_1 N_0 Z_100 
Stack 2
Z_101 Z_102 J_2 Z_103 I_1 H_2 
Stack 3
E_6 H_8 K_0 M_3 J_0 Z_104 
Stack 4
G_3 H_6 G_5 E_5 G_2 
Stack 5
F_2 I_2 O_2 C_3 Z_105 
Stack 6
H_4 L_3 Z_106 D_2 H_0 
Stack 7
I_3 D_0 Z_107 K_2 G_0 
Stack 8
H_3 Z_108 G_4 C_2 F_4 
Stack 9
F_0 I_5 Z_109 C_0 F_1 
Stack 10
L_0 E_4 B_2 O_0 L_4 
Stack 11
L_5 H_5 J_4 L_2 Z_110 
Stack 12
N_1 H_7 E_1 N_2 H_1 
Stack 13
J_1 O_1 Z_111 B_1 Z_112 
Stack 14
K_3 G_1 Z_113 G_6 M_0 
Stack 15
Z_114 B_0 I_4 K_4 I_0 
Stack 16
J_5 A_1 Z_115 L_1 M_2 
Stack 17
E_0 J_3 Z_116 Z_117 Z_118 
