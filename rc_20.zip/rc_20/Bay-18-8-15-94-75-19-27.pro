Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
N_2 L_0 K_1 C_0 N_1 F_2 
Stack 1
K_2 Z_100 Z_101 Z_102 E_5 A_2 
Stack 2
Z_103 B_1 O_0 G_1 M_0 Z_104 
Stack 3
J_4 J_1 D_4 H_0 I_7 L_1 
Stack 4
E_6 B_2 J_3 J_5 E_2 
Stack 5
Z_105 E_1 F_6 Z_106 Z_107 
Stack 6
E_3 I_1 F_5 H_2 Z_108 
Stack 7
Z_109 J_6 F_4 Z_110 N_0 
Stack 8
C_2 K_3 A_0 E_0 F_1 
Stack 9
C_3 M_2 A_1 J_0 Z_111 
Stack 10
L_2 Z_112 G_5 I_4 H_4 
Stack 11
G_3 G_6 F_0 I_3 Z_113 
Stack 12
I_6 I_0 J_2 D_2 H_3 
Stack 13
G_2 D_0 E_4 G_0 G_4 
Stack 14
H_5 H_1 Z_114 L_3 B_0 
Stack 15
Z_115 I_2 Z_116 C_1 D_3 
Stack 16
K_4 M_1 Z_117 D_5 Z_118 
Stack 17
D_1 F_3 I_5 K_0 K_5 
