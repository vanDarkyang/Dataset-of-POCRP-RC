Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_2 A_2 Z_100 B_1 
Stack 1
D_3 C_7 B_8 A_3 
Stack 2
B_0 E_3 E_5 C_2 
Stack 3
B_3 E_4 C_5 A_6 
Stack 4
D_8 C_3 C_4 A_5 
Stack 5
Z_101 Z_102 Z_103 Z_104 
Stack 6
A_1 E_0 Z_105 D_0 
Stack 7
A_4 C_1 Z_106 D_1 
Stack 8
E_6 D_6 B_7 D_4 
Stack 9
Z_107 B_5 D_7 B_9 
Stack 10
A_0 B_2 B_4 B_6 
Stack 11
D_2 C_6 B_10 Z_108 
Stack 12
Z_109 D_5 C_0 
Stack 13
E_1 C_8 Z_110 
