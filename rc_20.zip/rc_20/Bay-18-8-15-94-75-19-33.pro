Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
L_3 B_3 L_2 G_1 Z_100 G_0 
Stack 1
Z_101 A_2 M_1 E_1 H_0 M_3 
Stack 2
A_0 Z_102 H_1 H_8 M_0 H_4 
Stack 3
Z_103 K_3 O_0 Z_104 Z_105 H_6 
Stack 4
Z_106 G_5 I_1 M_2 J_5 
Stack 5
A_1 Z_107 K_4 C_0 C_3 
Stack 6
Z_108 F_4 I_4 H_2 J_1 
Stack 7
B_2 Z_109 F_2 F_0 N_1 
Stack 8
N_0 Z_110 C_1 C_4 Z_111 
Stack 9
F_3 G_7 K_2 L_1 E_0 
Stack 10
H_7 I_2 J_3 K_1 G_4 
Stack 11
N_2 J_2 B_0 E_3 J_0 
Stack 12
I_5 E_5 L_4 E_4 G_6 
Stack 13
C_2 J_4 G_2 Z_112 H_5 
Stack 14
Z_113 Z_114 I_0 Z_115 F_1 
Stack 15
K_0 D_2 I_3 Z_116 B_1 
Stack 16
L_0 F_5 D_1 G_3 I_6 
Stack 17
E_2 Z_117 H_3 D_0 Z_118 
