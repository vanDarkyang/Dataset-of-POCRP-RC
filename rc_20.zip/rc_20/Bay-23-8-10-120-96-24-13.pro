Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 H_0 F_4 Z_101 Z_102 H_8 
Stack 1
Z_103 B_0 C_5 Z_104 B_2 A_7 
Stack 2
J_6 E_5 I_0 C_2 I_5 C_8 
Stack 3
Z_105 F_8 J_0 Z_106 D_9 A_5 
Stack 4
C_0 D_7 Z_107 F_9 G_1 H_1 
Stack 5
Z_108 F_1 J_7 E_8 H_5 
Stack 6
D_2 D_5 E_6 C_7 I_4 
Stack 7
A_1 B_6 G_6 J_2 H_4 
Stack 8
E_3 A_6 I_7 G_9 Z_109 
Stack 9
Z_110 A_4 H_7 D_8 I_6 
Stack 10
E_2 F_10 F_7 G_2 Z_111 
Stack 11
I_1 H_3 H_6 Z_112 Z_113 
Stack 12
D_0 B_7 Z_114 Z_115 B_1 
Stack 13
E_9 J_5 J_4 A_2 Z_116 
Stack 14
G_3 Z_117 F_6 B_5 G_5 
Stack 15
Z_118 Z_119 E_10 C_3 D_3 
Stack 16
A_8 F_5 G_4 Z_120 E_1 
Stack 17
D_10 A_0 G_0 D_4 Z_121 
Stack 18
G_8 F_0 Z_122 D_6 C_6 
Stack 19
E_7 G_7 C_1 I_3 J_1 
Stack 20
C_9 E_4 E_0 I_8 D_1 
Stack 21
I_2 H_2 F_2 F_3 B_4 
Stack 22
J_3 C_4 B_3 A_3 Z_123 
