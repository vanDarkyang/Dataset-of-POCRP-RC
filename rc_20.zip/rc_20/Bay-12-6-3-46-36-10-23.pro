Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_10 Z_100 B_4 Z_101 
Stack 1
B_9 B_7 A_11 A_9 
Stack 2
C_1 A_4 A_5 C_2 
Stack 3
B_5 C_0 C_5 B_3 
Stack 4
Z_102 C_4 Z_103 Z_104 
Stack 5
B_6 B_1 B_12 B_8 
Stack 6
Z_105 A_0 B_10 A_7 
Stack 7
B_2 Z_106 Z_107 Z_108 
Stack 8
C_10 A_8 C_9 B_11 
Stack 9
A_1 C_3 A_3 A_2 
Stack 10
C_6 C_7 Z_109 
Stack 11
B_0 C_8 A_6 
