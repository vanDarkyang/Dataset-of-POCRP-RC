Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 G_8 I_7 Z_101 J_1 E_4 
Stack 1
E_2 I_4 E_1 F_11 Z_102 J_7 
Stack 2
J_3 G_2 F_5 B_1 F_0 Z_103 
Stack 3
D_2 Z_104 B_0 C_4 J_2 G_9 
Stack 4
I_5 E_8 G_3 H_9 Z_105 D_9 
Stack 5
B_2 G_7 Z_106 Z_107 C_6 
Stack 6
Z_108 J_0 C_1 F_4 H_4 
Stack 7
D_6 A_8 H_6 D_8 H_5 
Stack 8
I_3 G_5 J_5 Z_109 J_6 
Stack 9
Z_110 Z_111 A_6 A_4 H_2 
Stack 10
A_3 A_0 H_7 Z_112 A_2 
Stack 11
B_5 G_1 Z_113 E_5 I_6 
Stack 12
Z_114 D_3 C_7 Z_115 C_3 
Stack 13
E_0 I_2 D_1 F_3 G_0 
Stack 14
Z_116 D_5 H_1 J_4 Z_117 
Stack 15
G_6 F_9 Z_118 I_0 D_0 
Stack 16
Z_119 D_4 Z_120 F_1 H_3 
Stack 17
C_2 D_7 F_12 Z_121 E_7 
Stack 18
E_6 F_2 B_6 C_5 B_3 
Stack 19
E_9 E_11 I_1 H_8 A_5 
Stack 20
A_1 C_0 E_3 A_7 F_7 
Stack 21
F_13 F_8 Z_122 F_6 B_4 
Stack 22
G_4 Z_123 F_10 E_10 H_0 
