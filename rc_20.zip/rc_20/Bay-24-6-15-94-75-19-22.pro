Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
C_2 I_1 L_2 M_1 
Stack 1
N_1 K_5 E_0 J_1 
Stack 2
F_6 H_6 H_3 D_2 
Stack 3
B_3 Z_100 H_2 L_1 
Stack 4
C_3 C_0 G_3 Z_101 
Stack 5
Z_102 G_0 Z_103 N_0 
Stack 6
E_2 Z_104 H_5 F_0 
Stack 7
G_4 L_0 O_1 B_1 
Stack 8
G_1 E_4 I_3 Z_105 
Stack 9
G_8 F_1 M_4 B_0 
Stack 10
I_4 J_5 H_0 I_2 
Stack 11
H_7 Z_106 I_5 Z_107 
Stack 12
L_3 J_2 K_3 M_0 
Stack 13
Z_108 Z_109 Z_110 E_5 
Stack 14
Z_111 Z_112 I_0 Z_113 
Stack 15
G_2 A_0 F_4 B_2 
Stack 16
F_2 K_4 C_1 H_8 
Stack 17
M_2 Z_114 J_3 G_7 
Stack 18
D_0 Z_115 F_3 G_6 
Stack 19
F_5 Z_116 H_4 H_1 
Stack 20
E_3 Z_117 J_0 K_0 
Stack 21
Z_118 K_2 G_5 K_1 
Stack 22
M_3 E_1 J_4 
Stack 23
D_1 I_6 O_0 
