Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
G_11 H_6 A_5 G_7 J_7 A_7 
Stack 1
Z_100 J_3 H_4 F_4 Z_101 D_8 
Stack 2
F_0 Z_102 G_3 D_0 I_7 C_4 
Stack 3
C_0 C_6 B_0 I_5 Z_103 J_4 
Stack 4
E_0 D_1 Z_104 Z_105 H_2 C_1 
Stack 5
C_3 A_1 C_10 I_8 F_1 
Stack 6
A_3 D_3 I_3 Z_106 G_4 
Stack 7
Z_107 I_1 J_5 D_2 A_4 
Stack 8
E_1 C_7 Z_108 F_2 Z_109 
Stack 9
H_7 G_5 H_1 I_6 Z_110 
Stack 10
C_5 B_1 C_11 Z_111 Z_112 
Stack 11
E_3 E_5 E_4 G_6 E_2 
Stack 12
Z_113 G_0 Z_114 F_3 Z_115 
Stack 13
J_2 E_8 A_0 F_7 F_8 
Stack 14
C_2 Z_116 H_5 F_6 C_8 
Stack 15
E_9 G_2 D_5 D_4 J_0 
Stack 16
G_10 D_9 Z_117 I_4 E_11 
Stack 17
Z_118 I_9 J_1 I_2 D_6 
Stack 18
Z_119 Z_120 J_8 A_2 H_9 
Stack 19
J_9 E_7 G_9 Z_121 H_8 
Stack 20
G_1 Z_122 B_2 I_0 F_5 
Stack 21
Z_123 J_6 E_10 E_6 C_9 
Stack 22
H_3 A_6 D_7 G_8 H_0 
