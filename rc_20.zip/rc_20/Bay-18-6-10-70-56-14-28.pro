Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
J_1 F_5 D_2 J_4 
Stack 1
E_0 F_6 Z_100 H_2 
Stack 2
Z_101 E_5 I_2 A_4 
Stack 3
G_1 C_3 E_6 B_3 
Stack 4
A_0 I_0 Z_102 G_2 
Stack 5
F_2 J_0 I_1 D_3 
Stack 6
C_0 E_7 Z_103 Z_104 
Stack 7
C_5 C_4 C_2 D_5 
Stack 8
D_0 I_3 E_1 Z_105 
Stack 9
Z_106 E_2 Z_107 J_3 
Stack 10
F_4 F_3 H_3 H_0 
Stack 11
E_3 B_2 Z_108 F_0 
Stack 12
A_3 A_2 Z_109 I_4 
Stack 13
J_2 G_0 C_1 I_5 
Stack 14
Z_110 F_1 D_4 B_0 
Stack 15
Z_111 Z_112 Z_113 H_4 
Stack 16
E_4 G_3 H_1 
Stack 17
A_1 B_1 D_1 
