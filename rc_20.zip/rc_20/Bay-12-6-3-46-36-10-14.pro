Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_12 A_3 A_1 B_3 
Stack 1
C_10 Z_100 Z_101 C_4 
Stack 2
C_11 Z_102 C_3 C_5 
Stack 3
A_4 A_8 C_7 C_9 
Stack 4
B_6 A_0 C_0 A_2 
Stack 5
A_7 C_12 A_5 B_0 
Stack 6
Z_103 Z_104 Z_105 Z_106 
Stack 7
A_10 B_1 C_2 B_2 
Stack 8
C_6 C_1 B_4 Z_107 
Stack 9
B_8 B_9 C_8 A_9 
Stack 10
A_11 Z_108 A_6 
Stack 11
B_7 Z_109 B_5 
