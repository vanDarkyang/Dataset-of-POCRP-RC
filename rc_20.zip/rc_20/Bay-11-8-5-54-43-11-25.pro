Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_1 C_1 D_2 Z_100 D_8 
Stack 1
E_1 Z_101 D_3 D_1 E_5 
Stack 2
Z_102 C_5 Z_103 A_2 D_4 
Stack 3
Z_104 E_0 B_4 B_0 A_3 
Stack 4
C_3 A_4 B_8 C_2 D_6 
Stack 5
Z_105 C_6 A_7 E_3 A_0 
Stack 6
B_2 A_6 E_6 C_0 B_3 
Stack 7
B_1 E_2 Z_106 D_7 Z_107 
Stack 8
C_8 A_5 C_7 B_5 C_4 
Stack 9
B_6 B_7 Z_108 Z_109 D_5 
Stack 10
E_7 Z_110 E_4 D_0 
