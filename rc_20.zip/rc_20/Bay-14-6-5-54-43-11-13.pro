Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_4 Z_100 Z_101 Z_102 
Stack 1
A_1 A_8 E_0 C_1 
Stack 2
A_3 B_8 D_4 D_2 
Stack 3
E_3 Z_103 D_0 C_4 
Stack 4
Z_104 C_9 E_5 C_2 
Stack 5
C_10 B_7 D_6 D_5 
Stack 6
B_5 C_3 C_5 D_3 
Stack 7
Z_105 Z_106 A_2 Z_107 
Stack 8
B_6 B_3 A_5 C_6 
Stack 9
C_7 B_2 A_4 A_0 
Stack 10
C_8 E_2 A_6 B_0 
Stack 11
Z_108 E_6 Z_109 Z_110 
Stack 12
D_1 A_7 E_1 
Stack 13
B_1 B_4 C_0 
