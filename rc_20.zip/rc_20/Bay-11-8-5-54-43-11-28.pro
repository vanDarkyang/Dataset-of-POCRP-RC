Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_2 B_5 E_2 C_8 Z_100 
Stack 1
Z_101 C_0 B_3 Z_102 C_7 
Stack 2
Z_103 D_1 D_4 A_3 C_3 
Stack 3
D_8 E_1 C_5 A_0 A_1 
Stack 4
B_6 Z_104 C_1 Z_105 Z_106 
Stack 5
A_7 Z_107 D_2 D_5 Z_108 
Stack 6
B_4 B_0 D_6 E_3 D_0 
Stack 7
A_4 E_4 Z_109 D_7 C_6 
Stack 8
C_4 C_9 B_2 Z_110 D_3 
Stack 9
E_5 A_5 B_8 A_6 A_2 
Stack 10
B_1 A_8 E_0 B_7 
