Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 B_3 Z_101 A_7 F_5 F_7 
Stack 1
C_0 F_8 G_7 E_8 J_4 G_2 
Stack 2
D_7 Z_102 G_0 C_6 Z_103 A_1 
Stack 3
E_0 C_4 A_3 Z_104 I_0 I_2 
Stack 4
D_3 A_2 A_6 H_3 D_6 E_2 
Stack 5
E_5 D_5 I_10 G_1 C_1 
Stack 6
B_6 B_5 Z_105 Z_106 G_3 
Stack 7
B_1 Z_107 I_1 H_4 Z_108 
Stack 8
Z_109 B_9 I_9 Z_110 F_4 
Stack 9
Z_111 F_3 E_10 H_7 A_4 
Stack 10
E_6 J_0 I_8 D_8 J_1 
Stack 11
E_4 Z_112 Z_113 H_9 Z_114 
Stack 12
F_2 G_6 B_7 J_2 H_6 
Stack 13
D_4 E_7 Z_115 H_10 F_11 
Stack 14
H_2 G_5 J_5 Z_116 D_0 
Stack 15
B_8 A_0 I_5 G_4 H_5 
Stack 16
I_3 B_0 H_8 I_4 F_0 
Stack 17
A_8 B_4 E_1 H_1 F_9 
Stack 18
Z_117 C_7 D_2 Z_118 Z_119 
Stack 19
A_5 I_7 J_6 Z_120 H_0 
Stack 20
D_1 J_3 F_10 C_5 F_6 
Stack 21
C_2 B_2 I_6 Z_121 C_3 
Stack 22
Z_122 F_1 E_3 Z_123 E_9 
