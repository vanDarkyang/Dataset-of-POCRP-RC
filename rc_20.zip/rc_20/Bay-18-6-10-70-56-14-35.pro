Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
J_4 F_4 Z_100 I_2 
Stack 1
C_4 B_0 E_5 H_4 
Stack 2
H_5 D_4 I_4 H_6 
Stack 3
G_6 G_2 I_1 H_1 
Stack 4
Z_101 F_1 A_3 G_5 
Stack 5
E_4 Z_102 G_1 Z_103 
Stack 6
A_2 F_0 A_1 E_3 
Stack 7
E_6 G_0 D_2 F_2 
Stack 8
C_0 Z_104 E_2 E_1 
Stack 9
I_3 Z_105 C_3 D_0 
Stack 10
Z_106 H_3 H_2 J_2 
Stack 11
C_1 G_4 G_3 F_3 
Stack 12
J_0 Z_107 A_4 E_0 
Stack 13
D_3 C_2 E_7 Z_108 
Stack 14
F_6 Z_109 Z_110 I_0 
Stack 15
Z_111 J_3 J_1 D_1 
Stack 16
A_0 Z_112 D_5 
Stack 17
H_0 Z_113 F_5 
