Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_6 B_13 D_0 D_2 
Stack 1
Z_100 A_3 E_7 E_1 
Stack 2
Z_101 A_9 C_0 C_5 
Stack 3
B_9 Z_102 E_11 E_9 
Stack 4
B_10 C_11 E_0 E_4 
Stack 5
B_8 B_1 E_6 Z_103 
Stack 6
C_6 C_13 B_2 Z_104 
Stack 7
A_5 A_4 B_7 D_9 
Stack 8
Z_105 D_6 B_12 E_10 
Stack 9
C_8 E_5 C_2 D_5 
Stack 10
B_11 Z_106 E_3 Z_107 
Stack 11
A_0 Z_108 C_4 Z_109 
Stack 12
E_2 B_0 B_6 C_10 
Stack 13
Z_110 A_1 Z_111 D_1 
Stack 14
C_1 D_4 D_8 Z_112 
Stack 15
A_8 Z_113 C_7 D_3 
Stack 16
B_14 C_9 D_7 D_10 
Stack 17
A_2 D_11 B_3 C_3 
Stack 18
Z_114 B_4 B_5 C_12 
Stack 19
A_7 E_8 Z_115 
