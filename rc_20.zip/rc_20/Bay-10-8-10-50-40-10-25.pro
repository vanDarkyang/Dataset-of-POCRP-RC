Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
G_2 B_2 G_3 J_0 C_0 
Stack 1
I_1 E_3 H_1 E_2 E_1 
Stack 2
D_0 I_0 Z_100 F_1 G_0 
Stack 3
I_2 B_3 F_6 Z_101 A_0 
Stack 4
B_1 C_4 Z_102 E_4 H_2 
Stack 5
A_1 Z_103 F_3 C_3 D_2 
Stack 6
D_1 Z_104 F_2 G_1 F_0 
Stack 7
Z_105 G_4 D_3 H_0 C_1 
Stack 8
H_3 E_0 C_2 F_4 B_0 
Stack 9
Z_106 Z_107 Z_108 Z_109 F_5 
