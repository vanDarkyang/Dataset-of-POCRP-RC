Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
G_3 C_0 A_0 B_1 
Stack 1
E_0 F_0 E_2 Z_100 
Stack 2
A_2 A_1 Z_101 Z_102 
Stack 3
C_1 C_2 E_1 E_4 
Stack 4
G_1 F_4 G_2 F_2 
Stack 5
Z_103 H_1 D_5 J_1 
Stack 6
D_1 H_0 Z_104 Z_105 
Stack 7
Z_106 I_0 H_2 B_2 
Stack 8
D_0 H_4 Z_107 D_2 
Stack 9
G_0 Z_108 G_4 Z_109 
Stack 10
F_3 I_1 B_0 J_2 
Stack 11
D_4 D_3 J_0 
Stack 12
H_3 F_1 E_3 
