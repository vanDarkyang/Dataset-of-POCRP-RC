Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_2 Z_100 J_2 Z_101 
Stack 1
A_3 G_7 G_4 I_3 
Stack 2
G_6 F_1 D_3 B_1 
Stack 3
Z_102 Z_103 Z_104 H_4 
Stack 4
Z_105 D_6 C_4 I_1 
Stack 5
Z_106 H_3 F_4 F_7 
Stack 6
C_1 E_0 G_3 J_0 
Stack 7
H_0 E_1 A_0 A_1 
Stack 8
E_4 E_5 Z_107 F_0 
Stack 9
C_3 Z_108 A_2 H_1 
Stack 10
D_4 D_0 I_0 B_3 
Stack 11
F_6 D_1 G_1 Z_109 
Stack 12
Z_110 Z_111 F_5 C_2 
Stack 13
E_2 F_2 B_2 D_7 
Stack 14
B_0 C_0 D_5 I_2 
Stack 15
J_1 G_2 G_0 Z_112 
Stack 16
F_3 G_5 E_3 
Stack 17
B_4 H_2 Z_113 
