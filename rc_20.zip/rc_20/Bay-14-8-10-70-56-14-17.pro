Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_3 G_1 F_5 D_6 C_2 
Stack 1
A_4 D_0 E_7 C_3 I_3 
Stack 2
E_3 D_4 Z_100 I_2 Z_101 
Stack 3
B_2 Z_102 J_1 D_2 J_2 
Stack 4
H_2 A_0 H_4 D_5 H_0 
Stack 5
F_1 C_0 E_0 A_2 E_2 
Stack 6
Z_103 G_3 H_3 E_1 B_0 
Stack 7
E_6 Z_104 Z_105 J_3 E_5 
Stack 8
Z_106 A_3 B_3 H_5 F_0 
Stack 9
Z_107 J_0 C_1 Z_108 E_4 
Stack 10
Z_109 F_3 B_4 Z_110 F_2 
Stack 11
F_4 F_6 D_1 E_8 G_4 
Stack 12
A_1 H_1 Z_111 B_1 Z_112 
Stack 13
I_0 G_2 Z_113 I_1 G_0 
