Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_0 H_0 C_2 C_1 B_2 
Stack 1
C_0 J_0 F_1 A_2 H_3 
Stack 2
E_0 G_0 Z_100 D_0 F_0 
Stack 3
Z_101 B_1 F_3 D_2 D_3 
Stack 4
G_3 Z_102 F_5 G_2 H_4 
Stack 5
G_1 J_1 E_2 A_0 E_4 
Stack 6
Z_103 E_3 Z_104 H_2 Z_105 
Stack 7
F_2 Z_106 H_1 Z_107 I_1 
Stack 8
E_1 B_3 A_1 Z_108 F_4 
Stack 9
Z_109 C_3 I_0 D_1 I_2 
