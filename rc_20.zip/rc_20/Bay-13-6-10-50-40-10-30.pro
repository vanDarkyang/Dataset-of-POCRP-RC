Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_1 F_1 E_3 J_0 
Stack 1
B_2 J_2 D_2 Z_100 
Stack 2
G_2 Z_101 I_0 F_5 
Stack 3
D_1 C_0 Z_102 Z_103 
Stack 4
F_0 B_3 J_1 Z_104 
Stack 5
C_4 F_4 D_4 E_2 
Stack 6
G_0 E_1 Z_105 D_5 
Stack 7
H_2 H_1 C_3 G_1 
Stack 8
C_2 F_6 Z_106 B_1 
Stack 9
G_3 E_0 A_0 F_3 
Stack 10
B_0 I_1 E_4 Z_107 
Stack 11
Z_108 F_2 H_0 
Stack 12
D_0 D_3 Z_109 
