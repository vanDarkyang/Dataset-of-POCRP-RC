Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
B_1 Z_100 C_10 C_11 C_12 C_5 
Stack 1
A_10 A_3 Z_101 C_8 A_4 C_4 
Stack 2
A_0 E_5 Z_102 A_9 D_6 E_6 
Stack 3
B_10 E_3 C_0 A_8 C_1 E_9 
Stack 4
B_0 B_7 Z_103 E_7 Z_104 
Stack 5
B_13 A_7 Z_105 A_2 Z_106 
Stack 6
A_6 B_2 B_6 D_10 Z_107 
Stack 7
Z_108 E_4 E_1 B_4 Z_109 
Stack 8
D_7 D_5 A_5 E_2 B_11 
Stack 9
Z_110 D_2 D_9 B_9 E_0 
Stack 10
A_1 Z_111 D_1 C_3 D_0 
Stack 11
C_2 B_12 C_6 E_8 Z_112 
Stack 12
B_3 D_11 D_4 Z_113 C_13 
Stack 13
B_5 Z_114 E_10 E_11 C_7 
Stack 14
B_8 Z_115 D_3 D_8 C_9 
