Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
H_3 Z_100 J_0 E_0 I_3 
Stack 1
F_1 Z_101 G_2 C_2 I_2 
Stack 2
Z_102 E_3 F_0 Z_103 C_1 
Stack 3
Z_104 Z_105 H_0 F_5 E_1 
Stack 4
B_0 J_1 Z_106 H_2 D_1 
Stack 5
G_1 B_1 C_0 I_1 F_2 
Stack 6
F_3 D_3 D_2 G_3 G_0 
Stack 7
Z_107 A_1 H_1 E_4 D_0 
Stack 8
Z_108 Z_109 A_0 F_4 J_2 
Stack 9
E_2 E_5 I_0 H_4 G_4 
