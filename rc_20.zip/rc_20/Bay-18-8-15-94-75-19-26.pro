Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 J_1 M_2 Z_101 Z_102 N_2 
Stack 1
A_0 G_3 G_1 B_0 G_7 O_2 
Stack 2
Z_103 H_5 H_1 H_0 D_1 D_0 
Stack 3
F_3 K_0 K_2 F_0 D_3 J_7 
Stack 4
H_2 L_0 J_2 J_3 I_5 
Stack 5
H_6 O_1 G_2 G_4 I_4 
Stack 6
K_4 I_1 Z_104 Z_105 M_4 
Stack 7
Z_106 J_6 D_5 G_6 Z_107 
Stack 8
Z_108 Z_109 E_4 Z_110 Z_111 
Stack 9
O_0 N_0 I_0 Z_112 E_1 
Stack 10
M_0 D_2 H_4 J_0 E_0 
Stack 11
C_0 J_5 M_1 L_2 Z_113 
Stack 12
K_1 B_1 K_3 I_2 L_4 
Stack 13
J_4 G_5 N_1 M_3 Z_114 
Stack 14
L_1 Z_115 F_1 C_1 F_2 
Stack 15
H_3 C_2 Z_116 I_6 D_4 
Stack 16
E_3 L_5 B_2 C_3 Z_117 
Stack 17
Z_118 G_0 I_3 L_3 E_2 
