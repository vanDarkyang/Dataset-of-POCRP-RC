Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 G_2 H_4 B_0 
Stack 1
Z_101 I_3 H_3 A_4 
Stack 2
E_5 E_0 E_4 A_2 
Stack 3
Z_102 D_0 B_4 I_4 
Stack 4
E_1 F_4 D_4 Z_103 
Stack 5
H_2 D_1 E_2 F_2 
Stack 6
B_2 J_2 Z_104 H_1 
Stack 7
B_3 I_1 Z_105 G_5 
Stack 8
G_4 Z_106 Z_107 Z_108 
Stack 9
G_0 F_3 H_5 C_3 
Stack 10
G_6 A_3 F_0 Z_109 
Stack 11
I_2 C_0 Z_110 C_1 
Stack 12
Z_111 J_1 B_1 D_5 
Stack 13
A_1 H_6 E_3 F_1 
Stack 14
G_1 D_3 J_0 C_2 
Stack 15
A_0 Z_112 D_2 E_6 
Stack 16
B_5 Z_113 C_4 
Stack 17
H_0 G_3 I_0 
