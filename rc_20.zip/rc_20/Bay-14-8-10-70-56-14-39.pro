Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 E_4 F_5 Z_101 F_2 
Stack 1
D_3 J_2 H_3 I_2 E_5 
Stack 2
B_2 G_1 B_1 H_1 I_1 
Stack 3
C_5 D_4 Z_102 Z_103 E_0 
Stack 4
D_1 C_3 D_2 Z_104 Z_105 
Stack 5
C_1 Z_106 Z_107 D_0 Z_108 
Stack 6
G_2 A_2 Z_109 I_3 Z_110 
Stack 7
C_2 E_2 J_1 B_3 D_5 
Stack 8
E_7 E_1 Z_111 J_0 Z_112 
Stack 9
F_7 H_2 A_1 C_4 G_3 
Stack 10
B_0 E_6 I_0 D_6 F_6 
Stack 11
F_8 C_0 B_4 G_4 F_0 
Stack 12
G_0 E_3 A_0 F_3 Z_113 
Stack 13
I_4 H_0 F_4 F_1 H_4 
