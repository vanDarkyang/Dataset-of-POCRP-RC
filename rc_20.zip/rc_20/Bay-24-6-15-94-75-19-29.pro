Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 Z_101 C_3 D_1 
Stack 1
G_2 Z_102 Z_103 B_3 
Stack 2
C_0 G_5 C_4 Z_104 
Stack 3
E_2 I_2 D_2 D_3 
Stack 4
G_0 J_4 M_3 L_0 
Stack 5
L_2 M_1 Z_105 J_2 
Stack 6
Z_106 I_3 D_4 O_1 
Stack 7
H_8 L_1 F_1 Z_107 
Stack 8
Z_108 K_2 Z_109 Z_110 
Stack 9
D_0 Z_111 Z_112 J_1 
Stack 10
A_0 K_3 Z_113 O_0 
Stack 11
H_2 F_5 K_0 H_3 
Stack 12
Z_114 E_0 I_4 M_0 
Stack 13
G_4 I_1 G_3 F_4 
Stack 14
H_6 L_3 Z_115 F_7 
Stack 15
F_3 B_2 I_6 C_1 
Stack 16
K_5 M_2 K_1 F_0 
Stack 17
C_2 B_0 J_5 N_0 
Stack 18
Z_116 F_2 J_6 H_4 
Stack 19
H_0 H_1 D_5 E_1 
Stack 20
H_5 I_5 I_0 J_0 
Stack 21
N_2 Z_117 H_7 N_1 
Stack 22
Z_118 F_6 J_3 
Stack 23
G_1 B_1 K_4 
