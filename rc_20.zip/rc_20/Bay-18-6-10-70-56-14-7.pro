Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_2 B_1 F_2 C_3 
Stack 1
D_1 D_3 J_0 B_4 
Stack 2
A_4 Z_100 Z_101 A_3 
Stack 3
E_6 I_1 D_0 I_0 
Stack 4
Z_102 F_4 Z_103 E_3 
Stack 5
I_2 G_3 D_4 E_1 
Stack 6
G_0 G_5 A_1 E_7 
Stack 7
B_2 E_2 H_1 J_1 
Stack 8
Z_104 G_1 Z_105 E_4 
Stack 9
J_2 F_0 C_1 E_0 
Stack 10
G_2 B_3 G_7 J_3 
Stack 11
Z_106 A_2 C_5 E_5 
Stack 12
H_2 C_4 G_4 G_6 
Stack 13
F_1 H_0 A_0 F_6 
Stack 14
Z_107 Z_108 D_5 I_3 
Stack 15
D_2 B_0 Z_109 Z_110 
Stack 16
F_3 Z_111 C_0 
Stack 17
Z_112 F_5 Z_113 
