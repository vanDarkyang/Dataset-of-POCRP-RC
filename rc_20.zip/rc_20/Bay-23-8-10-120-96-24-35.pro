Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
B_9 E_2 J_2 J_6 E_6 I_2 
Stack 1
I_0 E_4 B_6 C_6 G_1 H_7 
Stack 2
D_3 J_3 E_7 C_0 F_0 G_5 
Stack 3
D_1 D_7 A_3 C_8 J_4 H_6 
Stack 4
Z_100 E_10 J_1 F_5 B_2 A_0 
Stack 5
E_5 Z_101 Z_102 C_4 Z_103 
Stack 6
D_8 I_3 F_7 G_3 F_8 
Stack 7
F_10 G_7 E_1 Z_104 H_3 
Stack 8
B_7 A_1 Z_105 I_5 Z_106 
Stack 9
B_1 J_7 Z_107 B_5 B_8 
Stack 10
F_6 C_7 F_3 H_4 A_7 
Stack 11
H_2 D_0 D_6 Z_108 Z_109 
Stack 12
E_9 D_5 Z_110 E_3 H_1 
Stack 13
F_2 J_0 G_2 G_0 I_6 
Stack 14
C_1 H_5 D_2 C_9 Z_111 
Stack 15
Z_112 E_8 D_10 Z_113 Z_114 
Stack 16
A_5 B_4 Z_115 G_4 A_4 
Stack 17
Z_116 Z_117 J_8 Z_118 B_3 
Stack 18
C_2 C_5 I_7 Z_119 C_3 
Stack 19
H_0 I_1 F_9 D_9 D_4 
Stack 20
I_4 E_11 A_2 F_4 B_0 
Stack 21
Z_120 Z_121 Z_122 D_11 Z_123 
Stack 22
A_6 J_5 E_0 F_1 G_6 
