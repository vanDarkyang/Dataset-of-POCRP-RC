Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_2 D_10 A_9 D_8 C_1 A_7 
Stack 1
A_8 B_11 Z_100 A_4 E_1 Z_101 
Stack 2
D_2 D_9 D_11 A_0 B_0 Z_102 
Stack 3
Z_103 C_12 C_8 Z_104 C_7 E_4 
Stack 4
D_3 B_12 E_12 E_6 B_6 
Stack 5
D_1 B_9 C_0 A_2 E_11 
Stack 6
Z_105 A_5 C_11 Z_106 Z_107 
Stack 7
C_9 D_7 E_2 D_6 Z_108 
Stack 8
B_4 A_1 E_0 C_5 E_10 
Stack 9
Z_109 B_1 Z_110 C_10 C_6 
Stack 10
A_6 Z_111 B_8 D_0 B_7 
Stack 11
E_8 Z_112 Z_113 D_5 E_5 
Stack 12
B_5 E_7 D_4 B_10 B_13 
Stack 13
E_3 Z_114 C_13 C_4 B_3 
Stack 14
A_3 E_9 Z_115 C_3 B_2 
