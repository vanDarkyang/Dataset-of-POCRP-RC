Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_3 A_9 B_1 Z_100 
Stack 1
C_12 C_11 B_5 Z_101 
Stack 2
C_3 Z_102 Z_103 B_0 
Stack 3
A_7 B_2 B_6 A_11 
Stack 4
Z_104 A_2 C_10 B_9 
Stack 5
A_12 Z_105 Z_106 A_8 
Stack 6
A_6 Z_107 A_3 C_7 
Stack 7
C_1 A_10 A_4 C_8 
Stack 8
B_7 Z_108 C_5 B_8 
Stack 9
B_4 C_4 C_6 A_1 
Stack 10
C_9 A_0 Z_109 
Stack 11
C_2 C_0 A_5 
