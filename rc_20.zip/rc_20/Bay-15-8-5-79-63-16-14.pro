Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_8 C_12 E_3 B_4 Z_100 A_10 
Stack 1
C_3 B_11 Z_101 B_13 A_6 B_12 
Stack 2
E_4 B_10 C_1 C_7 E_1 E_5 
Stack 3
B_2 A_0 C_6 C_11 Z_102 A_11 
Stack 4
D_10 D_11 B_0 A_5 B_5 
Stack 5
C_5 C_0 D_4 E_0 Z_103 
Stack 6
A_4 B_8 A_7 A_9 D_6 
Stack 7
C_2 C_4 Z_104 A_1 D_0 
Stack 8
D_1 E_7 E_2 A_2 C_14 
Stack 9
Z_105 B_1 Z_106 C_9 D_9 
Stack 10
D_8 C_8 D_2 Z_107 Z_108 
Stack 11
B_7 A_13 C_13 B_6 Z_109 
Stack 12
A_3 C_10 B_9 Z_110 Z_111 
Stack 13
B_3 E_6 Z_112 A_12 Z_113 
Stack 14
D_5 Z_114 Z_115 D_3 D_7 
