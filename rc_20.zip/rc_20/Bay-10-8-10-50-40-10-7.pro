Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_4 Z_100 G_0 H_2 J_0 
Stack 1
E_2 E_5 D_0 Z_101 E_1 
Stack 2
G_1 F_0 D_5 B_1 D_2 
Stack 3
G_2 Z_102 C_1 G_4 H_0 
Stack 4
E_0 Z_103 A_0 C_3 A_1 
Stack 5
Z_104 C_4 Z_105 J_2 H_3 
Stack 6
I_1 A_2 B_0 Z_106 E_3 
Stack 7
I_0 D_1 H_4 Z_107 Z_108 
Stack 8
Z_109 G_3 H_1 D_3 C_0 
Stack 9
D_4 B_2 C_2 I_2 J_1 
