Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 D_6 A_6 E_4 
Stack 1
Z_101 B_2 C_6 C_7 
Stack 2
Z_102 A_2 E_2 E_6 
Stack 3
A_5 C_3 A_4 E_5 
Stack 4
Z_103 Z_104 D_4 B_6 
Stack 5
D_0 D_7 E_8 E_3 
Stack 6
C_5 C_0 B_8 B_1 
Stack 7
Z_105 E_0 D_5 D_3 
Stack 8
C_1 Z_106 E_1 D_2 
Stack 9
A_7 A_8 Z_107 B_5 
Stack 10
C_2 C_4 A_1 B_4 
Stack 11
A_3 Z_108 B_3 E_7 
Stack 12
D_1 B_7 Z_109 
Stack 13
B_0 A_0 Z_110 
