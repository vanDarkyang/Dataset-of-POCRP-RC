Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
K_1 I_5 K_2 E_0 Z_100 E_1 
Stack 1
I_0 Z_101 Z_102 I_4 G_6 D_2 
Stack 2
F_0 K_3 H_7 L_1 H_1 C_3 
Stack 3
Z_103 M_3 K_4 M_1 L_4 Z_104 
Stack 4
H_0 J_4 A_0 B_1 N_0 
Stack 5
Z_105 D_3 N_1 M_2 G_4 
Stack 6
Z_106 F_3 H_3 Z_107 A_1 
Stack 7
E_4 H_5 D_4 Z_108 J_0 
Stack 8
Z_109 Z_110 H_2 J_5 Z_111 
Stack 9
L_2 I_1 J_3 E_3 M_0 
Stack 10
C_1 G_0 I_3 G_2 O_0 
Stack 11
H_4 Z_112 D_5 I_2 D_0 
Stack 12
D_1 F_4 F_2 Z_113 H_6 
Stack 13
Z_114 C_0 G_1 J_1 N_3 
Stack 14
Z_115 L_3 G_3 K_0 L_5 
Stack 15
N_2 H_8 A_2 I_6 L_0 
Stack 16
B_0 Z_116 G_5 Z_117 E_2 
Stack 17
F_5 Z_118 J_2 F_1 C_2 
