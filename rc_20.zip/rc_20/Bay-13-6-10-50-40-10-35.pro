Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_6 D_2 F_2 B_0 
Stack 1
D_3 H_3 Z_100 A_0 
Stack 2
E_6 Z_101 Z_102 Z_103 
Stack 3
J_2 F_3 Z_104 D_5 
Stack 4
Z_105 B_1 F_0 I_1 
Stack 5
C_1 E_2 I_2 G_0 
Stack 6
E_4 E_5 H_0 F_4 
Stack 7
D_1 D_4 J_1 Z_106 
Stack 8
H_2 C_0 H_1 D_0 
Stack 9
C_2 Z_107 F_5 G_1 
Stack 10
J_0 I_0 E_0 Z_108 
Stack 11
F_1 E_1 Z_109 
Stack 12
G_2 E_3 A_1 
