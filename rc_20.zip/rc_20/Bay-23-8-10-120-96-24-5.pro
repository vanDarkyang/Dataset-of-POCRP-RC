Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
J_5 Z_100 H_3 A_3 Z_101 D_6 
Stack 1
D_3 A_7 C_4 G_4 D_1 F_7 
Stack 2
H_9 J_4 J_0 Z_102 E_8 C_2 
Stack 3
G_9 F_11 F_9 I_5 B_1 B_5 
Stack 4
Z_103 C_6 Z_104 B_3 C_8 F_4 
Stack 5
F_0 E_4 E_6 E_9 B_0 
Stack 6
Z_105 I_4 H_4 C_7 Z_106 
Stack 7
J_7 Z_107 I_3 F_12 G_2 
Stack 8
D_4 A_1 E_10 Z_108 Z_109 
Stack 9
I_7 I_1 A_6 H_5 B_4 
Stack 10
D_8 G_1 B_2 Z_110 E_0 
Stack 11
D_5 H_6 I_0 J_2 D_7 
Stack 12
C_1 Z_111 A_0 E_2 F_1 
Stack 13
J_1 G_0 Z_112 G_7 J_3 
Stack 14
Z_113 H_8 Z_114 I_2 A_5 
Stack 15
C_3 D_9 B_6 F_5 C_0 
Stack 16
Z_115 A_4 G_6 C_5 H_7 
Stack 17
G_3 Z_116 Z_117 H_1 I_6 
Stack 18
D_0 J_6 F_2 Z_118 H_2 
Stack 19
G_8 F_10 A_2 I_8 F_3 
Stack 20
Z_119 E_3 F_6 E_7 H_0 
Stack 21
D_2 E_1 F_8 E_5 H_10 
Stack 22
Z_120 Z_121 G_5 Z_122 Z_123 
