Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 C_7 E_0 E_2 
Stack 1
C_6 C_14 D_3 E_4 
Stack 2
B_4 E_9 C_3 Z_101 
Stack 3
C_1 B_10 A_7 B_8 
Stack 4
Z_102 D_2 D_11 E_3 
Stack 5
B_11 B_7 Z_103 Z_104 
Stack 6
A_0 E_7 C_8 B_5 
Stack 7
Z_105 C_2 Z_106 C_11 
Stack 8
Z_107 C_13 C_10 E_6 
Stack 9
E_8 Z_108 Z_109 E_5 
Stack 10
B_0 A_6 E_13 E_10 
Stack 11
D_10 E_11 A_3 A_2 
Stack 12
Z_110 Z_111 B_2 E_1 
Stack 13
D_0 C_9 B_1 A_1 
Stack 14
Z_112 B_9 B_6 Z_113 
Stack 15
A_8 E_12 C_5 A_5 
Stack 16
D_6 Z_114 D_1 D_8 
Stack 17
Z_115 D_9 C_0 C_4 
Stack 18
B_3 D_4 D_7 C_12 
Stack 19
D_5 A_4 B_12 
