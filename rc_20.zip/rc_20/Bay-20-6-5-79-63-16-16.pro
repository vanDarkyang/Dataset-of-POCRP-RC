Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
B_9 C_14 A_0 B_2 
Stack 1
Z_100 C_7 Z_101 D_10 
Stack 2
A_6 E_1 E_11 D_1 
Stack 3
C_12 C_3 E_9 E_5 
Stack 4
A_9 E_2 B_4 C_11 
Stack 5
E_4 C_0 B_11 A_2 
Stack 6
B_7 C_2 C_8 D_12 
Stack 7
D_6 Z_102 D_4 Z_103 
Stack 8
B_1 Z_104 C_1 Z_105 
Stack 9
E_7 C_10 Z_106 Z_107 
Stack 10
A_4 D_2 C_6 B_10 
Stack 11
C_9 A_7 C_4 B_6 
Stack 12
Z_108 A_5 D_8 B_3 
Stack 13
E_3 Z_109 D_13 Z_110 
Stack 14
Z_111 D_9 C_5 D_0 
Stack 15
E_10 A_3 Z_112 B_8 
Stack 16
D_7 Z_113 D_3 B_0 
Stack 17
Z_114 D_5 E_0 D_11 
Stack 18
B_5 A_1 E_6 Z_115 
Stack 19
E_8 C_13 A_8 
