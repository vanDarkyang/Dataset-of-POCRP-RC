Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 D_0 C_2 C_0 D_5 G_2 
Stack 1
E_7 C_5 I_7 Z_101 B_5 Z_102 
Stack 2
Z_103 F_9 E_6 H_5 D_7 D_2 
Stack 3
A_6 F_6 Z_104 Z_105 I_4 B_4 
Stack 4
I_6 Z_106 H_0 D_8 F_8 E_4 
Stack 5
C_3 Z_107 J_4 B_0 I_2 
Stack 6
Z_108 C_4 F_11 H_1 G_5 
Stack 7
Z_109 D_3 B_7 E_8 E_1 
Stack 8
H_7 E_3 J_1 I_0 Z_110 
Stack 9
I_1 F_0 J_5 Z_111 E_0 
Stack 10
F_1 B_6 A_3 G_7 C_1 
Stack 11
C_7 B_9 F_5 A_8 E_10 
Stack 12
H_6 F_2 Z_112 Z_113 A_7 
Stack 13
G_3 D_1 I_5 C_6 Z_114 
Stack 14
Z_115 Z_116 B_8 D_10 F_3 
Stack 15
Z_117 A_0 G_1 A_1 D_9 
Stack 16
Z_118 H_4 H_2 Z_119 A_2 
Stack 17
F_7 G_0 B_3 F_4 G_10 
Stack 18
G_6 H_3 Z_120 J_0 I_3 
Stack 19
Z_121 J_3 J_2 Z_122 Z_123 
Stack 20
E_2 G_4 E_9 J_6 A_4 
Stack 21
F_10 B_1 E_5 G_9 D_6 
Stack 22
G_8 A_5 A_9 B_2 D_4 
