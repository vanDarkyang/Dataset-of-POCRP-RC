Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 A_0 I_1 F_2 
Stack 1
E_2 D_2 I_0 F_1 
Stack 2
D_1 F_4 F_0 H_0 
Stack 3
Z_101 J_0 C_2 D_3 
Stack 4
D_5 A_1 I_2 C_4 
Stack 5
G_4 Z_102 E_1 E_5 
Stack 6
Z_103 I_3 D_4 H_2 
Stack 7
B_0 D_0 G_2 C_1 
Stack 8
Z_104 F_3 B_1 E_4 
Stack 9
B_2 Z_105 Z_106 E_0 
Stack 10
C_3 G_0 E_3 Z_107 
Stack 11
H_1 C_0 Z_108 
Stack 12
Z_109 G_1 G_3 
