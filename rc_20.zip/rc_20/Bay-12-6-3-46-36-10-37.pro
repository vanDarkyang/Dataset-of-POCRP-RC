Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 C_8 Z_101 Z_102 
Stack 1
B_3 A_4 B_1 C_0 
Stack 2
C_12 Z_103 C_7 Z_104 
Stack 3
A_0 A_1 B_6 C_10 
Stack 4
A_7 B_2 A_6 C_2 
Stack 5
A_2 B_4 A_9 Z_105 
Stack 6
C_4 A_11 B_0 C_11 
Stack 7
C_6 B_8 B_7 C_3 
Stack 8
C_1 Z_106 Z_107 Z_108 
Stack 9
B_5 B_10 B_9 C_5 
Stack 10
C_9 A_5 A_10 
Stack 11
A_8 Z_109 A_3 
