Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_1 D_7 D_6 C_10 B_2 Z_100 
Stack 1
D_1 A_10 B_11 B_5 Z_101 A_7 
Stack 2
E_10 E_11 A_3 B_3 C_2 C_12 
Stack 3
D_3 D_2 Z_102 E_5 Z_103 B_12 
Stack 4
B_8 D_5 E_3 Z_104 A_5 
Stack 5
B_4 C_11 C_9 C_5 A_4 
Stack 6
E_8 Z_105 C_4 B_6 Z_106 
Stack 7
B_10 C_8 C_6 Z_107 Z_108 
Stack 8
Z_109 E_2 D_10 C_1 Z_110 
Stack 9
Z_111 D_0 A_2 E_4 C_7 
Stack 10
B_0 Z_112 E_7 A_11 A_6 
Stack 11
D_9 D_4 Z_113 A_8 A_0 
Stack 12
Z_114 E_1 E_6 C_3 C_0 
Stack 13
C_13 Z_115 E_9 E_0 B_7 
Stack 14
B_9 D_8 B_1 A_9 E_12 
