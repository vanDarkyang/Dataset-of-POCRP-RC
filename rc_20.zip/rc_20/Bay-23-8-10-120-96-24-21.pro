Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
B_2 Z_100 Z_101 A_5 Z_102 F_1 
Stack 1
H_2 E_8 J_7 G_10 Z_103 C_0 
Stack 2
Z_104 B_5 J_3 Z_105 C_8 C_6 
Stack 3
Z_106 C_2 D_5 I_5 G_3 D_4 
Stack 4
Z_107 Z_108 I_6 Z_109 J_1 Z_110 
Stack 5
C_7 G_8 F_9 B_8 Z_111 
Stack 6
Z_112 E_4 G_7 Z_113 A_0 
Stack 7
I_3 D_8 B_1 A_2 B_6 
Stack 8
Z_114 D_1 Z_115 J_6 I_4 
Stack 9
B_9 F_6 B_7 E_5 H_0 
Stack 10
I_2 A_1 D_9 E_3 E_1 
Stack 11
G_9 D_3 Z_116 I_0 Z_117 
Stack 12
Z_118 G_4 C_5 D_0 G_1 
Stack 13
F_0 C_1 Z_119 H_8 G_5 
Stack 14
J_4 H_3 I_1 J_5 Z_120 
Stack 15
D_6 Z_121 F_5 I_7 A_4 
Stack 16
E_2 G_6 E_0 Z_122 G_0 
Stack 17
D_10 E_7 F_7 D_12 E_6 
Stack 18
H_4 H_7 H_6 B_3 C_9 
Stack 19
C_3 F_2 A_3 A_6 H_1 
Stack 20
C_4 G_2 J_2 G_11 B_4 
Stack 21
B_0 D_11 H_5 F_3 D_2 
Stack 22
D_7 F_8 J_0 Z_123 F_4 
