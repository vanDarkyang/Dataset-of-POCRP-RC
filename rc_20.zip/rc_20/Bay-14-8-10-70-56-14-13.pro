Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
G_5 G_3 D_0 I_3 F_1 
Stack 1
B_0 F_5 J_2 H_3 E_0 
Stack 2
B_2 G_6 G_0 J_1 I_2 
Stack 3
Z_100 E_1 Z_101 I_1 I_5 
Stack 4
Z_102 Z_103 G_1 J_0 B_3 
Stack 5
D_4 H_4 Z_104 C_0 D_2 
Stack 6
E_3 Z_105 Z_106 A_0 A_2 
Stack 7
H_0 G_7 J_3 I_0 F_2 
Stack 8
F_0 H_1 F_4 G_4 A_3 
Stack 9
H_5 E_4 D_5 Z_107 Z_108 
Stack 10
A_1 C_1 Z_109 I_4 G_2 
Stack 11
Z_110 Z_111 Z_112 E_2 H_2 
Stack 12
D_1 E_5 F_3 Z_113 C_3 
Stack 13
H_6 D_6 D_3 C_2 B_1 
