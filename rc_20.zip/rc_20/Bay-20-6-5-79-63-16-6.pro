Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_2 Z_100 C_13 Z_101 
Stack 1
B_6 E_2 A_1 Z_102 
Stack 2
A_4 B_11 A_2 C_5 
Stack 3
C_6 C_0 Z_103 B_0 
Stack 4
B_2 A_13 B_14 C_8 
Stack 5
A_9 D_5 A_0 E_9 
Stack 6
D_9 C_7 B_7 A_12 
Stack 7
Z_104 Z_105 D_6 B_10 
Stack 8
B_3 Z_106 A_6 B_8 
Stack 9
Z_107 C_3 A_7 C_4 
Stack 10
A_3 E_7 D_7 E_4 
Stack 11
E_5 D_2 D_3 C_10 
Stack 12
D_1 Z_108 D_8 B_1 
Stack 13
E_3 Z_109 E_0 D_0 
Stack 14
B_13 A_5 E_1 B_5 
Stack 15
E_8 C_9 A_8 Z_110 
Stack 16
A_10 C_11 Z_111 Z_112 
Stack 17
C_1 Z_113 Z_114 A_11 
Stack 18
C_12 B_9 B_12 D_4 
Stack 19
B_4 Z_115 E_6 
