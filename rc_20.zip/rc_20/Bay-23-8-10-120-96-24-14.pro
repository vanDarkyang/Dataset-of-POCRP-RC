Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_0 Z_100 E_9 F_0 Z_101 B_1 
Stack 1
D_6 J_7 C_4 Z_102 J_5 Z_103 
Stack 2
Z_104 C_7 F_5 H_4 I_3 Z_105 
Stack 3
Z_106 I_4 Z_107 F_11 Z_108 G_10 
Stack 4
Z_109 G_8 I_1 Z_110 F_4 I_2 
Stack 5
D_7 E_7 Z_111 A_8 H_5 
Stack 6
H_2 J_2 Z_112 Z_113 D_5 
Stack 7
F_12 B_3 D_0 G_0 I_6 
Stack 8
G_9 C_6 G_1 F_2 I_8 
Stack 9
Z_114 G_4 Z_115 H_6 Z_116 
Stack 10
D_4 J_6 H_7 F_7 J_3 
Stack 11
F_8 F_3 F_6 E_2 B_6 
Stack 12
E_3 Z_117 B_4 B_2 C_8 
Stack 13
I_5 H_9 G_5 I_0 A_2 
Stack 14
F_1 D_3 A_4 G_7 A_0 
Stack 15
Z_118 A_1 E_0 E_6 E_8 
Stack 16
Z_119 E_5 C_2 J_4 H_0 
Stack 17
D_1 C_3 A_7 D_2 Z_120 
Stack 18
B_0 Z_121 G_2 I_7 B_5 
Stack 19
H_1 A_6 F_10 H_3 A_3 
Stack 20
C_1 J_1 E_4 G_6 F_9 
Stack 21
C_5 B_7 H_8 A_5 G_3 
Stack 22
E_1 Z_122 J_0 J_8 Z_123 
