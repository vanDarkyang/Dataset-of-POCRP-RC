Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
N_0 F_4 G_1 J_0 Z_100 K_3 
Stack 1
F_2 E_1 H_4 Z_101 A_1 O_2 
Stack 2
I_1 I_0 D_1 Z_102 J_3 M_3 
Stack 3
E_5 G_0 F_5 D_2 C_2 Z_103 
Stack 4
H_3 Z_104 H_0 H_6 J_5 
Stack 5
B_2 Z_105 D_3 A_0 H_7 
Stack 6
J_6 Z_106 G_4 J_4 K_0 
Stack 7
C_1 D_0 L_1 J_1 F_0 
Stack 8
Z_107 Z_108 Z_109 E_6 M_0 
Stack 9
D_4 Z_110 F_3 I_3 C_3 
Stack 10
A_2 G_2 Z_111 L_0 B_3 
Stack 11
B_1 Z_112 B_0 Z_113 G_3 
Stack 12
C_0 E_3 Z_114 Z_115 Z_116 
Stack 13
M_1 I_4 K_1 J_7 Z_117 
Stack 14
I_2 M_2 E_2 E_4 K_2 
Stack 15
G_6 H_2 E_0 H_8 G_5 
Stack 16
F_1 G_7 J_2 H_1 N_1 
Stack 17
H_5 L_2 O_1 Z_118 O_0 
