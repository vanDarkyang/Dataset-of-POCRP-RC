Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
H_3 F_0 Z_100 D_2 D_1 
Stack 1
F_4 E_1 H_0 G_1 Z_101 
Stack 2
G_2 H_2 F_2 B_2 I_0 
Stack 3
C_0 E_4 Z_102 G_4 E_5 
Stack 4
A_0 Z_103 J_1 F_3 G_3 
Stack 5
B_1 D_3 G_0 I_2 Z_104 
Stack 6
Z_105 J_0 E_3 G_5 D_0 
Stack 7
C_1 Z_106 H_1 C_3 F_1 
Stack 8
Z_107 I_1 B_0 C_2 Z_108 
Stack 9
D_4 E_2 H_4 E_0 Z_109 
