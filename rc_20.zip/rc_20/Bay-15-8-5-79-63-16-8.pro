Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_10 C_0 Z_100 E_2 B_5 B_0 
Stack 1
B_1 C_8 E_5 E_10 C_5 D_10 
Stack 2
A_3 B_9 Z_101 E_8 A_11 E_9 
Stack 3
D_7 C_2 C_3 A_10 A_7 C_14 
Stack 4
A_9 D_11 B_4 A_13 D_9 
Stack 5
Z_102 D_2 Z_103 Z_104 D_5 
Stack 6
C_6 D_6 B_2 A_5 C_1 
Stack 7
B_6 A_12 C_9 E_1 Z_105 
Stack 8
D_0 D_3 Z_106 A_6 C_7 
Stack 9
B_3 Z_107 C_11 Z_108 D_1 
Stack 10
Z_109 D_8 A_4 E_6 C_13 
Stack 11
E_0 E_7 B_7 C_12 A_0 
Stack 12
A_8 D_4 Z_110 E_3 Z_111 
Stack 13
Z_112 Z_113 A_1 Z_114 E_11 
Stack 14
B_8 C_4 Z_115 E_4 A_2 
