Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
D_2 E_2 I_6 H_5 N_3 K_4 
Stack 1
C_4 M_3 F_1 O_1 Z_100 O_4 
Stack 2
K_3 L_3 F_5 G_6 I_8 L_2 
Stack 3
C_3 F_6 Z_101 I_1 Z_102 F_0 
Stack 4
K_1 H_2 E_0 A_3 A_0 
Stack 5
H_3 I_7 E_5 Z_103 Z_104 
Stack 6
J_4 L_5 G_2 F_9 Z_105 
Stack 7
K_0 N_0 I_0 A_1 Z_106 
Stack 8
D_1 Z_107 Z_108 O_3 I_2 
Stack 9
L_4 G_3 A_2 K_2 Z_109 
Stack 10
G_7 J_0 H_0 I_3 M_0 
Stack 11
C_5 Z_110 M_6 G_1 L_1 
Stack 12
J_1 K_6 J_5 O_0 D_5 
Stack 13
Z_111 N_4 M_5 M_1 F_4 
Stack 14
Z_112 J_7 G_8 M_4 F_8 
Stack 15
Z_113 Z_114 H_7 D_0 Z_115 
Stack 16
J_6 H_6 H_4 D_3 J_3 
Stack 17
M_2 E_1 N_1 Z_116 J_2 
Stack 18
H_1 D_4 Z_117 Z_118 I_4 
Stack 19
B_0 E_3 I_5 A_4 Z_119 
Stack 20
E_4 Z_120 Z_121 F_3 G_0 
Stack 21
G_4 Z_122 O_2 G_5 C_2 
Stack 22
L_0 Z_123 K_5 Z_124 C_1 
Stack 23
C_0 B_1 F_2 F_7 N_2 
