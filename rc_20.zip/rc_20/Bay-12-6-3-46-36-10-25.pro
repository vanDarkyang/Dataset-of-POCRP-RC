Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 A_4 Z_101 Z_102 
Stack 1
A_1 B_2 C_9 Z_103 
Stack 2
A_10 Z_104 B_11 B_9 
Stack 3
C_0 B_10 C_8 C_1 
Stack 4
B_12 B_13 B_3 Z_105 
Stack 5
C_6 B_4 A_0 B_7 
Stack 6
C_2 A_6 C_3 A_2 
Stack 7
C_7 B_6 B_1 Z_106 
Stack 8
B_5 A_8 C_4 C_5 
Stack 9
B_0 A_9 B_8 Z_107 
Stack 10
Z_108 B_14 A_3 
Stack 11
Z_109 A_7 A_5 
