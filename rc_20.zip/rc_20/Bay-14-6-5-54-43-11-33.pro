Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_6 D_7 C_6 B_6 
Stack 1
Z_100 D_2 Z_101 B_1 
Stack 2
D_1 C_1 A_0 E_2 
Stack 3
D_3 E_5 D_5 B_5 
Stack 4
C_2 D_6 C_5 A_5 
Stack 5
A_8 B_4 E_7 E_3 
Stack 6
D_0 A_6 A_1 Z_102 
Stack 7
Z_103 A_4 B_3 A_7 
Stack 8
B_7 C_4 C_0 B_2 
Stack 9
B_0 A_3 D_9 Z_104 
Stack 10
Z_105 D_8 E_1 D_10 
Stack 11
Z_106 Z_107 D_4 E_0 
Stack 12
E_4 A_2 C_3 
Stack 13
Z_108 Z_109 Z_110 
