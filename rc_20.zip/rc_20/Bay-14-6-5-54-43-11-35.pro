Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_0 D_4 Z_100 E_1 
Stack 1
A_7 C_5 B_2 Z_101 
Stack 2
Z_102 A_5 B_8 C_0 
Stack 3
C_4 Z_103 E_4 A_1 
Stack 4
E_5 Z_104 C_2 C_6 
Stack 5
D_1 D_0 D_7 D_3 
Stack 6
A_6 E_3 B_0 B_1 
Stack 7
B_7 A_0 Z_105 A_2 
Stack 8
E_2 Z_106 B_5 D_6 
Stack 9
Z_107 C_7 E_6 D_8 
Stack 10
A_3 Z_108 Z_109 E_8 
Stack 11
B_3 B_4 E_7 Z_110 
Stack 12
A_4 D_2 D_5 
Stack 13
B_6 C_1 C_3 
