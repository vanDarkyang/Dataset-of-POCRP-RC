Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
I_2 Z_100 B_2 H_1 
Stack 1
D_2 G_3 Z_101 F_6 
Stack 2
E_1 E_0 F_2 Z_102 
Stack 3
D_4 B_0 E_3 H_4 
Stack 4
Z_103 B_1 A_2 I_3 
Stack 5
C_2 F_7 Z_104 I_0 
Stack 6
D_7 I_1 C_4 H_2 
Stack 7
D_0 Z_105 I_4 D_5 
Stack 8
H_3 H_0 E_5 D_3 
Stack 9
H_6 G_0 Z_106 E_2 
Stack 10
G_4 D_1 E_6 B_3 
Stack 11
Z_107 G_5 J_0 A_0 
Stack 12
G_1 D_6 J_1 C_0 
Stack 13
F_3 C_3 G_2 F_5 
Stack 14
Z_108 Z_109 Z_110 F_4 
Stack 15
H_5 Z_111 J_2 Z_112 
Stack 16
Z_113 A_1 F_0 
Stack 17
F_1 C_1 E_4 
