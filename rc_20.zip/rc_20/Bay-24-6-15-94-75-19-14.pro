Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
C_3 F_0 Z_100 Z_101 
Stack 1
Z_102 H_4 D_1 I_7 
Stack 2
J_1 L_2 M_2 L_1 
Stack 3
E_4 H_1 Z_103 H_3 
Stack 4
K_4 I_1 N_1 D_2 
Stack 5
Z_104 Z_105 L_3 K_2 
Stack 6
G_7 M_0 G_0 Z_106 
Stack 7
Z_107 E_5 K_3 E_0 
Stack 8
D_0 I_6 J_2 I_5 
Stack 9
Z_108 B_0 F_3 F_1 
Stack 10
K_5 C_2 G_3 Z_109 
Stack 11
O_0 Z_110 H_7 F_2 
Stack 12
H_8 M_3 J_4 H_5 
Stack 13
H_0 I_3 C_1 Z_111 
Stack 14
Z_112 N_2 I_4 E_3 
Stack 15
E_2 J_0 Z_113 I_2 
Stack 16
H_2 C_4 O_1 Z_114 
Stack 17
G_5 C_0 Z_115 A_2 
Stack 18
Z_116 K_1 H_6 F_5 
Stack 19
M_1 I_0 J_3 O_2 
Stack 20
G_4 A_1 Z_117 M_4 
Stack 21
L_0 Z_118 G_6 A_0 
Stack 22
G_1 K_0 N_0 
Stack 23
E_1 F_4 G_2 
