Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 Z_101 H_3 Z_102 H_2 
Stack 1
B_1 I_1 Z_103 D_4 F_4 
Stack 2
G_2 D_0 Z_104 E_1 G_3 
Stack 3
D_1 F_0 I_2 C_2 H_0 
Stack 4
Z_105 J_1 F_1 G_0 E_3 
Stack 5
C_3 I_0 D_3 A_0 Z_106 
Stack 6
G_1 C_0 E_4 E_5 Z_107 
Stack 7
H_4 Z_108 D_2 H_1 B_0 
Stack 8
C_1 F_3 Z_109 A_2 F_2 
Stack 9
G_4 E_2 A_1 J_0 E_0 
