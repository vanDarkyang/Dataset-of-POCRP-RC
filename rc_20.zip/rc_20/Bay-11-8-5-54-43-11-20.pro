Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_7 Z_100 Z_101 A_5 Z_102 
Stack 1
D_10 D_3 B_8 E_1 B_9 
Stack 2
Z_103 C_6 A_1 Z_104 B_4 
Stack 3
A_8 C_0 A_3 A_2 E_2 
Stack 4
C_3 B_0 Z_105 Z_106 E_3 
Stack 5
C_5 B_3 B_6 E_5 B_7 
Stack 6
E_0 Z_107 D_2 D_4 D_6 
Stack 7
D_1 B_2 D_0 A_0 Z_108 
Stack 8
D_5 E_4 B_5 Z_109 C_2 
Stack 9
A_4 C_1 D_9 C_4 D_8 
Stack 10
A_6 Z_110 D_7 B_1 
