Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
H_0 D_8 D_5 Z_100 Z_101 Z_102 
Stack 1
Z_103 G_6 E_8 F_6 I_7 Z_104 
Stack 2
H_6 G_7 A_2 E_3 E_1 F_9 
Stack 3
E_9 Z_105 I_3 A_5 F_7 I_1 
Stack 4
I_4 Z_106 G_4 F_1 J_4 F_5 
Stack 5
Z_107 I_2 A_3 D_3 D_4 
Stack 6
A_6 E_2 I_6 J_2 J_6 
Stack 7
Z_108 I_0 F_8 Z_109 H_10 
Stack 8
A_4 A_0 Z_110 C_4 G_1 
Stack 9
G_8 H_5 Z_111 E_5 Z_112 
Stack 10
H_7 Z_113 F_0 Z_114 G_5 
Stack 11
A_1 C_0 A_7 J_1 F_11 
Stack 12
E_7 Z_115 B_6 Z_116 D_2 
Stack 13
D_6 Z_117 A_8 B_4 Z_118 
Stack 14
F_3 H_3 H_2 Z_119 B_5 
Stack 15
D_0 J_0 I_8 H_4 B_1 
Stack 16
E_4 D_9 J_3 C_5 G_3 
Stack 17
Z_120 I_9 F_2 B_0 D_7 
Stack 18
Z_121 H_8 B_7 E_0 C_3 
Stack 19
C_6 B_3 E_6 D_1 H_9 
Stack 20
C_1 I_5 C_8 C_2 G_2 
Stack 21
F_4 G_0 C_7 F_10 H_1 
Stack 22
B_2 G_9 J_5 Z_122 Z_123 
