Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 D_0 I_0 E_0 B_2 
Stack 1
Z_101 F_1 Z_102 D_3 Z_103 
Stack 2
C_0 Z_104 G_3 G_4 J_2 
Stack 3
B_0 E_3 B_3 Z_105 E_1 
Stack 4
D_4 G_2 B_1 J_0 D_2 
Stack 5
F_2 Z_106 G_0 G_1 E_5 
Stack 6
H_2 C_1 I_1 Z_107 C_2 
Stack 7
H_0 C_3 D_1 E_2 C_4 
Stack 8
A_0 G_5 E_4 D_5 H_1 
Stack 9
Z_108 Z_109 A_1 J_1 F_0 
