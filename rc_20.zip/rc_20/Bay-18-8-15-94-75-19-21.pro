Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
I_3 H_3 I_0 D_2 E_3 Z_100 
Stack 1
Z_101 L_0 I_2 D_5 Z_102 D_1 
Stack 2
E_0 F_4 Z_103 Z_104 H_1 C_0 
Stack 3
J_5 M_1 J_2 E_4 Z_105 M_0 
Stack 4
D_0 F_6 E_2 J_6 G_1 
Stack 5
Z_106 F_0 Z_107 F_3 F_2 
Stack 6
E_5 G_0 H_4 D_4 K_1 
Stack 7
Z_108 F_1 B_2 O_0 J_3 
Stack 8
K_0 I_1 L_1 A_2 D_3 
Stack 9
H_9 Z_109 E_1 Z_110 J_1 
Stack 10
L_2 L_4 Z_111 H_0 N_0 
Stack 11
N_1 H_2 C_2 F_5 C_3 
Stack 12
I_6 G_4 I_4 Z_112 H_7 
Stack 13
Z_113 H_5 J_4 G_2 A_0 
Stack 14
N_2 H_6 G_3 Z_114 H_8 
Stack 15
B_0 Z_115 L_3 K_2 O_1 
Stack 16
M_2 C_1 I_5 J_0 Z_116 
Stack 17
A_1 K_3 Z_117 B_1 Z_118 
