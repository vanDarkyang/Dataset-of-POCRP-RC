Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_1 Z_100 A_7 E_6 Z_101 
Stack 1
A_2 C_2 Z_102 E_0 C_0 
Stack 2
A_6 Z_103 B_4 C_6 D_1 
Stack 3
A_5 C_10 Z_104 D_0 B_5 
Stack 4
A_0 Z_105 C_5 B_1 E_5 
Stack 5
C_1 B_3 E_2 C_7 E_7 
Stack 6
E_8 Z_106 D_5 Z_107 C_3 
Stack 7
A_4 D_6 D_3 E_9 E_4 
Stack 8
B_2 B_0 A_3 A_1 Z_108 
Stack 9
Z_109 C_8 D_4 D_2 Z_110 
Stack 10
C_9 B_6 C_4 E_3 
