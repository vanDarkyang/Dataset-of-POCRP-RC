Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 D_3 N_1 Z_101 F_1 Z_102 
Stack 1
K_1 J_2 K_2 J_0 Z_103 Z_104 
Stack 2
N_0 H_6 H_4 M_1 F_4 F_3 
Stack 3
I_5 Z_105 I_2 O_0 J_1 G_2 
Stack 4
C_1 J_3 B_1 D_1 M_3 
Stack 5
B_2 F_2 F_0 L_3 Z_106 
Stack 6
M_0 G_1 I_1 D_4 H_8 
Stack 7
C_0 L_5 Z_107 N_2 L_0 
Stack 8
C_3 G_4 E_4 Z_108 L_1 
Stack 9
O_2 Z_109 D_0 E_0 G_5 
Stack 10
A_0 H_3 B_0 J_4 E_1 
Stack 11
I_4 K_5 Z_110 K_0 O_1 
Stack 12
H_2 G_3 Z_111 I_0 N_3 
Stack 13
L_4 Z_112 H_1 L_2 E_2 
Stack 14
M_2 E_3 Z_113 K_4 G_0 
Stack 15
Z_114 Z_115 I_3 E_5 Z_116 
Stack 16
H_5 Z_117 D_5 K_3 H_7 
Stack 17
H_0 E_6 C_2 Z_118 D_2 
