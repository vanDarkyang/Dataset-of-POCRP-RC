Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
F_6 I_2 D_6 E_1 H_4 D_4 
Stack 1
Z_100 J_4 A_8 A_3 D_1 G_6 
Stack 2
Z_101 F_4 Z_102 E_10 J_3 A_1 
Stack 3
D_0 Z_103 I_5 Z_104 G_4 E_2 
Stack 4
I_3 F_2 G_0 Z_105 C_3 E_9 
Stack 5
Z_106 F_1 J_0 G_7 F_8 
Stack 6
G_8 Z_107 F_3 H_7 D_5 
Stack 7
D_9 H_11 J_7 Z_108 G_3 
Stack 8
D_10 C_1 Z_109 B_6 E_5 
Stack 9
Z_110 A_7 E_8 A_0 E_7 
Stack 10
I_0 D_2 E_0 Z_111 A_6 
Stack 11
B_7 G_5 E_4 C_5 D_11 
Stack 12
C_4 H_3 F_0 H_9 J_6 
Stack 13
Z_112 D_7 Z_113 I_1 Z_114 
Stack 14
Z_115 I_4 J_1 B_5 F_9 
Stack 15
E_3 F_5 B_3 F_7 Z_116 
Stack 16
J_2 G_2 B_0 C_2 B_4 
Stack 17
H_0 E_6 E_11 Z_117 Z_118 
Stack 18
H_8 B_1 B_2 H_10 H_1 
Stack 19
D_8 H_2 A_5 I_6 H_5 
Stack 20
Z_119 C_0 J_5 Z_120 C_6 
Stack 21
H_6 F_10 Z_121 A_4 I_7 
Stack 22
Z_122 Z_123 G_1 A_2 D_3 
