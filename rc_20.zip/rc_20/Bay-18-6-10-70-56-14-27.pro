Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
J_3 D_5 E_6 F_2 
Stack 1
E_4 I_0 B_2 J_0 
Stack 2
I_2 H_3 Z_100 F_5 
Stack 3
G_5 E_2 A_1 A_2 
Stack 4
Z_101 Z_102 G_1 Z_103 
Stack 5
Z_104 E_0 I_1 J_1 
Stack 6
Z_105 H_0 D_1 G_4 
Stack 7
B_0 Z_106 I_4 G_2 
Stack 8
A_0 Z_107 Z_108 F_4 
Stack 9
F_3 C_4 J_2 F_6 
Stack 10
Z_109 C_5 D_7 E_1 
Stack 11
E_7 D_0 D_6 Z_110 
Stack 12
C_3 G_3 I_3 B_1 
Stack 13
H_2 F_0 H_1 E_3 
Stack 14
D_2 D_4 Z_111 E_5 
Stack 15
F_1 C_0 A_3 G_0 
Stack 16
Z_112 C_2 C_1 
Stack 17
D_3 Z_113 E_8 
