Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 Z_101 C_1 B_0 E_8 
Stack 1
A_8 Z_102 Z_103 A_2 D_6 
Stack 2
Z_104 D_0 C_0 D_3 C_6 
Stack 3
Z_105 D_9 C_2 Z_106 E_4 
Stack 4
A_3 E_9 A_0 A_6 Z_107 
Stack 5
C_8 Z_108 C_9 A_4 B_1 
Stack 6
A_7 D_4 D_7 E_1 E_7 
Stack 7
C_7 Z_109 C_5 E_6 Z_110 
Stack 8
A_5 C_3 E_0 E_3 D_5 
Stack 9
B_2 E_2 D_8 E_5 A_1 
Stack 10
D_1 C_4 D_2 B_3 
