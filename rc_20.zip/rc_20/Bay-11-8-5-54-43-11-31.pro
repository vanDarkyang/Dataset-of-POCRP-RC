Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_4 E_0 A_5 Z_100 D_1 
Stack 1
E_1 D_7 Z_101 B_7 B_0 
Stack 2
B_5 B_4 A_1 C_0 B_6 
Stack 3
C_2 A_3 B_8 D_2 A_2 
Stack 4
C_8 Z_102 D_5 E_2 Z_103 
Stack 5
Z_104 B_1 A_6 C_4 E_5 
Stack 6
Z_105 D_6 B_3 C_6 C_7 
Stack 7
E_3 E_6 D_3 D_4 C_5 
Stack 8
Z_106 C_10 C_9 A_4 Z_107 
Stack 9
D_0 Z_108 B_2 C_1 Z_109 
Stack 10
C_3 Z_110 A_0 E_7 
