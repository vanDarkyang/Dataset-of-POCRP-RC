Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_7 B_9 Z_100 Z_101 
Stack 1
C_4 E_7 B_8 D_8 
Stack 2
E_10 E_0 C_9 A_2 
Stack 3
D_2 A_7 Z_102 Z_103 
Stack 4
B_3 Z_104 E_3 C_3 
Stack 5
A_3 D_7 Z_105 A_11 
Stack 6
D_11 D_12 D_14 D_1 
Stack 7
B_5 D_13 D_3 E_9 
Stack 8
D_10 B_11 Z_106 C_2 
Stack 9
Z_107 E_12 Z_108 C_10 
Stack 10
D_9 A_8 Z_109 B_4 
Stack 11
C_1 A_5 Z_110 E_1 
Stack 12
A_9 E_11 B_6 E_6 
Stack 13
A_0 C_5 B_0 B_2 
Stack 14
D_5 E_2 Z_111 D_0 
Stack 15
A_10 B_1 C_6 B_10 
Stack 16
E_5 A_1 B_7 E_8 
Stack 17
A_4 D_6 C_0 A_6 
Stack 18
Z_112 Z_113 Z_114 D_4 
Stack 19
C_8 Z_115 E_4 
