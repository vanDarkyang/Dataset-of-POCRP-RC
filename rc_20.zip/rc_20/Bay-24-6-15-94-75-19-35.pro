Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
F_7 M_3 I_0 B_0 
Stack 1
K_2 G_5 J_0 J_4 
Stack 2
I_5 E_3 I_1 B_1 
Stack 3
O_0 H_4 K_0 F_0 
Stack 4
H_7 Z_100 F_5 K_4 
Stack 5
A_1 I_6 M_2 Z_101 
Stack 6
D_4 G_4 F_3 H_5 
Stack 7
N_2 E_4 Z_102 G_1 
Stack 8
G_6 D_0 Z_103 Z_104 
Stack 9
H_6 Z_105 Z_106 H_2 
Stack 10
F_6 G_2 L_5 L_1 
Stack 11
Z_107 M_4 N_1 D_1 
Stack 12
I_4 Z_108 K_5 L_0 
Stack 13
F_1 H_0 M_1 Z_109 
Stack 14
Z_110 H_8 H_1 A_0 
Stack 15
I_2 Z_111 F_4 J_1 
Stack 16
E_0 Z_112 L_3 L_2 
Stack 17
E_1 M_0 F_2 D_2 
Stack 18
Z_113 Z_114 K_1 N_0 
Stack 19
O_1 G_3 J_5 G_0 
Stack 20
D_3 N_3 Z_115 Z_116 
Stack 21
J_2 L_4 I_3 E_2 
Stack 22
C_0 K_3 H_3 
Stack 23
Z_117 J_3 Z_118 
