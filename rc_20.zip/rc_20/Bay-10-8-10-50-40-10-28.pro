Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
I_3 E_4 E_5 Z_100 E_0 
Stack 1
C_2 I_1 H_2 F_3 G_3 
Stack 2
Z_101 E_2 Z_102 Z_103 F_2 
Stack 3
B_1 G_4 G_2 G_0 D_3 
Stack 4
F_0 I_0 F_4 H_0 Z_104 
Stack 5
E_1 C_0 Z_105 C_1 Z_106 
Stack 6
F_5 A_1 B_0 Z_107 G_1 
Stack 7
F_1 H_1 Z_108 I_2 J_0 
Stack 8
Z_109 D_1 C_4 E_3 D_2 
Stack 9
A_0 B_2 C_3 D_4 D_0 
