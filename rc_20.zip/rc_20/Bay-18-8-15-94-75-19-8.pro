Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
M_1 Z_100 F_1 H_2 L_0 J_2 
Stack 1
D_3 Z_101 C_3 K_2 F_3 H_6 
Stack 2
Z_102 G_3 Z_103 G_2 E_0 E_2 
Stack 3
L_2 Z_104 C_1 B_2 O_1 O_2 
Stack 4
J_1 K_4 F_5 A_1 K_1 
Stack 5
F_4 H_8 Z_105 E_4 F_0 
Stack 6
E_3 D_1 I_2 K_3 Z_106 
Stack 7
C_2 G_1 Z_107 B_3 G_5 
Stack 8
I_3 I_6 N_0 L_1 L_3 
Stack 9
B_0 Z_108 G_4 Z_109 N_1 
Stack 10
D_4 Z_110 J_0 I_0 Z_111 
Stack 11
M_4 B_1 O_0 I_1 E_1 
Stack 12
D_0 Z_112 H_0 K_0 I_5 
Stack 13
M_3 G_0 Z_113 A_2 H_1 
Stack 14
G_6 Z_114 Z_115 D_5 J_3 
Stack 15
M_0 H_5 M_2 F_2 K_5 
Stack 16
C_0 I_4 Z_116 Z_117 D_2 
Stack 17
H_4 H_3 Z_118 H_7 A_0 
