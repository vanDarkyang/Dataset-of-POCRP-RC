Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 L_0 K_4 K_3 
Stack 1
A_1 Z_101 I_4 L_1 
Stack 2
E_0 J_5 H_5 G_1 
Stack 3
I_6 H_1 Z_102 H_3 
Stack 4
N_0 L_5 E_4 L_4 
Stack 5
F_1 Z_103 G_7 H_0 
Stack 6
C_0 H_2 F_2 J_0 
Stack 7
D_3 B_1 K_1 F_3 
Stack 8
J_6 D_2 Z_104 Z_105 
Stack 9
H_4 O_2 O_0 D_1 
Stack 10
Z_106 O_1 E_2 Z_107 
Stack 11
Z_108 G_0 Z_109 A_0 
Stack 12
J_4 I_1 B_2 I_0 
Stack 13
G_5 F_0 Z_110 K_0 
Stack 14
M_0 Z_111 J_2 M_1 
Stack 15
C_3 G_4 Z_112 K_2 
Stack 16
Z_113 L_2 B_0 M_3 
Stack 17
I_3 I_2 G_3 N_3 
Stack 18
Z_114 E_3 C_2 N_2 
Stack 19
L_3 J_3 D_4 N_1 
Stack 20
F_4 E_1 M_2 Z_115 
Stack 21
K_5 D_0 J_1 Z_116 
Stack 22
G_2 G_6 Z_117 
Stack 23
C_1 I_5 Z_118 
