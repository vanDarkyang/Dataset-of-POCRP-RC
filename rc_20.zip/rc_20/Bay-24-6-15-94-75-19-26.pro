Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 I_3 Z_101 H_2 
Stack 1
A_2 J_5 N_1 G_5 
Stack 2
K_1 F_2 Z_102 D_1 
Stack 3
F_3 N_0 I_1 D_3 
Stack 4
Z_103 D_2 B_3 I_7 
Stack 5
H_6 J_4 I_5 I_6 
Stack 6
K_4 B_1 A_0 M_4 
Stack 7
Z_104 G_4 B_0 C_1 
Stack 8
E_1 N_2 H_0 Z_105 
Stack 9
O_0 C_3 F_0 Z_106 
Stack 10
M_0 L_4 J_2 Z_107 
Stack 11
C_0 G_0 G_3 F_5 
Stack 12
K_2 M_2 B_2 L_3 
Stack 13
J_3 G_1 Z_108 F_4 
Stack 14
L_0 H_1 F_6 F_1 
Stack 15
Z_109 K_3 H_3 Z_110 
Stack 16
Z_111 Z_112 J_0 I_0 
Stack 17
Z_113 G_2 L_1 E_0 
Stack 18
J_1 A_1 I_4 N_3 
Stack 19
Z_114 Z_115 M_3 O_2 
Stack 20
H_5 Z_116 C_2 D_0 
Stack 21
K_0 I_2 I_8 J_6 
Stack 22
Z_117 H_4 Z_118 
Stack 23
O_1 M_1 L_2 
