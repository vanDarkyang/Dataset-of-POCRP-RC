Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_3 Z_100 Z_101 I_1 
Stack 1
D_5 E_1 Z_102 I_3 
Stack 2
Z_103 D_3 I_2 G_2 
Stack 3
Z_104 J_0 F_0 Z_105 
Stack 4
A_1 J_1 E_4 H_1 
Stack 5
E_2 C_1 A_0 D_0 
Stack 6
E_0 A_2 C_2 G_3 
Stack 7
D_1 I_0 G_1 G_0 
Stack 8
Z_106 F_3 H_0 Z_107 
Stack 9
C_0 B_2 Z_108 B_1 
Stack 10
E_3 B_3 B_0 D_4 
Stack 11
F_1 D_2 J_2 
Stack 12
G_4 Z_109 F_2 
