Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_5 E_1 A_1 H_3 F_2 
Stack 1
E_3 F_3 A_2 B_2 Z_100 
Stack 2
Z_101 G_3 A_4 B_0 E_6 
Stack 3
J_0 C_2 F_4 C_1 I_4 
Stack 4
D_3 F_6 C_5 F_1 B_1 
Stack 5
E_4 Z_102 B_3 G_2 Z_103 
Stack 6
Z_104 E_5 G_0 G_4 C_3 
Stack 7
I_3 B_4 F_7 I_2 A_0 
Stack 8
H_4 C_4 D_1 E_0 H_1 
Stack 9
Z_105 H_5 Z_106 E_2 Z_107 
Stack 10
Z_108 Z_109 J_2 C_0 D_0 
Stack 11
Z_110 J_1 Z_111 I_0 D_2 
Stack 12
G_1 F_0 Z_112 H_2 F_5 
Stack 13
Z_113 A_3 H_0 D_4 I_1 
