Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_4 B_1 B_2 Z_100 
Stack 1
D_1 C_4 C_9 Z_101 
Stack 2
D_4 Z_102 C_7 E_7 
Stack 3
A_2 Z_103 C_6 Z_104 
Stack 4
B_0 A_5 Z_105 C_10 
Stack 5
Z_106 C_3 E_3 A_6 
Stack 6
C_2 B_3 B_5 C_0 
Stack 7
Z_107 A_0 A_7 D_5 
Stack 8
E_4 C_5 A_8 E_6 
Stack 9
C_1 A_1 D_2 Z_108 
Stack 10
E_2 D_7 E_1 E_5 
Stack 11
D_6 C_8 Z_109 A_3 
Stack 12
B_6 D_3 B_4 
Stack 13
D_0 Z_110 E_0 
