Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
E_2 G_1 D_6 G_2 D_10 E_0 
Stack 1
C_6 B_8 F_2 G_4 J_7 A_0 
Stack 2
B_6 A_2 Z_100 I_9 F_9 B_5 
Stack 3
B_7 Z_101 I_7 J_2 J_9 Z_102 
Stack 4
C_5 B_0 I_2 I_1 Z_103 Z_104 
Stack 5
F_10 E_8 Z_105 I_0 D_8 
Stack 6
B_3 Z_106 F_6 A_6 D_4 
Stack 7
J_8 H_6 E_7 D_5 F_7 
Stack 8
C_2 E_3 F_5 H_9 I_4 
Stack 9
Z_107 E_10 H_4 A_5 Z_108 
Stack 10
F_0 B_4 D_1 H_8 Z_109 
Stack 11
Z_110 H_5 C_7 J_4 B_1 
Stack 12
I_5 Z_111 C_0 H_1 Z_112 
Stack 13
I_6 D_3 Z_113 H_7 C_4 
Stack 14
E_4 H_3 G_5 E_6 Z_114 
Stack 15
G_6 F_4 G_0 H_0 E_9 
Stack 16
I_3 F_1 A_3 Z_115 A_1 
Stack 17
E_5 F_3 A_4 F_8 D_2 
Stack 18
D_0 Z_116 Z_117 B_2 C_1 
Stack 19
C_8 J_1 H_2 J_0 D_9 
Stack 20
D_7 J_5 Z_118 J_6 Z_119 
Stack 21
Z_120 Z_121 G_3 I_8 C_3 
Stack 22
Z_122 Z_123 J_3 E_1 F_11 
