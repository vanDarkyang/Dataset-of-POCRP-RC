Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
K_0 H_4 E_4 K_1 M_2 B_0 
Stack 1
Z_100 F_7 J_2 E_5 E_3 G_0 
Stack 2
Z_101 Z_102 F_1 Z_103 J_0 Z_104 
Stack 3
Z_105 K_2 Z_106 I_5 D_1 A_0 
Stack 4
N_3 Z_107 K_6 M_0 E_1 
Stack 5
Z_108 F_0 H_0 G_6 C_2 
Stack 6
Z_109 G_4 L_1 Z_110 L_2 
Stack 7
J_1 H_3 A_1 J_4 A_2 
Stack 8
E_0 F_6 F_2 J_3 G_5 
Stack 9
N_1 Z_111 D_0 H_5 M_1 
Stack 10
K_4 L_0 F_4 J_5 L_3 
Stack 11
D_2 I_4 G_7 Z_112 F_3 
Stack 12
I_0 Z_113 K_3 Z_114 D_3 
Stack 13
Z_115 I_1 C_1 H_2 Z_116 
Stack 14
D_4 E_2 B_1 K_5 G_3 
Stack 15
G_2 Z_117 I_6 Z_118 O_0 
Stack 16
G_1 D_5 N_0 N_2 C_3 
Stack 17
H_1 F_5 C_0 I_2 I_3 
