Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_2 Z_100 H_0 I_1 
Stack 1
C_0 Z_101 E_2 B_1 
Stack 2
A_4 B_0 J_1 I_5 
Stack 3
C_5 G_5 I_3 F_3 
Stack 4
D_2 Z_102 A_1 I_0 
Stack 5
B_4 Z_103 C_4 G_4 
Stack 6
G_0 Z_104 F_2 E_4 
Stack 7
Z_105 J_0 D_3 F_7 
Stack 8
F_4 D_4 E_3 A_3 
Stack 9
B_2 F_5 E_1 F_0 
Stack 10
F_1 C_3 F_6 E_5 
Stack 11
Z_106 Z_107 I_4 H_1 
Stack 12
D_1 Z_108 G_1 D_0 
Stack 13
H_4 Z_109 I_2 H_3 
Stack 14
G_2 H_2 E_0 J_3 
Stack 15
Z_110 G_3 Z_111 Z_112 
Stack 16
Z_113 B_3 A_0 
Stack 17
J_2 C_1 C_2 
