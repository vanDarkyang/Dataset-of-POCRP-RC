Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_3 I_0 E_0 H_2 
Stack 1
C_2 H_4 J_2 C_1 
Stack 2
D_2 F_0 D_1 G_4 
Stack 3
F_4 D_5 E_2 B_0 
Stack 4
Z_100 H_0 G_6 Z_101 
Stack 5
G_5 E_5 A_2 A_0 
Stack 6
J_1 Z_102 H_3 Z_103 
Stack 7
Z_104 F_3 B_2 A_1 
Stack 8
E_1 D_7 G_3 Z_105 
Stack 9
Z_106 F_6 Z_107 E_6 
Stack 10
E_7 D_6 B_1 G_2 
Stack 11
Z_108 I_2 E_4 Z_109 
Stack 12
A_3 H_1 Z_110 F_2 
Stack 13
C_5 C_0 E_3 D_3 
Stack 14
F_1 Z_111 F_7 I_1 
Stack 15
G_0 Z_112 C_4 G_1 
Stack 16
D_0 F_5 Z_113 
Stack 17
C_6 D_4 J_0 
