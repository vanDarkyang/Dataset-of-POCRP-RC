Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_3 E_6 D_6 A_3 Z_100 
Stack 1
A_6 B_1 B_3 B_2 D_2 
Stack 2
Z_101 Z_102 B_0 D_8 A_4 
Stack 3
E_2 C_0 A_0 C_3 B_4 
Stack 4
C_1 Z_103 Z_104 C_2 B_5 
Stack 5
B_6 Z_105 A_2 D_3 D_4 
Stack 6
E_0 E_5 Z_106 E_1 D_7 
Stack 7
A_7 A_1 C_7 A_5 Z_107 
Stack 8
Z_108 C_6 Z_109 D_1 B_7 
Stack 9
E_4 D_0 C_10 D_5 Z_110 
Stack 10
C_8 C_4 C_5 C_9 
