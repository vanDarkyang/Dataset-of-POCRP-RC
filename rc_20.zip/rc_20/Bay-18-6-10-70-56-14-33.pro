Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
F_6 D_1 Z_100 Z_101 
Stack 1
A_2 D_5 E_1 Z_102 
Stack 2
B_2 D_3 C_5 C_3 
Stack 3
D_6 H_0 A_1 E_0 
Stack 4
E_2 G_2 J_0 I_2 
Stack 5
D_0 Z_103 H_4 J_3 
Stack 6
C_0 E_3 F_3 Z_104 
Stack 7
Z_105 J_1 I_0 Z_106 
Stack 8
Z_107 A_0 Z_108 I_1 
Stack 9
C_1 Z_109 G_3 C_4 
Stack 10
F_2 H_3 F_0 E_7 
Stack 11
H_1 B_3 F_5 G_0 
Stack 12
A_4 A_3 G_1 B_1 
Stack 13
H_5 Z_110 H_2 J_2 
Stack 14
D_4 F_4 E_5 B_0 
Stack 15
G_4 C_2 Z_111 E_6 
Stack 16
Z_112 E_4 B_4 
Stack 17
Z_113 D_2 F_1 
