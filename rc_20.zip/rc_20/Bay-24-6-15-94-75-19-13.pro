Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
K_2 F_4 F_3 Z_100 
Stack 1
I_0 H_3 G_2 G_7 
Stack 2
Z_101 O_1 G_4 Z_102 
Stack 3
F_2 Z_103 A_2 L_3 
Stack 4
H_0 G_1 Z_104 N_0 
Stack 5
E_1 F_0 J_2 G_6 
Stack 6
G_0 F_5 E_0 A_1 
Stack 7
E_4 C_0 I_5 J_0 
Stack 8
C_2 Z_105 L_1 G_5 
Stack 9
L_2 Z_106 M_1 M_0 
Stack 10
C_1 I_1 B_2 O_2 
Stack 11
Z_107 O_0 M_2 D_0 
Stack 12
D_1 K_3 Z_108 Z_109 
Stack 13
I_2 H_1 Z_110 N_3 
Stack 14
B_0 H_4 J_5 Z_111 
Stack 15
N_2 Z_112 E_3 L_0 
Stack 16
B_1 A_0 G_3 E_2 
Stack 17
Z_113 N_1 I_3 C_3 
Stack 18
I_6 H_2 K_0 Z_114 
Stack 19
K_4 Z_115 J_1 D_2 
Stack 20
K_5 Z_116 K_1 Z_117 
Stack 21
M_4 J_3 I_7 M_3 
Stack 22
J_4 I_4 E_5 
Stack 23
D_3 Z_118 F_1 
