Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
J_3 G_4 L_3 Z_100 D_0 G_5 
Stack 1
H_5 K_3 L_4 H_3 I_3 M_3 
Stack 2
Z_101 G_2 O_1 Z_102 K_0 F_1 
Stack 3
H_9 F_6 J_2 L_5 F_0 Z_103 
Stack 4
E_1 H_0 B_1 I_5 H_8 
Stack 5
I_2 Z_104 H_2 I_4 M_2 
Stack 6
B_3 Z_105 Z_106 I_1 G_6 
Stack 7
Z_107 F_2 Z_108 L_1 H_4 
Stack 8
H_7 I_7 O_0 J_1 Z_109 
Stack 9
G_3 K_2 N_0 B_2 F_4 
Stack 10
G_1 L_2 K_1 Z_110 J_4 
Stack 11
J_6 E_2 I_6 L_0 Z_111 
Stack 12
F_5 H_6 B_0 H_1 Z_112 
Stack 13
A_1 Z_113 C_2 Z_114 J_0 
Stack 14
G_0 D_2 E_0 F_3 E_4 
Stack 15
J_5 Z_115 Z_116 C_1 D_1 
Stack 16
A_0 Z_117 E_3 I_0 M_1 
Stack 17
C_0 Z_118 D_3 N_1 M_0 
