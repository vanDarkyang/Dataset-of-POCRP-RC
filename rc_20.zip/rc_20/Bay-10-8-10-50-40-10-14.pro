Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
F_1 E_1 Z_100 D_2 H_3 
Stack 1
B_2 Z_101 Z_102 D_1 C_2 
Stack 2
A_2 H_2 C_1 G_2 E_2 
Stack 3
A_0 E_0 H_4 Z_103 H_1 
Stack 4
F_6 G_3 F_2 Z_104 J_0 
Stack 5
D_0 B_1 I_2 B_0 Z_105 
Stack 6
D_3 Z_106 F_3 F_4 Z_107 
Stack 7
F_5 G_4 G_0 I_1 D_4 
Stack 8
G_1 Z_108 I_3 A_1 C_0 
Stack 9
C_3 F_0 Z_109 I_0 H_0 
