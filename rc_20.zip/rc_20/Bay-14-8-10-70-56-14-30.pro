Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_1 C_1 D_3 C_0 A_2 
Stack 1
F_0 G_4 A_3 Z_100 I_1 
Stack 2
D_6 H_0 B_4 C_3 B_1 
Stack 3
Z_101 E_6 B_3 G_7 Z_102 
Stack 4
Z_103 Z_104 F_2 Z_105 I_3 
Stack 5
E_1 F_4 B_2 Z_106 Z_107 
Stack 6
H_1 B_5 E_5 E_2 I_2 
Stack 7
F_5 G_1 F_6 Z_108 A_0 
Stack 8
Z_109 B_0 D_4 E_0 I_0 
Stack 9
J_2 E_7 Z_110 H_4 G_6 
Stack 10
J_1 G_5 D_0 Z_111 D_5 
Stack 11
A_1 J_0 F_3 H_2 E_3 
Stack 12
E_4 C_2 F_1 G_0 H_3 
Stack 13
Z_112 D_2 G_3 Z_113 G_2 
