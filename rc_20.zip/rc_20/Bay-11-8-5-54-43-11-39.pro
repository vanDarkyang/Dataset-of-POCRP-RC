Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 C_1 Z_101 Z_102 Z_103 
Stack 1
E_6 Z_104 C_0 Z_105 D_0 
Stack 2
A_3 B_3 D_6 B_1 D_3 
Stack 3
B_2 C_3 C_9 Z_106 C_7 
Stack 4
A_9 E_5 B_6 A_8 A_7 
Stack 5
B_7 D_2 A_6 E_0 C_6 
Stack 6
D_5 A_1 A_2 A_0 Z_107 
Stack 7
Z_108 A_4 C_4 D_1 B_5 
Stack 8
E_2 B_8 E_1 E_3 C_5 
Stack 9
B_0 C_2 A_5 B_4 Z_109 
Stack 10
C_8 Z_110 D_4 E_4 
