Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
D_8 A_0 D_1 Z_100 
Stack 1
C_0 B_7 E_3 E_2 
Stack 2
B_6 C_3 Z_101 A_7 
Stack 3
C_7 D_4 D_5 C_6 
Stack 4
C_4 Z_102 E_4 E_5 
Stack 5
Z_103 E_0 Z_104 B_5 
Stack 6
A_4 A_1 D_3 A_6 
Stack 7
C_8 C_5 C_9 D_2 
Stack 8
A_2 B_4 B_2 A_5 
Stack 9
C_10 E_6 C_1 B_1 
Stack 10
C_2 Z_105 B_0 E_1 
Stack 11
B_3 Z_106 Z_107 Z_108 
Stack 12
Z_109 D_7 Z_110 
Stack 13
D_0 A_3 D_6 
