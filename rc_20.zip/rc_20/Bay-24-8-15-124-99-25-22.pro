Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
J_2 Z_100 J_3 O_1 M_1 D_2 
Stack 1
H_6 C_3 E_1 E_5 N_5 E_2 
Stack 2
C_5 O_0 N_1 I_8 J_7 E_8 
Stack 3
I_0 M_0 G_7 Z_101 G_4 D_6 
Stack 4
K_3 N_3 I_1 G_2 I_6 
Stack 5
Z_102 E_6 Z_103 A_0 C_0 
Stack 6
J_0 C_1 Z_104 B_0 F_1 
Stack 7
F_3 F_4 K_5 F_6 Z_105 
Stack 8
B_1 B_3 M_2 I_5 F_5 
Stack 9
H_7 M_4 J_6 J_1 L_6 
Stack 10
N_2 Z_106 Z_107 B_2 E_0 
Stack 11
L_2 J_5 G_8 K_1 N_4 
Stack 12
G_3 D_3 G_10 K_4 L_1 
Stack 13
Z_108 Z_109 H_5 Z_110 G_1 
Stack 14
B_5 D_0 Z_111 Z_112 L_5 
Stack 15
Z_113 L_0 N_0 L_3 Z_114 
Stack 16
E_3 E_7 J_8 H_4 Z_115 
Stack 17
I_4 C_2 Z_116 Z_117 G_5 
Stack 18
D_4 H_1 E_4 G_0 D_1 
Stack 19
Z_118 B_4 D_5 I_3 I_7 
Stack 20
K_2 L_4 H_2 Z_119 Z_120 
Stack 21
Z_121 H_0 M_3 Z_122 F_0 
Stack 22
C_4 Z_123 I_2 Z_124 H_3 
Stack 23
G_6 G_9 K_0 F_2 J_4 
