Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
D_1 Z_100 C_12 D_6 
Stack 1
E_9 A_5 D_4 Z_101 
Stack 2
B_9 C_4 Z_102 Z_103 
Stack 3
Z_104 E_5 B_12 B_0 
Stack 4
A_9 D_10 E_0 D_2 
Stack 5
B_11 C_6 C_0 B_4 
Stack 6
A_6 D_0 E_6 E_4 
Stack 7
D_5 B_13 C_7 D_12 
Stack 8
A_1 Z_105 D_9 C_5 
Stack 9
A_7 A_3 C_11 B_2 
Stack 10
C_3 Z_106 C_10 E_11 
Stack 11
B_3 Z_107 E_2 A_0 
Stack 12
B_5 C_8 D_8 A_8 
Stack 13
D_11 E_7 E_12 Z_108 
Stack 14
Z_109 A_2 Z_110 C_2 
Stack 15
E_1 B_8 B_10 A_4 
Stack 16
Z_111 Z_112 E_8 Z_113 
Stack 17
B_1 Z_114 E_3 C_1 
Stack 18
B_7 Z_115 D_7 C_9 
Stack 19
B_6 E_10 D_3 
