Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_1 D_4 J_0 C_3 
Stack 1
C_2 E_0 F_0 C_4 
Stack 2
B_2 H_0 J_1 H_1 
Stack 3
Z_100 G_3 A_0 Z_101 
Stack 4
Z_102 D_2 I_1 B_3 
Stack 5
I_0 B_1 C_0 F_3 
Stack 6
Z_103 Z_104 H_3 F_5 
Stack 7
D_1 F_4 C_1 G_2 
Stack 8
Z_105 Z_106 G_1 E_1 
Stack 9
D_0 F_2 Z_107 H_2 
Stack 10
D_3 Z_108 E_2 G_4 
Stack 11
E_3 G_0 A_2 
Stack 12
Z_109 B_0 F_1 
