Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_4 Z_100 Z_101 Z_102 
Stack 1
C_9 Z_103 B_3 C_4 
Stack 2
B_8 B_0 B_11 C_6 
Stack 3
A_10 B_4 C_11 A_8 
Stack 4
C_2 Z_104 A_11 A_2 
Stack 5
A_1 B_2 A_3 A_0 
Stack 6
Z_105 C_5 Z_106 B_5 
Stack 7
C_1 Z_107 B_1 C_8 
Stack 8
A_7 A_9 A_6 Z_108 
Stack 9
C_7 B_10 B_7 Z_109 
Stack 10
C_0 B_9 C_10 
Stack 11
A_5 C_3 B_6 
