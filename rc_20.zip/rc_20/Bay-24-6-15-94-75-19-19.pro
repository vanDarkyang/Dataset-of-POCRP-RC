Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
D_1 Z_100 Z_101 Z_102 
Stack 1
E_1 Z_103 Z_104 N_0 
Stack 2
J_2 Z_105 D_2 I_1 
Stack 3
E_4 I_6 I_5 J_0 
Stack 4
G_2 E_2 C_1 Z_106 
Stack 5
F_2 H_4 Z_107 D_0 
Stack 6
H_3 H_7 Z_108 H_0 
Stack 7
I_4 O_1 M_1 G_0 
Stack 8
H_2 G_1 F_1 F_4 
Stack 9
Z_109 B_0 M_3 F_0 
Stack 10
L_0 A_2 E_3 L_3 
Stack 11
L_4 Z_110 C_3 Z_111 
Stack 12
N_1 Z_112 D_3 H_1 
Stack 13
J_1 M_4 K_1 G_3 
Stack 14
K_2 J_3 C_2 M_0 
Stack 15
I_2 Z_113 C_0 I_0 
Stack 16
J_4 G_4 O_0 M_2 
Stack 17
E_0 O_2 L_2 Z_114 
Stack 18
D_4 I_7 N_2 A_0 
Stack 19
F_3 K_4 Z_115 A_1 
Stack 20
K_0 Z_116 G_5 Z_117 
Stack 21
H_8 H_6 K_3 G_6 
Stack 22
H_5 B_2 L_1 
Stack 23
I_3 Z_118 B_1 
