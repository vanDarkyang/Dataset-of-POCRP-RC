Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 I_0 Z_101 I_1 A_0 
Stack 1
F_5 A_1 C_0 C_1 H_1 
Stack 2
D_5 J_2 Z_102 Z_103 D_3 
Stack 3
D_0 E_1 Z_104 Z_105 H_2 
Stack 4
J_0 C_2 F_3 D_2 Z_106 
Stack 5
E_3 F_1 E_4 B_0 G_2 
Stack 6
I_2 E_5 C_3 F_4 J_1 
Stack 7
F_0 E_0 D_1 G_1 G_0 
Stack 8
D_4 F_6 F_2 Z_107 Z_108 
Stack 9
G_3 H_0 Z_109 B_1 E_2 
