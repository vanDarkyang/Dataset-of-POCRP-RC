Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
A_1 Z_100 Z_101 M_1 
Stack 1
L_4 B_2 Z_102 H_3 
Stack 2
Z_103 Z_104 Z_105 L_0 
Stack 3
Z_106 D_2 K_0 H_0 
Stack 4
B_3 G_1 I_4 E_3 
Stack 5
G_2 G_0 K_4 I_1 
Stack 6
M_0 H_6 F_4 E_1 
Stack 7
Z_107 B_1 E_0 H_7 
Stack 8
I_0 I_7 C_3 E_2 
Stack 9
D_0 J_0 L_1 J_1 
Stack 10
J_4 M_2 Z_108 I_6 
Stack 11
C_0 N_0 E_4 I_3 
Stack 12
J_5 Z_109 Z_110 J_6 
Stack 13
L_5 Z_111 F_0 Z_112 
Stack 14
O_1 H_2 M_3 G_4 
Stack 15
H_8 C_1 H_5 I_5 
Stack 16
I_2 Z_113 F_3 Z_114 
Stack 17
F_2 B_0 K_3 C_2 
Stack 18
J_3 D_1 L_2 G_3 
Stack 19
G_6 M_4 J_2 H_4 
Stack 20
A_0 F_1 K_2 Z_115 
Stack 21
Z_116 Z_117 O_0 L_3 
Stack 22
G_5 Z_118 H_1 
Stack 23
E_5 D_3 K_1 
