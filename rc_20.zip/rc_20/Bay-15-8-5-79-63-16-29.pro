Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
B_1 E_7 B_0 Z_100 E_3 A_3 
Stack 1
C_4 E_9 C_8 D_1 D_7 Z_101 
Stack 2
Z_102 B_4 E_8 Z_103 C_9 A_8 
Stack 3
E_1 D_14 D_11 E_12 E_5 C_0 
Stack 4
A_11 D_0 D_9 Z_104 C_10 
Stack 5
A_6 D_10 B_5 E_10 A_5 
Stack 6
C_3 Z_105 D_3 B_6 A_7 
Stack 7
Z_106 B_9 Z_107 B_10 C_2 
Stack 8
D_4 C_11 Z_108 E_4 A_2 
Stack 9
D_8 A_4 E_6 B_8 B_3 
Stack 10
Z_109 D_2 E_0 A_1 Z_110 
Stack 11
C_5 A_0 B_2 D_12 B_7 
Stack 12
A_9 Z_111 C_6 Z_112 Z_113 
Stack 13
D_6 A_10 D_13 Z_114 E_11 
Stack 14
C_1 C_7 D_5 E_2 Z_115 
