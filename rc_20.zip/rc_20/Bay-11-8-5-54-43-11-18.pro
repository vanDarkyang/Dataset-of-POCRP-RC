Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_0 E_3 E_0 Z_100 E_2 
Stack 1
C_3 Z_101 D_4 Z_102 E_5 
Stack 2
D_8 A_2 A_6 D_2 Z_103 
Stack 3
A_5 D_7 A_1 A_7 Z_104 
Stack 4
C_9 C_5 Z_105 E_4 C_2 
Stack 5
C_7 D_3 B_1 A_3 E_1 
Stack 6
Z_106 Z_107 C_0 Z_108 E_6 
Stack 7
B_2 A_0 E_7 B_4 C_8 
Stack 8
B_5 D_0 D_1 B_3 D_6 
Stack 9
B_6 C_4 D_5 E_8 C_6 
Stack 10
Z_109 C_1 Z_110 A_4 
