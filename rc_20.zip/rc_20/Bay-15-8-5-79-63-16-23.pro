Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
D_1 Z_100 E_8 C_11 A_9 Z_101 
Stack 1
D_2 E_6 B_2 Z_102 D_6 B_0 
Stack 2
A_11 B_1 C_0 D_0 C_10 Z_103 
Stack 3
A_2 Z_104 C_6 D_11 B_12 B_11 
Stack 4
E_3 B_7 Z_105 A_6 Z_106 
Stack 5
C_8 E_5 A_7 A_10 B_10 
Stack 6
E_1 A_4 C_5 C_4 A_12 
Stack 7
Z_107 D_8 B_8 A_3 D_3 
Stack 8
D_12 Z_108 A_8 A_1 C_7 
Stack 9
D_7 Z_109 B_5 B_6 Z_110 
Stack 10
D_9 B_3 Z_111 B_4 E_4 
Stack 11
Z_112 D_13 Z_113 A_5 D_5 
Stack 12
C_1 C_3 E_2 A_0 B_9 
Stack 13
C_9 E_0 E_9 C_2 Z_114 
Stack 14
D_4 D_10 B_13 E_7 Z_115 
