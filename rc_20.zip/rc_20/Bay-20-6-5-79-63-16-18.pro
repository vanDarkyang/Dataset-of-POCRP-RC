Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_7 A_9 Z_100 D_4 
Stack 1
E_7 Z_101 D_12 Z_102 
Stack 2
Z_103 E_9 B_11 Z_104 
Stack 3
E_3 D_2 A_6 A_8 
Stack 4
Z_105 D_9 D_8 E_11 
Stack 5
A_2 C_9 C_10 B_1 
Stack 6
B_12 B_10 B_3 Z_106 
Stack 7
A_3 A_10 A_0 Z_107 
Stack 8
C_0 A_1 D_10 E_5 
Stack 9
C_3 C_2 B_2 C_4 
Stack 10
A_11 B_6 Z_108 E_10 
Stack 11
E_6 D_7 Z_109 E_1 
Stack 12
D_3 B_4 D_1 C_5 
Stack 13
C_7 Z_110 Z_111 E_2 
Stack 14
D_0 Z_112 D_11 B_8 
Stack 15
D_6 E_0 B_9 Z_113 
Stack 16
A_5 C_11 B_0 C_6 
Stack 17
D_5 E_4 A_12 Z_114 
Stack 18
C_8 Z_115 C_1 B_7 
Stack 19
B_5 A_4 E_8 
