Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_8 A_4 B_5 A_2 
Stack 1
Z_100 A_7 Z_101 C_5 
Stack 2
C_4 C_3 A_6 B_3 
Stack 3
A_1 C_0 Z_102 C_2 
Stack 4
B_12 C_1 B_10 A_9 
Stack 5
A_3 Z_103 A_5 B_7 
Stack 6
Z_104 A_11 B_11 Z_105 
Stack 7
Z_106 C_6 B_8 B_2 
Stack 8
A_10 Z_107 B_9 Z_108 
Stack 9
B_0 A_0 B_13 Z_109 
Stack 10
C_8 B_1 B_6 
Stack 11
B_4 C_7 C_9 
