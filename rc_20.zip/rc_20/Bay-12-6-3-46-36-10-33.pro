Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 B_6 Z_101 A_2 
Stack 1
C_2 Z_102 A_6 C_14 
Stack 2
C_5 C_3 C_7 C_8 
Stack 3
A_4 C_10 C_12 B_4 
Stack 4
Z_103 A_3 B_9 Z_104 
Stack 5
C_11 C_6 B_7 C_13 
Stack 6
Z_105 B_2 Z_106 A_0 
Stack 7
B_0 Z_107 C_1 A_9 
Stack 8
C_0 B_10 A_7 Z_108 
Stack 9
B_8 C_4 B_3 A_1 
Stack 10
A_5 B_5 B_1 
Stack 11
A_8 Z_109 C_9 
