Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
Z_100 G_7 L_0 I_4 
Stack 1
B_1 E_4 J_1 O_2 
Stack 2
G_2 A_0 Z_101 Z_102 
Stack 3
D_2 I_0 I_3 C_3 
Stack 4
A_2 I_2 D_0 J_4 
Stack 5
K_2 Z_103 F_6 Z_104 
Stack 6
G_6 F_0 K_3 D_1 
Stack 7
G_5 H_3 O_0 H_5 
Stack 8
C_1 I_1 N_2 Z_105 
Stack 9
Z_106 L_1 Z_107 F_4 
Stack 10
L_3 Z_108 G_3 H_8 
Stack 11
Z_109 Z_110 L_2 I_5 
Stack 12
E_2 J_3 Z_111 G_0 
Stack 13
Z_112 O_1 G_4 H_7 
Stack 14
K_1 H_2 Z_113 A_1 
Stack 15
D_3 J_2 Z_114 K_0 
Stack 16
F_1 Z_115 Z_116 C_2 
Stack 17
E_3 J_0 J_6 H_1 
Stack 18
G_1 B_2 C_0 E_1 
Stack 19
Z_117 F_5 M_1 H_0 
Stack 20
N_3 Z_118 E_0 N_0 
Stack 21
H_6 K_4 F_7 F_2 
Stack 22
B_0 H_4 F_3 
Stack 23
M_0 J_5 N_1 
