Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_8 C_7 E_7 C_10 C_5 B_12 
Stack 1
B_1 A_7 E_9 Z_100 E_1 E_10 
Stack 2
D_6 E_2 C_9 C_8 Z_101 B_10 
Stack 3
B_13 C_3 C_13 Z_102 D_9 B_0 
Stack 4
D_0 C_1 B_3 B_6 D_2 
Stack 5
Z_103 C_6 A_9 D_4 Z_104 
Stack 6
C_14 C_2 C_15 E_0 D_3 
Stack 7
A_4 D_5 Z_105 Z_106 E_6 
Stack 8
B_9 A_10 Z_107 D_8 A_0 
Stack 9
B_2 A_1 A_6 A_3 B_4 
Stack 10
C_4 Z_108 A_2 Z_109 Z_110 
Stack 11
Z_111 B_5 E_5 E_8 E_3 
Stack 12
Z_112 D_1 D_10 C_0 E_4 
Stack 13
B_11 D_7 Z_113 B_7 B_8 
Stack 14
Z_114 C_12 Z_115 A_5 C_11 
