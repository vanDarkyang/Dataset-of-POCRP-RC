Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_1 G_0 Z_100 J_3 Z_101 
Stack 1
F_8 Z_102 C_0 J_1 I_3 
Stack 2
E_4 B_5 J_2 E_6 E_7 
Stack 3
D_0 H_0 H_3 H_2 F_3 
Stack 4
Z_103 G_1 D_2 F_1 Z_104 
Stack 5
Z_105 Z_106 Z_107 F_0 G_5 
Stack 6
B_2 E_0 C_2 B_1 G_2 
Stack 7
B_3 Z_108 G_3 E_2 C_4 
Stack 8
G_4 F_5 H_1 J_0 I_2 
Stack 9
Z_109 D_1 Z_110 Z_111 Z_112 
Stack 10
G_6 J_4 E_3 C_5 D_4 
Stack 11
I_1 I_0 B_4 Z_113 F_2 
Stack 12
F_7 F_6 D_3 B_0 C_3 
Stack 13
A_0 F_4 E_1 A_1 E_5 
