Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_4 B_0 D_0 C_2 E_2 
Stack 1
Z_100 A_3 Z_101 B_6 C_4 
Stack 2
A_5 E_6 Z_102 B_2 D_7 
Stack 3
A_8 C_6 Z_103 Z_104 D_4 
Stack 4
A_4 C_5 E_3 D_1 C_8 
Stack 5
D_8 D_5 A_0 Z_105 Z_106 
Stack 6
D_6 B_5 C_7 E_0 Z_107 
Stack 7
E_1 A_1 Z_108 B_7 E_5 
Stack 8
Z_109 D_3 B_8 A_6 A_7 
Stack 9
D_2 C_3 B_3 B_1 C_1 
Stack 10
C_0 Z_110 E_4 A_2 
