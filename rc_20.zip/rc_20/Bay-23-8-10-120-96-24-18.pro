Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
H_1 Z_100 F_5 C_5 I_0 I_1 
Stack 1
A_4 I_9 G_6 I_7 I_2 B_7 
Stack 2
F_4 I_3 J_3 B_9 Z_101 E_12 
Stack 3
Z_102 E_8 C_2 F_0 E_9 C_7 
Stack 4
Z_103 B_3 Z_104 G_5 E_11 E_6 
Stack 5
Z_105 E_7 A_3 Z_106 I_8 
Stack 6
Z_107 Z_108 E_3 A_7 Z_109 
Stack 7
A_0 H_5 B_1 F_1 G_3 
Stack 8
H_6 E_1 D_6 G_7 D_0 
Stack 9
Z_110 C_3 F_6 H_3 G_11 
Stack 10
J_1 J_0 B_4 G_0 Z_111 
Stack 11
A_2 E_4 F_2 Z_112 D_7 
Stack 12
J_5 Z_113 G_4 D_8 F_7 
Stack 13
I_6 B_0 F_9 C_6 F_8 
Stack 14
G_9 Z_114 D_3 G_8 G_10 
Stack 15
H_2 B_6 Z_115 B_2 Z_116 
Stack 16
D_4 A_6 Z_117 H_0 I_4 
Stack 17
C_4 E_2 Z_118 E_5 A_5 
Stack 18
E_10 F_10 Z_119 H_4 B_8 
Stack 19
C_0 A_1 F_3 D_2 Z_120 
Stack 20
Z_121 D_5 C_1 I_5 Z_122 
Stack 21
G_1 G_2 D_9 Z_123 J_4 
Stack 22
C_8 D_1 J_2 E_0 B_5 
