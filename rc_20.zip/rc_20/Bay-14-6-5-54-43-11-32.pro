Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_6 Z_100 Z_101 Z_102 
Stack 1
D_6 D_4 B_7 B_1 
Stack 2
Z_103 D_0 B_2 B_4 
Stack 3
A_9 C_5 Z_104 C_4 
Stack 4
E_0 A_0 A_3 E_6 
Stack 5
D_7 A_8 B_3 A_4 
Stack 6
B_9 E_4 D_1 A_5 
Stack 7
Z_105 C_2 D_2 E_7 
Stack 8
D_3 C_1 E_2 C_0 
Stack 9
B_8 C_6 Z_106 Z_107 
Stack 10
B_6 E_1 B_0 Z_108 
Stack 11
Z_109 E_3 A_1 Z_110 
Stack 12
E_5 A_7 C_3 
Stack 13
A_2 D_5 B_5 
