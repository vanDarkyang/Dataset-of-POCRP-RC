Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
J_2 Z_100 D_1 F_2 G_0 D_2 
Stack 1
G_3 H_1 E_4 Z_101 H_5 K_1 
Stack 2
C_3 Z_102 K_2 Z_103 L_3 M_1 
Stack 3
B_2 E_1 J_0 H_0 H_4 H_8 
Stack 4
G_1 N_2 E_3 Z_104 C_2 
Stack 5
O_1 I_0 I_5 N_1 G_4 
Stack 6
Z_105 Z_106 M_2 Z_107 J_3 
Stack 7
A_1 H_6 A_2 K_0 O_2 
Stack 8
D_0 G_2 G_5 N_0 D_3 
Stack 9
Z_108 M_0 L_2 I_4 H_2 
Stack 10
A_0 K_3 L_0 O_0 J_1 
Stack 11
B_1 J_4 B_0 C_1 Z_109 
Stack 12
I_1 E_0 Z_110 Z_111 L_5 
Stack 13
E_5 G_6 Z_112 I_8 F_1 
Stack 14
C_0 H_7 Z_113 I_3 I_2 
Stack 15
Z_114 I_7 F_4 H_3 Z_115 
Stack 16
Z_116 I_6 L_1 L_4 F_0 
Stack 17
B_3 Z_117 Z_118 F_3 E_2 
