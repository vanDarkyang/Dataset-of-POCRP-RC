Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 D_1 D_5 Z_101 C_2 
Stack 1
Z_102 C_4 B_4 E_7 Z_103 
Stack 2
B_0 Z_104 Z_105 C_10 A_4 
Stack 3
B_2 A_2 Z_106 Z_107 D_2 
Stack 4
D_7 C_8 D_4 D_6 D_0 
Stack 5
A_5 E_1 C_9 B_3 Z_108 
Stack 6
A_1 E_2 Z_109 B_8 D_3 
Stack 7
Z_110 C_3 B_6 C_0 B_7 
Stack 8
E_5 C_7 E_4 E_3 B_5 
Stack 9
A_6 E_0 C_6 B_1 E_6 
Stack 10
A_0 C_1 C_5 A_3 
