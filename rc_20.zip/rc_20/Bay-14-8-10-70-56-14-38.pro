Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_1 B_2 F_0 G_7 B_3 
Stack 1
D_5 Z_100 E_0 Z_101 Z_102 
Stack 2
A_0 C_0 B_0 I_2 Z_103 
Stack 3
Z_104 F_1 G_0 F_8 H_3 
Stack 4
F_7 G_6 F_2 Z_105 A_3 
Stack 5
I_0 Z_106 C_1 I_3 E_2 
Stack 6
E_5 Z_107 Z_108 A_1 G_5 
Stack 7
G_4 Z_109 F_3 G_3 E_4 
Stack 8
F_5 A_2 Z_110 J_1 J_3 
Stack 9
D_3 D_0 F_4 H_0 J_4 
Stack 10
I_1 C_2 J_0 E_3 B_1 
Stack 11
Z_111 H_1 C_3 H_5 Z_112 
Stack 12
E_1 D_4 G_2 G_1 F_6 
Stack 13
J_2 H_2 H_4 D_2 Z_113 
