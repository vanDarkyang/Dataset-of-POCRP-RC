Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 J_2 C_1 H_1 I_1 
Stack 1
E_2 B_2 G_2 A_0 Z_101 
Stack 2
F_0 G_0 I_2 E_0 H_2 
Stack 3
Z_102 Z_103 E_4 H_3 D_1 
Stack 4
Z_104 Z_105 C_2 G_1 J_0 
Stack 5
C_3 I_0 B_0 F_1 F_3 
Stack 6
B_3 F_5 F_4 E_1 I_3 
Stack 7
C_0 B_1 Z_106 D_2 D_0 
Stack 8
F_2 D_3 Z_107 E_5 Z_108 
Stack 9
H_0 A_1 E_3 Z_109 J_1 
