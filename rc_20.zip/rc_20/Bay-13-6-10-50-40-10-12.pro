Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_1 G_4 F_2 H_3 
Stack 1
E_1 D_3 F_0 I_1 
Stack 2
Z_100 I_0 G_3 D_0 
Stack 3
E_2 F_3 E_3 H_2 
Stack 4
C_1 B_1 H_1 D_2 
Stack 5
C_3 D_4 A_0 Z_101 
Stack 6
B_3 A_2 E_0 Z_102 
Stack 7
C_0 Z_103 Z_104 Z_105 
Stack 8
F_1 G_2 G_1 D_1 
Stack 9
H_0 I_2 Z_106 G_0 
Stack 10
J_1 E_4 Z_107 J_0 
Stack 11
B_2 C_2 Z_108 
Stack 12
Z_109 B_0 E_5 
