Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_1 E_3 I_0 E_5 I_1 
Stack 1
D_4 F_1 F_3 A_0 G_1 
Stack 2
H_2 G_4 B_1 C_0 F_0 
Stack 3
E_6 E_4 B_2 G_0 H_3 
Stack 4
A_1 E_1 D_2 H_1 D_0 
Stack 5
E_2 Z_100 F_5 H_0 G_2 
Stack 6
E_0 J_0 F_4 Z_101 Z_102 
Stack 7
D_1 J_1 G_3 Z_103 C_2 
Stack 8
Z_104 Z_105 Z_106 F_2 B_0 
Stack 9
Z_107 A_2 Z_108 Z_109 D_3 
