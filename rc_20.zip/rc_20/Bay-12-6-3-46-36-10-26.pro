Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_9 B_4 C_9 B_13 
Stack 1
Z_100 Z_101 C_3 A_6 
Stack 2
A_11 B_12 A_5 A_4 
Stack 3
B_5 Z_102 C_8 C_1 
Stack 4
C_2 B_6 B_8 A_1 
Stack 5
Z_103 B_10 A_2 Z_104 
Stack 6
B_0 C_4 B_11 Z_105 
Stack 7
A_3 A_0 Z_106 B_2 
Stack 8
Z_107 Z_108 A_8 Z_109 
Stack 9
B_3 C_5 B_7 C_6 
Stack 10
B_1 C_7 C_0 
Stack 11
A_9 A_7 A_10 
