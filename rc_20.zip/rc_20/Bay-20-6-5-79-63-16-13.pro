Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
B_1 A_7 Z_100 C_10 
Stack 1
A_13 B_2 C_4 A_3 
Stack 2
A_0 E_4 D_3 Z_101 
Stack 3
B_7 D_5 E_11 Z_102 
Stack 4
B_0 D_1 D_2 E_7 
Stack 5
B_10 Z_103 C_9 Z_104 
Stack 6
A_6 B_8 C_6 A_4 
Stack 7
A_12 D_11 A_9 D_4 
Stack 8
D_6 C_11 A_8 Z_105 
Stack 9
A_10 B_9 E_8 E_0 
Stack 10
A_1 C_8 Z_106 D_0 
Stack 11
Z_107 B_5 Z_108 D_9 
Stack 12
B_3 Z_109 Z_110 C_12 
Stack 13
Z_111 Z_112 E_2 C_5 
Stack 14
B_6 C_0 Z_113 C_7 
Stack 15
A_11 D_8 C_1 C_3 
Stack 16
A_2 B_4 E_9 C_2 
Stack 17
E_5 E_1 D_10 E_6 
Stack 18
E_3 A_5 E_12 E_10 
Stack 19
Z_114 D_7 Z_115 
