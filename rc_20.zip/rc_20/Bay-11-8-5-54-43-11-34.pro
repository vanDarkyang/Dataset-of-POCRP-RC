Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
Z_100 D_6 D_8 B_6 E_6 
Stack 1
E_8 Z_101 E_3 D_4 C_1 
Stack 2
A_6 Z_102 B_1 E_5 Z_103 
Stack 3
E_7 B_2 A_1 D_5 E_4 
Stack 4
A_0 Z_104 A_5 C_5 C_0 
Stack 5
A_7 Z_105 Z_106 D_1 E_1 
Stack 6
B_7 C_6 A_3 B_5 D_2 
Stack 7
D_7 E_2 C_7 Z_107 Z_108 
Stack 8
C_3 C_2 A_4 D_9 Z_109 
Stack 9
B_4 A_2 B_3 Z_110 B_0 
Stack 10
C_4 D_0 D_3 E_0 
