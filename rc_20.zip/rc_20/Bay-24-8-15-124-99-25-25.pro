Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
M_5 Z_100 H_8 G_4 N_2 Z_101 
Stack 1
D_3 E_0 I_0 B_3 B_4 G_2 
Stack 2
E_2 B_5 Z_102 F_4 Z_103 O_2 
Stack 3
Z_104 H_0 Z_105 K_7 C_2 Z_106 
Stack 4
D_4 Z_107 Z_108 F_1 K_1 
Stack 5
A_2 N_3 N_1 J_4 I_5 
Stack 6
F_7 H_2 K_8 Z_109 C_4 
Stack 7
D_2 Z_110 I_6 N_0 Z_111 
Stack 8
H_4 Z_112 C_3 I_1 L_3 
Stack 9
D_5 M_4 H_1 K_3 L_6 
Stack 10
B_0 Z_113 K_6 Z_114 K_5 
Stack 11
G_6 F_3 J_1 F_2 C_1 
Stack 12
G_5 Z_115 J_2 L_0 M_1 
Stack 13
G_1 L_4 I_3 I_4 K_0 
Stack 14
H_6 Z_116 L_7 H_5 O_1 
Stack 15
Z_117 J_5 A_1 D_0 H_3 
Stack 16
F_0 I_2 M_2 K_2 H_7 
Stack 17
D_1 F_6 B_2 J_3 L_1 
Stack 18
Z_118 Z_119 C_0 O_0 L_5 
Stack 19
F_5 M_0 G_0 A_0 Z_120 
Stack 20
E_6 E_3 N_4 Z_121 E_5 
Stack 21
G_7 E_4 C_5 L_2 G_3 
Stack 22
J_0 M_3 E_1 Z_122 Z_123 
Stack 23
G_8 Z_124 E_7 K_4 B_1 
