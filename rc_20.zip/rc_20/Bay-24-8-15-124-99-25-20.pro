Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
C_0 G_3 I_0 B_1 J_3 H_3 
Stack 1
E_3 Z_100 Z_101 G_8 A_1 M_0 
Stack 2
J_1 F_5 Z_102 E_7 J_2 I_4 
Stack 3
G_4 F_7 J_6 I_9 D_1 F_0 
Stack 4
E_6 H_10 D_5 Z_103 E_5 
Stack 5
Z_104 I_5 J_0 K_0 Z_105 
Stack 6
Z_106 A_2 H_4 Z_107 F_4 
Stack 7
K_2 H_7 Z_108 H_8 C_1 
Stack 8
C_4 J_5 E_2 F_2 I_6 
Stack 9
A_0 M_3 Z_109 Z_110 H_1 
Stack 10
O_0 L_1 Z_111 B_3 Z_112 
Stack 11
A_3 B_0 O_2 I_10 I_7 
Stack 12
Z_113 L_0 Z_114 N_4 D_0 
Stack 13
C_5 Z_115 H_9 L_4 N_3 
Stack 14
Z_116 F_6 Z_117 L_3 G_0 
Stack 15
C_3 M_2 G_6 G_9 I_8 
Stack 16
Z_118 L_2 N_0 G_2 G_5 
Stack 17
F_1 G_1 J_4 Z_119 N_2 
Stack 18
Z_120 M_1 D_4 E_0 Z_121 
Stack 19
Z_122 O_1 Z_123 K_3 C_2 
Stack 20
I_2 Z_124 M_4 E_1 F_3 
Stack 21
H_5 K_1 H_2 N_5 N_1 
Stack 22
D_3 G_7 O_3 H_0 I_3 
Stack 23
E_4 H_6 I_1 B_2 D_2 
