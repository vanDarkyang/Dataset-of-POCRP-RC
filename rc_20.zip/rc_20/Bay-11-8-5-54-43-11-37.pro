Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
C_4 C_7 Z_100 Z_101 B_4 
Stack 1
E_7 A_0 Z_102 A_3 E_5 
Stack 2
D_4 A_1 C_1 B_1 D_7 
Stack 3
D_8 B_9 C_2 B_8 B_5 
Stack 4
Z_103 D_0 B_7 Z_104 Z_105 
Stack 5
B_6 C_0 D_5 E_0 C_3 
Stack 6
C_6 A_6 Z_106 Z_107 E_2 
Stack 7
D_6 A_5 B_2 E_6 D_2 
Stack 8
A_4 E_1 C_5 D_1 E_4 
Stack 9
A_2 E_3 D_3 B_0 Z_108 
Stack 10
Z_109 B_10 Z_110 B_3 
