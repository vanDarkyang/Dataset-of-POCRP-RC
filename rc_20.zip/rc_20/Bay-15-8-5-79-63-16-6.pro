Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_3 E_9 E_8 A_0 E_5 Z_100 
Stack 1
B_5 A_10 D_5 B_6 C_2 E_6 
Stack 2
A_4 C_1 C_5 D_11 C_6 A_11 
Stack 3
C_7 C_12 D_7 A_6 B_0 D_8 
Stack 4
Z_101 B_3 A_5 A_7 C_9 
Stack 5
A_9 E_1 Z_102 Z_103 E_10 
Stack 6
D_12 Z_104 C_11 D_6 A_12 
Stack 7
E_3 B_7 D_4 Z_105 Z_106 
Stack 8
B_2 C_0 Z_107 Z_108 Z_109 
Stack 9
D_9 A_13 D_13 E_0 Z_110 
Stack 10
A_3 D_10 Z_111 A_8 Z_112 
Stack 11
E_4 C_8 A_1 D_1 C_10 
Stack 12
D_2 D_3 A_2 Z_113 B_1 
Stack 13
E_2 B_8 C_4 B_9 D_0 
Stack 14
B_10 Z_114 Z_115 E_7 B_4 
