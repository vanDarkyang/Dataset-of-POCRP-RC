Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
F_5 J_0 H_3 L_1 
Stack 1
F_4 H_6 B_2 N_0 
Stack 2
Z_100 F_6 Z_101 D_2 
Stack 3
Z_102 G_1 K_5 I_5 
Stack 4
M_2 Z_103 E_2 H_0 
Stack 5
Z_104 A_2 I_3 Z_105 
Stack 6
M_4 C_3 Z_106 G_4 
Stack 7
Z_107 Z_108 H_2 E_0 
Stack 8
H_8 H_4 H_5 D_1 
Stack 9
Z_109 F_2 L_2 Z_110 
Stack 10
F_0 Z_111 K_3 J_3 
Stack 11
I_0 J_2 J_4 H_7 
Stack 12
F_1 B_0 G_2 Z_112 
Stack 13
G_5 D_3 G_3 L_3 
Stack 14
E_1 Z_113 F_3 Z_114 
Stack 15
C_1 H_1 K_4 J_1 
Stack 16
N_1 C_0 O_1 K_2 
Stack 17
A_1 M_0 E_3 Z_115 
Stack 18
Z_116 Z_117 K_0 K_1 
Stack 19
C_2 I_4 B_1 D_0 
Stack 20
E_4 J_5 M_1 I_1 
Stack 21
L_4 M_3 A_0 E_5 
Stack 22
Z_118 O_0 I_2 
Stack 23
E_6 G_0 L_0 
