Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
K_3 Z_100 A_1 G_8 L_5 B_3 
Stack 1
Z_101 C_2 Z_102 O_1 K_0 F_8 
Stack 2
M_2 C_1 K_1 F_2 N_1 Z_103 
Stack 3
H_2 L_0 J_2 N_2 Z_104 Z_105 
Stack 4
H_0 Z_106 E_4 O_3 Z_107 
Stack 5
M_0 Z_108 Z_109 F_7 D_1 
Stack 6
H_3 I_1 D_0 L_3 C_0 
Stack 7
L_2 J_0 I_2 E_0 O_2 
Stack 8
N_0 B_5 D_2 M_3 N_4 
Stack 9
K_6 M_5 G_1 J_4 I_6 
Stack 10
Z_110 Z_111 O_4 E_3 A_0 
Stack 11
C_5 Z_112 Z_113 F_0 Z_114 
Stack 12
B_1 E_2 B_0 F_3 Z_115 
Stack 13
I_4 B_2 E_1 K_4 A_2 
Stack 14
J_6 M_1 H_5 Z_116 D_5 
Stack 15
I_3 F_1 K_5 G_2 G_5 
Stack 16
O_0 L_6 G_7 H_1 C_4 
Stack 17
G_4 D_4 K_2 J_1 J_5 
Stack 18
G_6 D_3 L_4 Z_117 F_6 
Stack 19
I_5 N_3 Z_118 B_4 D_6 
Stack 20
Z_119 H_4 Z_120 J_3 L_1 
Stack 21
F_4 K_7 Z_121 I_7 G_3 
Stack 22
G_0 M_4 Z_122 Z_123 Z_124 
Stack 23
H_7 I_0 H_6 F_5 C_3 
