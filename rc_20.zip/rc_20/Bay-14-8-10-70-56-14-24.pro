Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_0 F_2 J_1 F_5 F_4 
Stack 1
D_4 E_8 E_7 H_6 Z_100 
Stack 2
C_1 E_3 J_0 B_3 D_6 
Stack 3
Z_101 A_3 B_1 Z_102 E_6 
Stack 4
D_1 Z_103 G_1 E_0 I_0 
Stack 5
Z_104 I_4 I_3 Z_105 D_3 
Stack 6
E_4 B_2 H_2 A_2 D_2 
Stack 7
Z_106 Z_107 G_0 H_5 Z_108 
Stack 8
Z_109 B_4 G_2 I_1 G_4 
Stack 9
F_0 G_3 F_1 D_5 J_2 
Stack 10
A_1 Z_110 H_3 E_2 Z_111 
Stack 11
E_5 E_1 F_6 H_0 B_0 
Stack 12
H_4 A_0 F_7 Z_112 C_0 
Stack 13
J_3 Z_113 I_2 H_1 F_3 
