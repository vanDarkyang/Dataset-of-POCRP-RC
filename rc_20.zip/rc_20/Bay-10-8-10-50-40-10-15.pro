Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_0 C_1 D_1 F_2 F_3 
Stack 1
H_3 I_0 Z_100 F_5 D_3 
Stack 2
Z_101 Z_102 H_1 F_4 A_2 
Stack 3
F_1 H_2 G_0 H_0 Z_103 
Stack 4
B_0 Z_104 I_1 G_2 G_4 
Stack 5
H_4 E_1 Z_105 G_3 A_1 
Stack 6
E_2 E_3 D_0 Z_106 D_5 
Stack 7
C_0 D_2 Z_107 E_5 E_0 
Stack 8
B_1 D_4 I_2 Z_108 Z_109 
Stack 9
G_1 C_2 J_0 F_0 E_4 
