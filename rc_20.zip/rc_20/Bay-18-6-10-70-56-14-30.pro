Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_1 D_5 D_3 Z_100 
Stack 1
F_0 F_5 F_4 Z_101 
Stack 2
D_6 B_4 D_0 A_3 
Stack 3
J_3 Z_102 Z_103 I_2 
Stack 4
C_3 B_0 F_2 Z_104 
Stack 5
E_2 Z_105 G_1 H_3 
Stack 6
H_0 G_3 C_0 I_5 
Stack 7
F_6 J_0 A_0 Z_106 
Stack 8
F_1 C_2 C_4 I_3 
Stack 9
J_2 Z_107 G_4 A_1 
Stack 10
Z_108 D_2 I_4 I_1 
Stack 11
A_2 Z_109 Z_110 Z_111 
Stack 12
E_4 B_3 E_3 D_4 
Stack 13
J_1 B_2 E_1 Z_112 
Stack 14
C_1 F_3 E_0 H_2 
Stack 15
G_2 B_1 H_4 G_0 
Stack 16
Z_113 E_5 I_0 
Stack 17
E_6 F_7 H_1 
