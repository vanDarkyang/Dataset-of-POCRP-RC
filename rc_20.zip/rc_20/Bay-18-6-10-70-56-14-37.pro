Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_1 Z_100 H_0 G_5 
Stack 1
B_0 D_3 F_5 H_1 
Stack 2
D_5 Z_101 C_0 Z_102 
Stack 3
D_4 I_1 G_4 Z_103 
Stack 4
E_0 J_3 B_5 C_3 
Stack 5
Z_104 B_1 Z_105 A_2 
Stack 6
G_0 C_1 D_0 C_2 
Stack 7
H_4 G_2 F_3 I_4 
Stack 8
I_0 I_2 G_6 Z_106 
Stack 9
E_1 C_4 I_3 D_2 
Stack 10
E_2 F_2 Z_107 J_2 
Stack 11
D_1 E_5 J_1 G_3 
Stack 12
H_3 A_0 G_1 D_6 
Stack 13
Z_108 J_0 B_2 B_4 
Stack 14
Z_109 E_3 H_2 Z_110 
Stack 15
B_3 F_4 Z_111 Z_112 
Stack 16
Z_113 E_4 F_0 
Stack 17
F_1 C_5 E_6 
