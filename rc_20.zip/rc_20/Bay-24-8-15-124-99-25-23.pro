Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
H_0 B_2 H_9 E_2 A_2 J_0 
Stack 1
O_1 N_0 F_4 Z_100 K_0 G_1 
Stack 2
G_7 L_2 L_5 Z_101 L_3 Z_102 
Stack 3
D_5 J_8 Z_103 F_1 C_1 A_3 
Stack 4
F_7 F_3 J_1 Z_104 N_1 
Stack 5
J_5 I_8 Z_105 E_1 D_3 
Stack 6
F_2 G_3 H_2 A_0 I_6 
Stack 7
G_5 J_4 E_5 J_7 Z_106 
Stack 8
Z_107 I_0 Z_108 K_6 Z_109 
Stack 9
I_4 C_2 F_0 Z_110 E_3 
Stack 10
K_4 H_8 Z_111 G_4 G_8 
Stack 11
E_7 M_2 Z_112 K_1 Z_113 
Stack 12
I_7 Z_114 J_6 Z_115 K_2 
Stack 13
D_4 E_0 L_0 C_5 E_4 
Stack 14
M_4 M_3 Z_116 Z_117 G_0 
Stack 15
Z_118 O_0 Z_119 K_3 H_7 
Stack 16
M_1 L_6 I_3 B_1 G_2 
Stack 17
L_4 D_1 L_1 H_4 C_0 
Stack 18
C_4 H_5 Z_120 E_6 K_5 
Stack 19
H_3 J_3 I_2 Z_121 M_0 
Stack 20
D_0 D_2 I_1 J_2 A_1 
Stack 21
G_9 C_3 B_0 H_1 F_5 
Stack 22
N_2 Z_122 Z_123 H_6 I_5 
Stack 23
Z_124 F_6 G_6 N_3 M_5 
