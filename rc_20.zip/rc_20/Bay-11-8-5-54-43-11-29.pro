Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_2 D_7 Z_100 E_4 E_9 
Stack 1
D_1 B_6 Z_101 Z_102 E_2 
Stack 2
D_5 D_0 D_8 Z_103 C_8 
Stack 3
Z_104 Z_105 C_6 A_6 A_5 
Stack 4
Z_106 Z_107 D_3 Z_108 C_0 
Stack 5
B_5 C_9 D_2 E_1 D_6 
Stack 6
C_2 B_1 Z_109 B_3 E_7 
Stack 7
B_0 A_3 C_7 B_4 Z_110 
Stack 8
E_5 C_3 C_5 E_0 E_6 
Stack 9
C_1 B_2 C_4 E_8 A_1 
Stack 10
E_3 A_0 D_4 A_4 
