Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_2 D_1 B_2 A_1 A_3 
Stack 1
D_2 D_4 A_2 H_3 Z_100 
Stack 2
A_4 F_3 C_4 F_1 E_3 
Stack 3
E_7 B_1 H_0 C_1 E_1 
Stack 4
E_6 B_0 Z_101 G_4 Z_102 
Stack 5
I_1 D_5 Z_103 C_5 J_1 
Stack 6
G_0 J_0 F_5 G_3 E_4 
Stack 7
Z_104 I_0 F_6 A_0 E_0 
Stack 8
D_3 F_4 Z_105 D_6 J_2 
Stack 9
Z_106 G_2 Z_107 I_4 E_5 
Stack 10
Z_108 Z_109 Z_110 C_0 Z_111 
Stack 11
H_1 E_2 D_0 H_2 F_7 
Stack 12
H_4 G_1 I_3 C_3 I_2 
Stack 13
F_2 F_0 Z_112 B_3 Z_113 
