Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_0 J_1 F_1 G_0 F_0 
Stack 1
C_3 H_3 G_4 A_1 A_2 
Stack 2
B_0 G_5 G_1 C_2 F_3 
Stack 3
Z_100 Z_101 F_2 C_4 D_2 
Stack 4
I_0 E_1 G_3 F_4 Z_102 
Stack 5
A_0 Z_103 G_2 B_1 H_2 
Stack 6
Z_104 I_1 Z_105 I_2 Z_106 
Stack 7
D_3 D_0 E_3 C_0 H_0 
Stack 8
C_1 E_2 B_2 D_1 Z_107 
Stack 9
Z_108 E_4 H_1 Z_109 J_0 
