Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_5 C_10 D_11 D_10 
Stack 1
A_7 C_5 B_9 E_0 
Stack 2
Z_100 B_7 B_11 E_5 
Stack 3
E_7 Z_101 C_8 Z_102 
Stack 4
B_10 Z_103 C_9 E_8 
Stack 5
B_6 B_8 B_4 B_1 
Stack 6
Z_104 E_10 Z_105 D_5 
Stack 7
D_8 B_3 A_11 A_4 
Stack 8
B_2 E_3 A_1 A_12 
Stack 9
B_5 Z_106 Z_107 C_0 
Stack 10
C_12 Z_108 E_4 E_6 
Stack 11
Z_109 D_1 D_9 Z_110 
Stack 12
Z_111 A_3 A_9 A_8 
Stack 13
E_1 A_10 Z_112 E_2 
Stack 14
B_0 D_3 A_2 D_2 
Stack 15
D_7 D_6 C_7 A_0 
Stack 16
D_0 E_9 C_6 Z_113 
Stack 17
C_13 C_1 B_12 C_4 
Stack 18
D_4 C_11 C_2 Z_114 
Stack 19
Z_115 A_6 C_3 
