Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_2 G_0 H_4 B_4 
Stack 1
A_0 F_1 J_0 D_3 
Stack 2
G_2 Z_100 Z_101 Z_102 
Stack 3
F_3 H_1 G_7 I_3 
Stack 4
F_2 C_4 E_2 G_5 
Stack 5
F_0 G_3 E_4 E_1 
Stack 6
C_2 J_2 F_6 Z_103 
Stack 7
A_1 E_3 I_1 J_3 
Stack 8
Z_104 Z_105 D_4 E_6 
Stack 9
G_1 I_4 D_2 C_3 
Stack 10
A_2 E_5 H_0 Z_106 
Stack 11
Z_107 I_5 F_5 Z_108 
Stack 12
G_6 H_3 C_0 D_1 
Stack 13
Z_109 E_0 D_5 Z_110 
Stack 14
Z_111 B_0 H_2 I_2 
Stack 15
D_0 B_3 F_4 Z_112 
Stack 16
Z_113 J_1 B_1 
Stack 17
G_4 I_0 C_1 
