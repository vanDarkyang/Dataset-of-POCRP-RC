Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_7 C_3 D_2 B_3 
Stack 1
A_9 B_10 D_0 D_7 
Stack 2
D_10 A_11 Z_100 C_9 
Stack 3
Z_101 A_10 A_8 C_1 
Stack 4
B_7 D_12 D_6 C_5 
Stack 5
A_5 Z_102 B_1 Z_103 
Stack 6
E_7 C_0 D_3 Z_104 
Stack 7
B_0 B_4 D_5 E_0 
Stack 8
Z_105 Z_106 C_2 D_1 
Stack 9
Z_107 A_0 C_11 A_13 
Stack 10
Z_108 C_7 E_3 E_8 
Stack 11
Z_109 Z_110 C_13 A_3 
Stack 12
C_10 A_1 Z_111 C_8 
Stack 13
E_1 Z_112 D_9 E_4 
Stack 14
E_5 D_4 C_6 A_12 
Stack 15
B_2 B_5 E_6 C_12 
Stack 16
A_6 E_9 A_4 B_6 
Stack 17
B_8 C_4 D_8 Z_113 
Stack 18
Z_114 B_11 A_2 Z_115 
Stack 19
B_9 E_2 D_11 
