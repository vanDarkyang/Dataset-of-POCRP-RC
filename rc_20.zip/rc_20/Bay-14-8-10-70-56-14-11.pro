Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
F_2 Z_100 J_0 H_3 A_2 
Stack 1
Z_101 D_2 I_2 H_2 C_6 
Stack 2
H_0 G_3 F_7 B_2 B_0 
Stack 3
H_1 H_4 G_1 A_0 F_0 
Stack 4
E_1 G_5 Z_102 G_4 C_1 
Stack 5
Z_103 J_3 C_5 Z_104 E_6 
Stack 6
I_3 C_2 I_1 D_1 C_0 
Stack 7
E_0 F_5 Z_105 E_3 E_4 
Stack 8
J_1 G_2 B_1 Z_106 D_3 
Stack 9
D_0 D_4 A_3 G_0 E_2 
Stack 10
B_3 Z_107 A_1 Z_108 Z_109 
Stack 11
Z_110 F_3 F_6 F_4 J_2 
Stack 12
G_6 C_3 A_4 Z_111 C_4 
Stack 13
F_1 Z_112 I_0 Z_113 E_5 
