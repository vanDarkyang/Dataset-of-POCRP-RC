Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
C_7 C_3 A_8 Z_100 
Stack 1
Z_101 B_3 C_8 C_4 
Stack 2
Z_102 C_9 A_4 C_10 
Stack 3
C_2 Z_103 C_11 B_0 
Stack 4
B_8 A_1 Z_104 B_1 
Stack 5
C_1 B_12 A_9 B_7 
Stack 6
C_5 Z_105 C_6 B_10 
Stack 7
A_6 B_9 Z_106 A_3 
Stack 8
B_2 Z_107 A_5 A_0 
Stack 9
B_11 A_2 A_10 A_7 
Stack 10
B_6 Z_108 C_0 
Stack 11
Z_109 B_4 B_5 
