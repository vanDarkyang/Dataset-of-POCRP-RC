Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
N_2 I_1 J_1 Z_100 
Stack 1
K_2 J_5 E_2 E_3 
Stack 2
L_1 K_3 J_6 M_0 
Stack 3
J_3 M_4 H_4 I_8 
Stack 4
Z_101 N_1 G_7 E_1 
Stack 5
G_1 G_6 I_6 M_1 
Stack 6
Z_102 I_0 C_0 Z_103 
Stack 7
O_0 D_0 M_2 N_0 
Stack 8
C_2 Z_104 Z_105 F_1 
Stack 9
C_3 I_2 Z_106 O_1 
Stack 10
L_3 M_3 J_4 H_2 
Stack 11
G_3 F_4 Z_107 H_1 
Stack 12
I_7 K_1 Z_108 H_0 
Stack 13
G_2 I_5 Z_109 G_4 
Stack 14
Z_110 O_2 Z_111 B_0 
Stack 15
B_2 D_3 Z_112 Z_113 
Stack 16
K_4 J_2 I_4 C_1 
Stack 17
D_1 F_6 I_3 K_5 
Stack 18
L_0 F_5 D_2 F_3 
Stack 19
H_3 Z_114 G_0 A_1 
Stack 20
Z_115 A_0 L_4 F_2 
Stack 21
J_0 Z_116 Z_117 L_2 
Stack 22
B_1 G_5 Z_118 
Stack 23
E_0 F_0 K_0 
