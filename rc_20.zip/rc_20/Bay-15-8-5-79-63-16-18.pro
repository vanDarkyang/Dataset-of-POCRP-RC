Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 D_6 B_4 C_11 D_3 C_13 
Stack 1
Z_101 A_4 D_7 Z_102 B_10 C_7 
Stack 2
B_0 D_4 B_2 A_0 E_9 D_11 
Stack 3
E_2 C_9 A_1 D_10 Z_103 B_5 
Stack 4
Z_104 B_3 A_9 Z_105 E_10 
Stack 5
Z_106 A_6 E_0 D_0 Z_107 
Stack 6
B_12 E_6 C_12 C_14 Z_108 
Stack 7
Z_109 E_8 E_3 Z_110 B_7 
Stack 8
C_0 Z_111 C_1 E_5 E_4 
Stack 9
C_4 D_9 A_3 D_12 C_5 
Stack 10
A_8 C_10 D_5 B_8 Z_112 
Stack 11
Z_113 B_9 D_13 B_1 E_1 
Stack 12
D_2 A_7 B_11 Z_114 C_6 
Stack 13
C_8 A_2 A_5 C_2 Z_115 
Stack 14
D_1 C_3 D_8 E_7 B_6 
