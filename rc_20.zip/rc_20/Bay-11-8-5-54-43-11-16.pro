Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_2 B_3 C_7 A_3 D_7 
Stack 1
D_0 Z_100 A_1 A_0 D_8 
Stack 2
E_0 E_3 C_3 D_4 Z_101 
Stack 3
D_5 B_4 C_2 A_5 B_6 
Stack 4
Z_102 Z_103 D_1 C_4 A_4 
Stack 5
Z_104 C_0 B_1 D_6 C_5 
Stack 6
B_0 A_2 E_4 Z_105 E_1 
Stack 7
E_5 Z_106 C_1 E_2 Z_107 
Stack 8
D_2 Z_108 Z_109 Z_110 C_8 
Stack 9
B_5 E_7 E_8 B_7 C_6 
Stack 10
E_6 A_6 D_3 A_7 
