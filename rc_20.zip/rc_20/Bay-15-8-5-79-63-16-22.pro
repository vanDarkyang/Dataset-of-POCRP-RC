Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
D_2 E_1 A_3 C_0 D_9 A_1 
Stack 1
E_9 A_7 D_4 E_7 A_5 C_10 
Stack 2
B_9 B_1 C_9 Z_100 Z_101 C_1 
Stack 3
B_3 B_7 Z_102 D_12 B_0 Z_103 
Stack 4
A_8 B_5 A_0 C_12 D_3 
Stack 5
Z_104 Z_105 B_8 C_11 Z_106 
Stack 6
A_4 A_2 D_6 E_3 E_5 
Stack 7
D_8 C_5 Z_107 D_11 D_15 
Stack 8
Z_108 E_6 C_7 E_12 C_6 
Stack 9
A_6 D_13 E_10 D_0 B_2 
Stack 10
C_4 C_8 Z_109 B_10 E_11 
Stack 11
Z_110 D_1 D_7 E_8 Z_111 
Stack 12
B_4 B_11 E_2 E_4 Z_112 
Stack 13
D_14 B_6 Z_113 D_10 C_3 
Stack 14
Z_114 Z_115 E_0 D_5 C_2 
