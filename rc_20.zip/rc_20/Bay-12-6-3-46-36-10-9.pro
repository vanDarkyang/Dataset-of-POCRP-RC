Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_1 B_6 B_10 A_0 
Stack 1
B_2 A_10 A_9 A_7 
Stack 2
C_4 Z_100 A_5 C_1 
Stack 3
B_5 Z_101 C_11 C_8 
Stack 4
C_6 A_8 Z_102 C_10 
Stack 5
B_9 A_6 C_12 A_4 
Stack 6
C_2 C_3 C_0 B_3 
Stack 7
A_3 C_7 Z_103 B_0 
Stack 8
B_4 B_11 C_5 Z_104 
Stack 9
A_2 C_9 Z_105 Z_106 
Stack 10
Z_107 B_8 A_1 
Stack 11
B_7 Z_108 Z_109 
