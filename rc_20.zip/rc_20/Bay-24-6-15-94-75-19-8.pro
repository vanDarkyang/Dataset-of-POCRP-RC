Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
M_1 Z_100 H_0 L_1 
Stack 1
D_2 G_1 L_0 Z_101 
Stack 2
L_3 Z_102 J_6 Z_103 
Stack 3
L_4 E_5 M_2 Z_104 
Stack 4
J_3 I_3 H_7 K_1 
Stack 5
F_2 B_1 Z_105 Z_106 
Stack 6
E_3 J_0 H_2 N_0 
Stack 7
C_3 G_0 K_2 G_5 
Stack 8
Z_107 F_0 G_2 L_5 
Stack 9
B_0 Z_108 B_2 N_1 
Stack 10
D_3 I_4 A_1 Z_109 
Stack 11
Z_110 H_3 E_4 E_0 
Stack 12
D_0 F_1 K_3 I_5 
Stack 13
M_3 C_4 B_3 H_1 
Stack 14
G_6 J_2 L_2 J_5 
Stack 15
M_0 C_2 Z_111 K_5 
Stack 16
C_0 F_3 I_0 D_1 
Stack 17
H_4 Z_112 I_1 A_0 
Stack 18
Z_113 I_2 K_0 J_4 
Stack 19
Z_114 Z_115 A_2 H_5 
Stack 20
G_3 Z_116 D_4 E_2 
Stack 21
E_1 G_4 Z_117 O_1 
Stack 22
K_4 J_1 C_1 
Stack 23
Z_118 O_0 H_6 
