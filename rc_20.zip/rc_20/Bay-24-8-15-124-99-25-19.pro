Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
Z_100 L_0 E_5 F_2 B_4 Z_101 
Stack 1
D_3 G_2 G_3 Z_102 Z_103 E_3 
Stack 2
Z_104 H_6 H_7 G_0 D_6 N_4 
Stack 3
L_5 H_9 B_3 E_1 C_1 J_6 
Stack 4
L_2 F_6 Z_105 Z_106 Z_107 
Stack 5
Z_108 L_3 A_0 I_2 J_7 
Stack 6
B_0 J_3 F_4 N_0 H_1 
Stack 7
H_5 N_1 Z_109 M_4 J_2 
Stack 8
C_2 C_3 M_2 N_3 L_4 
Stack 9
K_2 Z_110 I_1 Z_111 F_8 
Stack 10
M_0 G_8 Z_112 G_7 J_5 
Stack 11
K_5 Z_113 Z_114 J_0 F_0 
Stack 12
L_1 D_0 Z_115 Z_116 Z_117 
Stack 13
D_5 H_0 D_4 Z_118 E_4 
Stack 14
F_1 G_5 G_6 H_4 G_4 
Stack 15
Z_119 B_1 F_5 J_1 C_0 
Stack 16
M_1 Z_120 K_1 M_5 F_7 
Stack 17
H_2 I_4 J_8 O_3 A_2 
Stack 18
I_0 E_0 I_6 D_2 O_1 
Stack 19
A_3 Z_121 O_2 E_6 Z_122 
Stack 20
B_2 Z_123 C_4 E_2 Z_124 
Stack 21
G_1 J_4 H_3 K_0 A_1 
Stack 22
F_3 I_3 N_2 O_0 K_3 
Stack 23
D_1 H_8 I_5 K_4 M_3 
