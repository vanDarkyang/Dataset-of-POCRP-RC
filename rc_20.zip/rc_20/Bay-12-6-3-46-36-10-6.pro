Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_5 B_10 B_7 B_4 
Stack 1
A_6 A_1 B_6 C_10 
Stack 2
A_12 A_0 B_5 Z_100 
Stack 3
A_9 B_1 C_4 B_0 
Stack 4
B_9 A_7 Z_101 A_4 
Stack 5
Z_102 Z_103 A_10 A_3 
Stack 6
Z_104 Z_105 C_8 C_6 
Stack 7
A_11 A_8 C_1 A_13 
Stack 8
C_9 C_7 B_2 B_8 
Stack 9
Z_106 A_2 C_5 Z_107 
Stack 10
C_2 C_0 C_3 
Stack 11
B_3 Z_108 Z_109 
