Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_3 B_10 B_9 C_2 
Stack 1
Z_100 Z_101 B_1 Z_102 
Stack 2
Z_103 D_7 D_3 B_0 
Stack 3
C_1 Z_104 C_14 C_8 
Stack 4
D_2 B_2 C_0 B_7 
Stack 5
Z_105 A_3 Z_106 E_10 
Stack 6
Z_107 Z_108 Z_109 B_13 
Stack 7
Z_110 E_7 A_0 Z_111 
Stack 8
B_5 A_8 C_13 E_9 
Stack 9
D_0 Z_112 E_6 C_7 
Stack 10
A_4 A_9 A_1 B_8 
Stack 11
E_8 A_6 A_5 E_5 
Stack 12
B_6 D_10 D_6 B_14 
Stack 13
E_3 C_9 C_6 B_4 
Stack 14
A_2 E_11 C_10 B_3 
Stack 15
D_9 Z_113 D_1 A_7 
Stack 16
B_11 C_11 D_4 D_5 
Stack 17
D_8 E_1 Z_114 Z_115 
Stack 18
C_12 E_0 C_5 E_4 
Stack 19
B_12 E_2 C_4 
