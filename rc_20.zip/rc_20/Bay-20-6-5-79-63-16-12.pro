Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_9 B_13 A_6 D_3 
Stack 1
A_7 D_9 D_7 E_8 
Stack 2
E_2 B_2 E_9 D_1 
Stack 3
B_8 C_8 A_5 A_0 
Stack 4
D_5 E_5 Z_100 Z_101 
Stack 5
E_11 C_10 C_4 C_2 
Stack 6
C_11 C_3 Z_102 Z_103 
Stack 7
Z_104 Z_105 B_6 Z_106 
Stack 8
B_4 E_3 E_0 Z_107 
Stack 9
E_1 E_10 Z_108 Z_109 
Stack 10
C_13 C_12 D_11 C_1 
Stack 11
A_4 B_9 A_1 A_8 
Stack 12
A_9 Z_110 A_3 D_10 
Stack 13
Z_111 Z_112 E_6 C_0 
Stack 14
Z_113 B_10 B_11 B_12 
Stack 15
B_1 B_3 D_8 D_0 
Stack 16
C_5 B_5 D_2 Z_114 
Stack 17
C_7 Z_115 D_4 E_7 
Stack 18
C_6 B_7 E_4 D_6 
Stack 19
B_0 A_2 E_12 
