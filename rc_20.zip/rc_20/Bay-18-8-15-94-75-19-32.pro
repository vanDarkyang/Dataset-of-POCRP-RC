Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
K_4 F_1 H_5 G_5 N_2 M_3 
Stack 1
J_0 Z_100 H_0 Z_101 I_0 Z_102 
Stack 2
J_5 F_6 I_7 Z_103 M_2 D_3 
Stack 3
Z_104 K_1 D_0 A_0 E_2 B_0 
Stack 4
C_1 E_5 M_1 Z_105 N_0 
Stack 5
H_4 I_5 G_2 Z_106 L_2 
Stack 6
E_0 I_6 O_2 B_1 I_1 
Stack 7
Z_107 H_1 Z_108 B_3 H_6 
Stack 8
F_2 F_3 B_2 E_4 I_3 
Stack 9
F_5 Z_109 Z_110 K_5 C_0 
Stack 10
G_6 A_1 Z_111 J_2 C_3 
Stack 11
C_2 Z_112 J_4 K_0 Z_113 
Stack 12
Z_114 H_3 G_3 K_2 N_1 
Stack 13
Z_115 O_0 G_4 J_3 I_4 
Stack 14
G_1 Z_116 F_0 D_1 F_4 
Stack 15
D_2 K_3 J_1 G_0 Z_117 
Stack 16
E_1 M_0 L_1 E_6 E_3 
Stack 17
L_0 O_1 H_2 Z_118 I_2 
