Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
A_0 Z_100 D_0 F_0 
Stack 1
H_1 F_4 I_2 F_3 
Stack 2
B_1 E_0 Z_101 D_3 
Stack 3
F_1 Z_102 J_2 A_2 
Stack 4
B_2 D_2 F_2 J_0 
Stack 5
Z_103 D_4 F_6 G_5 
Stack 6
Z_104 C_3 F_5 A_1 
Stack 7
C_0 D_1 Z_105 Z_106 
Stack 8
B_3 E_1 G_3 Z_107 
Stack 9
G_2 H_0 G_4 Z_108 
Stack 10
C_1 G_0 G_1 E_2 
Stack 11
I_0 I_1 Z_109 
Stack 12
B_0 J_1 C_2 
