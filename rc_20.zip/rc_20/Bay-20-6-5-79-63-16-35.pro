Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_8 C_1 D_8 D_9 
Stack 1
C_13 Z_100 C_2 B_4 
Stack 2
B_0 A_5 C_0 C_3 
Stack 3
A_0 B_3 E_6 D_10 
Stack 4
E_3 Z_101 D_7 E_4 
Stack 5
B_7 C_5 C_6 B_8 
Stack 6
D_5 D_13 Z_102 A_2 
Stack 7
B_12 D_2 Z_103 E_7 
Stack 8
Z_104 Z_105 A_7 E_8 
Stack 9
B_9 D_0 C_4 E_11 
Stack 10
B_1 B_6 Z_106 A_8 
Stack 11
A_9 Z_107 D_3 Z_108 
Stack 12
Z_109 B_11 C_11 E_0 
Stack 13
Z_110 A_6 D_6 E_9 
Stack 14
Z_111 B_2 C_7 C_10 
Stack 15
D_1 D_4 A_4 C_12 
Stack 16
Z_112 D_11 D_12 B_10 
Stack 17
A_1 E_5 Z_113 E_2 
Stack 18
Z_114 A_3 C_9 Z_115 
Stack 19
E_1 E_10 B_5 
