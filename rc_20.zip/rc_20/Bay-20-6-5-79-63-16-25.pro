Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_0 B_8 C_3 Z_100 
Stack 1
E_4 Z_101 D_4 B_5 
Stack 2
B_10 C_7 D_11 C_12 
Stack 3
B_7 Z_102 E_2 C_8 
Stack 4
C_14 C_9 C_4 C_1 
Stack 5
Z_103 D_2 A_10 A_5 
Stack 6
D_6 E_9 A_6 Z_104 
Stack 7
Z_105 Z_106 D_12 B_1 
Stack 8
A_2 B_4 A_9 E_10 
Stack 9
C_15 B_9 D_0 D_3 
Stack 10
Z_107 A_3 E_1 Z_108 
Stack 11
A_4 A_7 E_3 Z_109 
Stack 12
A_0 Z_110 B_6 B_2 
Stack 13
C_5 E_0 D_9 Z_111 
Stack 14
Z_112 C_10 Z_113 D_5 
Stack 15
D_8 E_7 B_0 D_10 
Stack 16
A_8 C_2 D_7 C_13 
Stack 17
Z_114 A_1 D_1 E_5 
Stack 18
E_8 Z_115 C_6 D_13 
Stack 19
E_6 C_11 B_3 
