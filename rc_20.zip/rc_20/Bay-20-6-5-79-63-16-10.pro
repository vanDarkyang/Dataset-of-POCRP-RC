Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
D_8 E_2 Z_100 E_9 
Stack 1
D_5 D_13 E_8 A_10 
Stack 2
C_7 B_1 Z_101 E_3 
Stack 3
Z_102 A_0 C_4 C_3 
Stack 4
C_12 E_4 A_4 Z_103 
Stack 5
A_5 D_10 A_7 Z_104 
Stack 6
E_6 D_1 D_3 E_7 
Stack 7
C_10 A_9 B_9 B_0 
Stack 8
C_9 C_11 C_1 C_13 
Stack 9
Z_105 A_6 C_6 E_1 
Stack 10
A_3 C_8 Z_106 A_1 
Stack 11
Z_107 B_3 E_5 Z_108 
Stack 12
C_0 D_4 A_11 Z_109 
Stack 13
C_14 B_8 A_8 A_2 
Stack 14
D_9 B_5 Z_110 D_2 
Stack 15
Z_111 D_12 E_0 E_10 
Stack 16
D_0 A_12 Z_112 C_5 
Stack 17
Z_113 Z_114 C_2 B_6 
Stack 18
B_4 Z_115 D_11 D_6 
Stack 19
B_7 D_7 B_2 
