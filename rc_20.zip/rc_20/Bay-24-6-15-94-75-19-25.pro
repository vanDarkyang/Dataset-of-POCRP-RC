Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
K_2 Z_100 Z_101 M_3 
Stack 1
L_4 Z_102 D_3 G_7 
Stack 2
N_2 H_6 J_0 H_4 
Stack 3
G_6 Z_103 B_0 Z_104 
Stack 4
Z_105 K_1 N_3 F_3 
Stack 5
D_1 Z_106 G_5 K_0 
Stack 6
G_8 E_0 E_1 H_5 
Stack 7
J_3 K_3 I_4 M_1 
Stack 8
I_6 I_7 J_1 I_0 
Stack 9
Z_107 B_2 L_5 L_1 
Stack 10
G_0 F_0 Z_108 C_3 
Stack 11
I_2 G_1 G_2 N_0 
Stack 12
E_4 D_0 A_1 C_1 
Stack 13
E_2 H_3 J_5 C_0 
Stack 14
F_4 G_3 Z_109 O_1 
Stack 15
Z_110 A_0 J_4 Z_111 
Stack 16
Z_112 I_5 Z_113 F_1 
Stack 17
I_1 I_3 F_2 H_1 
Stack 18
Z_114 L_0 B_1 A_2 
Stack 19
Z_115 J_2 L_2 M_0 
Stack 20
M_2 Z_116 H_2 O_0 
Stack 21
H_0 D_2 G_4 N_1 
Stack 22
Z_117 L_3 Z_118 
Stack 23
C_2 H_7 E_3 
