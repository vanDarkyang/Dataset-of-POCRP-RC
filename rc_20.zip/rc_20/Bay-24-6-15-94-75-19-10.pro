Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
M_0 M_2 F_1 Z_100 
Stack 1
C_1 D_3 N_1 K_4 
Stack 2
H_3 J_5 H_7 Z_101 
Stack 3
C_0 I_5 Z_102 Z_103 
Stack 4
Z_104 J_2 H_2 M_3 
Stack 5
Z_105 K_0 G_1 F_6 
Stack 6
Z_106 I_3 O_1 D_4 
Stack 7
F_7 Z_107 A_1 L_0 
Stack 8
I_4 H_1 E_3 E_0 
Stack 9
C_2 E_1 G_0 G_5 
Stack 10
Z_108 G_3 B_0 I_6 
Stack 11
E_2 M_4 Z_109 F_0 
Stack 12
F_3 Z_110 B_2 H_0 
Stack 13
I_1 G_6 N_2 F_4 
Stack 14
D_2 L_3 F_5 A_0 
Stack 15
Z_111 Z_112 Z_113 H_6 
Stack 16
B_1 D_0 K_2 O_0 
Stack 17
F_2 J_4 G_2 M_1 
Stack 18
Z_114 I_2 L_2 Z_115 
Stack 19
H_5 J_0 E_4 Z_116 
Stack 20
D_1 K_3 G_4 N_3 
Stack 21
N_0 H_8 L_1 Z_117 
Stack 22
Z_118 J_1 K_1 
Stack 23
H_4 I_0 J_3 
