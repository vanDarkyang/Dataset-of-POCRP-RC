Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
J_4 C_3 G_7 G_2 D_5 G_6 
Stack 1
Z_100 F_12 Z_101 Z_102 C_0 E_0 
Stack 2
B_3 A_4 H_4 F_7 D_0 I_8 
Stack 3
C_2 A_7 I_7 J_2 G_11 Z_103 
Stack 4
F_5 I_6 G_10 Z_104 H_5 Z_105 
Stack 5
A_1 J_3 E_8 D_7 G_1 
Stack 6
H_6 F_2 Z_106 C_1 J_6 
Stack 7
C_6 H_2 Z_107 D_4 F_1 
Stack 8
G_5 G_8 I_3 D_1 C_7 
Stack 9
G_9 A_0 C_4 J_5 Z_108 
Stack 10
Z_109 Z_110 B_4 D_3 B_2 
Stack 11
A_2 D_6 I_0 D_9 F_3 
Stack 12
D_2 F_0 G_3 F_4 Z_111 
Stack 13
Z_112 Z_113 J_1 C_10 H_0 
Stack 14
Z_114 A_3 E_2 I_9 E_9 
Stack 15
B_5 E_4 A_5 Z_115 I_1 
Stack 16
A_6 F_9 C_9 I_2 Z_116 
Stack 17
F_11 C_5 E_1 E_3 F_6 
Stack 18
H_1 Z_117 Z_118 I_5 E_7 
Stack 19
C_8 B_6 Z_119 Z_120 B_1 
Stack 20
Z_121 G_0 J_0 G_4 E_6 
Stack 21
E_10 I_4 B_0 Z_122 D_8 
Stack 22
E_5 F_8 F_10 H_3 Z_123 
