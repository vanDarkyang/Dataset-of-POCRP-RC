Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 F_3 I_0 Z_101 F_1 
Stack 1
E_0 D_4 H_3 D_5 I_2 
Stack 2
Z_102 H_2 C_1 B_2 E_5 
Stack 3
C_2 C_0 I_1 H_1 Z_103 
Stack 4
G_2 F_0 D_3 E_4 J_1 
Stack 5
F_2 Z_104 Z_105 Z_106 E_6 
Stack 6
D_1 C_4 A_0 B_0 B_1 
Stack 7
C_3 F_4 E_2 J_0 D_2 
Stack 8
D_0 H_0 Z_107 E_3 G_0 
Stack 9
G_1 Z_108 E_1 Z_109 J_2 
