Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 C_10 E_7 B_3 
Stack 1
D_1 A_10 Z_101 C_6 
Stack 2
E_11 C_7 E_5 C_3 
Stack 3
D_3 Z_102 E_10 D_4 
Stack 4
B_9 D_0 B_2 A_4 
Stack 5
B_5 Z_103 C_9 Z_104 
Stack 6
E_8 Z_105 B_6 A_1 
Stack 7
B_11 E_1 B_4 C_2 
Stack 8
B_0 Z_106 E_4 Z_107 
Stack 9
E_9 D_8 B_1 Z_108 
Stack 10
Z_109 Z_110 C_5 A_5 
Stack 11
D_9 B_12 B_7 A_0 
Stack 12
D_6 A_3 E_6 C_0 
Stack 13
C_12 Z_111 C_1 B_8 
Stack 14
B_10 E_2 E_3 E_13 
Stack 15
D_7 C_8 A_9 Z_112 
Stack 16
Z_113 Z_114 A_7 A_6 
Stack 17
E_12 Z_115 C_4 C_11 
Stack 18
D_2 D_10 E_0 B_13 
Stack 19
D_5 A_2 A_8 
