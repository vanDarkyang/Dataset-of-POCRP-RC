Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_3 B_1 A_4 C_8 D_4 
Stack 1
C_5 B_2 B_0 Z_100 B_6 
Stack 2
C_6 E_7 C_1 A_1 E_2 
Stack 3
D_3 D_7 C_2 C_0 C_9 
Stack 4
Z_101 A_0 E_0 C_3 Z_102 
Stack 5
A_3 Z_103 B_5 B_4 E_8 
Stack 6
D_2 C_4 Z_104 E_1 Z_105 
Stack 7
Z_106 Z_107 E_6 C_7 B_7 
Stack 8
B_3 D_8 Z_108 D_9 D_6 
Stack 9
Z_109 E_5 Z_110 D_5 D_0 
Stack 10
A_2 D_1 D_10 E_4 
