Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_2 G_2 C_4 F_2 Z_100 
Stack 1
C_0 E_0 B_2 D_3 F_3 
Stack 2
Z_101 G_5 D_4 Z_102 I_0 
Stack 3
C_6 J_1 Z_103 Z_104 G_4 
Stack 4
D_2 H_3 H_1 F_7 Z_105 
Stack 5
B_4 J_3 G_3 I_3 F_8 
Stack 6
G_0 Z_106 B_3 G_1 Z_107 
Stack 7
H_4 Z_108 C_1 I_1 F_0 
Stack 8
F_4 C_3 H_0 E_1 E_5 
Stack 9
B_1 D_5 E_2 E_3 Z_109 
Stack 10
F_1 D_1 Z_110 A_0 D_0 
Stack 11
F_6 J_0 I_2 C_2 H_2 
Stack 12
Z_111 Z_112 A_1 Z_113 J_2 
Stack 13
H_5 F_5 C_5 B_0 E_4 
