Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
B_2 A_5 D_8 E_1 B_4 B_12 
Stack 1
D_11 A_3 D_7 Z_100 B_5 C_5 
Stack 2
Z_101 Z_102 A_4 C_0 E_11 A_8 
Stack 3
Z_103 B_13 C_7 E_0 D_5 Z_104 
Stack 4
B_0 Z_105 A_1 E_2 D_1 
Stack 5
C_1 E_9 Z_106 D_4 E_5 
Stack 6
Z_107 C_8 C_12 C_10 D_9 
Stack 7
B_11 C_2 D_6 A_9 C_4 
Stack 8
E_4 D_10 Z_108 C_11 D_2 
Stack 9
B_14 D_3 B_9 A_6 E_8 
Stack 10
B_1 A_0 Z_109 Z_110 A_2 
Stack 11
B_6 C_3 B_7 E_7 C_6 
Stack 12
Z_111 E_3 Z_112 B_3 B_8 
Stack 13
E_6 D_12 B_10 A_7 Z_113 
Stack 14
D_0 Z_114 Z_115 C_9 E_10 
