Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
F_2 Z_100 I_0 F_3 K_3 N_1 
Stack 1
A_1 L_3 F_0 K_1 L_1 N_0 
Stack 2
E_0 Z_101 I_4 C_0 G_1 Z_102 
Stack 3
I_7 Z_103 G_4 O_0 Z_104 E_6 
Stack 4
Z_105 G_2 L_2 E_2 L_4 
Stack 5
F_1 C_2 I_2 H_5 Z_106 
Stack 6
C_1 L_0 E_3 B_2 J_0 
Stack 7
D_4 H_1 J_3 Z_107 Z_108 
Stack 8
J_4 Z_109 E_1 J_2 F_4 
Stack 9
H_3 Z_110 D_1 Z_111 D_2 
Stack 10
J_5 L_5 G_5 B_0 Z_112 
Stack 11
H_2 E_4 I_6 G_3 A_0 
Stack 12
Z_113 H_0 Z_114 C_3 Z_115 
Stack 13
Z_116 B_1 I_5 Z_117 K_0 
Stack 14
M_0 D_3 H_4 M_2 M_1 
Stack 15
C_4 O_2 I_1 J_1 K_2 
Stack 16
D_0 O_1 E_5 K_4 M_4 
Stack 17
I_3 G_0 Z_118 M_3 N_2 
