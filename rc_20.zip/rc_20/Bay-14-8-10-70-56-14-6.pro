Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
G_4 I_1 D_2 A_4 J_0 
Stack 1
A_2 E_5 C_3 H_4 C_5 
Stack 2
D_3 F_1 E_3 D_1 Z_100 
Stack 3
F_2 B_3 B_1 E_1 J_2 
Stack 4
Z_101 G_1 G_2 B_4 Z_102 
Stack 5
F_4 A_1 F_5 I_2 H_0 
Stack 6
C_0 A_3 Z_103 F_6 E_6 
Stack 7
Z_104 C_1 Z_105 H_1 I_0 
Stack 8
A_0 B_0 H_3 I_3 Z_106 
Stack 9
Z_107 H_2 G_5 E_4 E_2 
Stack 10
B_2 G_0 Z_108 F_0 Z_109 
Stack 11
I_4 C_2 G_3 F_3 D_4 
Stack 12
E_0 F_7 Z_110 Z_111 Z_112 
Stack 13
D_0 I_5 J_1 C_4 Z_113 
