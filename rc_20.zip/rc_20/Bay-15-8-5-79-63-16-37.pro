Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
A_4 Z_100 D_6 B_3 D_10 A_0 
Stack 1
A_7 D_0 D_2 E_9 Z_101 E_12 
Stack 2
A_10 C_11 A_3 A_11 E_5 C_4 
Stack 3
E_7 D_5 Z_102 A_1 E_10 A_5 
Stack 4
B_11 B_1 D_4 Z_103 E_8 
Stack 5
B_5 C_8 D_7 E_4 B_0 
Stack 6
D_1 Z_104 E_11 D_9 Z_105 
Stack 7
D_8 B_6 C_0 A_9 Z_106 
Stack 8
Z_107 D_3 C_9 Z_108 Z_109 
Stack 9
B_4 B_7 A_6 A_2 Z_110 
Stack 10
C_10 B_9 D_11 C_5 E_6 
Stack 11
B_8 E_13 B_10 Z_111 E_3 
Stack 12
Z_112 B_2 B_12 Z_113 A_8 
Stack 13
E_0 E_2 C_6 C_1 E_1 
Stack 14
Z_114 C_2 C_7 C_3 Z_115 
