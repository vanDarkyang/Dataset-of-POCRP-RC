Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
B_4 A_3 C_2 D_2 E_3 
Stack 1
A_2 B_2 D_5 D_1 B_3 
Stack 2
C_9 A_4 Z_100 Z_101 Z_102 
Stack 3
D_6 B_1 C_0 B_6 A_1 
Stack 4
Z_103 C_3 C_6 Z_104 Z_105 
Stack 5
Z_106 A_0 B_0 A_5 A_7 
Stack 6
E_1 Z_107 C_10 Z_108 C_4 
Stack 7
C_5 B_8 D_7 C_7 E_4 
Stack 8
D_3 B_7 C_8 D_4 D_0 
Stack 9
Z_109 E_0 A_6 E_5 E_6 
Stack 10
B_5 Z_110 C_1 E_2 
