Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
96
Number Of Shutout Containers
24
Yard Bay
Stack 0
F_7 H_1 C_2 D_5 Z_100 J_3 
Stack 1
B_1 G_2 B_0 Z_101 A_1 I_1 
Stack 2
G_1 Z_102 E_1 G_6 J_1 F_1 
Stack 3
D_11 E_8 Z_103 I_8 G_3 A_5 
Stack 4
D_1 I_9 C_10 H_5 B_9 G_9 
Stack 5
C_6 Z_104 J_4 H_7 I_5 
Stack 6
A_6 H_6 Z_105 Z_106 B_8 
Stack 7
Z_107 D_10 A_3 Z_108 Z_109 
Stack 8
J_0 H_4 E_3 D_0 C_0 
Stack 9
C_7 Z_110 E_4 B_5 B_7 
Stack 10
I_0 Z_111 J_5 B_3 C_5 
Stack 11
F_5 Z_112 J_2 D_6 Z_113 
Stack 12
I_7 Z_114 E_7 D_3 I_6 
Stack 13
F_3 B_2 F_4 A_4 B_4 
Stack 14
F_9 D_9 G_5 E_9 D_2 
Stack 15
G_7 C_4 D_4 C_3 G_8 
Stack 16
Z_115 Z_116 H_3 Z_117 Z_118 
Stack 17
G_4 Z_119 Z_120 G_10 C_8 
Stack 18
F_6 A_2 H_2 I_2 E_6 
Stack 19
Z_121 I_3 E_2 F_8 E_5 
Stack 20
C_1 G_11 E_0 D_8 I_4 
Stack 21
F_0 D_7 Z_122 A_0 G_0 
Stack 22
Z_123 H_0 B_6 F_2 C_9 
