Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
99
Number Of Shutout Containers
25
Yard Bay
Stack 0
F_2 K_2 M_4 L_2 M_1 E_1 
Stack 1
G_6 Z_100 Z_101 H_8 I_7 F_4 
Stack 2
I_1 I_10 L_3 C_3 I_5 H_1 
Stack 3
C_5 G_2 H_5 M_3 I_6 Z_102 
Stack 4
J_1 G_1 M_5 Z_103 D_3 
Stack 5
Z_104 A_1 D_5 Z_105 I_4 
Stack 6
E_0 A_4 I_3 I_9 J_4 
Stack 7
O_0 N_3 H_7 E_4 Z_106 
Stack 8
I_8 Z_107 H_9 K_7 A_0 
Stack 9
Z_108 G_3 Z_109 L_4 L_1 
Stack 10
I_2 Z_110 L_0 C_4 Z_111 
Stack 11
A_2 F_5 Z_112 Z_113 J_6 
Stack 12
L_6 Z_114 D_4 M_2 G_7 
Stack 13
E_3 O_1 N_2 E_6 Z_115 
Stack 14
F_1 I_0 B_0 M_0 K_1 
Stack 15
F_3 J_3 D_6 L_5 J_5 
Stack 16
K_5 B_1 H_6 Z_116 J_7 
Stack 17
H_2 H_0 N_4 E_2 D_2 
Stack 18
C_0 K_4 J_2 H_4 K_3 
Stack 19
H_3 A_3 G_0 D_0 Z_117 
Stack 20
G_5 J_0 Z_118 Z_119 F_0 
Stack 21
K_0 Z_120 N_0 C_2 K_6 
Stack 22
G_4 F_6 Z_121 Z_122 E_5 
Stack 23
Z_123 D_1 Z_124 N_1 C_1 
