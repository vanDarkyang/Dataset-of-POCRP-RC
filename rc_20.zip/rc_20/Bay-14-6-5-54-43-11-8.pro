Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_0 D_5 Z_100 E_1 
Stack 1
D_3 C_6 C_2 B_6 
Stack 2
E_5 Z_101 B_2 Z_102 
Stack 3
C_9 Z_103 Z_104 Z_105 
Stack 4
C_7 B_1 E_0 C_4 
Stack 5
B_8 D_0 A_6 B_3 
Stack 6
C_5 C_0 D_2 C_1 
Stack 7
A_5 A_3 A_4 B_7 
Stack 8
E_7 B_0 Z_106 Z_107 
Stack 9
D_6 D_8 C_8 A_1 
Stack 10
E_4 A_2 E_2 Z_108 
Stack 11
Z_109 D_4 E_6 B_4 
Stack 12
D_1 C_3 E_3 
Stack 13
B_5 D_7 Z_110 
