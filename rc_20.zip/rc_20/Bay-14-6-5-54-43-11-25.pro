Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
A_0 Z_100 E_5 C_8 
Stack 1
Z_101 A_3 D_2 D_0 
Stack 2
Z_102 C_7 Z_103 D_8 
Stack 3
C_4 A_6 B_4 E_3 
Stack 4
Z_104 E_0 E_2 D_4 
Stack 5
E_4 A_5 Z_105 A_2 
Stack 6
B_2 B_7 D_1 D_6 
Stack 7
B_1 D_5 A_1 Z_106 
Stack 8
C_9 D_3 B_0 B_3 
Stack 9
B_6 Z_107 C_3 Z_108 
Stack 10
E_6 C_2 E_1 C_5 
Stack 11
C_1 B_5 C_0 Z_109 
Stack 12
A_4 B_8 D_7 
Stack 13
C_6 A_7 Z_110 
