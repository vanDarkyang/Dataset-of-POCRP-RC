Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
75
Number Of Shutout Containers
19
Yard Bay
Stack 0
N_0 C_1 D_4 H_5 E_5 G_1 
Stack 1
F_1 H_3 H_4 G_5 M_4 Z_100 
Stack 2
D_1 L_2 M_1 L_1 J_0 H_0 
Stack 3
E_6 Z_101 D_3 K_0 M_2 B_0 
Stack 4
C_3 F_4 K_1 O_2 F_2 
Stack 5
Z_102 Z_103 N_1 D_5 J_6 
Stack 6
G_3 B_1 I_3 J_1 E_3 
Stack 7
J_7 M_0 Z_104 Z_105 Z_106 
Stack 8
O_1 F_0 E_2 F_3 Z_107 
Stack 9
F_5 L_0 I_1 K_4 Z_108 
Stack 10
J_5 Z_109 Z_110 Z_111 Z_112 
Stack 11
K_5 E_0 I_2 L_3 Z_113 
Stack 12
E_4 Z_114 Z_115 I_0 E_1 
Stack 13
A_0 G_6 J_2 G_2 H_1 
Stack 14
N_2 J_4 Z_116 Z_117 Z_118 
Stack 15
G_4 M_3 H_6 O_0 D_2 
Stack 16
D_0 H_2 J_3 A_1 C_0 
Stack 17
N_3 K_3 C_2 K_2 G_0 
