Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
Z_100 Z_101 Z_102 D_0 E_11 E_1 
Stack 1
B_13 Z_103 D_1 A_1 B_4 E_2 
Stack 2
D_4 Z_104 C_9 Z_105 C_1 B_5 
Stack 3
D_7 B_8 C_2 A_7 Z_106 C_3 
Stack 4
E_7 A_9 B_11 Z_107 E_0 
Stack 5
A_8 D_12 Z_108 B_2 Z_109 
Stack 6
Z_110 A_4 E_8 A_0 A_2 
Stack 7
C_12 B_6 B_9 B_7 D_3 
Stack 8
Z_111 E_3 B_12 E_9 E_10 
Stack 9
D_8 C_8 B_0 D_11 A_6 
Stack 10
E_5 C_11 C_13 C_0 Z_112 
Stack 11
C_7 D_10 B_10 Z_113 E_6 
Stack 12
D_6 C_10 D_9 E_4 D_2 
Stack 13
B_1 D_5 A_5 A_3 C_6 
Stack 14
Z_114 Z_115 C_5 C_4 B_3 
