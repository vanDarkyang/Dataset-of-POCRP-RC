Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
E_1 B_2 F_6 C_0 Z_100 
Stack 1
B_0 Z_101 Z_102 G_1 F_4 
Stack 2
B_1 F_5 G_2 I_3 J_0 
Stack 3
E_4 F_2 D_0 D_4 A_0 
Stack 4
D_2 G_3 A_1 D_1 E_6 
Stack 5
G_0 Z_103 H_3 H_1 I_1 
Stack 6
Z_104 Z_105 F_0 Z_106 E_2 
Stack 7
H_0 H_2 F_3 Z_107 E_0 
Stack 8
E_5 E_3 C_1 D_5 Z_108 
Stack 9
Z_109 I_0 F_1 I_2 D_3 
