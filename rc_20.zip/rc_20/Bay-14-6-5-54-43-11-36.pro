Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_0 C_10 Z_100 Z_101 
Stack 1
A_2 B_2 D_2 Z_102 
Stack 2
A_7 B_4 A_3 B_5 
Stack 3
A_6 D_3 D_4 C_0 
Stack 4
A_0 Z_103 C_4 D_1 
Stack 5
C_1 B_0 E_3 B_7 
Stack 6
E_5 C_8 Z_104 Z_105 
Stack 7
A_4 B_8 C_6 E_4 
Stack 8
B_3 A_9 Z_106 C_3 
Stack 9
A_5 A_8 B_1 E_2 
Stack 10
C_9 Z_107 C_7 Z_108 
Stack 11
B_6 Z_109 Z_110 D_5 
Stack 12
C_2 C_5 E_6 
Stack 13
D_0 E_1 A_1 
