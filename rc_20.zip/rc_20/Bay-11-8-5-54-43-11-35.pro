Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
43
Number Of Shutout Containers
11
Yard Bay
Stack 0
E_0 B_4 B_0 D_6 C_0 
Stack 1
A_6 A_4 C_8 B_2 A_0 
Stack 2
A_2 B_7 C_4 C_6 C_5 
Stack 3
Z_100 D_4 B_5 B_6 D_3 
Stack 4
E_4 Z_101 D_2 E_5 Z_102 
Stack 5
D_1 A_5 C_1 Z_103 A_1 
Stack 6
Z_104 Z_105 D_9 E_6 Z_106 
Stack 7
B_8 B_1 B_3 D_5 D_8 
Stack 8
Z_107 D_0 Z_108 C_3 E_7 
Stack 9
C_7 E_2 E_3 E_1 D_7 
Stack 10
A_3 Z_109 C_2 Z_110 
