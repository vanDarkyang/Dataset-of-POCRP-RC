Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 C_4 Z_101 J_3 C_1 
Stack 1
B_1 I_3 G_2 Z_102 E_6 
Stack 2
Z_103 F_8 I_0 F_2 Z_104 
Stack 3
C_3 D_3 E_3 Z_105 F_1 
Stack 4
J_2 F_3 A_2 Z_106 H_3 
Stack 5
A_0 Z_107 E_5 A_1 H_5 
Stack 6
D_0 B_2 I_4 D_2 C_0 
Stack 7
E_1 Z_108 F_7 C_2 Z_109 
Stack 8
F_5 G_4 A_3 E_0 E_4 
Stack 9
E_7 Z_110 Z_111 F_0 H_1 
Stack 10
H_0 E_2 B_3 H_2 G_3 
Stack 11
F_6 A_4 J_1 G_1 I_1 
Stack 12
J_0 H_4 F_4 Z_112 C_5 
Stack 13
B_0 G_0 I_2 D_1 Z_113 
