Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
36
Number Of Shutout Containers
10
Yard Bay
Stack 0
B_4 A_13 C_1 A_0 
Stack 1
A_2 C_4 B_5 Z_100 
Stack 2
A_10 C_2 A_6 Z_101 
Stack 3
Z_102 Z_103 C_0 B_2 
Stack 4
B_7 A_7 A_4 Z_104 
Stack 5
A_11 C_5 A_8 Z_105 
Stack 6
B_6 Z_106 Z_107 C_3 
Stack 7
C_11 A_9 A_5 A_12 
Stack 8
Z_108 C_7 B_3 B_1 
Stack 9
C_9 C_6 C_10 A_3 
Stack 10
B_0 B_8 Z_109 
Stack 11
A_14 C_8 A_1 
