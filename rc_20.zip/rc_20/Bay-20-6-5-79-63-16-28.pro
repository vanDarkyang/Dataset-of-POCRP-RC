Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
C_1 Z_100 A_6 E_5 
Stack 1
Z_101 Z_102 E_0 D_10 
Stack 2
Z_103 Z_104 Z_105 B_4 
Stack 3
D_11 B_10 C_13 C_2 
Stack 4
E_7 C_7 Z_106 B_2 
Stack 5
D_0 A_3 A_4 E_8 
Stack 6
Z_107 C_12 Z_108 A_0 
Stack 7
Z_109 C_5 B_7 D_3 
Stack 8
B_5 C_0 B_1 E_11 
Stack 9
D_12 D_4 B_11 Z_110 
Stack 10
B_3 C_3 B_9 C_10 
Stack 11
Z_111 Z_112 E_6 E_3 
Stack 12
E_9 A_2 A_9 C_8 
Stack 13
A_8 E_2 A_1 D_2 
Stack 14
D_7 A_5 B_8 B_0 
Stack 15
D_13 Z_113 C_9 D_5 
Stack 16
C_11 C_6 C_4 E_4 
Stack 17
B_6 D_9 Z_114 D_8 
Stack 18
D_1 E_1 E_10 B_12 
Stack 19
Z_115 D_6 A_7 
