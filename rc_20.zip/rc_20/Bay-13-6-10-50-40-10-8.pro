Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
40
Number Of Shutout Containers
10
Yard Bay
Stack 0
Z_100 B_2 Z_101 Z_102 
Stack 1
Z_103 J_0 H_1 I_3 
Stack 2
D_1 B_1 A_1 I_2 
Stack 3
B_3 D_4 I_0 C_1 
Stack 4
B_0 A_2 E_0 E_1 
Stack 5
G_0 C_3 C_2 D_3 
Stack 6
F_2 Z_104 E_2 F_1 
Stack 7
F_4 Z_105 F_5 Z_106 
Stack 8
D_0 Z_107 H_2 D_2 
Stack 9
Z_108 F_0 I_1 J_1 
Stack 10
G_2 H_0 G_1 G_3 
Stack 11
A_0 C_0 E_4 
Stack 12
E_3 Z_109 F_3 
