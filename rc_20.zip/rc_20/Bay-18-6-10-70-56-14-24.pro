Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
D_0 J_2 G_5 F_0 
Stack 1
D_4 I_3 Z_100 Z_101 
Stack 2
C_5 B_2 H_0 Z_102 
Stack 3
C_2 B_5 F_3 Z_103 
Stack 4
D_1 B_4 F_4 D_6 
Stack 5
G_3 Z_104 I_1 Z_105 
Stack 6
E_3 C_3 F_2 Z_106 
Stack 7
G_1 Z_107 H_3 D_3 
Stack 8
C_0 A_0 B_3 D_2 
Stack 9
Z_108 Z_109 A_4 G_0 
Stack 10
A_1 J_1 E_0 G_6 
Stack 11
E_4 Z_110 C_4 J_3 
Stack 12
H_1 J_0 A_2 C_6 
Stack 13
J_4 B_1 H_2 B_0 
Stack 14
F_1 G_4 I_0 C_1 
Stack 15
E_5 I_2 D_5 Z_111 
Stack 16
E_2 Z_112 E_1 
Stack 17
A_3 G_2 Z_113 
