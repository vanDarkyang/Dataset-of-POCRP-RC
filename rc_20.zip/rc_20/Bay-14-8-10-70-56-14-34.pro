Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
56
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 A_1 I_2 E_5 H_0 
Stack 1
F_4 D_2 C_1 Z_101 H_2 
Stack 2
B_0 H_5 B_4 Z_102 B_3 
Stack 3
B_1 H_1 Z_103 E_0 Z_104 
Stack 4
E_4 B_2 D_3 G_2 C_3 
Stack 5
E_1 C_0 Z_105 Z_106 Z_107 
Stack 6
G_3 H_6 D_5 Z_108 D_6 
Stack 7
I_0 F_8 D_0 H_4 F_1 
Stack 8
G_1 Z_109 E_2 I_1 C_4 
Stack 9
J_1 G_0 J_0 A_0 F_7 
Stack 10
C_5 Z_110 F_0 F_3 E_6 
Stack 11
F_6 F_2 D_4 C_6 Z_111 
Stack 12
F_5 A_2 Z_112 C_2 E_3 
Stack 13
J_2 H_3 B_5 Z_113 D_1 
