Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
63
Number Of Shutout Containers
16
Yard Bay
Stack 0
B_5 C_10 E_10 E_7 
Stack 1
E_9 C_4 Z_100 D_9 
Stack 2
A_7 Z_101 A_4 C_12 
Stack 3
A_5 Z_102 A_3 Z_103 
Stack 4
D_4 B_0 D_7 B_11 
Stack 5
Z_104 A_2 E_3 A_1 
Stack 6
C_5 D_5 B_8 B_9 
Stack 7
C_14 E_1 Z_105 Z_106 
Stack 8
C_0 C_9 C_1 B_10 
Stack 9
Z_107 E_2 B_4 C_7 
Stack 10
D_2 C_2 E_8 A_6 
Stack 11
Z_108 Z_109 Z_110 Z_111 
Stack 12
A_9 C_3 E_12 Z_112 
Stack 13
A_10 D_6 Z_113 Z_114 
Stack 14
Z_115 D_11 D_8 D_3 
Stack 15
A_0 B_1 C_11 B_6 
Stack 16
C_8 D_10 C_6 E_4 
Stack 17
C_13 E_5 D_0 B_3 
Stack 18
A_8 B_7 D_1 E_6 
Stack 19
B_2 E_11 E_0 
