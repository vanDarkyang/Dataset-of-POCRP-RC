Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 H_0 C_2 C_1 B_1 
Stack 1
C_0 Z_101 F_1 A_1 H_3 
Stack 2
E_1 G_0 E_2 D_0 F_0 
Stack 3
E_0 B_0 F_2 D_2 D_3 
Stack 4
G_2 Z_102 Z_103 G_1 Z_104 
Stack 5
Z_105 Z_106 Z_107 A_0 E_5 
Stack 6
Z_108 E_4 D_4 H_2 I_1 
Stack 7
Z_109 J_0 H_1 D_1 Z_110 
Stack 8
E_3 B_2 Z_111 C_3 F_3 
Stack 9
Z_112 Z_113 I_0 Z_114 I_2 
