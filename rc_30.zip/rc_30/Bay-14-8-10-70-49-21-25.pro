Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 C_3 A_1 H_0 Z_101 
Stack 1
H_1 D_1 H_4 Z_102 B_0 
Stack 2
B_3 Z_103 Z_104 E_2 I_3 
Stack 3
Z_105 J_1 C_1 Z_106 I_4 
Stack 4
Z_107 H_2 F_0 Z_108 A_2 
Stack 5
H_6 G_0 F_4 F_3 C_4 
Stack 6
A_0 Z_109 Z_110 E_1 H_5 
Stack 7
G_5 D_2 F_5 C_2 B_2 
Stack 8
F_1 J_0 D_0 E_3 G_2 
Stack 9
G_1 A_4 Z_111 Z_112 G_3 
Stack 10
Z_113 Z_114 E_0 I_2 F_2 
Stack 11
Z_115 Z_116 I_1 C_0 Z_117 
Stack 12
Z_118 D_3 I_0 A_3 B_1 
Stack 13
Z_119 H_3 G_4 Z_120 F_6 
