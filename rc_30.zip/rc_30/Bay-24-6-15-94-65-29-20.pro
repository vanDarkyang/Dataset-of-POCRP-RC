Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
C_3 F_0 F_4 L_3 
Stack 1
Z_100 Z_101 Z_102 Z_103 
Stack 2
Z_104 L_2 M_0 L_1 
Stack 3
E_4 Z_105 F_1 Z_106 
Stack 4
K_4 I_1 Z_107 Z_108 
Stack 5
E_0 K_0 L_5 K_3 
Stack 6
Z_109 Z_110 G_0 Z_111 
Stack 7
Z_112 E_5 Z_113 E_1 
Stack 8
D_0 I_5 J_1 I_4 
Stack 9
J_0 Z_114 Z_115 F_2 
Stack 10
K_5 C_2 G_2 N_1 
Stack 11
Z_116 D_1 H_2 F_3 
Stack 12
H_3 M_1 J_4 Z_117 
Stack 13
Z_118 Z_119 C_1 H_1 
Stack 14
B_0 N_2 I_3 E_3 
Stack 15
Z_120 Z_121 Z_122 I_2 
Stack 16
H_0 C_4 O_0 B_1 
Stack 17
G_4 C_0 Z_123 A_1 
Stack 18
G_3 K_2 Z_124 F_6 
Stack 19
Z_125 I_0 J_3 O_1 
Stack 20
Z_126 A_0 L_4 M_2 
Stack 21
L_0 J_2 G_5 Z_127 
Stack 22
Z_128 K_1 N_0 
Stack 23
E_2 F_5 G_1 
