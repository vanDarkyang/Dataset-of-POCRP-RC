Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
J_1 A_0 I_1 F_2 
Stack 1
E_3 D_1 I_0 F_1 
Stack 2
D_0 F_4 F_0 H_0 
Stack 3
J_0 Z_100 C_2 D_2 
Stack 4
Z_101 A_2 I_2 C_4 
Stack 5
Z_102 Z_103 E_1 Z_104 
Stack 6
Z_105 Z_106 D_3 Z_107 
Stack 7
Z_108 Z_109 G_2 C_1 
Stack 8
G_3 F_3 B_0 E_4 
Stack 9
B_1 Z_110 Z_111 E_0 
Stack 10
C_3 G_0 Z_112 E_2 
Stack 11
Z_113 C_0 A_1 
Stack 12
H_1 G_1 Z_114 
