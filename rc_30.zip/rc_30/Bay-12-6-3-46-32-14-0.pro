Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 Z_101 A_4 Z_102 
Stack 1
Z_103 Z_104 A_3 Z_105 
Stack 2
A_8 Z_106 C_6 C_1 
Stack 3
A_9 C_2 Z_107 Z_108 
Stack 4
C_3 A_10 A_7 C_7 
Stack 5
A_2 B_2 B_6 Z_109 
Stack 6
B_1 A_0 B_3 C_5 
Stack 7
C_4 B_9 C_8 Z_110 
Stack 8
A_6 C_9 B_8 B_5 
Stack 9
Z_111 B_10 B_0 Z_112 
Stack 10
C_0 A_1 B_7 
Stack 11
B_4 Z_113 A_5 
