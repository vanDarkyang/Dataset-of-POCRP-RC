Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 C_4 J_0 Z_101 B_1 
Stack 1
D_1 J_2 G_2 A_3 E_5 
Stack 2
F_7 C_2 Z_102 B_0 G_1 
Stack 3
J_1 H_1 E_0 Z_103 C_0 
Stack 4
F_0 Z_104 H_0 Z_105 Z_106 
Stack 5
F_6 E_1 B_2 Z_107 E_6 
Stack 6
D_0 F_3 B_3 A_1 E_2 
Stack 7
Z_108 H_2 Z_109 D_2 C_3 
Stack 8
B_4 D_3 I_2 Z_110 J_3 
Stack 9
E_3 Z_111 H_3 H_4 I_3 
Stack 10
Z_112 Z_113 F_5 F_2 Z_114 
Stack 11
G_0 Z_115 Z_116 Z_117 E_4 
Stack 12
A_2 Z_118 C_1 F_4 I_0 
Stack 13
I_1 F_1 Z_119 A_0 Z_120 
