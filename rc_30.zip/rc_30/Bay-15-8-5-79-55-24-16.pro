Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_8 C_1 Z_100 E_2 B_7 B_0 
Stack 1
B_1 C_6 E_5 E_10 C_3 Z_101 
Stack 2
A_1 Z_102 Z_103 E_8 A_6 E_9 
Stack 3
D_6 Z_104 Z_105 A_5 A_3 C_10 
Stack 4
A_4 D_11 B_6 A_8 D_9 
Stack 5
Z_106 D_2 Z_107 Z_108 Z_109 
Stack 6
C_4 D_5 Z_110 Z_111 C_2 
Stack 7
Z_112 A_7 C_7 E_1 E_3 
Stack 8
D_0 D_3 C_0 A_2 C_5 
Stack 9
B_4 D_10 Z_113 D_8 D_1 
Stack 10
B_8 D_7 Z_114 E_6 Z_115 
Stack 11
E_0 E_7 Z_116 C_9 Z_117 
Stack 12
Z_118 D_4 B_10 Z_119 B_3 
Stack 13
D_12 B_2 A_0 Z_120 Z_121 
Stack 14
B_9 Z_122 B_5 E_4 Z_123 
