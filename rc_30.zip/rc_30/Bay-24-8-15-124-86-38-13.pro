Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
F_1 E_4 O_1 F_2 C_1 G_1 
Stack 1
Z_100 D_4 I_2 H_7 L_3 A_3 
Stack 2
E_2 C_2 N_3 G_3 N_4 H_4 
Stack 3
Z_101 E_0 F_3 C_0 K_0 I_4 
Stack 4
D_0 J_0 Z_102 F_0 D_3 
Stack 5
Z_103 I_5 Z_104 Z_105 Z_106 
Stack 6
A_2 A_1 Z_107 Z_108 N_0 
Stack 7
Z_109 D_1 F_5 Z_110 I_6 
Stack 8
E_6 K_3 Z_111 H_2 Z_112 
Stack 9
H_6 M_3 Z_113 G_2 Z_114 
Stack 10
K_5 M_2 G_6 E_5 A_4 
Stack 11
H_8 I_1 Z_115 O_3 M_1 
Stack 12
C_5 L_2 O_2 G_4 Z_116 
Stack 13
G_7 F_4 Z_117 Z_118 D_2 
Stack 14
J_2 Z_119 J_1 Z_120 Z_121 
Stack 15
I_0 Z_122 H_5 O_0 H_3 
Stack 16
Z_123 Z_124 L_1 K_1 B_0 
Stack 17
Z_125 Z_126 C_4 A_0 Z_127 
Stack 18
Z_128 I_3 J_4 G_0 Z_129 
Stack 19
K_4 L_4 Z_130 Z_131 N_2 
Stack 20
Z_132 G_5 Z_133 Z_134 E_3 
Stack 21
C_3 J_5 L_0 H_1 Z_135 
Stack 22
J_3 N_1 Z_136 Z_137 O_4 
Stack 23
H_0 E_1 K_2 M_0 L_5 
