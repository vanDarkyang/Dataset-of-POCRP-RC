Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_3 C_4 A_10 A_7 
Stack 1
A_12 A_4 Z_100 A_6 
Stack 2
A_1 C_1 B_5 A_5 
Stack 3
Z_101 B_4 A_2 B_9 
Stack 4
Z_102 C_3 Z_103 B_1 
Stack 5
B_8 A_8 A_0 A_11 
Stack 6
Z_104 B_7 C_5 C_2 
Stack 7
Z_105 Z_106 Z_107 Z_108 
Stack 8
B_2 C_0 B_0 B_6 
Stack 9
A_9 Z_109 Z_110 B_10 
Stack 10
A_3 Z_111 Z_112 
Stack 11
C_7 Z_113 C_6 
