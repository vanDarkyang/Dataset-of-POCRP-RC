Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
G_3 G_1 D_0 Z_100 Z_101 
Stack 1
Z_102 Z_103 Z_104 H_1 Z_105 
Stack 2
B_2 G_4 Z_106 J_2 I_2 
Stack 3
B_1 E_2 C_4 I_1 I_4 
Stack 4
C_5 E_1 G_0 J_1 B_3 
Stack 5
D_4 H_2 J_0 C_0 D_2 
Stack 6
E_4 E_0 B_4 A_0 Z_107 
Stack 7
Z_108 Z_109 Z_110 I_0 Z_111 
Stack 8
F_2 H_0 F_5 G_2 Z_112 
Stack 9
Z_113 E_5 Z_114 E_3 F_1 
Stack 10
Z_115 C_2 F_0 I_3 Z_116 
Stack 11
Z_117 F_3 A_1 Z_118 Z_119 
Stack 12
D_1 Z_120 F_4 C_1 C_6 
Stack 13
H_3 D_5 D_3 C_3 B_0 
