Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_0 Z_100 Z_101 G_0 
Stack 1
F_0 Z_102 F_2 H_1 
Stack 2
Z_103 B_3 Z_104 A_2 
Stack 3
J_2 G_1 Z_105 I_1 
Stack 4
C_4 Z_106 Z_107 B_0 
Stack 5
E_2 E_7 Z_108 Z_109 
Stack 6
Z_110 G_4 C_0 I_3 
Stack 7
F_3 Z_111 A_0 C_5 
Stack 8
Z_112 C_3 Z_113 I_2 
Stack 9
Z_114 D_1 G_6 Z_115 
Stack 10
J_1 D_2 Z_116 Z_117 
Stack 11
A_1 A_3 C_2 G_5 
Stack 12
E_5 B_2 E_3 D_3 
Stack 13
J_0 Z_118 E_1 E_4 
Stack 14
C_1 F_1 E_0 H_3 
Stack 15
G_3 B_1 Z_119 G_2 
Stack 16
H_0 Z_120 I_0 
Stack 17
E_6 F_4 H_2 
