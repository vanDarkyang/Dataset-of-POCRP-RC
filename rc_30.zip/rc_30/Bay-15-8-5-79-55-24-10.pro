Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_7 C_4 D_10 A_2 C_9 B_2 
Stack 1
C_2 B_5 Z_100 Z_101 C_6 E_3 
Stack 2
Z_102 D_3 B_3 D_8 D_9 Z_103 
Stack 3
A_1 Z_104 E_0 D_11 B_10 A_4 
Stack 4
Z_105 Z_106 Z_107 Z_108 B_0 
Stack 5
D_1 E_9 C_5 Z_109 A_5 
Stack 6
B_4 D_7 E_2 D_4 E_11 
Stack 7
B_11 Z_110 C_0 Z_111 D_6 
Stack 8
Z_112 Z_113 E_8 C_8 E_5 
Stack 9
B_13 C_3 B_7 Z_114 C_1 
Stack 10
B_9 Z_115 D_5 Z_116 A_3 
Stack 11
Z_117 D_2 Z_118 B_8 B_1 
Stack 12
E_7 E_4 Z_119 D_0 B_14 
Stack 13
E_6 Z_120 Z_121 Z_122 E_1 
Stack 14
A_0 Z_123 B_12 B_6 E_10 
