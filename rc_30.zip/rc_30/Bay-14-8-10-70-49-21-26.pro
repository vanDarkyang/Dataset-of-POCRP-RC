Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
A_1 G_2 C_3 Z_100 Z_101 
Stack 1
C_0 E_0 Z_102 Z_103 Z_104 
Stack 2
A_2 G_7 Z_105 E_4 I_0 
Stack 3
C_5 Z_106 G_6 E_2 G_4 
Stack 4
Z_107 H_2 H_0 Z_108 E_6 
Stack 5
B_2 J_2 G_3 I_3 Z_109 
Stack 6
G_0 Z_110 B_1 G_1 Z_111 
Stack 7
H_3 G_5 Z_112 I_1 F_0 
Stack 8
F_2 C_2 Z_113 E_1 E_7 
Stack 9
B_0 D_3 E_3 Z_114 Z_115 
Stack 10
F_1 D_1 J_1 Z_116 D_0 
Stack 11
F_4 J_0 I_2 C_1 H_1 
Stack 12
Z_117 D_2 A_0 Z_118 Z_119 
Stack 13
H_4 F_3 C_4 Z_120 E_5 
