Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
D_6 D_3 Z_100 Z_101 Z_102 E_9 
Stack 1
Z_103 Z_104 E_1 Z_105 Z_106 I_6 
Stack 2
Z_107 C_6 D_1 E_6 Z_108 A_5 
Stack 3
E_7 H_6 B_2 I_3 Z_109 E_2 
Stack 4
Z_110 J_5 F_4 F_6 H_2 Z_111 
Stack 5
E_0 Z_112 I_7 Z_113 G_7 
Stack 6
I_5 Z_114 Z_115 Z_116 D_8 
Stack 7
G_3 A_6 I_8 F_3 Z_117 
Stack 8
B_0 A_0 D_7 C_3 H_1 
Stack 9
H_4 Z_118 D_0 G_2 H_3 
Stack 10
Z_119 Z_120 Z_121 Z_122 C_2 
Stack 11
Z_123 C_1 Z_124 C_10 G_0 
Stack 12
A_4 H_7 A_2 E_8 J_4 
Stack 13
J_0 G_1 Z_125 B_3 C_5 
Stack 14
E_5 J_6 B_1 D_5 G_5 
Stack 15
F_5 F_0 Z_126 C_4 C_7 
Stack 16
G_8 B_4 E_3 Z_127 D_10 
Stack 17
J_3 Z_128 D_9 Z_129 Z_130 
Stack 18
C_0 Z_131 H_5 C_9 Z_132 
Stack 19
I_1 F_1 A_3 J_2 E_4 
Stack 20
I_2 Z_133 Z_134 H_0 J_1 
Stack 21
C_8 G_4 G_6 D_2 I_4 
Stack 22
F_2 D_4 I_0 A_1 Z_135 
