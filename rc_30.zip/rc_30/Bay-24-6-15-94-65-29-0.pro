Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
O_0 Z_100 L_1 G_0 
Stack 1
Z_101 D_3 K_1 K_3 
Stack 2
Z_102 E_0 J_1 G_1 
Stack 3
C_3 K_5 J_2 C_2 
Stack 4
O_1 F_0 Z_103 B_1 
Stack 5
Z_104 Z_105 Z_106 Z_107 
Stack 6
G_5 J_3 J_4 H_5 
Stack 7
M_0 Z_108 Z_109 Z_110 
Stack 8
D_1 C_0 N_2 H_4 
Stack 9
Z_111 L_0 B_0 Z_112 
Stack 10
K_2 Z_113 D_2 Z_114 
Stack 11
H_3 H_2 Z_115 Z_116 
Stack 12
D_4 G_2 Z_117 E_2 
Stack 13
M_1 B_2 J_5 G_3 
Stack 14
Z_118 A_0 M_4 F_2 
Stack 15
I_0 E_3 G_7 N_1 
Stack 16
F_3 M_3 Z_119 I_3 
Stack 17
I_2 A_1 Z_120 J_0 
Stack 18
Z_121 G_4 M_2 Z_122 
Stack 19
H_1 C_1 Z_123 K_0 
Stack 20
H_0 I_1 Z_124 H_6 
Stack 21
K_4 Z_125 Z_126 Z_127 
Stack 22
Z_128 D_0 E_1 
Stack 23
F_1 G_6 N_0 
