Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 Z_101 H_1 Z_102 
Stack 1
K_1 L_1 E_3 L_0 
Stack 2
Z_103 D_1 K_2 Z_104 
Stack 3
H_5 D_0 Z_105 Z_106 
Stack 4
F_2 I_2 F_3 F_4 
Stack 5
H_4 Z_107 A_1 Z_108 
Stack 6
E_1 O_1 A_0 M_2 
Stack 7
M_3 Z_109 I_4 H_0 
Stack 8
Z_110 C_2 Z_111 J_2 
Stack 9
Z_112 Z_113 B_1 F_1 
Stack 10
Z_114 G_5 F_5 N_0 
Stack 11
B_0 Z_115 K_0 Z_116 
Stack 12
G_7 A_2 K_4 G_2 
Stack 13
O_0 Z_117 G_3 F_0 
Stack 14
G_4 M_0 H_2 Z_118 
Stack 15
J_1 H_3 E_0 Z_119 
Stack 16
B_2 Z_120 E_2 N_1 
Stack 17
Z_121 K_3 I_3 G_6 
Stack 18
E_4 G_1 J_3 Z_122 
Stack 19
Z_123 L_2 Z_124 I_0 
Stack 20
J_0 I_6 Z_125 Z_126 
Stack 21
I_1 G_0 C_0 M_1 
Stack 22
Z_127 C_1 Z_128 
Stack 23
I_5 J_4 I_7 
