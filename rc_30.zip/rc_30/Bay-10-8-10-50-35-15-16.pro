Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
B_0 Z_100 G_3 G_1 E_3 
Stack 1
H_0 C_0 Z_101 J_2 F_0 
Stack 2
Z_102 D_1 Z_103 H_2 Z_104 
Stack 3
G_4 Z_105 Z_106 Z_107 Z_108 
Stack 4
I_0 G_2 C_3 Z_109 E_1 
Stack 5
F_2 D_0 Z_110 H_1 E_4 
Stack 6
A_1 D_2 C_1 A_0 C_4 
Stack 7
Z_111 B_1 J_1 F_3 C_2 
Stack 8
J_0 Z_112 F_1 Z_113 E_0 
Stack 9
H_3 E_2 G_0 Z_114 B_2 
