Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
J_5 Z_100 G_4 Z_101 D_3 G_3 
Stack 1
B_0 F_12 H_2 D_7 Z_102 E_0 
Stack 2
B_5 A_3 H_9 Z_103 D_0 I_6 
Stack 3
Z_104 A_6 I_5 J_3 Z_105 Z_106 
Stack 4
F_6 I_4 Z_107 H_8 H_10 J_2 
Stack 5
Z_108 J_4 E_6 D_5 G_1 
Stack 6
H_11 F_3 J_1 C_0 J_7 
Stack 7
C_1 H_4 A_0 Z_109 F_2 
Stack 8
G_2 G_5 Z_110 D_1 C_2 
Stack 9
Z_111 A_1 Z_112 J_6 B_3 
Stack 10
E_4 G_6 Z_113 Z_114 B_4 
Stack 11
A_2 D_4 I_0 D_9 F_4 
Stack 12
D_2 F_0 Z_115 F_5 C_4 
Stack 13
F_1 H_7 J_0 Z_116 H_0 
Stack 14
I_3 Z_117 Z_118 Z_119 E_7 
Stack 15
B_6 E_3 A_4 D_8 I_1 
Stack 16
A_5 F_9 Z_120 I_2 Z_121 
Stack 17
F_11 Z_122 E_1 E_2 F_7 
Stack 18
H_3 H_1 Z_123 Z_124 Z_125 
Stack 19
C_3 Z_126 E_5 H_6 B_2 
Stack 20
Z_127 G_0 Z_128 Z_129 Z_130 
Stack 21
Z_131 Z_132 B_1 Z_133 D_6 
Stack 22
Z_134 F_8 F_10 H_5 Z_135 
