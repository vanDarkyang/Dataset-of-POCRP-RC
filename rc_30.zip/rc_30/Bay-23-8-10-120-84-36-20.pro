Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
B_3 H_0 Z_100 Z_101 A_4 H_5 
Stack 1
C_4 B_0 Z_102 Z_103 Z_104 A_7 
Stack 2
J_4 E_5 I_0 C_2 I_5 Z_105 
Stack 3
I_3 Z_106 Z_107 H_6 D_6 A_5 
Stack 4
C_0 D_4 E_7 F_7 G_0 Z_108 
Stack 5
B_1 Z_109 J_5 Z_110 H_2 
Stack 6
D_2 Z_111 E_6 C_6 I_4 
Stack 7
Z_112 B_6 Z_113 J_1 H_1 
Stack 8
E_3 A_6 I_7 G_6 Z_114 
Stack 9
Z_115 A_3 H_4 D_5 Z_116 
Stack 10
Z_117 F_8 Z_118 G_1 Z_119 
Stack 11
I_1 Z_120 H_3 J_7 Z_121 
Stack 12
D_0 B_7 F_6 F_3 B_2 
Stack 13
E_9 Z_122 J_3 A_1 Z_123 
Stack 14
G_2 Z_124 Z_125 B_5 Z_126 
Stack 15
E_2 J_6 E_10 Z_127 Z_128 
Stack 16
A_8 F_5 G_3 Z_129 E_1 
Stack 17
D_7 A_0 Z_130 D_3 I_6 
Stack 18
G_5 F_0 F_1 Z_131 C_5 
Stack 19
E_8 G_4 C_1 I_2 J_0 
Stack 20
C_7 E_4 E_0 I_8 D_1 
Stack 21
Z_132 Z_133 F_2 F_4 B_4 
Stack 22
J_2 C_3 Z_134 A_2 Z_135 
