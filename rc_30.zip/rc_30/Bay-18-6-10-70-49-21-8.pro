Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_2 G_4 E_2 Z_100 
Stack 1
D_4 Z_101 F_2 Z_102 
Stack 2
Z_103 C_4 J_0 B_4 
Stack 3
B_0 I_0 C_3 D_0 
Stack 4
F_3 A_2 G_1 B_3 
Stack 5
Z_104 D_1 H_3 H_2 
Stack 6
E_7 Z_105 Z_106 Z_107 
Stack 7
G_3 H_1 A_0 E_1 
Stack 8
Z_108 Z_109 Z_110 Z_111 
Stack 9
D_3 Z_112 F_4 E_6 
Stack 10
I_1 F_0 E_5 Z_113 
Stack 11
Z_114 E_0 I_2 Z_115 
Stack 12
Z_116 Z_117 A_1 B_1 
Stack 13
J_2 G_0 G_2 E_4 
Stack 14
B_2 Z_118 J_1 Z_119 
Stack 15
C_2 C_1 H_0 H_5 
Stack 16
C_0 I_3 E_3 
Stack 17
F_1 Z_120 H_4 
