Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 Z_101 I_1 E_5 E_11 B_6 
Stack 1
C_8 G_3 Z_102 H_2 Z_103 D_9 
Stack 2
Z_104 B_3 G_1 D_5 G_4 Z_105 
Stack 3
G_5 D_7 C_2 Z_106 A_2 D_2 
Stack 4
Z_107 Z_108 I_5 B_1 G_0 A_1 
Stack 5
C_1 B_8 F_3 B_5 I_6 
Stack 6
J_5 G_6 B_7 Z_109 Z_110 
Stack 7
Z_111 Z_112 Z_113 H_4 H_5 
Stack 8
E_7 C_7 I_4 Z_114 H_7 
Stack 9
B_4 H_1 D_6 J_0 A_4 
Stack 10
Z_115 E_12 F_0 E_10 J_2 
Stack 11
Z_116 I_2 C_4 Z_117 D_3 
Stack 12
E_0 E_1 A_0 H_6 Z_118 
Stack 13
E_8 I_0 J_3 Z_119 C_6 
Stack 14
Z_120 E_3 I_3 C_5 Z_121 
Stack 15
D_1 E_4 Z_122 D_4 I_8 
Stack 16
J_4 I_7 Z_123 C_9 Z_124 
Stack 17
Z_125 Z_126 Z_127 E_2 Z_128 
Stack 18
F_6 D_0 Z_129 F_4 B_2 
Stack 19
H_0 B_0 Z_130 G_2 E_9 
Stack 20
E_6 A_3 C_3 D_8 Z_131 
Stack 21
Z_132 Z_133 Z_134 F_5 F_2 
Stack 22
J_1 H_3 C_0 F_1 Z_135 
