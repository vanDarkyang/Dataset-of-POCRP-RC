Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
E_0 Z_100 Z_101 C_0 A_1 
Stack 1
Z_102 Z_103 Z_104 G_2 F_4 
Stack 2
B_1 F_5 G_3 I_2 J_0 
Stack 3
E_3 F_2 Z_105 Z_106 A_0 
Stack 4
Z_107 G_4 A_2 D_0 E_5 
Stack 5
G_0 Z_108 H_2 H_1 Z_109 
Stack 6
J_1 B_0 F_0 Z_110 E_1 
Stack 7
H_0 Z_111 F_3 G_5 Z_112 
Stack 8
E_4 E_2 C_1 D_1 G_1 
Stack 9
Z_113 I_0 F_1 I_1 Z_114 
