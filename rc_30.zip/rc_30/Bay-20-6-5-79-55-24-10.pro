Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_6 E_7 Z_100 C_8 
Stack 1
Z_101 D_8 Z_102 Z_103 
Stack 2
A_7 Z_104 E_1 D_10 
Stack 3
A_2 D_0 A_3 B_7 
Stack 4
D_4 C_3 B_9 Z_105 
Stack 5
D_2 C_2 A_5 A_9 
Stack 6
B_3 D_3 Z_106 E_9 
Stack 7
B_8 Z_107 D_9 D_7 
Stack 8
C_0 A_1 Z_108 E_4 
Stack 9
B_11 Z_109 B_10 C_1 
Stack 10
Z_110 D_11 A_11 A_6 
Stack 11
A_4 E_0 D_6 B_0 
Stack 12
E_5 B_2 A_10 Z_111 
Stack 13
Z_112 Z_113 C_7 Z_114 
Stack 14
Z_115 C_5 Z_116 E_8 
Stack 15
Z_117 Z_118 Z_119 B_1 
Stack 16
B_4 E_3 Z_120 Z_121 
Stack 17
D_5 Z_122 D_1 Z_123 
Stack 18
C_4 E_6 A_0 A_8 
Stack 19
E_2 B_6 B_5 
