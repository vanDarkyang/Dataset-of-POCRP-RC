Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
G_2 J_5 C_1 Z_100 
Stack 1
G_4 E_1 C_2 H_1 
Stack 2
D_1 D_3 J_3 F_2 
Stack 3
G_5 I_1 D_0 Z_101 
Stack 4
H_7 J_4 K_2 Z_102 
Stack 5
H_3 D_2 H_6 H_4 
Stack 6
E_0 Z_103 Z_104 Z_105 
Stack 7
Z_106 K_1 J_0 Z_107 
Stack 8
L_0 Z_108 Z_109 B_1 
Stack 9
I_4 G_1 K_5 E_2 
Stack 10
H_8 Z_110 Z_111 Z_112 
Stack 11
Z_113 Z_114 I_3 Z_115 
Stack 12
Z_116 J_2 Z_117 H_5 
Stack 13
G_3 F_6 K_3 M_1 
Stack 14
B_0 H_0 Z_118 N_1 
Stack 15
F_1 F_3 F_4 E_4 
Stack 16
J_1 I_0 N_2 M_0 
Stack 17
Z_119 J_6 A_0 Z_120 
Stack 18
Z_121 O_0 F_5 Z_122 
Stack 19
L_1 Z_123 A_1 E_3 
Stack 20
K_4 H_2 I_2 Z_124 
Stack 21
Z_125 N_0 F_0 Z_126 
Stack 22
Z_127 K_0 G_0 
Stack 23
Z_128 C_0 C_3 
