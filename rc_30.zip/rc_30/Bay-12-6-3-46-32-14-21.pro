Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 A_3 A_1 B_5 
Stack 1
C_6 Z_101 Z_102 C_2 
Stack 2
C_7 B_2 C_1 Z_103 
Stack 3
A_4 A_6 C_3 C_5 
Stack 4
B_8 A_0 Z_104 A_2 
Stack 5
A_5 C_8 Z_105 B_0 
Stack 6
Z_106 Z_107 B_3 Z_108 
Stack 7
A_8 B_1 C_0 B_4 
Stack 8
Z_109 Z_110 B_6 Z_111 
Stack 9
B_11 Z_112 C_4 A_7 
Stack 10
A_9 B_10 Z_113 
Stack 11
B_9 B_12 B_7 
