Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
D_2 F_2 C_0 G_3 Z_100 
Stack 1
H_0 A_1 Z_101 D_1 F_3 
Stack 2
F_5 Z_102 E_0 G_1 J_1 
Stack 3
Z_103 F_1 Z_104 Z_105 Z_106 
Stack 4
B_2 J_0 A_2 H_3 Z_107 
Stack 5
G_0 Z_108 H_1 I_1 Z_109 
Stack 6
D_0 F_0 Z_110 E_1 F_4 
Stack 7
A_0 I_0 Z_111 H_2 Z_112 
Stack 8
C_3 B_1 G_4 C_1 G_2 
Stack 9
D_3 B_0 Z_113 Z_114 C_2 
