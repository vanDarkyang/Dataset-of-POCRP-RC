Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
9
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
A_0 G_1 F_1 C_0 Z_100 
Stack 1
E_4 Z_101 C_4 C_3 D_4 
Stack 2
I_0 D_3 D_0 H_0 Z_102 
Stack 3
B_1 C_2 C_1 Z_103 E_1 
Stack 4
D_2 F_0 Z_104 Z_105 E_3 
Stack 5
B_2 E_2 G_0 Z_106 F_3 
Stack 6
Z_107 D_1 Z_108 F_2 A_1 
Stack 7
H_1 Z_109 Z_110 G_2 Z_111 
Stack 8
B_0 B_3 H_2 Z_112 Z_113 
Stack 9
I_1 B_4 A_2 E_0 Z_114 
