Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
A_1 Z_100 E_0 O_1 N_3 H_5 
Stack 1
N_1 Z_101 N_2 M_1 I_0 H_3 
Stack 2
F_3 O_0 I_1 I_7 G_2 G_5 
Stack 3
Z_102 I_5 L_0 Z_103 Z_104 Z_105 
Stack 4
Z_106 F_2 Z_107 Z_108 A_3 
Stack 5
H_8 F_1 Z_109 F_4 F_8 
Stack 6
Z_110 F_6 D_1 B_4 Z_111 
Stack 7
Z_112 Z_113 K_7 Z_114 L_3 
Stack 8
C_1 Z_115 H_7 G_4 M_0 
Stack 9
B_2 Z_116 H_9 Z_117 K_5 
Stack 10
Z_118 F_5 J_0 Z_119 Z_120 
Stack 11
E_4 Z_121 B_1 Z_122 M_2 
Stack 12
H_1 Z_123 H_0 Z_124 H_4 
Stack 13
H_10 F_7 E_3 J_3 Z_125 
Stack 14
F_0 Z_126 K_2 K_4 G_6 
Stack 15
C_3 C_0 D_5 E_1 Z_127 
Stack 16
B_0 Z_128 C_2 L_2 D_0 
Stack 17
K_0 G_1 K_3 O_2 I_3 
Stack 18
G_0 D_3 I_4 Z_129 K_6 
Stack 19
Z_130 Z_131 D_4 B_3 J_1 
Stack 20
E_2 H_2 Z_132 D_2 Z_133 
Stack 21
I_6 H_6 K_1 A_0 Z_134 
Stack 22
Z_135 L_1 A_2 Z_136 G_3 
Stack 23
N_0 Z_137 J_2 J_4 I_2 
