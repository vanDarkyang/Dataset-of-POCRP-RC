Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_9 A_10 B_8 Z_100 D_2 Z_101 
Stack 1
D_5 B_10 D_9 Z_102 Z_103 D_8 
Stack 2
D_1 A_3 B_0 B_4 C_4 C_2 
Stack 3
B_6 Z_104 A_2 B_9 E_9 C_9 
Stack 4
Z_105 Z_106 D_3 C_1 E_4 
Stack 5
B_5 Z_107 A_0 Z_108 Z_109 
Stack 6
Z_110 A_4 C_7 C_3 A_8 
Stack 7
A_7 A_11 D_10 Z_111 Z_112 
Stack 8
E_3 Z_113 B_2 Z_114 E_10 
Stack 9
C_6 C_8 E_7 D_7 D_4 
Stack 10
B_7 Z_115 Z_116 C_5 A_6 
Stack 11
A_1 Z_117 E_6 D_6 E_8 
Stack 12
E_1 A_5 C_0 B_1 Z_118 
Stack 13
E_2 Z_119 Z_120 B_3 D_0 
Stack 14
Z_121 E_5 E_0 Z_122 Z_123 
