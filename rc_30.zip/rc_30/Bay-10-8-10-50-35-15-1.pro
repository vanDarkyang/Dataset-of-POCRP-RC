Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
A_1 Z_100 C_1 H_1 I_1 
Stack 1
E_2 Z_101 G_2 A_0 D_0 
Stack 2
F_1 G_0 Z_102 E_0 H_2 
Stack 3
E_3 G_4 Z_103 Z_104 Z_105 
Stack 4
C_2 D_2 Z_106 G_1 J_0 
Stack 5
C_3 I_0 Z_107 F_2 F_3 
Stack 6
B_0 F_4 Z_108 E_1 I_2 
Stack 7
C_0 Z_109 F_0 D_1 Z_110 
Stack 8
Z_111 D_3 G_3 E_4 Z_112 
Stack 9
H_0 A_2 Z_113 Z_114 J_1 
