Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_2 Z_100 Z_101 A_7 
Stack 1
C_3 C_4 A_5 C_8 
Stack 2
B_1 B_6 B_9 Z_102 
Stack 3
A_10 Z_103 A_3 A_8 
Stack 4
C_6 Z_104 B_7 Z_105 
Stack 5
A_1 A_9 Z_106 B_10 
Stack 6
B_4 A_0 Z_107 Z_108 
Stack 7
Z_109 A_6 Z_110 B_8 
Stack 8
B_2 C_1 C_7 B_0 
Stack 9
C_0 C_5 Z_111 B_3 
Stack 10
C_9 C_2 Z_112 
Stack 11
A_4 Z_113 B_5 
