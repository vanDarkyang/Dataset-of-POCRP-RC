Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
A_4 Z_100 D_5 J_0 
Stack 1
Z_101 I_4 I_0 I_3 
Stack 2
A_3 G_4 C_2 B_1 
Stack 3
Z_102 Z_103 G_3 C_3 
Stack 4
H_1 E_1 Z_104 Z_105 
Stack 5
Z_106 F_5 C_0 I_2 
Stack 6
F_6 Z_107 E_0 F_0 
Stack 7
Z_108 D_2 E_3 A_1 
Stack 8
C_4 Z_109 I_5 F_3 
Stack 9
H_3 Z_110 E_2 Z_111 
Stack 10
D_0 A_2 H_0 Z_112 
Stack 11
F_4 Z_113 F_2 G_0 
Stack 12
D_3 D_1 I_1 G_2 
Stack 13
Z_114 B_2 D_4 C_1 
Stack 14
Z_115 B_0 Z_116 F_1 
Stack 15
B_3 A_0 Z_117 B_4 
Stack 16
Z_118 G_1 Z_119 
Stack 17
Z_120 H_4 H_2 
