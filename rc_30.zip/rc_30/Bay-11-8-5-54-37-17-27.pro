Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
A_7 C_1 E_5 A_5 E_0 
Stack 1
D_7 Z_100 Z_101 E_1 B_5 
Stack 2
C_2 C_6 A_1 Z_102 B_3 
Stack 3
A_8 C_0 Z_103 A_2 E_2 
Stack 4
C_3 Z_104 A_3 E_6 E_3 
Stack 5
C_5 B_2 Z_105 Z_106 B_4 
Stack 6
Z_107 Z_108 D_2 D_3 D_5 
Stack 7
D_1 B_1 D_0 A_0 Z_109 
Stack 8
D_4 E_4 Z_110 Z_111 Z_112 
Stack 9
A_4 Z_113 D_6 C_4 Z_114 
Stack 10
A_6 Z_115 Z_116 B_0 
