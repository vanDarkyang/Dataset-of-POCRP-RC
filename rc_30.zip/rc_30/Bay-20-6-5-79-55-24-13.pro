Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_7 B_8 Z_100 C_10 
Stack 1
C_3 E_5 B_7 D_7 
Stack 2
Z_101 E_0 C_8 A_1 
Stack 3
D_1 Z_102 C_6 E_8 
Stack 4
B_2 C_5 E_3 Z_103 
Stack 5
A_2 D_6 C_1 A_9 
Stack 6
D_9 D_10 D_12 Z_104 
Stack 7
B_5 D_11 D_2 E_7 
Stack 8
Z_105 B_10 Z_106 C_2 
Stack 9
A_8 E_9 Z_107 C_9 
Stack 10
D_8 A_6 A_4 B_3 
Stack 11
Z_108 Z_109 Z_110 E_1 
Stack 12
A_7 Z_111 Z_112 E_4 
Stack 13
Z_113 C_4 B_0 Z_114 
Stack 14
D_4 E_2 B_4 D_0 
Stack 15
Z_115 B_1 Z_116 B_9 
Stack 16
Z_117 A_0 B_6 E_6 
Stack 17
A_3 D_5 C_0 A_5 
Stack 18
Z_118 Z_119 D_3 Z_120 
Stack 19
Z_121 Z_122 Z_123 
