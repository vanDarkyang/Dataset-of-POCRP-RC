Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_3 E_0 C_3 B_9 
Stack 1
C_1 D_1 C_4 A_0 
Stack 2
Z_100 Z_101 Z_102 E_5 
Stack 3
D_5 B_0 A_5 E_1 
Stack 4
Z_103 C_2 Z_104 Z_105 
Stack 5
B_6 B_8 Z_106 A_3 
Stack 6
Z_107 Z_108 B_4 A_1 
Stack 7
D_0 Z_109 E_7 E_2 
Stack 8
D_4 Z_110 A_2 D_6 
Stack 9
Z_111 E_4 Z_112 B_2 
Stack 10
A_6 E_6 B_3 D_2 
Stack 11
B_5 B_7 B_1 Z_113 
Stack 12
C_0 A_4 E_3 
Stack 13
Z_114 Z_115 Z_116 
