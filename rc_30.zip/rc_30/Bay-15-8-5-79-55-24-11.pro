Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_7 E_8 Z_100 Z_101 C_2 Z_102 
Stack 1
Z_103 C_7 B_2 A_9 E_1 B_3 
Stack 2
B_0 A_5 A_8 Z_104 C_1 E_6 
Stack 3
C_9 Z_105 A_1 E_2 E_7 B_1 
Stack 4
Z_106 A_10 Z_107 Z_108 Z_109 
Stack 5
A_12 E_3 E_9 D_9 A_0 
Stack 6
Z_110 A_4 D_0 C_0 Z_111 
Stack 7
A_11 Z_112 C_5 D_3 Z_113 
Stack 8
Z_114 Z_115 E_4 B_11 C_8 
Stack 9
Z_116 Z_117 E_0 D_8 D_2 
Stack 10
B_8 C_6 D_6 C_4 B_10 
Stack 11
B_5 B_7 D_4 D_5 B_9 
Stack 12
Z_118 Z_119 E_5 Z_120 Z_121 
Stack 13
C_3 Z_122 Z_123 A_7 A_2 
Stack 14
B_6 B_4 A_3 D_1 A_6 
