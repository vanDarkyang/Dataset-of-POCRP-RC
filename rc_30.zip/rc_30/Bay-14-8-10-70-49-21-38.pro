Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 H_1 Z_101 Z_102 E_2 
Stack 1
Z_103 D_1 E_3 I_0 Z_104 
Stack 2
Z_105 D_4 Z_106 B_3 J_2 
Stack 3
C_5 I_1 F_0 E_5 G_4 
Stack 4
A_0 Z_107 E_4 H_3 G_3 
Stack 5
I_2 Z_108 B_0 B_2 C_2 
Stack 6
Z_109 Z_110 I_4 C_6 Z_111 
Stack 7
J_1 Z_112 B_1 E_0 D_2 
Stack 8
C_1 G_5 E_1 Z_113 F_2 
Stack 9
G_1 Z_114 Z_115 Z_116 A_1 
Stack 10
C_0 G_0 A_2 Z_117 Z_118 
Stack 11
C_4 D_5 D_0 H_0 J_3 
Stack 12
G_2 Z_119 J_0 H_2 C_3 
Stack 13
Z_120 F_1 G_6 D_3 I_3 
