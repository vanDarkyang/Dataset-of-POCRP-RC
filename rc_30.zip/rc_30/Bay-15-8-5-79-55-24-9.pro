Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 E_10 B_2 Z_101 Z_102 E_6 
Stack 1
C_3 A_7 B_4 Z_103 D_2 C_4 
Stack 2
C_8 B_8 A_4 C_1 A_1 B_6 
Stack 3
Z_104 Z_105 C_0 D_4 Z_106 C_11 
Stack 4
A_3 D_5 C_12 B_0 E_11 
Stack 5
E_9 A_2 A_8 D_1 B_5 
Stack 6
Z_107 C_2 D_8 Z_108 Z_109 
Stack 7
A_5 Z_110 D_9 E_8 A_0 
Stack 8
Z_111 D_6 E_3 E_4 B_1 
Stack 9
Z_112 E_2 C_6 C_10 E_5 
Stack 10
Z_113 C_9 C_5 Z_114 D_7 
Stack 11
D_0 E_7 Z_115 E_0 A_9 
Stack 12
B_3 Z_116 B_7 D_10 Z_117 
Stack 13
Z_118 E_1 Z_119 C_7 Z_120 
Stack 14
Z_121 Z_122 Z_123 D_3 A_6 
