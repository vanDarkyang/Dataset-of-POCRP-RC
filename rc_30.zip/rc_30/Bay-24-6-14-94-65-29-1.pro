Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
14
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
E_0 Z_100 F_1 L_4 
Stack 1
Z_101 L_3 I_6 Z_102 
Stack 2
M_2 J_2 Z_103 Z_104 
Stack 3
M_3 Z_105 Z_106 Z_107 
Stack 4
J_4 F_5 H_0 D_1 
Stack 5
Z_108 J_6 I_3 K_0 
Stack 6
H_1 F_2 I_1 Z_109 
Stack 7
L_2 I_5 G_1 D_4 
Stack 8
C_0 L_1 H_2 Z_110 
Stack 9
M_0 Z_111 K_2 Z_112 
Stack 10
I_0 J_5 Z_113 E_1 
Stack 11
K_1 B_0 Z_114 D_2 
Stack 12
E_2 L_0 F_0 H_3 
Stack 13
A_1 F_3 Z_115 J_3 
Stack 14
J_1 Z_116 Z_117 A_0 
Stack 15
Z_118 Z_119 D_3 N_0 
Stack 16
B_2 C_1 Z_120 N_1 
Stack 17
Z_121 H_4 G_0 Z_122 
Stack 18
I_4 Z_123 Z_124 F_6 
Stack 19
Z_125 N_2 Z_126 G_3 
Stack 20
D_0 I_2 J_0 H_5 
Stack 21
H_7 A_2 B_1 Z_127 
Stack 22
G_4 M_1 G_2 
Stack 23
H_6 F_4 Z_128 
