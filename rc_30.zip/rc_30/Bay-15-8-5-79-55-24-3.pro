Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_1 Z_100 Z_101 C_10 A_7 E_9 
Stack 1
D_2 E_4 Z_102 Z_103 D_5 B_0 
Stack 2
A_9 Z_104 C_0 D_0 Z_105 E_6 
Stack 3
A_1 E_5 C_7 D_9 B_10 Z_106 
Stack 4
E_2 B_6 D_12 A_3 E_0 
Stack 5
Z_107 Z_108 A_4 A_8 Z_109 
Stack 6
Z_110 A_2 C_6 C_5 Z_111 
Stack 7
A_5 D_6 B_7 Z_112 Z_113 
Stack 8
Z_114 D_10 A_6 Z_115 Z_116 
Stack 9
Z_117 Z_118 B_4 B_5 B_9 
Stack 10
D_7 B_1 B_3 B_2 E_3 
Stack 11
C_4 D_11 C_8 Z_119 D_4 
Stack 12
Z_120 C_2 E_1 A_0 B_8 
Stack 13
C_9 Z_121 E_8 C_1 C_3 
Stack 14
D_3 D_8 Z_122 E_7 Z_123 
