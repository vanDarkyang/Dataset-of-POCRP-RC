Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
D_0 Z_100 A_5 I_7 Z_101 D_1 
Stack 1
G_4 B_4 B_6 Z_102 H_5 F_6 
Stack 2
E_0 F_8 H_2 Z_103 Z_104 I_1 
Stack 3
Z_105 Z_106 F_3 D_8 E_2 C_1 
Stack 4
Z_107 A_6 Z_108 G_3 A_0 H_3 
Stack 5
J_4 B_0 C_2 D_4 J_3 
Stack 6
H_1 B_1 J_5 Z_109 G_5 
Stack 7
Z_110 B_2 Z_111 F_0 H_4 
Stack 8
Z_112 A_4 I_4 Z_113 A_3 
Stack 9
C_8 Z_114 Z_115 F_5 Z_116 
Stack 10
G_6 C_0 C_3 H_6 I_6 
Stack 11
D_6 F_4 Z_117 A_1 H_7 
Stack 12
Z_118 B_5 J_2 B_3 Z_119 
Stack 13
Z_120 H_0 Z_121 I_0 Z_122 
Stack 14
G_0 D_7 C_6 Z_123 Z_124 
Stack 15
I_3 J_0 G_2 F_1 I_2 
Stack 16
F_9 A_2 C_4 E_4 E_9 
Stack 17
C_7 I_5 Z_125 F_7 E_5 
Stack 18
F_2 J_6 Z_126 D_9 D_2 
Stack 19
E_3 Z_127 C_5 D_3 Z_128 
Stack 20
Z_129 Z_130 J_1 Z_131 D_5 
Stack 21
Z_132 E_1 E_6 E_8 G_1 
Stack 22
Z_133 A_7 E_7 Z_134 Z_135 
