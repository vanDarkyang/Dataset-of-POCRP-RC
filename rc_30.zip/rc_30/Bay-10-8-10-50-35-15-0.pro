Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
H_0 E_2 F_0 Z_100 C_0 
Stack 1
E_1 Z_101 G_3 F_3 C_4 
Stack 2
B_1 B_0 G_0 I_1 Z_102 
Stack 3
F_1 G_2 G_4 Z_103 Z_104 
Stack 4
F_2 Z_105 Z_106 Z_107 E_3 
Stack 5
Z_108 Z_109 Z_110 H_1 Z_111 
Stack 6
C_1 I_2 A_0 B_2 Z_112 
Stack 7
D_1 E_0 D_0 J_1 F_4 
Stack 8
C_2 A_1 H_2 G_1 D_2 
Stack 9
J_0 Z_113 Z_114 I_0 C_3 
