Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
J_0 Z_100 G_2 C_3 Z_101 
Stack 1
E_2 G_5 E_5 Z_102 Z_103 
Stack 2
C_1 Z_104 Z_105 C_2 G_4 
Stack 3
F_0 A_3 Z_106 D_5 E_3 
Stack 4
C_0 G_1 A_1 Z_107 Z_108 
Stack 5
H_3 E_4 H_4 H_1 Z_109 
Stack 6
D_1 A_2 B_0 Z_110 F_3 
Stack 7
C_4 D_6 B_1 B_2 Z_111 
Stack 8
J_1 D_4 Z_112 F_4 Z_113 
Stack 9
G_3 Z_114 E_0 D_0 D_2 
Stack 10
B_3 Z_115 F_2 Z_116 H_2 
Stack 11
B_4 E_1 I_0 Z_117 A_0 
Stack 12
G_0 Z_118 F_1 I_2 I_1 
Stack 13
D_3 Z_119 G_6 Z_120 H_0 
