Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 C_0 Z_101 Z_102 
Stack 1
A_4 Z_103 C_5 C_7 
Stack 2
E_6 E_5 E_3 B_0 
Stack 3
E_2 Z_104 C_8 D_2 
Stack 4
C_1 A_0 C_3 Z_105 
Stack 5
B_6 C_4 Z_106 B_3 
Stack 6
E_0 D_0 Z_107 B_5 
Stack 7
A_5 C_2 D_7 D_4 
Stack 8
Z_108 D_6 Z_109 Z_110 
Stack 9
E_4 B_2 Z_111 A_3 
Stack 10
C_6 Z_112 D_3 Z_113 
Stack 11
Z_114 Z_115 E_1 B_4 
Stack 12
B_1 D_5 A_2 
Stack 13
Z_116 A_1 D_1 
