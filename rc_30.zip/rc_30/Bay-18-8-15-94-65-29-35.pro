Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 D_2 Z_101 N_3 E_0 O_0 
Stack 1
Z_102 I_1 H_4 Z_103 N_2 I_0 
Stack 2
H_2 C_3 D_1 H_1 Z_104 K_3 
Stack 3
Z_105 I_4 Z_106 J_0 F_1 L_2 
Stack 4
G_3 Z_107 Z_108 I_2 I_3 
Stack 5
D_4 Z_109 L_3 I_5 L_0 
Stack 6
Z_110 M_0 Z_111 Z_112 G_0 
Stack 7
D_0 Z_113 B_1 J_2 G_4 
Stack 8
Z_114 K_1 O_2 M_1 G_2 
Stack 9
Z_115 Z_116 J_1 F_4 F_5 
Stack 10
H_5 L_1 B_0 C_2 N_0 
Stack 11
B_2 E_3 A_0 Z_117 Z_118 
Stack 12
H_0 Z_119 K_2 Z_120 C_1 
Stack 13
F_3 C_0 Z_121 D_3 G_6 
Stack 14
Z_122 Z_123 G_5 Z_124 Z_125 
Stack 15
Z_126 A_1 E_1 H_3 G_7 
Stack 16
Z_127 N_1 F_2 O_1 J_3 
Stack 17
E_2 K_0 G_1 F_0 Z_128 
