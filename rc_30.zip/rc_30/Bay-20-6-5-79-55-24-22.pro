Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
E_1 D_9 C_13 Z_100 
Stack 1
Z_101 A_4 Z_102 B_5 
Stack 2
Z_103 Z_104 D_6 C_0 
Stack 3
D_4 E_4 A_5 Z_105 
Stack 4
E_7 C_7 C_4 E_0 
Stack 5
A_7 C_10 Z_106 D_7 
Stack 6
Z_107 Z_108 Z_109 A_2 
Stack 7
C_11 C_9 Z_110 D_1 
Stack 8
B_1 D_2 A_6 E_10 
Stack 9
D_5 Z_111 A_3 Z_112 
Stack 10
Z_113 Z_114 B_3 Z_115 
Stack 11
C_6 D_0 A_0 E_6 
Stack 12
D_3 C_8 Z_116 Z_117 
Stack 13
Z_118 C_1 E_9 C_5 
Stack 14
A_9 Z_119 D_8 B_4 
Stack 15
E_11 C_14 Z_120 E_2 
Stack 16
A_1 E_8 B_2 E_3 
Stack 17
C_12 B_6 E_5 Z_121 
Stack 18
Z_122 B_7 Z_123 C_2 
Stack 19
A_8 B_0 C_3 
