Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
C_2 G_1 H_3 Z_100 
Stack 1
F_5 I_3 H_2 Z_101 
Stack 2
Z_102 E_0 E_2 A_2 
Stack 3
D_0 Z_103 Z_104 I_5 
Stack 4
Z_105 F_2 D_2 E_4 
Stack 5
H_1 D_1 E_1 Z_106 
Stack 6
Z_107 Z_108 J_3 H_0 
Stack 7
B_1 I_1 J_1 G_4 
Stack 8
G_3 F_3 Z_109 G_2 
Stack 9
G_0 Z_110 Z_111 C_5 
Stack 10
G_5 A_3 Z_112 I_4 
Stack 11
I_2 C_0 F_0 C_1 
Stack 12
F_4 J_2 B_0 Z_113 
Stack 13
A_1 H_4 Z_114 F_1 
Stack 14
Z_115 Z_116 J_0 C_4 
Stack 15
A_0 Z_117 Z_118 E_3 
Stack 16
B_2 C_3 C_6 
Stack 17
Z_119 Z_120 I_0 
