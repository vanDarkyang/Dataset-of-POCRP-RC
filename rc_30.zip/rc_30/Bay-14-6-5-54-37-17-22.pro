Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 E_2 C_5 Z_101 
Stack 1
C_4 D_0 C_0 D_2 
Stack 2
Z_102 A_1 C_3 C_2 
Stack 3
B_1 Z_103 B_4 Z_104 
Stack 4
Z_105 B_2 Z_106 D_7 
Stack 5
C_6 E_4 B_7 D_8 
Stack 6
Z_107 A_5 Z_108 D_4 
Stack 7
Z_109 A_0 Z_110 A_3 
Stack 8
D_3 C_7 D_5 B_3 
Stack 9
D_1 E_0 Z_111 Z_112 
Stack 10
E_5 D_6 Z_113 B_0 
Stack 11
Z_114 B_6 Z_115 Z_116 
Stack 12
E_1 E_3 A_2 
Stack 13
C_1 B_5 A_4 
