Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_9 E_8 Z_100 C_9 D_3 C_8 
Stack 1
A_8 E_7 Z_101 A_0 Z_102 Z_103 
Stack 2
D_10 A_6 A_7 Z_104 Z_105 Z_106 
Stack 3
C_11 Z_107 D_4 E_3 D_5 E_5 
Stack 4
Z_108 E_1 Z_109 E_2 Z_110 
Stack 5
C_7 B_9 Z_111 B_8 C_10 
Stack 6
D_1 C_2 A_3 C_4 C_3 
Stack 7
Z_112 A_4 C_6 Z_113 D_8 
Stack 8
D_2 B_0 Z_114 Z_115 A_2 
Stack 9
B_10 D_0 Z_116 C_0 D_11 
Stack 10
C_12 D_7 A_5 B_5 C_5 
Stack 11
B_2 D_6 Z_117 Z_118 A_1 
Stack 12
Z_119 B_6 B_1 B_3 E_9 
Stack 13
Z_120 Z_121 B_4 E_0 Z_122 
Stack 14
Z_123 E_6 B_7 C_1 E_4 
