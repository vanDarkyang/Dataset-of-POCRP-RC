Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
K_3 F_7 H_8 M_4 N_1 C_5 
Stack 1
A_0 I_1 C_0 H_2 Z_100 L_4 
Stack 2
J_3 M_0 D_4 C_1 F_5 N_2 
Stack 3
Z_101 Z_102 G_0 G_5 I_3 Z_103 
Stack 4
F_2 Z_104 J_2 Z_105 Z_106 
Stack 5
Z_107 Z_108 Z_109 H_0 D_0 
Stack 6
Z_110 Z_111 G_6 L_3 B_1 
Stack 7
Z_112 J_0 C_2 Z_113 F_6 
Stack 8
C_3 H_5 D_1 O_0 Z_114 
Stack 9
Z_115 Z_116 E_2 N_3 Z_117 
Stack 10
B_0 M_2 E_4 L_0 Z_118 
Stack 11
N_0 Z_119 H_1 Z_120 K_5 
Stack 12
Z_121 Z_122 D_5 D_3 Z_123 
Stack 13
Z_124 A_3 C_4 A_1 B_4 
Stack 14
Z_125 Z_126 H_7 L_2 O_1 
Stack 15
D_2 H_4 B_5 M_3 K_0 
Stack 16
Z_127 G_4 E_1 E_3 M_1 
Stack 17
G_1 E_0 K_1 F_3 H_6 
Stack 18
I_0 G_3 F_0 O_2 F_1 
Stack 19
Z_128 Z_129 H_3 Z_130 B_2 
Stack 20
G_2 Z_131 Z_132 Z_133 B_3 
Stack 21
J_4 Z_134 G_7 Z_135 N_4 
Stack 22
Z_136 I_2 Z_137 K_2 K_4 
Stack 23
J_5 J_1 F_4 A_2 L_1 
