Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
C_2 E_3 F_2 I_1 
Stack 1
D_2 Z_100 G_3 I_3 
Stack 2
H_2 Z_101 I_2 G_2 
Stack 3
E_4 Z_102 Z_103 Z_104 
Stack 4
A_1 Z_105 Z_106 H_3 
Stack 5
E_1 C_1 A_0 D_0 
Stack 6
E_0 A_2 Z_107 Z_108 
Stack 7
D_1 I_0 G_1 G_0 
Stack 8
H_1 Z_109 Z_110 C_3 
Stack 9
C_0 Z_111 H_0 B_0 
Stack 10
E_2 B_1 Z_112 Z_113 
Stack 11
F_0 Z_114 J_0 
Stack 12
G_4 F_3 F_1 
