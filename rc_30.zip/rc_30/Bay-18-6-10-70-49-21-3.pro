Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
G_0 Z_100 I_2 A_1 
Stack 1
A_3 Z_101 C_0 Z_102 
Stack 2
A_2 F_0 F_4 E_3 
Stack 3
Z_103 Z_104 Z_105 Z_106 
Stack 4
G_2 F_7 G_3 I_0 
Stack 5
C_3 D_1 Z_107 I_4 
Stack 6
C_1 B_2 E_6 Z_108 
Stack 7
D_5 C_2 F_6 G_4 
Stack 8
D_4 Z_109 F_3 H_0 
Stack 9
E_4 F_5 F_1 B_0 
Stack 10
J_2 D_3 Z_110 D_0 
Stack 11
E_5 E_1 Z_111 Z_112 
Stack 12
I_3 E_0 Z_113 H_1 
Stack 13
I_1 C_4 J_1 D_2 
Stack 14
Z_114 Z_115 F_2 A_0 
Stack 15
Z_116 B_1 Z_117 Z_118 
Stack 16
Z_119 Z_120 J_0 
Stack 17
H_2 G_1 E_2 
