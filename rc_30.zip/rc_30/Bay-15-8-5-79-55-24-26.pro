Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_1 C_0 C_4 C_6 C_1 A_5 
Stack 1
Z_100 D_1 D_0 Z_101 A_0 B_4 
Stack 2
Z_102 B_6 Z_103 Z_104 C_9 A_3 
Stack 3
Z_105 E_0 C_11 D_4 B_8 B_7 
Stack 4
Z_106 B_1 D_8 D_9 D_3 
Stack 5
Z_107 Z_108 A_8 Z_109 A_7 
Stack 6
A_2 D_10 D_2 E_3 E_5 
Stack 7
Z_110 C_2 Z_111 Z_112 E_2 
Stack 8
B_0 Z_113 Z_114 E_4 A_12 
Stack 9
Z_115 Z_116 B_5 C_3 A_4 
Stack 10
Z_117 Z_118 Z_119 Z_120 E_7 
Stack 11
D_5 C_12 E_1 E_6 A_11 
Stack 12
C_8 C_5 D_6 A_10 C_7 
Stack 13
E_8 D_7 B_2 A_9 C_10 
Stack 14
A_6 B_3 Z_121 Z_122 Z_123 
