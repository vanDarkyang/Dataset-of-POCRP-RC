Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_4 Z_100 A_3 C_5 
Stack 1
Z_101 C_9 C_7 E_0 
Stack 2
A_5 A_2 A_4 E_5 
Stack 3
E_6 Z_102 B_2 C_1 
Stack 4
A_0 E_2 D_3 C_8 
Stack 5
A_6 C_2 B_5 Z_103 
Stack 6
B_6 Z_104 Z_105 C_0 
Stack 7
Z_106 D_0 E_3 E_1 
Stack 8
C_3 Z_107 D_4 D_1 
Stack 9
Z_108 Z_109 Z_110 C_6 
Stack 10
C_4 Z_111 Z_112 Z_113 
Stack 11
D_5 A_1 Z_114 B_0 
Stack 12
D_2 Z_115 B_1 
Stack 13
B_4 B_3 Z_116 
