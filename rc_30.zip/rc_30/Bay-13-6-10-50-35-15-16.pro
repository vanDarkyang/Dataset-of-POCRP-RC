Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
D_1 E_1 Z_100 G_0 
Stack 1
D_0 G_2 Z_101 Z_102 
Stack 2
D_2 A_2 Z_103 Z_104 
Stack 3
I_1 E_4 Z_105 Z_106 
Stack 4
F_4 Z_107 I_2 J_0 
Stack 5
G_1 E_2 A_0 Z_108 
Stack 6
C_1 C_0 I_0 Z_109 
Stack 7
E_3 G_3 H_1 F_2 
Stack 8
D_3 Z_110 Z_111 H_0 
Stack 9
C_2 F_0 H_2 F_1 
Stack 10
B_0 A_1 F_3 Z_112 
Stack 11
Z_113 J_1 Z_114 
Stack 12
E_0 H_3 B_1 
