Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
K_0 Z_100 E_3 K_1 Z_101 B_1 
Stack 1
B_0 Z_102 Z_103 E_4 Z_104 Z_105 
Stack 2
Z_106 J_2 F_1 H_1 J_0 G_0 
Stack 3
H_5 Z_107 Z_108 I_6 D_1 Z_109 
Stack 4
N_3 Z_110 K_4 M_0 E_0 
Stack 5
Z_111 F_0 Z_112 G_6 C_3 
Stack 6
Z_113 G_4 Z_114 C_2 L_1 
Stack 7
J_1 Z_115 A_0 Z_116 A_1 
Stack 8
Z_117 F_3 F_2 Z_118 G_5 
Stack 9
N_1 H_2 D_0 H_6 M_1 
Stack 10
Z_119 L_0 Z_120 J_3 L_2 
Stack 11
D_2 Z_121 G_7 I_4 Z_122 
Stack 12
I_0 E_1 K_2 H_0 Z_123 
Stack 13
I_1 I_2 C_1 H_4 Z_124 
Stack 14
Z_125 E_2 Z_126 K_3 G_3 
Stack 15
G_2 M_3 Z_127 M_2 O_0 
Stack 16
G_1 D_3 N_0 N_2 C_4 
Stack 17
H_3 Z_128 C_0 I_3 I_5 
