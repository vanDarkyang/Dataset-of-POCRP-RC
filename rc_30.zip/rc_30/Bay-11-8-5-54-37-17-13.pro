Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_3 A_4 B_5 B_1 Z_100 
Stack 1
D_6 A_3 D_8 A_5 C_2 
Stack 2
E_6 Z_101 A_0 Z_102 D_5 
Stack 3
Z_103 C_3 B_2 D_4 B_3 
Stack 4
C_1 Z_104 A_1 C_0 Z_105 
Stack 5
E_0 B_6 Z_106 D_0 B_7 
Stack 6
Z_107 C_6 D_1 B_0 Z_108 
Stack 7
E_3 Z_109 E_4 Z_110 Z_111 
Stack 8
Z_112 C_4 Z_113 Z_114 D_2 
Stack 9
E_2 B_4 Z_115 A_2 C_5 
Stack 10
Z_116 D_7 E_1 E_5 
