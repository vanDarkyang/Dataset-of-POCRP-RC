Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_2 B_0 C_8 E_6 
Stack 1
Z_100 C_2 D_5 Z_101 
Stack 2
Z_102 A_0 C_7 E_2 
Stack 3
D_4 E_0 Z_103 B_1 
Stack 4
Z_104 Z_105 C_1 D_1 
Stack 5
A_1 Z_106 D_0 A_2 
Stack 6
E_1 Z_107 Z_108 D_7 
Stack 7
C_5 Z_109 E_5 A_5 
Stack 8
D_2 Z_110 B_4 C_4 
Stack 9
E_4 Z_111 C_3 E_3 
Stack 10
B_3 B_5 A_4 Z_112 
Stack 11
Z_113 C_0 D_6 E_7 
Stack 12
Z_114 C_6 Z_115 
Stack 13
A_3 Z_116 D_3 
