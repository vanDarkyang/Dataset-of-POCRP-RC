Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 C_7 D_1 Z_101 
Stack 1
E_0 Z_102 E_1 A_4 
Stack 2
Z_103 Z_104 C_2 Z_105 
Stack 3
A_3 A_5 C_4 Z_106 
Stack 4
E_6 Z_107 D_0 B_4 
Stack 5
E_5 C_3 Z_108 A_2 
Stack 6
Z_109 B_0 A_6 Z_110 
Stack 7
Z_111 Z_112 D_5 B_3 
Stack 8
C_0 C_1 E_4 A_0 
Stack 9
Z_113 Z_114 E_2 Z_115 
Stack 10
C_8 D_3 E_7 A_1 
Stack 11
B_1 D_4 D_7 C_5 
Stack 12
Z_116 D_6 D_2 
Stack 13
C_6 B_2 E_3 
