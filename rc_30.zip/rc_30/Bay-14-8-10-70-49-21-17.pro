Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 C_3 H_0 Z_101 F_0 
Stack 1
D_0 D_1 E_0 Z_102 I_2 
Stack 2
Z_103 B_3 Z_104 Z_105 D_6 
Stack 3
D_5 Z_106 G_4 Z_107 I_5 
Stack 4
G_5 E_2 A_0 Z_108 Z_109 
Stack 5
F_4 Z_110 Z_111 H_1 B_2 
Stack 6
G_1 F_1 J_0 E_1 A_1 
Stack 7
Z_112 G_0 I_4 D_3 I_1 
Stack 8
B_0 Z_113 B_1 E_3 F_2 
Stack 9
F_3 B_5 Z_114 E_4 I_3 
Stack 10
C_2 B_4 D_2 H_4 Z_115 
Stack 11
G_3 D_4 I_0 Z_116 H_3 
Stack 12
C_0 G_2 Z_117 Z_118 Z_119 
Stack 13
H_2 F_5 C_1 J_1 Z_120 
