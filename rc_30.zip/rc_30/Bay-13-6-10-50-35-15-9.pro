Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
A_1 I_1 C_1 D_0 
Stack 1
G_0 Z_100 Z_101 Z_102 
Stack 2
E_0 H_1 C_3 Z_103 
Stack 3
Z_104 F_1 Z_105 B_0 
Stack 4
Z_106 Z_107 D_3 C_0 
Stack 5
E_2 J_1 H_2 I_0 
Stack 6
Z_108 H_0 E_1 A_2 
Stack 7
E_3 G_3 F_4 F_3 
Stack 8
G_2 F_2 C_2 Z_109 
Stack 9
A_0 J_0 Z_110 G_1 
Stack 10
F_0 J_2 Z_111 Z_112 
Stack 11
D_1 D_2 G_4 
Stack 12
Z_113 Z_114 G_5 
