Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 Z_101 A_4 B_9 
Stack 1
B_1 Z_102 B_5 B_8 
Stack 2
C_3 B_2 C_8 A_0 
Stack 3
A_5 Z_103 Z_104 C_0 
Stack 4
Z_105 B_0 C_9 C_6 
Stack 5
C_11 C_7 C_4 Z_106 
Stack 6
B_7 Z_107 B_3 C_10 
Stack 7
A_1 B_4 Z_108 Z_109 
Stack 8
B_11 Z_110 C_12 B_6 
Stack 9
A_6 A_2 C_5 C_1 
Stack 10
C_2 A_3 B_10 
Stack 11
Z_111 Z_112 Z_113 
