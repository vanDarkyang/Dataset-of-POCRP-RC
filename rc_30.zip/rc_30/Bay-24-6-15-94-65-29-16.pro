Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
K_2 G_7 L_0 I_5 
Stack 1
B_0 E_4 Z_100 O_2 
Stack 2
G_3 Z_101 I_3 E_0 
Stack 3
Z_102 I_0 I_4 C_0 
Stack 4
A_0 I_2 D_0 Z_103 
Stack 5
Z_104 Z_105 F_4 Z_106 
Stack 6
G_6 F_0 K_3 D_1 
Stack 7
Z_107 Z_108 O_0 H_5 
Stack 8
Z_109 I_1 Z_110 L_1 
Stack 9
Z_111 Z_112 Z_113 Z_114 
Stack 10
Z_115 I_7 G_4 H_8 
Stack 11
J_1 M_1 L_2 I_6 
Stack 12
E_2 J_2 M_0 G_0 
Stack 13
Z_116 O_1 G_5 H_7 
Stack 14
K_1 H_3 D_4 Z_117 
Stack 15
D_3 J_0 H_2 K_0 
Stack 16
F_1 D_2 Z_118 Z_119 
Stack 17
E_3 Z_120 Z_121 H_1 
Stack 18
G_2 Z_122 Z_123 Z_124 
Stack 19
G_1 Z_125 M_3 H_0 
Stack 20
N_1 Z_126 E_1 Z_127 
Stack 21
H_6 K_4 F_5 F_2 
Stack 22
Z_128 H_4 F_3 
Stack 23
M_2 J_3 N_0 
