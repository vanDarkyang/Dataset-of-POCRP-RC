Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_1 Z_100 B_4 B_2 
Stack 1
A_1 C_0 C_1 I_0 
Stack 2
E_3 G_1 B_5 C_3 
Stack 3
B_3 Z_101 Z_102 I_3 
Stack 4
H_2 Z_103 I_2 H_4 
Stack 5
Z_104 J_1 B_1 J_2 
Stack 6
J_0 Z_105 D_5 H_0 
Stack 7
Z_106 F_4 Z_107 E_2 
Stack 8
F_1 H_1 I_1 B_0 
Stack 9
C_5 Z_108 D_0 E_5 
Stack 10
C_4 Z_109 D_4 Z_110 
Stack 11
F_3 E_6 A_0 E_4 
Stack 12
Z_111 D_3 E_1 F_0 
Stack 13
Z_112 Z_113 Z_114 G_2 
Stack 14
Z_115 H_5 Z_116 Z_117 
Stack 15
Z_118 E_0 F_2 Z_119 
Stack 16
D_2 H_3 C_2 
Stack 17
G_0 Z_120 E_7 
