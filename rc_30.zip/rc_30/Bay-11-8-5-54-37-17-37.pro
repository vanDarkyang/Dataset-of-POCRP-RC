Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_2 Z_100 Z_101 A_0 D_1 
Stack 1
E_1 Z_102 E_6 B_8 B_0 
Stack 2
B_6 B_5 Z_103 C_0 B_7 
Stack 3
Z_104 Z_105 B_9 Z_106 A_1 
Stack 4
Z_107 Z_108 D_5 Z_109 Z_110 
Stack 5
D_2 Z_111 A_3 C_4 E_3 
Stack 6
B_2 D_7 B_4 Z_112 Z_113 
Stack 7
Z_114 E_4 Z_115 D_4 C_5 
Stack 8
D_6 C_7 C_6 A_2 B_3 
Stack 9
D_0 D_3 B_1 C_1 C_2 
Stack 10
C_3 E_0 Z_116 E_5 
