Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
A_1 Z_100 J_0 C_2 
Stack 1
C_1 E_0 F_0 C_3 
Stack 2
Z_101 H_0 J_1 H_1 
Stack 3
E_2 G_2 A_0 Z_102 
Stack 4
F_1 D_2 Z_103 B_2 
Stack 5
Z_104 B_1 C_0 Z_105 
Stack 6
E_1 Z_106 H_3 F_4 
Stack 7
D_1 Z_107 Z_108 G_1 
Stack 8
Z_109 J_2 G_0 Z_110 
Stack 9
D_0 F_3 I_1 H_2 
Stack 10
D_3 Z_111 Z_112 G_3 
Stack 11
Z_113 Z_114 A_2 
Stack 12
I_0 B_0 F_2 
