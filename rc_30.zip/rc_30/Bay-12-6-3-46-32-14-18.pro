Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_1 B_10 Z_100 B_9 
Stack 1
Z_101 Z_102 Z_103 B_4 
Stack 2
A_5 A_6 B_3 Z_104 
Stack 3
B_0 C_4 Z_105 C_2 
Stack 4
A_2 B_5 A_0 B_7 
Stack 5
C_3 C_7 C_8 A_1 
Stack 6
Z_106 A_8 C_6 Z_107 
Stack 7
B_8 B_6 C_1 C_0 
Stack 8
A_4 A_10 Z_108 A_9 
Stack 9
Z_109 Z_110 Z_111 Z_112 
Stack 10
Z_113 A_3 A_11 
Stack 11
A_7 B_2 C_5 
