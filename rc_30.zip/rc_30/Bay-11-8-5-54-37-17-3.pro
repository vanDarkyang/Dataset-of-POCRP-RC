Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_4 Z_100 D_4 Z_101 Z_102 
Stack 1
A_5 Z_103 D_0 E_2 Z_104 
Stack 2
D_3 C_6 D_5 Z_105 B_2 
Stack 3
Z_106 Z_107 Z_108 B_1 D_7 
Stack 4
Z_109 C_2 B_3 C_3 Z_110 
Stack 5
C_0 Z_111 B_0 C_4 E_7 
Stack 6
C_7 A_1 E_1 C_8 Z_112 
Stack 7
E_6 C_5 A_0 E_3 Z_113 
Stack 8
A_4 C_1 E_5 A_2 D_1 
Stack 9
D_6 A_6 E_4 E_0 Z_114 
Stack 10
Z_115 D_2 A_3 Z_116 
