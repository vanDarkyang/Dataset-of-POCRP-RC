Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 I_4 Z_101 Z_102 D_0 H_4 
Stack 1
Z_103 H_0 Z_104 F_0 B_2 Z_105 
Stack 2
Z_106 H_6 L_4 H_5 Z_107 Z_108 
Stack 3
E_2 Z_109 B_1 N_1 D_1 Z_110 
Stack 4
G_0 K_2 Z_111 A_0 L_0 
Stack 5
L_3 G_1 Z_112 K_0 Z_113 
Stack 6
I_0 E_0 F_1 Z_114 O_1 
Stack 7
H_9 Z_115 H_1 G_2 Z_116 
Stack 8
G_4 Z_117 I_2 E_1 M_0 
Stack 9
Z_118 Z_119 E_4 I_3 Z_120 
Stack 10
A_2 Z_121 F_5 K_1 O_0 
Stack 11
H_2 M_2 B_0 J_1 H_3 
Stack 12
L_5 I_1 Z_122 Z_123 M_1 
Stack 13
G_3 L_2 E_3 D_2 F_3 
Stack 14
H_7 K_3 Z_124 Z_125 Z_126 
Stack 15
F_2 L_1 Z_127 H_8 C_0 
Stack 16
K_6 K_4 M_3 J_0 Z_128 
Stack 17
C_1 F_4 A_1 K_5 N_0 
