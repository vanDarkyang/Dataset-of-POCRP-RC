Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_6 A_7 Z_100 Z_101 A_5 
Stack 1
A_0 D_5 E_6 B_5 Z_102 
Stack 2
Z_103 C_0 E_2 C_3 Z_104 
Stack 3
C_4 Z_105 E_4 Z_106 B_0 
Stack 4
B_4 B_7 D_1 E_3 E_0 
Stack 5
A_6 A_8 Z_107 C_5 E_5 
Stack 6
B_3 D_6 E_1 A_2 C_2 
Stack 7
A_1 Z_108 Z_109 Z_110 Z_111 
Stack 8
D_4 Z_112 C_1 B_1 Z_113 
Stack 9
Z_114 A_4 D_0 B_2 D_3 
Stack 10
A_3 Z_115 D_2 Z_116 
