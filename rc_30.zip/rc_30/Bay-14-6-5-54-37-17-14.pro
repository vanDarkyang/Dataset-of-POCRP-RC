Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 E_1 D_7 D_6 
Stack 1
Z_101 E_3 Z_102 B_3 
Stack 2
Z_103 Z_104 A_0 Z_105 
Stack 3
C_8 Z_106 Z_107 Z_108 
Stack 4
A_4 B_4 A_3 D_0 
Stack 5
C_7 D_4 B_2 Z_109 
Stack 6
C_2 E_2 E_6 A_5 
Stack 7
D_5 B_1 C_6 Z_110 
Stack 8
B_6 A_2 C_0 C_5 
Stack 9
Z_111 Z_112 Z_113 Z_114 
Stack 10
E_4 A_1 E_5 D_3 
Stack 11
C_3 Z_115 C_4 B_0 
Stack 12
B_5 E_0 D_2 
Stack 13
Z_116 C_1 D_1 
