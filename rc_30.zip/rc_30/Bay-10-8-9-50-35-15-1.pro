Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
9
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
B_1 C_0 Z_100 D_3 F_2 
Stack 1
D_5 H_2 E_4 D_0 H_3 
Stack 2
D_2 E_3 E_2 Z_101 Z_102 
Stack 3
F_1 I_2 B_3 Z_103 Z_104 
Stack 4
Z_105 C_1 Z_106 I_0 F_4 
Stack 5
Z_107 G_3 B_2 F_0 A_1 
Stack 6
Z_108 G_2 Z_109 B_0 Z_110 
Stack 7
Z_111 Z_112 A_0 E_0 Z_113 
Stack 8
G_0 E_1 D_4 I_1 Z_114 
Stack 9
G_1 H_1 F_3 H_0 D_1 
