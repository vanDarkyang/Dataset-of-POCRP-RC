Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
D_1 Z_100 Z_101 C_0 K_1 A_0 
Stack 1
E_0 Z_102 M_4 M_1 N_1 Z_103 
Stack 2
J_3 Z_104 J_4 F_1 I_0 Z_105 
Stack 3
E_2 H_7 K_0 M_3 J_0 G_6 
Stack 4
Z_106 H_5 G_5 E_1 G_2 
Stack 5
Z_107 I_1 Z_108 C_2 Z_109 
Stack 6
H_3 L_2 I_5 Z_110 H_0 
Stack 7
I_3 D_0 K_4 K_2 G_0 
Stack 8
H_2 I_2 G_3 Z_111 F_2 
Stack 9
Z_112 I_4 Z_113 Z_114 F_0 
Stack 10
Z_115 Z_116 B_2 O_0 L_3 
Stack 11
L_4 H_4 J_5 L_1 J_2 
Stack 12
Z_117 H_6 Z_118 N_2 H_1 
Stack 13
J_1 O_1 N_0 Z_119 G_4 
Stack 14
K_3 G_1 Z_120 Z_121 M_0 
Stack 15
Z_122 B_0 Z_123 Z_124 Z_125 
Stack 16
J_6 A_1 C_1 L_0 M_2 
Stack 17
Z_126 Z_127 F_3 B_1 Z_128 
