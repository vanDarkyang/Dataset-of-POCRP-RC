Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_4 Z_100 C_4 B_2 
Stack 1
Z_101 C_3 E_2 A_1 
Stack 2
Z_102 D_6 B_7 E_4 
Stack 3
A_7 B_5 B_3 Z_103 
Stack 4
A_3 Z_104 Z_105 Z_106 
Stack 5
Z_107 D_4 Z_108 D_5 
Stack 6
D_7 C_2 B_6 C_5 
Stack 7
E_1 Z_109 Z_110 Z_111 
Stack 8
D_1 D_0 E_3 A_4 
Stack 9
D_3 Z_112 D_2 E_5 
Stack 10
C_0 Z_113 Z_114 A_6 
Stack 11
B_1 B_0 E_0 C_1 
Stack 12
A_2 Z_115 Z_116 
Stack 13
E_6 A_0 A_5 
