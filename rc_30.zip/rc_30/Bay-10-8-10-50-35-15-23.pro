Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
B_3 Z_100 Z_101 H_0 Z_102 
Stack 1
Z_103 Z_104 Z_105 D_0 B_2 
Stack 2
E_6 D_1 J_1 E_1 Z_106 
Stack 3
E_3 F_0 E_5 Z_107 Z_108 
Stack 4
F_3 I_0 H_1 C_2 C_1 
Stack 5
G_0 D_2 F_1 E_4 C_0 
Stack 6
Z_109 Z_110 A_2 Z_111 B_0 
Stack 7
G_1 J_0 Z_112 A_0 Z_113 
Stack 8
G_3 A_1 F_2 G_2 E_2 
Stack 9
E_0 Z_114 B_1 I_1 C_3 
