Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
F_4 Z_100 C_3 F_5 J_3 Z_101 
Stack 1
J_1 Z_102 G_4 D_3 Z_103 Z_104 
Stack 2
C_0 E_2 Z_105 H_5 Z_106 D_2 
Stack 3
J_2 H_0 B_6 Z_107 F_0 B_3 
Stack 4
Z_108 Z_109 I_1 Z_110 A_3 F_6 
Stack 5
Z_111 I_7 Z_112 Z_113 F_3 
Stack 6
A_1 G_2 I_8 A_5 Z_114 
Stack 7
D_7 I_0 G_8 Z_115 Z_116 
Stack 8
Z_117 A_0 F_7 G_3 G_7 
Stack 9
Z_118 J_5 Z_119 Z_120 I_2 
Stack 10
G_10 B_2 G_5 Z_121 H_3 
Stack 11
E_3 H_6 G_6 E_1 H_8 
Stack 12
H_4 D_6 A_2 D_5 E_0 
Stack 13
I_3 F_1 D_11 B_1 Z_122 
Stack 14
H_1 A_4 C_6 J_0 C_1 
Stack 15
Z_123 Z_124 D_8 I_4 C_5 
Stack 16
H_9 Z_125 B_4 C_4 G_1 
Stack 17
H_7 D_1 Z_126 Z_127 J_4 
Stack 18
D_9 I_6 G_9 I_5 D_4 
Stack 19
C_7 Z_128 B_5 Z_129 G_0 
Stack 20
C_9 B_0 F_2 C_2 D_0 
Stack 21
Z_130 Z_131 E_4 C_8 Z_132 
Stack 22
Z_133 D_10 Z_134 H_2 Z_135 
