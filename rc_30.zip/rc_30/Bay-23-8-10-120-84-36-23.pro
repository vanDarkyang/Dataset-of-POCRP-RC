Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
E_10 Z_100 F_4 C_0 Z_101 C_4 
Stack 1
F_1 E_3 E_5 Z_102 B_4 A_3 
Stack 2
J_1 H_6 E_1 J_3 Z_103 Z_104 
Stack 3
Z_105 D_1 B_1 Z_106 Z_107 G_2 
Stack 4
Z_108 Z_109 H_2 B_8 B_5 Z_110 
Stack 5
B_2 Z_111 G_7 D_4 G_0 
Stack 6
A_0 B_9 Z_112 B_3 Z_113 
Stack 7
Z_114 I_0 Z_115 Z_116 C_2 
Stack 8
Z_117 D_5 Z_118 Z_119 J_5 
Stack 9
A_5 G_1 A_6 Z_120 G_5 
Stack 10
Z_121 E_6 Z_122 C_1 Z_123 
Stack 11
Z_124 F_3 Z_125 Z_126 G_8 
Stack 12
J_2 E_0 D_2 H_1 E_7 
Stack 13
F_2 F_7 G_6 F_6 D_7 
Stack 14
I_2 C_3 H_5 Z_127 J_7 
Stack 15
D_0 G_3 I_7 H_0 G_9 
Stack 16
G_4 I_3 B_7 I_4 A_2 
Stack 17
Z_128 F_5 Z_129 C_6 D_6 
Stack 18
E_8 I_5 E_2 Z_130 Z_131 
Stack 19
J_0 C_5 I_1 A_1 B_0 
Stack 20
J_6 Z_132 D_3 Z_133 J_4 
Stack 21
E_4 B_6 E_9 I_6 Z_134 
Stack 22
Z_135 F_0 H_3 A_4 H_4 
