Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 D_4 D_5 E_0 
Stack 1
Z_101 C_6 Z_102 Z_103 
Stack 2
E_5 A_1 B_2 E_4 
Stack 3
C_9 E_7 B_1 D_2 
Stack 4
C_7 Z_104 Z_105 Z_106 
Stack 5
Z_107 D_0 A_6 Z_108 
Stack 6
C_5 C_0 Z_109 C_1 
Stack 7
Z_110 A_4 A_5 B_3 
Stack 8
E_8 B_0 Z_111 Z_112 
Stack 9
Z_113 Z_114 C_8 A_2 
Stack 10
E_3 A_3 E_1 A_0 
Stack 11
C_4 D_3 E_6 Z_115 
Stack 12
D_1 C_3 E_2 
Stack 13
Z_116 D_6 C_2 
