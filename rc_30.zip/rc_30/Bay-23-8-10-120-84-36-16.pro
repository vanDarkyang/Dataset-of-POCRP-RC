Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 E_4 B_0 Z_101 G_5 B_3 
Stack 1
Z_102 F_3 Z_103 G_7 Z_104 I_5 
Stack 2
J_1 Z_105 I_4 J_3 B_6 Z_106 
Stack 3
J_2 Z_107 B_5 Z_108 Z_109 F_6 
Stack 4
C_0 F_8 Z_110 Z_111 C_2 H_7 
Stack 5
E_6 H_0 Z_112 H_4 Z_113 
Stack 6
C_5 F_2 D_8 E_7 D_1 
Stack 7
H_3 B_7 Z_114 J_0 C_1 
Stack 8
E_3 A_0 I_7 F_5 Z_115 
Stack 9
G_2 C_7 A_3 I_1 G_3 
Stack 10
J_6 Z_116 B_2 Z_117 Z_118 
Stack 11
A_1 H_6 D_6 J_5 I_2 
Stack 12
H_1 Z_119 Z_120 I_0 G_1 
Stack 13
Z_121 C_3 H_8 D_7 Z_122 
Stack 14
D_5 D_3 A_4 E_2 Z_123 
Stack 15
C_6 E_1 D_4 F_4 Z_124 
Stack 16
Z_125 E_0 Z_126 I_3 Z_127 
Stack 17
F_1 Z_128 G_4 G_8 Z_129 
Stack 18
F_7 G_0 B_4 D_0 Z_130 
Stack 19
E_8 E_5 G_6 Z_131 H_5 
Stack 20
G_9 A_5 Z_132 F_0 Z_133 
Stack 21
I_6 Z_134 B_1 J_4 D_2 
Stack 22
A_2 H_2 C_4 Z_135 E_9 
