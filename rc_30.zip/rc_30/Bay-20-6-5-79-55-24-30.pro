Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_1 D_6 E_3 Z_100 
Stack 1
Z_101 Z_102 C_10 B_9 
Stack 2
B_10 D_2 Z_103 B_6 
Stack 3
C_2 A_0 Z_104 Z_105 
Stack 4
B_8 A_11 D_5 C_1 
Stack 5
A_3 C_11 Z_106 Z_107 
Stack 6
Z_108 B_1 C_9 C_7 
Stack 7
Z_109 B_5 E_7 Z_110 
Stack 8
Z_111 A_9 C_3 A_4 
Stack 9
B_7 E_10 Z_112 B_3 
Stack 10
Z_113 B_11 Z_114 Z_115 
Stack 11
D_0 Z_116 D_4 A_2 
Stack 12
Z_117 A_10 Z_118 E_0 
Stack 13
C_4 A_7 A_6 Z_119 
Stack 14
C_6 E_5 B_2 Z_120 
Stack 15
E_4 E_1 B_4 A_1 
Stack 16
A_8 Z_121 C_5 D_3 
Stack 17
C_8 C_0 B_0 Z_122 
Stack 18
E_2 Z_123 E_6 E_8 
Stack 19
A_5 D_7 E_9 
