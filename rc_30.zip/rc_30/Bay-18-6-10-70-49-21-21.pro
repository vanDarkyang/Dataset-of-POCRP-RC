Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
I_3 I_0 B_2 Z_100 
Stack 1
Z_101 G_4 G_3 F_4 
Stack 2
E_0 Z_102 F_0 Z_103 
Stack 3
D_2 B_0 E_1 H_2 
Stack 4
Z_104 Z_105 A_1 I_4 
Stack 5
C_2 F_5 A_2 I_1 
Stack 6
Z_106 I_2 Z_107 Z_108 
Stack 7
D_0 Z_109 I_5 Z_110 
Stack 8
H_1 H_0 E_4 D_1 
Stack 9
H_4 G_0 C_4 Z_111 
Stack 10
Z_112 Z_113 Z_114 B_3 
Stack 11
G_6 G_5 J_0 A_0 
Stack 12
G_1 D_3 J_1 C_0 
Stack 13
F_1 C_3 G_2 F_3 
Stack 14
Z_115 F_6 E_3 F_2 
Stack 15
H_3 B_1 J_2 Z_116 
Stack 16
Z_117 Z_118 Z_119 
Stack 17
Z_120 C_1 E_2 
