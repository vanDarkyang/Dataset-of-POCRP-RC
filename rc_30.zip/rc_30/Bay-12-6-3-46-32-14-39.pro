Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 B_4 A_3 Z_101 
Stack 1
C_2 B_5 Z_102 Z_103 
Stack 2
C_4 C_3 Z_104 Z_105 
Stack 3
A_7 C_6 C_7 Z_106 
Stack 4
A_6 A_4 B_8 A_2 
Stack 5
Z_107 C_5 B_6 C_8 
Stack 6
Z_108 B_1 Z_109 A_0 
Stack 7
B_0 B_10 C_1 A_10 
Stack 8
C_0 B_11 A_8 B_9 
Stack 9
B_7 Z_110 B_2 A_1 
Stack 10
Z_111 B_3 Z_112 
Stack 11
A_9 A_5 Z_113 
