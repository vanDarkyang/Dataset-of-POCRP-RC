Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
F_1 G_2 I_1 Z_100 K_3 N_2 
Stack 1
Z_101 L_2 Z_102 K_1 L_1 N_1 
Stack 2
Z_103 Z_104 I_5 C_0 G_0 Z_105 
Stack 3
I_7 Z_106 G_3 O_0 Z_107 E_4 
Stack 4
N_0 G_1 Z_108 E_1 L_3 
Stack 5
F_0 Z_109 I_3 Z_110 H_0 
Stack 6
C_1 L_0 E_2 B_3 Z_111 
Stack 7
D_4 H_2 J_0 B_2 F_3 
Stack 8
J_2 J_1 E_0 Z_112 F_2 
Stack 9
H_3 Z_113 D_1 A_1 D_2 
Stack 10
Z_114 L_4 G_5 B_0 Z_115 
Stack 11
Z_116 E_3 I_6 Z_117 A_0 
Stack 12
Z_118 H_1 Z_119 Z_120 I_0 
Stack 13
G_4 B_1 Z_121 D_5 K_0 
Stack 14
M_0 D_3 Z_122 Z_123 M_1 
Stack 15
C_2 O_2 I_2 Z_124 K_2 
Stack 16
D_0 O_1 Z_125 K_4 M_2 
Stack 17
I_4 Z_126 Z_127 Z_128 N_3 
