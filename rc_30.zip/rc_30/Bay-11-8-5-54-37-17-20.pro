Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_5 D_6 B_2 Z_100 D_2 
Stack 1
A_1 D_1 B_1 Z_101 Z_102 
Stack 2
A_3 Z_103 E_1 A_2 C_1 
Stack 3
E_3 Z_104 E_7 Z_105 D_9 
Stack 4
Z_106 A_5 A_4 Z_107 D_4 
Stack 5
C_4 Z_108 B_4 Z_109 D_5 
Stack 6
B_5 D_8 C_2 D_3 Z_110 
Stack 7
E_4 C_3 E_0 Z_111 A_0 
Stack 8
Z_112 B_6 D_7 C_0 B_0 
Stack 9
Z_113 Z_114 D_0 B_3 E_2 
Stack 10
Z_115 A_6 E_6 Z_116 
