Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
C_2 F_0 M_0 Z_100 
Stack 1
M_2 Z_101 G_5 C_0 
Stack 2
Z_102 Z_103 I_1 J_3 
Stack 3
A_2 Z_104 I_2 H_5 
Stack 4
Z_105 H_3 I_4 C_4 
Stack 5
B_1 G_0 B_0 F_1 
Stack 6
H_4 Z_106 M_1 G_2 
Stack 7
G_6 Z_107 E_1 Z_108 
Stack 8
Z_109 M_3 D_2 Z_110 
Stack 9
F_3 Z_111 K_2 G_1 
Stack 10
Z_112 Z_113 G_4 N_3 
Stack 11
I_0 E_0 C_3 N_1 
Stack 12
M_4 C_1 E_2 Z_114 
Stack 13
J_1 K_1 Z_115 I_5 
Stack 14
Z_116 I_3 F_2 Z_117 
Stack 15
F_4 H_1 Z_118 Z_119 
Stack 16
D_1 A_1 L_0 Z_120 
Stack 17
Z_121 Z_122 D_0 K_3 
Stack 18
H_6 N_2 F_5 F_6 
Stack 19
L_2 H_2 K_0 Z_123 
Stack 20
Z_124 B_2 Z_125 N_0 
Stack 21
Z_126 Z_127 Z_128 O_0 
Stack 22
G_3 J_2 A_0 
Stack 23
L_1 J_0 H_0 
