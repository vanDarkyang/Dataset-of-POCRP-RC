Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 E_0 C_2 Z_101 
Stack 1
G_3 J_3 E_3 Z_102 
Stack 2
C_0 G_6 Z_103 O_0 
Stack 3
E_2 Z_104 D_1 Z_105 
Stack 4
G_1 J_2 M_1 L_0 
Stack 5
Z_106 M_0 A_1 J_1 
Stack 6
I_2 Z_107 D_2 O_1 
Stack 7
Z_108 L_2 Z_109 G_0 
Stack 8
G_5 K_3 H_4 Z_110 
Stack 9
D_0 L_1 Z_111 Z_112 
Stack 10
A_2 Z_113 A_0 Z_114 
Stack 11
Z_115 Z_116 K_0 H_2 
Stack 12
L_4 Z_117 I_3 Z_118 
Stack 13
G_4 I_1 Z_119 F_3 
Stack 14
H_6 L_3 E_1 F_5 
Stack 15
F_2 B_1 I_5 C_1 
Stack 16
Z_120 Z_121 K_1 F_0 
Stack 17
Z_122 Z_123 Z_124 N_0 
Stack 18
I_6 F_1 Z_125 H_3 
Stack 19
H_0 H_1 D_3 Z_126 
Stack 20
H_5 I_4 I_0 J_0 
Stack 21
N_1 E_4 H_7 Z_127 
Stack 22
K_2 F_4 Z_128 
Stack 23
G_2 B_0 K_4 
