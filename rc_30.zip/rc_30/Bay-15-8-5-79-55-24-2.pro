Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 B_0 Z_101 C_2 D_5 Z_102 
Stack 1
Z_103 Z_104 B_7 A_9 E_5 D_0 
Stack 2
E_1 C_5 D_1 Z_105 D_3 Z_106 
Stack 3
B_6 C_3 Z_107 Z_108 A_0 Z_109 
Stack 4
D_7 Z_110 B_8 C_9 A_6 
Stack 5
Z_111 B_12 B_2 D_11 Z_112 
Stack 6
C_7 D_9 B_4 A_2 C_4 
Stack 7
Z_113 B_1 B_13 A_4 E_0 
Stack 8
B_3 C_6 B_5 E_4 B_9 
Stack 9
Z_114 E_3 A_3 B_10 A_1 
Stack 10
C_8 Z_115 Z_116 D_8 C_1 
Stack 11
A_5 Z_117 Z_118 D_4 A_7 
Stack 12
A_8 Z_119 E_6 D_6 D_10 
Stack 13
Z_120 Z_121 Z_122 E_2 C_0 
Stack 14
Z_123 E_7 D_2 E_8 B_11 
