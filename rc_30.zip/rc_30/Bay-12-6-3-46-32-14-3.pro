Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 C_1 B_5 Z_101 
Stack 1
B_9 B_8 A_10 A_8 
Stack 2
C_2 Z_102 A_3 C_3 
Stack 3
B_6 C_0 C_4 B_4 
Stack 4
C_9 Z_103 A_1 A_6 
Stack 5
B_7 B_1 Z_104 Z_105 
Stack 6
A_9 Z_106 B_10 A_5 
Stack 7
B_3 C_6 Z_107 Z_108 
Stack 8
C_8 A_7 Z_109 Z_110 
Stack 9
A_0 Z_111 A_2 Z_112 
Stack 10
C_5 C_7 B_2 
Stack 11
B_0 Z_113 A_4 
