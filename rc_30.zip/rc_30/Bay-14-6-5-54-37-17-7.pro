Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
C_5 B_7 E_8 Z_100 
Stack 1
E_7 D_0 Z_101 B_1 
Stack 2
D_4 C_0 Z_102 B_2 
Stack 3
Z_103 A_4 D_3 E_5 
Stack 4
D_6 Z_104 Z_105 Z_106 
Stack 5
B_4 Z_107 A_2 B_3 
Stack 6
C_6 E_3 A_1 D_1 
Stack 7
Z_108 Z_109 B_0 Z_110 
Stack 8
Z_111 C_3 B_6 E_2 
Stack 9
Z_112 C_4 E_1 Z_113 
Stack 10
Z_114 C_1 E_0 E_4 
Stack 11
Z_115 C_2 A_5 A_3 
Stack 12
A_0 B_5 E_6 
Stack 13
Z_116 D_5 D_2 
