Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_6 D_8 Z_100 Z_101 A_4 
Stack 1
Z_102 D_0 Z_103 E_0 Z_104 
Stack 2
B_3 Z_105 Z_106 Z_107 Z_108 
Stack 3
A_2 E_2 A_3 B_0 C_5 
Stack 4
Z_109 C_7 D_5 Z_110 B_2 
Stack 5
Z_111 Z_112 D_3 E_4 D_6 
Stack 6
D_7 C_0 E_5 B_5 C_2 
Stack 7
C_6 A_0 Z_113 C_4 E_3 
Stack 8
C_1 B_4 Z_114 Z_115 D_2 
Stack 9
A_1 A_5 D_1 D_4 B_1 
Stack 10
Z_116 C_3 E_1 B_7 
