Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
A_0 Z_100 D_0 F_0 
Stack 1
H_2 F_3 Z_101 F_2 
Stack 2
B_1 E_1 Z_102 D_3 
Stack 3
F_1 E_3 Z_103 Z_104 
Stack 4
Z_105 D_2 Z_106 Z_107 
Stack 5
H_3 D_4 Z_108 G_3 
Stack 6
E_2 C_4 Z_109 A_1 
Stack 7
C_0 D_1 H_0 D_5 
Stack 8
Z_110 Z_111 Z_112 E_0 
Stack 9
G_2 H_1 Z_113 C_2 
Stack 10
C_1 G_0 G_1 Z_114 
Stack 11
I_0 I_1 E_4 
Stack 12
B_0 J_0 C_3 
