Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
F_5 D_1 F_1 E_4 
Stack 1
Z_100 D_5 E_1 D_6 
Stack 2
B_2 D_3 Z_101 C_1 
Stack 3
Z_102 H_0 A_1 E_0 
Stack 4
E_2 G_2 Z_103 Z_104 
Stack 5
D_0 F_0 H_5 J_3 
Stack 6
C_0 Z_105 F_3 Z_106 
Stack 7
G_7 J_0 I_1 Z_107 
Stack 8
I_3 A_0 J_1 I_2 
Stack 9
Z_108 G_3 G_5 C_2 
Stack 10
F_2 H_4 Z_109 Z_110 
Stack 11
H_1 Z_111 F_4 G_0 
Stack 12
Z_112 Z_113 G_1 B_1 
Stack 13
Z_114 H_2 H_3 J_2 
Stack 14
D_4 Z_115 Z_116 B_0 
Stack 15
G_6 Z_117 Z_118 Z_119 
Stack 16
G_4 E_3 B_3 
Stack 17
I_0 D_2 Z_120 
