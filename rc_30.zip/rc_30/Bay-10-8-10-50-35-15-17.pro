Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
H_1 D_0 Z_100 E_0 B_1 
Stack 1
E_3 Z_101 F_1 D_3 Z_102 
Stack 2
C_0 I_1 Z_103 G_2 J_1 
Stack 3
B_0 E_2 Z_104 A_1 E_1 
Stack 4
D_4 Z_105 Z_106 J_0 D_2 
Stack 5
F_3 I_0 G_0 G_1 E_5 
Stack 6
H_2 C_1 I_2 Z_107 C_2 
Stack 7
H_0 C_3 D_1 Z_108 Z_109 
Stack 8
A_0 Z_110 E_4 D_5 Z_111 
Stack 9
F_2 Z_112 Z_113 Z_114 F_0 
