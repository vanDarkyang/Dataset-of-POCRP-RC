Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_9 B_1 A_4 B_0 
Stack 1
A_7 C_4 Z_100 Z_101 
Stack 2
Z_102 A_1 A_0 A_8 
Stack 3
A_9 Z_103 B_7 Z_104 
Stack 4
Z_105 C_0 C_6 B_9 
Stack 5
C_1 Z_106 A_10 C_2 
Stack 6
Z_107 C_3 A_6 B_3 
Stack 7
B_5 Z_108 Z_109 B_10 
Stack 8
B_4 Z_110 C_7 B_6 
Stack 9
C_8 B_8 A_2 C_5 
Stack 10
Z_111 B_2 A_5 
Stack 11
Z_112 A_3 Z_113 
