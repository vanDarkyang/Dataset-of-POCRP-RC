Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_4 B_9 Z_100 Z_101 
Stack 1
A_5 A_1 B_5 Z_102 
Stack 2
A_10 A_0 Z_103 Z_104 
Stack 3
A_7 B_1 C_5 B_0 
Stack 4
B_8 Z_105 B_4 A_3 
Stack 5
C_7 Z_106 A_8 A_2 
Stack 6
Z_107 B_7 C_9 Z_108 
Stack 7
A_9 A_6 C_2 A_11 
Stack 8
Z_109 C_8 B_2 B_6 
Stack 9
Z_110 Z_111 Z_112 C_0 
Stack 10
C_3 C_1 C_4 
Stack 11
Z_113 C_6 B_3 
