Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
I_0 G_2 K_0 C_1 
Stack 1
G_1 B_1 K_2 H_8 
Stack 2
J_4 L_1 L_2 F_4 
Stack 3
Z_100 Z_101 F_1 Z_102 
Stack 4
Z_103 B_2 Z_104 M_2 
Stack 5
H_0 Z_105 Z_106 O_1 
Stack 6
K_3 H_4 A_1 H_6 
Stack 7
H_3 Z_107 Z_108 E_3 
Stack 8
B_0 Z_109 Z_110 M_1 
Stack 9
G_3 G_6 Z_111 Z_112 
Stack 10
Z_113 Z_114 N_0 F_2 
Stack 11
H_1 G_7 Z_115 Z_116 
Stack 12
E_2 J_3 F_6 Z_117 
Stack 13
Z_118 H_2 G_4 C_2 
Stack 14
Z_119 K_1 D_1 E_0 
Stack 15
B_3 I_2 J_0 M_0 
Stack 16
Z_120 I_1 Z_121 Z_122 
Stack 17
E_1 H_7 A_0 L_3 
Stack 18
F_5 F_0 Z_123 G_5 
Stack 19
M_4 Z_124 J_1 A_2 
Stack 20
Z_125 H_5 L_0 C_0 
Stack 21
I_3 D_0 Z_126 F_3 
Stack 22
J_2 G_0 Z_127 
Stack 23
O_0 Z_128 M_3 
