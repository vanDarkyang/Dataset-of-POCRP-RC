Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_0 J_1 Z_100 F_0 
Stack 1
D_3 Z_101 F_2 H_1 
Stack 2
Z_102 B_1 H_2 Z_103 
Stack 3
C_2 B_3 Z_104 Z_105 
Stack 4
D_1 Z_106 F_6 Z_107 
Stack 5
Z_108 G_3 I_3 Z_109 
Stack 6
E_1 C_3 F_5 I_1 
Stack 7
G_0 Z_110 H_5 Z_111 
Stack 8
C_0 A_0 B_2 D_2 
Stack 9
F_1 I_0 Z_112 Z_113 
Stack 10
A_1 Z_114 E_0 G_4 
Stack 11
E_2 E_3 C_4 Z_115 
Stack 12
H_3 J_0 A_2 Z_116 
Stack 13
J_2 B_0 H_4 Z_117 
Stack 14
F_3 G_2 I_2 C_1 
Stack 15
E_4 I_4 D_4 F_4 
Stack 16
Z_118 Z_119 Z_120 
Stack 17
A_3 G_1 H_0 
