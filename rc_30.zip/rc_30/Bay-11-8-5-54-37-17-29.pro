Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_4 E_7 Z_100 A_2 B_0 
Stack 1
A_4 Z_101 B_2 Z_102 D_1 
Stack 2
Z_103 Z_104 B_1 D_5 A_3 
Stack 3
E_2 C_0 A_0 C_3 B_3 
Stack 4
C_1 A_5 D_3 C_2 Z_105 
Stack 5
B_5 E_5 A_1 Z_106 D_2 
Stack 6
E_0 E_6 Z_107 E_1 D_4 
Stack 7
A_6 Z_108 Z_109 Z_110 Z_111 
Stack 8
C_4 C_5 E_3 Z_112 B_6 
Stack 9
Z_113 D_0 C_8 Z_114 B_4 
Stack 10
C_6 Z_115 Z_116 C_7 
