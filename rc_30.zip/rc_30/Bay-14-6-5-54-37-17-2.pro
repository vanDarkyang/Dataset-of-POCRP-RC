Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_4 D_5 A_4 Z_100 
Stack 1
Z_101 B_2 Z_102 Z_103 
Stack 2
E_1 Z_104 E_3 Z_105 
Stack 3
A_3 C_5 A_2 E_5 
Stack 4
D_6 B_1 D_2 Z_106 
Stack 5
Z_107 D_7 E_6 E_4 
Stack 6
Z_108 C_1 B_6 Z_109 
Stack 7
Z_110 E_0 D_3 Z_111 
Stack 8
C_2 C_7 E_2 D_1 
Stack 9
A_5 A_6 Z_112 Z_113 
Stack 10
C_4 C_6 Z_114 B_4 
Stack 11
A_1 Z_115 B_3 Z_116 
Stack 12
D_0 B_5 C_3 
Stack 13
B_0 A_0 C_0 
