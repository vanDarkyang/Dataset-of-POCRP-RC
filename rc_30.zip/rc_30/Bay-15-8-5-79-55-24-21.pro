Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 C_8 E_4 Z_101 E_5 Z_102 
Stack 1
Z_103 B_10 D_1 B_12 Z_104 B_11 
Stack 2
E_6 B_9 C_1 C_4 E_2 E_7 
Stack 3
Z_105 A_0 Z_106 Z_107 E_8 A_6 
Stack 4
D_10 Z_108 B_1 A_4 B_5 
Stack 5
Z_109 C_0 D_3 E_0 A_2 
Stack 6
A_3 B_8 Z_110 A_5 Z_111 
Stack 7
C_2 C_3 E_1 A_1 D_0 
Stack 8
Z_112 E_10 Z_113 Z_114 C_12 
Stack 9
E_3 B_2 D_5 C_6 D_8 
Stack 10
Z_115 C_5 Z_116 Z_117 D_7 
Stack 11
B_7 Z_118 C_11 B_6 C_10 
Stack 12
Z_119 C_7 Z_120 B_0 Z_121 
Stack 13
B_4 E_9 C_9 Z_122 B_3 
Stack 14
D_4 D_9 Z_123 D_2 D_6 
