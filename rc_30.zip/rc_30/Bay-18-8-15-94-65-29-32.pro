Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
F_3 Z_100 B_1 I_6 L_0 Z_101 
Stack 1
Z_102 C_2 Z_103 Z_104 N_0 D_0 
Stack 2
B_0 E_3 C_0 Z_105 Z_106 I_1 
Stack 3
D_2 L_4 H_1 L_2 I_5 E_4 
Stack 4
Z_107 N_2 Z_108 K_1 H_0 
Stack 5
L_1 E_5 M_0 J_4 Z_109 
Stack 6
M_2 J_0 Z_110 G_2 Z_111 
Stack 7
I_7 Z_112 I_4 G_4 E_0 
Stack 8
Z_113 Z_114 J_5 Z_115 Z_116 
Stack 9
G_3 G_1 M_1 Z_117 D_1 
Stack 10
F_0 F_1 O_0 Z_118 Z_119 
Stack 11
I_0 A_2 G_0 E_2 H_3 
Stack 12
Z_120 C_3 Z_121 Z_122 J_2 
Stack 13
G_5 J_3 B_3 B_2 L_3 
Stack 14
Z_123 H_2 Z_124 Z_125 O_1 
Stack 15
C_1 F_2 K_2 A_0 J_1 
Stack 16
N_1 Z_126 E_1 I_2 K_0 
Stack 17
A_1 Z_127 I_3 Z_128 K_3 
