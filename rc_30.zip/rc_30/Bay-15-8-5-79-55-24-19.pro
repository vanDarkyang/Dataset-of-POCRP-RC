Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 Z_101 A_10 Z_102 E_0 C_6 
Stack 1
E_6 A_4 D_2 Z_103 E_1 B_6 
Stack 2
Z_104 Z_105 D_1 C_8 E_2 D_9 
Stack 3
Z_106 Z_107 Z_108 E_7 Z_109 E_3 
Stack 4
A_12 B_4 A_5 A_6 Z_110 
Stack 5
Z_111 Z_112 D_8 D_7 C_4 
Stack 6
A_8 C_9 A_0 C_7 B_1 
Stack 7
D_3 Z_113 B_10 B_0 A_1 
Stack 8
E_5 Z_114 C_10 Z_115 B_9 
Stack 9
B_2 C_1 C_2 Z_116 A_3 
Stack 10
A_11 C_3 A_7 B_7 B_11 
Stack 11
Z_117 B_8 C_0 E_4 Z_118 
Stack 12
Z_119 D_4 A_9 Z_120 D_5 
Stack 13
A_2 C_11 B_5 Z_121 C_5 
Stack 14
Z_122 Z_123 B_3 D_6 D_0 
