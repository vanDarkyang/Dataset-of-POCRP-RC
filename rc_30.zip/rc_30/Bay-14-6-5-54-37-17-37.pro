Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_2 Z_100 B_3 C_1 
Stack 1
E_0 Z_101 D_3 Z_102 
Stack 2
B_5 Z_103 C_7 D_1 
Stack 3
Z_104 Z_105 B_0 Z_106 
Stack 4
Z_107 E_4 A_0 Z_108 
Stack 5
D_2 Z_109 Z_110 A_3 
Stack 6
B_1 D_4 B_6 A_1 
Stack 7
E_1 Z_111 C_0 E_3 
Stack 8
D_7 A_5 Z_112 C_6 
Stack 9
D_0 E_5 Z_113 Z_114 
Stack 10
C_3 A_2 C_4 B_2 
Stack 11
Z_115 B_7 C_5 C_2 
Stack 12
D_8 D_6 D_5 
Stack 13
B_4 Z_116 A_4 
