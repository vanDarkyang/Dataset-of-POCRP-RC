Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 A_6 B_8 D_5 
Stack 1
C_0 B_0 E_10 E_9 
Stack 2
Z_101 B_11 A_0 D_8 
Stack 3
A_3 C_2 B_9 D_6 
Stack 4
C_3 B_1 Z_102 E_4 
Stack 5
B_4 Z_103 Z_104 A_8 
Stack 6
A_9 Z_105 B_3 E_2 
Stack 7
C_1 Z_106 A_2 Z_107 
Stack 8
Z_108 C_10 E_7 D_1 
Stack 9
C_9 Z_109 D_4 Z_110 
Stack 10
Z_111 D_9 Z_112 B_6 
Stack 11
C_8 Z_113 A_7 A_1 
Stack 12
Z_114 B_2 Z_115 E_0 
Stack 13
A_4 Z_116 B_5 B_7 
Stack 14
C_4 Z_117 E_5 C_11 
Stack 15
D_0 Z_118 E_6 C_5 
Stack 16
E_1 C_7 D_7 A_5 
Stack 17
Z_119 B_10 Z_120 E_8 
Stack 18
D_3 D_2 E_3 Z_121 
Stack 19
Z_122 Z_123 C_6 
