Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
C_3 F_3 A_2 D_2 H_2 
Stack 1
Z_100 Z_101 G_2 H_5 H_6 
Stack 2
E_4 J_1 Z_102 Z_103 Z_104 
Stack 3
H_0 F_2 G_4 Z_105 Z_106 
Stack 4
E_0 Z_107 Z_108 Z_109 Z_110 
Stack 5
Z_111 H_3 A_0 B_0 C_4 
Stack 6
C_0 F_1 D_3 Z_112 G_0 
Stack 7
Z_113 C_2 Z_114 Z_115 F_7 
Stack 8
H_1 Z_116 Z_117 G_3 E_2 
Stack 9
D_4 Z_118 F_4 I_0 J_0 
Stack 10
E_3 Z_119 I_3 F_5 G_1 
Stack 11
F_6 E_5 Z_120 B_1 E_1 
Stack 12
C_1 D_1 I_2 A_1 A_3 
Stack 13
D_5 I_1 D_0 H_4 F_0 
