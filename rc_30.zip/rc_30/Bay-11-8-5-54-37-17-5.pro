Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 B_4 B_0 Z_101 C_0 
Stack 1
A_6 A_4 Z_102 B_2 A_0 
Stack 2
A_2 B_5 C_7 Z_103 Z_104 
Stack 3
C_4 D_1 Z_105 Z_106 D_0 
Stack 4
Z_107 C_6 Z_108 E_5 Z_109 
Stack 5
Z_110 Z_111 C_1 Z_112 A_1 
Stack 6
A_5 C_5 Z_113 E_6 D_3 
Stack 7
B_6 B_1 B_3 D_2 D_5 
Stack 8
E_2 Z_114 B_7 C_3 Z_115 
Stack 9
C_8 E_3 E_4 E_0 D_4 
Stack 10
A_3 Z_116 C_2 E_1 
