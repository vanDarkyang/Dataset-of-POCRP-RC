Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
E_6 Z_100 Z_101 Z_102 I_0 
Stack 1
B_2 H_3 E_4 J_2 D_2 
Stack 2
Z_103 Z_104 Z_105 G_0 G_5 
Stack 3
F_3 Z_106 B_0 E_2 H_2 
Stack 4
D_0 H_1 I_2 B_3 Z_107 
Stack 5
F_1 D_3 C_0 J_0 D_1 
Stack 6
I_1 C_2 E_7 A_0 G_1 
Stack 7
G_2 E_1 Z_108 F_2 C_1 
Stack 8
E_3 E_0 Z_109 B_4 Z_110 
Stack 9
H_4 Z_111 Z_112 D_4 Z_113 
Stack 10
Z_114 F_0 C_3 H_5 G_6 
Stack 11
Z_115 Z_116 Z_117 B_1 G_7 
Stack 12
H_0 E_5 J_1 Z_118 G_3 
Stack 13
G_4 A_1 Z_119 Z_120 I_3 
