Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
F_0 Z_100 H_4 Z_101 A_1 Z_102 
Stack 1
G_1 G_4 H_6 D_3 B_0 K_1 
Stack 2
C_2 Z_103 Z_104 K_4 Z_105 F_1 
Stack 3
M_4 Z_106 D_1 L_4 G_5 Z_107 
Stack 4
Z_108 J_4 L_0 L_2 Z_109 
Stack 5
H_0 C_5 N_4 M_1 E_0 
Stack 6
H_3 F_5 Z_110 I_1 Z_111 
Stack 7
Z_112 N_1 H_1 F_6 G_0 
Stack 8
I_2 B_1 Z_113 J_5 Z_114 
Stack 9
Z_115 E_3 K_0 K_6 H_2 
Stack 10
B_3 L_3 Z_116 Z_117 Z_118 
Stack 11
Z_119 G_6 C_1 M_3 Z_120 
Stack 12
N_2 Z_121 Z_122 Z_123 O_1 
Stack 13
D_0 A_2 F_3 O_2 I_0 
Stack 14
G_2 J_1 F_2 K_3 J_6 
Stack 15
Z_124 G_3 Z_125 M_2 B_2 
Stack 16
G_7 Z_126 M_0 I_5 N_0 
Stack 17
J_0 Z_127 O_0 C_0 H_5 
Stack 18
L_1 Z_128 Z_129 M_5 Z_130 
Stack 19
C_3 I_3 Z_131 E_1 F_4 
Stack 20
Z_132 E_4 D_2 Z_133 Z_134 
Stack 21
J_3 N_3 F_7 Z_135 I_4 
Stack 22
E_2 C_4 Z_136 F_8 Z_137 
Stack 23
K_2 A_0 D_4 J_2 K_5 
