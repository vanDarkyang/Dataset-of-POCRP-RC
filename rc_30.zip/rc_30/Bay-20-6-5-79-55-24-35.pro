Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
B_1 D_10 Z_100 Z_101 
Stack 1
C_5 B_10 Z_102 D_6 
Stack 2
C_14 B_7 C_8 C_11 
Stack 3
E_0 C_13 D_13 E_2 
Stack 4
Z_103 Z_104 D_4 C_12 
Stack 5
A_4 D_2 Z_105 A_3 
Stack 6
C_4 A_0 D_1 Z_106 
Stack 7
A_1 D_9 B_3 C_2 
Stack 8
Z_107 Z_108 E_6 Z_109 
Stack 9
D_7 C_9 Z_110 B_2 
Stack 10
B_11 Z_111 Z_112 B_0 
Stack 11
Z_113 C_10 B_5 B_6 
Stack 12
Z_114 E_4 B_9 C_6 
Stack 13
D_5 D_11 Z_115 E_5 
Stack 14
C_1 D_8 Z_116 C_3 
Stack 15
Z_117 B_4 Z_118 A_2 
Stack 16
Z_119 D_3 D_12 Z_120 
Stack 17
Z_121 B_8 C_7 A_5 
Stack 18
D_14 Z_122 Z_123 C_0 
Stack 19
D_0 E_3 E_1 
