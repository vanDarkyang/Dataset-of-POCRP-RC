Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
C_3 I_0 E_1 H_1 
Stack 1
C_2 Z_100 J_2 C_1 
Stack 2
D_1 F_0 Z_101 G_4 
Stack 3
Z_102 D_3 E_3 B_1 
Stack 4
E_0 Z_103 Z_104 Z_105 
Stack 5
G_5 E_6 Z_106 A_0 
Stack 6
Z_107 H_2 Z_108 B_0 
Stack 7
Z_109 F_1 B_4 A_2 
Stack 8
E_2 D_5 Z_110 J_1 
Stack 9
B_3 Z_111 G_3 E_7 
Stack 10
E_8 D_4 B_2 G_2 
Stack 11
Z_112 I_2 E_5 Z_113 
Stack 12
A_3 H_0 Z_114 Z_115 
Stack 13
C_5 C_0 E_4 Z_116 
Stack 14
Z_117 J_0 F_2 Z_118 
Stack 15
G_0 A_1 C_4 G_1 
Stack 16
D_0 Z_119 I_1 
Stack 17
C_6 D_2 Z_120 
