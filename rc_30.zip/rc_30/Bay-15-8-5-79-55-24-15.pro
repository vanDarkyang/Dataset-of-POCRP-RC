Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_6 C_4 E_9 C_5 C_3 B_10 
Stack 1
B_1 A_5 E_11 B_0 E_2 E_12 
Stack 2
Z_100 E_3 Z_101 Z_102 Z_103 B_8 
Stack 3
B_11 C_1 C_9 Z_104 Z_105 Z_106 
Stack 4
D_0 Z_107 Z_108 B_4 D_2 
Stack 5
A_2 Z_109 Z_110 D_5 E_0 
Stack 6
Z_111 Z_112 Z_113 E_1 D_3 
Stack 7
A_4 D_6 D_11 E_5 E_8 
Stack 8
Z_114 A_7 Z_115 D_9 A_0 
Stack 9
B_2 A_1 Z_116 Z_117 Z_118 
Stack 10
C_2 B_6 A_3 C_7 D_1 
Stack 11
E_7 B_3 E_6 E_10 E_4 
Stack 12
Z_119 Z_120 D_10 C_0 Z_121 
Stack 13
B_9 D_8 Z_122 B_5 B_7 
Stack 14
D_7 C_8 D_4 Z_123 C_6 
