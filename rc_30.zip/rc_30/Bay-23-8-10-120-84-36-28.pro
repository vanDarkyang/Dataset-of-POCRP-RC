Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 B_0 I_7 A_6 E_4 Z_101 
Stack 1
H_2 E_8 Z_102 G_7 Z_103 Z_104 
Stack 2
Z_105 B_2 J_3 E_0 C_8 C_6 
Stack 3
Z_106 C_1 Z_107 I_5 G_2 D_3 
Stack 4
Z_108 H_5 Z_109 Z_110 J_1 A_2 
Stack 5
C_7 G_6 Z_111 B_5 C_4 
Stack 6
Z_112 E_3 G_5 C_10 A_0 
Stack 7
I_3 D_5 B_1 A_1 B_3 
Stack 8
F_5 D_0 Z_113 Z_114 I_4 
Stack 9
Z_115 F_4 B_4 E_5 H_0 
Stack 10
I_2 Z_116 D_6 Z_117 Z_118 
Stack 11
Z_119 D_2 A_4 I_0 Z_120 
Stack 12
J_5 G_3 C_5 Z_121 Z_122 
Stack 13
F_0 C_0 H_1 H_8 Z_123 
Stack 14
J_4 H_3 I_1 J_6 F_3 
Stack 15
Z_124 G_4 Z_125 I_6 A_5 
Stack 16
E_2 Z_126 Z_127 Z_128 G_0 
Stack 17
D_7 E_7 F_6 D_8 E_6 
Stack 18
H_4 H_7 H_6 Z_129 C_9 
Stack 19
C_2 F_1 A_3 A_7 Z_130 
Stack 20
C_3 G_1 J_2 G_8 Z_131 
Stack 21
Z_132 Z_133 Z_134 F_2 D_1 
Stack 22
D_4 F_7 J_0 E_1 Z_135 
