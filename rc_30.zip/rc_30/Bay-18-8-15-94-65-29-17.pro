Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 Z_101 Z_102 K_2 I_5 Z_103 
Stack 1
B_1 Z_104 Z_105 Z_106 O_0 H_0 
Stack 2
Z_107 N_2 H_3 N_1 E_0 N_0 
Stack 3
D_2 H_6 J_1 Z_108 C_1 Z_109 
Stack 4
A_2 Z_110 D_3 G_1 J_3 
Stack 5
K_0 Z_111 J_0 L_0 Z_112 
Stack 6
G_4 G_5 B_2 Z_113 D_1 
Stack 7
G_3 E_4 F_4 G_2 H_5 
Stack 8
Z_114 A_0 B_0 D_5 Z_115 
Stack 9
I_3 I_0 K_3 H_2 F_3 
Stack 10
L_2 I_2 H_4 L_1 H_8 
Stack 11
J_2 Z_116 J_4 J_5 Z_117 
Stack 12
E_2 F_0 Z_118 Z_119 G_0 
Stack 13
K_1 Z_120 Z_121 M_1 H_7 
Stack 14
Z_122 I_1 I_4 E_1 A_1 
Stack 15
D_4 Z_123 Z_124 F_5 Z_125 
Stack 16
F_1 Z_126 D_0 F_2 C_0 
Stack 17
E_3 M_0 Z_127 Z_128 H_1 
