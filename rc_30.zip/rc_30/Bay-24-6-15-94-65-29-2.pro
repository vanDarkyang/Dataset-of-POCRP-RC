Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 D_5 N_0 M_0 
Stack 1
L_2 Z_101 N_3 H_3 
Stack 2
H_2 G_7 Z_102 L_0 
Stack 3
G_6 D_2 K_0 H_0 
Stack 4
B_0 G_1 I_3 Z_103 
Stack 5
G_2 G_0 K_4 Z_104 
Stack 6
Z_105 H_5 Z_106 E_2 
Stack 7
D_3 Z_107 E_1 H_6 
Stack 8
I_0 I_6 C_3 E_3 
Stack 9
D_0 J_0 L_1 Z_108 
Stack 10
J_2 M_1 F_2 I_5 
Stack 11
C_0 N_2 E_4 I_2 
Stack 12
J_3 C_1 Z_109 Z_110 
Stack 13
Z_111 I_1 F_0 N_1 
Stack 14
O_1 H_1 M_2 G_4 
Stack 15
Z_112 C_2 H_4 I_4 
Stack 16
Z_113 K_1 Z_114 E_0 
Stack 17
Z_115 Z_116 Z_117 Z_118 
Stack 18
J_1 D_1 Z_119 G_3 
Stack 19
Z_120 M_3 Z_121 Z_122 
Stack 20
A_0 Z_123 Z_124 A_1 
Stack 21
F_1 Z_125 O_0 Z_126 
Stack 22
G_5 K_2 Z_127 
Stack 23
Z_128 D_4 K_3 
