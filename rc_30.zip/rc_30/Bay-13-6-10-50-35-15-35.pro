Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
C_1 F_1 E_3 Z_100 
Stack 1
Z_101 J_0 D_1 H_2 
Stack 2
Z_102 Z_103 I_1 F_4 
Stack 3
D_0 C_0 A_1 G_3 
Stack 4
F_0 B_1 Z_104 H_0 
Stack 5
C_4 F_3 D_3 Z_105 
Stack 6
G_1 Z_106 E_1 D_4 
Stack 7
Z_107 Z_108 C_3 G_2 
Stack 8
C_2 F_5 G_0 Z_109 
Stack 9
Z_110 E_2 A_0 F_2 
Stack 10
B_0 Z_111 Z_112 E_0 
Stack 11
I_0 Z_113 H_1 
Stack 12
Z_114 D_2 A_2 
