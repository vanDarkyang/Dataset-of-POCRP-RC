Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_4 Z_100 C_6 Z_101 Z_102 E_13 
Stack 1
Z_103 D_0 Z_104 Z_105 A_6 Z_106 
Stack 2
Z_107 Z_108 Z_109 B_12 E_7 B_8 
Stack 3
Z_110 B_5 B_11 Z_111 C_3 D_2 
Stack 4
C_9 Z_112 B_6 C_5 B_10 
Stack 5
Z_113 E_4 Z_114 B_7 E_5 
Stack 6
E_10 Z_115 A_8 E_9 E_11 
Stack 7
C_8 B_2 B_9 A_7 B_0 
Stack 8
C_7 A_0 E_6 Z_116 Z_117 
Stack 9
B_1 E_8 D_3 E_2 E_1 
Stack 10
Z_118 D_5 C_0 E_0 A_1 
Stack 11
A_4 Z_119 E_12 C_1 E_3 
Stack 12
Z_120 A_5 B_13 C_2 B_3 
Stack 13
C_10 Z_121 C_4 D_6 A_2 
Stack 14
Z_122 Z_123 A_3 B_4 D_1 
