Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_2 D_0 E_6 C_7 
Stack 1
B_2 Z_100 C_1 A_6 
Stack 2
C_4 B_0 Z_101 A_1 
Stack 3
Z_102 Z_103 A_4 D_3 
Stack 4
B_1 E_4 B_3 C_5 
Stack 5
Z_104 A_7 C_6 D_5 
Stack 6
Z_105 Z_106 C_0 Z_107 
Stack 7
D_1 Z_108 E_0 Z_109 
Stack 8
B_5 C_2 Z_110 E_7 
Stack 9
Z_111 A_2 D_4 Z_112 
Stack 10
C_3 E_5 A_0 Z_113 
Stack 11
E_3 E_1 Z_114 Z_115 
Stack 12
D_6 A_3 E_2 
Stack 13
B_4 Z_116 A_5 
