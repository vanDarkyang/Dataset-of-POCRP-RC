Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 C_10 C_3 C_8 
Stack 1
C_5 A_1 A_6 B_3 
Stack 2
A_0 B_7 A_8 C_4 
Stack 3
A_3 Z_101 C_9 A_2 
Stack 4
B_0 C_11 Z_102 A_7 
Stack 5
B_8 Z_103 A_4 Z_104 
Stack 6
Z_105 B_2 A_10 Z_106 
Stack 7
C_6 Z_107 B_5 B_6 
Stack 8
A_9 Z_108 C_7 B_1 
Stack 9
C_1 Z_109 C_0 Z_110 
Stack 10
C_2 Z_111 B_4 
Stack 11
Z_112 A_5 Z_113 
