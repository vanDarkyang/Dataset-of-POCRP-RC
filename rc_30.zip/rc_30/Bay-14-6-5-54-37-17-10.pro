Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_6 B_8 E_6 D_6 
Stack 1
B_0 E_7 Z_100 E_0 
Stack 2
A_5 A_2 A_3 E_5 
Stack 3
Z_101 C_1 B_1 Z_102 
Stack 4
B_5 D_0 B_2 B_3 
Stack 5
Z_103 Z_104 D_3 Z_105 
Stack 6
E_2 Z_106 E_8 D_2 
Stack 7
Z_107 D_4 A_1 C_2 
Stack 8
Z_108 C_5 E_1 B_4 
Stack 9
Z_109 Z_110 D_1 A_4 
Stack 10
E_3 Z_111 C_3 Z_112 
Stack 11
Z_113 A_0 D_5 E_4 
Stack 12
Z_114 C_4 Z_115 
Stack 13
Z_116 B_7 C_0 
