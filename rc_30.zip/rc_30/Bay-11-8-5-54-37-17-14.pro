Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
C_7 C_2 A_2 B_4 E_4 
Stack 1
D_0 Z_100 Z_101 E_5 Z_102 
Stack 2
Z_103 A_3 A_1 C_6 D_2 
Stack 3
Z_104 E_0 A_5 C_0 B_5 
Stack 4
Z_105 E_1 Z_106 E_6 Z_107 
Stack 5
C_8 C_4 C_1 E_3 B_0 
Stack 6
Z_108 Z_109 D_6 C_3 C_5 
Stack 7
D_5 B_6 D_1 Z_110 Z_111 
Stack 8
B_7 Z_112 A_0 D_3 D_4 
Stack 9
B_2 Z_113 Z_114 Z_115 B_1 
Stack 10
E_2 B_3 A_4 Z_116 
