Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
C_2 L_0 E_5 F_2 Z_100 K_1 
Stack 1
Z_101 G_3 Z_102 Z_103 E_0 E_3 
Stack 2
Z_104 H_5 H_6 G_1 D_4 N_2 
Stack 3
Z_105 H_8 B_3 E_1 C_1 J_4 
Stack 4
L_2 F_6 I_3 L_4 I_0 
Stack 5
Z_106 Z_107 Z_108 I_4 Z_109 
Stack 6
B_0 Z_110 F_5 N_0 H_0 
Stack 7
Z_111 N_1 Z_112 M_1 J_1 
Stack 8
C_3 C_4 Z_113 Z_114 L_3 
Stack 9
K_2 K_5 I_2 G_4 F_8 
Stack 10
Z_115 G_8 Z_116 Z_117 J_3 
Stack 11
K_6 Z_118 Z_119 Z_120 F_0 
Stack 12
Z_121 D_0 N_3 L_1 I_6 
Stack 13
D_3 Z_122 D_2 F_3 E_4 
Stack 14
F_1 G_6 G_7 H_4 G_5 
Stack 15
K_4 B_1 Z_123 J_0 C_0 
Stack 16
Z_124 Z_125 K_0 M_2 F_7 
Stack 17
H_1 Z_126 Z_127 O_2 A_0 
Stack 18
I_1 Z_128 I_8 D_1 Z_129 
Stack 19
Z_130 G_0 O_1 E_6 Z_131 
Stack 20
B_2 J_5 Z_132 E_2 H_3 
Stack 21
G_2 J_2 H_2 Z_133 Z_134 
Stack 22
F_4 I_5 Z_135 O_0 Z_136 
Stack 23
Z_137 H_7 I_7 K_3 M_0 
