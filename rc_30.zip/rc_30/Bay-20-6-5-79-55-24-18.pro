Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 Z_101 C_1 E_10 
Stack 1
D_4 D_10 E_9 A_8 
Stack 2
Z_102 B_1 B_11 Z_103 
Stack 3
A_0 A_1 C_5 C_4 
Stack 4
C_8 Z_104 A_3 B_8 
Stack 5
Z_105 D_7 A_6 E_4 
Stack 6
E_7 D_1 Z_106 E_8 
Stack 7
C_7 A_7 B_10 Z_107 
Stack 8
C_6 Z_108 Z_109 Z_110 
Stack 9
B_0 A_5 Z_111 E_1 
Stack 10
A_2 Z_112 Z_113 Z_114 
Stack 11
A_4 Z_115 E_6 E_3 
Stack 12
C_0 D_3 A_9 B_2 
Stack 13
C_9 Z_116 Z_117 Z_118 
Stack 14
Z_119 B_5 E_2 D_2 
Stack 15
D_8 D_9 E_0 Z_120 
Stack 16
D_0 A_10 C_2 Z_121 
Stack 17
D_5 B_7 C_3 B_6 
Stack 18
B_4 E_5 Z_122 D_6 
Stack 19
B_9 Z_123 B_3 
