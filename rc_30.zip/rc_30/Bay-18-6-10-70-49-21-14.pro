Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
G_3 Z_100 H_4 D_3 
Stack 1
Z_101 A_0 G_4 C_4 
Stack 2
D_4 Z_102 F_4 J_0 
Stack 3
Z_103 C_1 Z_104 C_5 
Stack 4
H_3 B_0 Z_105 E_2 
Stack 5
F_2 Z_106 Z_107 J_1 
Stack 6
C_0 Z_108 Z_109 D_5 
Stack 7
G_1 Z_110 H_5 H_0 
Stack 8
Z_111 F_5 D_1 Z_112 
Stack 9
B_4 Z_113 E_1 I_0 
Stack 10
B_2 D_2 B_3 Z_114 
Stack 11
I_3 C_3 I_1 E_3 
Stack 12
E_0 E_4 Z_115 J_2 
Stack 13
D_0 B_1 H_2 Z_116 
Stack 14
Z_117 G_2 I_2 G_0 
Stack 15
E_6 F_3 E_5 H_1 
Stack 16
Z_118 C_2 F_0 
Stack 17
Z_119 Z_120 F_1 
