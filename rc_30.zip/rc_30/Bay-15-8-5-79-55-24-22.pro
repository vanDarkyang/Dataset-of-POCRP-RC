Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
E_0 Z_100 A_4 Z_101 E_8 E_1 
Stack 1
Z_102 A_1 D_0 A_2 B_3 E_2 
Stack 2
D_3 C_12 C_8 D_2 C_1 B_4 
Stack 3
D_6 Z_103 C_2 A_7 C_5 C_3 
Stack 4
Z_104 A_9 B_8 Z_105 Z_106 
Stack 5
A_8 D_11 Z_107 Z_108 D_10 
Stack 6
Z_109 Z_110 E_6 A_0 A_3 
Stack 7
C_11 B_5 B_6 Z_111 Z_112 
Stack 8
B_1 Z_113 Z_114 Z_115 E_7 
Stack 9
D_8 Z_116 Z_117 Z_118 Z_119 
Stack 10
E_4 C_10 C_13 C_0 D_7 
Stack 11
C_7 Z_120 B_7 B_2 E_5 
Stack 12
D_5 C_9 D_9 E_3 D_1 
Stack 13
B_0 D_4 A_6 A_5 C_6 
Stack 14
A_10 Z_121 Z_122 C_4 Z_123 
