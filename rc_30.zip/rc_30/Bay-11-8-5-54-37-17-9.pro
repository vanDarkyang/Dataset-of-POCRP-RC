Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_1 C_0 C_3 Z_100 Z_101 
Stack 1
E_4 Z_102 Z_103 B_0 D_0 
Stack 2
A_2 B_2 D_6 B_1 D_3 
Stack 3
Z_104 Z_105 C_7 E_0 Z_106 
Stack 4
A_7 E_3 Z_107 A_6 Z_108 
Stack 5
B_6 Z_109 A_5 Z_110 C_5 
Stack 6
D_5 A_1 Z_111 A_0 B_3 
Stack 7
Z_112 A_3 C_2 D_2 B_5 
Stack 8
Z_113 B_7 Z_114 E_1 C_4 
Stack 9
Z_115 C_1 A_4 B_4 Z_116 
Stack 10
C_6 E_5 D_4 E_2 
