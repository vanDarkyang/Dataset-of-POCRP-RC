Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
C_1 I_0 Z_100 M_0 
Stack 1
N_2 K_5 E_0 J_1 
Stack 2
F_6 Z_101 H_1 D_4 
Stack 3
B_2 C_2 H_0 Z_102 
Stack 4
Z_103 C_0 G_2 N_0 
Stack 5
D_3 G_0 A_2 N_1 
Stack 6
E_2 L_1 H_2 Z_104 
Stack 7
Z_105 L_0 O_1 Z_106 
Stack 8
Z_107 E_4 Z_108 Z_109 
Stack 9
G_3 F_0 M_2 B_0 
Stack 10
I_2 Z_110 Z_111 Z_112 
Stack 11
H_3 D_0 I_4 D_2 
Stack 12
L_2 Z_113 K_3 Z_114 
Stack 13
L_3 K_6 A_1 E_5 
Stack 14
I_3 Z_115 Z_116 Z_117 
Stack 15
G_1 A_0 F_4 B_1 
Stack 16
F_1 K_4 Z_118 H_4 
Stack 17
Z_119 Z_120 J_2 Z_121 
Stack 18
Z_122 F_2 F_3 Z_123 
Stack 19
F_5 I_1 Z_124 Z_125 
Stack 20
E_3 Z_126 J_0 K_0 
Stack 21
Z_127 K_2 Z_128 K_1 
Stack 22
M_1 E_1 J_3 
Stack 23
D_1 I_5 O_0 
