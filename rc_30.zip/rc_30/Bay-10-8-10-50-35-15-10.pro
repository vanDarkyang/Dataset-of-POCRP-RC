Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
E_3 E_0 H_0 Z_100 E_4 
Stack 1
E_1 Z_101 Z_102 Z_103 Z_104 
Stack 2
Z_105 D_1 I_1 I_3 C_1 
Stack 3
G_3 E_2 G_0 J_0 I_0 
Stack 4
Z_106 D_0 Z_107 G_2 Z_108 
Stack 5
F_0 H_4 C_0 Z_109 Z_110 
Stack 6
D_3 G_4 F_3 Z_111 H_3 
Stack 7
F_2 F_1 H_2 D_2 I_2 
Stack 8
D_4 H_1 G_1 C_2 A_0 
Stack 9
Z_112 B_0 Z_113 Z_114 B_1 
