Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 B_1 C_3 Z_101 Z_102 
Stack 1
E_0 B_5 Z_103 A_7 E_1 
Stack 2
C_0 Z_104 Z_105 D_3 B_6 
Stack 3
A_4 C_8 D_2 E_2 A_3 
Stack 4
E_4 Z_106 Z_107 Z_108 C_2 
Stack 5
E_3 D_1 B_2 E_5 B_4 
Stack 6
A_0 A_6 Z_109 D_5 A_1 
Stack 7
B_3 Z_110 Z_111 Z_112 D_4 
Stack 8
C_1 Z_113 C_4 Z_114 A_2 
Stack 9
Z_115 Z_116 C_5 B_0 C_7 
Stack 10
C_9 C_6 D_0 A_5 
