Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_0 Z_100 B_11 C_1 
Stack 1
A_4 D_11 E_0 Z_101 
Stack 2
Z_102 Z_103 D_5 C_7 
Stack 3
A_6 C_3 B_2 B_12 
Stack 4
B_9 D_0 B_5 Z_104 
Stack 5
B_0 E_9 Z_105 A_5 
Stack 6
A_1 Z_106 Z_107 Z_108 
Stack 7
B_1 C_5 E_4 E_3 
Stack 8
Z_109 D_8 D_3 A_9 
Stack 9
D_7 B_6 D_10 A_2 
Stack 10
B_3 C_4 E_2 E_10 
Stack 11
D_4 D_1 E_5 Z_110 
Stack 12
C_6 Z_111 Z_112 Z_113 
Stack 13
Z_114 Z_115 E_6 Z_116 
Stack 14
Z_117 D_9 C_2 E_7 
Stack 15
C_0 Z_118 D_6 A_3 
Stack 16
Z_119 D_2 E_8 B_7 
Stack 17
Z_120 B_4 A_8 Z_121 
Stack 18
Z_122 D_12 A_7 B_10 
Stack 19
Z_123 B_8 E_1 
