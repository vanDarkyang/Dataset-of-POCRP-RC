Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
9
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_0 H_2 D_1 A_3 
Stack 1
H_1 G_0 C_3 C_5 
Stack 2
Z_100 Z_101 E_0 G_2 
Stack 3
E_1 D_2 I_2 B_1 
Stack 4
F_2 Z_102 I_0 Z_103 
Stack 5
H_5 Z_104 G_6 I_4 
Stack 6
A_0 B_0 H_0 A_2 
Stack 7
Z_105 E_2 I_1 C_4 
Stack 8
F_1 D_3 Z_106 H_4 
Stack 9
G_1 Z_107 E_4 B_3 
Stack 10
E_6 A_1 Z_108 G_3 
Stack 11
Z_109 H_3 Z_110 G_4 
Stack 12
Z_111 E_5 Z_112 Z_113 
Stack 13
Z_114 Z_115 C_1 Z_116 
Stack 14
C_2 F_0 E_3 B_2 
Stack 15
Z_117 F_3 G_5 F_5 
Stack 16
Z_118 Z_119 I_3 
Stack 17
Z_120 F_4 C_0 
