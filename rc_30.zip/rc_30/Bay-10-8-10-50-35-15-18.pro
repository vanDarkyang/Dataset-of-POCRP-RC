Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 E_4 E_3 D_2 H_2 
Stack 1
B_1 D_1 E_2 Z_101 C_2 
Stack 2
A_0 H_1 C_1 G_2 E_6 
Stack 3
Z_102 E_0 H_3 G_4 H_0 
Stack 4
Z_103 G_3 F_1 J_1 J_0 
Stack 5
D_0 B_0 I_1 Z_104 Z_105 
Stack 6
D_3 Z_106 Z_107 Z_108 E_5 
Stack 7
Z_109 Z_110 G_0 Z_111 D_4 
Stack 8
G_1 E_1 I_2 Z_112 C_0 
Stack 9
C_3 F_0 Z_113 I_0 Z_114 
