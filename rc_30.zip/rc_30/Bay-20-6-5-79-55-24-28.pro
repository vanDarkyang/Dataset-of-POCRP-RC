Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_4 Z_100 D_0 Z_101 
Stack 1
A_6 B_10 Z_102 D_4 
Stack 2
D_7 A_7 B_7 Z_103 
Stack 3
Z_104 Z_105 A_5 Z_106 
Stack 4
B_8 D_9 Z_107 C_3 
Stack 5
A_3 D_8 B_1 E_2 
Stack 6
E_9 Z_108 D_1 E_0 
Stack 7
Z_109 B_4 D_3 E_1 
Stack 8
Z_110 C_6 C_0 Z_111 
Stack 9
B_0 Z_112 C_9 Z_113 
Stack 10
E_6 C_5 E_4 E_10 
Stack 11
B_3 Z_114 C_11 Z_115 
Stack 12
C_8 A_0 C_1 C_7 
Stack 13
Z_116 Z_117 D_6 E_5 
Stack 14
E_7 D_2 C_4 A_8 
Stack 15
B_2 B_5 E_8 C_10 
Stack 16
Z_118 E_11 A_2 B_6 
Stack 17
B_9 C_2 D_5 Z_119 
Stack 18
Z_120 B_11 A_1 Z_121 
Stack 19
Z_122 E_3 Z_123 
