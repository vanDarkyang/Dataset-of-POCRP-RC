Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
C_6 Z_100 C_2 C_0 D_0 G_0 
Stack 1
Z_101 C_7 I_9 Z_102 B_5 Z_103 
Stack 2
B_1 F_9 Z_104 Z_105 D_2 Z_106 
Stack 3
A_5 F_7 E_5 I_5 I_6 B_4 
Stack 4
I_8 Z_107 H_0 D_3 F_8 E_2 
Stack 5
Z_108 I_4 J_4 B_0 I_2 
Stack 6
Z_109 C_4 F_10 Z_110 Z_111 
Stack 7
C_5 Z_112 B_7 E_6 Z_113 
Stack 8
Z_114 Z_115 J_2 I_0 Z_116 
Stack 9
I_1 F_0 J_6 G_2 E_0 
Stack 10
F_1 B_6 A_2 Z_117 Z_118 
Stack 11
C_9 B_8 F_6 A_7 E_8 
Stack 12
H_5 F_3 J_1 H_6 A_6 
Stack 13
Z_119 Z_120 I_7 C_8 H_4 
Stack 14
H_1 Z_121 Z_122 D_5 F_4 
Stack 15
Z_123 A_0 Z_124 A_1 D_4 
Stack 16
F_2 H_3 H_2 C_1 Z_125 
Stack 17
Z_126 Z_127 B_3 F_5 Z_128 
Stack 18
Z_129 Z_130 J_5 J_0 I_3 
Stack 19
C_3 Z_131 J_3 E_4 Z_132 
Stack 20
E_1 G_1 E_7 J_7 A_3 
Stack 21
Z_133 Z_134 E_3 G_4 D_1 
Stack 22
G_3 A_4 A_8 B_2 Z_135 
