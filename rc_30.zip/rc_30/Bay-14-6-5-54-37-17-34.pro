Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
C_2 E_1 D_7 Z_100 
Stack 1
Z_101 D_0 Z_102 B_6 
Stack 2
B_8 D_3 B_2 E_2 
Stack 3
D_9 Z_103 B_7 C_4 
Stack 4
B_5 E_4 E_0 Z_104 
Stack 5
Z_105 C_6 C_5 Z_106 
Stack 6
B_3 A_3 C_0 Z_107 
Stack 7
A_2 Z_108 A_1 B_0 
Stack 8
C_3 Z_109 Z_110 D_1 
Stack 9
E_6 Z_111 Z_112 Z_113 
Stack 10
B_1 D_5 D_6 D_4 
Stack 11
B_4 Z_114 E_3 A_0 
Stack 12
Z_115 C_1 D_8 
Stack 13
D_2 Z_116 E_5 
