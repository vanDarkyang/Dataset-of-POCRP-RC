Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 H_3 I_0 D_0 E_3 G_2 
Stack 1
G_6 Z_101 I_2 D_1 J_0 Z_102 
Stack 2
E_0 Z_103 Z_104 C_1 H_1 Z_105 
Stack 3
Z_106 M_1 J_3 E_4 Z_107 M_0 
Stack 4
Z_108 F_5 E_2 Z_109 G_1 
Stack 5
I_1 F_0 M_2 F_2 F_1 
Stack 6
E_5 G_0 H_4 Z_110 K_2 
Stack 7
G_4 Z_111 Z_112 O_0 Z_113 
Stack 8
K_0 Z_114 L_0 A_2 Z_115 
Stack 9
Z_116 K_3 E_1 Z_117 J_2 
Stack 10
L_1 L_2 N_0 H_0 Z_118 
Stack 11
Z_119 H_2 Z_120 F_4 C_2 
Stack 12
I_5 Z_121 Z_122 Z_123 H_6 
Stack 13
F_3 Z_124 J_4 G_3 A_0 
Stack 14
N_1 H_5 G_5 K_1 H_7 
Stack 15
B_1 O_1 Z_125 K_4 Z_126 
Stack 16
Z_127 C_0 I_3 J_1 I_4 
Stack 17
A_1 K_5 Z_128 B_2 B_0 
