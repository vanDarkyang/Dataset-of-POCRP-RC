Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
14
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
E_0 Z_100 Z_101 I_0 L_1 F_5 
Stack 1
E_1 G_0 F_3 Z_102 Z_103 G_4 
Stack 2
M_1 D_0 C_1 H_2 I_1 H_5 
Stack 3
M_2 H_7 I_5 Z_104 K_3 Z_105 
Stack 4
J_4 G_5 C_0 Z_106 D_1 
Stack 5
Z_107 H_6 H_4 K_0 K_1 
Stack 6
H_1 Z_108 C_2 F_0 Z_109 
Stack 7
L_0 Z_110 N_1 Z_111 D_3 
Stack 8
Z_112 J_2 I_2 Z_113 K_2 
Stack 9
Z_114 N_2 A_1 D_2 E_3 
Stack 10
Z_115 Z_116 M_0 L_2 E_2 
Stack 11
K_4 J_6 F_4 G_1 Z_117 
Stack 12
E_4 F_2 F_1 Z_118 H_3 
Stack 13
Z_119 I_4 I_6 Z_120 J_3 
Stack 14
J_1 Z_121 H_0 J_0 A_0 
Stack 15
E_5 G_2 Z_122 Z_123 N_0 
Stack 16
B_0 J_5 Z_124 G_3 Z_125 
Stack 17
Z_126 Z_127 I_3 G_6 Z_128 
