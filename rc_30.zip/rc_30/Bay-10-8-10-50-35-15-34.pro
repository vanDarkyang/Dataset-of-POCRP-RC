Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
F_1 D_3 E_2 Z_100 Z_101 
Stack 1
G_3 Z_102 D_2 A_1 F_2 
Stack 2
Z_103 C_0 B_1 E_3 C_2 
Stack 3
B_0 A_0 I_1 Z_104 F_3 
Stack 4
D_0 E_1 Z_105 Z_106 G_2 
Stack 5
G_1 H_0 J_1 F_4 I_0 
Stack 6
Z_107 Z_108 Z_109 E_4 Z_110 
Stack 7
Z_111 F_0 J_2 G_4 J_0 
Stack 8
G_0 Z_112 C_1 A_2 E_0 
Stack 9
H_2 Z_113 H_1 Z_114 D_1 
