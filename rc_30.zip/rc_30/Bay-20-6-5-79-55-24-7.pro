Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_2 C_10 Z_100 D_8 
Stack 1
A_4 C_5 B_10 E_0 
Stack 2
A_6 B_6 B_12 Z_101 
Stack 3
Z_102 D_1 C_8 E_8 
Stack 4
B_11 B_7 C_9 E_7 
Stack 5
Z_103 B_9 B_4 B_0 
Stack 6
Z_104 E_10 Z_105 D_5 
Stack 7
Z_106 B_3 A_7 Z_107 
Stack 8
B_2 E_3 A_0 Z_108 
Stack 9
B_5 Z_109 C_0 Z_110 
Stack 10
C_11 D_4 E_5 E_6 
Stack 11
B_8 Z_111 Z_112 E_4 
Stack 12
Z_113 A_1 Z_114 A_5 
Stack 13
E_1 Z_115 D_3 E_2 
Stack 14
Z_116 Z_117 Z_118 D_2 
Stack 15
D_7 D_6 C_7 Z_119 
Stack 16
D_0 E_9 C_6 Z_120 
Stack 17
C_12 C_1 B_13 C_4 
Stack 18
Z_121 Z_122 C_2 Z_123 
Stack 19
B_1 A_3 C_3 
