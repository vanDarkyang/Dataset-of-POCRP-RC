Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
B_0 F_2 Z_100 E_5 
Stack 1
C_0 D_0 Z_101 Z_102 
Stack 2
E_1 E_0 E_2 Z_103 
Stack 3
Z_104 F_3 G_1 A_1 
Stack 4
D_1 A_0 Z_105 Z_106 
Stack 5
C_1 Z_107 H_0 Z_108 
Stack 6
Z_109 D_2 Z_110 J_0 
Stack 7
E_4 F_4 A_2 B_1 
Stack 8
C_2 H_2 H_1 Z_111 
Stack 9
G_2 I_1 G_0 H_3 
Stack 10
F_0 J_1 E_3 Z_112 
Stack 11
F_5 Z_113 I_0 
Stack 12
F_1 G_3 Z_114 
