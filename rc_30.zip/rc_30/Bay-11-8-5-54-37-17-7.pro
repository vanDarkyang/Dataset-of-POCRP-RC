Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
C_4 Z_100 C_2 A_3 B_3 
Stack 1
E_6 Z_101 Z_102 A_2 E_4 
Stack 2
Z_103 A_0 Z_104 Z_105 Z_106 
Stack 3
D_4 B_7 C_1 Z_107 B_4 
Stack 4
D_5 Z_108 B_6 E_1 D_0 
Stack 5
B_5 C_0 D_3 Z_109 C_3 
Stack 6
C_5 Z_110 E_7 A_7 E_2 
Stack 7
Z_111 A_6 B_1 E_5 D_2 
Stack 8
A_4 E_0 Z_112 D_1 Z_113 
Stack 9
A_1 E_3 Z_114 B_0 A_5 
Stack 10
Z_115 B_8 Z_116 B_2 
