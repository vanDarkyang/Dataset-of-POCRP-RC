Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 D_5 Z_101 E_2 Z_102 
Stack 1
D_0 B_6 A_1 Z_103 E_1 
Stack 2
D_4 Z_104 D_6 Z_105 C_6 
Stack 3
A_2 B_1 Z_106 A_7 A_6 
Stack 4
B_0 Z_107 D_2 Z_108 C_0 
Stack 5
Z_109 C_7 D_1 E_0 Z_110 
Stack 6
C_2 B_2 B_3 Z_111 E_5 
Stack 7
Z_112 A_4 C_5 B_5 Z_113 
Stack 8
E_3 Z_114 C_4 Z_115 E_4 
Stack 9
C_1 B_4 C_3 E_6 A_3 
Stack 10
Z_116 A_0 D_3 A_5 
