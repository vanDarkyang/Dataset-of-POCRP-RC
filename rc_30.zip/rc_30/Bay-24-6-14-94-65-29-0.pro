Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
14
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
K_0 Z_100 K_3 M_2 
Stack 1
B_0 Z_101 C_0 E_3 
Stack 2
L_1 F_4 B_3 Z_102 
Stack 3
Z_103 H_2 I_7 D_1 
Stack 4
Z_104 L_0 Z_105 E_1 
Stack 5
N_2 I_6 Z_106 C_2 
Stack 6
Z_107 E_2 K_1 L_3 
Stack 7
Z_108 I_2 E_5 Z_109 
Stack 8
E_0 Z_110 H_1 G_4 
Stack 9
Z_111 Z_112 Z_113 M_1 
Stack 10
Z_114 D_5 M_0 L_4 
Stack 11
D_2 F_3 G_5 F_1 
Stack 12
I_0 E_4 C_1 D_3 
Stack 13
I_1 Z_115 J_2 J_0 
Stack 14
D_4 Z_116 J_1 G_3 
Stack 15
G_2 N_1 H_4 N_0 
Stack 16
G_1 K_5 J_3 Z_117 
Stack 17
Z_118 Z_119 I_4 I_5 
Stack 18
H_3 L_2 H_0 B_2 
Stack 19
Z_120 A_0 Z_121 Z_122 
Stack 20
Z_123 Z_124 K_4 G_0 
Stack 21
K_2 D_0 Z_125 Z_126 
Stack 22
B_1 F_2 Z_127 
Stack 23
F_0 Z_128 I_3 
