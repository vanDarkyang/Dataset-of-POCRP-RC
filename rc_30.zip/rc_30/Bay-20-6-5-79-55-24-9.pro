Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 A_1 Z_101 Z_102 
Stack 1
C_1 C_0 B_11 D_2 
Stack 2
Z_103 Z_104 B_9 Z_105 
Stack 3
B_7 D_6 C_5 A_6 
Stack 4
A_2 E_1 Z_106 E_10 
Stack 5
Z_107 Z_108 D_3 B_6 
Stack 6
Z_109 E_7 Z_110 E_6 
Stack 7
A_4 D_7 Z_111 A_0 
Stack 8
Z_112 E_0 D_4 B_1 
Stack 9
Z_113 C_3 B_0 E_3 
Stack 10
B_5 Z_114 D_1 D_8 
Stack 11
D_0 B_4 Z_115 A_10 
Stack 12
B_3 A_3 E_8 A_7 
Stack 13
Z_116 Z_117 Z_118 E_5 
Stack 14
A_11 Z_119 C_6 A_5 
Stack 15
E_9 A_9 B_2 E_4 
Stack 16
A_8 D_9 Z_120 C_2 
Stack 17
B_10 D_10 D_11 B_8 
Stack 18
Z_121 E_2 C_4 C_7 
Stack 19
D_5 Z_122 Z_123 
