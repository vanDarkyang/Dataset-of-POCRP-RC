Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 H_6 C_0 M_0 Z_101 Z_102 
Stack 1
M_1 L_4 K_0 E_0 Z_103 B_3 
Stack 2
I_3 G_0 Z_104 D_1 J_5 N_0 
Stack 3
A_1 H_0 H_2 K_2 Z_105 Z_106 
Stack 4
K_1 G_3 Z_107 G_4 C_2 
Stack 5
B_1 L_2 G_5 C_1 F_1 
Stack 6
H_5 F_0 N_2 E_3 G_2 
Stack 7
Z_108 E_2 Z_109 Z_110 J_1 
Stack 8
J_2 O_1 B_2 Z_111 L_5 
Stack 9
Z_112 O_0 H_1 H_3 G_1 
Stack 10
D_2 H_4 J_4 L_1 N_3 
Stack 11
Z_113 Z_114 J_0 D_0 N_1 
Stack 12
M_3 Z_115 Z_116 Z_117 Z_118 
Stack 13
J_3 Z_119 Z_120 Z_121 I_6 
Stack 14
I_2 M_2 I_0 Z_122 E_1 
Stack 15
F_2 Z_123 I_1 L_3 J_6 
Stack 16
Z_124 L_0 I_4 A_0 Z_125 
Stack 17
I_5 Z_126 B_0 Z_127 Z_128 
