Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
E_0 E_4 D_1 Z_100 E_2 
Stack 1
Z_101 J_1 I_2 B_0 F_4 
Stack 2
B_1 Z_102 C_0 G_1 F_3 
Stack 3
J_0 F_2 E_5 I_0 Z_103 
Stack 4
E_1 D_3 E_3 F_1 E_6 
Stack 5
G_2 Z_104 A_0 D_2 Z_105 
Stack 6
Z_106 H_1 Z_107 Z_108 Z_109 
Stack 7
D_0 Z_110 Z_111 C_3 H_2 
Stack 8
H_0 C_1 C_2 Z_112 J_2 
Stack 9
Z_113 F_0 I_1 Z_114 G_0 
