Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_0 B_3 A_7 E_3 Z_100 
Stack 1
A_2 C_0 Z_101 Z_102 Z_103 
Stack 2
Z_104 D_1 B_2 C_4 D_2 
Stack 3
A_6 C_8 B_4 D_0 Z_105 
Stack 4
A_0 B_0 C_3 Z_106 E_2 
Stack 5
Z_107 Z_108 E_1 C_5 E_4 
Stack 6
E_5 D_5 Z_109 Z_110 C_1 
Stack 7
A_4 Z_111 D_4 E_6 Z_112 
Stack 8
B_1 Z_113 A_3 A_1 Z_114 
Stack 9
A_5 C_6 D_6 D_3 Z_115 
Stack 10
C_7 B_5 C_2 Z_116 
