Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_3 B_4 C_8 Z_100 E_4 
Stack 1
C_1 C_0 E_3 Z_101 Z_102 
Stack 2
B_7 E_1 E_5 E_6 A_3 
Stack 3
Z_103 Z_104 B_6 A_1 A_2 
Stack 4
A_5 Z_105 Z_106 Z_107 A_0 
Stack 5
B_5 C_7 Z_108 B_3 E_0 
Stack 6
Z_109 B_0 C_6 B_1 D_5 
Stack 7
D_0 C_4 C_9 E_2 B_2 
Stack 8
D_4 Z_110 C_3 Z_111 D_2 
Stack 9
C_2 D_1 Z_112 Z_113 C_5 
Stack 10
A_4 Z_114 Z_115 Z_116 
