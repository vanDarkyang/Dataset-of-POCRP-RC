Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_7 Z_100 B_5 B_1 
Stack 1
C_8 Z_101 Z_102 C_5 
Stack 2
C_3 A_4 A_2 B_3 
Stack 3
Z_103 Z_104 A_5 A_9 
Stack 4
Z_105 B_6 A_0 C_1 
Stack 5
C_0 A_7 Z_106 C_11 
Stack 6
B_8 C_10 C_4 A_6 
Stack 7
B_2 C_2 B_7 C_9 
Stack 8
Z_107 Z_108 Z_109 B_4 
Stack 9
Z_110 Z_111 B_9 C_6 
Stack 10
Z_112 Z_113 A_8 
Stack 11
B_0 A_1 A_3 
