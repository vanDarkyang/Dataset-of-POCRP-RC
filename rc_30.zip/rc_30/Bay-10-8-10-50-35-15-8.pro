Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
A_1 F_0 G_2 Z_100 Z_101 
Stack 1
G_0 D_1 Z_102 H_2 E_1 
Stack 2
Z_103 Z_104 J_0 Z_105 B_1 
Stack 3
B_0 I_1 J_2 Z_106 C_0 
Stack 4
B_3 H_3 Z_107 C_2 I_0 
Stack 5
Z_108 H_1 F_3 D_2 A_2 
Stack 6
Z_109 Z_110 C_1 H_4 F_1 
Stack 7
E_2 E_0 F_2 G_3 Z_111 
Stack 8
Z_112 J_1 Z_113 G_4 G_1 
Stack 9
A_0 H_0 B_2 D_0 Z_114 
