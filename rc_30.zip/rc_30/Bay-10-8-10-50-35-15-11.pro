Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
D_2 I_0 Z_100 I_1 F_2 
Stack 1
G_2 Z_101 D_3 A_0 D_1 
Stack 2
E_2 F_4 J_1 C_0 G_0 
Stack 3
G_3 D_0 H_0 Z_102 F_0 
Stack 4
B_1 Z_103 C_2 J_0 F_1 
Stack 5
Z_104 D_4 C_3 H_1 Z_105 
Stack 6
J_2 C_1 H_2 E_1 E_0 
Stack 7
G_1 I_2 B_0 Z_106 Z_107 
Stack 8
Z_108 E_3 Z_109 F_3 Z_110 
Stack 9
C_4 Z_111 Z_112 Z_113 Z_114 
