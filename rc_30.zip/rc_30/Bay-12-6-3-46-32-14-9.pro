Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_1 B_12 C_6 B_7 
Stack 1
B_4 B_3 A_2 Z_100 
Stack 2
B_8 B_2 Z_101 Z_102 
Stack 3
B_13 B_1 C_7 A_3 
Stack 4
Z_103 B_6 Z_104 Z_105 
Stack 5
A_1 B_9 Z_106 C_3 
Stack 6
B_0 Z_107 A_8 A_6 
Stack 7
C_4 A_9 A_0 A_5 
Stack 8
B_10 C_0 B_11 Z_108 
Stack 9
A_7 C_5 Z_109 Z_110 
Stack 10
Z_111 Z_112 Z_113 
Stack 11
C_2 B_5 A_4 
