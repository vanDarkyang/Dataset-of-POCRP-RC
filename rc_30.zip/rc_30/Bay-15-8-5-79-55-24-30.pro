Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_2 E_3 Z_100 E_7 B_9 Z_101 
Stack 1
D_12 A_6 Z_102 C_9 B_10 D_4 
Stack 2
Z_103 Z_104 Z_105 E_6 B_6 E_10 
Stack 3
C_1 Z_106 A_5 C_3 D_8 E_8 
Stack 4
B_8 Z_107 E_4 C_6 Z_108 
Stack 5
A_1 D_9 E_1 Z_109 A_3 
Stack 6
C_8 Z_110 Z_111 D_6 C_7 
Stack 7
Z_112 Z_113 Z_114 Z_115 D_1 
Stack 8
C_2 A_0 C_0 Z_116 A_2 
Stack 9
B_7 A_9 D_11 B_3 Z_117 
Stack 10
B_5 Z_118 E_2 Z_119 A_8 
Stack 11
D_0 B_2 Z_120 Z_121 Z_122 
Stack 12
A_4 B_4 B_1 B_0 E_0 
Stack 13
C_4 A_7 D_5 E_5 D_10 
Stack 14
C_5 Z_123 D_7 E_9 D_3 
