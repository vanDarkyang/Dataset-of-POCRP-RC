Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
B_0 Z_100 F_4 F_2 C_3 
Stack 1
C_0 F_5 Z_101 Z_102 Z_103 
Stack 2
E_1 F_0 Z_104 J_0 Z_105 
Stack 3
B_2 F_1 J_2 A_0 E_0 
Stack 4
D_2 D_1 Z_106 H_0 H_2 
Stack 5
C_1 Z_107 G_3 Z_108 J_1 
Stack 6
I_1 F_3 D_4 E_3 B_1 
Stack 7
Z_109 Z_110 C_2 Z_111 Z_112 
Stack 8
Z_113 I_0 E_2 D_0 H_1 
Stack 9
G_2 D_3 G_1 Z_114 G_0 
