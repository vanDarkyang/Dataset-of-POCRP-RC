Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
K_2 H_3 J_4 M_2 
Stack 1
L_2 D_2 Z_100 Z_101 
Stack 2
N_2 H_6 J_0 H_4 
Stack 3
Z_102 K_3 Z_103 Z_104 
Stack 4
Z_105 K_1 N_3 F_3 
Stack 5
Z_106 Z_107 G_3 K_0 
Stack 6
G_4 Z_108 E_2 H_5 
Stack 7
J_2 Z_109 I_3 M_0 
Stack 8
I_5 I_7 Z_110 Z_111 
Stack 9
F_1 Z_112 L_3 L_0 
Stack 10
Z_113 F_0 E_1 C_2 
Stack 11
I_1 G_0 G_1 N_0 
Stack 12
Z_114 D_0 A_1 C_1 
Stack 13
Z_115 Z_116 Z_117 C_0 
Stack 14
F_5 Z_118 O_2 O_1 
Stack 15
K_4 A_0 Z_119 Z_120 
Stack 16
F_4 I_4 Z_121 F_2 
Stack 17
I_0 I_2 Z_122 H_1 
Stack 18
Z_123 Z_124 B_0 Z_125 
Stack 19
B_1 J_1 Z_126 Z_127 
Stack 20
M_1 J_3 H_2 O_0 
Stack 21
H_0 D_1 G_2 N_1 
Stack 22
I_6 L_1 E_0 
Stack 23
Z_128 H_7 E_3 
