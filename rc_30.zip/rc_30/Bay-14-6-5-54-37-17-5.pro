Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_0 D_1 D_5 E_1 
Stack 1
Z_100 Z_101 B_3 E_2 
Stack 2
A_3 A_6 Z_102 C_0 
Stack 3
C_3 C_4 E_5 A_1 
Stack 4
Z_103 B_1 C_1 Z_104 
Stack 5
Z_105 Z_106 D_3 D_0 
Stack 6
A_7 E_4 Z_107 B_2 
Stack 7
B_6 A_0 C_6 A_2 
Stack 8
E_3 B_0 B_5 Z_108 
Stack 9
Z_109 C_7 E_6 D_4 
Stack 10
Z_110 C_5 A_5 E_7 
Stack 11
Z_111 B_4 Z_112 Z_113 
Stack 12
A_4 Z_114 D_2 
Stack 13
Z_115 Z_116 C_2 
