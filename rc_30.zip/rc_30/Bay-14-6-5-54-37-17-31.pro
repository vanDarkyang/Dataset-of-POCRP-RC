Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
A_1 E_0 E_4 C_6 
Stack 1
Z_100 A_4 D_2 D_0 
Stack 2
Z_101 C_5 C_7 D_7 
Stack 3
Z_102 A_6 B_2 Z_103 
Stack 4
Z_104 E_1 Z_105 Z_106 
Stack 5
Z_107 Z_108 B_5 A_3 
Stack 6
B_0 Z_109 D_1 D_6 
Stack 7
Z_110 D_5 A_2 A_0 
Stack 8
C_8 D_3 Z_111 B_1 
Stack 9
Z_112 D_4 Z_113 E_3 
Stack 10
E_5 C_2 E_2 C_3 
Stack 11
C_1 B_3 C_0 Z_114 
Stack 12
A_5 B_6 Z_115 
Stack 13
C_4 Z_116 B_4 
