Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
G_1 B_2 F_1 D_3 
Stack 1
Z_100 C_3 Z_101 C_0 
Stack 2
Z_102 J_0 C_2 E_1 
Stack 3
Z_103 H_1 Z_104 Z_105 
Stack 4
B_0 G_3 J_1 A_0 
Stack 5
A_1 E_0 E_2 H_0 
Stack 6
D_1 D_0 Z_106 D_2 
Stack 7
I_0 G_2 Z_107 F_0 
Stack 8
Z_108 Z_109 E_5 C_1 
Stack 9
G_4 E_3 Z_110 Z_111 
Stack 10
B_1 F_5 G_0 F_4 
Stack 11
E_4 Z_112 Z_113 
Stack 12
Z_114 F_2 F_3 
