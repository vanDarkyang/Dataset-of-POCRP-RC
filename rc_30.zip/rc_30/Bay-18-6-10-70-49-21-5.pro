Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 Z_101 B_4 I_2 
Stack 1
C_2 B_0 E_5 H_2 
Stack 2
Z_102 Z_103 Z_104 H_3 
Stack 3
G_6 G_1 I_0 Z_105 
Stack 4
C_3 F_1 A_3 G_5 
Stack 5
E_4 Z_106 Z_107 B_1 
Stack 6
A_2 Z_108 A_1 E_3 
Stack 7
E_6 G_0 D_3 F_2 
Stack 8
Z_109 B_2 E_2 E_1 
Stack 9
I_3 I_1 C_1 D_1 
Stack 10
C_4 Z_110 H_1 J_2 
Stack 11
Z_111 G_4 G_2 F_3 
Stack 12
J_0 D_0 Z_112 Z_113 
Stack 13
Z_114 C_0 Z_115 B_3 
Stack 14
Z_116 G_3 Z_117 Z_118 
Stack 15
F_0 Z_119 J_1 D_2 
Stack 16
A_0 E_0 D_4 
Stack 17
H_0 Z_120 F_4 
