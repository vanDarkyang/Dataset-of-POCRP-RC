Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_7 C_5 Z_100 C_4 
Stack 1
B_1 C_1 Z_101 E_1 
Stack 2
D_6 D_4 D_10 E_5 
Stack 3
B_9 A_9 Z_102 D_9 
Stack 4
Z_103 Z_104 D_2 Z_105 
Stack 5
A_1 B_5 Z_106 Z_107 
Stack 6
Z_108 Z_109 B_0 D_1 
Stack 7
A_4 Z_110 Z_111 Z_112 
Stack 8
Z_113 D_7 A_10 Z_114 
Stack 9
Z_115 C_9 Z_116 B_3 
Stack 10
C_3 Z_117 D_3 D_0 
Stack 11
E_7 E_9 E_0 E_3 
Stack 12
A_0 Z_118 E_6 E_4 
Stack 13
B_7 C_10 D_8 B_6 
Stack 14
D_5 B_2 A_3 C_7 
Stack 15
C_6 A_8 C_8 B_8 
Stack 16
Z_119 C_11 E_8 E_10 
Stack 17
E_2 Z_120 Z_121 Z_122 
Stack 18
C_2 A_2 B_4 Z_123 
Stack 19
C_0 A_6 A_5 
