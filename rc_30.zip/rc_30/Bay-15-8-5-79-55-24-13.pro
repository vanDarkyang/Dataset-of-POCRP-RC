Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_5 Z_100 A_6 C_1 C_9 Z_101 
Stack 1
Z_102 E_4 A_2 D_11 Z_103 E_6 
Stack 2
Z_104 A_1 E_10 D_3 Z_105 A_4 
Stack 3
D_2 B_9 Z_106 E_8 E_9 D_5 
Stack 4
Z_107 C_6 E_1 B_6 C_2 
Stack 5
A_0 B_8 B_1 A_3 A_8 
Stack 6
Z_108 E_5 Z_109 C_3 D_1 
Stack 7
Z_110 Z_111 D_7 B_4 E_7 
Stack 8
D_9 A_5 Z_112 B_0 Z_113 
Stack 9
Z_114 Z_115 Z_116 B_3 C_8 
Stack 10
Z_117 D_8 C_10 Z_118 Z_119 
Stack 11
Z_120 Z_121 B_7 B_5 E_0 
Stack 12
A_7 D_10 C_7 C_0 Z_122 
Stack 13
Z_123 B_10 C_4 D_4 B_2 
Stack 14
D_6 E_11 E_2 E_3 D_0 
