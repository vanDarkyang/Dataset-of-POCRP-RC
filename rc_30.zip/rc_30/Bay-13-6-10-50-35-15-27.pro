Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
D_0 Z_100 A_0 A_2 
Stack 1
Z_101 A_1 G_1 H_2 
Stack 2
Z_102 E_0 F_2 E_3 
Stack 3
Z_103 Z_104 J_0 D_3 
Stack 4
C_0 Z_105 C_3 I_2 
Stack 5
C_4 C_2 G_2 Z_106 
Stack 6
D_2 Z_107 Z_108 Z_109 
Stack 7
E_4 E_1 I_0 C_1 
Stack 8
Z_110 Z_111 Z_112 I_1 
Stack 9
B_0 B_2 B_3 G_0 
Stack 10
F_0 D_1 B_1 F_3 
Stack 11
E_2 F_1 H_0 
Stack 12
Z_113 H_1 Z_114 
