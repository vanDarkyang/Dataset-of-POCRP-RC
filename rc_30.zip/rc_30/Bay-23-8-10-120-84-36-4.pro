Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
D_1 Z_100 I_7 D_5 J_1 E_4 
Stack 1
E_2 Z_101 E_1 F_7 Z_102 Z_103 
Stack 2
J_2 G_3 Z_104 Z_105 F_0 I_3 
Stack 3
D_2 G_7 Z_106 C_3 Z_107 G_11 
Stack 4
Z_108 E_8 G_4 H_9 Z_109 D_11 
Stack 5
Z_110 G_10 Z_111 Z_112 C_5 
Stack 6
H_4 J_0 C_0 Z_113 H_3 
Stack 7
D_7 A_3 H_5 D_10 Z_114 
Stack 8
I_4 G_8 J_4 E_7 J_5 
Stack 9
B_2 D_9 A_2 Z_115 Z_116 
Stack 10
Z_117 A_0 H_6 Z_118 A_1 
Stack 11
B_3 G_1 H_7 E_5 I_6 
Stack 12
I_5 D_3 C_6 G_6 Z_119 
Stack 13
E_0 Z_120 Z_121 F_3 G_0 
Stack 14
Z_122 D_6 H_1 J_3 B_1 
Stack 15
G_9 Z_123 G_2 I_0 D_0 
Stack 16
Z_124 D_4 Z_125 F_1 H_2 
Stack 17
C_1 D_8 Z_126 Z_127 Z_128 
Stack 18
E_6 F_2 B_4 C_4 B_0 
Stack 19
E_9 E_10 I_2 H_8 Z_129 
Stack 20
Z_130 Z_131 E_3 Z_132 F_4 
Stack 21
F_8 F_5 I_1 Z_133 Z_134 
Stack 22
G_5 C_2 F_6 Z_135 H_0 
