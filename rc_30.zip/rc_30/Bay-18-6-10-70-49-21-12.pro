Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 D_6 Z_101 H_1 
Stack 1
D_3 D_1 C_1 G_4 
Stack 2
F_4 D_0 Z_102 B_2 
Stack 3
B_1 Z_103 J_3 H_0 
Stack 4
B_4 I_0 E_0 Z_104 
Stack 5
G_0 E_2 Z_105 C_2 
Stack 6
C_4 Z_106 I_1 Z_107 
Stack 7
D_4 G_5 J_0 F_1 
Stack 8
A_2 E_1 Z_108 Z_109 
Stack 9
E_4 Z_110 Z_111 C_3 
Stack 10
J_2 J_4 B_3 Z_112 
Stack 11
Z_113 Z_114 C_0 J_1 
Stack 12
F_5 B_0 D_5 E_3 
Stack 13
E_5 Z_115 G_1 Z_116 
Stack 14
F_2 H_3 H_2 A_1 
Stack 15
Z_117 Z_118 G_3 F_0 
Stack 16
F_3 Z_119 A_0 
Stack 17
D_2 G_2 Z_120 
