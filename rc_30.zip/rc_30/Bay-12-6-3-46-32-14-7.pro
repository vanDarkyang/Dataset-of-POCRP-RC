Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_5 Z_100 B_7 A_0 
Stack 1
B_3 Z_101 B_1 C_0 
Stack 2
C_8 B_4 Z_102 Z_103 
Stack 3
A_1 Z_104 B_9 C_6 
Stack 4
Z_105 B_2 Z_106 C_2 
Stack 5
A_2 B_5 A_7 B_8 
Stack 6
C_3 A_9 B_0 C_7 
Stack 7
C_5 B_10 Z_107 Z_108 
Stack 8
C_1 Z_109 C_9 Z_110 
Stack 9
B_6 B_11 Z_111 C_4 
Stack 10
Z_112 A_4 A_8 
Stack 11
A_6 Z_113 A_3 
