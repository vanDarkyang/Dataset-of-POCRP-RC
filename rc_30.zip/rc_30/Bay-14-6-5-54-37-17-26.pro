Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_6 E_0 Z_100 Z_101 
Stack 1
A_0 B_8 E_4 D_3 
Stack 2
C_8 Z_102 C_2 A_3 
Stack 3
Z_103 D_5 Z_104 C_3 
Stack 4
B_4 Z_105 Z_106 B_7 
Stack 5
A_5 B_1 A_4 B_0 
Stack 6
B_3 A_2 B_5 Z_107 
Stack 7
Z_108 Z_109 C_5 Z_110 
Stack 8
D_4 C_6 Z_111 Z_112 
Stack 9
C_7 E_5 E_3 D_1 
Stack 10
A_1 E_1 C_9 C_4 
Stack 11
Z_113 Z_114 Z_115 D_2 
Stack 12
Z_116 D_0 C_1 
Stack 13
C_0 E_2 B_2 
