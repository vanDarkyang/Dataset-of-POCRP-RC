Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_8 B_10 A_6 D_3 
Stack 1
A_7 Z_100 B_0 Z_101 
Stack 2
D_9 A_5 Z_102 B_6 
Stack 3
C_11 B_2 Z_103 D_5 
Stack 4
Z_104 D_0 B_8 C_6 
Stack 5
Z_105 Z_106 C_9 C_10 
Stack 6
Z_107 D_6 Z_108 C_2 
Stack 7
E_1 Z_109 A_3 Z_110 
Stack 8
Z_111 C_3 E_5 Z_112 
Stack 9
B_11 E_8 Z_113 Z_114 
Stack 10
C_12 B_7 B_9 C_4 
Stack 11
B_3 D_2 Z_115 A_0 
Stack 12
D_1 Z_116 Z_117 E_11 
Stack 13
A_4 D_4 B_1 A_2 
Stack 14
D_7 E_3 C_0 E_6 
Stack 15
E_10 Z_118 Z_119 C_7 
Stack 16
E_9 Z_120 E_2 Z_121 
Stack 17
Z_122 C_5 B_4 B_5 
Stack 18
Z_123 C_8 E_0 E_7 
Stack 19
E_4 A_1 C_1 
