Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_3 E_8 Z_100 A_0 E_6 Z_101 
Stack 1
B_3 A_7 Z_102 B_4 C_2 Z_103 
Stack 2
Z_104 C_1 C_6 D_6 C_7 A_8 
Stack 3
Z_105 C_13 D_4 A_4 B_0 Z_106 
Stack 4
B_1 Z_107 A_3 Z_108 C_9 
Stack 5
A_6 E_0 C_10 Z_109 Z_110 
Stack 6
D_8 Z_111 C_12 D_3 A_9 
Stack 7
E_3 B_7 D_2 D_7 Z_112 
Stack 8
Z_113 C_0 B_6 Z_114 B_5 
Stack 9
Z_115 A_10 D_9 Z_116 Z_117 
Stack 10
A_2 D_5 C_14 A_5 E_4 
Stack 11
E_5 C_8 Z_118 D_0 C_11 
Stack 12
Z_119 D_1 A_1 E_1 Z_120 
Stack 13
E_2 Z_121 C_4 B_8 Z_122 
Stack 14
Z_123 C_5 B_9 E_7 B_2 
