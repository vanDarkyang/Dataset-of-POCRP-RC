Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
M_0 I_2 J_0 O_2 L_2 Z_100 
Stack 1
C_1 H_5 G_4 Z_101 K_4 Z_102 
Stack 2
H_3 Z_103 L_3 Z_104 J_3 Z_105 
Stack 3
C_0 N_0 K_0 G_0 Z_106 E_1 
Stack 4
Z_107 C_2 D_0 B_0 M_2 
Stack 5
Z_108 H_4 J_2 A_1 Z_109 
Stack 6
Z_110 Z_111 I_3 B_1 Z_112 
Stack 7
F_5 D_1 Z_113 N_1 L_0 
Stack 8
I_5 Z_114 Z_115 F_4 E_0 
Stack 9
C_4 I_6 Z_116 E_4 G_3 
Stack 10
C_3 J_1 Z_117 K_3 I_7 
Stack 11
E_3 Z_118 I_0 G_1 F_0 
Stack 12
F_2 I_4 F_1 L_1 H_0 
Stack 13
I_1 O_1 Z_119 Z_120 F_3 
Stack 14
Z_121 H_1 H_7 Z_122 A_0 
Stack 15
K_1 E_2 G_2 Z_123 H_6 
Stack 16
Z_124 Z_125 H_2 K_2 O_0 
Stack 17
Z_126 M_3 Z_127 Z_128 M_1 
