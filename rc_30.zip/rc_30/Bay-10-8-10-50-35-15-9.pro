Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
A_1 E_3 B_0 F_0 Z_100 
Stack 1
C_2 Z_101 E_6 A_0 Z_102 
Stack 2
Z_103 Z_104 H_3 I_1 I_0 
Stack 3
D_4 Z_105 D_2 Z_106 Z_107 
Stack 4
Z_108 E_0 G_2 D_0 H_0 
Stack 5
Z_109 G_1 J_0 F_3 C_1 
Stack 6
J_1 Z_110 E_5 E_2 Z_111 
Stack 7
A_2 J_2 H_2 H_1 F_2 
Stack 8
D_3 D_1 G_0 C_0 Z_112 
Stack 9
Z_113 E_1 F_1 Z_114 E_4 
