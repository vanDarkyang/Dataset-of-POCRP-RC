Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
E_5 Z_100 C_2 Z_101 
Stack 1
B_2 D_3 Z_102 C_1 
Stack 2
Z_103 C_3 Z_104 I_0 
Stack 3
F_2 Z_105 D_4 D_2 
Stack 4
D_0 E_1 J_2 G_3 
Stack 5
F_0 Z_106 F_3 H_1 
Stack 6
I_1 Z_107 D_7 Z_108 
Stack 7
G_2 A_0 Z_109 D_1 
Stack 8
Z_110 E_4 G_0 G_1 
Stack 9
Z_111 Z_112 E_2 Z_113 
Stack 10
F_4 D_5 B_3 I_4 
Stack 11
C_4 E_3 J_1 F_1 
Stack 12
H_0 Z_114 A_1 G_4 
Stack 13
Z_115 Z_116 Z_117 G_5 
Stack 14
J_0 I_2 B_4 Z_118 
Stack 15
Z_119 C_0 D_6 I_3 
Stack 16
B_0 Z_120 H_2 
Stack 17
E_0 A_2 B_1 
