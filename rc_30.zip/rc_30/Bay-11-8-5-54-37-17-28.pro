Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_9 B_2 Z_100 E_2 Z_101 
Stack 1
Z_102 A_1 E_8 D_4 C_2 
Stack 2
B_3 D_1 B_5 C_4 E_7 
Stack 3
C_3 A_0 D_0 B_1 Z_103 
Stack 4
Z_104 B_4 D_8 C_0 A_6 
Stack 5
Z_105 Z_106 A_3 Z_107 D_3 
Stack 6
A_4 D_5 D_2 E_0 A_5 
Stack 7
Z_108 Z_109 Z_110 Z_111 B_0 
Stack 8
Z_112 E_1 Z_113 D_7 E_4 
Stack 9
Z_114 Z_115 D_6 E_3 A_2 
Stack 10
C_1 Z_116 E_6 E_5 
