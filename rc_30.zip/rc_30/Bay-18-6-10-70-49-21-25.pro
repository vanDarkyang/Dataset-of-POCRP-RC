Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
A_2 Z_100 H_0 Z_101 
Stack 1
C_0 J_3 Z_102 B_1 
Stack 2
Z_103 B_0 J_0 I_4 
Stack 3
Z_104 G_5 I_2 F_3 
Stack 4
D_2 Z_105 A_1 I_0 
Stack 5
Z_106 D_5 C_2 G_4 
Stack 6
G_0 D_1 F_2 Z_107 
Stack 7
H_2 Z_108 D_3 F_8 
Stack 8
F_4 Z_109 E_3 Z_110 
Stack 9
B_2 F_5 E_1 F_0 
Stack 10
F_1 Z_111 F_7 E_4 
Stack 11
F_6 B_3 I_3 Z_112 
Stack 12
D_0 D_4 G_1 Z_113 
Stack 13
H_3 Z_114 I_1 H_1 
Stack 14
G_2 Z_115 E_0 J_2 
Stack 15
Z_116 G_3 E_2 Z_117 
Stack 16
Z_118 Z_119 A_0 
Stack 17
J_1 Z_120 C_1 
