Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
H_2 Z_100 A_2 Z_101 D_1 
Stack 1
F_4 E_0 Z_102 G_0 Z_103 
Stack 2
G_1 H_1 F_2 B_2 I_0 
Stack 3
C_0 E_3 Z_104 Z_105 Z_106 
Stack 4
A_0 F_0 J_1 F_3 G_2 
Stack 5
B_0 D_2 Z_107 I_3 Z_108 
Stack 6
I_1 J_0 E_2 Z_109 D_0 
Stack 7
C_1 B_1 H_0 Z_110 F_1 
Stack 8
Z_111 I_2 Z_112 C_2 A_1 
Stack 9
D_3 E_1 H_3 Z_113 Z_114 
