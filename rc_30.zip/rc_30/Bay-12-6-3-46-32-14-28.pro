Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_2 A_0 Z_100 Z_101 
Stack 1
B_10 A_3 B_8 B_0 
Stack 2
A_8 B_6 B_4 Z_102 
Stack 3
B_5 C_8 Z_103 A_1 
Stack 4
Z_104 A_9 A_5 Z_105 
Stack 5
Z_106 A_7 B_9 C_1 
Stack 6
C_2 C_6 B_11 C_9 
Stack 7
A_6 A_4 Z_107 Z_108 
Stack 8
C_5 Z_109 Z_110 C_4 
Stack 9
C_3 C_0 A_2 B_3 
Stack 10
B_1 Z_111 C_7 
Stack 11
Z_112 B_7 Z_113 
