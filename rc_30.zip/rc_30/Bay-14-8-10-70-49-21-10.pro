Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
A_3 B_2 A_2 Z_100 B_0 
Stack 1
H_0 B_3 E_4 E_3 C_2 
Stack 2
Z_101 E_0 D_1 I_3 G_3 
Stack 3
C_5 D_3 B_1 E_1 Z_102 
Stack 4
Z_103 Z_104 Z_105 Z_106 Z_107 
Stack 5
E_5 I_2 A_0 Z_108 A_1 
Stack 6
F_3 G_5 Z_109 I_1 Z_110 
Stack 7
J_1 Z_111 H_3 D_5 C_4 
Stack 8
C_3 Z_112 D_6 Z_113 Z_114 
Stack 9
H_2 F_2 I_0 Z_115 G_0 
Stack 10
D_0 G_2 Z_116 Z_117 G_1 
Stack 11
F_1 D_2 G_4 H_1 C_1 
Stack 12
D_4 E_2 Z_118 J_2 F_0 
Stack 13
J_0 Z_119 C_0 Z_120 B_4 
