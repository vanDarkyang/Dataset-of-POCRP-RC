Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_3 Z_100 D_0 C_2 E_3 
Stack 1
E_7 A_3 D_4 B_5 Z_101 
Stack 2
A_5 E_6 C_1 B_1 Z_102 
Stack 3
Z_103 C_4 B_0 E_2 D_5 
Stack 4
A_4 C_3 E_4 Z_104 Z_105 
Stack 5
Z_106 D_6 A_0 C_6 B_4 
Stack 6
D_7 Z_107 C_5 E_0 Z_108 
Stack 7
Z_109 A_1 E_1 B_6 Z_110 
Stack 8
D_1 D_3 Z_111 A_6 Z_112 
Stack 9
D_2 Z_113 B_2 Z_114 Z_115 
Stack 10
Z_116 C_0 E_5 A_2 
