Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
A_1 F_3 Z_100 E_5 
Stack 1
B_2 Z_101 F_0 I_3 
Stack 2
C_4 J_2 Z_102 A_2 
Stack 3
C_6 A_0 C_2 F_1 
Stack 4
Z_103 Z_104 G_1 C_5 
Stack 5
H_2 Z_105 F_2 H_1 
Stack 6
Z_106 I_0 I_1 Z_107 
Stack 7
E_1 B_0 H_3 G_0 
Stack 8
C_1 Z_108 E_0 D_1 
Stack 9
E_3 Z_109 E_4 D_3 
Stack 10
D_2 G_5 C_0 J_0 
Stack 11
Z_110 G_2 Z_111 Z_112 
Stack 12
Z_113 A_3 Z_114 J_1 
Stack 13
G_3 Z_115 C_3 G_4 
Stack 14
G_6 Z_116 F_4 Z_117 
Stack 15
D_0 D_4 H_0 E_2 
Stack 16
J_3 Z_118 Z_119 
Stack 17
I_2 Z_120 B_1 
