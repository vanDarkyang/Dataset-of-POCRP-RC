Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
C_2 E_2 B_0 Z_100 
Stack 1
Z_101 F_4 C_0 J_2 
Stack 2
A_1 F_1 D_1 F_0 
Stack 3
D_4 G_0 I_0 Z_102 
Stack 4
Z_103 Z_104 E_0 Z_105 
Stack 5
F_5 B_3 C_3 I_3 
Stack 6
G_2 Z_106 J_1 H_1 
Stack 7
Z_107 D_3 Z_108 B_1 
Stack 8
Z_109 G_3 E_5 A_4 
Stack 9
F_3 Z_110 Z_111 I_1 
Stack 10
Z_112 H_0 E_4 F_2 
Stack 11
G_4 Z_113 Z_114 Z_115 
Stack 12
C_1 G_1 E_1 Z_116 
Stack 13
H_2 G_5 D_2 H_4 
Stack 14
Z_117 A_2 E_3 A_0 
Stack 15
D_0 A_3 E_6 Z_118 
Stack 16
B_2 J_0 Z_119 
Stack 17
Z_120 I_2 H_3 
