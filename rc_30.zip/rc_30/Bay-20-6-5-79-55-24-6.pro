Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_3 C_4 Z_100 E_6 
Stack 1
B_11 D_0 Z_101 E_0 
Stack 2
Z_102 E_3 A_6 C_2 
Stack 3
D_5 C_0 D_8 D_12 
Stack 4
C_6 D_3 B_10 B_12 
Stack 5
Z_103 A_4 E_8 E_5 
Stack 6
C_5 A_1 Z_104 Z_105 
Stack 7
C_1 Z_106 A_9 Z_107 
Stack 8
Z_108 Z_109 Z_110 D_6 
Stack 9
A_5 C_9 D_2 B_8 
Stack 10
C_8 B_5 A_2 B_0 
Stack 11
Z_111 B_2 D_7 B_9 
Stack 12
Z_112 D_11 Z_113 E_4 
Stack 13
D_4 E_7 Z_114 Z_115 
Stack 14
Z_116 Z_117 A_7 E_2 
Stack 15
Z_118 B_3 D_10 E_1 
Stack 16
Z_119 A_0 Z_120 D_9 
Stack 17
B_4 Z_121 A_8 B_7 
Stack 18
C_7 D_1 B_1 Z_122 
Stack 19
B_6 Z_123 C_3 
