Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_4 F_5 D_0 Z_100 
Stack 1
E_2 C_4 E_1 D_3 
Stack 2
J_1 Z_101 Z_102 Z_103 
Stack 3
J_0 Z_104 D_1 J_3 
Stack 4
D_2 C_3 Z_105 E_4 
Stack 5
E_3 H_3 H_0 I_3 
Stack 6
Z_106 Z_107 H_2 B_1 
Stack 7
Z_108 J_2 B_2 G_3 
Stack 8
Z_109 F_0 B_0 C_2 
Stack 9
G_5 A_2 C_1 Z_110 
Stack 10
Z_111 A_0 F_1 H_1 
Stack 11
Z_112 A_1 G_1 Z_113 
Stack 12
Z_114 A_3 G_4 Z_115 
Stack 13
I_4 F_3 I_2 Z_116 
Stack 14
E_0 C_5 Z_117 F_4 
Stack 15
F_2 B_3 Z_118 I_1 
Stack 16
G_2 G_0 C_0 
Stack 17
Z_119 Z_120 I_0 
