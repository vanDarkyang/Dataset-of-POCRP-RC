Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_0 A_5 C_4 B_4 
Stack 1
A_9 Z_100 A_4 Z_101 
Stack 2
B_0 B_8 Z_102 Z_103 
Stack 3
C_5 C_3 A_11 Z_104 
Stack 4
A_2 Z_105 B_6 Z_106 
Stack 5
B_9 A_8 C_1 C_7 
Stack 6
B_10 C_6 Z_107 B_1 
Stack 7
Z_108 C_8 C_2 Z_109 
Stack 8
B_2 Z_110 A_6 Z_111 
Stack 9
B_5 Z_112 Z_113 A_7 
Stack 10
A_3 B_7 B_3 
Stack 11
A_0 A_10 A_1 
