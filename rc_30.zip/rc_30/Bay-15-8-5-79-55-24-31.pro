Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_0 Z_100 Z_101 Z_102 Z_103 D_6 
Stack 1
E_4 Z_104 A_7 A_6 Z_105 C_10 
Stack 2
B_8 C_12 Z_106 D_9 C_9 E_5 
Stack 3
B_6 Z_107 Z_108 A_9 C_6 D_10 
Stack 4
C_11 Z_109 C_8 D_0 C_1 
Stack 5
E_8 B_7 Z_110 E_2 A_3 
Stack 6
D_4 Z_111 Z_112 E_3 E_6 
Stack 7
D_11 Z_113 Z_114 B_4 B_1 
Stack 8
Z_115 E_0 Z_116 D_5 E_9 
Stack 9
C_13 C_7 Z_117 A_5 Z_118 
Stack 10
D_7 D_2 C_2 B_0 A_8 
Stack 11
A_2 E_7 Z_119 Z_120 A_1 
Stack 12
A_0 B_5 D_8 D_1 Z_121 
Stack 13
C_4 B_3 Z_122 C_5 E_1 
Stack 14
A_4 Z_123 C_3 B_2 D_3 
