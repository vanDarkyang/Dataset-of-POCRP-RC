Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
H_2 Z_100 J_3 I_1 Z_101 
Stack 1
D_3 E_4 Z_102 J_0 Z_103 
Stack 2
F_5 F_4 Z_104 H_1 C_0 
Stack 3
Z_105 D_2 A_3 Z_106 C_3 
Stack 4
B_1 D_6 H_3 Z_107 F_0 
Stack 5
G_0 D_1 Z_108 C_1 F_2 
Stack 6
C_5 D_0 F_7 D_5 Z_109 
Stack 7
D_4 Z_110 Z_111 Z_112 C_4 
Stack 8
A_2 I_0 B_0 Z_113 Z_114 
Stack 9
E_5 E_2 C_2 Z_115 Z_116 
Stack 10
J_1 G_2 F_3 A_0 E_3 
Stack 11
G_1 G_4 J_2 Z_117 Z_118 
Stack 12
F_6 E_1 E_0 H_0 A_1 
Stack 13
E_6 Z_119 Z_120 G_3 F_1 
