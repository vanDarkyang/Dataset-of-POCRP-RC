Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 H_1 H_6 I_7 D_5 H_5 
Stack 1
D_7 A_0 G_1 Z_101 C_0 F_6 
Stack 2
B_0 Z_102 E_5 J_3 E_6 A_4 
Stack 3
Z_103 D_2 I_3 Z_104 I_0 Z_105 
Stack 4
Z_106 I_9 H_8 Z_107 Z_108 D_4 
Stack 5
C_6 Z_109 C_3 Z_110 C_7 
Stack 6
Z_111 Z_112 E_8 B_3 Z_113 
Stack 7
Z_114 B_6 F_2 Z_115 J_6 
Stack 8
C_5 D_0 G_5 I_4 D_1 
Stack 9
J_5 F_3 I_6 E_7 C_4 
Stack 10
F_4 E_1 I_1 E_0 Z_116 
Stack 11
C_1 E_4 Z_117 F_0 F_7 
Stack 12
Z_118 A_3 G_3 Z_119 I_8 
Stack 13
Z_120 E_3 B_5 A_2 J_2 
Stack 14
H_7 Z_121 Z_122 C_8 Z_123 
Stack 15
H_0 A_1 Z_124 B_4 B_7 
Stack 16
G_2 Z_125 Z_126 J_0 C_2 
Stack 17
I_5 H_2 G_0 Z_127 Z_128 
Stack 18
I_2 H_3 Z_129 G_4 E_2 
Stack 19
E_9 Z_130 D_6 F_5 G_6 
Stack 20
Z_131 J_1 B_1 I_10 H_4 
Stack 21
A_5 G_7 B_2 F_1 Z_132 
Stack 22
Z_133 Z_134 D_3 Z_135 J_4 
