Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
F_2 L_0 K_3 K_2 
Stack 1
Z_100 H_1 I_5 L_1 
Stack 2
E_0 J_4 H_4 G_1 
Stack 3
I_6 Z_101 I_1 Z_102 
Stack 4
N_0 L_3 Z_103 Z_104 
Stack 5
Z_105 Z_106 G_4 H_0 
Stack 6
C_0 Z_107 F_3 J_0 
Stack 7
D_3 Z_108 Z_109 F_5 
Stack 8
Z_110 D_2 Z_111 F_4 
Stack 9
H_3 O_1 Z_112 D_1 
Stack 10
J_5 O_0 E_2 F_1 
Stack 11
H_2 G_0 H_5 A_0 
Stack 12
Z_113 Z_114 B_2 I_0 
Stack 13
Z_115 F_0 B_1 K_0 
Stack 14
M_0 I_4 J_2 M_1 
Stack 15
Z_116 Z_117 A_1 K_1 
Stack 16
Z_118 Z_119 B_0 M_4 
Stack 17
I_3 I_2 G_3 N_1 
Stack 18
Z_120 E_3 C_2 Z_121 
Stack 19
L_2 J_3 D_4 Z_122 
Stack 20
Z_123 E_1 M_2 Z_124 
Stack 21
K_4 D_0 J_1 Z_125 
Stack 22
G_2 Z_126 Z_127 
Stack 23
C_1 Z_128 M_3 
