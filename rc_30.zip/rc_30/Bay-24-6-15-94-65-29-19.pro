Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 F_3 Z_101 B_1 
Stack 1
I_0 H_5 Z_102 G_4 
Stack 2
F_0 O_1 G_1 H_1 
Stack 3
F_2 I_1 A_1 L_2 
Stack 4
H_0 G_0 G_3 N_0 
Stack 5
E_1 Z_103 Z_104 G_2 
Stack 6
Z_105 F_4 E_0 A_0 
Stack 7
E_3 C_0 Z_106 J_0 
Stack 8
C_2 Z_107 Z_108 Z_109 
Stack 9
L_1 H_7 Z_110 M_0 
Stack 10
C_1 I_2 B_3 O_2 
Stack 11
H_4 O_0 Z_111 D_0 
Stack 12
D_1 K_2 J_4 H_6 
Stack 13
Z_112 Z_113 Z_114 Z_115 
Stack 14
B_0 Z_116 Z_117 Z_118 
Stack 15
N_1 K_4 E_2 L_0 
Stack 16
B_2 Z_119 Z_120 Z_121 
Stack 17
F_5 Z_122 Z_123 C_3 
Stack 18
I_4 H_3 K_0 Z_124 
Stack 19
Z_125 D_3 J_1 Z_126 
Stack 20
K_3 H_2 K_1 C_4 
Stack 21
M_1 J_2 Z_127 Z_128 
Stack 22
J_3 I_3 E_4 
Stack 23
D_2 D_4 F_1 
