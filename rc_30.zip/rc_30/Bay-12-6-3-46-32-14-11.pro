Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_5 A_4 A_10 Z_100 
Stack 1
B_0 Z_101 C_1 Z_102 
Stack 2
A_6 C_0 C_6 A_5 
Stack 3
Z_103 A_8 Z_104 C_8 
Stack 4
A_9 B_2 C_2 Z_105 
Stack 5
A_0 C_3 A_3 A_7 
Stack 6
B_7 C_10 B_3 B_1 
Stack 7
Z_106 C_4 B_6 A_2 
Stack 8
Z_107 B_4 C_9 B_8 
Stack 9
Z_108 Z_109 Z_110 Z_111 
Stack 10
Z_112 Z_113 C_7 
Stack 11
A_1 C_5 B_9 
