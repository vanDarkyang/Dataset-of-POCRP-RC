Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 C_2 D_1 Z_101 
Stack 1
D_6 B_3 Z_102 E_4 
Stack 2
Z_103 Z_104 D_2 C_4 
Stack 3
A_6 C_6 A_1 Z_105 
Stack 4
C_1 A_3 E_2 D_5 
Stack 5
E_0 C_3 B_2 B_4 
Stack 6
Z_106 B_5 A_7 Z_107 
Stack 7
E_3 D_7 E_1 B_7 
Stack 8
Z_108 B_6 D_4 C_5 
Stack 9
Z_109 Z_110 C_0 Z_111 
Stack 10
A_5 A_0 D_0 D_3 
Stack 11
Z_112 Z_113 B_0 Z_114 
Stack 12
A_4 A_2 Z_115 
Stack 13
B_1 E_5 Z_116 
