Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
B_2 H_2 E_6 Z_100 B_0 
Stack 1
Z_101 D_1 I_5 I_1 I_3 
Stack 2
G_1 F_4 Z_102 D_4 Z_103 
Stack 3
F_3 Z_104 E_0 D_3 E_1 
Stack 4
F_1 Z_105 Z_106 H_0 Z_107 
Stack 5
F_0 Z_108 B_3 Z_109 J_2 
Stack 6
C_2 A_3 Z_110 C_0 E_7 
Stack 7
A_1 H_1 I_0 D_5 C_3 
Stack 8
Z_111 Z_112 H_3 Z_113 E_5 
Stack 9
G_0 G_2 J_0 Z_114 Z_115 
Stack 10
A_2 J_1 F_2 B_1 D_2 
Stack 11
D_0 E_4 G_4 C_1 Z_116 
Stack 12
G_3 Z_117 E_3 Z_118 I_2 
Stack 13
A_0 I_4 Z_119 Z_120 E_2 
