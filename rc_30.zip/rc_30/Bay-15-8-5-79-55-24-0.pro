Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_8 Z_100 C_2 Z_101 A_3 Z_102 
Stack 1
E_4 D_8 D_12 Z_103 Z_104 Z_105 
Stack 2
C_4 D_0 Z_106 Z_107 C_3 Z_108 
Stack 3
B_6 E_1 E_5 D_5 C_9 A_5 
Stack 4
Z_109 A_2 Z_110 Z_111 D_13 
Stack 5
D_6 B_7 C_10 C_1 A_1 
Stack 6
C_7 C_5 B_9 E_3 A_6 
Stack 7
B_4 D_1 E_0 D_9 B_1 
Stack 8
D_4 Z_112 Z_113 D_10 Z_114 
Stack 9
C_12 C_6 A_9 Z_115 C_11 
Stack 10
Z_116 Z_117 B_5 E_2 D_11 
Stack 11
A_4 A_7 B_2 Z_118 B_3 
Stack 12
B_0 B_8 B_10 D_7 A_10 
Stack 13
D_3 C_8 Z_119 A_0 Z_120 
Stack 14
D_2 Z_121 Z_122 Z_123 C_0 
