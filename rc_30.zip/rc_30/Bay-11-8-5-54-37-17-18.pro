Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
C_2 B_4 A_3 E_2 C_0 
Stack 1
E_7 B_2 Z_100 C_5 Z_101 
Stack 2
A_4 A_1 Z_102 Z_103 C_6 
Stack 3
E_4 Z_104 C_7 Z_105 Z_106 
Stack 4
Z_107 D_0 Z_108 B_7 E_6 
Stack 5
A_2 D_5 E_0 Z_109 E_5 
Stack 6
B_5 D_3 B_6 D_1 C_3 
Stack 7
A_5 Z_110 Z_111 E_3 E_1 
Stack 8
B_3 Z_112 C_4 B_1 Z_113 
Stack 9
Z_114 B_0 D_4 A_0 D_2 
Stack 10
C_1 C_8 Z_115 Z_116 
