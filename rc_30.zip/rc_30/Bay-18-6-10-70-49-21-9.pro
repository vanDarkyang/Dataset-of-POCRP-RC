Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
H_0 C_3 H_4 F_1 
Stack 1
D_2 D_3 Z_100 F_0 
Stack 2
B_3 Z_101 I_0 Z_102 
Stack 3
Z_103 E_1 B_5 Z_104 
Stack 4
D_0 Z_105 A_0 Z_106 
Stack 5
C_1 H_3 F_2 E_0 
Stack 6
Z_107 E_4 C_5 B_2 
Stack 7
C_2 C_0 Z_108 J_1 
Stack 8
E_5 E_2 H_2 A_1 
Stack 9
F_5 H_1 Z_109 D_4 
Stack 10
B_0 F_3 G_0 I_1 
Stack 11
Z_110 Z_111 Z_112 G_3 
Stack 12
Z_113 B_1 I_2 F_4 
Stack 13
I_3 Z_114 B_4 Z_115 
Stack 14
E_3 D_1 J_0 Z_116 
Stack 15
Z_117 Z_118 C_4 H_5 
Stack 16
G_1 G_2 Z_119 
Stack 17
Z_120 J_2 G_4 
