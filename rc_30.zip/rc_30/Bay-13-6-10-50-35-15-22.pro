Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
D_2 Z_100 Z_101 Z_102 
Stack 1
H_1 J_0 C_1 E_1 
Stack 2
F_4 G_0 Z_103 F_2 
Stack 3
E_0 F_0 E_2 Z_104 
Stack 4
Z_105 Z_106 G_3 E_4 
Stack 5
Z_107 B_1 D_1 Z_108 
Stack 6
Z_109 B_0 G_1 I_0 
Stack 7
A_0 C_0 I_1 F_3 
Stack 8
C_3 D_0 H_4 H_0 
Stack 9
D_3 Z_110 Z_111 G_2 
Stack 10
F_1 Z_112 E_5 C_2 
Stack 11
A_1 Z_113 H_3 
Stack 12
E_3 H_2 Z_114 
