Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 L_1 E_0 K_1 
Stack 1
E_1 D_0 N_0 N_1 
Stack 2
J_2 I_2 Z_101 I_0 
Stack 3
E_5 I_4 Z_102 Z_103 
Stack 4
G_2 E_3 Z_104 G_1 
Stack 5
Z_105 H_4 F_4 D_1 
Stack 6
Z_106 Z_107 C_1 H_0 
Stack 7
I_3 Z_108 Z_109 Z_110 
Stack 8
H_3 G_0 F_1 Z_111 
Stack 9
F_0 B_0 M_2 Z_112 
Stack 10
Z_113 Z_114 E_4 L_2 
Stack 11
L_3 J_4 C_3 J_1 
Stack 12
N_2 E_2 D_2 H_1 
Stack 13
J_0 M_3 Z_115 Z_116 
Stack 14
K_2 J_3 C_2 M_0 
Stack 15
I_1 K_0 C_0 Z_117 
Stack 16
J_5 Z_118 O_0 M_1 
Stack 17
Z_119 O_1 L_0 F_3 
Stack 18
D_3 Z_120 N_3 A_0 
Stack 19
F_2 Z_121 B_2 A_1 
Stack 20
Z_122 Z_123 Z_124 H_2 
Stack 21
H_6 H_5 K_3 G_3 
Stack 22
Z_125 B_3 Z_126 
Stack 23
Z_127 Z_128 B_1 
