Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_1 C_2 C_6 A_0 
Stack 1
B_4 Z_100 A_4 C_3 
Stack 2
C_0 B_3 B_1 A_9 
Stack 3
B_10 B_0 B_11 A_3 
Stack 4
A_7 C_1 C_4 A_8 
Stack 5
Z_101 A_11 B_2 Z_102 
Stack 6
Z_103 C_7 Z_104 B_8 
Stack 7
B_6 Z_105 B_5 B_7 
Stack 8
Z_106 B_9 A_2 Z_107 
Stack 9
Z_108 Z_109 A_10 C_5 
Stack 10
Z_110 Z_111 A_5 
Stack 11
Z_112 Z_113 A_6 
