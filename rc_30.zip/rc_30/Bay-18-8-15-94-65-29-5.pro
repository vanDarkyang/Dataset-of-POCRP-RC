Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
F_6 J_2 Z_100 F_3 B_1 Z_101 
Stack 1
K_2 O_1 H_0 C_1 J_6 G_0 
Stack 2
I_3 Z_102 H_5 Z_103 Z_104 Z_105 
Stack 3
O_0 J_3 I_1 B_0 F_0 E_4 
Stack 4
Z_106 Z_107 Z_108 L_2 Z_109 
Stack 5
A_1 Z_110 M_0 N_0 K_3 
Stack 6
D_2 M_2 H_2 K_5 H_3 
Stack 7
N_1 G_4 G_2 Z_111 Z_112 
Stack 8
G_5 E_5 N_2 H_1 J_4 
Stack 9
H_4 Z_113 L_1 F_4 Z_114 
Stack 10
Z_115 D_3 K_4 L_0 Z_116 
Stack 11
C_0 I_4 J_5 F_2 Z_117 
Stack 12
Z_118 G_3 I_0 K_1 Z_119 
Stack 13
F_1 Z_120 J_0 J_7 E_0 
Stack 14
E_1 D_0 Z_121 Z_122 A_0 
Stack 15
Z_123 Z_124 K_0 I_2 J_1 
Stack 16
E_2 G_1 F_5 Z_125 Z_126 
Stack 17
E_3 Z_127 M_1 Z_128 D_1 
