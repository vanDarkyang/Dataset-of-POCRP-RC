Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
G_0 Z_100 D_3 E_6 E_2 
Stack 1
Z_101 J_2 E_1 Z_102 H_0 
Stack 2
A_1 J_0 E_0 F_1 I_0 
Stack 3
D_0 H_3 C_2 Z_103 I_3 
Stack 4
G_2 Z_104 G_7 Z_105 H_4 
Stack 5
Z_106 Z_107 B_2 G_4 G_5 
Stack 6
C_0 Z_108 H_2 B_4 Z_109 
Stack 7
D_6 E_4 G_1 J_1 B_1 
Stack 8
D_4 Z_110 I_1 Z_111 Z_112 
Stack 9
E_3 D_1 Z_113 Z_114 G_6 
Stack 10
J_3 B_3 F_2 Z_115 H_1 
Stack 11
E_5 C_1 B_0 Z_116 D_2 
Stack 12
I_2 F_0 G_3 A_0 Z_117 
Stack 13
Z_118 F_3 Z_119 Z_120 D_5 
