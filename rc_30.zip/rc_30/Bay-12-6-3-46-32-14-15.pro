Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_7 B_11 C_5 C_6 
Stack 1
B_4 B_0 B_12 A_0 
Stack 2
A_5 C_0 Z_100 A_8 
Stack 3
B_3 Z_101 Z_102 B_9 
Stack 4
Z_103 B_2 Z_104 Z_105 
Stack 5
B_7 Z_106 C_4 A_4 
Stack 6
B_5 A_3 C_1 B_1 
Stack 7
A_9 Z_107 B_8 B_6 
Stack 8
A_6 Z_108 C_8 Z_109 
Stack 9
A_2 C_3 Z_110 B_10 
Stack 10
C_7 Z_111 A_1 
Stack 11
Z_112 Z_113 C_2 
