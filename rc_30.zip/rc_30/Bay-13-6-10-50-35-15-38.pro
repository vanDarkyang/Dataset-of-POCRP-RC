Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
E_1 Z_100 F_0 Z_101 
Stack 1
Z_102 G_4 F_1 A_1 
Stack 2
B_0 J_0 C_1 F_2 
Stack 3
E_4 Z_103 Z_104 J_1 
Stack 4
D_2 H_3 C_0 A_0 
Stack 5
G_0 E_3 G_2 Z_105 
Stack 6
Z_106 I_0 Z_107 Z_108 
Stack 7
H_0 F_4 D_3 E_2 
Stack 8
E_5 H_1 D_1 E_0 
Stack 9
Z_109 G_3 H_2 G_1 
Stack 10
B_1 D_0 Z_110 Z_111 
Stack 11
Z_112 A_2 Z_113 
Stack 12
F_3 Z_114 D_4 
