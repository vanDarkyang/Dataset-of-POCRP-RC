Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
H_3 G_3 J_0 E_0 Z_100 
Stack 1
F_0 Z_101 Z_102 C_3 I_2 
Stack 2
D_1 Z_103 Z_104 E_1 C_2 
Stack 3
B_1 Z_105 H_0 F_3 Z_106 
Stack 4
Z_107 J_1 C_0 H_2 Z_108 
Stack 5
G_1 B_0 C_1 I_1 Z_109 
Stack 6
Z_110 D_3 D_2 G_2 G_0 
Stack 7
F_2 A_0 H_1 E_2 Z_111 
Stack 8
D_0 C_4 Z_112 F_1 J_2 
Stack 9
Z_113 Z_114 I_0 H_4 G_4 
