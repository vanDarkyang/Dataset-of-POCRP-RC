Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
Z_100 Z_101 Z_102 H_5 J_2 F_2 
Stack 1
E_2 L_0 K_3 Z_103 E_5 G_2 
Stack 2
G_5 K_1 M_0 Z_104 Z_105 O_1 
Stack 3
Z_106 Z_107 J_1 J_3 A_2 Z_108 
Stack 4
O_2 G_6 L_2 H_1 E_4 
Stack 5
Z_109 Z_110 A_3 Z_111 O_0 
Stack 6
Z_112 Z_113 L_3 A_0 H_4 
Stack 7
N_0 Z_114 C_5 K_2 I_8 
Stack 8
K_7 C_4 I_3 B_2 Z_115 
Stack 9
L_1 M_4 C_1 E_1 M_2 
Stack 10
Z_116 I_1 Z_117 I_0 A_1 
Stack 11
K_0 O_3 Z_118 G_3 I_9 
Stack 12
C_6 O_4 J_0 D_1 K_6 
Stack 13
D_0 Z_119 Z_120 B_0 C_2 
Stack 14
I_6 Z_121 H_0 I_7 N_1 
Stack 15
Z_122 Z_123 M_3 Z_124 Z_125 
Stack 16
Z_126 C_0 D_2 Z_127 G_0 
Stack 17
F_1 Z_128 D_5 B_3 J_5 
Stack 18
E_3 Z_129 E_0 G_4 D_3 
Stack 19
J_6 K_4 Z_130 H_3 I_4 
Stack 20
C_3 I_5 I_2 Z_131 Z_132 
Stack 21
Z_133 B_1 F_0 L_4 D_4 
Stack 22
Z_134 M_1 Z_135 Z_136 H_2 
Stack 23
G_1 Z_137 K_5 F_3 J_4 
