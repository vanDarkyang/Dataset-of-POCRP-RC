Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
A_1 Z_100 C_4 D_7 D_6 
Stack 1
B_4 B_8 C_0 Z_101 E_2 
Stack 2
Z_102 E_5 Z_103 B_5 E_1 
Stack 3
Z_104 A_4 Z_105 Z_106 D_4 
Stack 4
D_0 B_7 C_2 Z_107 E_6 
Stack 5
D_8 Z_108 E_3 D_9 D_5 
Stack 6
D_1 D_2 Z_109 B_1 A_0 
Stack 7
Z_110 Z_111 C_3 E_0 A_3 
Stack 8
C_5 A_2 Z_112 Z_113 B_3 
Stack 9
B_0 C_1 E_4 B_2 D_3 
Stack 10
B_6 Z_114 Z_115 Z_116 
