Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 A_0 D_0 H_3 
Stack 1
G_1 Z_101 J_1 I_0 
Stack 2
Z_102 H_1 Z_103 F_1 
Stack 3
B_2 C_1 H_2 C_2 
Stack 4
Z_104 Z_105 I_3 F_2 
Stack 5
Z_106 B_1 A_1 G_0 
Stack 6
G_3 C_0 E_3 I_1 
Stack 7
Z_107 Z_108 E_0 H_0 
Stack 8
Z_109 Z_110 E_2 Z_111 
Stack 9
H_4 Z_112 F_3 E_1 
Stack 10
D_2 I_2 E_4 D_1 
Stack 11
B_0 F_0 G_2 
Stack 12
Z_113 J_0 Z_114 
