Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
J_0 Z_100 G_1 I_2 
Stack 1
Z_101 E_3 Z_102 J_2 
Stack 2
C_1 A_1 Z_103 F_3 
Stack 3
F_0 Z_104 I_0 A_3 
Stack 4
C_0 D_3 Z_105 Z_106 
Stack 5
H_4 Z_107 G_4 E_2 
Stack 6
Z_108 Z_109 Z_110 B_1 
Stack 7
Z_111 E_1 F_1 H_6 
Stack 8
J_1 Z_112 C_2 F_2 
Stack 9
G_2 I_3 D_4 E_0 
Stack 10
B_4 Z_113 Z_114 I_4 
Stack 11
B_5 E_5 H_2 D_1 
Stack 12
G_0 Z_115 D_2 H_3 
Stack 13
Z_116 H_1 B_3 Z_117 
Stack 14
C_3 A_0 Z_118 I_1 
Stack 15
G_3 H_5 D_0 H_0 
Stack 16
Z_119 B_0 E_4 
Stack 17
A_2 B_2 Z_120 
