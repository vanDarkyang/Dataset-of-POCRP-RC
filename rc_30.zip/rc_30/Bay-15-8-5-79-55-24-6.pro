Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_3 C_9 B_4 E_10 E_9 E_1 
Stack 1
B_8 A_10 B_1 Z_100 E_0 D_7 
Stack 2
A_0 B_2 D_9 Z_101 C_1 B_5 
Stack 3
Z_102 C_5 Z_103 E_6 D_10 A_5 
Stack 4
Z_104 Z_105 Z_106 Z_107 B_9 
Stack 5
D_3 Z_108 Z_109 Z_110 E_8 
Stack 6
C_4 D_0 A_1 D_5 A_6 
Stack 7
C_0 E_3 Z_111 Z_112 E_4 
Stack 8
E_7 Z_113 D_1 C_3 Z_114 
Stack 9
Z_115 D_2 Z_116 A_8 B_6 
Stack 10
C_7 A_4 B_10 D_8 B_0 
Stack 11
Z_117 A_2 Z_118 C_8 B_7 
Stack 12
Z_119 C_6 A_7 A_9 E_5 
Stack 13
Z_120 Z_121 D_6 Z_122 D_4 
Stack 14
B_3 C_10 Z_123 C_2 E_2 
