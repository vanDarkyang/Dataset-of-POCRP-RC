Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_6 Z_100 Z_101 Z_102 
Stack 1
Z_103 Z_104 C_11 A_4 
Stack 2
Z_105 Z_106 B_7 Z_107 
Stack 3
Z_108 Z_109 C_9 E_6 
Stack 4
D_10 B_2 E_8 B_5 
Stack 5
C_2 C_5 B_4 A_2 
Stack 6
A_3 A_10 B_10 Z_110 
Stack 7
C_1 C_7 C_4 D_0 
Stack 8
D_1 E_7 Z_111 C_12 
Stack 9
E_2 D_9 Z_112 D_8 
Stack 10
D_7 E_3 Z_113 Z_114 
Stack 11
B_6 D_2 A_7 C_10 
Stack 12
Z_115 C_0 Z_116 E_5 
Stack 13
Z_117 C_3 A_1 B_3 
Stack 14
Z_118 B_1 C_6 D_6 
Stack 15
C_8 D_4 E_1 Z_119 
Stack 16
B_8 A_5 Z_120 B_9 
Stack 17
Z_121 E_0 B_0 E_4 
Stack 18
A_0 Z_122 A_9 A_8 
Stack 19
Z_123 D_5 D_3 
