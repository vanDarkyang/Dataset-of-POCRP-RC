Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
A_1 C_4 B_0 A_6 E_4 
Stack 1
Z_100 D_1 D_6 D_2 D_3 
Stack 2
E_5 B_5 A_3 A_5 Z_101 
Stack 3
Z_102 Z_103 D_4 Z_104 Z_105 
Stack 4
Z_106 C_6 C_3 Z_107 C_1 
Stack 5
B_7 A_2 Z_108 E_1 B_6 
Stack 6
C_5 E_6 Z_109 Z_110 B_4 
Stack 7
Z_111 B_2 C_2 E_2 Z_112 
Stack 8
E_7 D_0 B_3 Z_113 A_0 
Stack 9
D_5 C_0 B_1 E_0 Z_114 
Stack 10
E_3 A_4 Z_115 Z_116 
