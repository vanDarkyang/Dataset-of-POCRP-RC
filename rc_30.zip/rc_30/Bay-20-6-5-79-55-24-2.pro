Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_6 B_11 A_5 D_4 
Stack 1
A_6 Z_100 D_8 E_4 
Stack 2
Z_101 B_2 E_5 D_3 
Stack 3
B_6 C_5 Z_102 Z_103 
Stack 4
D_6 E_3 D_1 A_4 
Stack 5
E_7 C_7 C_1 Z_104 
Stack 6
C_8 Z_105 A_8 Z_106 
Stack 7
D_2 Z_107 Z_108 Z_109 
Stack 8
B_4 Z_110 E_0 B_9 
Stack 9
E_1 E_6 C_11 A_1 
Stack 10
C_10 C_9 D_11 C_0 
Stack 11
A_3 B_7 Z_111 A_7 
Stack 12
Z_112 Z_113 Z_114 D_10 
Stack 13
A_0 Z_115 Z_116 Z_117 
Stack 14
Z_118 B_8 Z_119 B_10 
Stack 15
B_1 B_3 D_9 D_0 
Stack 16
C_2 Z_120 Z_121 Z_122 
Stack 17
C_4 B_12 D_5 Z_123 
Stack 18
C_3 B_5 E_2 D_7 
Stack 19
B_0 A_2 E_8 
