Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
C_0 F_1 E_2 Z_100 
Stack 1
I_0 C_1 G_2 D_0 
Stack 2
G_0 F_0 B_1 Z_101 
Stack 3
B_2 E_1 H_1 Z_102 
Stack 4
Z_103 Z_104 G_1 Z_105 
Stack 5
J_1 J_2 Z_106 D_1 
Stack 6
I_1 Z_107 H_4 G_3 
Stack 7
Z_108 Z_109 H_3 E_0 
Stack 8
I_3 G_4 H_2 Z_110 
Stack 9
Z_111 D_2 A_0 B_0 
Stack 10
I_2 A_1 Z_112 J_0 
Stack 11
D_3 Z_113 D_4 
Stack 12
H_0 A_2 Z_114 
