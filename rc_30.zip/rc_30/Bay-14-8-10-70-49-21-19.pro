Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
F_0 D_4 Z_100 H_3 A_1 
Stack 1
E_5 D_3 I_3 H_1 Z_101 
Stack 2
Z_102 G_3 F_5 B_3 B_0 
Stack 3
H_0 Z_103 Z_104 Z_105 Z_106 
Stack 4
E_1 G_5 F_1 G_4 Z_107 
Stack 5
B_1 J_0 C_1 Z_108 E_7 
Stack 6
Z_109 Z_110 I_2 D_2 Z_111 
Stack 7
E_0 F_3 I_1 E_3 E_4 
Stack 8
Z_112 G_2 B_2 Z_113 D_5 
Stack 9
D_1 D_6 A_2 G_1 E_2 
Stack 10
B_4 G_0 A_0 H_2 Z_114 
Stack 11
H_4 Z_115 F_4 F_2 Z_116 
Stack 12
Z_117 C_0 A_3 D_0 Z_118 
Stack 13
Z_119 D_7 I_0 Z_120 E_6 
