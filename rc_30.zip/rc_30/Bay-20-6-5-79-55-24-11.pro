Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_9 Z_100 D_8 C_3 
Stack 1
Z_101 A_4 D_4 E_0 
Stack 2
B_0 C_5 Z_102 C_2 
Stack 3
C_8 B_3 D_0 Z_103 
Stack 4
C_1 Z_104 A_3 Z_105 
Stack 5
A_9 C_7 B_2 A_1 
Stack 6
E_5 B_10 Z_106 Z_107 
Stack 7
A_8 D_10 Z_108 E_4 
Stack 8
E_1 C_4 Z_109 Z_110 
Stack 9
D_5 B_8 D_6 D_2 
Stack 10
B_11 B_7 D_12 B_13 
Stack 11
B_9 B_4 Z_111 B_12 
Stack 12
A_0 A_7 D_3 Z_112 
Stack 13
C_6 Z_113 B_14 A_2 
Stack 14
Z_114 C_0 Z_115 A_5 
Stack 15
E_6 E_7 Z_116 B_6 
Stack 16
Z_117 Z_118 D_7 B_5 
Stack 17
Z_119 Z_120 D_11 E_3 
Stack 18
Z_121 E_2 A_6 B_1 
Stack 19
Z_122 Z_123 D_1 
