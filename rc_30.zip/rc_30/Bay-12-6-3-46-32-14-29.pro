Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_6 Z_100 A_5 Z_101 
Stack 1
Z_102 B_4 C_7 C_4 
Stack 2
Z_103 C_8 A_2 C_9 
Stack 3
C_2 C_10 C_11 B_0 
Stack 4
B_8 A_0 B_3 B_1 
Stack 5
C_1 B_11 A_7 B_7 
Stack 6
Z_104 C_3 C_5 B_10 
Stack 7
Z_105 B_9 B_2 A_1 
Stack 8
Z_106 Z_107 A_3 Z_108 
Stack 9
Z_109 Z_110 Z_111 A_4 
Stack 10
B_6 A_6 C_0 
Stack 11
Z_112 B_5 Z_113 
