Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
G_4 E_1 F_4 C_0 
Stack 1
B_0 H_3 D_5 Z_100 
Stack 2
B_2 E_0 F_0 Z_101 
Stack 3
B_1 G_6 A_2 Z_102 
Stack 4
Z_103 H_0 F_3 Z_104 
Stack 5
D_3 E_5 D_2 Z_105 
Stack 6
E_4 C_1 I_1 Z_106 
Stack 7
Z_107 Z_108 H_2 D_1 
Stack 8
Z_109 E_6 Z_110 A_1 
Stack 9
H_4 D_6 I_0 F_2 
Stack 10
A_0 D_0 Z_111 A_3 
Stack 11
D_4 J_0 Z_112 F_1 
Stack 12
Z_113 Z_114 Z_115 G_1 
Stack 13
H_5 Z_116 Z_117 H_1 
Stack 14
G_2 G_0 G_3 C_2 
Stack 15
F_5 Z_118 E_2 Z_119 
Stack 16
G_5 B_3 I_2 
Stack 17
Z_120 J_1 E_3 
