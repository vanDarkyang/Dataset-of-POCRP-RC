Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
A_1 Z_100 B_2 E_5 
Stack 1
D_1 C_3 C_8 Z_101 
Stack 2
Z_102 Z_103 C_6 E_6 
Stack 3
Z_104 B_1 C_5 Z_105 
Stack 4
Z_106 A_2 D_4 Z_107 
Stack 5
B_6 Z_108 Z_109 A_3 
Stack 6
C_2 Z_110 B_5 C_0 
Stack 7
B_0 Z_111 Z_112 D_6 
Stack 8
E_3 C_4 A_4 Z_113 
Stack 9
C_1 A_0 Z_114 D_5 
Stack 10
E_2 Z_115 E_1 E_4 
Stack 11
D_7 C_7 B_3 Z_116 
Stack 12
B_7 D_3 B_4 
Stack 13
D_0 D_2 E_0 
