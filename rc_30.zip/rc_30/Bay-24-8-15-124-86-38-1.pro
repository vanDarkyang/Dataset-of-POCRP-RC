Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
Z_100 Z_101 I_0 E_6 F_0 H_1 
Stack 1
Z_102 K_0 I_2 O_0 N_1 E_5 
Stack 2
H_2 N_0 Z_103 G_8 I_4 D_4 
Stack 3
Z_104 D_2 E_3 D_0 H_0 Z_105 
Stack 4
B_3 O_1 C_0 G_7 J_4 
Stack 5
Z_106 J_2 H_4 D_5 Z_107 
Stack 6
F_2 K_4 G_6 F_4 Z_108 
Stack 7
E_0 C_3 H_5 A_0 N_2 
Stack 8
B_4 H_3 Z_109 J_0 A_2 
Stack 9
D_1 L_3 Z_110 Z_111 Z_112 
Stack 10
H_8 F_1 Z_113 F_3 Z_114 
Stack 11
Z_115 N_3 G_4 C_2 G_2 
Stack 12
K_3 L_5 Z_116 E_4 Z_117 
Stack 13
Z_118 L_0 Z_119 M_2 K_1 
Stack 14
D_3 G_1 Z_120 O_2 Z_121 
Stack 15
I_3 Z_122 Z_123 K_2 Z_124 
Stack 16
Z_125 Z_126 J_5 E_1 B_0 
Stack 17
G_3 Z_127 J_6 Z_128 L_2 
Stack 18
G_5 Z_129 M_3 B_2 H_6 
Stack 19
E_2 Z_130 Z_131 H_7 C_4 
Stack 20
Z_132 M_1 M_0 Z_133 I_1 
Stack 21
L_1 L_4 Z_134 N_4 Z_135 
Stack 22
J_3 B_1 C_1 Z_136 Z_137 
Stack 23
L_6 A_1 L_7 J_1 G_0 
