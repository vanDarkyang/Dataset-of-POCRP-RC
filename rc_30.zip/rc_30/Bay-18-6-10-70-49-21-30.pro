Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 I_1 D_3 C_1 
Stack 1
H_2 Z_101 Z_102 Z_103 
Stack 2
D_2 F_0 Z_104 I_0 
Stack 3
Z_105 Z_106 G_4 H_5 
Stack 4
G_0 Z_107 Z_108 C_2 
Stack 5
F_2 Z_109 Z_110 Z_111 
Stack 6
Z_112 D_4 E_3 F_1 
Stack 7
C_3 Z_113 Z_114 F_4 
Stack 8
I_2 J_0 H_3 A_2 
Stack 9
A_3 D_5 A_1 H_0 
Stack 10
E_5 Z_115 Z_116 F_5 
Stack 11
Z_117 D_6 G_3 A_0 
Stack 12
I_3 Z_118 Z_119 E_4 
Stack 13
B_1 A_4 B_0 H_1 
Stack 14
H_4 F_3 I_4 H_6 
Stack 15
G_1 E_0 G_2 B_2 
Stack 16
E_2 E_1 Z_120 
Stack 17
D_0 D_1 C_0 
