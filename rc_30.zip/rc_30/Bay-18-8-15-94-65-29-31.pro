Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 L_0 K_2 Z_101 Z_102 F_2 
Stack 1
K_3 H_3 Z_103 M_1 Z_104 A_1 
Stack 2
L_2 B_1 O_1 G_0 M_0 F_1 
Stack 3
J_1 Z_105 D_3 H_0 I_7 Z_106 
Stack 4
Z_107 B_2 Z_108 J_2 E_2 
Stack 5
G_1 E_1 F_5 L_1 Z_109 
Stack 6
E_3 I_1 F_4 Z_110 Z_111 
Stack 7
O_0 J_3 F_3 K_1 N_0 
Stack 8
Z_112 K_4 A_0 E_0 Z_113 
Stack 9
Z_114 M_3 Z_115 Z_116 Z_117 
Stack 10
L_3 N_1 Z_118 I_4 Z_119 
Stack 11
G_2 Z_120 F_0 I_3 H_2 
Stack 12
I_6 I_0 J_0 D_1 Z_121 
Stack 13
Z_122 Z_123 E_4 Z_124 Z_125 
Stack 14
H_5 H_1 J_4 L_4 B_0 
Stack 15
B_3 I_2 H_4 C_1 D_2 
Stack 16
K_5 M_2 Z_126 D_4 C_0 
Stack 17
D_0 Z_127 I_5 K_0 Z_128 
