Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
N_1 F_3 Z_100 J_0 M_2 K_4 
Stack 1
Z_101 Z_102 H_3 D_1 Z_103 Z_104 
Stack 2
Z_105 Z_106 D_2 Z_107 J_3 M_1 
Stack 3
E_2 G_0 F_4 D_3 C_3 Z_108 
Stack 4
H_2 L_2 Z_109 H_4 J_5 
Stack 5
Z_110 Z_111 D_4 A_0 H_5 
Stack 6
Z_112 N_0 G_4 J_4 K_0 
Stack 7
C_2 D_0 L_3 J_1 F_0 
Stack 8
I_0 G_2 I_1 E_3 M_0 
Stack 9
D_5 I_2 F_2 Z_113 Z_114 
Stack 10
A_1 G_1 L_4 L_1 Z_115 
Stack 11
B_1 C_0 B_0 H_1 G_3 
Stack 12
C_1 E_1 Z_116 K_3 I_3 
Stack 13
Z_117 I_4 K_1 J_6 K_2 
Stack 14
Z_118 Z_119 E_0 Z_120 Z_121 
Stack 15
Z_122 H_0 Z_123 H_6 G_5 
Stack 16
F_1 Z_124 J_2 Z_125 Z_126 
Stack 17
Z_127 Z_128 O_1 L_0 O_0 
