Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_2 Z_100 C_5 C_0 
Stack 1
C_9 Z_101 Z_102 Z_103 
Stack 2
Z_104 A_2 B_11 B_0 
Stack 3
C_7 B_3 A_0 B_9 
Stack 4
Z_105 C_10 B_5 B_4 
Stack 5
A_1 Z_106 A_7 Z_107 
Stack 6
C_2 C_6 C_11 A_4 
Stack 7
B_7 C_1 Z_108 Z_109 
Stack 8
Z_110 B_8 Z_111 B_6 
Stack 9
B_10 C_8 A_3 A_6 
Stack 10
C_4 C_3 Z_112 
Stack 11
B_1 A_5 Z_113 
