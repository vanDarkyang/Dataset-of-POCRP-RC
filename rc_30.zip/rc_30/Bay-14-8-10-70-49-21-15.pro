Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
C_2 D_1 Z_100 A_1 A_3 
Stack 1
D_2 Z_101 A_2 H_3 Z_102 
Stack 2
A_4 Z_103 Z_104 Z_105 Z_106 
Stack 3
E_6 B_3 Z_107 C_1 E_1 
Stack 4
E_5 B_1 H_1 Z_108 E_7 
Stack 5
I_1 Z_109 B_0 C_5 Z_110 
Stack 6
G_0 J_1 Z_111 Z_112 E_3 
Stack 7
B_2 I_0 F_3 A_0 E_0 
Stack 8
D_3 F_2 F_1 D_5 Z_113 
Stack 9
J_2 Z_114 J_0 I_4 E_4 
Stack 10
Z_115 G_1 C_4 C_0 Z_116 
Stack 11
H_0 E_2 D_0 H_2 Z_117 
Stack 12
H_4 Z_118 I_3 C_3 I_2 
Stack 13
Z_119 F_0 D_4 B_4 Z_120 
