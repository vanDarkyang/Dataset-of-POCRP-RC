Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_1 G_2 F_7 D_5 C_0 
Stack 1
A_1 D_0 E_6 Z_100 Z_101 
Stack 2
E_3 D_2 D_3 Z_102 H_1 
Stack 3
B_3 G_1 J_1 Z_103 J_2 
Stack 4
Z_104 A_0 H_2 D_4 H_0 
Stack 5
F_1 Z_105 E_0 Z_106 E_2 
Stack 6
Z_107 G_4 Z_108 E_1 B_0 
Stack 7
Z_109 Z_110 I_1 J_3 E_5 
Stack 8
F_3 Z_111 B_4 Z_112 F_0 
Stack 9
C_2 J_0 Z_113 F_4 E_4 
Stack 10
C_1 F_5 B_5 Z_114 F_2 
Stack 11
F_6 F_8 Z_115 E_7 Z_116 
Stack 12
Z_117 Z_118 Z_119 B_2 G_5 
Stack 13
I_0 G_3 B_1 Z_120 G_0 
