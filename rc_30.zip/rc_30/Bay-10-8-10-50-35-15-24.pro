Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
D_0 F_0 E_1 C_2 H_3 
Stack 1
Z_100 E_2 F_1 G_3 E_4 
Stack 2
H_0 D_2 B_1 H_1 D_3 
Stack 3
F_3 E_5 Z_101 Z_102 Z_103 
Stack 4
C_0 Z_104 F_2 E_3 Z_105 
Stack 5
Z_106 E_0 H_2 Z_107 J_0 
Stack 6
D_1 I_1 A_0 Z_108 Z_109 
Stack 7
E_6 G_0 G_1 Z_110 I_0 
Stack 8
G_2 C_1 F_4 Z_111 Z_112 
Stack 9
B_0 Z_113 Z_114 A_1 F_5 
