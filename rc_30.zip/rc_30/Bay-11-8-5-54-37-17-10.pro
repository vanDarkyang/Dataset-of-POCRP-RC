Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 B_4 C_6 D_4 Z_101 
Stack 1
B_0 Z_102 Z_103 E_6 Z_104 
Stack 2
A_6 A_5 Z_105 Z_106 B_3 
Stack 3
C_4 B_9 A_1 E_0 C_5 
Stack 4
B_6 E_5 C_3 D_2 D_3 
Stack 5
Z_107 Z_108 B_8 Z_109 C_2 
Stack 6
E_1 C_1 E_4 D_5 B_5 
Stack 7
B_7 D_1 E_2 D_0 A_4 
Stack 8
A_0 Z_110 A_3 C_0 Z_111 
Stack 9
A_2 Z_112 B_1 Z_113 Z_114 
Stack 10
E_3 Z_115 B_2 Z_116 
