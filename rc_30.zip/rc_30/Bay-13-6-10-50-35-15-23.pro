Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
B_0 Z_100 D_4 Z_101 
Stack 1
C_0 G_2 Z_102 B_1 
Stack 2
Z_103 J_2 A_1 Z_104 
Stack 3
E_0 Z_105 I_0 F_0 
Stack 4
G_3 J_0 C_1 D_3 
Stack 5
G_1 B_2 A_2 H_1 
Stack 6
Z_106 C_4 D_0 Z_107 
Stack 7
F_2 C_2 D_2 I_1 
Stack 8
E_1 F_1 Z_108 Z_109 
Stack 9
Z_110 Z_111 A_0 F_3 
Stack 10
Z_112 Z_113 H_0 Z_114 
Stack 11
J_1 F_4 D_1 
Stack 12
G_0 E_2 C_3 
