Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
F_3 Z_100 D_2 Z_101 
Stack 1
Z_102 E_1 I_1 I_0 
Stack 2
Z_103 Z_104 G_0 C_0 
Stack 3
Z_105 A_0 C_2 D_4 
Stack 4
C_3 G_1 F_1 Z_106 
Stack 5
F_0 E_3 Z_107 J_0 
Stack 6
A_1 Z_108 E_2 Z_109 
Stack 7
C_1 B_0 E_5 Z_110 
Stack 8
G_2 F_2 Z_111 C_4 
Stack 9
Z_112 H_0 G_3 Z_113 
Stack 10
D_0 F_4 Z_114 H_2 
Stack 11
H_1 D_3 E_0 
Stack 12
D_1 B_1 E_4 
