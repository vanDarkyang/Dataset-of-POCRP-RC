Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
9
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
D_4 F_1 Z_100 H_2 
Stack 1
D_2 Z_101 G_4 I_0 
Stack 2
F_2 B_1 G_1 D_1 
Stack 3
F_3 Z_102 Z_103 Z_104 
Stack 4
D_0 C_1 G_2 G_0 
Stack 5
E_3 F_4 Z_105 Z_106 
Stack 6
H_1 A_0 Z_107 G_3 
Stack 7
H_0 F_0 F_5 D_3 
Stack 8
E_2 C_0 Z_108 Z_109 
Stack 9
C_3 Z_110 I_2 Z_111 
Stack 10
H_3 B_0 E_1 I_1 
Stack 11
Z_112 Z_113 Z_114 
Stack 12
E_0 D_5 C_2 
