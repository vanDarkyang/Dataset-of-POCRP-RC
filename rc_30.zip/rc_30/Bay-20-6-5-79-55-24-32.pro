Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 C_10 E_6 B_3 
Stack 1
D_1 Z_101 A_2 C_6 
Stack 2
E_8 C_8 E_5 C_3 
Stack 3
D_2 E_2 E_7 Z_102 
Stack 4
B_8 D_0 Z_103 A_6 
Stack 5
B_4 D_3 C_9 A_5 
Stack 6
Z_104 D_4 B_5 A_1 
Stack 7
B_9 E_1 Z_105 C_2 
Stack 8
B_2 Z_106 E_4 B_1 
Stack 9
Z_107 Z_108 Z_109 C_7 
Stack 10
B_0 Z_110 C_5 A_7 
Stack 11
D_7 Z_111 B_6 A_0 
Stack 12
D_6 A_4 Z_112 C_0 
Stack 13
C_12 C_13 C_1 B_7 
Stack 14
Z_113 E_3 Z_114 Z_115 
Stack 15
Z_116 Z_117 Z_118 D_8 
Stack 16
Z_119 C_4 A_9 A_8 
Stack 17
E_9 Z_120 Z_121 C_11 
Stack 18
Z_122 Z_123 E_0 B_10 
Stack 19
D_5 A_3 A_10 
