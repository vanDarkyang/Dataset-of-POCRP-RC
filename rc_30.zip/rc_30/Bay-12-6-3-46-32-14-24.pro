Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 A_4 B_5 Z_101 
Stack 1
Z_102 A_7 C_7 C_4 
Stack 2
Z_103 C_3 A_6 B_3 
Stack 3
Z_104 Z_105 C_1 Z_106 
Stack 4
B_10 C_2 B_8 A_8 
Stack 5
A_3 Z_107 A_5 B_6 
Stack 6
B_1 A_9 B_9 C_0 
Stack 7
Z_108 C_5 B_7 B_2 
Stack 8
Z_109 A_1 Z_110 Z_111 
Stack 9
B_0 A_0 B_11 A_2 
Stack 10
C_8 Z_112 Z_113 
Stack 11
B_4 C_6 C_9 
