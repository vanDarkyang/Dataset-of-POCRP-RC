Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 Z_101 Z_102 A_2 
Stack 1
B_3 C_1 Z_103 C_2 
Stack 2
A_6 C_8 B_7 C_3 
Stack 3
A_4 A_3 B_0 C_5 
Stack 4
Z_104 C_4 C_9 B_5 
Stack 5
Z_105 B_1 Z_106 C_7 
Stack 6
B_2 B_8 B_4 Z_107 
Stack 7
A_5 Z_108 A_8 Z_109 
Stack 8
A_10 C_0 A_1 B_9 
Stack 9
A_0 B_6 C_10 Z_110 
Stack 10
Z_111 C_6 A_7 
Stack 11
Z_112 Z_113 A_9 
