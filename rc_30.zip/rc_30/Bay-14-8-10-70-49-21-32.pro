Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 Z_101 Z_102 Z_103 J_2 
Stack 1
D_1 E_1 H_5 G_3 A_1 
Stack 2
C_2 D_5 C_0 Z_104 E_8 
Stack 3
E_2 D_4 Z_105 G_0 E_5 
Stack 4
J_0 I_2 G_1 H_0 Z_106 
Stack 5
I_0 E_7 E_4 C_4 H_1 
Stack 6
F_0 J_1 I_4 D_0 B_1 
Stack 7
Z_107 B_0 J_3 Z_108 Z_109 
Stack 8
F_4 Z_110 H_3 H_2 E_0 
Stack 9
Z_111 Z_112 Z_113 H_4 G_2 
Stack 10
Z_114 Z_115 Z_116 F_1 C_1 
Stack 11
Z_117 Z_118 F_2 A_0 I_1 
Stack 12
I_3 D_6 Z_119 F_3 E_3 
Stack 13
Z_120 C_3 E_6 D_2 D_3 
