Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
K_0 G_3 A_0 M_0 
Stack 1
Z_100 D_3 F_2 K_4 
Stack 2
C_0 N_0 F_1 H_3 
Stack 3
K_1 L_1 H_0 Z_101 
Stack 4
D_4 G_1 M_1 Z_102 
Stack 5
H_2 J_0 E_2 I_4 
Stack 6
C_3 Z_103 H_1 K_2 
Stack 7
Z_104 F_3 G_0 C_1 
Stack 8
Z_105 G_4 I_2 Z_106 
Stack 9
Z_107 L_0 M_2 L_3 
Stack 10
Z_108 E_1 I_5 Z_109 
Stack 11
F_4 Z_110 M_3 A_2 
Stack 12
G_5 J_2 O_0 Z_111 
Stack 13
Z_112 J_3 H_4 Z_113 
Stack 14
D_1 E_3 L_2 Z_114 
Stack 15
Z_115 Z_116 A_1 F_0 
Stack 16
H_6 Z_117 D_0 Z_118 
Stack 17
Z_119 K_3 N_2 C_2 
Stack 18
Z_120 Z_121 O_1 E_0 
Stack 19
N_1 I_1 H_5 I_3 
Stack 20
Z_122 Z_123 G_2 Z_124 
Stack 21
Z_125 B_0 Z_126 Z_127 
Stack 22
Z_128 I_0 B_1 
Stack 23
D_2 B_2 J_1 
