Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 Z_101 D_2 Z_102 Z_103 
Stack 1
E_1 A_4 D_3 Z_104 Z_105 
Stack 2
A_2 Z_106 C_0 A_1 D_4 
Stack 3
C_2 E_0 B_2 Z_107 Z_108 
Stack 4
Z_109 A_3 B_6 C_1 Z_110 
Stack 5
E_6 C_3 A_7 E_3 A_0 
Stack 6
Z_111 A_6 Z_112 Z_113 B_0 
Stack 7
Z_114 E_2 D_1 D_7 E_5 
Stack 8
C_6 A_5 C_5 B_3 Z_115 
Stack 9
B_4 B_5 B_1 C_4 D_6 
Stack 10
Z_116 D_5 E_4 D_0 
