Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
A_6 Z_100 D_1 C_5 
Stack 1
Z_101 B_0 D_0 B_1 
Stack 2
C_3 B_2 B_4 E_1 
Stack 3
A_7 Z_102 Z_103 Z_104 
Stack 4
C_4 Z_105 D_5 B_3 
Stack 5
C_6 E_4 A_4 E_3 
Stack 6
Z_106 C_2 E_2 Z_107 
Stack 7
Z_108 C_1 B_5 Z_109 
Stack 8
D_3 E_5 A_1 D_4 
Stack 9
Z_110 B_6 E_6 C_7 
Stack 10
A_5 A_0 Z_111 Z_112 
Stack 11
C_0 A_3 D_2 D_6 
Stack 12
Z_113 A_2 Z_114 
Stack 13
Z_115 Z_116 E_0 
