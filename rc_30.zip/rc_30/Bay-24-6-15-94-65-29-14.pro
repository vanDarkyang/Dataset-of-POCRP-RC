Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
J_5 F_4 J_2 G_0 
Stack 1
G_2 H_4 Z_100 Z_101 
Stack 2
C_2 G_1 Z_102 Z_103 
Stack 3
Z_104 M_0 Z_105 H_3 
Stack 4
Z_106 K_5 Z_107 Z_108 
Stack 5
O_1 J_6 Z_109 Z_110 
Stack 6
Z_111 E_0 F_2 Z_112 
Stack 7
A_0 Z_113 J_1 O_2 
Stack 8
D_0 Z_114 G_4 D_3 
Stack 9
Z_115 Z_116 Z_117 H_1 
Stack 10
Z_118 I_3 K_3 J_3 
Stack 11
B_1 K_1 N_1 J_4 
Stack 12
I_0 D_1 Z_119 L_3 
Stack 13
E_4 Z_120 K_0 F_1 
Stack 14
C_0 K_4 N_0 I_1 
Stack 15
G_3 J_0 Z_121 M_1 
Stack 16
Z_122 E_3 O_0 F_0 
Stack 17
B_2 Z_123 C_1 E_2 
Stack 18
Z_124 M_3 M_2 D_2 
Stack 19
H_0 A_1 I_4 K_2 
Stack 20
Z_125 Z_126 I_2 Z_127 
Stack 21
E_1 L_1 H_2 H_5 
Stack 22
N_2 L_0 L_2 
Stack 23
Z_128 B_0 F_3 
