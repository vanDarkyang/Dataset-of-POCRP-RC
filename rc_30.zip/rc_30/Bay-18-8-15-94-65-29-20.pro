Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
K_1 I_3 Z_100 Z_101 B_1 Z_102 
Stack 1
I_0 K_2 H_1 Z_103 Z_104 Z_105 
Stack 2
Z_106 K_3 H_7 L_1 Z_107 Z_108 
Stack 3
Z_109 M_3 K_4 M_0 Z_110 M_2 
Stack 4
H_0 J_1 Z_111 Z_112 N_0 
Stack 5
Z_113 Z_114 N_1 M_1 G_6 
Stack 6
G_0 F_2 H_3 J_3 A_0 
Stack 7
E_2 H_5 Z_115 Z_116 Z_117 
Stack 8
C_1 O_1 H_2 J_2 G_5 
Stack 9
L_2 I_1 J_0 E_1 Z_118 
Stack 10
C_0 G_1 Z_119 G_3 O_2 
Stack 11
H_4 F_0 Z_120 I_2 D_0 
Stack 12
D_1 F_3 Z_121 K_0 H_6 
Stack 13
Z_122 Z_123 G_2 Z_124 N_3 
Stack 14
B_0 L_3 G_4 Z_125 L_4 
Stack 15
N_2 H_8 Z_126 I_4 L_0 
Stack 16
B_2 Z_127 G_7 E_3 E_0 
Stack 17
F_4 O_0 Z_128 F_1 C_2 
