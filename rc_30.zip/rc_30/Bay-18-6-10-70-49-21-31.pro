Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
C_3 I_1 H_2 F_6 
Stack 1
D_1 E_4 G_1 D_2 
Stack 2
C_1 J_1 B_2 Z_100 
Stack 3
Z_101 B_3 F_4 A_3 
Stack 4
J_0 G_3 B_0 E_5 
Stack 5
Z_102 G_2 Z_103 E_3 
Stack 6
F_0 Z_104 A_2 Z_105 
Stack 7
F_3 I_2 Z_106 Z_107 
Stack 8
F_7 Z_108 A_0 B_4 
Stack 9
B_1 C_2 Z_109 Z_110 
Stack 10
F_2 Z_111 H_0 E_0 
Stack 11
Z_112 Z_113 C_4 Z_114 
Stack 12
I_3 C_0 D_0 Z_115 
Stack 13
Z_116 Z_117 J_2 I_0 
Stack 14
F_5 G_0 H_1 E_2 
Stack 15
E_1 Z_118 Z_119 D_3 
Stack 16
D_4 I_4 F_1 
Stack 17
Z_120 J_3 A_1 
