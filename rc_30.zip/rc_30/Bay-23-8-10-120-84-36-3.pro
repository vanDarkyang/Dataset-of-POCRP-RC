Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 Z_101 J_0 Z_102 D_8 I_4 
Stack 1
Z_103 D_9 H_8 Z_104 Z_105 A_6 
Stack 2
C_7 C_0 Z_106 F_1 Z_107 Z_108 
Stack 3
A_4 G_0 A_2 D_5 E_0 J_4 
Stack 4
E_3 E_1 E_5 Z_109 H_4 B_7 
Stack 5
F_7 F_8 A_1 E_4 G_7 
Stack 6
Z_110 H_3 Z_111 Z_112 D_7 
Stack 7
E_8 B_5 Z_113 Z_114 D_1 
Stack 8
J_3 H_1 C_8 C_6 I_2 
Stack 9
H_7 F_2 F_6 J_2 B_1 
Stack 10
D_6 Z_115 Z_116 A_0 B_2 
Stack 11
B_4 C_4 Z_117 F_4 E_7 
Stack 12
B_8 F_0 Z_118 Z_119 J_1 
Stack 13
D_2 G_3 F_3 Z_120 D_0 
Stack 14
F_5 G_2 A_5 Z_121 C_2 
Stack 15
D_4 B_0 C_3 C_9 J_5 
Stack 16
G_1 Z_122 I_3 H_5 Z_123 
Stack 17
E_9 Z_124 G_6 D_3 Z_125 
Stack 18
Z_126 Z_127 H_6 E_6 F_9 
Stack 19
Z_128 E_2 Z_129 I_1 Z_130 
Stack 20
Z_131 B_3 B_6 Z_132 I_0 
Stack 21
Z_133 H_0 Z_134 A_3 H_2 
Stack 22
C_1 G_4 Z_135 G_5 C_5 
