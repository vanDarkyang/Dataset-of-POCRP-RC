Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
H_0 Z_100 F_3 C_4 F_1 
Stack 1
D_2 J_3 Z_101 I_3 E_4 
Stack 2
B_2 G_0 B_0 H_1 I_1 
Stack 3
C_5 D_3 Z_102 J_2 Z_103 
Stack 4
Z_104 C_2 D_1 Z_105 B_1 
Stack 5
Z_106 D_4 E_0 D_0 J_1 
Stack 6
G_2 A_1 Z_107 Z_108 A_2 
Stack 7
C_1 E_2 Z_109 Z_110 D_5 
Stack 8
Z_111 E_1 H_2 J_0 I_2 
Stack 9
F_5 Z_112 Z_113 C_3 G_3 
Stack 10
Z_114 E_5 I_0 D_6 F_4 
Stack 11
F_6 C_0 B_3 Z_115 Z_116 
Stack 12
Z_117 E_3 A_0 F_2 G_1 
Stack 13
Z_118 Z_119 Z_120 F_0 H_3 
