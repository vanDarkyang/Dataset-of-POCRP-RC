Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 Z_101 A_8 Z_102 D_3 
Stack 1
C_5 Z_103 B_1 Z_104 Z_105 
Stack 2
Z_106 Z_107 C_2 A_3 Z_108 
Stack 3
D_2 D_6 Z_109 C_1 Z_110 
Stack 4
A_2 A_0 E_0 C_3 A_6 
Stack 5
A_7 A_5 B_5 B_3 E_5 
Stack 6
Z_111 Z_112 B_0 E_1 Z_113 
Stack 7
C_4 A_1 E_4 Z_114 B_6 
Stack 8
B_2 Z_115 B_4 D_7 D_5 
Stack 9
C_0 E_3 Z_116 D_4 D_0 
Stack 10
A_4 D_1 D_8 E_2 
