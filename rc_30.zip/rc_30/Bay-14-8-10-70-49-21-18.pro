Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
A_0 G_6 G_5 Z_100 A_2 
Stack 1
Z_101 D_0 G_2 Z_102 Z_103 
Stack 2
C_3 J_4 A_3 E_0 C_4 
Stack 3
C_5 I_0 E_3 E_4 H_3 
Stack 4
J_2 F_2 I_2 C_0 Z_104 
Stack 5
H_4 Z_105 D_5 G_4 G_0 
Stack 6
B_0 J_3 I_1 A_1 Z_106 
Stack 7
E_1 Z_107 F_1 Z_108 D_2 
Stack 8
C_1 F_3 B_1 F_4 J_0 
Stack 9
Z_109 F_5 Z_110 H_0 Z_111 
Stack 10
D_1 Z_112 D_4 H_1 J_1 
Stack 11
F_0 Z_113 C_2 Z_114 Z_115 
Stack 12
D_3 H_2 G_1 Z_116 Z_117 
Stack 13
G_3 Z_118 Z_119 Z_120 E_2 
