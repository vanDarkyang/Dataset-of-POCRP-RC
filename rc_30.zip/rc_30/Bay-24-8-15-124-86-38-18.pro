Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
Z_100 F_2 N_3 E_0 A_0 Z_101 
Stack 1
M_3 C_5 Z_102 Z_103 I_4 Z_104 
Stack 2
E_1 Z_105 Z_106 Z_107 N_2 Z_108 
Stack 3
Z_109 K_4 N_1 G_3 B_2 H_5 
Stack 4
Z_110 G_4 O_1 H_7 F_5 
Stack 5
C_0 I_1 K_1 D_0 N_4 
Stack 6
D_2 G_1 J_6 Z_111 Z_112 
Stack 7
Z_113 B_5 J_2 G_5 Z_114 
Stack 8
Z_115 J_3 Z_116 Z_117 N_0 
Stack 9
Z_118 H_1 B_1 Z_119 M_1 
Stack 10
Z_120 A_2 I_3 D_4 Z_121 
Stack 11
F_7 Z_122 C_3 D_3 C_1 
Stack 12
Z_123 B_3 I_2 L_0 K_2 
Stack 13
Z_124 Z_125 L_2 G_2 E_3 
Stack 14
J_0 Z_126 Z_127 K_0 H_3 
Stack 15
I_6 C_2 E_2 E_4 Z_128 
Stack 16
D_1 H_0 H_6 C_4 G_6 
Stack 17
Z_129 B_0 J_4 A_1 H_2 
Stack 18
Z_130 G_0 B_4 F_3 Z_131 
Stack 19
L_1 I_8 I_0 O_0 J_5 
Stack 20
Z_132 J_1 Z_133 Z_134 I_7 
Stack 21
F_4 D_5 Z_135 F_8 F_6 
Stack 22
M_2 H_4 M_0 K_3 F_1 
Stack 23
I_5 Z_136 Z_137 O_2 F_0 
