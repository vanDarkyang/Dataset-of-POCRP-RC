Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
F_4 B_2 C_0 Z_100 A_0 
Stack 1
F_2 H_3 E_3 Z_101 E_4 
Stack 2
Z_102 G_2 B_3 I_0 B_1 
Stack 3
Z_103 Z_104 G_1 I_1 Z_105 
Stack 4
A_1 Z_106 H_1 Z_107 B_0 
Stack 5
G_0 Z_108 D_3 D_0 Z_109 
Stack 6
H_0 F_0 D_1 E_2 Z_110 
Stack 7
J_0 I_2 E_0 Z_111 A_2 
Stack 8
C_2 F_3 E_1 Z_112 C_1 
Stack 9
F_1 Z_113 D_2 H_2 Z_114 
