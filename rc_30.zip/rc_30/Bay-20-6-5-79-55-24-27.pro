Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
E_8 D_8 E_7 Z_100 
Stack 1
B_3 A_7 C_8 E_0 
Stack 2
C_13 B_7 D_2 Z_101 
Stack 3
B_4 A_6 C_11 C_4 
Stack 4
C_5 B_5 Z_102 Z_103 
Stack 5
C_7 C_9 Z_104 D_4 
Stack 6
B_0 E_5 B_9 B_2 
Stack 7
C_10 Z_105 A_3 Z_106 
Stack 8
E_10 D_1 D_6 C_12 
Stack 9
Z_107 Z_108 Z_109 C_0 
Stack 10
Z_110 Z_111 E_9 A_2 
Stack 11
C_6 A_1 E_6 Z_112 
Stack 12
A_10 E_4 Z_113 A_4 
Stack 13
Z_114 A_5 Z_115 Z_116 
Stack 14
Z_117 Z_118 E_1 D_7 
Stack 15
Z_119 E_2 Z_120 C_1 
Stack 16
B_8 D_3 Z_121 A_0 
Stack 17
C_3 A_9 D_0 C_2 
Stack 18
A_8 B_1 Z_122 E_3 
Stack 19
D_5 B_6 Z_123 
