Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_6 Z_100 Z_101 Z_102 
Stack 1
B_1 A_2 Z_103 E_8 
Stack 2
Z_104 Z_105 C_11 C_2 
Stack 3
D_3 D_6 B_0 B_8 
Stack 4
A_7 A_4 Z_106 B_6 
Stack 5
Z_107 Z_108 Z_109 E_11 
Stack 6
A_5 Z_110 B_7 E_10 
Stack 7
D_5 C_0 D_7 B_2 
Stack 8
C_4 A_1 C_5 Z_111 
Stack 9
C_1 C_12 Z_112 D_1 
Stack 10
E_0 Z_113 A_3 E_2 
Stack 11
D_0 D_2 E_9 C_8 
Stack 12
D_4 Z_114 C_10 C_7 
Stack 13
A_8 D_10 A_6 D_9 
Stack 14
E_5 Z_115 Z_116 E_4 
Stack 15
E_7 C_3 E_6 B_3 
Stack 16
Z_117 Z_118 Z_119 E_1 
Stack 17
E_3 B_9 D_8 B_4 
Stack 18
Z_120 C_9 Z_121 B_5 
Stack 19
Z_122 A_0 Z_123 
