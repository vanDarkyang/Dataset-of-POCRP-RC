Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
H_1 I_0 Z_100 I_1 Z_101 
Stack 1
F_3 A_0 C_0 Z_102 H_2 
Stack 2
D_5 J_1 H_3 C_1 D_3 
Stack 3
D_0 Z_103 Z_104 Z_105 H_4 
Stack 4
J_0 C_2 F_1 D_2 B_1 
Stack 5
E_1 F_0 Z_106 Z_107 Z_108 
Stack 6
I_2 E_2 C_3 F_2 Z_109 
Stack 7
Z_110 E_0 D_1 G_1 G_0 
Stack 8
D_4 F_4 Z_111 E_3 Z_112 
Stack 9
G_2 H_0 Z_113 B_0 Z_114 
