Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_7 A_3 B_9 A_11 
Stack 1
C_5 Z_100 Z_101 C_8 
Stack 2
Z_102 Z_103 Z_104 A_2 
Stack 3
A_4 C_6 C_7 Z_105 
Stack 4
Z_106 A_9 A_6 B_3 
Stack 5
A_8 Z_107 Z_108 C_1 
Stack 6
B_4 B_6 Z_109 B_2 
Stack 7
A_0 C_0 Z_110 B_10 
Stack 8
B_5 Z_111 B_0 A_10 
Stack 9
B_8 A_1 Z_112 B_1 
Stack 10
A_5 C_3 C_4 
Stack 11
A_7 Z_113 C_2 
