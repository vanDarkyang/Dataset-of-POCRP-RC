Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
I_1 A_0 I_4 E_7 Z_100 
Stack 1
Z_101 Z_102 C_0 Z_103 H_0 
Stack 2
B_0 Z_104 B_3 Z_105 B_2 
Stack 3
Z_106 Z_107 J_0 E_0 G_3 
Stack 4
E_6 B_1 Z_108 G_4 C_2 
Stack 5
E_1 Z_109 D_4 I_3 G_0 
Stack 6
G_6 H_2 D_2 J_1 D_3 
Stack 7
I_0 F_4 Z_110 Z_111 F_1 
Stack 8
G_2 Z_112 E_2 I_2 Z_113 
Stack 9
J_3 G_1 J_2 Z_114 Z_115 
Stack 10
C_3 E_4 F_0 F_2 E_8 
Stack 11
F_3 Z_116 D_1 C_4 Z_117 
Stack 12
Z_118 A_1 E_5 C_1 E_3 
Stack 13
Z_119 H_1 Z_120 G_5 D_0 
