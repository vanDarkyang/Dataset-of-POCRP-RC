Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 B_3 Z_101 Z_102 
Stack 1
B_1 A_10 A_9 A_7 
Stack 2
Z_103 B_6 Z_104 C_1 
Stack 3
B_2 B_9 C_9 C_7 
Stack 4
C_4 A_8 C_6 C_8 
Stack 5
B_8 A_6 Z_105 A_5 
Stack 6
Z_106 C_2 C_0 Z_107 
Stack 7
A_4 Z_108 A_0 Z_109 
Stack 8
Z_110 B_10 C_3 Z_111 
Stack 9
A_3 Z_112 B_0 A_2 
Stack 10
B_4 B_7 A_1 
Stack 11
B_5 C_5 Z_113 
