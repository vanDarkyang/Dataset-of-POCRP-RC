Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
F_2 Z_100 B_2 D_0 
Stack 1
Z_101 J_3 A_3 Z_102 
Stack 2
H_0 C_2 A_1 A_2 
Stack 3
H_1 Z_103 F_4 C_5 
Stack 4
Z_104 G_1 A_4 B_0 
Stack 5
B_1 D_6 Z_105 F_0 
Stack 6
Z_106 Z_107 H_4 C_1 
Stack 7
E_0 Z_108 H_2 E_4 
Stack 8
J_1 C_3 B_3 C_0 
Stack 9
D_1 D_7 A_0 Z_109 
Stack 10
B_4 J_0 Z_110 D_5 
Stack 11
H_5 Z_111 Z_112 Z_113 
Stack 12
Z_114 F_5 D_2 E_1 
Stack 13
F_1 G_0 E_2 J_2 
Stack 14
D_4 Z_115 Z_116 C_4 
Stack 15
D_3 Z_117 Z_118 E_3 
Stack 16
G_2 I_0 H_3 
Stack 17
Z_119 Z_120 F_3 
