Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
J_3 G_2 Z_100 N_3 D_0 G_3 
Stack 1
Z_101 Z_102 L_2 H_2 I_4 M_3 
Stack 2
Z_103 G_1 Z_104 K_1 Z_105 F_1 
Stack 3
H_6 F_4 J_2 L_3 F_0 N_1 
Stack 4
Z_106 Z_107 Z_108 I_6 H_5 
Stack 5
I_3 K_3 H_1 I_5 M_2 
Stack 6
B_1 O_0 I_2 I_1 G_4 
Stack 7
Z_109 F_2 Z_110 Z_111 Z_112 
Stack 8
H_4 I_7 Z_113 J_1 C_0 
Stack 9
Z_114 K_2 N_0 B_0 Z_115 
Stack 10
G_0 L_1 K_0 Z_116 J_4 
Stack 11
J_6 Z_117 Z_118 L_0 Z_119 
Stack 12
Z_120 H_3 Z_121 H_0 Z_122 
Stack 13
A_2 Z_123 C_3 D_2 J_0 
Stack 14
Z_124 D_1 E_0 F_3 Z_125 
Stack 15
J_5 Z_126 J_7 C_2 Z_127 
Stack 16
A_0 E_1 E_2 I_0 M_1 
Stack 17
C_1 A_1 Z_128 N_2 M_0 
