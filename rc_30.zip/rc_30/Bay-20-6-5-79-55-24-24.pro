Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 Z_101 C_1 C_10 
Stack 1
Z_102 D_6 B_1 D_7 
Stack 2
A_2 D_8 A_4 Z_103 
Stack 3
D_4 B_7 B_10 D_3 
Stack 4
C_4 C_6 D_1 Z_104 
Stack 5
E_3 Z_105 C_2 A_0 
Stack 6
B_11 A_1 C_8 Z_106 
Stack 7
E_1 A_6 C_0 C_7 
Stack 8
Z_107 B_12 A_3 Z_108 
Stack 9
Z_109 Z_110 Z_111 Z_112 
Stack 10
B_8 C_5 B_4 E_9 
Stack 11
B_3 E_4 C_3 Z_113 
Stack 12
Z_114 Z_115 D_11 B_2 
Stack 13
C_9 D_5 E_0 Z_116 
Stack 14
E_8 B_5 B_0 A_5 
Stack 15
E_2 Z_117 Z_118 E_10 
Stack 16
Z_119 Z_120 D_10 E_6 
Stack 17
B_9 B_6 E_7 Z_121 
Stack 18
Z_122 E_5 A_7 D_9 
Stack 19
D_2 Z_123 D_0 
