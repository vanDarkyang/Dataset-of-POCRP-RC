Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
G_1 B_3 Z_100 Z_101 Z_102 F_6 
Stack 1
C_1 F_7 G_8 Z_103 Z_104 Z_105 
Stack 2
D_9 E_5 G_0 C_5 Z_106 A_1 
Stack 3
E_0 Z_107 A_3 J_4 I_0 Z_108 
Stack 4
D_5 A_2 A_4 H_2 Z_109 Z_110 
Stack 5
E_4 Z_111 I_7 Z_112 C_2 
Stack 6
Z_113 Z_114 Z_115 Z_116 G_3 
Stack 7
B_2 C_4 Z_117 H_3 B_1 
Stack 8
D_6 B_4 Z_118 Z_119 F_4 
Stack 9
E_6 Z_120 E_8 H_6 Z_121 
Stack 10
Z_122 J_0 I_6 Z_123 J_2 
Stack 11
E_3 C_7 G_2 H_8 F_1 
Stack 12
F_3 G_6 Z_124 J_3 H_5 
Stack 13
D_7 Z_125 G_7 H_9 F_9 
Stack 14
H_1 G_5 J_6 D_3 D_0 
Stack 15
Z_126 A_0 I_3 G_4 H_4 
Stack 16
I_1 B_0 H_7 I_2 F_0 
Stack 17
Z_127 Z_128 E_1 H_0 F_8 
Stack 18
A_5 C_6 D_4 D_2 J_1 
Stack 19
Z_129 I_5 J_7 C_0 Z_130 
Stack 20
D_1 J_5 Z_131 Z_132 F_5 
Stack 21
Z_133 Z_134 I_4 D_8 C_3 
Stack 22
Z_135 F_2 E_2 H_10 E_7 
