Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 B_3 F_0 G_5 B_4 
Stack 1
D_5 C_1 Z_101 Z_102 D_0 
Stack 2
A_0 Z_103 B_0 I_2 Z_104 
Stack 3
B_1 Z_105 G_0 F_3 H_1 
Stack 4
Z_106 G_4 F_1 E_4 A_3 
Stack 5
I_0 D_4 C_0 I_3 E_1 
Stack 6
E_5 C_3 I_4 A_1 Z_107 
Stack 7
G_3 Z_108 Z_109 G_2 Z_110 
Stack 8
Z_111 A_2 E_2 J_1 Z_112 
Stack 9
D_2 Z_113 Z_114 Z_115 J_3 
Stack 10
I_1 Z_116 J_0 E_3 B_2 
Stack 11
C_4 Z_117 C_2 H_2 Z_118 
Stack 12
E_0 D_3 G_1 Z_119 F_2 
Stack 13
J_2 H_0 Z_120 D_1 H_3 
