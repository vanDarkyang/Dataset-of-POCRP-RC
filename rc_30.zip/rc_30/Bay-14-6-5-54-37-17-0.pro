Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_2 Z_100 Z_101 D_4 
Stack 1
Z_102 C_9 D_1 Z_103 
Stack 2
Z_104 B_3 E_1 A_8 
Stack 3
A_5 C_1 Z_105 E_3 
Stack 4
E_2 A_0 Z_106 A_1 
Stack 5
Z_107 Z_108 C_0 Z_109 
Stack 6
Z_110 A_9 E_0 Z_111 
Stack 7
C_6 C_4 E_5 Z_112 
Stack 8
C_2 A_2 Z_113 C_3 
Stack 9
A_4 C_8 B_1 Z_114 
Stack 10
Z_115 A_6 E_4 D_2 
Stack 11
D_6 A_7 Z_116 B_0 
Stack 12
D_0 D_5 C_5 
Stack 13
A_3 D_3 C_7 
