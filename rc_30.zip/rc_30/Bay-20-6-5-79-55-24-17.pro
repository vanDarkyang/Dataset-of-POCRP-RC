Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_5 C_7 Z_100 Z_101 
Stack 1
C_6 C_10 D_4 E_2 
Stack 2
B_3 E_6 Z_102 Z_103 
Stack 3
C_1 B_10 Z_104 B_8 
Stack 4
Z_105 D_3 D_10 E_0 
Stack 5
B_11 Z_106 C_3 Z_107 
Stack 6
A_1 E_5 Z_108 B_4 
Stack 7
B_2 C_2 E_1 C_8 
Stack 8
B_6 Z_109 Z_110 E_4 
Stack 9
Z_111 A_7 A_0 E_3 
Stack 10
Z_112 A_8 E_9 Z_113 
Stack 11
D_9 E_7 A_4 A_3 
Stack 12
D_0 Z_114 B_0 Z_115 
Stack 13
D_1 Z_116 Z_117 A_2 
Stack 14
Z_118 B_9 B_5 A_9 
Stack 15
A_10 E_8 C_5 Z_119 
Stack 16
D_6 Z_120 D_2 D_8 
Stack 17
B_7 Z_121 C_0 C_4 
Stack 18
B_1 Z_122 D_7 C_9 
Stack 19
D_5 A_6 Z_123 
