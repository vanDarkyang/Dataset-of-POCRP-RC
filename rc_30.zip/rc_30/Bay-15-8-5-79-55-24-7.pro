Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_2 D_7 D_5 B_4 D_10 Z_100 
Stack 1
A_5 D_0 Z_101 E_7 E_0 Z_102 
Stack 2
A_7 C_10 Z_103 A_8 Z_104 Z_105 
Stack 3
E_5 D_4 Z_106 A_0 E_8 A_3 
Stack 4
B_9 B_1 D_2 Z_107 E_6 
Stack 5
Z_108 C_7 D_6 E_3 B_0 
Stack 6
Z_109 C_3 E_9 D_9 Z_110 
Stack 7
D_8 B_6 C_0 A_6 A_1 
Stack 8
B_2 Z_111 C_8 D_3 Z_112 
Stack 9
B_5 B_7 A_4 Z_113 Z_114 
Stack 10
C_9 Z_115 D_11 C_4 E_4 
Stack 11
B_8 E_10 Z_116 Z_117 Z_118 
Stack 12
Z_119 B_3 B_10 B_11 Z_120 
Stack 13
E_1 E_2 C_5 Z_121 Z_122 
Stack 14
Z_123 C_1 C_6 C_2 D_1 
