Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 N_2 G_5 E_3 
Stack 1
C_2 H_0 A_0 Z_101 
Stack 2
Z_102 I_5 Z_103 C_1 
Stack 3
E_4 Z_104 O_1 Z_105 
Stack 4
C_0 H_1 J_2 H_3 
Stack 5
B_1 L_0 Z_106 E_0 
Stack 6
Z_107 H_6 Z_108 F_0 
Stack 7
H_7 Z_109 F_5 I_3 
Stack 8
F_2 E_1 F_1 F_3 
Stack 9
D_0 O_0 L_1 J_3 
Stack 10
I_6 H_2 Z_110 Z_111 
Stack 11
G_0 F_6 O_2 N_0 
Stack 12
Z_112 K_1 G_3 Z_113 
Stack 13
K_0 K_3 G_6 G_2 
Stack 14
Z_114 Z_115 L_2 Z_116 
Stack 15
N_1 Z_117 Z_118 F_4 
Stack 16
Z_119 H_4 M_2 I_0 
Stack 17
Z_120 K_5 Z_121 A_1 
Stack 18
L_3 K_4 J_1 Z_122 
Stack 19
G_4 Z_123 B_0 Z_124 
Stack 20
I_4 H_5 J_0 Z_125 
Stack 21
I_1 E_2 G_1 Z_126 
Stack 22
Z_127 K_2 M_0 
Stack 23
Z_128 M_1 I_2 
