Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
E_3 G_3 Z_100 Z_101 
Stack 1
G_0 J_2 Z_102 F_4 
Stack 2
Z_103 Z_104 G_2 O_1 
Stack 3
Z_105 G_5 I_6 L_1 
Stack 4
I_4 O_0 H_1 F_2 
Stack 5
Z_106 E_1 Z_107 Z_108 
Stack 6
N_0 L_2 E_2 J_3 
Stack 7
Z_109 D_0 Z_110 Z_111 
Stack 8
J_4 M_0 I_5 I_3 
Stack 9
K_5 Z_112 J_5 G_6 
Stack 10
B_0 F_1 J_7 H_0 
Stack 11
M_2 F_3 E_0 Z_113 
Stack 12
L_5 I_0 Z_114 Z_115 
Stack 13
K_3 Z_116 M_1 L_3 
Stack 14
I_7 K_0 A_2 K_1 
Stack 15
A_1 Z_117 Z_118 A_0 
Stack 16
D_2 Z_119 Z_120 I_2 
Stack 17
J_0 Z_121 D_3 Z_122 
Stack 18
L_0 C_0 Z_123 Z_124 
Stack 19
I_1 K_2 Z_125 N_1 
Stack 20
H_2 E_4 Z_126 G_1 
Stack 21
J_1 L_4 G_4 D_1 
Stack 22
Z_127 K_6 F_0 
Stack 23
K_4 Z_128 J_6 
