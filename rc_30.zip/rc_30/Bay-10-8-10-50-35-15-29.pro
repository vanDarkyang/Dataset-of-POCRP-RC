Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
E_1 F_2 I_0 Z_100 Z_101 
Stack 1
Z_102 G_4 A_0 Z_103 Z_104 
Stack 2
F_4 A_1 Z_105 J_0 Z_106 
Stack 3
D_1 F_6 B_1 G_2 F_0 
Stack 4
Z_107 Z_108 G_1 F_3 D_2 
Stack 5
C_2 G_3 I_2 H_2 Z_109 
Stack 6
F_1 D_5 H_0 H_1 G_0 
Stack 7
C_0 D_0 Z_110 Z_111 Z_112 
Stack 8
C_1 Z_113 F_5 I_1 B_0 
Stack 9
J_1 Z_114 D_4 E_0 D_3 
