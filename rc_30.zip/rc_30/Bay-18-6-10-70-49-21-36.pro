Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
E_2 F_5 Z_100 F_4 
Stack 1
H_0 J_3 C_4 D_6 
Stack 2
Z_101 E_6 D_1 C_1 
Stack 3
Z_102 Z_103 E_1 D_2 
Stack 4
Z_104 I_3 E_4 Z_105 
Stack 5
Z_106 Z_107 Z_108 Z_109 
Stack 6
F_1 I_1 A_0 G_1 
Stack 7
E_0 J_2 E_3 F_0 
Stack 8
F_6 Z_110 D_3 B_0 
Stack 9
C_3 Z_111 A_1 E_5 
Stack 10
B_1 Z_112 A_2 J_1 
Stack 11
J_0 D_5 H_3 Z_113 
Stack 12
Z_114 H_1 Z_115 A_3 
Stack 13
I_0 F_3 Z_116 F_2 
Stack 14
Z_117 H_4 D_0 B_2 
Stack 15
G_2 D_4 Z_118 Z_119 
Stack 16
G_0 C_0 H_2 
Stack 17
C_2 Z_120 I_2 
