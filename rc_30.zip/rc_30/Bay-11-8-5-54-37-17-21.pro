Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 A_5 B_5 Z_101 Z_102 
Stack 1
D_5 D_6 Z_103 C_1 E_7 
Stack 2
Z_104 C_0 B_2 D_0 E_1 
Stack 3
B_3 A_6 A_1 E_6 B_7 
Stack 4
E_2 E_4 Z_105 D_2 C_3 
Stack 5
B_4 D_1 D_3 Z_106 A_4 
Stack 6
Z_107 B_0 B_8 Z_108 C_4 
Stack 7
Z_109 Z_110 Z_111 Z_112 Z_113 
Stack 8
B_6 E_0 A_2 C_2 D_4 
Stack 9
B_1 Z_114 A_0 B_9 Z_115 
Stack 10
A_3 E_3 E_5 Z_116 
