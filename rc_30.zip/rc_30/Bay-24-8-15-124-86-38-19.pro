Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
M_1 F_6 E_3 Z_100 A_0 G_5 
Stack 1
K_1 Z_101 Z_102 Z_103 E_6 H_0 
Stack 2
D_2 E_0 Z_104 E_5 Z_105 I_2 
Stack 3
Z_106 J_2 A_4 H_2 Z_107 F_2 
Stack 4
I_5 G_3 J_0 N_0 K_3 
Stack 5
C_3 G_7 I_3 D_4 D_0 
Stack 6
H_4 K_4 M_2 I_9 L_0 
Stack 7
L_3 H_8 Z_108 Z_109 I_0 
Stack 8
G_6 H_7 J_4 F_5 Z_110 
Stack 9
Z_111 Z_112 L_2 Z_113 Z_114 
Stack 10
Z_115 J_5 Z_116 O_3 Z_117 
Stack 11
Z_118 F_3 O_0 L_1 G_8 
Stack 12
H_3 B_2 A_1 J_3 B_0 
Stack 13
I_7 H_5 H_1 I_8 N_1 
Stack 14
Z_119 Z_120 Z_121 Z_122 F_1 
Stack 15
I_6 H_6 Z_123 Z_124 E_1 
Stack 16
Z_125 C_1 Z_126 K_2 Z_127 
Stack 17
Z_128 G_4 I_1 K_0 M_0 
Stack 18
Z_129 Z_130 G_2 Z_131 C_0 
Stack 19
D_3 N_2 Z_132 F_0 C_2 
Stack 20
Z_133 Z_134 J_6 G_1 J_1 
Stack 21
G_0 E_2 Z_135 Z_136 A_2 
Stack 22
L_4 B_1 I_4 Z_137 E_4 
Stack 23
F_4 O_2 A_3 D_1 O_1 
