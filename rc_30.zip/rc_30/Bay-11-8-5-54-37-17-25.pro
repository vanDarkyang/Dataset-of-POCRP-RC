Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_0 E_1 Z_100 D_0 E_0 
Stack 1
Z_101 Z_102 D_4 B_2 Z_103 
Stack 2
Z_104 Z_105 A_6 Z_106 A_1 
Stack 3
A_4 D_7 Z_107 A_7 Z_108 
Stack 4
C_7 C_4 A_5 E_2 Z_109 
Stack 5
Z_110 D_3 B_1 A_2 Z_111 
Stack 6
Z_112 C_5 C_0 Z_113 E_3 
Stack 7
Z_114 A_0 E_4 B_4 C_6 
Stack 8
B_5 D_1 D_2 B_3 D_6 
Stack 9
B_6 C_3 Z_115 E_5 Z_116 
Stack 10
C_1 C_2 D_5 A_3 
