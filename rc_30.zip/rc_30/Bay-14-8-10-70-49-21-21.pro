Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
I_1 C_3 D_0 C_5 J_0 
Stack 1
D_1 H_3 G_4 Z_100 H_2 
Stack 2
E_1 Z_101 Z_102 E_5 I_2 
Stack 3
Z_103 F_1 C_2 C_4 Z_104 
Stack 4
Z_105 I_0 F_7 Z_106 H_1 
Stack 5
C_1 G_2 Z_107 J_1 D_3 
Stack 6
D_4 E_0 Z_108 J_2 D_2 
Stack 7
Z_109 B_0 C_0 Z_110 E_2 
Stack 8
Z_111 B_1 B_2 E_4 B_3 
Stack 9
H_4 F_6 G_1 J_3 A_0 
Stack 10
G_3 Z_112 F_2 F_0 Z_113 
Stack 11
Z_114 E_3 Z_115 Z_116 Z_117 
Stack 12
G_0 Z_118 A_1 H_0 F_4 
Stack 13
F_3 Z_119 A_2 F_5 Z_120 
