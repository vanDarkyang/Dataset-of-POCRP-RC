Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_1 B_2 C_8 A_1 D_5 
Stack 1
D_0 Z_100 A_0 Z_101 D_6 
Stack 2
E_1 E_4 C_4 Z_102 B_3 
Stack 3
Z_103 B_4 Z_104 A_2 B_6 
Stack 4
Z_105 Z_106 D_1 C_6 Z_107 
Stack 5
Z_108 C_0 B_0 D_4 C_7 
Stack 6
Z_109 Z_110 Z_111 E_0 E_2 
Stack 7
E_5 C_3 C_1 E_3 D_7 
Stack 8
D_2 C_5 C_2 Z_112 C_9 
Stack 9
B_5 E_6 Z_113 B_7 Z_114 
Stack 10
Z_115 Z_116 D_3 A_3 
