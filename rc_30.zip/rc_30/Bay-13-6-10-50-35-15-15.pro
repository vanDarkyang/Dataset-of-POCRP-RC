Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 Z_101 Z_102 H_3 
Stack 1
Z_103 Z_104 H_1 I_3 
Stack 2
D_1 Z_105 A_1 I_2 
Stack 3
Z_106 D_4 I_0 Z_107 
Stack 4
B_0 Z_108 Z_109 E_0 
Stack 5
Z_110 C_2 Z_111 D_3 
Stack 6
F_2 E_5 E_2 F_1 
Stack 7
F_3 J_0 Z_112 G_0 
Stack 8
D_0 G_1 H_2 D_2 
Stack 9
E_1 F_0 I_1 J_1 
Stack 10
G_3 H_0 G_2 Z_113 
Stack 11
A_0 C_0 E_4 
Stack 12
E_3 C_1 Z_114 
