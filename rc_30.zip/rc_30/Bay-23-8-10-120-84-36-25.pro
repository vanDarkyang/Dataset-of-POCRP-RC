Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
H_3 E_5 Z_100 C_2 I_0 I_1 
Stack 1
A_4 Z_101 Z_102 Z_103 I_2 B_7 
Stack 2
F_4 I_3 Z_104 B_9 Z_105 E_9 
Stack 3
D_0 E_6 Z_106 F_0 E_7 Z_107 
Stack 4
C_1 B_3 B_5 G_2 Z_108 Z_109 
Stack 5
H_9 Z_110 A_3 Z_111 I_8 
Stack 6
Z_112 D_1 E_3 A_8 H_2 
Stack 7
A_0 H_7 B_1 F_1 Z_113 
Stack 8
H_8 E_1 D_6 G_3 D_2 
Stack 9
F_3 C_0 F_5 H_5 G_7 
Stack 10
Z_114 J_0 B_4 G_0 G_4 
Stack 11
A_2 Z_115 F_2 A_6 D_7 
Stack 12
J_5 F_8 Z_116 Z_117 F_6 
Stack 13
I_6 B_0 F_7 Z_118 Z_119 
Stack 14
G_5 I_7 D_3 Z_120 G_6 
Stack 15
H_4 B_6 Z_121 B_2 Z_122 
Stack 16
D_4 A_7 J_4 H_1 I_4 
Stack 17
Z_123 E_2 J_2 E_4 A_5 
Stack 18
E_8 F_9 Z_124 Z_125 B_8 
Stack 19
Z_126 A_1 Z_127 Z_128 Z_129 
Stack 20
H_0 D_5 Z_130 I_5 H_6 
Stack 21
Z_131 G_1 Z_132 J_1 J_3 
Stack 22
C_3 Z_133 Z_134 E_0 Z_135 
