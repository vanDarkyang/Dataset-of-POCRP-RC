Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 D_2 D_7 A_3 C_0 
Stack 1
D_3 C_1 B_5 E_6 Z_101 
Stack 2
B_0 Z_102 B_2 Z_103 Z_104 
Stack 3
B_3 A_0 C_3 B_7 Z_105 
Stack 4
D_9 C_4 D_5 D_8 D_0 
Stack 5
A_2 E_1 C_5 B_4 D_1 
Stack 6
Z_106 E_2 D_6 B_9 D_4 
Stack 7
Z_107 Z_108 B_8 Z_109 Z_110 
Stack 8
E_5 Z_111 E_4 E_3 B_6 
Stack 9
Z_112 E_0 C_2 B_1 Z_113 
Stack 10
Z_114 Z_115 Z_116 A_1 
