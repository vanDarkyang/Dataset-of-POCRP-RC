Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
A_3 I_1 A_8 G_5 Z_100 G_2 
Stack 1
C_2 Z_101 Z_102 Z_103 F_6 H_7 
Stack 2
H_6 Z_104 Z_105 B_0 Z_106 E_6 
Stack 3
D_6 D_1 I_3 Z_107 J_6 J_4 
Stack 4
C_3 F_4 F_7 D_2 Z_108 Z_109 
Stack 5
F_3 Z_110 B_5 Z_111 I_4 
Stack 6
Z_112 B_2 D_7 B_6 Z_113 
Stack 7
Z_114 H_5 F_1 Z_115 I_5 
Stack 8
Z_116 E_0 A_2 Z_117 Z_118 
Stack 9
B_4 Z_119 I_0 J_2 D_4 
Stack 10
I_6 C_0 H_2 G_1 Z_120 
Stack 11
Z_121 D_3 Z_122 C_6 C_7 
Stack 12
A_4 J_1 D_5 D_0 A_0 
Stack 13
Z_123 E_4 C_8 C_5 Z_124 
Stack 14
Z_125 H_0 Z_126 A_7 G_8 
Stack 15
J_3 G_4 C_4 Z_127 I_7 
Stack 16
Z_128 A_6 I_2 C_9 B_3 
Stack 17
Z_129 E_3 Z_130 G_7 C_1 
Stack 18
A_1 H_4 F_0 Z_131 J_5 
Stack 19
E_1 B_1 I_8 H_1 H_3 
Stack 20
D_8 G_9 Z_132 F_2 Z_133 
Stack 21
E_2 J_0 Z_134 G_0 E_5 
Stack 22
A_5 F_5 G_3 G_6 Z_135 
