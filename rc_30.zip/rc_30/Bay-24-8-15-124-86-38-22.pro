Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
Z_100 J_0 I_3 D_3 O_1 H_6 
Stack 1
E_0 Z_101 B_0 Z_102 H_2 D_4 
Stack 2
B_2 N_5 L_2 O_4 A_0 B_1 
Stack 3
Z_103 H_8 M_3 K_4 Z_104 J_1 
Stack 4
G_0 Z_105 Z_106 Z_107 Z_108 
Stack 5
G_2 H_0 H_1 O_0 Z_109 
Stack 6
Z_110 N_4 H_3 L_0 N_1 
Stack 7
K_2 H_4 Z_111 G_4 J_2 
Stack 8
F_0 Z_112 J_4 C_3 Z_113 
Stack 9
Z_114 I_2 I_1 F_4 G_5 
Stack 10
H_5 N_0 L_4 F_6 C_4 
Stack 11
D_6 F_3 I_4 M_4 L_5 
Stack 12
C_0 G_10 Z_115 Z_116 J_3 
Stack 13
Z_117 G_8 G_3 I_0 L_3 
Stack 14
Z_118 D_5 K_0 Z_119 Z_120 
Stack 15
Z_121 Z_122 B_3 F_5 A_1 
Stack 16
Z_123 Z_124 Z_125 G_1 D_0 
Stack 17
O_3 Z_126 Z_127 N_2 G_7 
Stack 18
C_1 Z_128 M_0 Z_129 F_1 
Stack 19
G_9 E_1 C_2 F_2 Z_130 
Stack 20
C_5 K_1 M_1 Z_131 Z_132 
Stack 21
Z_133 B_4 D_2 N_3 Z_134 
Stack 22
H_7 Z_135 K_3 Z_136 M_2 
Stack 23
O_2 D_1 G_6 Z_137 L_1 
