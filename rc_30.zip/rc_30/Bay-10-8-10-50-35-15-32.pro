Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
C_1 B_0 H_3 Z_100 H_2 
Stack 1
B_2 Z_101 F_5 D_3 Z_102 
Stack 2
Z_103 D_0 E_1 E_0 G_2 
Stack 3
Z_104 F_1 Z_105 C_2 H_0 
Stack 4
F_0 J_1 F_2 G_0 E_3 
Stack 5
Z_106 I_0 D_2 Z_107 D_4 
Stack 6
G_1 C_0 E_4 Z_108 Z_109 
Stack 7
Z_110 B_3 D_1 H_1 B_1 
Stack 8
Z_111 F_4 Z_112 Z_113 F_3 
Stack 9
G_3 E_2 A_0 J_0 Z_114 
