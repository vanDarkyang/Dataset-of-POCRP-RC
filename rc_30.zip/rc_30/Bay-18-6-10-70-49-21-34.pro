Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
B_2 G_0 Z_100 B_4 
Stack 1
A_0 F_0 Z_101 D_4 
Stack 2
G_2 A_2 Z_102 B_1 
Stack 3
Z_103 H_1 G_5 I_2 
Stack 4
F_1 Z_104 Z_105 Z_106 
Stack 5
Z_107 G_3 E_4 E_1 
Stack 6
C_1 Z_108 F_4 Z_109 
Stack 7
A_1 E_3 I_1 J_1 
Stack 8
J_2 C_2 D_5 E_7 
Stack 9
G_1 I_3 D_3 Z_110 
Stack 10
Z_111 E_6 H_0 E_5 
Stack 11
Z_112 Z_113 F_2 Z_114 
Stack 12
G_4 H_4 Z_115 D_2 
Stack 13
Z_116 E_0 D_6 D_1 
Stack 14
H_2 B_0 H_3 Z_117 
Stack 15
D_0 B_3 Z_118 E_2 
Stack 16
F_3 J_0 Z_119 
Stack 17
Z_120 I_0 C_0 
