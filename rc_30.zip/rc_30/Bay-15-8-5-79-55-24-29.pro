Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_1 E_1 A_5 C_0 D_5 A_4 
Stack 1
Z_100 Z_101 D_2 E_5 A_7 Z_102 
Stack 2
B_9 B_1 C_9 Z_103 Z_104 C_1 
Stack 3
Z_105 B_7 Z_106 D_7 B_0 C_10 
Stack 4
Z_107 B_5 A_2 C_11 Z_108 
Stack 5
B_11 Z_109 B_8 Z_110 B_4 
Stack 6
A_6 Z_111 D_3 E_3 Z_112 
Stack 7
Z_113 C_5 E_6 D_6 D_9 
Stack 8
A_1 Z_114 C_6 E_10 Z_115 
Stack 9
A_8 D_8 E_8 D_0 B_2 
Stack 10
C_4 C_8 Z_116 B_10 E_9 
Stack 11
B_3 Z_117 D_4 E_7 A_0 
Stack 12
Z_118 Z_119 E_2 E_4 A_9 
Stack 13
Z_120 B_6 Z_121 Z_122 C_3 
Stack 14
C_7 A_3 E_0 Z_123 C_2 
