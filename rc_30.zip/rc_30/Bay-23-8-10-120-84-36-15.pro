Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
E_0 F_0 A_6 F_7 Z_100 Z_101 
Stack 1
B_4 Z_102 B_5 B_1 Z_103 A_5 
Stack 2
D_6 G_6 H_3 Z_104 C_0 Z_105 
Stack 3
H_7 Z_106 F_3 G_3 E_5 G_4 
Stack 4
J_2 I_3 D_3 Z_107 D_1 A_2 
Stack 5
D_5 Z_108 Z_109 D_4 Z_110 
Stack 6
Z_111 C_8 B_8 G_7 A_0 
Stack 7
Z_112 H_5 A_7 Z_113 H_8 
Stack 8
Z_114 I_1 Z_115 Z_116 Z_117 
Stack 9
H_4 Z_118 A_4 C_3 I_5 
Stack 10
Z_119 Z_120 Z_121 H_0 F_2 
Stack 11
Z_122 J_6 B_0 I_2 Z_123 
Stack 12
I_6 E_3 Z_124 Z_125 Z_126 
Stack 13
J_3 Z_127 A_1 C_6 G_5 
Stack 14
E_2 E_9 D_0 Z_128 G_1 
Stack 15
Z_129 Z_130 F_4 J_4 G_0 
Stack 16
E_4 F_5 E_1 C_2 J_5 
Stack 17
B_6 Z_131 H_1 J_0 E_6 
Stack 18
B_3 H_2 J_7 I_4 A_3 
Stack 19
Z_132 I_0 C_5 F_1 C_7 
Stack 20
Z_133 B_2 J_1 Z_134 E_8 
Stack 21
H_9 G_2 Z_135 D_2 C_1 
Stack 22
H_6 C_4 B_7 E_7 F_6 
