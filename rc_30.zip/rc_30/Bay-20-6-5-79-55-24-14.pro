Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 Z_101 Z_102 E_3 
Stack 1
B_4 Z_103 A_1 C_1 
Stack 2
Z_104 B_9 A_2 C_5 
Stack 3
Z_105 Z_106 C_2 B_0 
Stack 4
Z_107 A_11 B_12 C_7 
Stack 5
A_7 D_8 A_0 E_6 
Stack 6
D_10 C_6 B_5 A_10 
Stack 7
E_2 D_3 Z_108 B_8 
Stack 8
B_2 B_10 A_4 B_6 
Stack 9
Z_109 Z_110 A_5 C_3 
Stack 10
A_3 E_5 D_9 Z_111 
Stack 11
Z_112 D_5 D_6 Z_113 
Stack 12
D_2 C_4 Z_114 B_1 
Stack 13
Z_115 D_7 E_0 D_0 
Stack 14
Z_116 Z_117 E_1 B_3 
Stack 15
Z_118 C_8 A_6 Z_119 
Stack 16
A_8 C_9 D_1 E_4 
Stack 17
C_0 D_4 Z_120 A_9 
Stack 18
C_10 B_7 B_11 Z_121 
Stack 19
Z_122 D_11 Z_123 
