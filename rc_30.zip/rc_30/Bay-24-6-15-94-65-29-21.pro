Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
H_3 J_5 H_6 E_0 
Stack 1
Z_100 N_1 F_2 J_4 
Stack 2
J_2 K_2 Z_101 H_5 
Stack 3
C_0 Z_102 Z_103 F_1 
Stack 4
Z_104 Z_105 I_4 Z_106 
Stack 5
E_5 I_1 Z_107 Z_108 
Stack 6
I_0 I_2 F_6 Z_109 
Stack 7
D_3 O_0 A_1 O_1 
Stack 8
J_3 K_3 A_2 Z_110 
Stack 9
Z_111 F_3 Z_112 E_3 
Stack 10
Z_113 C_2 K_5 E_1 
Stack 11
D_2 B_0 J_0 K_0 
Stack 12
Z_114 F_0 I_3 N_0 
Stack 13
Z_115 Z_116 G_0 E_2 
Stack 14
F_4 A_0 Z_117 G_2 
Stack 15
D_4 Z_118 M_0 F_5 
Stack 16
B_1 Z_119 Z_120 H_4 
Stack 17
H_0 Z_121 C_1 G_3 
Stack 18
C_3 I_5 K_4 G_4 
Stack 19
Z_122 G_1 E_4 Z_123 
Stack 20
Z_124 Z_125 K_1 M_1 
Stack 21
D_0 Z_126 J_1 L_0 
Stack 22
Z_127 M_2 H_1 
Stack 23
Z_128 D_1 H_2 
