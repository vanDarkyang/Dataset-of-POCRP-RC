Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
C_3 C_4 J_1 Z_100 E_9 Z_101 
Stack 1
G_8 E_4 J_3 Z_102 D_5 E_3 
Stack 2
E_5 B_6 B_0 C_0 Z_103 J_4 
Stack 3
A_3 D_4 Z_104 E_8 H_5 G_5 
Stack 4
Z_105 I_2 C_5 Z_106 Z_107 Z_108 
Stack 5
J_0 G_0 A_2 B_3 F_4 
Stack 6
Z_109 E_2 Z_110 E_6 Z_111 
Stack 7
I_3 Z_112 D_6 C_6 E_1 
Stack 8
B_1 D_1 G_1 G_9 H_4 
Stack 9
H_1 B_5 D_2 Z_113 B_4 
Stack 10
Z_114 J_5 H_0 Z_115 H_3 
Stack 11
D_7 D_8 F_8 D_9 Z_116 
Stack 12
A_1 C_1 Z_117 E_7 Z_118 
Stack 13
B_7 Z_119 G_4 Z_120 E_11 
Stack 14
F_2 Z_121 E_0 C_7 G_7 
Stack 15
Z_122 F_5 Z_123 F_3 I_0 
Stack 16
Z_124 G_10 Z_125 F_0 D_3 
Stack 17
Z_126 B_2 Z_127 G_11 C_2 
Stack 18
Z_128 A_4 F_1 I_1 Z_129 
Stack 19
D_0 F_6 H_2 Z_130 A_0 
Stack 20
C_8 Z_131 J_2 E_12 Z_132 
Stack 21
G_6 E_10 F_9 Z_133 G_3 
Stack 22
G_2 Z_134 B_8 Z_135 F_7 
