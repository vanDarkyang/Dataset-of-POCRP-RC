Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
C_2 B_3 E_1 C_6 E_2 
Stack 1
Z_100 C_0 Z_101 C_1 Z_102 
Stack 2
Z_103 D_2 D_3 Z_104 C_3 
Stack 3
D_7 Z_105 C_4 A_1 A_2 
Stack 4
Z_106 D_0 Z_107 E_4 A_0 
Stack 5
A_6 Z_108 Z_109 D_4 Z_110 
Stack 6
B_2 Z_111 D_5 E_3 D_1 
Stack 7
A_4 E_5 Z_112 D_6 C_5 
Stack 8
Z_113 C_7 B_1 E_6 Z_114 
Stack 9
E_7 A_5 B_4 Z_115 A_3 
Stack 10
B_0 A_7 E_0 Z_116 
