Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 A_7 B_4 B_2 
Stack 1
B_3 B_7 Z_101 Z_102 
Stack 2
Z_103 C_1 A_6 D_5 
Stack 3
E_2 D_0 Z_104 E_0 
Stack 4
Z_105 C_5 A_5 Z_106 
Stack 5
D_6 A_3 Z_107 D_3 
Stack 6
Z_108 C_4 E_3 E_4 
Stack 7
A_0 Z_109 B_5 D_4 
Stack 8
C_7 C_6 D_1 A_2 
Stack 9
B_1 C_0 Z_110 A_4 
Stack 10
B_6 B_0 Z_111 Z_112 
Stack 11
C_2 C_3 Z_113 D_2 
Stack 12
B_8 Z_114 Z_115 
Stack 13
Z_116 E_1 A_1 
