Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
C_4 B_5 A_1 Z_100 
Stack 1
B_6 D_5 E_5 A_3 
Stack 2
C_1 C_2 D_2 Z_101 
Stack 3
Z_102 Z_103 C_8 Z_104 
Stack 4
B_0 E_4 B_4 D_0 
Stack 5
A_2 E_1 Z_105 D_8 
Stack 6
C_3 C_6 A_0 D_7 
Stack 7
Z_106 C_0 C_5 Z_107 
Stack 8
D_4 D_1 B_2 Z_108 
Stack 9
E_0 Z_109 D_3 Z_110 
Stack 10
E_3 Z_111 B_3 C_7 
Stack 11
Z_112 B_1 A_5 Z_113 
Stack 12
D_6 A_4 E_2 
Stack 13
Z_114 Z_115 Z_116 
