Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_4 Z_100 C_3 Z_101 
Stack 1
Z_102 B_8 B_1 A_1 
Stack 2
A_0 Z_103 C_0 Z_104 
Stack 3
B_3 B_2 A_7 Z_105 
Stack 4
B_7 A_4 A_10 B_4 
Stack 5
C_2 Z_106 A_6 Z_107 
Stack 6
A_9 C_8 A_2 Z_108 
Stack 7
B_6 Z_109 C_1 B_0 
Stack 8
Z_110 A_11 B_9 A_3 
Stack 9
B_5 A_5 A_8 Z_111 
Stack 10
C_6 Z_112 C_5 
Stack 11
C_7 Z_113 C_9 
