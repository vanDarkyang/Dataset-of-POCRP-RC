Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 F_3 Z_101 H_6 
Stack 1
B_3 J_2 I_1 Z_102 
Stack 2
G_1 B_4 Z_103 Z_104 
Stack 3
Z_105 D_2 J_1 Z_106 
Stack 4
Z_107 G_3 F_4 E_4 
Stack 5
Z_108 Z_109 Z_110 F_1 
Stack 6
D_0 E_0 Z_111 H_3 
Stack 7
Z_112 A_2 B_0 H_5 
Stack 8
F_5 H_4 F_2 C_0 
Stack 9
E_5 G_0 D_4 B_1 
Stack 10
H_0 C_1 D_1 E_2 
Stack 11
F_6 Z_113 A_0 H_1 
Stack 12
J_0 I_0 D_3 Z_114 
Stack 13
B_2 E_1 C_2 Z_115 
Stack 14
C_3 A_1 Z_116 Z_117 
Stack 15
I_2 E_3 F_0 Z_118 
Stack 16
Z_119 Z_120 H_2 
Stack 17
D_5 F_7 G_2 
