Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
E_5 E_4 Z_100 F_2 F_6 I_4 
Stack 1
Z_101 H_8 Z_102 Z_103 H_2 Z_104 
Stack 2
J_0 J_8 E_3 A_0 D_8 Z_105 
Stack 3
G_0 I_5 Z_106 Z_107 C_5 Z_108 
Stack 4
I_7 H_4 Z_109 Z_110 I_6 E_6 
Stack 5
Z_111 F_0 C_0 I_1 Z_112 
Stack 6
Z_113 D_4 Z_114 Z_115 Z_116 
Stack 7
E_1 B_2 A_3 H_3 D_3 
Stack 8
Z_117 Z_118 F_7 Z_119 D_1 
Stack 9
D_5 J_2 H_1 Z_120 D_7 
Stack 10
H_6 D_2 Z_121 J_7 Z_122 
Stack 11
B_3 B_4 C_6 G_3 B_1 
Stack 12
E_0 Z_123 I_0 D_0 B_7 
Stack 13
G_2 E_8 B_8 Z_124 Z_125 
Stack 14
B_5 J_5 Z_126 I_8 D_6 
Stack 15
A_4 B_0 I_3 Z_127 J_6 
Stack 16
Z_128 Z_129 E_7 G_1 G_4 
Stack 17
C_3 Z_130 F_5 A_1 C_7 
Stack 18
F_4 Z_131 G_6 Z_132 J_3 
Stack 19
A_2 E_2 H_5 C_4 Z_133 
Stack 20
C_2 B_6 G_5 F_1 J_9 
Stack 21
A_5 H_0 Z_134 F_3 J_4 
Stack 22
J_1 Z_135 C_1 H_7 I_2 
