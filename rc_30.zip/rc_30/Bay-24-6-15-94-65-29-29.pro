Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
H_5 I_3 Z_100 H_2 
Stack 1
Z_101 J_2 Z_102 G_7 
Stack 2
K_0 F_1 Z_103 D_1 
Stack 3
F_2 Z_104 I_1 Z_105 
Stack 4
H_3 Z_106 B_2 I_5 
Stack 5
Z_107 J_1 Z_108 Z_109 
Stack 6
Z_110 Z_111 A_0 M_3 
Stack 7
Z_112 G_4 B_0 C_1 
Stack 8
Z_113 N_0 H_0 G_5 
Stack 9
O_0 C_3 Z_114 E_1 
Stack 10
M_0 Z_115 J_0 E_0 
Stack 11
C_0 G_0 G_3 Z_116 
Stack 12
K_1 Z_117 B_1 L_3 
Stack 13
Z_118 G_1 G_6 Z_119 
Stack 14
L_1 H_1 F_3 F_0 
Stack 15
H_6 K_2 H_4 D_2 
Stack 16
E_3 Z_120 Z_121 I_0 
Stack 17
Z_122 Z_123 Z_124 E_2 
Stack 18
Z_125 Z_126 I_4 N_1 
Stack 19
G_2 D_3 M_2 Z_127 
Stack 20
H_8 E_4 C_2 D_0 
Stack 21
Z_128 I_2 I_6 J_3 
Stack 22
L_0 H_7 C_4 
Stack 23
O_1 M_1 L_2 
