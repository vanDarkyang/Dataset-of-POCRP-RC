Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_3 B_5 E_4 B_8 
Stack 1
Z_100 Z_101 C_1 A_4 
Stack 2
Z_102 C_0 Z_103 Z_104 
Stack 3
D_2 Z_105 E_7 D_4 
Stack 4
B_2 C_2 Z_106 B_4 
Stack 5
A_0 C_4 A_1 B_7 
Stack 6
B_0 Z_107 Z_108 Z_109 
Stack 7
E_5 Z_110 Z_111 Z_112 
Stack 8
D_1 C_7 A_2 E_1 
Stack 9
B_6 Z_113 C_5 D_5 
Stack 10
E_6 C_3 D_3 C_8 
Stack 11
Z_114 Z_115 E_0 C_6 
Stack 12
A_3 Z_116 E_2 
Stack 13
E_3 B_1 D_0 
