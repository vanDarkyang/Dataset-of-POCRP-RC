Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
E_1 Z_100 F_4 F_5 
Stack 1
Z_101 D_0 H_2 Z_102 
Stack 2
C_2 Z_103 G_1 G_2 
Stack 3
Z_104 G_4 A_1 C_1 
Stack 4
B_1 F_2 Z_105 Z_106 
Stack 5
F_1 H_1 J_2 B_3 
Stack 6
Z_107 B_0 Z_108 Z_109 
Stack 7
F_3 H_0 J_0 H_3 
Stack 8
Z_110 E_0 G_3 I_1 
Stack 9
F_6 I_0 Z_111 A_0 
Stack 10
Z_112 G_0 Z_113 B_2 
Stack 11
J_1 F_0 D_2 
Stack 12
D_1 C_0 Z_114 
