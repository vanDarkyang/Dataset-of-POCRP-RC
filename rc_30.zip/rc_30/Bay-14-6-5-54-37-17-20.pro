Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_3 Z_100 C_3 Z_101 
Stack 1
A_1 A_5 E_0 C_0 
Stack 2
A_3 B_7 D_6 D_2 
Stack 3
E_2 D_7 D_0 C_2 
Stack 4
B_3 C_6 E_4 Z_102 
Stack 5
C_7 B_6 D_8 Z_103 
Stack 6
B_4 C_1 Z_104 D_4 
Stack 7
Z_105 Z_106 A_2 D_5 
Stack 8
B_5 B_1 Z_107 C_4 
Stack 9
Z_108 Z_109 Z_110 A_0 
Stack 10
C_5 Z_111 A_4 Z_112 
Stack 11
Z_113 E_5 D_3 Z_114 
Stack 12
D_1 Z_115 E_1 
Stack 13
B_0 B_2 Z_116 
