Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
E_2 I_1 G_0 H_1 J_0 
Stack 1
Z_100 Z_101 D_0 F_0 E_0 
Stack 2
G_1 F_1 Z_102 B_1 D_1 
Stack 3
Z_103 Z_104 C_0 G_3 Z_105 
Stack 4
Z_106 Z_107 A_0 C_2 A_1 
Stack 5
F_6 Z_108 E_3 J_1 H_2 
Stack 6
Z_109 A_2 B_0 F_2 E_1 
Stack 7
Z_110 Z_111 H_3 F_4 F_3 
Stack 8
F_5 G_2 H_0 D_2 Z_112 
Stack 9
Z_113 B_2 C_1 I_0 Z_114 
