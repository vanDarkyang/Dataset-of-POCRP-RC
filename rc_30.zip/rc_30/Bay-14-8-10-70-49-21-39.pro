Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
F_5 Z_100 Z_101 F_2 C_3 
Stack 1
A_2 G_6 B_3 Z_102 E_0 
Stack 2
B_1 G_4 A_3 J_2 I_0 
Stack 3
D_4 Z_103 Z_104 G_5 J_4 
Stack 4
E_1 D_1 F_3 F_1 B_2 
Stack 5
D_0 D_3 C_2 F_4 C_4 
Stack 6
C_0 Z_105 E_2 G_1 Z_106 
Stack 7
G_7 Z_107 D_2 H_0 C_5 
Stack 8
I_1 G_2 Z_108 E_3 Z_109 
Stack 9
C_1 F_0 Z_110 I_2 G_0 
Stack 10
Z_111 Z_112 Z_113 B_4 Z_114 
Stack 11
Z_115 J_1 A_1 Z_116 J_3 
Stack 12
A_4 A_0 J_0 Z_117 B_0 
Stack 13
Z_118 G_3 Z_119 D_5 Z_120 
