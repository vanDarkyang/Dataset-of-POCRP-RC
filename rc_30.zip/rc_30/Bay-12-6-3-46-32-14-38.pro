Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
C_5 Z_100 A_4 B_4 
Stack 1
C_6 B_0 B_1 Z_101 
Stack 2
A_3 Z_102 A_6 Z_103 
Stack 3
Z_104 C_1 A_10 B_3 
Stack 4
Z_105 C_4 A_5 Z_106 
Stack 5
A_7 C_2 C_3 A_1 
Stack 6
B_7 B_2 Z_107 B_5 
Stack 7
Z_108 Z_109 C_0 B_9 
Stack 8
Z_110 A_8 A_0 A_2 
Stack 9
Z_111 C_7 Z_112 C_10 
Stack 10
B_8 C_8 C_9 
Stack 11
Z_113 B_6 A_9 
