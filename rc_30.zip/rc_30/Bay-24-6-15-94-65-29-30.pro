Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
N_2 I_1 Z_100 N_1 
Stack 1
Z_101 J_3 Z_102 E_3 
Stack 2
L_0 Z_103 J_4 M_0 
Stack 3
J_1 M_3 Z_104 I_7 
Stack 4
E_4 Z_105 Z_106 E_2 
Stack 5
G_1 G_4 Z_107 Z_108 
Stack 6
Z_109 I_0 C_0 H_3 
Stack 7
O_0 D_0 M_1 N_0 
Stack 8
C_3 H_1 G_0 Z_110 
Stack 9
Z_111 I_2 H_0 O_1 
Stack 10
Z_112 M_2 J_2 H_4 
Stack 11
G_3 F_3 Z_113 Z_114 
Stack 12
I_6 Z_115 Z_116 H_2 
Stack 13
G_2 I_5 Z_117 Z_118 
Stack 14
H_6 O_2 E_0 B_0 
Stack 15
B_3 D_3 Z_119 D_2 
Stack 16
K_1 J_0 I_4 C_1 
Stack 17
D_1 F_6 I_3 K_2 
Stack 18
Z_120 F_5 Z_121 F_2 
Stack 19
H_5 F_4 Z_122 A_0 
Stack 20
B_1 Z_123 Z_124 F_1 
Stack 21
Z_125 Z_126 C_2 L_1 
Stack 22
B_2 Z_127 Z_128 
Stack 23
E_1 F_0 K_0 
