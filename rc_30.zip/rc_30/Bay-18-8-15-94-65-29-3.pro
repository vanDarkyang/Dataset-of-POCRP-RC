Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 Z_101 D_0 H_5 E_4 G_1 
Stack 1
Z_102 H_3 H_4 Z_103 M_3 C_1 
Stack 2
Z_104 L_2 Z_105 L_1 Z_106 H_0 
Stack 3
E_5 B_2 Z_107 K_0 M_1 B_0 
Stack 4
C_3 F_2 K_2 O_2 Z_108 
Stack 5
Z_109 Z_110 N_0 D_1 J_5 
Stack 6
Z_111 B_1 I_7 J_0 E_2 
Stack 7
Z_112 M_0 K_1 L_3 Z_113 
Stack 8
O_1 F_0 Z_114 Z_115 Z_116 
Stack 9
Z_117 Z_118 I_2 K_5 I_5 
Stack 10
J_4 I_0 I_3 I_8 F_3 
Stack 11
K_6 E_0 I_6 Z_119 I_4 
Stack 12
E_3 Z_120 L_0 I_1 E_1 
Stack 13
A_0 Z_121 J_1 Z_122 H_1 
Stack 14
Z_123 J_3 A_1 F_1 H_2 
Stack 15
G_2 M_2 Z_124 O_0 Z_125 
Stack 16
Z_126 Z_127 J_2 A_2 C_0 
Stack 17
Z_128 K_4 C_2 K_3 G_0 
