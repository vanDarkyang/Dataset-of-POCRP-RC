Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 G_1 F_4 H_4 
Stack 1
E_2 Z_101 F_0 Z_102 
Stack 2
F_1 I_0 Z_103 D_0 
Stack 3
E_3 F_5 E_4 H_2 
Stack 4
Z_104 Z_105 H_1 D_1 
Stack 5
C_1 D_3 A_0 J_0 
Stack 6
Z_106 Z_107 E_0 F_3 
Stack 7
Z_108 C_0 H_3 I_2 
Stack 8
F_2 Z_109 Z_110 Z_111 
Stack 9
H_0 I_1 Z_112 Z_113 
Stack 10
J_2 E_5 E_1 J_1 
Stack 11
B_1 Z_114 D_2 
Stack 12
G_0 B_0 E_6 
