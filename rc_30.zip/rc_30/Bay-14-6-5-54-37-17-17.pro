Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 A_2 Z_101 E_0 
Stack 1
Z_102 D_0 B_3 Z_103 
Stack 2
C_6 D_1 Z_104 Z_105 
Stack 3
C_1 C_4 Z_106 Z_107 
Stack 4
E_1 E_3 B_2 A_0 
Stack 5
D_2 Z_108 A_4 C_3 
Stack 6
E_4 Z_109 D_5 E_2 
Stack 7
D_3 Z_110 B_1 A_5 
Stack 8
Z_111 Z_112 B_0 E_8 
Stack 9
E_6 E_5 Z_113 A_3 
Stack 10
C_7 D_6 E_7 C_0 
Stack 11
Z_114 B_5 D_4 Z_115 
Stack 12
C_2 Z_116 A_1 
Stack 13
B_4 C_5 A_6 
