Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
F_4 E_1 D_1 H_2 
Stack 1
Z_100 Z_101 E_2 A_0 
Stack 2
C_3 Z_102 Z_103 Z_104 
Stack 3
G_0 F_0 Z_105 B_1 
Stack 4
Z_106 I_1 Z_107 D_3 
Stack 5
G_1 F_3 E_0 B_0 
Stack 6
H_0 Z_108 I_0 Z_109 
Stack 7
J_0 C_0 Z_110 Z_111 
Stack 8
C_2 E_3 D_2 A_1 
Stack 9
F_1 B_2 D_0 C_1 
Stack 10
Z_112 G_2 Z_113 F_2 
Stack 11
H_3 H_1 G_4 
Stack 12
G_3 Z_114 J_1 
