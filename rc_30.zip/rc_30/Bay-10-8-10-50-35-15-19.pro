Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 Z_101 D_1 F_1 F_2 
Stack 1
H_2 I_0 Z_102 F_5 D_3 
Stack 2
Z_103 Z_104 H_0 F_4 Z_105 
Stack 3
Z_106 H_1 G_0 Z_107 J_0 
Stack 4
B_0 F_3 Z_108 G_3 G_5 
Stack 5
H_3 E_0 Z_109 G_4 A_0 
Stack 6
E_1 E_2 D_0 G_1 D_4 
Stack 7
C_0 D_2 Z_110 Z_111 Z_112 
Stack 8
B_1 Z_113 I_1 C_2 C_1 
Stack 9
G_2 Z_114 J_1 F_0 E_3 
