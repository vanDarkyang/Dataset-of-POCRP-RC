Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
H_0 Z_100 A_0 I_0 
Stack 1
E_3 E_0 Z_101 C_0 
Stack 2
Z_102 F_1 Z_103 Z_104 
Stack 3
Z_105 I_2 G_1 Z_106 
Stack 4
F_3 E_1 B_0 F_2 
Stack 5
Z_107 A_1 Z_108 Z_109 
Stack 6
C_1 Z_110 I_1 Z_111 
Stack 7
D_0 F_0 I_3 A_2 
Stack 8
C_2 G_2 J_1 F_4 
Stack 9
Z_112 Z_113 H_2 D_1 
Stack 10
E_4 G_3 B_2 C_3 
Stack 11
H_1 E_2 J_0 
Stack 12
B_1 Z_114 G_0 
