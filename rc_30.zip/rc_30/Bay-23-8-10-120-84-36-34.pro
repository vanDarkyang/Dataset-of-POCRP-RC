Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 J_3 E_0 Z_101 F_3 Z_102 
Stack 1
J_6 Z_103 I_3 E_5 B_6 Z_104 
Stack 2
B_5 B_2 Z_105 E_6 I_6 J_8 
Stack 3
B_1 Z_106 D_7 Z_107 Z_108 G_5 
Stack 4
Z_109 G_3 C_3 G_1 E_7 D_6 
Stack 5
D_1 C_1 Z_110 G_4 Z_111 
Stack 6
E_3 D_4 C_5 C_7 D_0 
Stack 7
E_1 Z_112 H_5 J_0 D_2 
Stack 8
A_4 Z_113 Z_114 H_0 H_4 
Stack 9
Z_115 A_2 E_8 C_9 C_2 
Stack 10
H_2 G_0 F_6 C_8 H_1 
Stack 11
Z_116 Z_117 E_4 D_3 C_6 
Stack 12
E_9 Z_118 I_4 C_10 H_3 
Stack 13
H_7 C_0 A_0 I_0 J_5 
Stack 14
Z_119 Z_120 Z_121 Z_122 Z_123 
Stack 15
Z_124 C_4 F_0 J_4 J_2 
Stack 16
J_7 Z_125 Z_126 I_5 Z_127 
Stack 17
F_5 E_2 Z_128 G_2 F_4 
Stack 18
Z_129 A_5 I_1 A_3 B_4 
Stack 19
C_11 A_1 Z_130 B_3 Z_131 
Stack 20
Z_132 B_0 I_7 J_1 H_6 
Stack 21
G_7 Z_133 H_8 F_2 G_6 
Stack 22
D_5 Z_134 F_1 Z_135 I_2 
