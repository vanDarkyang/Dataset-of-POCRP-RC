Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 D_7 Z_101 Z_102 
Stack 1
A_6 C_2 A_1 Z_103 
Stack 2
Z_104 C_0 Z_105 B_6 
Stack 3
D_5 A_2 E_2 C_4 
Stack 4
A_0 C_5 A_4 B_4 
Stack 5
Z_106 C_1 Z_107 D_8 
Stack 6
Z_108 A_7 E_0 B_0 
Stack 7
E_4 D_2 E_3 E_5 
Stack 8
Z_109 D_3 B_2 A_5 
Stack 9
Z_110 D_0 Z_111 D_6 
Stack 10
Z_112 D_4 Z_113 D_1 
Stack 11
Z_114 B_3 C_6 C_3 
Stack 12
Z_115 B_5 E_1 
Stack 13
Z_116 B_1 A_3 
