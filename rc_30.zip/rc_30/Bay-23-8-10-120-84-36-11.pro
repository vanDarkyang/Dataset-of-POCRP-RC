Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
J_2 Z_100 D_9 B_7 F_1 B_4 
Stack 1
B_2 Z_101 Z_102 G_2 E_1 Z_103 
Stack 2
E_6 A_4 G_4 G_6 Z_104 Z_105 
Stack 3
Z_106 C_1 A_0 G_1 C_0 Z_107 
Stack 4
Z_108 F_3 Z_109 E_3 I_6 G_7 
Stack 5
Z_110 D_1 Z_111 B_1 H_8 
Stack 6
B_9 D_3 C_7 D_5 J_0 
Stack 7
D_0 B_0 Z_112 Z_113 C_6 
Stack 8
Z_114 Z_115 I_2 Z_116 F_4 
Stack 9
B_5 J_4 J_7 H_0 J_1 
Stack 10
Z_117 D_7 D_2 Z_118 Z_119 
Stack 11
F_2 Z_120 Z_121 B_8 H_6 
Stack 12
E_4 D_8 C_8 J_3 F_5 
Stack 13
I_0 H_4 Z_122 Z_123 D_4 
Stack 14
I_5 J_6 D_6 A_2 A_5 
Stack 15
I_3 F_0 C_5 A_3 G_5 
Stack 16
Z_124 I_1 Z_125 Z_126 B_3 
Stack 17
Z_127 G_3 G_0 G_8 C_4 
Stack 18
Z_128 Z_129 B_6 E_5 H_2 
Stack 19
C_2 I_7 E_0 F_6 Z_130 
Stack 20
J_5 Z_131 C_3 Z_132 Z_133 
Stack 21
H_5 Z_134 H_7 H_3 H_1 
Stack 22
I_4 E_2 Z_135 F_7 A_1 
