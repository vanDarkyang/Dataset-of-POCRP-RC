Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_2 Z_100 D_0 G_2 Z_101 
Stack 1
A_3 J_2 D_1 A_0 H_5 
Stack 2
Z_102 F_3 B_0 Z_103 I_0 
Stack 3
C_3 B_1 F_1 A_2 F_6 
Stack 4
Z_104 I_2 Z_105 Z_106 J_0 
Stack 5
Z_107 G_5 G_1 Z_108 Z_109 
Stack 6
C_0 F_0 G_4 F_5 Z_110 
Stack 7
H_0 H_2 H_3 Z_111 H_1 
Stack 8
Z_112 D_5 J_3 D_4 Z_113 
Stack 9
C_2 H_4 G_3 G_0 F_2 
Stack 10
Z_114 E_0 D_3 E_2 C_1 
Stack 11
Z_115 Z_116 E_3 Z_117 D_6 
Stack 12
J_1 Z_118 C_4 E_4 I_1 
Stack 13
E_1 Z_119 F_4 Z_120 A_1 
