Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_11 A_1 C_0 B_9 
Stack 1
Z_100 C_10 Z_101 Z_102 
Stack 2
Z_103 Z_104 D_4 E_1 
Stack 3
B_1 Z_105 C_2 E_8 
Stack 4
E_3 C_6 D_3 Z_106 
Stack 5
B_5 Z_107 A_4 A_7 
Stack 6
Z_108 E_9 B_6 D_0 
Stack 7
Z_109 B_4 A_0 D_8 
Stack 8
C_4 A_3 Z_110 A_5 
Stack 9
Z_111 C_8 Z_112 Z_113 
Stack 10
Z_114 Z_115 A_2 D_2 
Stack 11
E_7 C_7 D_1 C_1 
Stack 12
D_5 C_9 C_5 Z_116 
Stack 13
A_9 E_5 D_10 D_9 
Stack 14
Z_117 D_6 B_3 Z_118 
Stack 15
B_7 D_11 Z_119 B_8 
Stack 16
E_2 E_6 Z_120 A_8 
Stack 17
E_10 B_0 D_7 E_0 
Stack 18
A_6 C_3 E_4 Z_121 
Stack 19
Z_122 B_2 Z_123 
