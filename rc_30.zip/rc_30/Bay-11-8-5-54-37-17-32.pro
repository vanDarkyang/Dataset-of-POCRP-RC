Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_2 Z_100 Z_101 C_6 A_1 
Stack 1
B_1 D_9 A_2 Z_102 D_4 
Stack 2
Z_103 B_4 Z_104 E_0 C_5 
Stack 3
C_0 D_0 E_1 C_2 D_7 
Stack 4
Z_105 B_6 A_3 D_6 B_5 
Stack 5
Z_106 Z_107 E_2 A_0 B_2 
Stack 6
Z_108 Z_109 E_5 D_5 E_6 
Stack 7
D_1 E_4 C_3 E_3 C_1 
Stack 8
Z_110 Z_111 Z_112 Z_113 Z_114 
Stack 9
Z_115 D_8 Z_116 C_7 D_3 
Stack 10
C_4 B_0 B_3 A_4 
