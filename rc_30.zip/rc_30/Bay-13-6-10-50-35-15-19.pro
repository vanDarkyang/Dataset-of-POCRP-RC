Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 E_2 I_2 Z_101 
Stack 1
E_3 Z_102 Z_103 B_1 
Stack 2
Z_104 Z_105 E_4 F_5 
Stack 3
B_0 Z_106 Z_107 J_1 
Stack 4
Z_108 Z_109 E_0 E_1 
Stack 5
F_4 G_4 D_2 D_1 
Stack 6
H_2 F_0 G_3 E_5 
Stack 7
H_0 I_0 A_1 C_0 
Stack 8
A_0 F_1 J_0 C_1 
Stack 9
F_3 G_2 G_1 H_1 
Stack 10
D_0 Z_110 Z_111 Z_112 
Stack 11
F_2 Z_113 Z_114 
Stack 12
I_1 G_0 D_3 
