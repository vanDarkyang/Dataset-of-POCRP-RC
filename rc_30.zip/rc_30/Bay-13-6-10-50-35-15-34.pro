Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 Z_101 H_1 Z_102 
Stack 1
Z_103 D_2 D_3 E_1 
Stack 2
Z_104 Z_105 C_3 F_2 
Stack 3
J_0 H_2 I_1 F_1 
Stack 4
E_0 A_0 Z_106 Z_107 
Stack 5
G_2 C_1 B_0 Z_108 
Stack 6
D_4 Z_109 G_1 G_3 
Stack 7
Z_110 D_0 Z_111 I_0 
Stack 8
H_0 I_2 F_0 H_3 
Stack 9
Z_112 C_0 D_1 J_2 
Stack 10
Z_113 E_3 G_0 Z_114 
Stack 11
J_1 E_2 C_4 
Stack 12
F_3 A_1 C_2 
