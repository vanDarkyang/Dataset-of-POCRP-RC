Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_0 Z_100 Z_101 Z_102 
Stack 1
B_1 B_3 Z_103 B_6 
Stack 2
Z_104 A_4 C_0 Z_105 
Stack 3
Z_106 Z_107 C_2 C_7 
Stack 4
B_2 A_5 Z_108 C_8 
Stack 5
Z_109 Z_110 C_9 A_6 
Stack 6
A_2 B_9 A_1 C_3 
Stack 7
A_11 B_8 C_1 A_7 
Stack 8
C_6 C_4 C_5 A_8 
Stack 9
Z_111 A_3 B_4 A_0 
Stack 10
B_7 A_9 A_10 
Stack 11
Z_112 B_5 Z_113 
