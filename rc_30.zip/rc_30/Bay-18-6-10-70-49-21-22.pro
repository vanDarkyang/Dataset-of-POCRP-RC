Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
G_0 D_2 I_1 F_4 
Stack 1
D_4 E_1 Z_100 A_1 
Stack 2
Z_101 F_3 F_5 B_1 
Stack 3
J_1 H_2 B_0 E_5 
Stack 4
F_0 D_6 Z_102 Z_103 
Stack 5
F_6 Z_104 G_1 C_0 
Stack 6
D_3 H_1 I_2 C_2 
Stack 7
Z_105 D_0 Z_106 E_7 
Stack 8
B_2 E_6 Z_107 E_2 
Stack 9
Z_108 F_1 I_3 Z_109 
Stack 10
E_3 J_0 G_4 J_2 
Stack 11
G_2 G_3 D_1 I_4 
Stack 12
A_2 Z_110 Z_111 A_0 
Stack 13
Z_112 E_0 D_5 E_4 
Stack 14
Z_113 H_0 G_5 I_0 
Stack 15
Z_114 Z_115 Z_116 Z_117 
Stack 16
C_1 Z_118 F_2 
Stack 17
Z_119 H_3 Z_120 
