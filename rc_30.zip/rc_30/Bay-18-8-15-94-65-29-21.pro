Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 Z_101 Z_102 F_5 E_0 G_7 
Stack 1
G_4 L_1 H_5 A_0 Z_103 L_3 
Stack 2
J_0 B_3 Z_104 Z_105 H_7 M_2 
Stack 3
C_0 D_0 L_4 G_3 F_0 L_2 
Stack 4
N_0 Z_106 Z_107 K_2 C_1 
Stack 5
Z_108 I_2 J_2 Z_109 L_0 
Stack 6
I_0 J_3 Z_110 Z_111 E_3 
Stack 7
D_2 N_2 G_2 G_0 O_1 
Stack 8
Z_112 Z_113 B_2 J_1 G_8 
Stack 9
F_2 M_0 H_4 M_1 E_1 
Stack 10
Z_114 Z_115 M_3 Z_116 Z_117 
Stack 11
Z_118 I_1 D_1 Z_119 K_0 
Stack 12
Z_120 I_3 Z_121 Z_122 N_1 
Stack 13
M_4 O_0 F_1 E_2 Z_123 
Stack 14
F_3 Z_124 Z_125 K_1 G_5 
Stack 15
D_3 Z_126 H_2 Z_127 F_4 
Stack 16
B_1 C_2 Z_128 H_1 H_6 
Stack 17
H_0 B_0 G_1 H_3 G_6 
