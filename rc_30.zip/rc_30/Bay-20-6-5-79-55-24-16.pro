Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_8 D_2 A_2 Z_100 
Stack 1
Z_101 D_7 B_6 C_4 
Stack 2
Z_102 Z_103 B_7 A_8 
Stack 3
D_8 D_3 A_0 A_5 
Stack 4
A_7 Z_104 Z_105 D_11 
Stack 5
B_0 D_9 E_3 D_6 
Stack 6
C_5 Z_106 E_9 C_0 
Stack 7
Z_107 D_5 Z_108 Z_109 
Stack 8
D_0 B_2 Z_110 C_7 
Stack 9
B_4 C_3 A_9 D_1 
Stack 10
Z_111 E_0 D_4 C_11 
Stack 11
E_1 E_6 A_3 Z_112 
Stack 12
A_6 C_6 E_2 B_3 
Stack 13
Z_113 C_2 A_4 Z_114 
Stack 14
Z_115 B_5 D_10 A_1 
Stack 15
Z_116 Z_117 E_7 Z_118 
Stack 16
Z_119 B_1 C_10 D_12 
Stack 17
Z_120 Z_121 E_4 E_8 
Stack 18
C_1 Z_122 E_10 Z_123 
Stack 19
D_13 C_9 E_5 
