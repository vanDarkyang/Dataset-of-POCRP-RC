Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
G_3 I_1 D_2 Z_100 J_0 
Stack 1
A_0 E_4 C_2 H_6 Z_101 
Stack 2
D_3 F_1 E_3 D_1 E_1 
Stack 3
F_2 Z_102 Z_103 Z_104 J_1 
Stack 4
H_4 Z_105 Z_106 Z_107 D_4 
Stack 5
F_3 Z_108 F_4 I_2 H_0 
Stack 6
Z_109 A_1 C_1 F_5 E_6 
Stack 7
G_1 C_0 E_5 H_2 I_0 
Stack 8
Z_110 B_0 H_5 I_3 Z_111 
Stack 9
B_1 H_3 G_4 Z_112 E_2 
Stack 10
Z_113 Z_114 F_6 F_0 Z_115 
Stack 11
Z_116 Z_117 G_2 Z_118 D_5 
Stack 12
E_0 F_7 J_2 Z_119 G_0 
Stack 13
D_0 I_4 Z_120 C_3 H_1 
