Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 E_1 Z_101 Z_102 C_1 
Stack 1
B_0 D_2 Z_103 F_6 I_0 
Stack 2
J_1 I_1 J_0 F_2 E_2 
Stack 3
H_0 Z_104 E_3 D_1 G_2 
Stack 4
D_0 E_0 F_1 Z_105 A_1 
Stack 5
I_3 B_2 A_0 Z_106 F_0 
Stack 6
F_5 G_1 G_0 Z_107 B_1 
Stack 7
Z_108 D_3 Z_109 Z_110 Z_111 
Stack 8
Z_112 F_3 F_4 I_2 Z_113 
Stack 9
H_1 C_0 H_2 H_3 Z_114 
