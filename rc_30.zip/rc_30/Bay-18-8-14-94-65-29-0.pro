Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
14
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
C_3 Z_100 M_1 Z_101 L_2 F_5 
Stack 1
I_4 M_0 I_1 K_3 I_6 Z_102 
Stack 2
J_2 G_1 N_1 J_3 L_0 M_2 
Stack 3
E_3 Z_103 J_1 F_3 H_2 Z_104 
Stack 4
K_4 Z_105 C_4 G_0 D_2 
Stack 5
Z_106 E_1 C_0 H_6 K_2 
Stack 6
Z_107 Z_108 Z_109 J_5 D_0 
Stack 7
Z_110 H_3 Z_111 C_1 E_0 
Stack 8
D_1 L_1 A_0 I_2 I_3 
Stack 9
J_0 H_0 J_4 Z_112 F_1 
Stack 10
K_5 I_0 K_1 Z_113 Z_114 
Stack 11
Z_115 K_0 Z_116 B_2 F_2 
Stack 12
H_7 Z_117 F_4 H_5 H_4 
Stack 13
Z_118 E_4 Z_119 Z_120 Z_121 
Stack 14
B_0 I_5 Z_122 L_3 Z_123 
Stack 15
E_2 B_1 F_0 G_2 Z_124 
Stack 16
H_1 C_2 Z_125 N_0 B_3 
Stack 17
Z_126 Z_127 L_4 Z_128 A_1 
