Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
C_2 F_1 D_4 Z_100 Z_101 
Stack 1
C_1 G_0 Z_102 B_5 B_1 
Stack 2
D_0 Z_103 H_1 Z_104 F_4 
Stack 3
F_2 C_5 Z_105 G_3 A_0 
Stack 4
E_0 Z_106 J_0 B_2 B_0 
Stack 5
Z_107 H_3 A_1 E_4 Z_108 
Stack 6
J_1 F_0 F_3 H_0 J_2 
Stack 7
I_1 D_3 D_2 E_3 E_5 
Stack 8
E_2 Z_109 E_1 Z_110 G_2 
Stack 9
B_3 Z_111 J_3 C_3 I_0 
Stack 10
E_6 H_4 Z_112 I_2 Z_113 
Stack 11
B_4 Z_114 Z_115 Z_116 D_1 
Stack 12
A_2 D_5 Z_117 H_2 Z_118 
Stack 13
C_4 Z_119 Z_120 C_0 G_1 
