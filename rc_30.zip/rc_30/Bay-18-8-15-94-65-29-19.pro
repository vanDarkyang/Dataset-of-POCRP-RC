Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
N_1 E_0 Z_100 K_2 J_0 J_1 
Stack 1
C_3 M_0 Z_101 H_5 K_5 F_2 
Stack 2
Z_102 H_0 D_2 C_0 H_4 H_3 
Stack 3
F_0 O_2 N_2 Z_103 Z_104 I_1 
Stack 4
K_3 L_0 Z_105 G_1 Z_106 
Stack 5
D_3 C_2 Z_107 K_0 Z_108 
Stack 6
G_2 G_0 A_1 E_1 M_3 
Stack 7
D_0 Z_109 Z_110 D_1 B_0 
Stack 8
Z_111 H_1 Z_112 K_1 Z_113 
Stack 9
Z_114 N_0 I_6 K_4 C_1 
Stack 10
L_1 Z_115 Z_116 D_5 F_1 
Stack 11
I_0 A_0 C_4 I_3 Z_117 
Stack 12
G_4 E_2 J_2 Z_118 G_3 
Stack 13
Z_119 H_6 Z_120 L_2 E_3 
Stack 14
I_2 Z_121 I_4 Z_122 Z_123 
Stack 15
I_5 Z_124 Z_125 G_5 O_0 
Stack 16
Z_126 Z_127 F_3 M_2 D_4 
Stack 17
H_2 I_7 M_1 Z_128 O_1 
