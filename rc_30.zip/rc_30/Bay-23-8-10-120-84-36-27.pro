Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 G_3 D_5 G_4 Z_101 E_0 
Stack 1
C_5 B_9 F_0 Z_102 J_4 Z_103 
Stack 2
B_7 Z_104 A_0 I_7 F_7 B_6 
Stack 3
B_8 F_5 Z_105 Z_106 J_6 Z_107 
Stack 4
Z_108 Z_109 I_2 I_1 C_2 G_6 
Stack 5
F_8 Z_110 A_3 I_0 D_6 
Stack 6
B_3 Z_111 F_4 Z_112 D_3 
Stack 7
J_5 H_4 Z_113 D_4 Z_114 
Stack 8
C_1 E_2 Z_115 H_8 Z_116 
Stack 9
Z_117 Z_118 H_3 A_5 B_5 
Stack 10
Z_119 B_4 D_1 H_7 F_2 
Stack 11
E_7 Z_120 C_6 J_2 B_1 
Stack 12
I_4 G_2 Z_121 H_1 G_0 
Stack 13
Z_122 D_2 Z_123 H_6 C_3 
Stack 14
E_4 Z_124 G_8 E_6 A_4 
Stack 15
G_9 F_3 G_1 H_0 E_8 
Stack 16
I_3 Z_125 A_2 Z_126 A_1 
Stack 17
E_5 F_1 Z_127 F_6 Z_128 
Stack 18
D_0 E_3 I_5 B_2 C_0 
Stack 19
C_7 J_0 H_2 Z_129 Z_130 
Stack 20
Z_131 J_3 H_5 Z_132 C_4 
Stack 21
D_7 Z_133 G_7 I_6 Z_134 
Stack 22
G_5 B_0 J_1 E_1 Z_135 
