Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
K_0 Z_100 Z_101 H_1 Z_102 Z_103 
Stack 1
I_1 N_1 J_3 Z_104 K_3 I_3 
Stack 2
C_0 Z_105 E_4 I_2 H_3 Z_106 
Stack 3
K_1 G_5 C_1 M_1 K_5 Z_107 
Stack 4
Z_108 F_1 J_0 I_5 E_1 
Stack 5
H_2 D_2 Z_109 Z_110 I_4 
Stack 6
Z_111 Z_112 G_0 Z_113 K_2 
Stack 7
N_3 D_3 Z_114 H_5 C_2 
Stack 8
K_4 N_0 Z_115 L_1 H_0 
Stack 9
E_0 L_0 B_0 A_0 L_3 
Stack 10
Z_116 G_1 I_0 D_0 Z_117 
Stack 11
F_5 J_1 B_2 N_2 A_1 
Stack 12
G_4 J_4 Z_118 O_0 F_6 
Stack 13
H_4 F_4 F_3 Z_119 Z_120 
Stack 14
D_1 G_3 F_2 G_2 Z_121 
Stack 15
E_2 Z_122 Z_123 M_0 F_0 
Stack 16
Z_124 Z_125 Z_126 B_1 Z_127 
Stack 17
Z_128 L_2 E_3 J_2 C_3 
