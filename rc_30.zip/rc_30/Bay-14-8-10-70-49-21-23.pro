Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 G_4 F_2 Z_101 Z_102 
Stack 1
Z_103 Z_104 Z_105 I_3 F_7 
Stack 2
Z_106 Z_107 E_0 D_2 G_0 
Stack 3
D_4 D_1 Z_108 D_5 I_4 
Stack 4
Z_109 E_3 Z_110 C_0 C_1 
Stack 5
Z_111 Z_112 F_0 Z_113 A_3 
Stack 6
A_2 H_4 Z_114 F_3 D_3 
Stack 7
B_3 F_1 I_1 F_5 A_0 
Stack 8
E_4 H_1 Z_115 Z_116 I_2 
Stack 9
E_1 H_0 J_0 B_1 F_4 
Stack 10
G_3 J_1 Z_117 B_0 C_2 
Stack 11
F_6 I_0 G_5 B_2 H_5 
Stack 12
Z_118 G_1 H_3 E_2 D_0 
Stack 13
Z_119 A_1 G_2 H_2 Z_120 
