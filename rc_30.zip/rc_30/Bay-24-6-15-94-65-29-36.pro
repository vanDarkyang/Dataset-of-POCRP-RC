Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
L_1 F_2 Z_100 H_6 
Stack 1
Z_101 J_3 G_1 H_0 
Stack 2
A_0 D_1 Z_102 M_0 
Stack 3
E_5 Z_103 I_2 Z_104 
Stack 4
Z_105 I_1 Z_106 J_5 
Stack 5
Z_107 J_1 Z_108 C_3 
Stack 6
F_3 E_4 Z_109 J_0 
Stack 7
Z_110 J_4 E_1 N_1 
Stack 8
N_0 N_2 H_5 J_2 
Stack 9
F_1 D_2 Z_111 E_0 
Stack 10
Z_112 F_4 M_2 G_3 
Stack 11
Z_113 O_0 C_0 Z_114 
Stack 12
I_5 L_0 H_1 Z_115 
Stack 13
C_2 M_1 Z_116 H_3 
Stack 14
G_4 Z_117 C_4 Z_118 
Stack 15
K_0 Z_119 Z_120 B_1 
Stack 16
Z_121 I_0 K_1 I_6 
Stack 17
E_2 K_5 E_3 D_0 
Stack 18
B_2 Z_122 Z_123 G_0 
Stack 19
Z_124 F_0 O_1 M_3 
Stack 20
I_4 C_1 Z_125 H_2 
Stack 21
K_4 K_3 K_2 H_4 
Stack 22
Z_126 Z_127 G_2 
Stack 23
I_3 B_0 Z_128 
