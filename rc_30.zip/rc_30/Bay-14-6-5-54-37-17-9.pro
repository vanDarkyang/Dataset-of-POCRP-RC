Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_0 Z_100 A_2 B_5 
Stack 1
Z_101 E_5 C_3 E_4 
Stack 2
A_3 D_2 E_2 Z_102 
Stack 3
B_3 A_1 A_5 Z_103 
Stack 4
Z_104 A_4 D_4 Z_105 
Stack 5
Z_106 Z_107 Z_108 Z_109 
Stack 6
D_5 C_2 B_1 A_7 
Stack 7
D_3 E_6 B_2 Z_110 
Stack 8
E_3 C_4 Z_111 B_4 
Stack 9
B_0 C_0 A_8 B_6 
Stack 10
C_5 D_6 E_1 Z_112 
Stack 11
C_1 Z_113 A_0 Z_114 
Stack 12
E_0 B_7 D_1 
Stack 13
Z_115 A_6 Z_116 
