Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
Z_100 H_0 B_4 Z_101 Z_102 H_2 
Stack 1
Z_103 N_2 I_6 J_4 Z_104 K_1 
Stack 2
J_5 G_3 N_3 L_0 H_7 G_6 
Stack 3
Z_105 F_5 C_3 Z_106 A_0 Z_107 
Stack 4
G_0 B_0 Z_108 D_1 L_5 
Stack 5
A_2 H_4 Z_109 B_2 Z_110 
Stack 6
D_2 G_1 Z_111 J_3 K_5 
Stack 7
Z_112 M_1 Z_113 H_6 Z_114 
Stack 8
Z_115 Z_116 F_3 F_1 I_4 
Stack 9
O_2 G_2 F_6 Z_117 N_0 
Stack 10
K_0 Z_118 I_2 G_4 F_4 
Stack 11
I_1 Z_119 H_1 Z_120 Z_121 
Stack 12
L_3 D_0 Z_122 Z_123 M_3 
Stack 13
B_3 M_0 L_1 Z_124 J_2 
Stack 14
C_2 E_2 H_3 Z_125 G_5 
Stack 15
E_1 J_6 K_2 I_7 Z_126 
Stack 16
J_1 F_0 M_2 A_3 E_0 
Stack 17
H_8 I_5 N_1 Z_127 I_3 
Stack 18
K_3 Z_128 Z_129 K_6 Z_130 
Stack 19
C_0 J_0 Z_131 Z_132 G_7 
Stack 20
D_3 H_5 Z_133 C_1 I_0 
Stack 21
C_4 L_2 Z_134 Z_135 Z_136 
Stack 22
O_0 L_4 J_7 K_4 B_1 
Stack 23
O_1 Z_137 E_3 A_1 F_2 
