Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 Z_101 C_1 G_0 
Stack 1
H_0 G_2 J_1 E_4 
Stack 2
Z_102 D_0 F_2 F_1 
Stack 3
Z_103 D_2 G_1 E_1 
Stack 4
Z_104 B_0 Z_105 Z_106 
Stack 5
F_3 F_0 Z_107 E_2 
Stack 6
A_2 E_3 H_2 E_5 
Stack 7
Z_108 Z_109 Z_110 C_3 
Stack 8
J_0 I_1 F_5 C_2 
Stack 9
H_3 A_0 H_1 E_0 
Stack 10
Z_111 I_0 A_1 Z_112 
Stack 11
C_0 Z_113 F_4 
Stack 12
D_1 E_6 Z_114 
