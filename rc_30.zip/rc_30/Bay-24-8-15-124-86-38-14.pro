Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
Z_100 Z_101 Z_102 A_0 J_2 F_1 
Stack 1
I_6 M_1 O_3 D_5 E_3 L_2 
Stack 2
J_6 Z_103 O_1 E_0 J_1 I_7 
Stack 3
H_2 C_5 J_5 J_3 Z_104 Z_105 
Stack 4
D_2 F_5 Z_106 A_1 Z_107 
Stack 5
Z_108 H_3 J_4 H_4 M_2 
Stack 6
Z_109 F_4 G_1 H_6 G_0 
Stack 7
E_2 K_6 K_4 L_1 O_0 
Stack 8
G_3 E_1 Z_110 B_0 E_5 
Stack 9
O_2 G_2 Z_111 F_6 Z_112 
Stack 10
Z_113 K_1 E_4 L_3 Z_114 
Stack 11
Z_115 H_0 C_2 Z_116 I_3 
Stack 12
Z_117 I_9 H_1 Z_118 Z_119 
Stack 13
Z_120 Z_121 N_3 C_3 Z_122 
Stack 14
J_0 I_4 Z_123 F_0 C_1 
Stack 15
Z_124 N_2 D_3 Z_125 Z_126 
Stack 16
C_0 G_4 I_2 Z_127 Z_128 
Stack 17
I_1 F_3 Z_129 D_4 D_1 
Stack 18
D_0 I_8 B_1 M_0 N_4 
Stack 19
Z_130 Z_131 C_4 Z_132 F_2 
Stack 20
N_0 K_7 H_5 Z_133 K_0 
Stack 21
I_0 L_4 I_5 K_5 B_2 
Stack 22
K_3 Z_134 L_0 K_8 K_2 
Stack 23
Z_135 N_1 G_5 Z_136 Z_137 
