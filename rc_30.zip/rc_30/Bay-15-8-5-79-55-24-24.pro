Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 E_2 Z_101 Z_102 C_9 E_13 
Stack 1
C_4 C_0 E_4 C_8 Z_103 E_7 
Stack 2
A_3 B_9 B_8 Z_104 Z_105 C_6 
Stack 3
D_4 E_8 D_5 Z_106 D_2 Z_107 
Stack 4
Z_108 Z_109 Z_110 Z_111 D_6 
Stack 5
E_3 E_0 C_1 B_5 Z_112 
Stack 6
B_11 Z_113 A_2 C_2 D_8 
Stack 7
E_1 D_7 Z_114 D_10 C_7 
Stack 8
Z_115 B_6 E_5 Z_116 E_6 
Stack 9
D_3 C_5 B_4 B_0 A_1 
Stack 10
B_7 C_3 Z_117 Z_118 E_12 
Stack 11
B_3 A_0 B_1 D_9 E_9 
Stack 12
A_4 A_6 A_5 E_10 B_2 
Stack 13
Z_119 Z_120 B_10 A_7 Z_121 
Stack 14
E_11 Z_122 D_1 D_0 Z_123 
