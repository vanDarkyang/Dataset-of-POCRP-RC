Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_2 Z_100 J_4 E_5 
Stack 1
Z_101 G_5 G_3 Z_102 
Stack 2
G_4 F_0 D_3 Z_103 
Stack 3
C_2 H_2 E_4 H_5 
Stack 4
J_2 D_6 Z_104 I_1 
Stack 5
Z_105 H_4 F_3 Z_106 
Stack 6
Z_107 E_0 G_2 J_0 
Stack 7
H_1 E_1 A_0 A_1 
Stack 8
Z_108 E_2 H_0 Z_109 
Stack 9
C_1 E_3 Z_110 Z_111 
Stack 10
D_4 D_0 I_0 B_3 
Stack 11
F_4 D_1 G_0 Z_112 
Stack 12
J_1 B_2 Z_113 Z_114 
Stack 13
Z_115 F_1 B_1 D_7 
Stack 14
B_0 Z_116 D_5 Z_117 
Stack 15
J_3 G_1 Z_118 A_2 
Stack 16
F_2 Z_119 Z_120 
Stack 17
B_4 H_3 C_0 
