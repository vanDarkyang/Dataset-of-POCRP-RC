Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 Z_101 B_0 C_6 E_5 A_2 
Stack 1
C_5 E_8 Z_102 D_0 D_4 A_9 
Stack 2
Z_103 B_2 Z_104 Z_105 C_11 A_7 
Stack 3
E_2 D_11 D_8 E_10 Z_106 C_0 
Stack 4
A_11 Z_107 D_6 E_1 C_12 
Stack 5
A_5 D_7 Z_108 E_9 A_4 
Stack 6
C_4 B_5 D_1 Z_109 A_6 
Stack 7
Z_110 Z_111 Z_112 B_4 C_2 
Stack 8
D_2 Z_113 E_4 E_6 A_1 
Stack 9
D_5 A_3 E_7 B_3 B_1 
Stack 10
B_6 Z_114 E_0 Z_115 Z_116 
Stack 11
C_8 Z_117 Z_118 D_9 Z_119 
Stack 12
A_8 Z_120 C_9 C_7 Z_121 
Stack 13
D_3 A_10 D_10 A_0 Z_122 
Stack 14
C_1 C_10 Z_123 E_3 C_3 
