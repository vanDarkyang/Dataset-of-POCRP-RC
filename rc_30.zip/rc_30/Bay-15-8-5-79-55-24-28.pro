Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_6 Z_100 C_6 B_1 B_2 C_11 
Stack 1
A_8 A_5 Z_101 D_3 Z_102 Z_103 
Stack 2
Z_104 Z_105 A_1 D_5 C_8 E_2 
Stack 3
E_6 D_8 Z_106 Z_107 C_1 B_5 
Stack 4
B_6 Z_108 D_4 C_10 C_4 
Stack 5
Z_109 C_2 B_4 E_4 Z_110 
Stack 6
E_8 Z_111 E_9 C_12 Z_112 
Stack 7
Z_113 A_10 C_3 Z_114 E_0 
Stack 8
Z_115 A_9 B_7 D_7 D_1 
Stack 9
B_0 D_11 E_3 C_5 A_11 
Stack 10
Z_116 D_10 D_2 Z_117 Z_118 
Stack 11
B_3 C_0 D_0 A_4 A_3 
Stack 12
C_9 Z_119 Z_120 D_6 Z_121 
Stack 13
E_1 C_7 A_7 A_2 E_5 
Stack 14
E_7 A_0 Z_122 D_9 Z_123 
