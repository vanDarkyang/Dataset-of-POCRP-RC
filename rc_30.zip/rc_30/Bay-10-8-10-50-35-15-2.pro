Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 D_0 B_1 Z_101 I_1 
Stack 1
Z_102 Z_103 Z_104 Z_105 Z_106 
Stack 2
J_1 D_2 H_0 E_2 D_4 
Stack 3
I_0 G_2 F_2 E_5 H_1 
Stack 4
C_1 E_0 Z_107 F_1 J_0 
Stack 5
F_0 G_0 Z_108 G_3 I_2 
Stack 6
Z_109 A_1 D_3 A_0 D_1 
Stack 7
Z_110 G_1 I_3 Z_111 C_2 
Stack 8
Z_112 E_3 Z_113 E_4 E_1 
Stack 9
H_2 Z_114 C_0 B_0 H_3 
