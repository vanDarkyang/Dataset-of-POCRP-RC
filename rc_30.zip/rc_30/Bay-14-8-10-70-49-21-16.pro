Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 A_3 H_2 H_0 A_1 
Stack 1
Z_101 Z_102 E_1 B_3 H_1 
Stack 2
B_2 C_1 Z_103 Z_104 C_2 
Stack 3
E_2 G_1 G_5 F_1 D_2 
Stack 4
Z_105 D_0 Z_106 Z_107 D_3 
Stack 5
J_0 F_6 G_2 Z_108 Z_109 
Stack 6
Z_110 E_3 G_0 G_4 I_2 
Stack 7
Z_111 I_1 I_4 Z_112 E_0 
Stack 8
C_3 D_4 A_0 Z_113 F_3 
Stack 9
H_3 F_2 I_3 A_2 Z_114 
Stack 10
Z_115 H_4 G_3 Z_116 Z_117 
Stack 11
C_4 B_0 J_1 F_4 D_1 
Stack 12
C_0 B_1 Z_118 J_2 F_0 
Stack 13
I_0 Z_119 F_5 Z_120 F_7 
