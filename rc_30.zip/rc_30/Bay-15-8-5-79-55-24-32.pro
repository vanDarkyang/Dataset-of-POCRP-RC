Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_0 D_8 D_6 C_8 Z_100 D_10 
Stack 1
D_0 A_8 B_8 Z_101 Z_102 A_5 
Stack 2
E_7 Z_103 A_2 B_3 C_2 C_10 
Stack 3
D_2 Z_104 C_12 E_1 Z_105 B_9 
Stack 4
Z_106 D_5 Z_107 B_2 Z_108 
Stack 5
B_4 C_9 C_7 C_5 A_3 
Stack 6
E_5 A_10 C_4 B_5 A_1 
Stack 7
Z_109 Z_110 C_6 E_3 C_1 
Stack 8
B_1 Z_111 D_11 Z_112 Z_113 
Stack 9
E_6 Z_114 Z_115 Z_116 Z_117 
Stack 10
B_0 D_3 E_4 A_9 A_4 
Stack 11
Z_118 D_4 Z_119 A_6 Z_120 
Stack 12
D_7 Z_121 E_2 C_3 C_0 
Stack 13
C_11 D_1 Z_122 E_0 B_6 
Stack 14
B_7 D_9 Z_123 A_7 E_8 
