Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
G_1 G_4 J_2 I_1 L_1 C_1 
Stack 1
G_2 Z_100 F_4 J_0 H_2 Z_101 
Stack 2
D_1 K_3 H_0 D_2 F_2 O_2 
Stack 3
G_3 Z_102 Z_103 Z_104 O_0 Z_105 
Stack 4
H_6 A_1 I_0 H_1 B_3 
Stack 5
H_4 F_5 Z_106 I_3 Z_107 
Stack 6
Z_108 Z_109 O_1 I_4 E_0 
Stack 7
K_1 E_1 L_2 Z_110 Z_111 
Stack 8
L_0 D_4 H_3 B_1 B_2 
Stack 9
I_5 Z_112 N_0 Z_113 E_2 
Stack 10
Z_114 Z_115 Z_116 N_1 Z_117 
Stack 11
Z_118 D_3 C_0 A_0 Z_119 
Stack 12
Z_120 E_4 C_2 F_3 Z_121 
Stack 13
Z_122 K_0 C_3 Z_123 M_1 
Stack 14
B_0 M_3 J_3 I_2 Z_124 
Stack 15
F_1 G_0 D_0 F_0 E_3 
Stack 16
J_1 M_2 K_2 Z_125 M_0 
Stack 17
Z_126 I_6 H_5 Z_127 Z_128 
