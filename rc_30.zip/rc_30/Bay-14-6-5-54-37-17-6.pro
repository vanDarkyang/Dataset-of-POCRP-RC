Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_1 C_9 Z_100 Z_101 
Stack 1
A_2 Z_102 Z_103 E_3 
Stack 2
Z_104 Z_105 Z_106 B_2 
Stack 3
A_5 Z_107 D_2 C_0 
Stack 4
A_0 Z_108 Z_109 Z_110 
Stack 5
Z_111 Z_112 Z_113 B_5 
Stack 6
E_6 C_7 E_0 E_5 
Stack 7
A_3 B_6 C_4 Z_114 
Stack 8
B_0 A_6 D_0 C_2 
Stack 9
A_4 Z_115 Z_116 E_4 
Stack 10
C_8 B_1 C_5 C_6 
Stack 11
B_3 B_4 D_3 D_4 
Stack 12
C_1 C_3 E_7 
Stack 13
D_1 E_2 A_1 
