Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
B_1 A_4 D_1 C_8 
Stack 1
A_9 Z_100 Z_101 A_1 
Stack 2
Z_102 E_5 Z_103 Z_104 
Stack 3
Z_105 D_4 E_11 C_1 
Stack 4
B_0 D_2 Z_106 E_8 
Stack 5
B_9 E_3 C_7 C_10 
Stack 6
Z_107 B_7 Z_108 A_2 
Stack 7
A_8 D_10 A_5 D_3 
Stack 8
D_5 C_9 Z_109 B_6 
Stack 9
A_6 B_8 E_9 E_0 
Stack 10
Z_110 C_6 A_0 D_0 
Stack 11
C_2 B_5 D_8 Z_111 
Stack 12
Z_112 E_12 B_2 Z_113 
Stack 13
Z_114 Z_115 E_2 C_4 
Stack 14
Z_116 C_0 Z_117 C_5 
Stack 15
A_7 D_7 Z_118 Z_119 
Stack 16
Z_120 B_3 E_10 C_3 
Stack 17
E_6 E_1 D_9 E_7 
Stack 18
E_4 A_3 Z_121 Z_122 
Stack 19
B_4 D_6 Z_123 
