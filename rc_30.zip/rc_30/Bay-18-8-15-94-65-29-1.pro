Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
D_0 E_3 A_2 A_0 G_1 H_2 
Stack 1
Z_100 F_2 Z_101 I_2 Z_102 I_0 
Stack 2
H_6 J_1 M_0 D_1 Z_103 Z_104 
Stack 3
H_7 I_1 H_5 B_1 J_2 M_1 
Stack 4
Z_105 H_4 C_2 F_4 F_3 
Stack 5
Z_106 I_3 K_3 K_1 Z_107 
Stack 6
E_1 H_8 Z_108 K_4 M_2 
Stack 7
M_3 L_0 Z_109 G_3 H_0 
Stack 8
N_0 D_2 I_4 H_3 Z_110 
Stack 9
Z_111 Z_112 G_0 Z_113 F_1 
Stack 10
Z_114 Z_115 C_1 E_2 N_2 
Stack 11
B_0 E_0 Z_116 Z_117 N_1 
Stack 12
G_6 O_2 H_1 J_3 G_2 
Stack 13
O_1 K_0 Z_118 Z_119 F_0 
Stack 14
G_4 C_3 K_2 Z_120 Z_121 
Stack 15
Z_122 Z_123 J_0 C_0 Z_124 
Stack 16
Z_125 G_5 Z_126 L_1 N_3 
Stack 17
Z_127 O_0 A_1 I_5 Z_128 
