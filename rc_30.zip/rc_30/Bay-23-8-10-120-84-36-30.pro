Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 F_6 Z_101 C_0 Z_102 G_4 
Stack 1
C_7 J_1 Z_103 I_3 G_0 Z_104 
Stack 2
J_5 Z_105 Z_106 A_3 G_6 Z_107 
Stack 3
J_9 J_4 C_6 F_9 I_2 G_2 
Stack 4
I_0 H_1 E_2 E_1 E_5 Z_108 
Stack 5
G_8 Z_109 J_2 C_8 D_7 
Stack 6
D_5 D_6 G_7 F_5 Z_110 
Stack 7
B_7 F_4 J_6 Z_111 B_3 
Stack 8
H_3 F_0 C_2 D_2 Z_112 
Stack 9
E_7 Z_113 H_5 E_0 Z_114 
Stack 10
Z_115 D_4 J_7 Z_116 Z_117 
Stack 11
B_1 B_2 Z_118 Z_119 I_5 
Stack 12
E_6 G_1 F_3 A_1 G_3 
Stack 13
Z_120 G_5 I_6 Z_121 J_0 
Stack 14
Z_122 B_6 A_0 I_1 F_7 
Stack 15
A_4 F_1 F_8 Z_123 Z_124 
Stack 16
Z_125 H_7 B_4 Z_126 Z_127 
Stack 17
H_0 Z_128 Z_129 Z_130 D_0 
Stack 18
F_2 Z_131 H_4 H_2 J_3 
Stack 19
C_5 E_3 Z_132 Z_133 D_1 
Stack 20
C_4 J_8 G_9 Z_134 B_5 
Stack 21
A_2 D_3 H_6 I_4 E_4 
Stack 22
Z_135 B_0 B_8 C_1 C_3 
