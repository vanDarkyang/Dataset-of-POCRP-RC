Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
M_1 Z_100 Z_101 L_0 
Stack 1
Z_102 G_0 Z_103 F_3 
Stack 2
L_1 I_3 Z_104 E_0 
Stack 3
L_2 Z_105 M_2 O_1 
Stack 4
J_2 Z_106 H_6 K_1 
Stack 5
F_4 B_1 Z_107 Z_108 
Stack 6
E_3 Z_109 H_1 Z_110 
Stack 7
C_3 Z_111 K_2 G_5 
Stack 8
Z_112 F_0 G_2 L_3 
Stack 9
B_0 H_4 Z_113 N_2 
Stack 10
D_1 Z_114 A_0 G_1 
Stack 11
Z_115 H_2 Z_116 Z_117 
Stack 12
D_0 F_1 K_3 Z_118 
Stack 13
M_3 C_4 Z_119 H_0 
Stack 14
G_6 J_1 Z_120 J_4 
Stack 15
M_0 C_2 N_0 K_4 
Stack 16
C_0 F_5 I_1 Z_121 
Stack 17
H_3 K_5 I_2 Z_122 
Stack 18
I_0 Z_123 K_0 J_3 
Stack 19
Z_124 G_3 Z_125 H_5 
Stack 20
Z_126 N_1 D_2 E_2 
Stack 21
E_1 G_4 F_2 O_2 
Stack 22
Z_127 J_0 C_1 
Stack 23
H_7 O_0 Z_128 
