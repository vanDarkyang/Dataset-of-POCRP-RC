Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
E_7 D_6 B_4 Z_100 
Stack 1
B_6 Z_101 D_5 B_10 
Stack 2
E_4 E_9 C_9 E_1 
Stack 3
Z_102 B_1 C_6 B_8 
Stack 4
A_2 D_0 A_1 C_5 
Stack 5
A_5 Z_103 Z_104 B_7 
Stack 6
A_4 C_7 Z_105 Z_106 
Stack 7
Z_107 C_11 E_8 C_2 
Stack 8
A_9 D_9 D_2 E_2 
Stack 9
A_8 D_3 Z_108 D_1 
Stack 10
E_6 Z_109 Z_110 C_12 
Stack 11
D_8 Z_111 B_3 Z_112 
Stack 12
Z_113 B_9 Z_114 Z_115 
Stack 13
Z_116 A_6 Z_117 C_1 
Stack 14
C_4 Z_118 Z_119 B_5 
Stack 15
A_0 Z_120 B_11 E_5 
Stack 16
E_0 C_0 C_10 C_3 
Stack 17
B_0 D_7 D_4 Z_121 
Stack 18
A_3 Z_122 A_7 C_8 
Stack 19
Z_123 B_2 E_3 
