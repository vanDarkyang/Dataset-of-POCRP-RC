Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 C_2 Z_101 Z_102 Z_103 
Stack 1
B_6 D_6 Z_104 Z_105 Z_106 
Stack 2
C_3 C_0 A_0 Z_107 D_0 
Stack 3
A_5 Z_108 Z_109 B_2 D_8 
Stack 4
B_0 D_5 A_4 D_4 D_7 
Stack 5
A_2 C_4 E_2 B_3 B_1 
Stack 6
C_5 E_0 A_1 Z_110 Z_111 
Stack 7
D_2 E_5 E_6 E_4 Z_112 
Stack 8
Z_113 E_3 D_3 B_5 C_6 
Stack 9
E_1 Z_114 C_7 Z_115 D_1 
Stack 10
Z_116 C_1 B_4 A_3 
