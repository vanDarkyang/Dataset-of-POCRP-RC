Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
B_7 Z_100 Z_101 Z_102 Z_103 Z_104 
Stack 1
C_0 E_3 E_11 Z_105 E_10 A_7 
Stack 2
D_1 C_4 B_2 A_1 Z_106 E_9 
Stack 3
Z_107 D_4 Z_108 E_8 D_6 A_5 
Stack 4
C_5 D_5 A_3 Z_109 E_6 
Stack 5
Z_110 A_9 A_2 D_7 A_11 
Stack 6
A_12 Z_111 Z_112 A_10 E_4 
Stack 7
C_2 B_9 Z_113 D_8 Z_114 
Stack 8
E_2 C_3 D_3 B_4 D_2 
Stack 9
C_8 B_1 A_8 E_7 C_7 
Stack 10
B_0 B_3 B_8 Z_115 B_6 
Stack 11
Z_116 Z_117 Z_118 Z_119 Z_120 
Stack 12
B_5 E_1 A_0 A_4 E_0 
Stack 13
A_6 C_9 Z_121 E_5 Z_122 
Stack 14
Z_123 C_1 D_0 C_6 C_10 
