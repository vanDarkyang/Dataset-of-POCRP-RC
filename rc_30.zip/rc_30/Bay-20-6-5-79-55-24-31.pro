Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_0 B_9 Z_100 B_12 
Stack 1
E_3 Z_101 D_3 B_4 
Stack 2
B_11 Z_102 Z_103 C_7 
Stack 3
B_7 E_0 Z_104 C_3 
Stack 4
C_9 C_4 Z_105 C_1 
Stack 5
E_8 Z_106 A_11 A_4 
Stack 6
D_5 E_7 A_7 Z_107 
Stack 7
D_9 B_6 D_8 Z_108 
Stack 8
Z_109 B_3 A_10 E_9 
Stack 9
Z_110 B_10 D_0 D_2 
Stack 10
D_7 A_2 Z_111 Z_112 
Stack 11
Z_113 A_8 Z_114 A_3 
Stack 12
A_0 B_8 B_5 B_2 
Stack 13
Z_115 E_2 D_6 E_1 
Stack 14
A_5 C_5 A_6 D_4 
Stack 15
Z_116 E_5 B_0 Z_117 
Stack 16
A_9 Z_118 Z_119 C_8 
Stack 17
Z_120 A_1 D_1 Z_121 
Stack 18
E_6 B_1 C_2 Z_122 
Stack 19
E_4 C_6 Z_123 
