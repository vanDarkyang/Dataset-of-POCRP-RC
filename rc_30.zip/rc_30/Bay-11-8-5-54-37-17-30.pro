Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_3 A_2 Z_100 Z_101 E_3 
Stack 1
A_1 B_1 D_4 D_1 B_2 
Stack 2
C_9 A_3 Z_102 Z_103 D_2 
Stack 3
Z_104 B_0 C_0 Z_105 A_0 
Stack 4
Z_106 C_2 C_6 C_3 D_7 
Stack 5
Z_107 Z_108 Z_109 Z_110 A_5 
Stack 6
E_1 E_0 C_10 D_6 C_4 
Stack 7
C_5 B_5 D_5 C_7 E_4 
Stack 8
Z_111 B_4 C_8 D_3 D_0 
Stack 9
E_5 Z_112 A_4 Z_113 Z_114 
Stack 10
Z_115 Z_116 C_1 E_2 
