Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
G_2 C_0 A_0 B_1 
Stack 1
E_0 F_0 Z_100 Z_101 
Stack 2
A_2 A_1 Z_102 I_2 
Stack 3
Z_103 C_3 E_1 Z_104 
Stack 4
G_1 Z_105 Z_106 F_2 
Stack 5
F_3 H_0 Z_107 J_1 
Stack 6
D_1 Z_108 B_3 Z_109 
Stack 7
C_2 I_0 Z_110 B_2 
Stack 8
D_0 H_2 E_2 Z_111 
Stack 9
Z_112 C_1 Z_113 G_0 
Stack 10
F_4 I_1 B_0 J_2 
Stack 11
D_3 D_2 J_0 
Stack 12
H_1 F_1 Z_114 
