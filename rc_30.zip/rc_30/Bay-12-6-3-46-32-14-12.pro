Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 B_0 B_6 C_5 
Stack 1
Z_101 C_4 B_8 C_10 
Stack 2
C_11 A_4 A_7 B_5 
Stack 3
A_0 C_9 Z_102 Z_103 
Stack 4
Z_104 Z_105 C_1 Z_106 
Stack 5
C_3 Z_107 C_6 A_3 
Stack 6
Z_108 B_9 Z_109 Z_110 
Stack 7
C_8 B_4 C_0 Z_111 
Stack 8
B_1 A_1 A_9 A_8 
Stack 9
B_3 A_2 B_2 B_7 
Stack 10
A_5 A_6 C_7 
Stack 11
C_2 Z_112 Z_113 
