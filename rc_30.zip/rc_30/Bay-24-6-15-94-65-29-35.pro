Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
K_4 I_4 Z_100 Z_101 
Stack 1
Z_102 H_2 Z_103 Z_104 
Stack 2
J_4 F_3 Z_105 M_2 
Stack 3
Z_106 J_0 J_1 E_1 
Stack 4
C_0 Z_107 Z_108 N_0 
Stack 5
H_7 M_3 H_3 Z_109 
Stack 6
E_0 H_6 Z_110 I_0 
Stack 7
I_5 O_0 L_3 H_9 
Stack 8
F_2 L_2 F_0 I_1 
Stack 9
Z_111 Z_112 Z_113 Z_114 
Stack 10
G_4 M_0 C_2 Z_115 
Stack 11
C_1 O_1 K_1 A_0 
Stack 12
H_4 H_8 Z_116 Z_117 
Stack 13
D_2 H_0 Z_118 I_2 
Stack 14
Z_119 I_6 E_3 F_4 
Stack 15
D_0 Z_120 K_5 G_3 
Stack 16
Z_121 M_1 J_2 E_2 
Stack 17
L_0 G_1 K_0 Z_122 
Stack 18
F_1 O_2 K_3 Z_123 
Stack 19
H_5 Z_124 J_3 L_1 
Stack 20
Z_125 B_0 Z_126 D_1 
Stack 21
K_2 N_1 G_0 Z_127 
Stack 22
E_4 G_2 E_5 
Stack 23
I_3 Z_128 H_1 
