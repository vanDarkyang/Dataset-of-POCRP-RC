Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
J_1 D_4 E_4 F_2 
Stack 1
Z_100 I_0 B_3 J_0 
Stack 2
Z_101 H_4 J_2 F_5 
Stack 3
G_5 E_1 A_2 A_3 
Stack 4
A_1 B_2 Z_102 Z_103 
Stack 5
B_1 Z_104 Z_105 Z_106 
Stack 6
Z_107 H_0 D_1 G_4 
Stack 7
B_0 G_3 Z_108 G_1 
Stack 8
A_0 F_6 Z_109 Z_110 
Stack 9
F_4 C_3 Z_111 F_7 
Stack 10
F_3 C_4 Z_112 E_0 
Stack 11
E_5 D_0 Z_113 Z_114 
Stack 12
Z_115 G_2 Z_116 Z_117 
Stack 13
H_3 F_0 H_2 E_2 
Stack 14
D_2 D_3 H_5 E_3 
Stack 15
F_1 C_0 Z_118 G_0 
Stack 16
Z_119 C_2 C_1 
Stack 17
Z_120 H_1 E_6 
