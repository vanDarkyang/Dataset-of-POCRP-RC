Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 J_0 Z_101 G_2 G_1 K_4 
Stack 1
N_1 E_0 C_2 B_0 K_5 E_1 
Stack 2
K_1 E_4 H_0 K_2 F_2 N_0 
Stack 3
Z_102 J_2 Z_103 L_2 Z_104 E_2 
Stack 4
E_3 C_0 H_2 M_0 D_0 
Stack 5
Z_105 Z_106 Z_107 F_0 Z_108 
Stack 6
D_4 G_6 Z_109 D_2 M_2 
Stack 7
F_4 Z_110 Z_111 J_1 M_3 
Stack 8
O_1 Z_112 H_3 I_3 Z_113 
Stack 9
D_3 M_4 F_3 G_3 Z_114 
Stack 10
Z_115 Z_116 H_1 L_0 I_2 
Stack 11
O_0 C_1 K_3 Z_117 H_4 
Stack 12
Z_118 I_1 Z_119 H_5 K_0 
Stack 13
D_1 F_5 Z_120 M_1 Z_121 
Stack 14
J_3 Z_122 Z_123 Z_124 I_4 
Stack 15
G_0 N_2 Z_125 G_5 A_0 
Stack 16
Z_126 L_1 F_1 G_7 J_4 
Stack 17
Z_127 G_4 I_5 I_0 Z_128 
