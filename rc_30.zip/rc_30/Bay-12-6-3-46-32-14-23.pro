Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_6 A_9 C_1 A_0 
Stack 1
A_2 Z_100 B_7 Z_101 
Stack 2
A_8 C_2 Z_102 Z_103 
Stack 3
B_3 Z_104 Z_105 B_4 
Stack 4
B_8 A_5 A_4 C_0 
Stack 5
Z_106 C_4 A_6 Z_107 
Stack 6
Z_108 Z_109 Z_110 C_3 
Stack 7
C_9 A_7 Z_111 Z_112 
Stack 8
B_10 C_6 B_5 B_2 
Stack 9
C_7 C_5 C_8 A_3 
Stack 10
B_0 B_9 B_1 
Stack 11
A_10 Z_113 A_1 
