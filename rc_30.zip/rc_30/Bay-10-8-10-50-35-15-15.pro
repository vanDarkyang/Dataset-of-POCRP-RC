Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
D_0 Z_100 G_5 I_1 D_3 
Stack 1
Z_101 B_1 B_0 A_0 C_0 
Stack 2
D_1 E_0 Z_102 I_0 F_0 
Stack 3
Z_103 E_1 A_1 H_1 J_1 
Stack 4
F_4 G_4 J_2 E_4 E_2 
Stack 5
G_3 A_2 Z_104 Z_105 Z_106 
Stack 6
C_2 Z_107 Z_108 F_3 Z_109 
Stack 7
E_3 Z_110 G_0 Z_111 H_0 
Stack 8
D_2 Z_112 F_1 Z_113 F_2 
Stack 9
Z_114 C_1 J_0 G_1 G_2 
