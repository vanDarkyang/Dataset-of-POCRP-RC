Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
M_3 D_2 N_1 J_4 Z_100 J_6 
Stack 1
K_1 J_1 K_2 Z_101 A_2 K_5 
Stack 2
N_0 H_4 H_2 Z_102 F_4 Z_103 
Stack 3
Z_104 Z_105 I_2 O_0 J_0 Z_106 
Stack 4
Z_107 J_2 B_2 D_0 M_2 
Stack 5
B_3 F_2 Z_108 L_2 A_1 
Stack 6
M_0 G_2 I_1 D_3 Z_109 
Stack 7
C_1 Z_110 I_3 N_2 L_0 
Stack 8
C_2 Z_111 Z_112 I_4 Z_113 
Stack 9
O_1 C_0 Z_114 E_0 G_5 
Stack 10
A_0 H_1 B_0 J_5 E_1 
Stack 11
Z_115 K_4 F_3 K_0 Z_116 
Stack 12
H_0 G_3 Z_117 I_0 Z_118 
Stack 13
Z_119 Z_120 Z_121 L_1 Z_122 
Stack 14
M_1 E_2 F_1 Z_123 G_0 
Stack 15
B_1 J_3 Z_124 E_3 G_4 
Stack 16
H_3 F_0 Z_125 K_3 H_5 
Stack 17
Z_126 Z_127 Z_128 G_1 D_1 
