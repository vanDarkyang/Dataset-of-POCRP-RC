Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 B_10 D_0 D_2 
Stack 1
D_5 A_4 E_7 E_1 
Stack 2
Z_101 A_10 Z_102 Z_103 
Stack 3
Z_104 A_2 E_10 E_9 
Stack 4
B_6 C_8 E_0 E_5 
Stack 5
Z_105 B_1 Z_106 Z_107 
Stack 6
C_3 C_10 B_2 A_7 
Stack 7
Z_108 A_5 B_5 Z_109 
Stack 8
E_3 Z_110 B_9 Z_111 
Stack 9
C_4 E_6 Z_112 Z_113 
Stack 10
B_7 B_8 E_4 A_6 
Stack 11
Z_114 D_8 C_2 Z_115 
Stack 12
E_2 B_0 B_4 C_7 
Stack 13
Z_116 Z_117 Z_118 D_1 
Stack 14
C_0 D_4 D_7 C_6 
Stack 15
A_9 A_0 Z_119 D_3 
Stack 16
B_11 C_5 D_6 Z_120 
Stack 17
A_3 D_9 Z_121 C_1 
Stack 18
A_1 Z_122 B_3 C_9 
Stack 19
A_8 E_8 Z_123 
