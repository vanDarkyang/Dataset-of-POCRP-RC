Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 M_1 F_1 L_3 
Stack 1
Z_101 D_2 Z_102 Z_103 
Stack 2
Z_104 J_5 H_7 Z_105 
Stack 3
Z_106 I_6 G_2 L_0 
Stack 4
Z_107 J_2 H_2 M_2 
Stack 5
H_3 K_0 G_1 F_4 
Stack 6
Z_108 I_5 O_1 Z_109 
Stack 7
F_5 O_0 A_1 L_1 
Stack 8
Z_110 H_1 E_5 E_0 
Stack 9
C_1 E_2 G_0 G_5 
Stack 10
Z_111 G_3 B_0 I_7 
Stack 11
E_3 Z_112 Z_113 F_0 
Stack 12
F_2 J_1 B_2 H_0 
Stack 13
I_1 G_6 Z_114 Z_115 
Stack 14
D_1 L_4 F_3 A_0 
Stack 15
Z_116 Z_117 E_4 H_6 
Stack 16
B_1 Z_118 Z_119 Z_120 
Stack 17
Z_121 J_4 Z_122 M_0 
Stack 18
I_3 I_4 Z_123 Z_124 
Stack 19
H_5 J_0 E_6 I_2 
Stack 20
D_0 Z_125 G_4 N_0 
Stack 21
Z_126 H_8 L_2 E_1 
Stack 22
C_0 Z_127 Z_128 
Stack 23
H_4 I_0 J_3 
