Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_4 Z_100 A_1 Z_101 
Stack 1
A_2 Z_102 C_11 C_10 
Stack 2
A_9 A_5 B_8 Z_103 
Stack 3
C_0 B_7 C_9 C_1 
Stack 4
Z_104 Z_105 B_3 C_8 
Stack 5
C_6 B_4 A_0 Z_106 
Stack 6
Z_107 A_6 C_4 A_3 
Stack 7
C_7 Z_108 B_2 C_3 
Stack 8
B_5 A_8 Z_109 C_5 
Stack 9
B_1 Z_110 B_6 C_2 
Stack 10
Z_111 B_9 Z_112 
Stack 11
B_0 A_7 Z_113 
