Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 A_7 C_8 C_9 C_10 C_5 
Stack 1
A_9 Z_101 B_5 Z_102 A_3 C_4 
Stack 2
A_0 E_3 E_10 A_5 D_5 E_4 
Stack 3
B_6 Z_103 C_1 Z_104 C_2 E_8 
Stack 4
B_0 Z_105 C_0 E_6 E_5 
Stack 5
B_9 Z_106 D_8 A_2 C_11 
Stack 6
Z_107 B_1 Z_108 D_9 A_4 
Stack 7
A_8 E_2 E_0 B_3 D_3 
Stack 8
D_6 D_4 Z_109 E_1 B_7 
Stack 9
A_6 Z_110 D_7 Z_111 Z_112 
Stack 10
A_1 Z_113 D_1 Z_114 D_0 
Stack 11
C_3 Z_115 C_6 E_7 D_10 
Stack 12
B_2 Z_116 D_2 Z_117 C_12 
Stack 13
B_4 Z_118 E_9 Z_119 C_7 
Stack 14
Z_120 B_8 Z_121 Z_122 Z_123 
