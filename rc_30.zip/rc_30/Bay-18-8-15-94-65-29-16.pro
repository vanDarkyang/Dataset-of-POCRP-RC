Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 I_0 Z_101 H_2 L_1 J_4 
Stack 1
D_2 F_3 C_3 K_0 F_4 Z_102 
Stack 2
Z_103 Z_104 J_2 G_1 E_0 E_2 
Stack 3
L_3 E_1 C_1 B_1 O_1 O_2 
Stack 4
J_3 K_2 F_6 Z_105 Z_106 
Stack 5
F_5 H_8 Z_107 E_4 F_0 
Stack 6
E_3 D_1 I_1 K_1 Z_108 
Stack 7
C_2 Z_109 G_2 B_2 G_3 
Stack 8
Z_110 Z_111 Z_112 L_2 L_4 
Stack 9
B_0 Z_113 Z_114 N_0 N_1 
Stack 10
Z_115 I_2 J_1 Z_116 Z_117 
Stack 11
M_1 Z_118 O_0 Z_119 Z_120 
Stack 12
D_0 J_0 H_0 Z_121 I_4 
Stack 13
Z_122 G_0 L_0 A_1 H_1 
Stack 14
Z_123 F_1 Z_124 D_3 J_5 
Stack 15
Z_125 H_5 M_0 F_2 K_3 
Stack 16
C_0 I_3 H_7 Z_126 Z_127 
Stack 17
H_4 H_3 Z_128 H_6 A_0 
