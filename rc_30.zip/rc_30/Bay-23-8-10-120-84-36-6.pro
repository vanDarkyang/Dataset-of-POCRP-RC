Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 F_1 D_6 A_7 Z_101 D_5 
Stack 1
I_3 C_0 H_5 J_3 I_6 G_1 
Stack 2
C_4 J_5 E_10 Z_102 C_2 H_7 
Stack 3
G_4 Z_103 Z_104 D_9 F_11 D_4 
Stack 4
J_0 C_5 Z_105 A_5 E_3 E_4 
Stack 5
B_3 Z_106 C_6 Z_107 Z_108 
Stack 6
D_10 E_5 B_1 F_5 Z_109 
Stack 7
G_2 Z_110 Z_111 Z_112 B_5 
Stack 8
F_6 F_10 D_1 Z_113 F_2 
Stack 9
Z_114 Z_115 E_0 I_2 D_7 
Stack 10
A_1 Z_116 Z_117 A_3 F_4 
Stack 11
C_3 D_2 F_9 B_2 I_5 
Stack 12
Z_118 D_8 Z_119 H_3 B_4 
Stack 13
Z_120 G_0 H_2 E_1 H_1 
Stack 14
Z_121 Z_122 I_1 I_0 E_7 
Stack 15
Z_123 Z_124 Z_125 J_2 G_5 
Stack 16
D_3 G_3 Z_126 H_0 A_2 
Stack 17
Z_127 C_1 H_4 Z_128 E_9 
Stack 18
E_6 E_8 H_8 Z_129 Z_130 
Stack 19
J_1 A_6 G_6 B_0 A_4 
Stack 20
H_6 Z_131 Z_132 F_7 Z_133 
Stack 21
J_4 I_4 F_8 A_0 F_0 
Stack 22
F_3 D_0 Z_134 Z_135 E_2 
