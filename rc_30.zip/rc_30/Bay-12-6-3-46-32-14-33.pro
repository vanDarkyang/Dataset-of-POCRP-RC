Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_1 B_1 Z_100 Z_101 
Stack 1
B_3 C_0 C_1 C_4 
Stack 2
Z_102 B_10 B_2 C_9 
Stack 3
B_7 Z_103 C_2 C_10 
Stack 4
A_2 Z_104 Z_105 A_8 
Stack 5
Z_106 Z_107 C_8 B_9 
Stack 6
C_3 B_5 Z_108 B_6 
Stack 7
Z_109 Z_110 Z_111 C_6 
Stack 8
A_3 A_0 A_4 Z_112 
Stack 9
C_7 A_9 A_7 A_6 
Stack 10
Z_113 B_8 B_4 
Stack 11
B_0 C_5 A_5 
