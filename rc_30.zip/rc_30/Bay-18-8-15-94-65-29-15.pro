Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
J_2 Z_100 D_2 F_2 Z_101 Z_102 
Stack 1
G_2 H_0 Z_103 J_0 H_3 Z_104 
Stack 2
C_3 E_3 K_1 G_7 L_1 M_3 
Stack 3
B_2 E_1 Z_105 Z_106 H_2 H_6 
Stack 4
G_0 N_3 E_4 Z_107 C_2 
Stack 5
Z_108 I_0 Z_109 N_2 G_3 
Stack 6
N_1 Z_110 M_4 Z_111 J_3 
Stack 7
A_1 H_4 Z_112 K_0 O_0 
Stack 8
D_1 G_1 G_4 N_0 D_3 
Stack 9
D_0 M_0 Z_113 Z_114 Z_115 
Stack 10
A_0 K_2 L_0 Z_116 Z_117 
Stack 11
B_1 Z_118 B_0 C_1 Z_119 
Stack 12
I_1 E_0 J_1 M_2 Z_120 
Stack 13
E_5 G_5 F_1 I_4 Z_121 
Stack 14
C_0 H_5 Z_122 I_2 Z_123 
Stack 15
G_6 Z_124 Z_125 H_1 M_1 
Stack 16
F_0 I_3 Z_126 L_2 Z_127 
Stack 17
B_3 Z_128 H_7 F_3 E_2 
