Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_0 F_2 J_1 F_4 F_3 
Stack 1
D_2 Z_100 Z_101 H_5 Z_102 
Stack 2
C_5 E_2 J_0 B_2 D_3 
Stack 3
C_2 A_2 Z_103 Z_104 E_3 
Stack 4
Z_105 J_2 G_4 E_0 Z_106 
Stack 5
G_3 Z_107 I_2 C_4 D_1 
Stack 6
Z_108 B_1 Z_109 Z_110 Z_111 
Stack 7
G_1 B_4 G_2 H_4 G_0 
Stack 8
C_0 B_3 G_5 I_1 Z_112 
Stack 9
Z_113 G_6 F_1 Z_114 J_3 
Stack 10
A_1 C_3 H_2 E_1 C_6 
Stack 11
Z_115 Z_116 Z_117 H_0 B_0 
Stack 12
H_3 A_0 Z_118 F_0 C_1 
Stack 13
J_4 I_0 Z_119 H_1 Z_120 
