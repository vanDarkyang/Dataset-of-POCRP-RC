Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
O_1 Z_100 G_1 J_4 Z_101 I_5 
Stack 1
Z_102 H_1 B_2 J_5 K_2 K_0 
Stack 2
J_1 H_0 Z_103 N_2 G_0 H_5 
Stack 3
Z_104 Z_105 E_2 B_0 C_2 Z_106 
Stack 4
O_2 F_2 M_1 D_2 Z_107 
Stack 5
Z_108 F_1 A_1 Z_109 Z_110 
Stack 6
G_4 F_3 G_3 Z_111 H_4 
Stack 7
Z_112 D_3 C_1 Z_113 A_0 
Stack 8
D_1 E_0 I_1 M_2 Z_114 
Stack 9
F_4 K_3 I_2 Z_115 Z_116 
Stack 10
K_1 F_0 D_0 Z_117 Z_118 
Stack 11
Z_119 Z_120 G_5 O_0 B_1 
Stack 12
D_4 J_3 L_1 Z_121 Z_122 
Stack 13
M_0 I_4 Z_123 I_6 G_2 
Stack 14
G_6 C_0 Z_124 Z_125 F_5 
Stack 15
I_0 L_0 J_2 K_4 N_1 
Stack 16
Z_126 H_2 Z_127 E_1 Z_128 
Stack 17
I_3 H_3 F_6 N_0 J_0 
