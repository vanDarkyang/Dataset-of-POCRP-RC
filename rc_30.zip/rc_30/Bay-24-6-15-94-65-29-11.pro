Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
G_3 Z_100 L_3 Z_101 
Stack 1
Z_102 F_0 Z_103 L_2 
Stack 2
K_3 H_0 Z_104 H_4 
Stack 3
N_0 Z_105 I_3 J_3 
Stack 4
A_1 G_4 I_2 L_4 
Stack 5
Z_106 G_5 G_2 D_1 
Stack 6
Z_107 Z_108 G_6 Z_109 
Stack 7
Z_110 Z_111 M_0 H_6 
Stack 8
C_2 Z_112 K_5 C_0 
Stack 9
A_2 H_5 Z_113 I_1 
Stack 10
O_2 N_2 K_6 Z_114 
Stack 11
A_0 G_0 M_1 B_1 
Stack 12
E_1 G_1 K_4 I_6 
Stack 13
J_2 D_0 N_3 B_2 
Stack 14
I_0 J_1 H_3 Z_115 
Stack 15
H_2 F_1 E_0 Z_116 
Stack 16
K_2 I_4 J_4 Z_117 
Stack 17
C_1 Z_118 M_3 K_1 
Stack 18
Z_119 I_5 Z_120 Z_121 
Stack 19
H_1 Z_122 M_2 Z_123 
Stack 20
Z_124 B_0 Z_125 L_1 
Stack 21
Z_126 O_0 O_1 D_2 
Stack 22
Z_127 K_0 L_0 
Stack 23
Z_128 N_1 J_0 
