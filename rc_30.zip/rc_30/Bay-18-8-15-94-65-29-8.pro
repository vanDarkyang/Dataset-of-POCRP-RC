Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
N_0 Z_100 L_4 M_0 B_0 J_0 
Stack 1
Z_101 F_5 J_3 Z_102 K_3 Z_103 
Stack 2
C_0 A_2 G_1 K_1 C_4 M_1 
Stack 3
H_0 H_6 Z_104 L_2 J_2 E_4 
Stack 4
O_0 H_3 N_2 K_0 H_7 
Stack 5
Z_105 Z_106 B_1 I_1 Z_107 
Stack 6
F_3 I_2 Z_108 I_0 E_2 
Stack 7
H_2 H_1 Z_109 Z_110 D_0 
Stack 8
E_1 L_0 Z_111 L_3 N_1 
Stack 9
I_4 F_1 Z_112 A_0 I_5 
Stack 10
A_1 H_4 G_2 Z_113 E_3 
Stack 11
F_0 Z_114 L_1 Z_115 Z_116 
Stack 12
D_2 C_3 E_0 D_1 O_1 
Stack 13
F_4 Z_117 Z_118 Z_119 Z_120 
Stack 14
Z_121 Z_122 G_0 Z_123 F_6 
Stack 15
B_2 J_1 I_3 O_2 Z_124 
Stack 16
C_1 M_2 F_2 Z_125 C_2 
Stack 17
H_5 Z_126 Z_127 K_2 Z_128 
