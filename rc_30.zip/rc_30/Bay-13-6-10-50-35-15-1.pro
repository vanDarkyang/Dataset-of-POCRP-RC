Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
B_1 D_1 A_0 F_0 
Stack 1
F_3 G_0 Z_100 G_3 
Stack 2
J_1 F_2 Z_101 Z_102 
Stack 3
C_1 E_1 Z_103 E_2 
Stack 4
E_3 Z_104 Z_105 Z_106 
Stack 5
C_2 C_3 D_2 Z_107 
Stack 6
Z_108 C_4 I_0 G_5 
Stack 7
I_1 G_1 G_2 Z_109 
Stack 8
C_0 Z_110 J_0 F_1 
Stack 9
J_2 E_0 B_0 H_1 
Stack 10
H_3 D_0 G_4 A_1 
Stack 11
Z_111 H_0 Z_112 
Stack 12
Z_113 H_2 Z_114 
