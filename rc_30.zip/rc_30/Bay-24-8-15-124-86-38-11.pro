Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
G_6 E_2 Z_100 C_0 N_4 Z_101 
Stack 1
Z_102 F_8 E_1 Z_103 M_3 F_5 
Stack 2
G_8 E_3 Z_104 F_2 M_4 Z_105 
Stack 3
B_2 A_2 H_1 B_0 F_0 A_0 
Stack 4
G_5 G_1 F_1 Z_106 O_2 
Stack 5
L_0 O_1 Z_107 H_4 Z_108 
Stack 6
G_3 Z_109 K_6 Z_110 E_5 
Stack 7
Z_111 F_7 H_0 B_1 Z_112 
Stack 8
Z_113 L_5 L_6 J_4 J_5 
Stack 9
N_1 M_1 L_3 G_2 Z_114 
Stack 10
I_0 C_1 G_7 K_2 J_1 
Stack 11
B_3 Z_115 Z_116 I_1 M_5 
Stack 12
F_4 Z_117 Z_118 Z_119 D_3 
Stack 13
E_4 L_2 J_0 Z_120 O_3 
Stack 14
M_2 G_4 K_1 Z_121 F_6 
Stack 15
M_0 A_1 Z_122 J_6 D_0 
Stack 16
Z_123 Z_124 Z_125 Z_126 Z_127 
Stack 17
N_0 Z_128 O_0 H_5 D_1 
Stack 18
A_3 Z_129 C_2 E_6 Z_130 
Stack 19
G_0 Z_131 Z_132 Z_133 N_2 
Stack 20
N_3 H_2 Z_134 Z_135 K_3 
Stack 21
K_0 L_1 F_3 K_5 H_3 
Stack 22
Z_136 J_2 J_3 E_0 L_4 
Stack 23
D_2 I_2 K_4 Z_137 H_6 
