Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
D_2 D_0 H_3 H_0 
Stack 1
G_1 H_2 B_1 F_1 
Stack 2
Z_100 D_5 Z_101 D_1 
Stack 3
Z_102 C_0 G_0 Z_103 
Stack 4
B_3 I_2 I_0 Z_104 
Stack 5
Z_105 Z_106 A_2 F_0 
Stack 6
J_2 A_1 Z_107 E_3 
Stack 7
Z_108 B_2 Z_109 E_0 
Stack 8
I_1 D_3 J_0 G_2 
Stack 9
Z_110 J_1 Z_111 D_4 
Stack 10
Z_112 H_1 E_1 B_0 
Stack 11
A_0 Z_113 E_2 
Stack 12
F_3 Z_114 F_2 
