Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
G_6 Z_100 I_0 F_9 J_4 Z_101 
Stack 1
B_5 Z_102 A_0 D_5 Z_103 B_4 
Stack 2
E_6 D_4 Z_104 C_7 Z_105 D_3 
Stack 3
G_3 Z_106 C_2 E_7 Z_107 Z_108 
Stack 4
C_3 Z_109 F_6 Z_110 H_0 G_4 
Stack 5
D_0 A_2 Z_111 E_5 J_5 
Stack 6
B_0 A_4 E_4 G_7 Z_112 
Stack 7
C_6 H_4 C_0 D_7 B_1 
Stack 8
Z_113 I_6 Z_114 G_0 A_3 
Stack 9
F_1 Z_115 E_8 Z_116 D_1 
Stack 10
Z_117 Z_118 G_1 H_5 F_10 
Stack 11
F_2 Z_119 J_2 Z_120 Z_121 
Stack 12
E_0 F_11 I_2 B_3 B_6 
Stack 13
C_8 F_5 Z_122 H_6 J_1 
Stack 14
H_3 A_5 F_7 Z_123 Z_124 
Stack 15
G_2 E_2 F_8 J_3 E_3 
Stack 16
Z_125 I_1 Z_126 Z_127 D_6 
Stack 17
F_3 I_5 J_7 C_1 I_3 
Stack 18
Z_128 A_1 Z_129 Z_130 F_4 
Stack 19
J_6 H_2 Z_131 C_5 Z_132 
Stack 20
Z_133 D_8 B_2 D_2 G_8 
Stack 21
Z_134 C_4 F_0 J_0 Z_135 
Stack 22
G_5 J_8 E_1 I_4 H_1 
