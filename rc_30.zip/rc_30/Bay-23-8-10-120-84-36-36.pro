Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 E_0 Z_101 F_8 C_2 Z_102 
Stack 1
Z_103 Z_104 H_6 H_3 H_8 D_7 
Stack 2
D_3 D_5 D_4 G_5 E_8 Z_105 
Stack 3
Z_106 Z_107 J_4 A_3 Z_108 J_1 
Stack 4
Z_109 D_1 J_3 Z_110 E_5 B_3 
Stack 5
H_7 Z_111 Z_112 Z_113 F_1 
Stack 6
Z_114 G_9 C_1 A_4 I_8 
Stack 7
C_6 I_1 Z_115 Z_116 G_0 
Stack 8
G_4 D_6 H_5 C_5 A_1 
Stack 9
I_0 E_6 Z_117 H_0 F_4 
Stack 10
C_4 A_0 J_8 Z_118 I_5 
Stack 11
A_2 Z_119 H_2 Z_120 F_6 
Stack 12
Z_121 Z_122 B_0 J_6 D_8 
Stack 13
B_2 Z_123 F_7 E_4 C_0 
Stack 14
Z_124 E_7 G_10 E_2 G_8 
Stack 15
Z_125 G_3 J_7 Z_126 B_4 
Stack 16
I_3 Z_127 B_1 J_0 F_3 
Stack 17
Z_128 E_3 I_2 H_4 J_2 
Stack 18
F_5 Z_129 Z_130 I_7 F_2 
Stack 19
C_3 G_1 D_2 D_0 J_5 
Stack 20
E_1 G_7 F_0 E_9 G_6 
Stack 21
Z_131 Z_132 A_5 Z_133 I_4 
Stack 22
Z_134 I_6 H_1 Z_135 G_2 
