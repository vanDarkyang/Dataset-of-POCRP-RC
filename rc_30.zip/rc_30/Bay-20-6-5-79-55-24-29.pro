Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_2 A_2 Z_100 D_7 
Stack 1
E_7 A_5 Z_101 A_8 
Stack 2
B_8 Z_102 E_0 A_1 
Stack 3
B_2 E_3 B_10 B_0 
Stack 4
Z_103 Z_104 Z_105 D_3 
Stack 5
Z_106 Z_107 C_0 Z_108 
Stack 6
A_7 D_1 E_4 E_2 
Stack 7
D_6 Z_109 C_6 D_12 
Stack 8
A_3 B_5 D_10 C_4 
Stack 9
A_9 Z_110 Z_111 Z_112 
Stack 10
C_3 A_6 Z_113 E_9 
Stack 11
B_1 D_4 E_1 A_0 
Stack 12
B_3 Z_114 D_9 A_10 
Stack 13
D_11 E_6 E_10 C_2 
Stack 14
C_5 Z_115 D_0 Z_116 
Stack 15
Z_117 B_7 B_9 A_4 
Stack 16
Z_118 Z_119 Z_120 C_7 
Stack 17
Z_121 E_5 Z_122 C_1 
Stack 18
B_6 Z_123 D_8 C_8 
Stack 19
B_4 E_8 D_5 
