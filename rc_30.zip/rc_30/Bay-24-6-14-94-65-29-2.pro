Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
14
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 G_0 Z_101 E_3 
Stack 1
G_5 F_1 J_4 J_0 
Stack 2
E_0 Z_102 G_3 Z_103 
Stack 3
Z_104 Z_105 Z_106 Z_107 
Stack 4
Z_108 L_3 I_3 G_1 
Stack 5
I_1 H_0 K_3 F_2 
Stack 6
Z_109 G_4 D_1 K_2 
Stack 7
Z_110 H_2 D_3 J_3 
Stack 8
K_0 H_3 Z_111 D_2 
Stack 9
H_6 N_1 E_4 J_1 
Stack 10
L_2 C_1 J_5 Z_112 
Stack 11
Z_113 K_4 F_3 Z_114 
Stack 12
Z_115 I_0 Z_116 H_4 
Stack 13
F_5 I_2 N_0 Z_117 
Stack 14
Z_118 M_2 A_0 H_5 
Stack 15
B_1 J_2 G_6 N_2 
Stack 16
Z_119 E_2 Z_120 Z_121 
Stack 17
Z_122 M_3 F_6 B_0 
Stack 18
Z_123 H_1 Z_124 G_2 
Stack 19
L_0 B_3 Z_125 D_0 
Stack 20
F_4 L_1 K_1 C_0 
Stack 21
M_1 E_1 Z_126 M_0 
Stack 22
F_7 Z_127 Z_128 
Stack 23
F_0 C_2 B_2 
