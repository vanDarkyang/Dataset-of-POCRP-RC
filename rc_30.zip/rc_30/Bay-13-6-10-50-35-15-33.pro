Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
I_1 G_5 Z_100 D_3 
Stack 1
C_1 I_0 J_1 E_0 
Stack 2
E_4 Z_101 Z_102 G_4 
Stack 3
B_0 Z_103 C_2 Z_104 
Stack 4
F_0 H_1 Z_105 D_2 
Stack 5
Z_106 D_1 F_3 J_0 
Stack 6
Z_107 B_2 H_0 D_4 
Stack 7
F_1 E_3 G_0 G_2 
Stack 8
F_2 H_2 Z_108 Z_109 
Stack 9
Z_110 G_1 C_0 Z_111 
Stack 10
Z_112 G_3 B_1 D_0 
Stack 11
Z_113 F_4 Z_114 
Stack 12
E_1 A_0 E_2 
