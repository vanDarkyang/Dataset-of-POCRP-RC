Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
B_3 F_0 A_0 Z_100 
Stack 1
F_1 I_0 Z_101 J_1 
Stack 2
E_4 D_3 Z_102 B_2 
Stack 3
Z_103 D_1 B_1 G_2 
Stack 4
F_3 J_0 Z_104 G_1 
Stack 5
Z_105 Z_106 D_0 C_1 
Stack 6
Z_107 H_1 E_1 C_0 
Stack 7
Z_108 I_1 D_5 B_0 
Stack 8
G_3 Z_109 Z_110 Z_111 
Stack 9
E_0 J_2 Z_112 E_2 
Stack 10
D_4 E_3 H_0 C_2 
Stack 11
Z_113 H_2 Z_114 
Stack 12
D_2 F_2 G_0 
