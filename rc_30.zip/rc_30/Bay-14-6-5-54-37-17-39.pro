Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_8 D_3 C_9 Z_100 
Stack 1
E_5 D_1 B_2 Z_101 
Stack 2
Z_102 Z_103 A_0 E_2 
Stack 3
D_2 E_7 Z_104 B_3 
Stack 4
C_1 Z_105 Z_106 Z_107 
Stack 5
Z_108 Z_109 Z_110 E_3 
Stack 6
D_0 A_4 A_1 Z_111 
Stack 7
C_5 A_3 B_1 A_5 
Stack 8
B_4 C_4 C_0 B_0 
Stack 9
Z_112 Z_113 Z_114 C_3 
Stack 10
C_6 D_4 E_1 D_5 
Stack 11
C_8 E_4 Z_115 E_0 
Stack 12
E_6 A_2 C_2 
Stack 13
C_7 A_6 Z_116 
