Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 A_0 B_7 A_3 
Stack 1
C_5 C_6 Z_101 A_2 
Stack 2
B_2 C_8 C_1 A_9 
Stack 3
Z_102 A_5 Z_103 Z_104 
Stack 4
C_9 C_4 A_1 Z_105 
Stack 5
A_4 Z_106 C_10 B_3 
Stack 6
B_6 Z_107 B_5 B_9 
Stack 7
B_0 Z_108 Z_109 C_3 
Stack 8
A_6 A_7 Z_110 B_4 
Stack 9
C_7 B_8 A_8 C_0 
Stack 10
Z_111 C_2 Z_112 
Stack 11
Z_113 B_1 B_10 
