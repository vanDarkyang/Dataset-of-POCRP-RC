Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 E_0 C_2 B_1 
Stack 1
F_4 C_1 D_1 A_0 
Stack 2
Z_101 F_0 F_1 H_1 
Stack 3
D_0 E_3 B_0 Z_102 
Stack 4
J_0 Z_103 I_1 H_2 
Stack 5
E_2 Z_104 C_0 Z_105 
Stack 6
I_2 H_0 Z_106 Z_107 
Stack 7
Z_108 I_3 A_2 Z_109 
Stack 8
D_3 Z_110 D_2 Z_111 
Stack 9
G_1 Z_112 Z_113 G_3 
Stack 10
I_0 G_2 F_3 E_1 
Stack 11
A_1 F_2 G_0 
Stack 12
J_1 Z_114 E_4 
