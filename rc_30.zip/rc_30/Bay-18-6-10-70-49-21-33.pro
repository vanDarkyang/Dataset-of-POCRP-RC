Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 Z_101 D_1 J_3 
Stack 1
Z_102 F_6 B_3 H_1 
Stack 2
D_2 E_4 I_2 Z_103 
Stack 3
G_1 C_3 Z_104 B_4 
Stack 4
Z_105 I_0 H_3 G_3 
Stack 5
F_4 J_0 I_1 Z_106 
Stack 6
Z_107 E_5 G_5 C_1 
Stack 7
C_5 C_4 C_2 D_3 
Stack 8
Z_108 Z_109 E_1 E_0 
Stack 9
Z_110 Z_111 Z_112 J_2 
Stack 10
F_5 Z_113 H_2 Z_114 
Stack 11
E_2 Z_115 B_2 F_0 
Stack 12
Z_116 A_1 Z_117 I_3 
Stack 13
J_1 G_0 C_0 I_4 
Stack 14
F_2 F_1 Z_118 B_0 
Stack 15
G_2 Z_119 F_3 Z_120 
Stack 16
E_3 G_4 H_0 
Stack 17
A_0 B_1 D_0 
