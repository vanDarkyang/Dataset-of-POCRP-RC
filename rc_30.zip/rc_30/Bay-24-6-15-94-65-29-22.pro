Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
L_0 C_2 Z_100 G_5 
Stack 1
Z_101 J_2 Z_102 G_7 
Stack 2
A_1 C_1 K_5 Z_103 
Stack 3
Z_104 Z_105 Z_106 D_3 
Stack 4
Z_107 F_1 F_6 Z_108 
Stack 5
Z_109 F_4 F_0 Z_110 
Stack 6
Z_111 Z_112 Z_113 G_6 
Stack 7
H_3 Z_114 Z_115 O_1 
Stack 8
Z_116 K_0 Z_117 Z_118 
Stack 9
E_1 L_1 H_1 G_3 
Stack 10
D_2 Z_119 E_0 I_5 
Stack 11
J_1 C_0 Z_120 Z_121 
Stack 12
Z_122 K_4 B_2 D_1 
Stack 13
I_2 Z_123 I_6 N_0 
Stack 14
F_2 I_4 E_2 A_0 
Stack 15
C_3 H_2 G_1 M_2 
Stack 16
O_0 I_1 H_0 D_0 
Stack 17
J_4 M_0 D_4 J_0 
Stack 18
Z_124 A_2 I_3 G_4 
Stack 19
I_0 N_1 M_1 B_1 
Stack 20
B_0 J_3 Z_125 Z_126 
Stack 21
K_3 K_1 Z_127 F_5 
Stack 22
F_3 G_2 K_2 
Stack 23
G_0 Z_128 O_2 
