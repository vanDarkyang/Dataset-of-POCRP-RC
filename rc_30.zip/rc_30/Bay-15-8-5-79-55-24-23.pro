Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
B_10 E_9 D_2 Z_100 B_2 Z_101 
Stack 1
E_1 D_6 A_3 C_7 Z_102 B_0 
Stack 2
Z_103 B_5 A_2 D_4 D_1 D_9 
Stack 3
C_11 B_7 Z_104 C_1 E_7 B_4 
Stack 4
A_5 Z_105 D_8 Z_106 C_10 
Stack 5
E_6 C_13 A_0 C_4 Z_107 
Stack 6
B_9 Z_108 C_5 C_2 D_10 
Stack 7
D_5 E_3 Z_109 D_7 Z_110 
Stack 8
Z_111 Z_112 Z_113 D_11 Z_114 
Stack 9
E_8 E_4 C_12 C_3 D_0 
Stack 10
A_1 C_0 Z_115 B_6 B_11 
Stack 11
C_8 Z_116 Z_117 D_3 B_8 
Stack 12
Z_118 Z_119 E_10 E_0 B_3 
Stack 13
E_5 E_2 Z_120 Z_121 C_6 
Stack 14
B_1 C_9 Z_122 A_4 Z_123 
