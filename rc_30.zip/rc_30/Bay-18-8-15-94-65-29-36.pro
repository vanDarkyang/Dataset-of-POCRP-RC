Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 F_1 H_3 G_3 N_2 M_3 
Stack 1
Z_101 Z_102 Z_103 Z_104 I_0 L_2 
Stack 2
J_5 F_6 I_5 Z_105 M_2 D_2 
Stack 3
J_2 K_1 D_0 A_0 Z_106 B_0 
Stack 4
C_1 Z_107 M_1 Z_108 N_0 
Stack 5
H_2 Z_109 Z_110 K_0 Z_111 
Stack 6
E_0 Z_112 O_2 B_1 I_1 
Stack 7
I_4 Z_113 D_1 B_3 Z_114 
Stack 8
F_2 F_3 B_2 E_2 I_2 
Stack 9
F_5 J_0 N_3 K_4 C_0 
Stack 10
G_4 Z_115 G_1 J_1 C_3 
Stack 11
C_2 Z_116 J_4 Z_117 A_1 
Stack 12
Z_118 H_1 Z_119 K_2 N_1 
Stack 13
D_3 O_0 G_2 J_3 I_3 
Stack 14
G_0 L_3 F_0 Z_120 F_4 
Stack 15
Z_121 K_3 Z_122 Z_123 Z_124 
Stack 16
E_1 M_0 L_1 Z_125 Z_126 
Stack 17
L_0 O_1 Z_127 H_0 Z_128 
