Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
N_1 G_0 Z_100 J_1 
Stack 1
C_3 Z_101 Z_102 K_4 
Stack 2
G_2 H_1 Z_103 H_4 
Stack 3
F_0 N_0 K_5 L_1 
Stack 4
Z_104 E_0 F_4 Z_105 
Stack 5
D_2 Z_106 Z_107 A_0 
Stack 6
Z_108 Z_109 K_2 Z_110 
Stack 7
D_0 H_6 Z_111 Z_112 
Stack 8
F_3 J_2 C_0 Z_113 
Stack 9
L_0 I_5 H_5 C_1 
Stack 10
L_2 G_1 Z_114 Z_115 
Stack 11
I_0 I_6 K_0 Z_116 
Stack 12
G_4 B_1 E_1 G_3 
Stack 13
L_3 G_5 D_1 E_4 
Stack 14
I_2 Z_117 K_1 B_0 
Stack 15
Z_118 N_2 K_3 Z_119 
Stack 16
Z_120 J_0 D_4 D_3 
Stack 17
H_2 Z_121 I_3 O_0 
Stack 18
Z_122 A_1 E_3 J_3 
Stack 19
M_0 F_2 Z_123 Z_124 
Stack 20
H_0 Z_125 E_2 H_3 
Stack 21
O_1 I_4 G_6 I_1 
Stack 22
Z_126 Z_127 M_1 
Stack 23
C_2 Z_128 F_1 
