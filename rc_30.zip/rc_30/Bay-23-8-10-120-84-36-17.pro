Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 E_8 H_9 G_6 C_5 E_0 
Stack 1
B_6 F_7 Z_101 Z_102 B_5 I_6 
Stack 2
Z_103 I_0 Z_104 D_4 H_8 F_9 
Stack 3
D_5 H_3 I_1 E_4 Z_105 A_3 
Stack 4
J_0 E_2 D_2 F_1 H_6 J_2 
Stack 5
Z_106 H_4 D_1 Z_107 I_5 
Stack 6
Z_108 H_0 G_2 E_1 H_5 
Stack 7
B_0 D_3 J_5 A_6 Z_109 
Stack 8
B_3 D_8 D_6 A_0 F_0 
Stack 9
C_0 A_5 Z_110 A_7 D_0 
Stack 10
F_5 Z_111 E_6 Z_112 B_4 
Stack 11
Z_113 G_4 J_4 B_2 Z_114 
Stack 12
Z_115 E_5 E_7 I_4 G_3 
Stack 13
G_7 E_3 H_2 Z_116 Z_117 
Stack 14
Z_118 C_3 I_3 Z_119 Z_120 
Stack 15
Z_121 Z_122 C_4 I_7 C_1 
Stack 16
Z_123 Z_124 H_1 F_4 F_6 
Stack 17
F_2 G_0 Z_125 Z_126 C_2 
Stack 18
Z_127 I_2 Z_128 Z_129 J_3 
Stack 19
H_7 H_10 Z_130 F_8 J_1 
Stack 20
Z_131 F_3 D_7 G_1 Z_132 
Stack 21
Z_133 B_1 Z_134 B_7 Z_135 
Stack 22
A_2 G_5 A_4 J_6 A_1 
