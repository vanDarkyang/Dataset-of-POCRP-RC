Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 A_0 D_3 Z_101 B_12 E_6 
Stack 1
B_6 E_1 E_8 Z_102 B_11 C_4 
Stack 2
E_5 B_0 B_9 E_7 E_2 E_10 
Stack 3
B_10 A_3 A_7 D_1 B_8 Z_103 
Stack 4
A_2 A_6 D_4 Z_104 C_8 
Stack 5
A_5 Z_105 A_9 B_4 B_7 
Stack 6
Z_106 C_6 C_0 Z_107 Z_108 
Stack 7
E_0 Z_109 Z_110 Z_111 C_3 
Stack 8
Z_112 B_2 E_9 Z_113 E_3 
Stack 9
Z_114 Z_115 B_3 C_1 D_0 
Stack 10
Z_116 A_4 B_5 Z_117 C_15 
Stack 11
Z_118 C_10 Z_119 C_13 Z_120 
Stack 12
C_11 C_14 C_12 D_2 B_1 
Stack 13
C_7 Z_121 C_9 A_8 C_2 
Stack 14
C_5 Z_122 A_1 E_4 Z_123 
