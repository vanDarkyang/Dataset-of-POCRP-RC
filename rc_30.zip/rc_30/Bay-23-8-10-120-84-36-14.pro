Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 C_6 C_5 B_3 I_0 G_8 
Stack 1
B_0 E_0 E_7 Z_101 H_8 E_4 
Stack 2
Z_102 F_2 B_1 Z_103 D_2 Z_104 
Stack 3
H_6 F_7 F_6 Z_105 I_4 J_4 
Stack 4
I_5 Z_106 H_1 A_3 I_6 C_1 
Stack 5
J_7 Z_107 Z_108 Z_109 Z_110 
Stack 6
E_3 Z_111 H_4 B_2 F_4 
Stack 7
J_0 H_2 G_6 G_9 Z_112 
Stack 8
Z_113 E_1 C_2 C_8 J_3 
Stack 9
I_1 A_5 D_0 Z_114 B_4 
Stack 10
F_3 Z_115 G_4 Z_116 F_1 
Stack 11
E_6 Z_117 G_1 H_5 H_3 
Stack 12
E_8 Z_118 A_1 Z_119 I_7 
Stack 13
G_0 D_4 F_8 I_3 I_9 
Stack 14
F_0 Z_120 G_2 E_5 Z_121 
Stack 15
H_0 D_5 J_5 Z_122 Z_123 
Stack 16
Z_124 J_1 Z_125 A_2 Z_126 
Stack 17
C_0 E_2 C_7 G_10 G_7 
Stack 18
Z_127 Z_128 G_3 Z_129 G_5 
Stack 19
A_4 I_8 D_3 Z_130 E_9 
Stack 20
J_2 H_7 Z_131 Z_132 C_3 
Stack 21
F_9 A_0 J_6 Z_133 F_5 
Stack 22
I_2 Z_134 D_1 C_4 Z_135 
