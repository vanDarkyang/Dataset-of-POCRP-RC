Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_3 B_7 Z_100 C_2 
Stack 1
A_9 Z_101 B_1 Z_102 
Stack 2
D_4 Z_103 Z_104 B_0 
Stack 3
C_1 A_1 C_8 Z_105 
Stack 4
D_5 B_2 Z_106 B_5 
Stack 5
D_2 A_4 D_9 E_7 
Stack 6
D_3 Z_107 A_3 B_11 
Stack 7
Z_108 E_4 A_0 D_12 
Stack 8
B_4 Z_109 C_7 E_6 
Stack 9
D_0 Z_110 E_3 Z_111 
Stack 10
A_5 A_10 Z_112 B_6 
Stack 11
E_5 A_7 A_6 Z_113 
Stack 12
Z_114 Z_115 D_8 Z_116 
Stack 13
E_1 C_6 C_5 Z_117 
Stack 14
A_2 E_9 Z_118 B_3 
Stack 15
D_11 C_0 D_1 A_8 
Stack 16
B_9 Z_119 D_6 D_7 
Stack 17
D_10 Z_120 B_8 E_8 
Stack 18
Z_121 E_0 Z_122 E_2 
Stack 19
B_10 Z_123 C_4 
