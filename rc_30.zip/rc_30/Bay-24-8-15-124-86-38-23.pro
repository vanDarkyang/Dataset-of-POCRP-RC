Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
Z_100 L_4 H_6 L_2 D_3 D_4 
Stack 1
Z_101 H_3 D_6 Z_102 B_3 Z_103 
Stack 2
D_0 E_1 Z_104 Z_105 G_3 E_5 
Stack 3
Z_106 E_2 L_0 A_1 A_2 G_5 
Stack 4
N_1 K_0 E_3 Z_107 F_2 
Stack 5
J_1 F_0 Z_108 K_5 F_4 
Stack 6
D_5 K_1 D_2 Z_109 H_8 
Stack 7
J_4 E_4 Z_110 Z_111 Z_112 
Stack 8
E_0 G_0 M_1 O_1 M_5 
Stack 9
Z_113 M_4 G_6 Z_114 H_4 
Stack 10
O_2 K_3 I_3 K_4 I_2 
Stack 11
Z_115 I_1 Z_116 G_1 Z_117 
Stack 12
L_3 Z_118 I_0 A_4 Z_119 
Stack 13
Z_120 F_3 B_2 C_2 Z_121 
Stack 14
D_1 Z_122 Z_123 H_2 Z_124 
Stack 15
K_2 J_0 M_3 F_5 Z_125 
Stack 16
Z_126 B_1 Z_127 L_6 O_3 
Stack 17
Z_128 Z_129 J_3 F_1 Z_130 
Stack 18
M_2 B_0 Z_131 L_5 J_5 
Stack 19
A_3 H_7 N_0 G_4 Z_132 
Stack 20
G_2 G_8 M_0 H_5 B_4 
Stack 21
A_0 Z_133 Z_134 H_1 C_1 
Stack 22
Z_135 H_0 L_1 Z_136 J_2 
Stack 23
G_7 Z_137 N_2 C_0 O_0 
