Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
L_0 M_1 Z_100 Z_101 G_6 G_5 
Stack 1
K_3 I_0 H_4 Z_102 G_8 B_1 
Stack 2
A_1 Z_103 I_2 Z_104 Z_105 Z_106 
Stack 3
C_3 K_2 H_7 H_6 D_2 Z_107 
Stack 4
L_2 F_1 I_1 E_0 Z_108 
Stack 5
E_2 G_0 M_0 H_3 H_1 
Stack 6
H_0 C_2 A_2 B_2 G_7 
Stack 7
H_8 J_2 N_1 Z_109 Z_110 
Stack 8
Z_111 C_1 J_3 E_1 Z_112 
Stack 9
Z_113 L_3 Z_114 G_1 G_3 
Stack 10
D_1 Z_115 G_2 H_2 Z_116 
Stack 11
J_1 Z_117 B_0 D_3 H_9 
Stack 12
N_2 I_4 Z_118 Z_119 Z_120 
Stack 13
Z_121 Z_122 H_5 Z_123 N_0 
Stack 14
F_0 K_0 Z_124 L_1 A_0 
Stack 15
C_4 L_4 Z_125 I_3 M_2 
Stack 16
Z_126 G_4 Z_127 K_1 D_0 
Stack 17
J_4 C_0 Z_128 O_0 J_0 
