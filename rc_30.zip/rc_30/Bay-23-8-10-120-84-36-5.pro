Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
B_7 E_2 Z_100 Z_101 E_7 Z_102 
Stack 1
I_0 E_6 B_5 C_6 G_3 H_9 
Stack 2
D_3 J_1 E_8 C_0 F_0 G_8 
Stack 3
D_1 D_7 Z_103 Z_104 Z_105 H_6 
Stack 4
E_5 E_11 Z_106 F_4 B_2 A_0 
Stack 5
Z_107 B_6 C_5 C_3 F_1 
Stack 6
Z_108 I_2 F_7 G_6 Z_109 
Stack 7
F_8 G_10 E_1 I_3 H_2 
Stack 8
Z_110 Z_111 G_11 I_4 G_2 
Stack 9
B_1 Z_112 F_5 Z_113 Z_114 
Stack 10
F_6 Z_115 Z_116 Z_117 A_4 
Stack 11
Z_118 D_0 D_6 G_1 H_7 
Stack 12
E_10 D_5 J_0 E_3 H_1 
Stack 13
Z_119 Z_120 G_5 G_0 I_5 
Stack 14
Z_121 H_4 D_2 C_7 H_5 
Stack 15
G_4 E_9 D_8 C_1 A_2 
Stack 16
A_1 B_4 H_8 G_7 Z_122 
Stack 17
Z_123 F_2 Z_124 A_3 B_3 
Stack 18
Z_125 C_4 I_6 E_4 C_2 
Stack 19
H_0 Z_126 Z_127 Z_128 D_4 
Stack 20
Z_129 Z_130 Z_131 Z_132 B_0 
Stack 21
H_3 I_1 Z_133 D_9 Z_134 
Stack 22
Z_135 J_2 E_0 F_3 G_9 
