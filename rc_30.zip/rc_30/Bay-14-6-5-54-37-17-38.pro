Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
A_5 B_5 C_0 Z_100 
Stack 1
Z_101 Z_102 Z_103 B_0 
Stack 2
E_2 Z_104 B_1 B_3 
Stack 3
Z_105 C_5 E_4 Z_106 
Stack 4
Z_107 Z_108 A_2 Z_109 
Stack 5
D_6 Z_110 B_2 A_3 
Stack 6
B_8 E_5 Z_111 A_4 
Stack 7
C_3 C_2 D_2 E_6 
Stack 8
D_3 C_1 E_1 Z_112 
Stack 9
B_7 C_6 Z_113 D_0 
Stack 10
B_6 E_0 Z_114 D_5 
Stack 11
D_1 E_3 A_0 C_7 
Stack 12
Z_115 Z_116 C_4 
Stack 13
A_1 D_4 B_4 
