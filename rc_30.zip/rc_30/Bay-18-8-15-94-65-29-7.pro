Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
E_5 Z_100 I_0 E_3 B_0 H_6 
Stack 1
G_0 I_1 H_0 N_1 F_5 N_2 
Stack 2
Z_101 Z_102 K_0 I_4 O_0 Z_103 
Stack 3
H_3 Z_104 H_5 Z_105 L_0 Z_106 
Stack 4
I_3 C_3 Z_107 J_4 F_1 
Stack 5
C_1 K_3 D_3 E_1 I_7 
Stack 6
Z_108 G_3 C_2 E_0 J_2 
Stack 7
E_4 J_1 K_2 M_1 Z_109 
Stack 8
J_3 Z_110 E_6 A_1 Z_111 
Stack 9
Z_112 Z_113 L_2 G_4 Z_114 
Stack 10
Z_115 Z_116 K_4 F_2 H_2 
Stack 11
Z_117 E_2 M_0 D_2 H_1 
Stack 12
Z_118 L_1 Z_119 C_0 N_0 
Stack 13
Z_120 D_0 H_4 Z_121 Z_122 
Stack 14
I_6 Z_123 G_2 B_1 K_1 
Stack 15
A_0 F_3 I_5 G_5 Z_124 
Stack 16
D_1 Z_125 Z_126 F_0 I_2 
Stack 17
J_0 F_4 G_1 Z_127 Z_128 
