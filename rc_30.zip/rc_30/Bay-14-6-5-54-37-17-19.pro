Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 D_5 Z_101 D_3 
Stack 1
C_5 A_0 E_5 E_3 
Stack 2
C_6 Z_102 Z_103 Z_104 
Stack 3
D_2 C_4 E_0 B_3 
Stack 4
A_2 A_1 D_8 E_2 
Stack 5
A_5 D_6 C_8 Z_105 
Stack 6
D_1 E_4 Z_106 Z_107 
Stack 7
Z_108 Z_109 A_3 E_7 
Stack 8
Z_110 Z_111 C_1 Z_112 
Stack 9
C_0 B_0 C_3 B_4 
Stack 10
A_4 Z_113 Z_114 D_4 
Stack 11
B_1 C_2 E_1 D_0 
Stack 12
B_2 Z_115 C_7 
Stack 13
E_6 Z_116 D_7 
