Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_5 Z_100 C_2 Z_101 C_1 
Stack 1
Z_102 I_1 G_3 B_0 E_5 
Stack 2
Z_103 F_7 Z_104 Z_105 Z_106 
Stack 3
C_4 D_6 E_2 D_4 F_1 
Stack 4
J_2 F_2 A_2 D_1 H_2 
Stack 5
A_0 Z_107 E_4 A_1 Z_108 
Stack 6
D_0 B_3 I_2 D_3 C_0 
Stack 7
Z_109 D_2 F_6 C_3 B_1 
Stack 8
F_4 Z_110 Z_111 E_0 E_3 
Stack 9
E_6 Z_112 Z_113 F_0 H_1 
Stack 10
H_0 E_1 Z_114 Z_115 Z_116 
Stack 11
F_5 Z_117 J_1 G_2 Z_118 
Stack 12
J_0 H_3 F_3 H_4 Z_119 
Stack 13
B_2 G_0 I_0 Z_120 G_1 
