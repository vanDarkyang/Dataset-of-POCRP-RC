Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 M_2 Z_101 Z_102 
Stack 1
K_2 G_3 J_0 Z_103 
Stack 2
I_4 E_4 Z_104 B_1 
Stack 3
Z_105 Z_106 K_0 Z_107 
Stack 4
Z_108 D_4 Z_109 K_5 
Stack 5
A_2 Z_110 M_1 K_3 
Stack 6
D_3 G_2 F_1 H_5 
Stack 7
Z_111 Z_112 C_0 Z_113 
Stack 8
G_5 D_0 A_1 J_4 
Stack 9
H_6 G_4 B_0 H_2 
Stack 10
F_2 G_1 L_5 L_1 
Stack 11
Z_114 M_3 N_0 Z_115 
Stack 12
I_3 Z_116 K_6 L_0 
Stack 13
F_0 H_0 M_0 Z_117 
Stack 14
E_0 H_7 H_1 A_0 
Stack 15
I_1 I_0 Z_118 J_1 
Stack 16
E_1 Z_119 L_3 L_2 
Stack 17
E_2 Z_120 Z_121 D_1 
Stack 18
J_2 H_4 K_1 Z_122 
Stack 19
O_1 Z_123 J_5 Z_124 
Stack 20
D_2 Z_125 Z_126 Z_127 
Stack 21
J_3 L_4 I_2 E_3 
Stack 22
C_1 K_4 H_3 
Stack 23
O_0 Z_128 G_0 
