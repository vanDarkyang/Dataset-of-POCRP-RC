Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
E_3 F_6 Z_100 E_2 
Stack 1
Z_101 Z_102 Z_103 Z_104 
Stack 2
F_4 Z_105 F_5 A_2 
Stack 3
Z_106 D_1 Z_107 C_0 
Stack 4
E_0 Z_108 H_2 F_0 
Stack 5
C_3 B_0 Z_109 Z_110 
Stack 6
F_1 Z_111 J_0 Z_112 
Stack 7
C_1 Z_113 G_3 G_0 
Stack 8
C_2 A_0 F_3 G_1 
Stack 9
J_1 B_1 H_1 Z_114 
Stack 10
F_2 B_2 H_0 D_0 
Stack 11
G_4 G_2 E_1 
Stack 12
A_1 I_1 I_0 
