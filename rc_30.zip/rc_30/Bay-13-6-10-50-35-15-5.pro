Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 Z_101 F_1 Z_102 
Stack 1
D_2 H_3 Z_103 Z_104 
Stack 2
E_6 G_2 Z_105 Z_106 
Stack 3
J_0 F_2 C_1 D_4 
Stack 4
G_3 B_2 Z_107 I_0 
Stack 5
C_0 E_2 I_1 Z_108 
Stack 6
E_4 E_5 Z_109 Z_110 
Stack 7
D_1 D_3 Z_111 H_1 
Stack 8
H_2 Z_112 H_0 D_0 
Stack 9
C_2 G_1 F_3 G_0 
Stack 10
Z_113 Z_114 E_0 B_0 
Stack 11
F_0 E_1 B_1 
Stack 12
G_4 E_3 A_0 
