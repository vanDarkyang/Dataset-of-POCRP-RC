Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_2 Z_100 A_6 Z_101 Z_102 A_4 
Stack 1
C_4 D_6 E_6 C_6 E_2 Z_103 
Stack 2
B_3 Z_104 D_7 E_1 D_1 C_3 
Stack 3
C_0 B_2 C_7 C_8 B_8 C_10 
Stack 4
A_8 Z_105 B_9 Z_106 Z_107 
Stack 5
B_11 C_5 E_7 E_8 A_0 
Stack 6
Z_108 C_12 D_2 Z_109 B_4 
Stack 7
Z_110 Z_111 D_9 B_1 C_9 
Stack 8
B_6 B_10 D_5 B_0 Z_112 
Stack 9
Z_113 Z_114 A_3 B_5 E_3 
Stack 10
Z_115 B_7 E_0 Z_116 E_5 
Stack 11
D_10 E_4 D_4 D_3 A_1 
Stack 12
D_0 C_1 Z_117 Z_118 Z_119 
Stack 13
Z_120 C_11 A_7 D_8 Z_121 
Stack 14
C_2 A_5 Z_122 B_12 Z_123 
