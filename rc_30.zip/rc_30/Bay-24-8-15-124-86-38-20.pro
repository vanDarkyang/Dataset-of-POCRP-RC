Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
I_1 I_5 H_1 Z_100 M_3 N_1 
Stack 1
G_5 E_0 J_3 J_4 I_0 E_1 
Stack 2
Z_101 F_2 N_2 O_1 Z_102 H_8 
Stack 3
G_4 Z_103 K_4 A_1 Z_104 D_3 
Stack 4
L_1 I_4 Z_105 H_4 C_0 
Stack 5
H_10 I_3 Z_106 Z_107 Z_108 
Stack 6
Z_109 J_2 K_2 N_0 I_2 
Stack 7
Z_110 F_1 J_0 O_0 L_0 
Stack 8
G_3 Z_111 I_7 G_6 Z_112 
Stack 9
I_6 Z_113 Z_114 Z_115 F_0 
Stack 10
Z_116 B_4 M_0 J_1 Z_117 
Stack 11
M_1 L_2 E_3 Z_118 C_6 
Stack 12
Z_119 Z_120 F_6 L_3 G_2 
Stack 13
G_1 H_2 Z_121 K_1 D_1 
Stack 14
B_2 C_1 Z_122 E_2 Z_123 
Stack 15
L_4 J_6 Z_124 C_4 Z_125 
Stack 16
Z_126 G_0 Z_127 Z_128 Z_129 
Stack 17
F_4 L_5 C_3 D_0 J_5 
Stack 18
L_6 H_3 Z_130 H_6 O_2 
Stack 19
M_2 F_3 D_2 Z_131 Z_132 
Stack 20
F_5 B_1 H_9 Z_133 D_4 
Stack 21
K_0 H_0 Z_134 C_5 Z_135 
Stack 22
E_4 B_3 A_0 K_3 Z_136 
Stack 23
Z_137 C_2 H_7 B_0 H_5 
