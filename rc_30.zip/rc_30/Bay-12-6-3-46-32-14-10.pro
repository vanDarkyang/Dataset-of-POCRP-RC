Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_4 A_9 Z_100 B_7 
Stack 1
B_6 A_5 Z_101 B_0 
Stack 2
A_4 A_1 C_5 C_4 
Stack 3
Z_102 B_1 C_10 B_9 
Stack 4
A_7 C_2 B_8 Z_103 
Stack 5
B_2 B_10 Z_104 C_6 
Stack 6
C_9 C_3 C_7 A_3 
Stack 7
A_0 B_5 B_3 C_1 
Stack 8
C_8 Z_105 Z_106 Z_107 
Stack 9
A_2 Z_108 Z_109 Z_110 
Stack 10
Z_111 C_0 Z_112 
Stack 11
A_8 Z_113 A_6 
