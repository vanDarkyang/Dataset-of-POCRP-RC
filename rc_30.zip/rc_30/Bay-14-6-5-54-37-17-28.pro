Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_6 A_0 D_1 E_2 
Stack 1
C_0 B_4 E_5 E_4 
Stack 2
Z_100 Z_101 B_6 Z_102 
Stack 3
C_4 D_2 Z_103 C_3 
Stack 4
Z_104 D_3 E_6 E_7 
Stack 5
Z_105 Z_106 E_1 B_3 
Stack 6
A_5 A_1 Z_107 A_7 
Stack 7
Z_108 C_2 Z_109 Z_110 
Stack 8
A_3 Z_111 B_1 A_6 
Stack 9
C_5 E_8 Z_112 B_0 
Stack 10
C_1 B_5 Z_113 E_3 
Stack 11
B_2 D_0 E_0 A_2 
Stack 12
Z_114 D_5 Z_115 
Stack 13
Z_116 A_4 D_4 
