Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_8 E_1 A_5 E_0 
Stack 1
Z_100 Z_101 Z_102 E_2 
Stack 2
C_11 B_5 Z_103 E_3 
Stack 3
E_8 C_5 Z_104 D_0 
Stack 4
A_10 C_0 Z_105 E_10 
Stack 5
Z_106 C_2 Z_107 C_3 
Stack 6
A_6 B_7 E_6 Z_108 
Stack 7
D_6 D_7 Z_109 Z_110 
Stack 8
Z_111 Z_112 E_7 B_8 
Stack 9
B_2 Z_113 A_4 A_1 
Stack 10
A_9 A_7 Z_114 B_9 
Stack 11
D_3 D_2 C_7 B_4 
Stack 12
E_5 Z_115 B_1 D_8 
Stack 13
Z_116 D_9 Z_117 C_4 
Stack 14
B_0 A_3 Z_118 D_1 
Stack 15
E_9 Z_119 B_6 C_6 
Stack 16
A_2 A_0 E_4 Z_120 
Stack 17
D_4 Z_121 C_9 D_10 
Stack 18
C_10 C_8 D_5 Z_122 
Stack 19
B_3 C_1 Z_123 
