Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_3 D_9 A_10 D_8 C_2 A_7 
Stack 1
A_9 Z_100 Z_101 A_3 Z_102 D_5 
Stack 2
D_2 Z_103 D_10 Z_104 B_0 E_7 
Stack 3
C_1 C_12 Z_105 Z_106 C_8 E_1 
Stack 4
D_3 Z_107 E_8 E_3 B_6 
Stack 5
Z_108 B_7 Z_109 Z_110 Z_111 
Stack 6
D_1 Z_112 C_11 A_6 B_8 
Stack 7
C_9 D_7 Z_113 D_6 Z_114 
Stack 8
B_4 A_0 Z_115 C_6 E_6 
Stack 9
D_0 B_2 Z_116 C_10 C_7 
Stack 10
A_5 A_4 Z_117 Z_118 Z_119 
Stack 11
Z_120 A_1 B_1 D_4 E_2 
Stack 12
B_5 E_4 Z_121 Z_122 B_9 
Stack 13
E_0 A_8 C_13 C_5 B_3 
Stack 14
A_2 E_5 C_0 C_4 Z_123 
