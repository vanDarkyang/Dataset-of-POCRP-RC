Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 B_10 B_7 A_1 
Stack 1
Z_101 C_6 B_3 A_5 
Stack 2
C_5 D_1 B_14 C_2 
Stack 3
B_8 E_2 A_7 Z_102 
Stack 4
C_7 Z_103 E_5 Z_104 
Stack 5
D_6 C_4 C_3 A_0 
Stack 6
C_8 A_6 B_4 Z_105 
Stack 7
B_6 B_11 Z_106 Z_107 
Stack 8
D_4 C_9 Z_108 Z_109 
Stack 9
Z_110 Z_111 B_1 C_11 
Stack 10
B_9 C_1 Z_112 D_10 
Stack 11
A_3 Z_113 E_6 B_5 
Stack 12
B_0 D_5 Z_114 Z_115 
Stack 13
D_3 E_8 D_9 Z_116 
Stack 14
D_2 E_7 B_2 C_0 
Stack 15
B_12 C_10 E_4 E_0 
Stack 16
D_8 B_13 Z_117 D_0 
Stack 17
Z_118 E_1 D_7 A_2 
Stack 18
E_3 Z_119 Z_120 A_4 
Stack 19
Z_121 Z_122 Z_123 
