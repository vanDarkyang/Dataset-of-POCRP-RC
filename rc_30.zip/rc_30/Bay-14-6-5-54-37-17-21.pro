Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 A_9 B_5 Z_101 
Stack 1
D_6 E_4 Z_102 A_0 
Stack 2
A_1 Z_103 A_5 Z_104 
Stack 3
Z_105 B_0 A_2 E_6 
Stack 4
Z_106 C_4 E_5 E_2 
Stack 5
B_2 E_1 D_5 B_4 
Stack 6
C_1 C_5 C_2 Z_107 
Stack 7
E_0 E_3 D_0 A_7 
Stack 8
Z_108 B_3 Z_109 Z_110 
Stack 9
Z_111 Z_112 D_2 Z_113 
Stack 10
A_6 Z_114 A_3 D_3 
Stack 11
A_8 A_4 Z_115 D_4 
Stack 12
D_7 B_1 D_1 
Stack 13
C_0 Z_116 C_3 
