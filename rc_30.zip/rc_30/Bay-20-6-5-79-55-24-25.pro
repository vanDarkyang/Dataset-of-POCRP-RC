Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
A_7 Z_100 D_4 D_2 
Stack 1
E_8 E_7 Z_101 B_9 
Stack 2
B_0 Z_102 B_10 E_9 
Stack 3
E_3 Z_103 A_6 Z_104 
Stack 4
C_2 Z_105 D_5 Z_106 
Stack 5
A_2 C_9 C_10 B_1 
Stack 6
B_11 B_8 B_3 Z_107 
Stack 7
A_3 A_8 A_0 B_7 
Stack 8
C_0 Z_108 Z_109 E_5 
Stack 9
Z_110 C_3 B_2 C_4 
Stack 10
A_9 Z_111 D_0 Z_112 
Stack 11
Z_113 Z_114 C_13 E_1 
Stack 12
Z_115 B_4 Z_116 C_5 
Stack 13
C_7 A_1 E_6 E_2 
Stack 14
D_1 Z_117 D_7 B_6 
Stack 15
Z_118 E_0 Z_119 C_12 
Stack 16
A_5 C_11 Z_120 C_6 
Stack 17
D_3 E_4 A_10 D_6 
Stack 18
C_8 C_1 Z_121 Z_122 
Stack 19
B_5 A_4 Z_123 
