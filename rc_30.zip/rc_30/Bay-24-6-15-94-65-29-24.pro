Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
M_4 G_2 G_0 F_2 
Stack 1
K_1 L_4 H_0 Z_100 
Stack 2
N_0 G_5 F_3 Z_101 
Stack 3
Z_102 Z_103 I_3 Z_104 
Stack 4
C_0 Z_105 D_4 M_3 
Stack 5
B_2 Z_106 C_1 A_0 
Stack 6
M_0 G_4 J_3 Z_107 
Stack 7
Z_108 Z_109 J_0 L_0 
Stack 8
Z_110 E_2 M_1 L_1 
Stack 9
O_2 J_2 O_0 G_7 
Stack 10
Z_111 F_1 D_1 E_1 
Stack 11
I_4 E_3 Z_112 O_1 
Stack 12
H_1 Z_113 D_3 N_2 
Stack 13
L_3 Z_114 N_1 Z_115 
Stack 14
M_2 H_2 I_5 Z_116 
Stack 15
Z_117 I_1 E_0 G_6 
Stack 16
H_3 B_1 J_4 H_5 
Stack 17
Z_118 F_0 K_0 D_2 
Stack 18
Z_119 I_0 Z_120 J_5 
Stack 19
Z_121 I_2 L_2 Z_122 
Stack 20
Z_123 Z_124 Z_125 F_5 
Stack 21
H_4 D_0 Z_126 G_3 
Stack 22
J_1 B_0 Z_127 
Stack 23
F_4 Z_128 G_1 
