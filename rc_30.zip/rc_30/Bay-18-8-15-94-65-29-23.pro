Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
I_0 F_2 J_3 A_1 C_3 G_3 
Stack 1
Z_100 M_4 H_1 C_2 H_7 A_2 
Stack 2
Z_101 J_2 Z_102 C_1 Z_103 C_0 
Stack 3
N_0 I_6 I_3 D_2 Z_104 F_1 
Stack 4
Z_105 Z_106 Z_107 Z_108 M_2 
Stack 5
H_0 Z_109 Z_110 Z_111 O_1 
Stack 6
Z_112 Z_113 Z_114 F_3 H_5 
Stack 7
H_2 Z_115 O_0 G_2 E_5 
Stack 8
B_0 L_1 H_4 Z_116 M_1 
Stack 9
G_1 K_4 Z_117 J_0 K_1 
Stack 10
D_0 B_1 Z_118 Z_119 F_0 
Stack 11
Z_120 I_2 H_6 A_0 I_1 
Stack 12
E_4 H_3 K_0 Z_121 L_2 
Stack 13
K_3 D_1 K_2 J_1 Z_122 
Stack 14
E_1 Z_123 Z_124 L_0 E_0 
Stack 15
B_2 G_4 Z_125 Z_126 M_0 
Stack 16
E_3 I_4 G_0 J_4 I_5 
Stack 17
E_2 G_5 Z_127 M_3 Z_128 
