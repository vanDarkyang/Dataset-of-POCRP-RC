Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
A_0 Z_100 Z_101 J_2 F_3 
Stack 1
H_2 D_0 G_0 Z_102 A_2 
Stack 2
Z_103 C_2 Z_104 Z_105 F_2 
Stack 3
D_2 C_3 A_1 F_0 B_1 
Stack 4
I_0 F_1 B_0 C_4 E_0 
Stack 5
E_1 Z_106 C_0 Z_107 D_1 
Stack 6
F_4 E_3 Z_108 H_1 J_1 
Stack 7
I_1 C_1 H_0 Z_109 Z_110 
Stack 8
Z_111 Z_112 G_3 B_2 J_0 
Stack 9
E_2 G_2 Z_113 G_1 Z_114 
