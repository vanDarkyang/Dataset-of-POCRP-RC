Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_6 E_5 C_9 D_0 A_5 B_6 
Stack 1
B_3 D_4 Z_100 B_8 E_6 Z_101 
Stack 2
Z_102 E_1 E_3 Z_103 C_2 Z_104 
Stack 3
Z_105 A_4 D_6 C_5 B_9 B_7 
Stack 4
A_10 E_7 A_8 Z_106 Z_107 
Stack 5
A_3 Z_108 Z_109 A_1 E_9 
Stack 6
Z_110 Z_111 D_3 Z_112 E_8 
Stack 7
Z_113 B_1 B_10 C_11 B_4 
Stack 8
C_4 Z_114 C_10 A_6 B_2 
Stack 9
C_1 A_2 A_0 C_7 D_1 
Stack 10
E_0 D_7 Z_115 E_4 Z_116 
Stack 11
Z_117 Z_118 A_9 C_3 C_8 
Stack 12
D_2 C_0 C_12 Z_119 Z_120 
Stack 13
A_11 Z_121 B_0 B_5 D_5 
Stack 14
E_2 C_13 A_7 Z_122 Z_123 
