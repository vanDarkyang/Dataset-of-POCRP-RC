Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
I_2 Z_100 E_2 H_2 Z_101 
Stack 1
C_2 I_0 H_3 F_3 G_2 
Stack 2
Z_102 E_0 Z_103 H_0 Z_104 
Stack 3
Z_105 G_3 G_1 G_0 D_2 
Stack 4
F_0 Z_106 Z_107 Z_108 J_1 
Stack 5
Z_109 C_0 A_2 C_1 D_4 
Stack 6
F_4 A_1 Z_110 B_0 Z_111 
Stack 7
F_1 H_1 Z_112 I_1 J_0 
Stack 8
F_2 D_1 C_3 E_1 Z_113 
Stack 9
A_0 B_1 Z_114 D_3 D_0 
