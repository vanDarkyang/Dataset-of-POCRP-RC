Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
I_1 Z_100 F_1 A_5 Z_101 E_5 
Stack 1
D_2 A_1 Z_102 F_2 Z_103 Z_104 
Stack 2
E_3 C_7 G_1 H_5 Z_105 H_2 
Stack 3
Z_106 C_3 A_2 H_0 H_4 J_5 
Stack 4
J_6 D_5 G_0 Z_107 Z_108 I_4 
Stack 5
C_0 E_1 I_0 I_5 A_6 
Stack 6
E_6 Z_109 D_4 I_3 J_1 
Stack 7
E_4 Z_110 C_4 F_7 D_6 
Stack 8
F_3 Z_111 A_4 Z_112 B_4 
Stack 9
Z_113 Z_114 Z_115 A_3 D_0 
Stack 10
F_9 D_8 B_0 G_7 A_0 
Stack 11
Z_116 Z_117 Z_118 I_2 E_7 
Stack 12
Z_119 F_5 F_0 G_2 J_4 
Stack 13
D_1 H_3 Z_120 G_6 Z_121 
Stack 14
F_6 J_0 H_6 C_9 B_3 
Stack 15
G_4 Z_122 Z_123 C_2 G_3 
Stack 16
E_9 Z_124 G_5 B_5 J_2 
Stack 17
Z_125 Z_126 B_6 E_2 Z_127 
Stack 18
E_8 B_8 C_8 C_5 C_1 
Stack 19
F_4 Z_128 D_7 J_3 Z_129 
Stack 20
Z_130 F_8 E_0 B_2 Z_131 
Stack 21
Z_132 Z_133 B_1 Z_134 H_1 
Stack 22
C_6 B_7 G_8 Z_135 D_3 
