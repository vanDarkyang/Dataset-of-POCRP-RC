Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
C_6 B_0 D_6 E_0 Z_100 
Stack 1
Z_101 D_5 Z_102 B_2 Z_103 
Stack 2
Z_104 B_5 C_3 B_4 Z_105 
Stack 3
C_7 B_3 Z_106 C_1 Z_107 
Stack 4
D_2 E_4 C_0 C_4 Z_108 
Stack 5
A_5 A_0 Z_109 D_4 Z_110 
Stack 6
D_1 C_2 A_4 A_2 B_8 
Stack 7
E_1 E_3 D_3 B_1 Z_111 
Stack 8
A_6 C_5 Z_112 B_7 A_3 
Stack 9
B_6 E_5 Z_113 Z_114 E_2 
Stack 10
A_1 D_0 Z_115 Z_116 
