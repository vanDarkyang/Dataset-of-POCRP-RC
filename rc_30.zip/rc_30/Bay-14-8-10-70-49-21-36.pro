Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
D_1 C_1 D_3 C_0 A_3 
Stack 1
Z_100 G_3 Z_101 A_0 Z_102 
Stack 2
D_6 H_0 B_2 C_4 B_0 
Stack 3
J_4 Z_103 Z_104 Z_105 H_5 
Stack 4
C_3 Z_106 Z_107 I_1 Z_108 
Stack 5
E_1 F_3 B_1 Z_109 C_5 
Stack 6
H_1 B_3 E_4 E_2 Z_110 
Stack 7
Z_111 Z_112 F_4 Z_113 A_1 
Stack 8
F_0 Z_114 D_4 E_0 Z_115 
Stack 9
J_3 Z_116 Z_117 Z_118 G_4 
Stack 10
J_2 Z_119 D_0 I_0 D_5 
Stack 11
A_2 J_0 F_2 H_3 E_3 
Stack 12
Z_120 C_2 F_1 G_0 H_4 
Stack 13
J_1 D_2 G_2 H_2 G_1 
