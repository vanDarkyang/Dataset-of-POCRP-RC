Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 B_2 H_3 Z_101 J_4 Z_102 
Stack 1
Z_103 A_6 Z_104 G_3 D_0 F_6 
Stack 2
H_6 J_5 J_0 B_4 Z_105 Z_106 
Stack 3
Z_107 F_9 Z_108 I_5 B_1 B_7 
Stack 4
C_4 C_6 I_4 Z_109 C_9 F_5 
Stack 5
F_0 E_1 E_4 E_6 B_0 
Stack 6
Z_110 Z_111 H_4 C_7 C_8 
Stack 7
Z_112 G_2 I_3 F_10 Z_113 
Stack 8
Z_114 A_1 E_7 I_1 B_5 
Stack 9
I_7 Z_115 A_5 Z_116 Z_117 
Stack 10
D_5 G_0 B_3 D_2 Z_118 
Stack 11
D_3 Z_119 I_0 Z_120 Z_121 
Stack 12
C_1 D_4 A_0 E_0 F_1 
Stack 13
J_1 Z_122 Z_123 G_7 J_3 
Stack 14
G_4 Z_124 D_6 I_2 A_4 
Stack 15
C_3 D_7 Z_125 Z_126 C_0 
Stack 16
B_6 A_3 G_6 C_5 H_5 
Stack 17
G_1 C_2 Z_127 Z_128 I_6 
Stack 18
Z_129 Z_130 F_2 F_4 H_2 
Stack 19
G_8 F_8 A_2 I_8 F_3 
Stack 20
Z_131 Z_132 Z_133 Z_134 H_0 
Stack 21
D_1 Z_135 F_7 E_2 H_7 
Stack 22
H_1 J_2 G_5 E_3 E_5 
