Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
C_0 H_5 Z_100 F_0 D_0 B_2 
Stack 1
D_9 Z_101 Z_102 Z_103 Z_104 E_8 
Stack 2
E_1 C_7 F_4 H_2 I_3 D_4 
Stack 3
I_0 I_4 Z_105 Z_106 Z_107 G_9 
Stack 4
B_5 G_7 I_2 H_4 F_3 Z_108 
Stack 5
Z_109 E_6 Z_110 Z_111 H_3 
Stack 6
H_0 J_2 Z_112 Z_113 D_8 
Stack 7
F_9 B_4 D_1 G_0 I_6 
Stack 8
G_8 C_6 Z_114 Z_115 Z_116 
Stack 9
C_2 G_3 E_0 H_6 C_4 
Stack 10
Z_117 Z_118 Z_119 Z_120 J_3 
Stack 11
F_6 F_2 Z_121 E_2 B_6 
Stack 12
E_3 Z_122 Z_123 Z_124 C_8 
Stack 13
I_5 H_8 G_4 I_1 A_2 
Stack 14
F_1 D_5 A_3 G_6 A_0 
Stack 15
F_5 A_1 Z_125 Z_126 E_7 
Stack 16
B_1 E_5 C_3 J_4 Z_127 
Stack 17
D_2 Z_128 Z_129 D_3 D_7 
Stack 18
B_0 Z_130 G_1 Z_131 Z_132 
Stack 19
Z_133 A_5 F_8 H_1 Z_134 
Stack 20
C_1 J_1 E_4 G_5 F_7 
Stack 21
C_5 B_7 H_7 A_4 G_2 
Stack 22
Z_135 B_3 J_0 J_5 D_6 
