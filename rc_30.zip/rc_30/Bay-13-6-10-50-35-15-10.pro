Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
A_1 Z_100 E_2 B_1 
Stack 1
Z_101 Z_102 H_1 I_1 
Stack 2
B_2 G_1 Z_103 G_0 
Stack 3
D_5 F_0 F_3 I_0 
Stack 4
C_1 J_1 F_2 G_2 
Stack 5
Z_104 D_1 A_0 H_0 
Stack 6
Z_105 Z_106 Z_107 Z_108 
Stack 7
A_2 B_0 Z_109 D_3 
Stack 8
D_4 Z_110 D_0 F_4 
Stack 9
F_1 H_2 F_5 F_6 
Stack 10
Z_111 D_2 E_0 E_1 
Stack 11
Z_112 G_3 Z_113 
Stack 12
Z_114 J_0 C_0 
