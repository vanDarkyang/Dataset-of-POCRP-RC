Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_4 Z_100 D_5 Z_101 
Stack 1
Z_102 E_5 C_2 B_9 
Stack 2
B_0 A_0 E_0 Z_103 
Stack 3
Z_104 D_3 D_6 D_4 
Stack 4
A_4 Z_105 D_1 C_3 
Stack 5
C_5 Z_106 B_1 E_2 
Stack 6
A_6 Z_107 A_3 B_7 
Stack 7
C_4 Z_108 D_2 B_5 
Stack 8
Z_109 Z_110 C_0 E_4 
Stack 9
B_6 Z_111 A_5 B_8 
Stack 10
Z_112 C_1 Z_113 Z_114 
Stack 11
B_2 Z_115 E_1 A_2 
Stack 12
B_3 A_1 E_3 
Stack 13
D_0 C_6 Z_116 
