Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
E_1 J_1 Z_100 Z_101 Z_102 
Stack 1
C_2 Z_103 G_1 A_1 A_2 
Stack 2
B_0 G_2 Z_104 Z_105 F_1 
Stack 3
Z_106 D_0 F_0 C_3 Z_107 
Stack 4
I_0 E_2 Z_108 F_3 E_0 
Stack 5
A_0 Z_109 G_0 B_1 H_3 
Stack 6
I_2 I_1 Z_110 Z_111 H_2 
Stack 7
D_3 D_1 Z_112 C_0 H_0 
Stack 8
C_1 E_3 B_2 D_2 Z_113 
Stack 9
F_2 E_4 H_1 Z_114 J_0 
