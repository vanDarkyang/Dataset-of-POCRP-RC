Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 C_8 A_0 B_3 
Stack 1
Z_101 C_4 Z_102 D_10 
Stack 2
A_8 E_0 E_9 D_3 
Stack 3
C_6 Z_103 E_7 Z_104 
Stack 4
A_11 E_1 Z_105 C_5 
Stack 5
E_3 C_0 Z_106 Z_107 
Stack 6
B_9 Z_108 Z_109 Z_110 
Stack 7
D_6 D_0 D_5 Z_111 
Stack 8
B_2 Z_112 C_1 A_3 
Stack 9
E_5 Z_113 A_9 D_1 
Stack 10
A_6 D_4 Z_114 Z_115 
Stack 11
Z_116 Z_117 Z_118 Z_119 
Stack 12
A_4 A_7 D_8 B_4 
Stack 13
E_2 A_1 D_12 C_3 
Stack 14
B_1 D_9 C_2 D_2 
Stack 15
E_8 A_5 B_7 B_10 
Stack 16
D_7 Z_120 Z_121 B_0 
Stack 17
B_6 Z_122 Z_123 D_11 
Stack 18
B_8 A_2 E_4 B_5 
Stack 19
E_6 C_7 A_10 
