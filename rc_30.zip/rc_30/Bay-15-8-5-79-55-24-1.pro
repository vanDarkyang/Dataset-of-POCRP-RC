Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
C_12 B_7 Z_100 A_5 B_9 Z_101 
Stack 1
Z_102 E_3 C_8 B_6 Z_103 Z_104 
Stack 2
C_3 Z_105 Z_106 A_0 E_2 E_1 
Stack 3
Z_107 A_6 E_6 B_5 Z_108 D_3 
Stack 4
E_4 Z_109 D_5 Z_110 E_8 
Stack 5
B_4 A_1 Z_111 Z_112 A_8 
Stack 6
B_10 C_10 Z_113 D_1 D_0 
Stack 7
B_3 C_0 B_0 C_6 D_7 
Stack 8
C_5 E_10 C_4 Z_114 Z_115 
Stack 9
C_9 C_7 B_1 B_2 B_8 
Stack 10
A_7 D_10 C_1 Z_116 D_2 
Stack 11
E_7 E_9 C_11 Z_117 Z_118 
Stack 12
Z_119 Z_120 D_4 D_6 A_3 
Stack 13
Z_121 A_4 C_2 E_5 D_8 
Stack 14
E_0 Z_122 Z_123 A_2 D_9 
