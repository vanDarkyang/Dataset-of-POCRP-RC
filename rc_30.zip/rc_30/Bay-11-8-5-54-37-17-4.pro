Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_3 D_5 D_6 B_6 E_4 
Stack 1
E_6 D_2 Z_100 D_4 C_0 
Stack 2
A_6 Z_101 B_0 Z_102 C_5 
Stack 3
E_5 Z_103 A_0 Z_104 E_2 
Stack 4
Z_105 C_6 A_5 C_3 Z_106 
Stack 5
A_7 A_1 B_4 Z_107 E_1 
Stack 6
Z_108 Z_109 A_3 B_5 D_1 
Stack 7
Z_110 Z_111 Z_112 B_1 C_4 
Stack 8
C_2 C_1 Z_113 D_7 A_4 
Stack 9
B_3 A_2 B_2 Z_114 Z_115 
Stack 10
Z_116 D_0 D_3 E_0 
