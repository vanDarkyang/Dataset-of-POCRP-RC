Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
I_6 L_4 Z_100 Z_101 E_4 Z_102 
Stack 1
C_1 Z_103 Z_104 F_4 L_3 B_1 
Stack 2
F_2 I_4 L_0 F_1 C_0 D_0 
Stack 3
E_5 I_1 Z_105 L_2 H_2 Z_106 
Stack 4
Z_107 I_5 H_4 M_0 Z_108 
Stack 5
B_2 J_2 K_3 Z_109 E_1 
Stack 6
Z_110 N_2 K_2 G_4 F_0 
Stack 7
Z_111 H_0 Z_112 G_6 I_3 
Stack 8
Z_113 Z_114 Z_115 Z_116 F_3 
Stack 9
D_4 E_0 E_3 D_1 Z_117 
Stack 10
I_7 H_1 K_1 M_2 A_1 
Stack 11
G_0 L_1 M_1 Z_118 N_0 
Stack 12
G_2 Z_119 G_5 Z_120 Z_121 
Stack 13
K_0 D_3 A_0 B_0 G_3 
Stack 14
J_0 E_2 Z_122 J_1 N_3 
Stack 15
N_1 O_0 O_1 G_1 Z_123 
Stack 16
D_2 H_3 Z_124 Z_125 I_0 
Stack 17
Z_126 Z_127 C_2 I_2 Z_128 
