Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
C_6 E_3 C_1 F_10 G_3 F_3 
Stack 1
F_7 C_5 H_8 Z_100 Z_101 Z_102 
Stack 2
Z_103 Z_104 A_3 H_3 I_3 E_4 
Stack 3
Z_105 Z_106 J_4 Z_107 B_5 J_5 
Stack 4
Z_108 F_11 Z_109 Z_110 Z_111 Z_112 
Stack 5
Z_113 G_9 Z_114 Z_115 H_6 
Stack 6
E_1 Z_116 Z_117 I_5 G_5 
Stack 7
Z_118 D_6 I_6 I_2 E_2 
Stack 8
B_6 D_5 D_1 I_4 D_4 
Stack 9
F_4 Z_119 E_7 F_9 G_8 
Stack 10
C_0 H_4 A_5 J_2 E_6 
Stack 11
H_5 J_0 Z_120 E_5 G_6 
Stack 12
H_0 F_12 Z_121 Z_122 E_0 
Stack 13
J_3 A_0 G_1 Z_123 Z_124 
Stack 14
Z_125 B_2 Z_126 D_9 Z_127 
Stack 15
F_8 F_2 I_1 F_6 Z_128 
Stack 16
F_1 G_7 D_3 F_5 Z_129 
Stack 17
B_0 H_1 J_1 H_9 A_2 
Stack 18
C_2 D_8 Z_130 Z_131 I_0 
Stack 19
D_0 Z_132 D_2 A_1 H_2 
Stack 20
B_1 B_3 A_4 H_7 C_4 
Stack 21
Z_133 G_2 G_0 C_3 D_7 
Stack 22
F_0 Z_134 B_4 Z_135 G_4 
