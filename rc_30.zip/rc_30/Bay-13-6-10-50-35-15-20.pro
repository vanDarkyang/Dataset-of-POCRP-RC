Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
F_1 E_0 Z_100 I_0 
Stack 1
Z_101 G_2 Z_102 H_1 
Stack 2
A_2 B_0 I_1 Z_103 
Stack 3
A_0 B_1 J_2 Z_104 
Stack 4
F_5 G_3 D_1 Z_105 
Stack 5
Z_106 E_1 D_0 J_0 
Stack 6
Z_107 F_0 G_1 C_1 
Stack 7
F_4 E_3 G_4 E_4 
Stack 8
G_0 E_2 J_1 D_2 
Stack 9
C_2 C_0 Z_108 Z_109 
Stack 10
Z_110 H_2 F_3 H_0 
Stack 11
Z_111 F_2 Z_112 
Stack 12
Z_113 Z_114 A_1 
