Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_2 Z_100 B_1 Z_101 
Stack 1
C_8 C_7 B_4 A_0 
Stack 2
C_1 B_8 Z_102 Z_103 
Stack 3
Z_104 Z_105 B_5 A_9 
Stack 4
C_2 Z_106 C_6 B_11 
Stack 5
A_10 B_7 C_5 A_7 
Stack 6
A_6 B_10 A_4 C_3 
Stack 7
C_0 A_8 Z_107 C_4 
Stack 8
B_6 A_3 Z_108 B_9 
Stack 9
B_3 Z_109 Z_110 A_2 
Stack 10
Z_111 A_1 B_0 
Stack 11
Z_112 Z_113 A_5 
