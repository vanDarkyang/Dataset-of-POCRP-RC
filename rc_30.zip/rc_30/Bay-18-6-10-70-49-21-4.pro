Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 Z_101 E_2 C_2 
Stack 1
F_3 C_0 J_2 G_6 
Stack 2
B_0 H_4 F_0 H_0 
Stack 3
Z_102 Z_103 Z_104 H_1 
Stack 4
E_5 Z_105 E_4 B_1 
Stack 5
E_1 G_1 B_2 G_3 
Stack 6
G_7 Z_106 E_6 C_3 
Stack 7
I_0 F_2 A_1 G_0 
Stack 8
G_2 A_2 A_3 Z_107 
Stack 9
J_3 H_2 E_0 F_1 
Stack 10
Z_108 Z_109 G_4 C_4 
Stack 11
F_5 C_1 Z_110 F_6 
Stack 12
F_4 Z_111 J_1 E_7 
Stack 13
J_4 J_0 Z_112 G_5 
Stack 14
Z_113 D_1 Z_114 E_3 
Stack 15
Z_115 Z_116 A_0 D_0 
Stack 16
H_3 Z_117 Z_118 
Stack 17
Z_119 Z_120 C_5 
