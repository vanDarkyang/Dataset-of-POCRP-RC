Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 D_6 D_3 J_2 E_6 Z_101 
Stack 1
C_6 Z_102 E_8 F_4 I_4 Z_103 
Stack 2
H_5 G_7 A_3 Z_104 E_0 F_6 
Stack 3
Z_105 A_0 Z_106 Z_107 Z_108 Z_109 
Stack 4
I_2 G_0 G_3 F_2 J_5 F_3 
Stack 5
F_5 I_1 A_4 D_1 D_2 
Stack 6
A_5 E_1 Z_110 J_3 J_7 
Stack 7
Z_111 I_0 Z_112 E_4 H_9 
Stack 8
Z_113 A_1 H_2 C_4 G_1 
Stack 9
Z_114 H_4 D_10 E_5 Z_115 
Stack 10
H_6 C_5 F_1 D_7 G_5 
Stack 11
A_2 C_0 Z_116 J_0 F_8 
Stack 12
E_7 E_2 B_6 G_6 D_0 
Stack 13
D_4 G_4 A_6 B_3 B_5 
Stack 14
Z_117 Z_118 H_1 B_0 B_4 
Stack 15
Z_119 Z_120 I_5 H_3 Z_121 
Stack 16
E_3 D_8 J_4 Z_122 G_2 
Stack 17
F_0 Z_123 Z_124 Z_125 D_5 
Stack 18
Z_126 H_7 B_7 Z_127 C_3 
Stack 19
Z_128 B_2 Z_129 Z_130 H_8 
Stack 20
C_1 I_3 Z_131 C_2 Z_132 
Stack 21
Z_133 Z_134 Z_135 F_7 H_0 
Stack 22
B_1 G_8 J_6 J_1 D_9 
