Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
F_4 J_0 D_2 F_0 A_1 
Stack 1
Z_100 F_1 Z_101 Z_102 Z_103 
Stack 2
E_4 G_4 G_1 H_0 Z_104 
Stack 3
Z_105 Z_106 I_0 J_1 I_1 
Stack 4
G_3 H_2 E_0 Z_107 G_0 
Stack 5
C_1 G_2 E_2 F_3 Z_108 
Stack 6
Z_109 Z_110 F_2 Z_111 H_1 
Stack 7
D_1 B_3 C_0 B_2 D_0 
Stack 8
Z_112 E_1 A_0 Z_113 Z_114 
Stack 9
C_3 E_3 C_2 B_1 B_0 
