Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
E_1 B_5 G_1 A_1 C_1 
Stack 1
H_0 G_3 Z_100 E_3 D_1 
Stack 2
Z_101 G_0 H_1 Z_102 I_2 
Stack 3
Z_103 C_2 F_3 A_2 I_1 
Stack 4
G_4 F_4 H_4 Z_104 Z_105 
Stack 5
Z_106 J_3 D_3 Z_107 F_0 
Stack 6
F_1 Z_108 C_0 J_0 B_0 
Stack 7
Z_109 E_2 G_2 C_3 Z_110 
Stack 8
F_5 I_4 B_2 Z_111 J_1 
Stack 9
Z_112 D_2 C_4 H_3 E_0 
Stack 10
B_1 I_0 D_0 Z_113 A_3 
Stack 11
Z_114 J_2 Z_115 I_3 F_2 
Stack 12
A_0 Z_116 E_4 Z_117 B_4 
Stack 13
Z_118 Z_119 B_3 Z_120 H_2 
