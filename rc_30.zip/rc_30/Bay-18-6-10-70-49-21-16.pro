Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 D_1 Z_101 J_3 
Stack 1
J_1 F_4 I_4 Z_102 
Stack 2
B_1 Z_103 Z_104 A_0 
Stack 3
E_1 I_2 J_2 H_1 
Stack 4
G_3 Z_105 Z_106 C_4 
Stack 5
J_0 Z_107 F_3 D_4 
Stack 6
Z_108 H_4 Z_109 D_5 
Stack 7
E_4 Z_110 B_3 E_2 
Stack 8
C_5 B_0 C_3 I_3 
Stack 9
H_3 G_0 Z_111 Z_112 
Stack 10
C_2 H_2 E_3 F_1 
Stack 11
Z_113 E_0 H_0 Z_114 
Stack 12
C_0 D_0 Z_115 Z_116 
Stack 13
I_0 Z_117 A_1 Z_118 
Stack 14
A_3 I_1 D_3 F_0 
Stack 15
B_2 G_2 A_2 Z_119 
Stack 16
C_1 G_1 D_2 
Stack 17
Z_120 I_5 F_2 
