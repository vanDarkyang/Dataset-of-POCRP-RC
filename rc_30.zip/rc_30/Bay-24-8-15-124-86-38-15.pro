Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
D_1 Z_100 F_5 J_0 I_1 Z_101 
Stack 1
G_1 Z_102 O_1 D_3 M_4 Z_103 
Stack 2
E_4 Z_104 K_3 Z_105 Z_106 D_6 
Stack 3
M_3 H_3 M_2 K_0 Z_107 L_1 
Stack 4
M_1 J_3 N_4 I_0 Z_108 
Stack 5
B_2 O_2 Z_109 Z_110 Z_111 
Stack 6
D_2 M_5 C_0 I_6 Z_112 
Stack 7
F_3 Z_113 Z_114 J_2 E_1 
Stack 8
A_0 H_7 H_5 J_5 G_4 
Stack 9
Z_115 D_7 Z_116 Z_117 G_0 
Stack 10
Z_118 N_2 Z_119 K_2 F_0 
Stack 11
Z_120 E_3 Z_121 Z_122 Z_123 
Stack 12
Z_124 G_3 G_2 D_4 I_2 
Stack 13
N_0 F_6 Z_125 O_0 G_5 
Stack 14
I_5 A_3 F_1 Z_126 H_6 
Stack 15
I_7 I_3 H_4 B_1 C_4 
Stack 16
L_5 L_3 Z_127 L_2 C_3 
Stack 17
Z_128 E_0 Z_129 D_0 M_0 
Stack 18
L_0 Z_130 K_1 A_2 J_1 
Stack 19
H_1 Z_131 K_4 Z_132 Z_133 
Stack 20
N_3 F_2 Z_134 N_1 Z_135 
Stack 21
Z_136 Z_137 H_0 A_1 E_2 
Stack 22
F_4 M_6 C_2 D_5 J_4 
Stack 23
L_4 I_4 C_1 H_2 B_0 
