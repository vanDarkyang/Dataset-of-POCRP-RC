Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
Z_100 Z_101 M_5 L_3 M_1 Z_102 
Stack 1
G_7 E_1 L_0 Z_103 Z_104 F_2 
Stack 2
I_1 I_8 Z_105 C_2 I_4 H_0 
Stack 3
C_4 Z_106 Z_107 M_4 I_5 Z_108 
Stack 4
J_0 G_1 M_6 Z_109 D_4 
Stack 5
B_0 Z_110 D_5 D_3 I_3 
Stack 6
E_0 Z_111 I_2 I_7 J_5 
Stack 7
O_0 N_2 H_4 E_3 G_5 
Stack 8
I_6 Z_112 Z_113 K_5 A_0 
Stack 9
Z_114 G_3 B_1 L_4 L_2 
Stack 10
Z_115 E_5 L_1 C_3 Z_116 
Stack 11
Z_117 Z_118 M_3 B_3 Z_119 
Stack 12
Z_120 Z_121 Z_122 M_2 G_8 
Stack 13
E_2 O_2 N_1 E_6 C_0 
Stack 14
F_1 I_0 Z_123 M_0 Z_124 
Stack 15
Z_125 J_4 D_6 L_5 Z_126 
Stack 16
K_3 Z_127 H_3 Z_128 J_6 
Stack 17
H_1 Z_129 N_3 Z_130 D_2 
Stack 18
Z_131 Z_132 J_3 Z_133 K_2 
Stack 19
H_2 Z_134 G_0 D_0 K_1 
Stack 20
G_6 Z_135 N_4 F_3 F_0 
Stack 21
K_0 O_1 N_0 C_1 K_4 
Stack 22
G_4 F_4 G_2 J_1 E_4 
Stack 23
J_2 D_1 B_2 Z_136 Z_137 
