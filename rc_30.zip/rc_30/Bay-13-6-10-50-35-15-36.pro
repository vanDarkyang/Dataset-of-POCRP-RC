Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 Z_101 H_3 G_1 
Stack 1
Z_102 F_1 H_0 F_3 
Stack 2
Z_103 D_2 Z_104 Z_105 
Stack 3
D_3 Z_106 E_3 Z_107 
Stack 4
I_0 C_1 J_2 B_1 
Stack 5
Z_108 Z_109 Z_110 E_0 
Stack 6
F_4 G_2 F_2 D_1 
Stack 7
Z_111 G_3 F_0 J_1 
Stack 8
H_2 G_0 Z_112 I_1 
Stack 9
E_4 Z_113 Z_114 J_0 
Stack 10
E_1 A_0 H_1 E_2 
Stack 11
D_0 B_0 D_4 
Stack 12
C_2 C_0 B_2 
