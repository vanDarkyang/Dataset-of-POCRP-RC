Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
A_1 E_3 Z_100 D_0 Z_101 
Stack 1
Z_102 B_2 Z_103 Z_104 I_5 
Stack 2
Z_105 C_1 A_0 G_5 Z_106 
Stack 3
D_3 F_2 J_0 I_3 A_2 
Stack 4
E_0 A_3 Z_107 A_4 C_0 
Stack 5
F_3 D_2 F_4 J_1 I_4 
Stack 6
G_0 H_1 Z_108 G_1 Z_109 
Stack 7
H_4 I_1 Z_110 B_1 D_1 
Stack 8
I_0 J_3 Z_111 H_2 J_2 
Stack 9
E_1 B_0 F_5 F_0 G_3 
Stack 10
E_2 Z_112 Z_113 F_1 D_4 
Stack 11
Z_114 G_2 G_4 E_4 B_3 
Stack 12
Z_115 I_2 B_4 Z_116 H_3 
Stack 13
Z_117 Z_118 Z_119 H_0 Z_120 
