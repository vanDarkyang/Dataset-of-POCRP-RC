Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
G_8 H_4 A_5 G_6 J_5 A_7 
Stack 1
Z_100 J_2 H_3 F_4 F_5 D_7 
Stack 2
Z_101 F_11 G_3 D_0 I_5 C_4 
Stack 3
C_0 C_6 B_1 I_4 D_1 J_3 
Stack 4
Z_102 Z_103 F_0 Z_104 Z_105 C_1 
Stack 5
C_3 A_1 C_8 Z_106 F_1 
Stack 6
A_4 D_3 I_3 B_0 Z_107 
Stack 7
Z_108 I_1 Z_109 Z_110 Z_111 
Stack 8
E_0 Z_112 G_7 F_2 A_3 
Stack 9
Z_113 G_4 H_1 Z_114 B_2 
Stack 10
C_5 B_4 C_9 Z_115 F_9 
Stack 11
E_2 E_3 Z_116 G_5 E_1 
Stack 12
B_7 G_0 B_5 Z_117 Z_118 
Stack 13
J_1 Z_119 A_0 F_8 F_10 
Stack 14
C_2 Z_120 Z_121 F_7 C_7 
Stack 15
E_5 G_2 Z_122 D_4 J_0 
Stack 16
Z_123 Z_124 Z_125 Z_126 E_7 
Stack 17
D_2 I_6 Z_127 I_2 D_5 
Stack 18
B_3 Z_128 Z_129 A_2 H_6 
Stack 19
J_6 Z_130 Z_131 F_3 H_5 
Stack 20
G_1 Z_132 B_6 I_0 F_6 
Stack 21
Z_133 J_4 E_6 E_4 Z_134 
Stack 22
H_2 A_6 D_6 Z_135 H_0 
