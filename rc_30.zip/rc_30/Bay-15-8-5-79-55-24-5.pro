Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 D_1 Z_101 C_6 D_9 Z_102 
Stack 1
Z_103 A_10 E_4 C_3 B_3 B_8 
Stack 2
B_0 A_0 Z_104 Z_105 C_1 E_3 
Stack 3
Z_106 C_5 A_7 Z_107 Z_108 A_4 
Stack 4
E_5 E_2 B_1 C_2 E_7 
Stack 5
B_5 Z_109 D_4 B_4 B_6 
Stack 6
D_5 A_8 Z_110 D_2 A_3 
Stack 7
B_9 A_6 Z_111 Z_112 E_9 
Stack 8
Z_113 Z_114 Z_115 D_6 Z_116 
Stack 9
B_7 C_10 Z_117 C_7 E_11 
Stack 10
Z_118 C_4 D_8 A_5 A_9 
Stack 11
Z_119 Z_120 Z_121 D_10 A_2 
Stack 12
E_1 Z_122 C_0 D_3 E_0 
Stack 13
A_1 E_6 E_8 C_8 E_10 
Stack 14
B_2 D_0 D_7 Z_123 C_9 
