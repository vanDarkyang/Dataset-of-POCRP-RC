Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
F_5 J_0 Z_100 L_1 
Stack 1
F_4 Z_101 Z_102 Z_103 
Stack 2
B_0 F_6 H_6 Z_104 
Stack 3
D_2 G_2 K_2 I_3 
Stack 4
M_1 Z_105 Z_106 H_0 
Stack 5
L_2 A_2 Z_107 I_2 
Stack 6
Z_108 C_2 I_4 G_6 
Stack 7
I_5 Z_109 H_2 E_0 
Stack 8
H_5 H_3 Z_110 D_3 
Stack 9
G_4 F_2 Z_111 D_1 
Stack 10
F_0 Z_112 Z_113 J_4 
Stack 11
Z_114 J_2 J_5 H_4 
Stack 12
F_1 Z_115 G_3 J_3 
Stack 13
G_8 Z_116 G_5 L_3 
Stack 14
E_1 Z_117 F_3 Z_118 
Stack 15
C_0 H_1 K_1 J_1 
Stack 16
N_0 Z_119 O_0 K_0 
Stack 17
A_1 M_0 E_2 K_3 
Stack 18
G_7 G_0 Z_120 Z_121 
Stack 19
C_1 I_1 Z_122 D_0 
Stack 20
E_3 J_6 Z_123 Z_124 
Stack 21
L_4 Z_125 A_0 E_4 
Stack 22
Z_126 Z_127 I_0 
Stack 23
Z_128 G_1 L_0 
