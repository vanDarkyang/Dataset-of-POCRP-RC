Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
E_4 Z_100 J_1 J_2 
Stack 1
C_4 A_1 B_3 J_3 
Stack 2
Z_101 I_3 I_2 G_4 
Stack 3
D_2 Z_102 I_0 Z_103 
Stack 4
Z_104 H_5 E_3 H_1 
Stack 5
Z_105 C_1 H_4 B_1 
Stack 6
Z_106 F_1 H_0 Z_107 
Stack 7
F_4 F_2 Z_108 Z_109 
Stack 8
F_0 D_3 J_0 Z_110 
Stack 9
E_0 H_3 G_1 G_2 
Stack 10
F_3 A_0 Z_111 C_0 
Stack 11
Z_112 E_2 Z_113 D_1 
Stack 12
Z_114 F_5 E_1 G_3 
Stack 13
C_2 B_0 G_0 I_1 
Stack 14
B_2 G_5 C_3 D_4 
Stack 15
Z_115 Z_116 B_4 Z_117 
Stack 16
D_0 Z_118 Z_119 
Stack 17
Z_120 E_5 H_2 
