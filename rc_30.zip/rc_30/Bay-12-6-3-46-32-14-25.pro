Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
A_1 Z_100 Z_101 Z_102 
Stack 1
C_8 A_7 B_3 Z_103 
Stack 2
Z_104 B_1 B_12 C_5 
Stack 3
A_8 B_4 Z_105 A_4 
Stack 4
C_3 C_1 A_9 Z_106 
Stack 5
Z_107 B_2 A_0 Z_108 
Stack 6
C_0 Z_109 B_6 B_5 
Stack 7
C_2 A_6 Z_110 C_7 
Stack 8
A_3 A_5 Z_111 B_0 
Stack 9
C_6 B_11 B_8 B_9 
Stack 10
Z_112 B_10 Z_113 
Stack 11
A_2 C_4 B_7 
