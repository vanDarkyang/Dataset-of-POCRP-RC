Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 D_0 E_3 Z_101 
Stack 1
C_2 E_0 E_2 F_0 
Stack 2
Z_102 J_1 B_1 Z_103 
Stack 3
Z_104 I_1 H_0 Z_105 
Stack 4
I_0 D_1 G_0 D_2 
Stack 5
A_0 E_1 A_1 Z_106 
Stack 6
I_2 E_4 C_1 Z_107 
Stack 7
D_3 F_1 C_3 H_1 
Stack 8
C_0 G_4 F_3 Z_108 
Stack 9
Z_109 G_1 B_0 Z_110 
Stack 10
Z_111 F_2 I_3 J_0 
Stack 11
Z_112 G_3 Z_113 
Stack 12
G_5 G_2 Z_114 
