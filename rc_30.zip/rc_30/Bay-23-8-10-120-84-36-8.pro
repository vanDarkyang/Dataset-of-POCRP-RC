Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
F_8 Z_100 C_2 D_2 Z_101 J_6 
Stack 1
Z_102 Z_103 B_0 H_0 A_1 I_2 
Stack 2
Z_104 Z_105 E_2 G_3 Z_106 F_1 
Stack 3
D_8 E_8 Z_107 I_7 G_2 A_5 
Stack 4
Z_108 I_8 C_10 Z_109 B_5 Z_110 
Stack 5
Z_111 Z_112 J_7 H_6 I_5 
Stack 6
Z_113 Z_114 Z_115 F_4 Z_116 
Stack 7
J_3 D_6 A_3 I_1 Z_117 
Stack 8
J_0 H_5 E_3 D_0 C_0 
Stack 9
C_7 J_4 E_4 B_3 Z_118 
Stack 10
I_0 H_2 Z_119 Z_120 C_6 
Stack 11
F_5 J_1 J_2 D_3 Z_121 
Stack 12
I_6 J_5 Z_122 Z_123 Z_124 
Stack 13
F_2 B_1 F_3 A_4 B_2 
Stack 14
F_10 D_5 Z_125 E_9 D_1 
Stack 15
Z_126 C_5 Z_127 C_4 G_4 
Stack 16
Z_128 D_7 H_4 E_1 F_7 
Stack 17
Z_129 G_0 C_3 G_5 C_8 
Stack 18
F_6 A_2 H_3 I_3 E_7 
Stack 19
E_6 Z_130 Z_131 F_9 E_5 
Stack 20
C_1 Z_132 E_0 D_4 I_4 
Stack 21
F_0 Z_133 Z_134 A_0 G_1 
Stack 22
A_6 H_1 B_4 Z_135 C_9 
