Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_6 Z_100 C_10 Z_101 
Stack 1
Z_102 B_3 Z_103 Z_104 
Stack 2
A_10 B_8 A_5 A_4 
Stack 3
Z_105 C_2 C_9 C_1 
Stack 4
Z_106 B_2 Z_107 A_1 
Stack 5
C_3 B_7 A_2 B_5 
Stack 6
B_0 C_6 Z_108 A_11 
Stack 7
A_3 A_0 C_5 B_1 
Stack 8
Z_109 C_4 A_7 Z_110 
Stack 9
Z_111 C_7 B_4 C_8 
Stack 10
Z_112 Z_113 C_0 
Stack 11
A_8 A_6 A_9 
