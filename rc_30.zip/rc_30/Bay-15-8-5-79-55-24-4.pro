Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
B_7 Z_100 C_2 Z_101 E_4 Z_102 
Stack 1
Z_103 C_8 C_5 B_9 D_11 Z_104 
Stack 2
A_3 Z_105 C_3 Z_106 Z_107 B_2 
Stack 3
A_2 A_4 D_7 C_1 B_3 E_3 
Stack 4
D_4 Z_108 D_14 B_6 B_13 
Stack 5
A_1 Z_109 B_1 E_5 Z_110 
Stack 6
Z_111 C_4 D_13 B_4 B_11 
Stack 7
Z_112 D_12 Z_113 E_8 D_6 
Stack 8
C_0 E_7 B_8 B_10 B_12 
Stack 9
Z_114 B_0 Z_115 D_10 C_7 
Stack 10
D_2 Z_116 E_6 Z_117 Z_118 
Stack 11
D_8 D_5 E_2 C_6 C_10 
Stack 12
A_5 Z_119 Z_120 D_0 Z_121 
Stack 13
Z_122 C_9 A_0 D_1 Z_123 
Stack 14
B_5 E_1 D_9 E_0 D_3 
