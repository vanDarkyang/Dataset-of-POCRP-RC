Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
L_0 G_5 D_0 G_0 
Stack 1
N_2 L_2 B_1 K_3 
Stack 2
Z_100 H_8 C_2 Z_101 
Stack 3
I_4 Z_102 E_1 A_0 
Stack 4
Z_103 H_3 F_2 Z_104 
Stack 5
G_3 Z_105 I_6 Z_106 
Stack 6
D_2 Z_107 G_1 M_1 
Stack 7
F_5 Z_108 Z_109 M_2 
Stack 8
O_1 I_2 Z_110 H_2 
Stack 9
Z_111 Z_112 L_4 J_0 
Stack 10
F_1 L_3 M_0 Z_113 
Stack 11
O_0 G_4 F_0 H_6 
Stack 12
F_3 L_1 D_1 Z_114 
Stack 13
Z_115 Z_116 J_2 I_1 
Stack 14
J_5 H_0 I_3 I_5 
Stack 15
Z_117 E_0 G_2 Z_118 
Stack 16
C_1 Z_119 Z_120 J_6 
Stack 17
K_0 J_1 Z_121 H_5 
Stack 18
Z_122 N_0 H_7 K_2 
Stack 19
Z_123 B_0 Z_124 Z_125 
Stack 20
Z_126 H_4 J_4 N_1 
Stack 21
J_3 F_4 Z_127 E_2 
Stack 22
C_0 H_1 G_6 
Stack 23
Z_128 K_1 I_0 
