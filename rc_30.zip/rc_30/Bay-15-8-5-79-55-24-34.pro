Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 D_11 Z_101 A_6 E_4 D_3 
Stack 1
E_6 C_5 A_3 Z_102 D_8 E_3 
Stack 2
C_8 Z_103 Z_104 B_6 B_5 D_6 
Stack 3
D_9 Z_105 E_1 B_2 Z_106 Z_107 
Stack 4
Z_108 A_2 Z_109 Z_110 B_3 
Stack 5
Z_111 Z_112 Z_113 B_9 E_7 
Stack 6
A_7 Z_114 C_3 E_5 A_0 
Stack 7
Z_115 B_1 D_7 A_10 D_1 
Stack 8
Z_116 B_10 Z_117 A_1 E_10 
Stack 9
D_10 Z_118 D_4 B_7 Z_119 
Stack 10
B_4 A_5 A_8 C_4 Z_120 
Stack 11
B_11 C_6 E_0 C_1 E_2 
Stack 12
E_8 C_2 A_4 B_8 Z_121 
Stack 13
Z_122 C_0 C_7 E_9 D_0 
Stack 14
D_5 D_2 Z_123 A_9 B_0 
