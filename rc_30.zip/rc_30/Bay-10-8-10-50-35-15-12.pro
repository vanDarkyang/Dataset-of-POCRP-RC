Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
G_2 F_4 Z_100 G_1 F_2 
Stack 1
E_0 D_3 H_1 D_4 I_2 
Stack 2
Z_101 Z_102 C_0 B_2 E_3 
Stack 3
C_1 Z_103 I_1 Z_104 F_1 
Stack 4
Z_105 Z_106 Z_107 Z_108 J_1 
Stack 5
F_3 A_0 F_0 G_3 E_4 
Stack 6
D_1 C_3 Z_109 B_0 Z_110 
Stack 7
C_2 F_5 E_2 J_0 D_2 
Stack 8
D_0 Z_111 I_0 Z_112 G_0 
Stack 9
Z_113 H_0 E_1 B_1 Z_114 
