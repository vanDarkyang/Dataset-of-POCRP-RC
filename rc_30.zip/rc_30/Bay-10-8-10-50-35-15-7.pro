Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
C_2 E_2 I_0 E_3 I_2 
Stack 1
D_3 Z_100 F_3 A_0 G_1 
Stack 2
H_2 G_4 Z_101 Z_102 F_0 
Stack 3
E_4 Z_103 B_1 G_0 H_3 
Stack 4
Z_104 E_0 Z_105 H_0 D_0 
Stack 5
E_1 D_2 F_5 Z_106 G_2 
Stack 6
Z_107 J_0 F_4 Z_108 Z_109 
Stack 7
D_1 Z_110 G_3 J_1 Z_111 
Stack 8
H_1 C_1 Z_112 F_2 B_0 
Stack 9
C_0 Z_113 F_1 I_1 Z_114 
