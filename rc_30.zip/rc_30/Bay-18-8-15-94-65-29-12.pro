Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 Z_101 Z_102 G_4 Z_103 M_0 
Stack 1
E_4 H_1 D_0 M_1 Z_104 C_2 
Stack 2
K_3 F_0 J_0 Z_105 Z_106 Z_107 
Stack 3
N_0 F_2 Z_108 E_5 J_2 D_4 
Stack 4
Z_109 E_1 I_3 K_5 L_1 
Stack 5
D_1 F_1 C_1 M_2 D_2 
Stack 6
Z_110 Z_111 I_4 K_4 G_3 
Stack 7
Z_112 F_3 Z_113 N_2 H_5 
Stack 8
C_3 H_0 Z_114 H_4 C_0 
Stack 9
Z_115 Z_116 O_0 E_0 Z_117 
Stack 10
O_2 Z_118 K_0 J_3 J_4 
Stack 11
A_0 Z_119 N_1 Z_120 B_0 
Stack 12
E_3 Z_121 L_0 G_1 I_6 
Stack 13
J_1 B_1 E_2 M_3 B_2 
Stack 14
I_0 F_4 I_5 D_3 H_2 
Stack 15
H_3 Z_122 I_1 O_1 I_2 
Stack 16
K_2 Z_123 Z_124 Z_125 Z_126 
Stack 17
Z_127 G_0 G_2 Z_128 K_1 
