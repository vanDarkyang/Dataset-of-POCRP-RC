Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
G_2 Z_100 G_3 Z_101 C_0 
Stack 1
Z_102 E_5 Z_103 E_3 E_2 
Stack 2
D_1 I_0 E_4 Z_104 G_0 
Stack 3
I_1 B_1 Z_105 E_0 Z_106 
Stack 4
Z_107 Z_108 A_1 E_6 H_1 
Stack 5
A_0 J_1 Z_109 Z_110 D_3 
Stack 6
D_2 H_2 Z_111 G_1 F_0 
Stack 7
I_2 Z_112 D_4 H_0 C_1 
Stack 8
H_3 E_1 C_2 F_1 B_0 
Stack 9
Z_113 D_0 J_0 D_5 Z_114 
