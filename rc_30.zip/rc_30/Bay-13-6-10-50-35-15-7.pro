Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
H_1 Z_100 Z_101 E_0 
Stack 1
F_5 F_1 H_0 D_1 
Stack 2
Z_102 D_3 Z_103 E_2 
Stack 3
C_0 J_0 H_2 I_0 
Stack 4
Z_104 B_0 D_2 E_3 
Stack 5
Z_105 I_1 G_1 G_2 
Stack 6
Z_106 Z_107 B_1 F_2 
Stack 7
C_2 A_1 G_3 Z_108 
Stack 8
Z_109 Z_110 F_4 Z_111 
Stack 9
Z_112 F_3 Z_113 A_0 
Stack 10
F_0 D_0 G_4 C_1 
Stack 11
E_1 J_1 C_4 
Stack 12
Z_114 G_0 C_3 
