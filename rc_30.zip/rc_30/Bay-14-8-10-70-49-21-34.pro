Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
J_1 F_1 F_4 Z_100 Z_101 
Stack 1
E_0 G_1 B_1 Z_102 B_4 
Stack 2
D_3 Z_103 A_2 E_2 G_2 
Stack 3
Z_104 A_1 G_0 Z_105 Z_106 
Stack 4
A_0 F_5 F_0 H_3 Z_107 
Stack 5
F_3 F_6 Z_108 B_2 D_5 
Stack 6
C_0 E_4 G_4 Z_109 E_1 
Stack 7
C_4 C_2 Z_110 C_1 Z_111 
Stack 8
D_0 Z_112 D_2 D_4 H_0 
Stack 9
G_3 J_0 B_3 F_2 Z_113 
Stack 10
Z_114 Z_115 I_0 H_1 Z_116 
Stack 11
Z_117 C_3 E_5 D_1 I_1 
Stack 12
A_3 Z_118 Z_119 J_3 B_0 
Stack 13
J_2 E_3 Z_120 H_2 H_4 
