Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
B_2 E_6 D_2 B_3 
Stack 1
D_11 C_7 Z_100 Z_101 
Stack 2
Z_102 C_2 C_11 Z_103 
Stack 3
D_8 D_10 B_7 D_6 
Stack 4
B_0 D_5 A_2 D_1 
Stack 5
C_1 A_0 Z_104 Z_105 
Stack 6
Z_106 C_3 A_3 D_9 
Stack 7
B_8 E_3 C_0 C_4 
Stack 8
Z_107 D_12 E_0 D_3 
Stack 9
B_10 Z_108 E_1 E_5 
Stack 10
B_1 D_7 Z_109 A_1 
Stack 11
Z_110 Z_111 C_9 C_5 
Stack 12
E_2 A_5 Z_112 B_4 
Stack 13
Z_113 C_6 C_10 Z_114 
Stack 14
D_0 Z_115 Z_116 E_7 
Stack 15
A_6 Z_117 Z_118 Z_119 
Stack 16
A_4 C_12 E_4 Z_120 
Stack 17
A_9 Z_121 Z_122 A_8 
Stack 18
B_9 D_4 A_7 Z_123 
Stack 19
B_5 B_6 C_8 
