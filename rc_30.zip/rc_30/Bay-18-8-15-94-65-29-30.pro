Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 Z_101 M_2 Z_102 H_2 Z_103 
Stack 1
A_0 G_3 G_1 B_0 G_7 Z_104 
Stack 2
Z_105 Z_106 H_1 H_0 D_0 Z_107 
Stack 3
F_2 Z_108 Z_109 F_0 Z_110 J_5 
Stack 4
Z_111 L_0 Z_112 J_1 I_6 
Stack 5
H_6 O_1 G_2 Z_113 I_5 
Stack 6
K_3 I_3 Z_114 B_2 Z_115 
Stack 7
K_1 J_4 Z_116 G_6 Z_117 
Stack 8
E_5 F_1 Z_118 Z_119 G_5 
Stack 9
O_0 Z_120 I_2 H_3 E_2 
Stack 10
M_0 D_1 H_5 J_0 E_0 
Stack 11
C_0 J_3 M_1 L_2 F_4 
Stack 12
K_0 B_1 K_2 Z_121 Z_122 
Stack 13
J_2 G_4 N_0 M_3 F_3 
Stack 14
L_1 N_1 Z_123 C_1 Z_124 
Stack 15
H_4 C_2 I_1 Z_125 D_2 
Stack 16
E_4 Z_126 B_3 Z_127 I_0 
Stack 17
E_1 G_0 I_4 Z_128 E_3 
