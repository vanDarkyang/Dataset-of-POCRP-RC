Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
J_0 M_0 K_4 E_0 
Stack 1
K_3 H_7 K_2 N_1 
Stack 2
H_2 K_1 Z_100 Z_101 
Stack 3
D_0 H_4 E_1 Z_102 
Stack 4
Z_103 L_2 F_2 Z_104 
Stack 5
Z_105 E_5 Z_106 L_0 
Stack 6
E_2 Z_107 Z_108 G_0 
Stack 7
D_1 C_0 L_1 G_2 
Stack 8
Z_109 F_0 H_1 G_1 
Stack 9
H_6 Z_110 J_2 F_3 
Stack 10
Z_111 N_0 I_1 Z_112 
Stack 11
Z_113 K_0 I_5 M_1 
Stack 12
H_0 I_2 J_1 C_1 
Stack 13
Z_114 H_5 Z_115 Z_116 
Stack 14
E_4 D_2 Z_117 I_6 
Stack 15
E_6 Z_118 Z_119 Z_120 
Stack 16
Z_121 J_4 Z_122 J_5 
Stack 17
E_3 Z_123 I_3 Z_124 
Stack 18
D_3 K_5 Z_125 O_0 
Stack 19
Z_126 B_1 D_4 I_0 
Stack 20
C_2 Z_127 M_2 K_6 
Stack 21
I_4 J_3 H_3 L_3 
Stack 22
Z_128 B_0 O_1 
Stack 23
H_8 A_0 F_1 
