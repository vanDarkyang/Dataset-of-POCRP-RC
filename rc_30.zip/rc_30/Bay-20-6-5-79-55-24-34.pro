Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 D_6 A_9 E_3 
Stack 1
E_5 E_0 Z_101 Z_102 
Stack 2
C_11 B_1 A_4 B_4 
Stack 3
D_7 B_7 C_10 C_1 
Stack 4
E_6 C_4 A_10 Z_103 
Stack 5
Z_104 A_6 A_7 E_7 
Stack 6
A_8 C_9 D_8 A_0 
Stack 7
C_8 Z_105 Z_106 D_1 
Stack 8
B_5 C_0 B_2 Z_107 
Stack 9
Z_108 Z_109 B_8 Z_110 
Stack 10
B_3 C_2 B_6 C_7 
Stack 11
Z_111 A_3 E_4 Z_112 
Stack 12
E_8 A_5 A_13 C_5 
Stack 13
A_12 E_2 A_1 Z_113 
Stack 14
Z_114 Z_115 Z_116 B_0 
Stack 15
D_9 Z_117 C_6 D_2 
Stack 16
Z_118 Z_119 C_3 Z_120 
Stack 17
Z_121 D_5 Z_122 D_4 
Stack 18
D_0 E_1 E_9 Z_123 
Stack 19
A_2 D_3 A_11 
