Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 C_1 Z_101 D_6 
Stack 1
Z_102 A_6 C_2 B_3 
Stack 2
Z_103 A_3 C_0 C_3 
Stack 3
A_0 Z_104 E_9 D_7 
Stack 4
E_5 Z_105 Z_106 E_7 
Stack 5
B_6 C_5 C_7 Z_107 
Stack 6
D_4 D_9 Z_108 Z_109 
Stack 7
Z_110 D_2 B_2 E_10 
Stack 8
Z_111 E_6 A_5 E_11 
Stack 9
B_7 D_0 C_4 E_14 
Stack 10
B_0 Z_112 B_5 Z_113 
Stack 11
A_8 E_4 D_3 Z_114 
Stack 12
E_1 B_9 C_9 E_0 
Stack 13
Z_115 A_4 D_5 E_12 
Stack 14
B_1 Z_116 C_8 Z_117 
Stack 15
D_1 Z_118 A_2 C_10 
Stack 16
A_7 Z_119 D_8 B_8 
Stack 17
Z_120 E_8 Z_121 E_3 
Stack 18
C_6 Z_122 Z_123 A_1 
Stack 19
E_2 E_13 B_4 
