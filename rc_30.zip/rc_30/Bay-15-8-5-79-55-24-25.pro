Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 Z_101 B_5 Z_102 D_4 Z_103 
Stack 1
Z_104 A_5 Z_105 B_3 B_10 Z_106 
Stack 2
Z_107 D_5 B_4 A_0 E_10 Z_108 
Stack 3
Z_109 C_7 A_1 Z_110 A_7 B_6 
Stack 4
C_2 Z_111 A_10 B_2 E_11 
Stack 5
A_3 Z_112 E_0 D_0 B_1 
Stack 6
Z_113 E_7 C_9 C_10 Z_114 
Stack 7
Z_115 E_9 E_3 Z_116 Z_117 
Stack 8
C_0 D_2 C_1 E_6 E_4 
Stack 9
C_3 Z_118 A_4 D_7 C_4 
Stack 10
Z_119 C_8 D_6 B_8 Z_120 
Stack 11
E_5 B_9 D_8 B_0 E_1 
Stack 12
D_3 A_8 B_11 A_9 C_5 
Stack 13
C_6 A_2 A_6 Z_121 E_2 
Stack 14
D_1 Z_122 Z_123 E_8 B_7 
