Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 A_6 D_6 E_1 Z_101 Z_102 
Stack 1
D_10 A_4 D_5 A_3 B_3 C_3 
Stack 2
Z_103 A_11 A_5 Z_104 E_10 A_9 
Stack 3
D_7 B_8 Z_105 E_0 D_3 A_1 
Stack 4
B_0 Z_106 A_0 E_2 Z_107 
Stack 5
C_0 E_8 C_5 Z_108 E_5 
Stack 6
Z_109 C_6 C_9 Z_110 D_8 
Stack 7
B_7 C_1 D_4 A_10 Z_111 
Stack 8
Z_112 D_9 D_2 C_7 D_1 
Stack 9
B_9 Z_113 B_5 A_7 E_7 
Stack 10
B_1 Z_114 D_0 Z_115 Z_116 
Stack 11
Z_117 C_2 B_4 E_6 C_4 
Stack 12
Z_118 E_4 Z_119 B_2 Z_120 
Stack 13
Z_121 D_11 B_6 A_8 E_3 
Stack 14
Z_122 C_8 A_2 Z_123 E_9 
