Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 I_0 F_1 J_2 Z_101 G_5 
Stack 1
H_1 D_8 C_0 B_5 H_4 B_6 
Stack 2
H_8 A_6 Z_102 C_1 I_1 F_8 
Stack 3
Z_103 Z_104 F_5 D_1 I_4 Z_105 
Stack 4
Z_106 B_0 E_7 E_5 E_10 A_2 
Stack 5
Z_107 E_0 Z_108 E_8 F_9 
Stack 6
Z_109 I_8 F_3 C_5 A_4 
Stack 7
C_6 I_2 C_2 E_9 I_5 
Stack 8
Z_110 Z_111 F_4 F_0 H_2 
Stack 9
Z_112 B_1 Z_113 Z_114 D_5 
Stack 10
I_7 D_3 I_6 Z_115 F_10 
Stack 11
Z_116 D_7 Z_117 H_5 Z_118 
Stack 12
Z_119 Z_120 Z_121 A_3 C_3 
Stack 13
I_3 J_4 G_3 G_4 J_1 
Stack 14
G_0 Z_122 D_4 Z_123 G_1 
Stack 15
H_9 Z_124 Z_125 Z_126 E_6 
Stack 16
F_11 H_3 A_0 H_0 C_4 
Stack 17
J_0 B_2 E_3 D_0 G_2 
Stack 18
A_1 Z_127 H_6 Z_128 D_2 
Stack 19
F_2 J_3 G_6 Z_129 E_2 
Stack 20
Z_130 B_3 Z_131 Z_132 B_4 
Stack 21
F_6 Z_133 Z_134 D_6 Z_135 
Stack 22
E_4 E_1 A_5 H_7 F_7 
