Number Of Containers
79
Number Of Yard Stacks
15
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
E_11 D_5 A_7 B_2 Z_100 C_2 
Stack 1
B_4 Z_101 A_1 Z_102 E_0 A_0 
Stack 2
Z_103 C_4 Z_104 A_3 E_9 C_3 
Stack 3
B_6 Z_105 Z_106 D_4 C_5 E_3 
Stack 4
C_6 Z_107 A_6 Z_108 Z_109 
Stack 5
C_7 D_7 E_2 E_12 Z_110 
Stack 6
B_0 A_5 D_2 E_8 B_3 
Stack 7
Z_111 B_10 A_8 B_7 Z_112 
Stack 8
E_13 Z_113 Z_114 C_9 C_11 
Stack 9
B_1 B_8 B_9 E_1 C_1 
Stack 10
E_5 Z_115 E_10 E_4 A_2 
Stack 11
Z_116 E_6 C_8 C_0 Z_117 
Stack 12
A_9 Z_118 Z_119 D_0 A_4 
Stack 13
Z_120 D_1 C_10 Z_121 D_3 
Stack 14
E_7 B_5 Z_122 Z_123 D_6 
