Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
9
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 C_3 E_4 H_1 B_3 
Stack 1
B_1 D_4 I_2 B_0 Z_101 
Stack 2
A_1 Z_102 E_2 G_1 F_2 
Stack 3
D_1 C_4 Z_103 Z_104 A_2 
Stack 4
Z_105 D_0 F_0 F_1 E_3 
Stack 5
H_0 G_0 Z_106 H_2 Z_107 
Stack 6
Z_108 Z_109 I_0 D_2 Z_110 
Stack 7
C_1 C_2 E_0 Z_111 Z_112 
Stack 8
D_3 A_0 I_1 E_1 Z_113 
Stack 9
C_0 G_2 Z_114 B_2 F_3 
