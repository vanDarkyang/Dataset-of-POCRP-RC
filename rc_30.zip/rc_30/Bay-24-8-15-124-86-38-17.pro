Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
A_1 L_3 J_6 J_3 Z_100 J_4 
Stack 1
K_7 Z_101 G_0 Z_102 G_7 D_5 
Stack 2
Z_103 C_3 Z_104 E_4 F_2 Z_105 
Stack 3
J_5 I_4 E_6 K_0 Z_106 H_0 
Stack 4
N_1 G_5 L_0 L_6 Z_107 
Stack 5
H_1 Z_108 L_2 J_1 E_3 
Stack 6
Z_109 H_3 E_2 Z_110 J_2 
Stack 7
B_1 H_5 Z_111 L_1 M_1 
Stack 8
B_0 Z_112 M_0 Z_113 Z_114 
Stack 9
Z_115 M_3 Z_116 M_2 H_6 
Stack 10
F_3 K_2 I_2 Z_117 G_2 
Stack 11
Z_118 D_4 Z_119 Z_120 B_2 
Stack 12
F_1 O_1 I_5 H_8 I_1 
Stack 13
Z_121 D_2 Z_122 Z_123 Z_124 
Stack 14
C_2 Z_125 N_0 G_3 I_0 
Stack 15
K_1 L_5 Z_126 Z_127 A_0 
Stack 16
G_6 C_1 Z_128 D_6 K_5 
Stack 17
I_3 F_0 K_4 Z_129 O_2 
Stack 18
Z_130 H_4 Z_131 L_4 Z_132 
Stack 19
E_0 K_3 G_4 F_5 B_3 
Stack 20
G_1 A_2 H_2 C_0 Z_133 
Stack 21
H_7 D_0 F_4 J_0 Z_134 
Stack 22
E_1 Z_135 Z_136 O_0 D_3 
Stack 23
K_6 E_5 Z_137 D_1 N_2 
