Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 B_3 B_0 Z_101 
Stack 1
B_7 A_0 B_9 C_2 
Stack 2
Z_102 Z_103 A_4 A_7 
Stack 3
Z_104 Z_105 C_7 Z_106 
Stack 4
Z_107 Z_108 C_6 A_1 
Stack 5
B_2 Z_109 A_8 B_10 
Stack 6
C_1 A_5 C_9 C_3 
Stack 7
A_3 Z_110 A_2 C_4 
Stack 8
A_6 Z_111 Z_112 B_4 
Stack 9
B_6 B_5 C_10 Z_113 
Stack 10
C_8 B_8 C_5 
Stack 11
C_0 B_1 C_11 
