Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
H_1 Z_100 Z_101 M_4 G_4 K_1 
Stack 1
G_1 Z_102 F_0 Z_103 D_2 I_5 
Stack 2
H_6 Z_104 E_2 E_1 H_9 I_4 
Stack 3
Z_105 Z_106 Z_107 Z_108 J_2 D_4 
Stack 4
Z_109 K_0 M_0 F_4 F_1 
Stack 5
G_0 Z_110 D_5 M_3 J_1 
Stack 6
A_1 B_0 A_2 O_1 Z_111 
Stack 7
N_1 M_1 Z_112 Z_113 Z_114 
Stack 8
Z_115 Z_116 C_5 Z_117 Z_118 
Stack 9
Z_119 M_5 E_4 H_7 I_3 
Stack 10
C_3 N_0 Z_120 E_5 Z_121 
Stack 11
F_5 Z_122 Z_123 Z_124 K_4 
Stack 12
O_0 Z_125 H_4 Z_126 K_3 
Stack 13
K_2 Z_127 N_2 L_2 N_3 
Stack 14
O_3 E_3 H_3 O_2 J_5 
Stack 15
Z_128 Z_129 L_5 Z_130 D_3 
Stack 16
G_3 M_2 H_8 D_0 J_3 
Stack 17
Z_131 A_0 C_0 I_6 C_1 
Stack 18
J_4 C_4 L_3 I_1 D_1 
Stack 19
F_3 E_0 Z_132 Z_133 F_2 
Stack 20
G_6 H_0 L_4 I_0 G_2 
Stack 21
Z_134 I_2 Z_135 M_6 J_0 
Stack 22
H_5 H_2 Z_136 Z_137 L_6 
Stack 23
L_1 B_1 G_5 C_2 L_0 
