Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
C_2 B_0 Z_100 Z_101 
Stack 1
Z_102 H_2 F_5 H_3 
Stack 2
Z_103 F_1 I_3 H_1 
Stack 3
Z_104 C_1 E_3 H_5 
Stack 4
E_0 J_1 I_2 B_3 
Stack 5
Z_105 Z_106 D_1 B_4 
Stack 6
C_0 G_0 D_2 Z_107 
Stack 7
B_1 E_7 H_4 C_3 
Stack 8
H_0 Z_108 G_1 Z_109 
Stack 9
D_3 I_0 E_2 F_7 
Stack 10
E_5 A_1 I_1 E_4 
Stack 11
F_6 Z_110 Z_111 J_0 
Stack 12
Z_112 Z_113 Z_114 G_2 
Stack 13
D_4 G_3 F_2 E_1 
Stack 14
F_4 E_6 Z_115 A_2 
Stack 15
Z_116 A_0 Z_117 F_0 
Stack 16
Z_118 Z_119 Z_120 
Stack 17
F_3 D_0 B_2 
