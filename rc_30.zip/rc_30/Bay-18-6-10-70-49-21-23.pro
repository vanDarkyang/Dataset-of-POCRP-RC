Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 E_3 Z_101 E_2 
Stack 1
H_4 J_1 J_2 Z_102 
Stack 2
G_4 H_2 B_2 C_0 
Stack 3
Z_103 F_0 Z_104 F_4 
Stack 4
C_3 H_1 Z_105 Z_106 
Stack 5
C_2 H_0 G_2 I_3 
Stack 6
A_2 J_3 A_0 C_1 
Stack 7
B_3 Z_107 I_2 Z_108 
Stack 8
E_6 G_1 Z_109 D_2 
Stack 9
E_1 A_1 D_4 Z_110 
Stack 10
G_3 Z_111 Z_112 I_1 
Stack 11
Z_113 E_5 G_0 F_3 
Stack 12
Z_114 E_0 F_2 C_4 
Stack 13
C_5 Z_115 Z_116 H_3 
Stack 14
G_5 J_0 D_3 Z_117 
Stack 15
F_1 Z_118 B_0 I_0 
Stack 16
E_4 D_1 Z_119 
Stack 17
D_0 Z_120 B_1 
