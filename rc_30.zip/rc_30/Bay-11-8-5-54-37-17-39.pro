Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_7 C_5 C_3 E_8 E_1 
Stack 1
E_4 E_5 A_1 A_0 Z_100 
Stack 2
D_1 Z_101 D_6 B_2 A_3 
Stack 3
D_3 D_5 E_3 Z_102 E_2 
Stack 4
C_1 D_2 Z_103 D_7 Z_104 
Stack 5
A_6 C_0 A_7 E_0 A_5 
Stack 6
D_0 E_6 C_6 Z_105 B_1 
Stack 7
Z_106 D_4 Z_107 Z_108 C_2 
Stack 8
Z_109 B_3 Z_110 Z_111 Z_112 
Stack 9
B_0 A_4 Z_113 B_4 Z_114 
Stack 10
C_4 A_2 Z_115 Z_116 
