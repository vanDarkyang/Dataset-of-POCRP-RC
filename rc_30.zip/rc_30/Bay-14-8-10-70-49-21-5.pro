Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
J_3 F_7 H_2 A_1 H_3 
Stack 1
C_3 F_0 G_2 D_1 Z_100 
Stack 2
Z_101 A_0 Z_102 E_3 G_3 
Stack 3
Z_103 H_0 C_1 C_2 Z_104 
Stack 4
C_4 F_5 G_1 H_1 E_4 
Stack 5
E_5 B_0 J_2 Z_105 F_3 
Stack 6
A_2 D_2 E_1 A_4 E_2 
Stack 7
Z_106 G_0 B_1 E_7 Z_107 
Stack 8
Z_108 F_2 B_3 D_0 J_1 
Stack 9
Z_109 Z_110 E_6 J_0 F_4 
Stack 10
C_5 F_1 I_2 Z_111 E_0 
Stack 11
C_0 Z_112 Z_113 F_6 Z_114 
Stack 12
Z_115 B_2 A_3 Z_116 I_0 
Stack 13
Z_117 I_1 Z_118 Z_119 Z_120 
