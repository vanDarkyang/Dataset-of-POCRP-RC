Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
C_2 Z_100 F_3 Z_101 
Stack 1
D_2 D_5 J_0 Z_102 
Stack 2
A_2 Z_103 Z_104 Z_105 
Stack 3
E_7 I_1 D_0 I_0 
Stack 4
E_6 F_5 Z_106 E_3 
Stack 5
I_2 G_2 D_6 E_1 
Stack 6
G_0 G_4 A_1 Z_107 
Stack 7
B_0 E_2 H_3 J_1 
Stack 8
D_3 G_1 F_1 E_4 
Stack 9
J_2 F_0 C_1 E_0 
Stack 10
Z_108 Z_109 G_6 Z_110 
Stack 11
H_0 Z_111 C_3 E_5 
Stack 12
H_4 Z_112 G_3 G_5 
Stack 13
F_2 Z_113 A_0 F_7 
Stack 14
D_1 H_1 Z_114 Z_115 
Stack 15
D_4 Z_116 Z_117 Z_118 
Stack 16
F_4 F_6 C_0 
Stack 17
Z_119 Z_120 H_2 
