Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
C_5 B_4 A_4 D_4 
Stack 1
B_3 Z_100 D_3 A_5 
Stack 2
E_5 A_0 A_2 E_3 
Stack 3
Z_101 Z_102 Z_103 B_8 
Stack 4
Z_104 E_2 Z_105 D_1 
Stack 5
Z_106 Z_107 E_0 E_4 
Stack 6
Z_108 E_6 B_2 A_6 
Stack 7
E_1 D_0 Z_109 D_2 
Stack 8
A_7 Z_110 C_1 B_7 
Stack 9
B_5 C_3 C_4 Z_111 
Stack 10
A_1 C_2 D_5 Z_112 
Stack 11
B_0 Z_113 A_3 Z_114 
Stack 12
D_6 C_0 B_1 
Stack 13
Z_115 Z_116 B_6 
