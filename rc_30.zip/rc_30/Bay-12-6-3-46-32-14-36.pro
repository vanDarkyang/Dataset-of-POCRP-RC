Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
B_6 Z_100 Z_101 Z_102 
Stack 1
Z_103 B_10 A_8 B_0 
Stack 2
A_5 A_2 C_3 C_1 
Stack 3
Z_104 Z_105 B_1 B_8 
Stack 4
Z_106 Z_107 A_12 C_5 
Stack 5
A_6 Z_108 A_1 Z_109 
Stack 6
A_11 B_3 B_9 Z_110 
Stack 7
B_2 C_0 A_0 Z_111 
Stack 8
A_7 B_11 C_2 B_4 
Stack 9
C_6 A_3 Z_112 B_5 
Stack 10
B_7 A_10 C_4 
Stack 11
A_4 A_9 Z_113 
