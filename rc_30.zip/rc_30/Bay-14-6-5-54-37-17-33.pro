Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
E_1 Z_100 Z_101 Z_102 
Stack 1
D_1 C_7 B_5 Z_103 
Stack 2
Z_104 Z_105 E_4 Z_106 
Stack 3
B_1 E_2 C_5 A_5 
Stack 4
D_6 C_2 C_4 A_2 
Stack 5
A_3 Z_107 A_6 D_2 
Stack 6
A_1 E_0 Z_108 Z_109 
Stack 7
Z_110 C_1 C_8 D_0 
Stack 8
E_5 Z_111 B_4 D_3 
Stack 9
A_4 B_2 D_5 Z_112 
Stack 10
A_0 B_0 Z_113 B_3 
Stack 11
Z_114 C_6 B_6 E_6 
Stack 12
C_3 D_4 C_0 
Stack 13
Z_115 Z_116 E_3 
