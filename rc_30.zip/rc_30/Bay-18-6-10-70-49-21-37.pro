Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
E_1 F_5 E_0 Z_100 
Stack 1
Z_101 F_3 H_4 Z_102 
Stack 2
D_2 Z_103 A_3 Z_104 
Stack 3
Z_105 Z_106 Z_107 B_0 
Stack 4
A_1 Z_108 J_0 J_3 
Stack 5
Z_109 H_1 G_5 G_4 
Stack 6
B_4 G_0 I_2 G_3 
Stack 7
J_2 Z_110 I_0 C_1 
Stack 8
Z_111 F_1 B_3 E_3 
Stack 9
G_1 F_0 E_5 Z_112 
Stack 10
C_0 E_4 H_3 F_2 
Stack 11
C_3 E_2 B_2 A_2 
Stack 12
G_2 D_3 C_4 A_0 
Stack 13
Z_113 Z_114 Z_115 J_4 
Stack 14
H_2 Z_116 F_4 C_2 
Stack 15
D_0 B_1 Z_117 Z_118 
Stack 16
D_1 Z_119 J_1 
Stack 17
I_1 Z_120 H_0 
