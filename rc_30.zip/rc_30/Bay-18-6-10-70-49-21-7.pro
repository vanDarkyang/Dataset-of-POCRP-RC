Number Of Containers
70
Number Of Yard Stacks
18
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
A_1 A_2 H_0 Z_100 
Stack 1
Z_101 D_3 F_4 H_1 
Stack 2
D_5 Z_102 C_0 Z_103 
Stack 3
D_4 I_1 G_4 I_4 
Stack 4
E_0 J_2 B_3 C_4 
Stack 5
F_1 B_0 D_1 Z_104 
Stack 6
Z_105 C_1 Z_106 C_2 
Stack 7
H_3 G_1 F_2 I_3 
Stack 8
I_0 Z_107 G_5 G_3 
Stack 9
Z_108 C_5 I_2 D_2 
Stack 10
Z_109 Z_110 A_3 Z_111 
Stack 11
D_0 E_4 J_1 G_2 
Stack 12
H_2 A_0 G_0 Z_112 
Stack 13
E_1 J_0 B_1 Z_113 
Stack 14
Z_114 E_2 Z_115 Z_116 
Stack 15
B_2 F_3 F_0 Z_117 
Stack 16
C_3 E_3 Z_118 
Stack 17
Z_119 Z_120 E_5 
