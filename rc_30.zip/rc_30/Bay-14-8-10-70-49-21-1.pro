Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
E_4 B_2 Z_100 Z_101 G_4 
Stack 1
C_3 Z_102 E_2 Z_103 F_0 
Stack 2
Z_104 Z_105 F_6 Z_106 H_1 
Stack 3
D_1 C_2 B_0 Z_107 B_1 
Stack 4
H_0 I_2 G_5 A_0 E_6 
Stack 5
I_0 A_2 Z_108 F_1 G_1 
Stack 6
D_2 I_3 J_1 E_1 Z_109 
Stack 7
F_5 Z_110 E_5 G_0 G_2 
Stack 8
F_2 Z_111 J_0 Z_112 C_0 
Stack 9
E_0 Z_113 B_3 B_4 D_0 
Stack 10
Z_114 F_3 Z_115 C_4 G_3 
Stack 11
A_1 F_4 Z_116 H_2 I_1 
Stack 12
Z_117 Z_118 E_3 Z_119 D_3 
Stack 13
C_1 H_3 H_4 Z_120 E_7 
