Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 Z_101 C_0 E_6 
Stack 1
C_3 Z_102 Z_103 Z_104 
Stack 2
Z_105 Z_106 D_2 Z_107 
Stack 3
A_5 Z_108 D_3 E_4 
Stack 4
C_7 A_0 D_4 A_3 
Stack 5
Z_109 D_1 D_0 B_0 
Stack 6
B_4 C_4 B_3 C_2 
Stack 7
B_2 Z_110 Z_111 E_1 
Stack 8
Z_112 E_0 A_7 E_5 
Stack 9
Z_113 Z_114 E_3 C_6 
Stack 10
C_1 A_6 A_4 D_5 
Stack 11
Z_115 A_1 E_2 C_5 
Stack 12
B_7 Z_116 B_6 
Stack 13
A_2 B_1 B_5 
