Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
D_1 Z_100 B_5 A_7 
Stack 1
D_2 Z_101 C_10 D_5 
Stack 2
A_8 Z_102 Z_103 C_13 
Stack 3
Z_104 D_8 E_7 B_10 
Stack 4
Z_105 Z_106 B_11 Z_107 
Stack 5
C_9 B_3 C_14 Z_108 
Stack 6
E_1 D_9 C_2 Z_109 
Stack 7
A_5 Z_110 D_0 D_3 
Stack 8
Z_111 E_0 Z_112 C_8 
Stack 9
D_6 D_7 A_3 B_8 
Stack 10
Z_113 Z_114 Z_115 E_2 
Stack 11
C_4 B_2 C_5 Z_116 
Stack 12
C_0 Z_117 Z_118 B_7 
Stack 13
C_11 C_7 A_1 C_3 
Stack 14
D_4 D_10 B_6 C_12 
Stack 15
Z_119 A_4 B_4 Z_120 
Stack 16
E_3 C_6 A_2 B_0 
Stack 17
B_1 Z_121 A_0 E_5 
Stack 18
E_4 A_6 C_1 B_9 
Stack 19
Z_122 Z_123 E_6 
