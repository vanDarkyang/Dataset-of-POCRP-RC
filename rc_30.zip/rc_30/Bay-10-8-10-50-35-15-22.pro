Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 Z_101 Z_102 G_2 D_0 
Stack 1
Z_103 D_4 G_4 F_0 Z_104 
Stack 2
G_0 Z_105 D_3 Z_106 C_0 
Stack 3
B_2 F_4 A_1 H_0 F_3 
Stack 4
C_1 C_2 Z_107 Z_108 D_2 
Stack 5
J_1 Z_109 A_2 A_0 Z_110 
Stack 6
I_0 E_1 E_2 F_1 E_0 
Stack 7
D_1 F_2 G_3 D_5 B_1 
Stack 8
I_1 J_2 Z_111 Z_112 B_0 
Stack 9
E_3 G_1 Z_113 Z_114 J_0 
