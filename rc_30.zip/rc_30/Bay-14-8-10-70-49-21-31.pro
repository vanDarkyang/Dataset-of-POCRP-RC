Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
J_1 H_3 Z_100 E_2 I_0 
Stack 1
Z_101 Z_102 D_2 Z_103 H_4 
Stack 2
D_0 Z_104 F_3 H_2 C_1 
Stack 3
Z_105 Z_106 A_4 A_1 F_5 
Stack 4
G_0 I_2 F_4 Z_107 F_1 
Stack 5
F_2 J_3 E_0 G_2 Z_108 
Stack 6
Z_109 F_0 E_1 E_4 A_2 
Stack 7
C_2 B_0 Z_110 B_1 H_0 
Stack 8
Z_111 J_0 Z_112 I_4 F_6 
Stack 9
A_3 Z_113 Z_114 G_1 A_0 
Stack 10
E_7 D_1 G_3 Z_115 E_6 
Stack 11
C_3 E_5 Z_116 Z_117 H_1 
Stack 12
I_3 J_2 I_1 C_0 H_5 
Stack 13
Z_118 Z_119 B_2 E_3 Z_120 
