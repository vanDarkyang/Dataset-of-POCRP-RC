Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
B_4 B_2 C_2 B_1 Z_100 
Stack 1
A_4 B_3 C_8 A_2 D_3 
Stack 2
B_0 Z_101 C_1 Z_102 C_6 
Stack 3
B_8 D_6 C_3 C_0 Z_103 
Stack 4
Z_104 E_4 A_0 Z_105 B_6 
Stack 5
C_7 Z_106 C_9 Z_107 B_5 
Stack 6
A_3 D_2 D_4 E_1 Z_108 
Stack 7
Z_109 Z_110 C_5 E_3 B_7 
Stack 8
Z_111 Z_112 E_0 E_2 Z_113 
Stack 9
Z_114 Z_115 D_5 Z_116 A_1 
Stack 10
D_0 C_4 D_1 B_9 
