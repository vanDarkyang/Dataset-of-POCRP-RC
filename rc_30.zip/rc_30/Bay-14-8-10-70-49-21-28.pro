Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
C_0 G_0 A_2 J_2 Z_100 
Stack 1
F_5 A_0 Z_101 Z_102 I_3 
Stack 2
Z_103 Z_104 J_1 E_6 Z_105 
Stack 3
D_0 H_0 Z_106 H_4 F_1 
Stack 4
E_1 G_1 D_2 Z_107 H_1 
Stack 5
H_2 I_2 Z_108 F_0 Z_109 
Stack 6
B_1 E_0 C_1 B_0 G_2 
Stack 7
B_2 D_1 G_3 E_3 C_3 
Stack 8
G_4 F_2 H_3 J_0 Z_110 
Stack 9
Z_111 Z_112 Z_113 Z_114 Z_115 
Stack 10
G_5 J_3 E_4 C_4 D_3 
Stack 11
Z_116 I_1 B_3 I_0 Z_117 
Stack 12
F_4 F_3 Z_118 Z_119 C_2 
Stack 13
A_1 Z_120 E_2 A_3 E_5 
