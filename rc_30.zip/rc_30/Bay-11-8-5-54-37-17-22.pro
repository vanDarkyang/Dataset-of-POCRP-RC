Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 Z_101 C_4 B_5 C_2 
Stack 1
Z_102 E_0 Z_103 Z_104 D_8 
Stack 2
D_2 Z_105 D_6 E_3 D_7 
Stack 3
B_0 E_1 B_4 D_5 D_9 
Stack 4
A_7 Z_106 E_2 B_1 D_4 
Stack 5
Z_107 A_1 Z_108 E_6 A_3 
Stack 6
Z_109 C_1 Z_110 Z_111 Z_112 
Stack 7
E_7 Z_113 C_0 Z_114 A_5 
Stack 8
D_3 E_4 C_3 A_4 Z_115 
Stack 9
D_0 A_6 B_2 Z_116 B_3 
Stack 10
E_5 A_0 A_2 D_1 
