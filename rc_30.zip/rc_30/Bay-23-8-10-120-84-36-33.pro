Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
F_8 I_2 D_4 E_1 H_2 D_3 
Stack 1
J_4 Z_100 Z_101 A_3 Z_102 G_5 
Stack 2
B_3 F_4 E_4 Z_103 J_3 A_1 
Stack 3
D_0 C_8 Z_104 C_1 Z_105 E_2 
Stack 4
I_3 F_2 Z_106 F_11 C_6 Z_107 
Stack 5
F_5 F_1 J_0 G_6 F_10 
Stack 6
Z_108 C_2 F_3 H_5 Z_109 
Stack 7
Z_110 H_6 Z_111 E_8 G_1 
Stack 8
D_8 C_4 C_3 B_5 Z_112 
Stack 9
Z_113 A_6 Z_114 A_0 E_6 
Stack 10
I_0 D_1 E_0 G_3 A_5 
Stack 11
Z_115 G_4 E_5 Z_116 D_9 
Stack 12
C_7 H_1 F_0 Z_117 J_5 
Stack 13
C_0 D_6 I_1 Z_118 D_5 
Stack 14
B_2 I_5 J_1 Z_119 Z_120 
Stack 15
E_3 F_7 B_4 F_9 A_4 
Stack 16
J_2 Z_121 Z_122 C_5 Z_123 
Stack 17
Z_124 Z_125 E_7 F_6 G_2 
Stack 18
Z_126 B_0 B_1 Z_127 H_0 
Stack 19
D_7 Z_128 Z_129 I_7 H_3 
Stack 20
I_4 Z_130 Z_131 G_7 Z_132 
Stack 21
H_4 F_12 Z_133 Z_134 I_8 
Stack 22
I_6 Z_135 G_0 A_2 D_2 
