Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
Z_100 Z_101 Z_102 B_2 B_3 
Stack 1
Z_103 Z_104 C_6 D_2 Z_105 
Stack 2
Z_106 A_2 Z_107 Z_108 E_3 
Stack 3
A_8 B_5 Z_109 E_0 A_4 
Stack 4
Z_110 D_3 A_6 C_3 A_5 
Stack 5
Z_111 D_1 D_4 Z_112 E_4 
Stack 6
Z_113 C_5 C_1 A_1 C_0 
Stack 7
C_4 A_0 B_7 Z_114 D_0 
Stack 8
Z_115 A_7 B_1 B_4 D_5 
Stack 9
B_8 E_2 E_1 C_2 C_7 
Stack 10
B_6 Z_116 A_3 B_0 
