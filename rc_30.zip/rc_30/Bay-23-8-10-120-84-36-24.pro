Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
A_4 H_5 Z_100 Z_101 Z_102 Z_103 
Stack 1
H_0 J_5 Z_104 C_1 A_5 Z_105 
Stack 2
C_2 I_2 C_3 Z_106 B_2 Z_107 
Stack 3
E_1 Z_108 J_4 Z_109 F_7 A_6 
Stack 4
Z_110 E_0 B_0 D_0 E_3 F_4 
Stack 5
B_5 D_7 G_4 D_1 G_0 
Stack 6
E_5 G_5 Z_111 G_8 Z_112 
Stack 7
Z_113 Z_114 Z_115 B_4 A_7 
Stack 8
D_3 A_0 I_1 E_8 E_7 
Stack 9
J_1 F_6 Z_116 Z_117 Z_118 
Stack 10
C_6 Z_119 J_2 Z_120 E_4 
Stack 11
F_9 A_3 I_6 G_6 C_7 
Stack 12
F_2 F_8 D_4 H_2 G_1 
Stack 13
C_4 D_2 H_6 I_4 J_0 
Stack 14
D_5 Z_121 C_0 Z_122 H_1 
Stack 15
F_10 Z_123 G_3 Z_124 D_6 
Stack 16
B_1 J_6 C_5 Z_125 H_4 
Stack 17
Z_126 Z_127 I_3 E_2 Z_128 
Stack 18
F_5 D_10 Z_129 C_8 Z_130 
Stack 19
F_0 F_3 A_1 Z_131 F_1 
Stack 20
A_2 H_3 Z_132 Z_133 J_3 
Stack 21
Z_134 B_3 I_0 Z_135 I_5 
Stack 22
G_2 E_6 G_7 D_9 D_8 
