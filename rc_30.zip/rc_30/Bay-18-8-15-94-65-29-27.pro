Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
C_2 D_0 Z_100 H_4 M_0 Z_101 
Stack 1
N_2 Z_102 K_5 O_1 Z_103 H_1 
Stack 2
Z_104 E_3 Z_105 Z_106 D_4 K_0 
Stack 3
Z_107 E_2 Z_108 Z_109 Z_110 K_1 
Stack 4
C_3 M_2 Z_111 H_0 N_0 
Stack 5
Z_112 D_2 J_0 Z_113 Z_114 
Stack 6
E_1 I_1 Z_115 K_3 Z_116 
Stack 7
G_3 K_4 I_3 A_0 B_1 
Stack 8
G_1 H_5 O_2 I_0 N_1 
Stack 9
Z_117 C_4 K_2 F_3 B_0 
Stack 10
Z_118 C_0 Z_119 C_1 I_2 
Stack 11
H_6 G_0 I_4 J_1 D_3 
Stack 12
L_3 L_1 L_2 F_2 Z_120 
Stack 13
L_4 L_0 E_0 H_3 E_4 
Stack 14
Z_121 Z_122 Z_123 Z_124 J_2 
Stack 15
Z_125 F_0 H_2 G_4 B_2 
Stack 16
F_1 Z_126 G_2 Z_127 H_7 
Stack 17
M_1 D_1 A_1 O_0 Z_128 
