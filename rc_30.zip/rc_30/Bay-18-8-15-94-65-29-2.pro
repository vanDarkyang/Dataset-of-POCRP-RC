Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
A_0 J_3 Z_100 F_4 M_1 G_2 
Stack 1
L_2 G_6 I_1 Z_101 H_4 H_5 
Stack 2
H_3 Z_102 H_2 C_2 L_0 A_1 
Stack 3
Z_103 F_0 Z_104 Z_105 H_0 L_1 
Stack 4
B_1 G_4 K_1 F_3 E_3 
Stack 5
G_1 Z_106 Z_107 E_4 Z_108 
Stack 6
M_0 Z_109 D_1 Z_110 E_1 
Stack 7
Z_111 Z_112 Z_113 Z_114 Z_115 
Stack 8
I_0 G_5 Z_116 M_2 E_2 
Stack 9
D_0 D_2 F_1 H_6 J_1 
Stack 10
Z_117 Z_118 K_2 Z_119 Z_120 
Stack 11
C_0 G_0 Z_121 K_3 I_3 
Stack 12
J_4 H_7 N_0 Z_122 J_5 
Stack 13
L_3 B_0 N_2 J_2 Z_123 
Stack 14
O_1 I_5 Z_124 Z_125 G_3 
Stack 15
H_8 J_0 K_0 O_0 I_4 
Stack 16
I_2 Z_126 Z_127 H_1 E_0 
Stack 17
F_2 N_1 K_4 Z_128 C_1 
