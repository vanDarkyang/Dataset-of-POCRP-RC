Number Of Containers
50
Number Of Yard Stacks
13
MaxTier of Yard Stacks
6
Number of Vessel Stacks
10
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 E_3 G_1 Z_101 
Stack 1
Z_102 E_0 Z_103 C_0 
Stack 2
Z_104 B_1 F_4 I_0 
Stack 3
H_1 G_2 Z_105 E_2 
Stack 4
Z_106 Z_107 Z_108 G_5 
Stack 5
I_2 F_3 F_6 A_1 
Stack 6
F_5 Z_109 F_2 F_0 
Stack 7
G_3 Z_110 D_0 Z_111 
Stack 8
C_1 Z_112 G_4 H_0 
Stack 9
H_2 J_1 J_0 Z_113 
Stack 10
E_1 E_4 D_1 B_0 
Stack 11
D_2 F_1 G_0 
Stack 12
Z_114 A_0 I_1 
