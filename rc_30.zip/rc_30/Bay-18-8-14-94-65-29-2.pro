Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
14
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
K_3 A_2 Z_100 Z_101 G_5 F_0 
Stack 1
Z_102 Z_103 L_1 D_1 G_0 L_2 
Stack 2
Z_104 H_4 G_1 Z_105 L_0 Z_106 
Stack 3
D_6 J_4 N_1 K_0 C_3 G_3 
Stack 4
E_5 F_5 H_1 Z_107 Z_108 
Stack 5
Z_109 Z_110 Z_111 Z_112 B_1 
Stack 6
Z_113 E_4 H_3 Z_114 I_0 
Stack 7
Z_115 Z_116 E_2 E_0 M_1 
Stack 8
M_0 C_2 Z_117 Z_118 I_2 
Stack 9
E_3 F_7 Z_119 K_2 D_0 
Stack 10
G_4 H_2 Z_120 J_2 F_3 
Stack 11
M_2 I_1 A_0 D_3 Z_121 
Stack 12
Z_122 D_5 K_4 D_4 F_6 
Stack 13
B_0 Z_123 F_1 N_2 G_2 
Stack 14
F_4 M_3 H_0 J_0 E_1 
Stack 15
J_1 C_4 Z_124 J_3 A_1 
Stack 16
K_1 Z_125 Z_126 F_2 Z_127 
Stack 17
D_2 N_0 Z_128 C_0 C_1 
