Number Of Containers
124
Number Of Yard Stacks
24
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
86
Number Of Shutout Containers
38
Yard Bay
Stack 0
K_3 E_4 A_2 Z_100 L_5 B_2 
Stack 1
Z_101 Z_102 A_0 Z_103 K_0 F_4 
Stack 2
M_2 C_0 K_1 F_2 Z_104 Z_105 
Stack 3
H_3 L_0 J_1 N_1 E_2 I_3 
Stack 4
H_0 Z_106 E_6 O_0 H_2 
Stack 5
M_0 Z_107 K_7 Z_108 D_1 
Stack 6
Z_109 I_1 D_0 L_3 Z_110 
Stack 7
L_2 Z_111 I_2 E_0 Z_112 
Stack 8
N_0 Z_113 Z_114 M_3 Z_115 
Stack 9
K_6 M_5 G_1 J_2 I_6 
Stack 10
Z_116 Z_117 O_1 E_5 Z_118 
Stack 11
C_3 A_1 L_1 F_0 H_4 
Stack 12
B_0 E_3 Z_119 Z_120 G_5 
Stack 13
I_4 B_1 Z_121 K_4 A_3 
Stack 14
J_5 M_1 Z_122 Z_123 D_4 
Stack 15
Z_124 F_1 K_5 Z_125 G_4 
Stack 16
Z_126 L_6 Z_127 H_1 C_2 
Stack 17
G_3 D_3 K_2 Z_128 J_3 
Stack 18
G_6 D_2 L_4 J_4 Z_129 
Stack 19
I_5 Z_130 D_6 B_3 D_5 
Stack 20
Z_131 H_5 J_0 Z_132 Z_133 
Stack 21
Z_134 Z_135 Z_136 I_7 G_2 
Stack 22
G_0 M_4 E_1 C_1 N_2 
Stack 23
H_7 I_0 H_6 F_3 Z_137 
