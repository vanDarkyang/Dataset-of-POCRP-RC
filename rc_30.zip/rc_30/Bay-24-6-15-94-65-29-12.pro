Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 N_0 N_2 M_1 
Stack 1
F_3 D_0 K_1 Z_101 
Stack 2
Z_102 G_1 E_1 J_3 
Stack 3
Z_103 Z_104 Z_105 Z_106 
Stack 4
H_3 G_0 J_2 Z_107 
Stack 5
B_2 C_0 O_1 H_6 
Stack 6
Z_108 E_2 J_0 K_0 
Stack 7
Z_109 I_4 D_1 F_0 
Stack 8
I_0 Z_110 K_2 Z_111 
Stack 9
Z_112 H_1 D_3 Z_113 
Stack 10
A_1 G_5 H_5 B_3 
Stack 11
B_1 L_4 A_0 G_2 
Stack 12
Z_114 Z_115 J_4 I_3 
Stack 13
M_0 Z_116 J_1 Z_117 
Stack 14
Z_118 D_2 Z_119 Z_120 
Stack 15
Z_121 Z_122 Z_123 G_4 
Stack 16
F_1 H_0 L_1 N_1 
Stack 17
H_4 Z_124 H_2 O_0 
Stack 18
F_6 G_3 K_3 K_4 
Stack 19
E_0 L_3 J_5 O_2 
Stack 20
I_1 I_2 E_3 Z_125 
Stack 21
Z_126 F_4 H_7 F_5 
Stack 22
L_2 Z_127 Z_128 
Stack 23
F_2 B_0 L_0 
