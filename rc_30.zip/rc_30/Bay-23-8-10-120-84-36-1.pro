Number Of Containers
120
Number Of Yard Stacks
23
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
84
Number Of Shutout Containers
36
Yard Bay
Stack 0
Z_100 I_5 Z_101 Z_102 B_1 J_2 
Stack 1
G_3 C_10 H_5 Z_103 Z_104 B_4 
Stack 2
H_8 Z_105 E_4 J_3 E_0 Z_106 
Stack 3
Z_107 Z_108 F_4 C_7 Z_109 F_7 
Stack 4
I_3 B_5 B_8 E_2 Z_110 Z_111 
Stack 5
D_3 E_7 E_8 C_4 B_9 
Stack 6
H_4 Z_112 E_10 I_4 F_5 
Stack 7
Z_113 G_6 B_6 Z_114 F_2 
Stack 8
C_11 D_0 H_1 B_0 H_6 
Stack 9
H_0 B_7 C_2 Z_115 C_8 
Stack 10
Z_116 Z_117 C_5 D_5 Z_118 
Stack 11
E_6 I_6 C_0 C_3 B_3 
Stack 12
E_5 A_0 F_1 J_1 Z_119 
Stack 13
Z_120 D_1 Z_121 A_5 E_1 
Stack 14
Z_122 Z_123 G_2 F_0 G_1 
Stack 15
J_4 G_5 H_2 E_9 Z_124 
Stack 16
Z_125 E_3 H_7 A_2 D_4 
Stack 17
C_6 D_2 A_3 G_4 D_6 
Stack 18
Z_126 D_7 F_3 I_0 B_2 
Stack 19
Z_127 Z_128 G_0 J_5 Z_129 
Stack 20
Z_130 A_1 Z_131 I_1 Z_132 
Stack 21
I_2 Z_133 C_1 J_0 A_4 
Stack 22
C_9 H_3 Z_134 Z_135 F_6 
