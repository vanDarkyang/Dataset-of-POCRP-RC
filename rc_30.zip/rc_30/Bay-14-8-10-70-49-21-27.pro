Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 E_0 Z_101 Z_102 F_2 
Stack 1
E_3 F_3 A_0 B_2 J_2 
Stack 2
J_1 G_2 A_2 B_0 E_4 
Stack 3
J_0 C_2 F_4 C_1 I_2 
Stack 4
D_1 F_6 C_5 F_1 B_1 
Stack 5
Z_103 C_4 B_4 G_1 G_4 
Stack 6
D_2 Z_104 G_0 Z_105 C_3 
Stack 7
Z_106 B_5 F_7 I_1 Z_107 
Stack 8
H_2 Z_108 D_0 Z_109 H_0 
Stack 9
G_5 H_3 E_1 E_2 B_3 
Stack 10
G_3 Z_110 J_3 C_0 Z_111 
Stack 11
Z_112 Z_113 Z_114 I_0 Z_115 
Stack 12
Z_116 F_0 Z_117 H_1 F_5 
Stack 13
I_3 A_1 Z_118 Z_119 Z_120 
