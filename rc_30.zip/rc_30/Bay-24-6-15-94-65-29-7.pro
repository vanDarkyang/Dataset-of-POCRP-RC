Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
N_0 I_2 E_0 B_0 
Stack 1
G_1 Z_100 G_0 K_3 
Stack 2
Z_101 L_0 Z_102 C_3 
Stack 3
H_1 F_1 I_3 J_5 
Stack 4
O_0 Z_103 F_2 Z_104 
Stack 5
D_2 J_0 Z_105 Z_106 
Stack 6
F_3 C_2 Z_107 E_2 
Stack 7
Z_108 G_2 H_0 Z_109 
Stack 8
E_1 Z_110 K_0 N_2 
Stack 9
Z_111 J_3 L_1 Z_112 
Stack 10
A_1 M_3 Z_113 Z_114 
Stack 11
F_0 Z_115 Z_116 Z_117 
Stack 12
D_4 L_3 I_0 Z_118 
Stack 13
Z_119 J_6 H_4 Z_120 
Stack 14
J_2 Z_121 L_2 F_4 
Stack 15
Z_122 M_0 A_0 B_1 
Stack 16
C_0 N_3 G_5 C_1 
Stack 17
H_3 Z_123 Z_124 D_1 
Stack 18
G_3 J_4 D_3 J_1 
Stack 19
Z_125 N_1 D_0 K_2 
Stack 20
A_2 I_4 I_5 M_2 
Stack 21
Z_126 M_1 O_1 Z_127 
Stack 22
H_2 G_4 E_3 
Stack 23
I_1 Z_128 K_1 
