Number Of Containers
50
Number Of Yard Stacks
10
MaxTier of Yard Stacks
8
Number of Vessel Stacks
9
Number Of Export Containers
35
Number Of Shutout Containers
15
Yard Bay
Stack 0
Z_100 C_3 D_0 I_1 F_2 
Stack 1
E_2 H_1 F_3 E_0 H_0 
Stack 2
D_1 Z_101 F_0 Z_102 Z_103 
Stack 3
Z_104 A_0 Z_105 G_1 C_4 
Stack 4
D_2 Z_106 C_0 Z_107 Z_108 
Stack 5
G_4 F_4 G_0 Z_109 H_2 
Stack 6
F_5 Z_110 Z_111 E_3 C_1 
Stack 7
B_0 A_2 I_0 A_1 Z_112 
Stack 8
G_2 B_1 F_1 G_3 Z_113 
Stack 9
B_2 I_2 C_2 Z_114 E_1 
