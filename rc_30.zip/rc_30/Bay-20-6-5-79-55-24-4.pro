Number Of Containers
79
Number Of Yard Stacks
20
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
55
Number Of Shutout Containers
24
Yard Bay
Stack 0
Z_100 C_8 E_9 Z_101 
Stack 1
E_8 Z_102 E_4 Z_103 
Stack 2
Z_104 D_9 Z_105 C_10 
Stack 3
A_3 E_10 Z_106 Z_107 
Stack 4
D_2 B_0 D_7 Z_108 
Stack 5
Z_109 A_2 E_2 Z_110 
Stack 6
C_4 D_3 Z_111 Z_112 
Stack 7
Z_113 E_1 Z_114 D_4 
Stack 8
C_0 C_7 C_1 B_8 
Stack 9
A_6 Z_115 B_5 Z_116 
Stack 10
Z_117 Z_118 E_7 A_4 
Stack 11
Z_119 C_3 B_4 C_12 
Stack 12
A_7 C_2 E_12 D_6 
Stack 13
Z_120 D_5 B_7 A_0 
Stack 14
Z_121 D_11 D_8 Z_122 
Stack 15
A_1 B_1 C_9 B_6 
Stack 16
C_6 D_10 C_5 E_3 
Stack 17
C_11 E_5 D_0 B_3 
Stack 18
A_5 Z_123 D_1 E_6 
Stack 19
B_2 E_11 E_0 
