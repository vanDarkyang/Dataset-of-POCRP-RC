Number Of Containers
46
Number Of Yard Stacks
12
MaxTier of Yard Stacks
6
Number of Vessel Stacks
3
Number Of Export Containers
32
Number Of Shutout Containers
14
Yard Bay
Stack 0
Z_100 C_5 Z_101 Z_102 
Stack 1
A_2 C_2 A_4 Z_103 
Stack 2
A_0 B_4 C_9 C_8 
Stack 3
A_9 B_6 A_7 B_8 
Stack 4
C_1 B_5 Z_104 Z_105 
Stack 5
C_3 A_6 B_2 B_11 
Stack 6
Z_106 B_3 A_8 Z_107 
Stack 7
Z_108 Z_109 C_4 B_9 
Stack 8
B_10 A_5 A_3 C_6 
Stack 9
A_1 Z_110 B_7 Z_111 
Stack 10
B_0 Z_112 C_7 
Stack 11
C_0 B_1 Z_113 
