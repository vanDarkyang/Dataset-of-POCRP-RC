Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
J_2 Z_100 B_0 Z_101 
Stack 1
Z_102 F_1 C_2 Z_103 
Stack 2
D_0 I_5 E_1 K_0 
Stack 3
H_6 K_1 J_5 Z_104 
Stack 4
E_3 L_1 E_5 Z_105 
Stack 5
Z_106 E_4 D_4 Z_107 
Stack 6
B_3 H_4 N_1 G_6 
Stack 7
E_0 Z_108 H_2 H_3 
Stack 8
H_5 D_2 Z_109 C_0 
Stack 9
Z_110 G_4 Z_111 Z_112 
Stack 10
G_1 E_2 Z_113 J_3 
Stack 11
J_4 Z_114 I_3 Z_115 
Stack 12
F_3 L_2 I_1 G_2 
Stack 13
A_0 L_3 L_0 J_0 
Stack 14
G_0 O_1 Z_116 E_6 
Stack 15
Z_117 J_1 B_2 D_1 
Stack 16
Z_118 B_1 M_2 M_1 
Stack 17
Z_119 Z_120 Z_121 M_0 
Stack 18
G_3 I_2 H_1 G_5 
Stack 19
K_2 C_1 D_3 M_3 
Stack 20
Z_122 O_0 F_2 F_0 
Stack 21
Z_123 Z_124 Z_125 N_0 
Stack 22
H_0 Z_126 I_0 
Stack 23
Z_127 I_4 Z_128 
