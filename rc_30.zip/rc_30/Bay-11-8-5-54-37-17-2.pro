Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_5 Z_100 C_7 Z_101 E_6 
Stack 1
Z_102 D_1 A_4 B_6 E_5 
Stack 2
E_1 Z_103 C_5 Z_104 B_4 
Stack 3
A_2 Z_105 A_1 E_2 E_3 
Stack 4
D_6 Z_106 B_5 D_3 B_1 
Stack 5
D_0 Z_107 Z_108 Z_109 D_2 
Stack 6
C_6 C_4 Z_110 B_2 Z_111 
Stack 7
C_2 B_0 Z_112 C_3 B_3 
Stack 8
Z_113 D_7 Z_114 C_0 Z_115 
Stack 9
A_3 C_1 A_0 E_4 E_7 
Stack 10
Z_116 E_0 D_4 C_8 
