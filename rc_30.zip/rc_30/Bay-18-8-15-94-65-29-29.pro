Number Of Containers
94
Number Of Yard Stacks
18
MaxTier of Yard Stacks
8
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
Z_100 F_3 Z_101 Z_102 M_3 A_1 
Stack 1
Z_103 B_1 H_2 I_3 G_3 M_0 
Stack 2
N_1 M_2 G_1 J_1 H_3 O_0 
Stack 3
G_2 H_0 Z_104 L_2 Z_105 N_0 
Stack 4
C_1 Z_106 I_4 E_2 F_4 
Stack 5
Z_107 C_3 I_2 Z_108 K_0 
Stack 6
G_4 Z_109 L_0 A_0 H_4 
Stack 7
J_3 D_2 J_2 J_7 Z_110 
Stack 8
I_5 Z_111 J_5 O_2 I_0 
Stack 9
F_1 Z_112 D_0 J_4 L_1 
Stack 10
G_0 K_1 Z_113 D_1 C_4 
Stack 11
I_1 H_1 Z_114 Z_115 Z_116 
Stack 12
Z_117 E_0 J_6 Z_118 C_2 
Stack 13
E_3 K_2 Z_119 Z_120 C_0 
Stack 14
F_5 I_6 J_0 Z_121 O_1 
Stack 15
K_3 B_0 Z_122 Z_123 M_1 
Stack 16
Z_124 F_0 N_2 E_1 F_2 
Stack 17
Z_125 Z_126 Z_127 E_4 Z_128 
