Number Of Containers
54
Number Of Yard Stacks
14
MaxTier of Yard Stacks
6
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
C_4 Z_100 B_5 A_0 
Stack 1
E_7 D_1 D_5 Z_101 
Stack 2
A_5 D_7 Z_102 C_0 
Stack 3
E_3 D_4 Z_103 A_4 
Stack 4
C_1 Z_104 C_3 C_6 
Stack 5
A_2 Z_105 E_2 D_6 
Stack 6
B_4 B_0 C_5 E_5 
Stack 7
A_6 Z_106 Z_107 E_4 
Stack 8
B_2 A_3 D_0 Z_108 
Stack 9
E_6 E_0 B_6 E_1 
Stack 10
C_2 Z_109 B_3 Z_110 
Stack 11
Z_111 Z_112 D_2 D_3 
Stack 12
Z_113 Z_114 Z_115 
Stack 13
A_1 Z_116 B_1 
