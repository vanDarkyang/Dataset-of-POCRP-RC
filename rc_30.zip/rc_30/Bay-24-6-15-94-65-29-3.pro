Number Of Containers
94
Number Of Yard Stacks
24
MaxTier of Yard Stacks
6
Number of Vessel Stacks
15
Number Of Export Containers
65
Number Of Shutout Containers
29
Yard Bay
Stack 0
N_0 Z_100 Z_101 E_4 
Stack 1
F_0 M_0 J_2 M_4 
Stack 2
Z_102 Z_103 A_0 J_0 
Stack 3
E_5 L_0 Z_104 M_2 
Stack 4
C_2 Z_105 Z_106 F_1 
Stack 5
Z_107 E_0 C_1 Z_108 
Stack 6
G_4 G_2 Z_109 Z_110 
Stack 7
J_5 G_6 G_5 H_4 
Stack 8
Z_111 J_3 L_1 B_1 
Stack 9
Z_112 M_3 K_0 I_4 
Stack 10
J_4 H_2 O_1 F_4 
Stack 11
Z_113 K_3 Z_114 I_3 
Stack 12
E_3 D_1 J_1 E_1 
Stack 13
Z_115 H_5 Z_116 H_1 
Stack 14
N_2 M_1 F_2 H_3 
Stack 15
Z_117 Z_118 K_4 D_0 
Stack 16
Z_119 Z_120 I_5 C_0 
Stack 17
N_3 N_1 L_2 G_0 
Stack 18
Z_121 Z_122 I_0 G_1 
Stack 19
Z_123 K_1 G_3 Z_124 
Stack 20
Z_125 E_2 Z_126 H_0 
Stack 21
B_2 I_1 O_0 B_0 
Stack 22
F_3 I_2 A_1 
Stack 23
Z_127 Z_128 K_2 
