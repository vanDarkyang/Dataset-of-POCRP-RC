Number Of Containers
54
Number Of Yard Stacks
11
MaxTier of Yard Stacks
8
Number of Vessel Stacks
5
Number Of Export Containers
37
Number Of Shutout Containers
17
Yard Bay
Stack 0
D_1 C_3 C_4 Z_100 C_5 
Stack 1
Z_101 C_2 Z_102 Z_103 D_6 
Stack 2
C_9 Z_104 Z_105 B_1 Z_106 
Stack 3
C_1 A_1 Z_107 B_0 C_6 
Stack 4
E_1 Z_108 Z_109 A_0 E_2 
Stack 5
Z_110 D_0 C_8 E_7 A_3 
Stack 6
E_5 C_7 D_3 D_4 Z_111 
Stack 7
D_2 E_3 B_3 Z_112 A_2 
Stack 8
Z_113 E_4 B_5 A_4 C_0 
Stack 9
E_6 Z_114 Z_115 E_0 B_4 
Stack 10
C_10 Z_116 B_2 D_5 
