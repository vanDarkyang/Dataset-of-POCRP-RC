Number Of Containers
70
Number Of Yard Stacks
14
MaxTier of Yard Stacks
8
Number of Vessel Stacks
10
Number Of Export Containers
49
Number Of Shutout Containers
21
Yard Bay
Stack 0
Z_100 Z_101 C_3 D_1 F_3 
Stack 1
E_3 Z_102 D_0 I_4 A_3 
Stack 2
Z_103 B_2 G_2 G_0 I_1 
Stack 3
G_4 D_2 Z_104 J_2 J_1 
Stack 4
A_1 D_4 D_3 D_6 Z_105 
Stack 5
B_1 I_0 Z_106 D_5 G_1 
Stack 6
H_3 H_5 C_1 I_3 F_2 
Stack 7
B_0 Z_107 H_1 H_2 Z_108 
Stack 8
A_0 Z_109 Z_110 Z_111 E_1 
Stack 9
F_1 E_0 B_3 A_4 Z_112 
Stack 10
F_0 H_0 Z_113 C_0 Z_114 
Stack 11
E_5 G_3 A_2 Z_115 E_2 
Stack 12
C_2 Z_116 Z_117 Z_118 E_4 
Stack 13
H_4 Z_119 I_2 J_0 Z_120 
